import { menuHeader, menuFooter } from './theme.js';
import { listCommands } from '../../../src/core/registry.js';

// Menos portais, sem perder nenhum comando público registrado.
// Cada comando continua pertencendo à categoria técnica original, mas o menu
// apresenta uma categoria de UX mais combinada.
const GROUPS = [
  { key:'social', title:'👤 PERFIL • SOCIAL • COMUNIDADE', cats:new Set(['perfil','personal','comunidade']) },
  { key:'diversao', title:'🎮 DIVERSÃO • JOGOS • ALÉM', cats:new Set(['jogos','alem']) },
  { key:'universo', title:'🌌 RPG • ECONOMIA • MUNDO', cats:new Set(['rpg','economia','mundo','world-engine']) },
  { key:'competicao', title:'🏰 CLÃS • GUERRAS • CAMPEONATOS', cats:new Set(['clans','group-clan','wars','campeonato']) },
  { key:'ferramentas', title:'🤖 IA • DOWNLOADS • FERRAMENTAS • PREMIUM', cats:new Set(['ia','downloads','produtividade','mega-expansao','expansion','platform','premium']) },
  { key:'controle', title:'🛡️ TRIAGEM • ADMIN • SISTEMA', cats:new Set(['triagem','admin','dono','owner','sistema','seguranca']) }
];

const ALIASES = new Map([
  ['social','social'], ['perfil','social'], ['comunidade','social'],
  ['diversao','diversao'], ['jogos','diversao'], ['alem','diversao'],
  ['universo','universo'], ['rpg','universo'], ['economia','universo'], ['mundo','universo'],
  ['competicao','competicao'], ['competição','competicao'], ['clans','competicao'], ['guerras','competicao'], ['campeonato','competicao'],
  ['ferramentas','ferramentas'], ['ia','ferramentas'], ['downloads','ferramentas'], ['premium','ferramentas'],
  ['controle','controle'], ['triagem','controle'], ['admin','controle'], ['dono','controle'], ['sistema','controle']
]);

const PAGE_SIZE = 36;
const normalize = v => String(v ?? '').trim().toLowerCase();

function groupForCommand(cmd) {
  return GROUPS.find(g => g.cats.has(cmd.category)) || GROUPS[4];
}

function visibleCommands() {
  return listCommands({ includeHidden:false }).filter(c => c.enabled !== false);
}

function groupCommands(group) {
  return visibleCommands().filter(c => group.cats.has(c.category)).sort((a,b)=>a.name.localeCompare(b.name));
}

function renderIndex(prefix, commands, groupTitle, page) {
  const pages = Math.max(1, Math.ceil(commands.length / PAGE_SIZE));
  const safePage = Math.min(Math.max(Number(page) || 1, 1), pages);
  const slice = commands.slice((safePage-1)*PAGE_SIZE, safePage*PAGE_SIZE);
  const lines = slice.map((cmd,i) => {
    const number = String((safePage-1)*PAGE_SIZE+i+1).padStart(3,'0');
    return `┊ ${number} • ${prefix}${cmd.name}`;
  });
  return {
    page:safePage,
    pages,
    text:[
      `╭─👻────────────────────────╮`,
      `│       F A N T A S M I N H A`,
      `│          × CENTRAL DO ALÉM`,
      `╰───────────────────────────╯`,
      '',
      `╭─✦ ${groupTitle} • ${safePage}/${pages}`,
      `┊ Total: ${commands.length} comandos ativos`,
      ...lines,
      `┊`,
      `┊ 📖 Página ${safePage}/${pages}`,
      `┊ 💡 ${prefix}menu <categoria> <página>`,
      `╰────────────────────────────`
    ].join('\n')
  };
}

export default async function menu(prefix='×', botName='Fantasminha', userName='Usuário', customDesign=null, options={}) {
  const requested = normalize(options?.category || options?.categoria || '');
  const page = Number(options?.page || options?.pagina || 1) || 1;
  const selectedKey = ALIASES.get(requested);

  if (selectedKey) {
    const group = GROUPS.find(g=>g.key===selectedKey);
    const commands = groupCommands(group);
    const rendered = renderIndex(prefix, commands, group.title, page);
    return `${menuHeader(botName,userName,group.title)}\n\n${rendered.text}\n\n${menuFooter(`Use ${prefix}menu para voltar às categorias.`)}`;
  }

  const stats = GROUPS.map(g => ({...g, count:groupCommands(g).length}));
  const total = stats.reduce((n,g)=>n+g.count,0);
  return [
    menuHeader(botName,userName,'CENTRAL DO ALÉM'),
    '',
    '🌑 *CENTRAL DO ALÉM — NOVA ORGANIZAÇÃO*',
    '',
    'Um menu mais simples por fora e completo por dentro.',
    'Todos os comandos públicos registrados continuam disponíveis.',
    '',
    ...stats.map((g,i)=>`┊ ${i+1}. ${g.title} — *${g.count} comandos*`),
    '',
    `📦 *Total:* ${total} comandos públicos ativos`,
    '',
    `💡 Abra uma categoria: ${prefix}menu jogos 1`,
    `💡 Busca inteligente: ${prefix}buscar <termo>`,
    `💡 Ajuda detalhada: ${prefix}ajuda <comando>`,
    '',
    menuFooter(`Ex.: ${prefix}menu universo 1`)
  ].join('\n');
}

export { GROUPS, groupCommands, visibleCommands };
