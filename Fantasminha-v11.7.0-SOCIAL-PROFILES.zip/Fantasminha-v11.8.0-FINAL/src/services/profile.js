import { readCollection, getUser, upsertUser } from '../database/store.js';
import { listNicks } from '../platform/nick/index.js';
import relationshipManager from '../../dados/src/funcs/utils/relationships.js';

const clamp=(n,a=0,b=100)=>Math.max(a,Math.min(b,Number(n)||0));
const idBase=v=>String(v||'').split('@')[0];
const safePhone=v=>String(v||'').toLowerCase().endsWith('@s.whatsapp.net')&&/^\d+$/.test(idBase(v))?idBase(v):null;
const mention=u=>`@${idBase(u)}`;

export function recordMessage(userId,groupId){
  if(!userId||!groupId)return;
  globalThis.__profileActivity ||= {pending:new Map(),timer:null};
  const k=`${groupId}:${userId}`; const p=globalThis.__profileActivity.pending.get(k)||{userId,groupId,messages:0,days:{}};
  p.messages++; p.days[new Date().toISOString().slice(0,10)]=(p.days[new Date().toISOString().slice(0,10)]||0)+1;
  globalThis.__profileActivity.pending.set(k,p);
  if(!globalThis.__profileActivity.timer){globalThis.__profileActivity.timer=setInterval(flushActivity,30000);globalThis.__profileActivity.timer.unref?.();}
}
export async function flushActivity(){const state=globalThis.__profileActivity;if(!state?.pending?.size)return;const rows=[...state.pending.values()];state.pending.clear();const {updateCollection}=await import('../database/store.js');for(const p of rows)await updateCollection('profile_activity',d=>{d.byGroupUser??={};const k=`${p.groupId}:${p.userId}`;const cur=d.byGroupUser[k]||{userId:p.userId,groupId:p.groupId,messages:0,days:{}};cur.messages+=p.messages;for(const[k2,v]of Object.entries(p.days))cur.days[k2]=(cur.days[k2]||0)+v;cur.updatedAt=Date.now();d.byGroupUser[k]=cur;return d;},{byGroupUser:{}});}
function activity(groupId,userId){return readCollection('profile_activity',{byGroupUser:{}}).byGroupUser?.[`${groupId}:${userId}`]||{messages:0,days:{}};}
function presenceScore(row){const days=Object.keys(row.days||{}).length;return clamp(days*8);}
function groupActivityScore(groupId,userId){const d=readCollection('profile_activity',{byGroupUser:{}});const vals=Object.values(d.byGroupUser||{}).filter(x=>x.groupId===groupId).map(x=>Number(x.messages)||0);const mine=Number(d.byGroupUser?.[`${groupId}:${userId}`]?.messages)||0;if(!mine||!vals.length)return 0;const sorted=[...vals].sort((a,b)=>b-a),rank=sorted.findIndex(x=>x<=mine);return clamp(100-(Math.max(0,rank)*100/Math.max(1,sorted.length-1)));}
function relationships(userId){try{const pair=relationshipManager.getActivePairForUser(userId);return pair?{partnerId:pair.partnerId,status:pair.pair?.status||pair.status||'relacionamento'}:{partnerId:null,status:null};}catch{return{partnerId:null,status:null}}}
function reputation(userId){const d=readCollection('reputation',{byId:{}});return Number(d.byId?.[userId]?.score ?? getUser(userId)?.reputation ?? 0)||0;}
function gameStats(userId){const d=readCollection('game_stats',{byUser:{}});return d.byUser?.[userId]||{plays:0,wins:0};}
function latestTriage(userId,groupId){const d=readCollection('triage',{byId:{}});return Object.values(d.byId||{}).filter(t=>t.userId===userId&&(!groupId||t.groupId===groupId)&&['aprovado','aguardando_julgamento','em_andamento'].includes(t.state)).sort((a,b)=>b.createdAt-a.createdAt)[0]||null;}
export async function buildPublicProfile({userId,displayUserId=null,groupId,pushname='',groupParticipants=[],groupAdmins=[],groupModerators=[]}){
  const u=await upsertUser(userId,{name:pushname||''});
  const role=groupAdmins.some(x=>String(x).split('@')[0]===String(userId).split('@')[0])?'ADM':(groupModerators.some(x=>String(x).split('@')[0]===String(userId).split('@')[0])?'MOD':'Membro');
  const tri=latestTriage(userId,groupId); const act=activity(groupId,userId); const rel=relationships(userId); const games=gameStats(userId); const nick=listNicks(groupId).find(x=>x.platformId===userId||x.memberId===userId);
  const participants=groupParticipants.filter(Boolean); const messages=Number(act.messages)||0; const interactions=Number(u.interactions||0);
  const presence=presenceScore(act), activityScore=groupActivityScore(groupId,userId);
  const prestige=clamp((Math.min(30,messages/20)*1.2)+(Math.min(20,interactions/5))+(Math.min(20,Number(u.rpg?.level||1)))+(Math.min(15,reputation(userId)/10))+(Math.min(15,Number(u.achievementsCount||0))));
  const chaos=clamp(Number(u.chaosScore||0));
  const position=participants.length?participants.map(x=>({id:x,m:Number(activity(groupId,x).messages)||0})).sort((a,b)=>b.m-a.m).findIndex(x=>x.id===userId)+1:null;
  return {userId,displayUserId:displayUserId||userId,number:safePhone(displayUserId)||null,name:tri?.answers?.find(a=>/nome/i.test(a.question))?.value||u.name||pushname||'Não informado',nick:nick?.nick||'Não definido',birthday:tri?.answers?.find(a=>/nasc|anivers/i.test(a.question))?.value||'Não informado',role,premium:!!u.premium?.active,status:u.status||'Normal',messages,interactions,interactionPercent:0,position,vacilos:Number(u.warns||0),married:rel.status==='casamento'?rel.partnerId:null,bestFriend:u.bestFriend||null,presence,activity:activityScore,prestige,chaos,games,level:Number(u.rpg?.level||1),xp:Number(u.rpg?.xp||0),achievements:Number(u.achievementsCount||0),triageId:tri?.id||null,registeredAt:tri?.createdAt||null,participants:participants.length};
}
export function profileText(p,interactionTotal=0){const pct=interactionTotal?clamp((p.interactions/interactionTotal)*100):0;const bar=n=>{const x=Math.round(clamp(n)/10);return '█'.repeat(x)+'░'.repeat(10-x)};return`╭─═─═─═─═─═─═─═─═─═─╮\n👻 *FICHA DA ALMA*\n╰─═─═─═─═─═─═─═─═─═─╯\n\n    👤 ${mention(p.displayUserId||p.userId)}\n    \`${p.number.slice(0,2)} •••• ${p.number.slice(-4)}\`\n\n╭─「 🪪 IDENTIFICAÇÃO 」\n│ Nome ........ "${p.name}"\n│ Nick ........ "${p.nick}"\n│ Nascimento .. "${p.birthday}"\n│ Cargo ....... "${p.role}${p.premium?' · 💎 Premium':''}"\n│ Status ...... "${p.status}"\n╰────────────────────\n\n╭─「 📈 REGISTRO 」\n│ 💬 Mensagens .... "${p.messages}"\n│ ⚡ Interações ... "${p.interactions}" · "${pct.toFixed(1)}%"\n│ 🏆 Posição ...... "${p.position?`#${p.position}`:'—'}"\n│ ⚠️ Vacilos ...... "${p.vacilos}"\n╰────────────────────\n\n╭─「 💕 VÍNCULOS 」\n│ 💍 Casado com\n│    ↳ ${p.married?mention(p.married):'Ninguém'}\n│\n│ 🫂 Best Friend\n│    ↳ ${p.bestFriend?mention(p.bestFriend):'Não definido'}\n╰────────────────────\n\n╭─「 🎭 PERFIL DA ALMA 」\n│\n│ 👻 Presença\n│ ${bar(p.presence)} "${p.presence}%"\n│\n│ ⚡ Atividade\n│ ${bar(p.activity)} "${Math.round(p.activity)}%"\n│\n│ 🏆 Prestígio\n│ ${bar(p.prestige)} "${Math.round(p.prestige)}%"\n│\n│ 😈 Caos\n│ ${bar(p.chaos)} "${Math.round(p.chaos)}%"\n│ _Análise recreativa; não é diagnóstico._\n╰────────────────────\n\n╭─「 🪪 REGISTRO 」\n│ Nº da ficha: "${p.triageId||'Ainda não registrado'}"\n│ 📅 Registrado em: "${p.registeredAt?new Date(p.registeredAt).toLocaleDateString('pt-BR'):'—'}"\n╰────────────────────\n\n╰─「 ×perfil 」─╯`;}
