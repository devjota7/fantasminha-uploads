#!/usr/bin/env node

/**
 * 👻 Fantasminha — Atualizador oficial por release GitHub
 *
 * Segurança/robustez:
 * - consulta latest.json no repositório configurado
 * - aceita download_url OU zip (deriva URL raw do GitHub)
 * - valida versão, ZIP, caminhos e package.json
 * - valida SHA-256 quando informado
 * - preserva .env, sessão WhatsApp, banco, mídias, logs e config local
 * - preserva config.json local para não obrigar o dono a reconfigurar o bot após cada atualização
 * - NÃO apaga arquivos locais desconhecidos
 * - cria e valida um snapshot de rollback antes de substituir a instalação
 * - limpa apenas arquivos que a própria release anterior registrou como pertencentes ao código
 * - verifica por SHA-256 que .env, sessão, banco, mídias, logs e config local não mudaram
 * - instala dependências somente quando necessário
 * - valida a instalação antes de concluir
 * - registra .last-update.json
 */

import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath, pathToFileURL } from 'url';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = process.cwd();

const CONFIG_FILE = path.join(ROOT, 'dados', 'src', 'config.json');
const ENV_FILE = path.join(ROOT, '.env');
const OWNED_FILES_MANIFEST = path.join(ROOT, '.update-owned-files.json');
const TEMP_ROOT = path.join(ROOT, '.update-tmp');

const DEFAULT_OWNER = 'devjota7';
const DEFAULT_REPO = 'fantasminha-uploads';
const DEFAULT_BRANCH = 'main';

// Dados locais que NUNCA devem ser substituídos por uma release.
const protectedRelative = [
  '.env',
  'dados/src/config.json',
  '.update-owned-files.json',
  'data/auth',
  'data/db',
  'data/backups',
  'auth',
  'session',
  'sessions',
  'dados/database',
  'dados/midias',
  'logs'
];

function log(message) { console.log(`[FANTASMINHA UPDATE] ${message}`); }
function fail(message) { console.error(`[FANTASMINHA UPDATE] ❌ ${message}`); }

function normalize(p) {
  return p.split(path.sep).join('/').replace(/^\.\//, '');
}

function isProtected(rel) {
  const n = normalize(rel);
  return protectedRelative.some(item => n === item || n.startsWith(`${item}/`));
}

function safeResolve(rel) {
  const target = path.resolve(ROOT, rel);
  const root = path.resolve(ROOT) + path.sep;
  if (target !== path.resolve(ROOT) && !target.startsWith(root)) {
    throw new Error(`Caminho inseguro: ${rel}`);
  }
  return target;
}

function envValue(name) {
  try {
    if (!fsSync.existsSync(ENV_FILE)) return '';
    const text = fsSync.readFileSync(ENV_FILE, 'utf8');
    const line = text.split(/\r?\n/).find(l => l.trim().startsWith(`${name}=`));
    return line ? line.slice(line.indexOf('=') + 1).trim().replace(/^['"]|['"]$/g, '') : '';
  } catch {
    return '';
  }
}

async function readLocalConfig() {
  try {
    return JSON.parse(await fs.readFile(CONFIG_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function githubInfo(config) {
  let owner = envValue('GITHUB_OWNER') || config.githubOwner || config.autor || DEFAULT_OWNER;
  let repo = envValue('GITHUB_REPO') || config.githubRepo || config.repositorio || DEFAULT_REPO;
  const branch = envValue('GITHUB_BRANCH') || DEFAULT_BRANCH;

  // github_ofc é a fonte mais direta quando não há override no .env/config.
  if (!envValue('GITHUB_OWNER') && !envValue('GITHUB_REPO') && config.github_ofc) {
    const m = String(config.github_ofc).match(/^https?:\/\/github\.com\/([^/]+)\/([^/#?]+)/i);
    if (m) {
      owner = m[1];
      repo = m[2].replace(/\.git$/i, '');
    }
  }

  const base = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}`;
  return { owner, repo, branch, base, manifestUrl: `${base}/latest.json` };
}

function headers() {
  return {
    Accept: 'application/json'
  };
}

async function fetchJson(url) {
  const response = await fetch(url, { headers: headers(), redirect: 'follow' });
  if (!response.ok) throw new Error(`HTTP ${response.status} ao acessar ${url}`);
  return response.json();
}

function releaseDownloadUrl(manifest, github) {
  if (manifest.download_url) return String(manifest.download_url);
  if (manifest.zip) {
    const zip = path.posix.basename(String(manifest.zip));
    if (!/^Fantasminha-v[\w.-]+\.zip$/i.test(zip)) {
      throw new Error('Nome do ZIP inválido no latest.json.');
    }
    return `${github.base}/${encodeURIComponent(zip)}`;
  }
  throw new Error('latest.json precisa informar download_url ou zip.');
}

function assertReleaseUrl(url, github) {
  let parsed;
  try { parsed = new URL(url); } catch { throw new Error('download_url inválido.'); }
  const expected = new URL(github.base + '/');
  const isGithubRaw = parsed.hostname === expected.hostname && parsed.pathname.startsWith(expected.pathname);
  const isGithubRelease = parsed.hostname === 'github.com' && parsed.pathname.startsWith(`/${github.owner}/${github.repo}/`);
  if (!isGithubRaw && !isGithubRelease) {
    throw new Error('download_url precisa apontar para o GitHub configurado.');
  }
}

function compareVersions(a, b) {
  const pa = String(a).replace(/^v/i, '').split('.').map(x => Number.parseInt(x, 10) || 0);
  const pb = String(b).replace(/^v/i, '').split('.').map(x => Number.parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

async function download(url, destination) {
  assertReleaseUrl(url, await readLocalConfig().then(c => githubInfo(c)));
  const response = await fetch(url, { headers: headers(), redirect: 'follow' });
  if (!response.ok) throw new Error(`HTTP ${response.status} ao baixar ZIP`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length < 100) throw new Error('Download do ZIP parece vazio ou inválido');
  await fs.writeFile(destination, buffer);
  return buffer.length;
}

async function sha256(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fsSync.createReadStream(file);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

async function zipList(zipFile) {
  const { stdout } = await execFileAsync('unzip', ['-Z1', zipFile], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
  return stdout.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
}

async function extract(zipFile, destination) {
  await fs.mkdir(destination, { recursive: true });
  await execFileAsync('unzip', ['-q', zipFile, '-d', destination], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
}

async function detectPayloadDir(extracted) {
  const entries = await fs.readdir(extracted, { withFileTypes: true });
  const dirs = entries.filter(e => e.isDirectory() && e.name !== '__MACOSX');
  const files = entries.filter(e => e.isFile());
  if (files.length || dirs.length !== 1) return extracted;
  const candidate = path.join(extracted, dirs[0].name);
  const nestedEntries = await fs.readdir(candidate);
  if (nestedEntries.some(n => n === 'package.json' || n === 'dados' || n === 'src')) return candidate;
  return extracted;
}

async function currentVersion() {
  try {
    const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
    return pkg.version || envValue('BOT_VERSION') || 'desconhecida';
  } catch {
    return envValue('BOT_VERSION') || 'desconhecida';
  }
}

async function readOwnedFiles() {
  try {
    const data = JSON.parse(await fs.readFile(OWNED_FILES_MANIFEST, 'utf8'));
    return Array.isArray(data.files) ? data.files.map(normalize).filter(Boolean) : [];
  } catch {
    return [];
  }
}

async function writeOwnedFiles(payload) {
  const files = [];
  async function walk(dir, prefix = '') {
    const entries = await fs.readdir(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (entry.name === '__MACOSX' || entry.name === 'node_modules') continue;
      const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
      const src = path.join(dir, entry.name);
      if (entry.isDirectory()) await walk(src, rel);
      else if (entry.isFile() && !isProtected(rel)) files.push(normalize(rel));
    }
  }
  await walk(payload);
  await fs.writeFile(OWNED_FILES_MANIFEST, JSON.stringify({
    version: 1,
    updatedAt: new Date().toISOString(),
    files: [...new Set(files)].sort()
  }, null, 2) + '\n');
}

async function copyTreeFiltered(source, destination, filterProtected = true, relativePrefix = '') {
  await fs.mkdir(destination, { recursive: true });
  const entries = await fs.readdir(source, { withFileTypes: true });
  for (const entry of entries) {
    if (entry.name === '__MACOSX' || entry.name === 'node_modules' || entry.name === '.update-tmp') continue;
    const rel = relativePrefix ? `${relativePrefix}/${entry.name}` : entry.name;
    if (filterProtected && isProtected(rel)) continue;
    const src = path.join(source, entry.name);
    const dst = path.join(destination, entry.name);
    if (entry.isDirectory()) {
      await copyTreeFiltered(src, dst, filterProtected, rel);
    } else if (entry.isFile()) {
      await fs.mkdir(path.dirname(dst), { recursive: true });
      await fs.copyFile(src, dst);
    }
  }
}

async function removeOwnedFilesOnly() {
  const owned = await readOwnedFiles();
  if (!owned.length) {
    log('🛡️ Nenhum manifesto de arquivos antigos encontrado; NÃO apagando arquivos locais desconhecidos.');
    return;
  }
  log(`🧹 Limpando somente ${owned.length} arquivo(s) pertencentes à release anterior...`);
  for (const rel of owned) {
    if (isProtected(rel)) continue;
    try { await fs.rm(safeResolve(rel), { recursive: true, force: true }); } catch {}
  }
}

// Compatibilidade com testes/integrações antigas: a limpeza agora é
// explicitamente conservadora e nunca remove dados/arquivos locais fora do
// manifesto da release. Em primeira atualização, ela não apaga nada.
async function clearNonProtectedTree() {
  await removeOwnedFilesOnly();
}

async function clearNonProtected() {
  await removeOwnedFilesOnly();
}

async function copyPayload(payload) {
  log('🚀 Aplicando a nova versão sem apagar dados locais...');
  await copyTreeFiltered(payload, ROOT, true);
  await writeOwnedFiles(payload);
}

function packageDependenciesChanged(oldPackage, newPackage) {
  if (!oldPackage || !newPackage) return true;
  const keys = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies', 'packageManager'];
  return keys.some(k => JSON.stringify(oldPackage[k] || {}) !== JSON.stringify(newPackage[k] || {}));
}

async function installDependencies() {
  log('📦 Instalando/verificando dependências...');
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  await execFileAsync(npm, ['install', '--no-audit', '--no-fund'], {
    cwd: ROOT,
    maxBuffer: 30 * 1024 * 1024
  });
}

async function createValidatedBackup() {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupDir = path.join(ROOT, 'data', 'backups');
  const backupFile = path.join(backupDir, `update-${stamp}.tar.gz`);
  await fs.mkdir(backupDir, { recursive: true });
  log(`💾 Criando backup/rollback validável: ${normalize(path.relative(ROOT, backupFile))}`);
  await execFileAsync('tar', [
    '-czf', backupFile,
    '--exclude=./node_modules',
    '--exclude=./.git',
    '--exclude=./.update-tmp',
    '--exclude=./data/backups',
    '-C', ROOT, '.'
  ], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });

  const stat = await fs.stat(backupFile);
  if (!stat.isFile() || stat.size < 1024) throw new Error('Backup criado, mas parece vazio/inválido.');
  const listing = (await execFileAsync('tar', ['-tzf', backupFile], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 })).stdout;
  for (const required of ['package.json', 'package-lock.json', 'dados/src/funcs/private/ia.js', 'dados/src/services/assistantV2Core.js']) {
    const normalized = required.replace(/^\.\//, '');
    if (!listing.split(/\r?\n/).some(line => line.replace(/^\.\//, '') === normalized)) {
      throw new Error(`Backup inválido: arquivo crítico ausente: ${required}`);
    }
  }
  log(`💾 Backup validado (${Math.round(stat.size / 1024)} KB).`);
  return backupFile;
}

async function rollbackFromBackup(backupFile) {
  if (!backupFile || !fsSync.existsSync(backupFile)) throw new Error('Backup de rollback não encontrado.');
  log('↩️ Iniciando rollback da instalação anterior...');
  await execFileAsync('tar', ['-xzf', backupFile, '--overwrite', '-C', ROOT], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 });
  const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
  if (!pkg?.version) throw new Error('Rollback terminou sem package.json válido.');
  log(`↩️ Rollback concluído para v${pkg.version}.`);
}

async function validateReleaseTree(payload) {
  const script = path.join(payload, 'scripts', 'validate-release.mjs');
  if (!fsSync.existsSync(script)) throw new Error('Release sem scripts/validate-release.mjs; pacote não pode ser confiável.');
  await execFileAsync(process.execPath, [script], { cwd: payload, maxBuffer: 30 * 1024 * 1024 });
}

async function validatePostUpdate(expectedVersion) {
  const validateScript = path.join(ROOT, 'scripts', 'validate-release.mjs');
  if (fsSync.existsSync(validateScript)) await execFileAsync(process.execPath, [validateScript], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 });
  const assistantTest = path.join(ROOT, 'tests', 'assistant-v2-core-hardening.mjs');
  if (fsSync.existsSync(assistantTest)) await execFileAsync(process.execPath, [assistantTest], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 });
  const runtimeHealth = path.join(ROOT, 'scripts', 'validate-runtime.mjs');
  if (fsSync.existsSync(runtimeHealth)) await execFileAsync(process.execPath, [runtimeHealth], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 });
  const bootstrap = path.join(ROOT, 'scripts', 'validate-bootstrap.mjs');
  if (fsSync.existsSync(bootstrap)) await execFileAsync(process.execPath, [bootstrap], { cwd: ROOT, maxBuffer: 30 * 1024 * 1024 });
  const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
  if (String(pkg.version) !== String(expectedVersion)) throw new Error(`Health check: package.json ficou em ${pkg.version}, esperado ${expectedVersion}`);
}

async function ensureRuntimeDirectories() {
  // A release nunca publica sessão/banco/mídia reais, mas a instalação limpa
  // precisa ter os diretórios de runtime antes da validação pós-update.
  const dirs = [
    path.join(ROOT, 'dados', 'database'),
    path.join(ROOT, 'dados', 'database', 'qr-code'),
    path.join(ROOT, 'dados', 'database', 'grupos'),
    path.join(ROOT, 'dados', 'midias'),
    path.join(ROOT, 'logs'),
    path.join(ROOT, 'data', 'auth'),
    path.join(ROOT, 'data', 'db'),
    path.join(ROOT, 'data', 'backups')
  ];
  for (const dir of dirs) await fs.mkdir(dir, { recursive: true });
  try { await fs.chmod(path.join(ROOT, 'dados', 'database', 'qr-code'), 0o700); } catch {}
}

async function validateInstall(expectedVersion) {
  log('🧪 Validando a instalação...');
  const pkgPath = path.join(ROOT, 'package.json');
  if (!fsSync.existsSync(pkgPath)) throw new Error('package.json não existe após a atualização');
  const pkg = JSON.parse(await fs.readFile(pkgPath, 'utf8'));
  if (expectedVersion && String(pkg.version) !== String(expectedVersion)) {
    throw new Error(`package.json ficou na versão ${pkg.version}, mas a release declara ${expectedVersion}`);
  }
  const syntaxScript = path.join(ROOT, 'scripts', 'syntax-check.mjs');
  if (fsSync.existsSync(syntaxScript)) {
    await execFileAsync(process.execPath, [syntaxScript], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
  } else {
    const indexPath = path.join(ROOT, 'dados', 'src', 'index.js');
    if (fsSync.existsSync(indexPath)) await execFileAsync(process.execPath, ['--check', indexPath], { cwd: ROOT });
  }
}


async function verifyProtectedState(before) {
  const failures = [];
  for (const [rel, expected] of Object.entries(before || {})) {
    const target = safeResolve(rel);
    let actual = null;
    try {
      const st = await fs.stat(target);
      if (st.isFile()) actual = await sha256(target);
      else if (st.isDirectory()) actual = `DIR:${st.size}:${st.mtimeMs}`;
    } catch { actual = null; }
    if (expected !== actual) failures.push(rel);
  }
  if (failures.length) throw new Error(`Proteção de dados falhou; itens alterados: ${failures.join(', ')}`);
}

async function snapshotProtectedState() {
  const tracked = ['.env', 'dados/src/config.json', 'data/auth', 'data/db', 'data/fantasminha.sqlite', 'data/backups', 'auth', 'session', 'sessions', 'dados/database', 'dados/midias', 'logs'];
  const out = {};
  for (const rel of tracked) {
    const target = safeResolve(rel);
    try {
      const st = await fs.stat(target);
      if (st.isFile()) out[rel] = await sha256(target);
      else if (st.isDirectory()) out[rel] = `DIR:${st.size}:${st.mtimeMs}`;
    } catch {}
  }
  return out;
}

async function main() {
  const config = await readLocalConfig();
  const github = githubInfo(config);
  const temp = path.join(TEMP_ROOT, `run-${Date.now()}`);
  const zipFile = path.join(temp, 'release.zip');
  const extracted = path.join(temp, 'extracted');
  let oldPackageSnapshot = null;
  let protectedBefore = null;
  let backupFile = null;
  let updateApplied = false;

  try {
    log(`🔎 Consultando ${github.owner}/${github.repo}...`);
    const manifest = await fetchJson(github.manifestUrl);
    if (!manifest || !manifest.version) throw new Error('latest.json inválido: versão ausente');
    if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(String(manifest.version))) {
      throw new Error(`Versão inválida no latest.json: ${manifest.version}`);
    }

    const oldVersion = await currentVersion();
    const cmp = compareVersions(manifest.version, oldVersion);
    log(`📌 Versão instalada: ${oldVersion}`);
    log(`🚀 Release encontrada: ${manifest.version}`);
    log('🔐 Proteção de dados locais: .env, sessão WhatsApp, bancos, mídias, logs, config e arquivos locais desconhecidos não serão apagados.');

    if (!manifest.sha256 || !/^[0-9a-f]{64}$/i.test(String(manifest.sha256))) {
      throw new Error('RELEASE INVALID: latest.json precisa conter SHA-256 exato do ZIP publicado.');
    }
    if (cmp < 0 && manifest.allow_downgrade !== true && manifest.force !== true) {
      throw new Error(`A release ${manifest.version} é anterior à instalada ${oldVersion}. Downgrade bloqueado.`);
    }

    const downloadUrl = releaseDownloadUrl(manifest, github);
    assertReleaseUrl(downloadUrl, github);

    await fs.mkdir(temp, { recursive: true });
    log('📥 Baixando a versão do GitHub...');
    const size = await download(downloadUrl, zipFile);
    log(`📥 Download concluído (${Math.round(size / 1024)} KB).`);

    const actualHash = await sha256(zipFile);
    if (actualHash.toLowerCase() !== String(manifest.sha256).toLowerCase()) {
      throw new Error(`SHA-256 não confere!\nEsperado: ${manifest.sha256}\nObtido:   ${actualHash}`);
    }
    log('🔐 SHA-256 verificado com sucesso.');

    const names = await zipList(zipFile);
    const requiredFiles = Array.isArray(manifest.requiredFiles) && manifest.requiredFiles.length
      ? manifest.requiredFiles.map(String)
      : ['dados/src/services/assistantV2Core.js', 'dados/src/funcs/private/ia.js', 'package.json', 'package-lock.json'];
    if (names.some(n => n.includes('..') || path.isAbsolute(n) || /^[A-Za-z]:[\\/]/.test(n))) {
      throw new Error('ZIP contém caminho inseguro');
    }
    for (const required of requiredFiles) {
      if (!names.includes(required) && !names.some(n => n.endsWith(`/${required}`))) throw new Error(`RELEASE INVALID: ZIP sem arquivo obrigatório: ${required}`);
    }
    if (manifest.size !== undefined && Number(manifest.size) !== size) throw new Error(`Tamanho do ZIP divergente: manifesto=${manifest.size} download=${size}`);
    log(`📦 Arquivos obrigatórios verificados: ${requiredFiles.length}.`);

    await extract(zipFile, extracted);
    const payload = await detectPayloadDir(extracted);
    await validateReleaseTree(payload);

    if (cmp === 0 && manifest.force !== true) {
      log('✅ Release remota validada por conteúdo, imports e SHA-256. O bot já está na versão mais recente.');
      return;
    }
    const packagePath = path.join(payload, 'package.json');
    const newPkg = JSON.parse(await fs.readFile(packagePath, 'utf8'));
    const oldPackagePath = path.join(ROOT, 'package.json');
    const oldPkg = fsSync.existsSync(oldPackagePath) ? JSON.parse(await fs.readFile(oldPackagePath, 'utf8')) : null;
    oldPackageSnapshot = oldPkg;

    if (String(newPkg.version) !== String(manifest.version)) {
      throw new Error(`package.json da release é ${newPkg.version}, mas latest.json declara ${manifest.version}`);
    }

    protectedBefore = await snapshotProtectedState();
    backupFile = await createValidatedBackup();
    await clearNonProtected();
    await copyPayload(payload);
    updateApplied = true;

    if (packageDependenciesChanged(oldPkg, newPkg) || !fsSync.existsSync(path.join(ROOT, 'node_modules'))) {
      await installDependencies();
    }

    await ensureRuntimeDirectories();
    await validateInstall(manifest.version);
    await validatePostUpdate(manifest.version);
    await verifyProtectedState(protectedBefore);

    await fs.writeFile(
      path.join(ROOT, '.last-update.json'),
      JSON.stringify({
        from: oldVersion,
        version: manifest.version,
        updatedAt: new Date().toISOString(),
        source: downloadUrl,
        sha256: manifest.sha256 || null
      }, null, 2)
    );

    log(`🎉 Atualização ${oldVersion} → ${manifest.version} concluída.`);
    log('🔐 .env, sessão WhatsApp e banco foram preservados sem criar backup extra.');
    log('🛡️ PRESERVAÇÃO CONFIRMADA: dados locais e configuração permaneceram intactos.');
    log('🔄 Encerrando com código 0 para o supervisor reiniciar o bot.');
  } catch (error) {
    fail(error?.stack || error?.message || String(error));
    if (updateApplied && backupFile) {
      try {
        await rollbackFromBackup(backupFile);
        updateApplied = false;
      } catch (rollbackError) {
        fail(`ROLLBACK FALHOU: ${rollbackError?.stack || rollbackError?.message || rollbackError}`);
      }
    }
    if (protectedBefore) {
      try { await verifyProtectedState(protectedBefore); log('🔐 Dados locais conferidos após falha e permanecem intactos.'); } catch (guardError) { fail(`ALERTA DE PRESERVAÇÃO: ${guardError.message}`); }
    }
    process.exitCode = 1;
  } finally {
    try { await fs.rm(temp, { recursive: true, force: true }); } catch {}
  }
}

export { clearNonProtected, clearNonProtectedTree, ensureRuntimeDirectories, isProtected, protectedRelative, createValidatedBackup, rollbackFromBackup, validateReleaseTree, validatePostUpdate };

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) main();
