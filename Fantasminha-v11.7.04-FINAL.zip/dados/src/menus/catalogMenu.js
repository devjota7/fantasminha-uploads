import { MENU_THEME, menuHeader, menuFooter } from './theme.js';
import { listCommands } from '../../../src/core/registry.js';

/*
 * FANTASMINHA — catálogo único de navegação.
 *
 * Regra fundamental:
 * - listCommands() representa comandos CANÔNICOS; aliases nunca entram no menu.
 * - includeHidden:true garante que um comando canônico habilitado não desapareça
 *   do catálogo só porque foi marcado como hidden em uma camada antiga.
 * - permissões continuam sendo respeitadas: cada usuário vê o que pode executar.
 * - nenhum menu mantém uma lista manual de centenas de comandos.
 */

export const MENU_STRUCTURE = {
  social: {
    title: '👤 SOCIAL',
    categories: ['perfil', 'personal', 'conquistas'],
    fallback: 'Social'
  },
  jogos: {
    title: '🎮 JOGOS',
    categories: ['jogos', 'quiz', 'rankings', 'brincadeiras', 'competitivo', 'torneios'],
    plugins: ['quizEngine', 'forca', 'stop', 'gartic', 'innovation', 'ranking', 'completeExpansion']
  },
  rpg: {
    title: '⚔️ RPG',
    categories: ['rpg', 'economia', 'mundo', 'world-engine'],
    fallback: 'RPG'
  },
  bn: {
    title: '🤖 BN / IA',
    categories: ['ia'],
    fallback: 'BN / IA'
  },
  ferramentas: {
    title: '🛠️ FERRAMENTAS',
    categories: ['ferramentas', 'utilidades', 'produtividade', 'downloads', 'figurinhas', 'media', 'geral', 'alem', 'mega-expansao', 'expansion', 'platform'],
    fallback: 'Ferramentas'
  },
  grupo: {
    title: '👥 GRUPO',
    categories: ['comunidade', 'clans', 'group-clan', 'wars', 'campeonato'],
    fallback: 'Grupo'
  },
  adm: {
    title: '🛡️ ADM',
    categories: ['admin', 'triagem'],
    fallback: 'Administração'
  },
  dono: {
    title: '👑 DONO',
    categories: ['dono', 'owner'],
    minPermission: 80
  },
  sistema: {
    title: '⚙️ SISTEMA',
    categories: ['sistema', 'seguranca'],
    fallback: 'Sistema'
  }
};

export const CATEGORY_ALIASES = {
  social: 'social',
  social: 'social',
  jogos: 'jogos',
  jogo: 'jogos',
  games: 'jogos',
  rpg: 'rpg',
  bn: 'bn',
  ia: 'bn',
  inteligencia: 'bn',
  ferramentas: 'ferramentas',
  ferramentas: 'ferramentas',
  grupo: 'grupo',
  comunidade: 'grupo',
  adm: 'adm',
  admin: 'adm',
  administracao: 'adm',
  triagem: 'adm',
  dono: 'dono',
  owner: 'dono',
  sistema: 'sistema',
  seguranca: 'sistema'
};

const ROLE_LABEL = new Map([
  [100, 'Dono'], [80, 'Bot Admin'], [60, 'Admin'], [50, 'Moderador'], [40, 'VIP'], [10, 'Membro']
]);

function normalize(value) {
  return String(value ?? '').trim().toLowerCase();
}

function commandAllowed(command, options = {}) {
  if (command.enabled === false) return false;
  const userPermission = Number(options.permission ?? 10);
  const required = Number(command.permission ?? 10);
  return userPermission >= required;
}

function categoryForCommand(command) {
  const category = normalize(command.category || 'geral');
  const plugin = normalize(command.plugin || '');

  for (const [key, definition] of Object.entries(MENU_STRUCTURE)) {
    if (definition.categories?.includes(category)) return key;
    if (definition.plugins?.includes(command.plugin)) return key;
    if (key === 'jogos' && plugin && definition.plugins?.some(p => p.toLowerCase() === plugin)) return key;
  }

  // Sistema só fica no portal próprio quando o comando é realmente restrito.
  if (['sistema', 'seguranca'].includes(category)) {
    return Number(command.permission ?? 10) >= 80 ? 'dono' : 'sistema';
  }

  // Fallback obrigatório: nenhum comando canônico fica órfão.
  return 'ferramentas';
}

function subcategoryForCommand(command, topLevel) {
  if (command.subcategory) return String(command.subcategory);
  const category = normalize(command.category || 'geral');

  const labels = {
    social: {
      perfil: '👤 Perfil', personal: '🤝 Interações', conquistas: '🏅 Conquistas'
    },
    jogos: {
      quiz: '🎯 Quiz', rankings: '🏆 Rankings', brincadeiras: '🎲 Brincadeiras',
      competitivo: '⚔️ Competitivo', torneios: '🏟️ Torneios', jogos: '🎮 Jogos e Brincadeiras'
    },
    rpg: {
      rpg: '⚔️ RPG', economia: '💰 Economia', mundo: '🌎 Mundo Vivo', 'world-engine': '🌎 Mundo Vivo'
    },
    bn: { ia: '🧠 Inteligência / IA' },
    ferramentas: {
      ferramentas: '🛠️ Ferramentas', utilidades: '⏱️ Utilidades', produtividade: '📝 Produtividade',
      downloads: '📥 Downloads', figurinhas: '🖼️ Figurinhas', media: '🖼️ Mídia',
      alem: '🌑 Além', 'mega-expansao': '🚀 Expansões', expansion: '🚀 Expansões', platform: '🚀 Plataforma', geral: '🧰 Geral'
    },
    grupo: {
      comunidade: '👥 Grupo / Comunidade', clans: '🏰 Clãs', 'group-clan': '🏰 Clãs', wars: '⚔️ Guerras', campeonato: '🏟️ Campeonatos'
    },
    adm: { admin: '🛡️ Administração', triagem: '⚖️ Triagem' },
    dono: { dono: '👑 Proprietário', owner: '👑 Proprietário' },
    sistema: { sistema: '⚙️ Sistema', seguranca: '🔐 Segurança' }
  };

  return labels[topLevel]?.[category] || `📂 ${String(command.category || 'Geral').toUpperCase()}`;
}

/**
 * Organiza uma lista de comandos sem perder nenhum comando canônico.
 * Retorna também total/duplicados/orphans para testes de integridade.
 */
export function organizeCommands(commands, options = {}) {
  const groups = new Map();
  const seen = new Set();
  const duplicates = [];
  const visible = [];

  for (const command of commands || []) {
    if (!command?.name || !commandAllowed(command, options)) continue;
    const name = normalize(command.name);
    if (!name) continue;
    if (seen.has(name)) {
      duplicates.push(name);
      continue;
    }
    seen.add(name);

    const topLevel = categoryForCommand(command);
    const subcategory = subcategoryForCommand(command, topLevel);
    if (!groups.has(topLevel)) groups.set(topLevel, new Map());
    const subgroups = groups.get(topLevel);
    if (!subgroups.has(subcategory)) subgroups.set(subcategory, []);
    subgroups.get(subcategory).push(command);
    visible.push(command);
  }

  for (const subgroups of groups.values()) {
    for (const list of subgroups.values()) list.sort((a, b) => normalize(a.name).localeCompare(normalize(b.name)));
  }

  const orphanCount = Math.max(0, visible.length - [...groups.values()].reduce((n, s) => n + [...s.values()].reduce((m, list) => m + list.length, 0), 0));
  return { groups, visible, duplicates, orphanCount, totalInput: (commands || []).filter(Boolean).length };
}

function chunk(items, size = 35) {
  const out = [];
  for (let i = 0; i < items.length; i += size) out.push(items.slice(i, i + size));
  return out;
}

function renderCommand(command, prefix) {
  const description = command.description ? ` — ${command.description}` : '';
  const scope = command.groupOnly ? ' [GRUPO]' : command.privateOnly ? ' [PV]' : '';
  return `${MENU_THEME.middleBorder}${MENU_THEME.itemIcon}${prefix}${command.name}${scope}${description}`;
}

function renderPage(title, prefix, commands, page, totalPages, totalVisible) {
  const lines = [menuHeader('Fantasminha', 'Usuário', title), '', `${MENU_THEME.topBorder} ${title}${totalPages > 1 ? ` • PÁGINA ${page}/${totalPages}` : ''} ┈┈╮`, MENU_THEME.middleBorder];
  lines.push(...commands.map(command => renderCommand(command, prefix)));
  lines.push(MENU_THEME.middleBorder, `${MENU_THEME.middleBorder}✦ ${totalVisible} comandos canônicos nesta seção.`, MENU_THEME.bottomBorder, '', `${MENU_THEME.itemIcon}${prefix}menu • voltar`);
  return lines.join('\n');
}

export function buildCatalogMenu(prefix = '×', category = null, options = {}) {
  const allCommands = listCommands({ includeHidden: true });
  const organized = organizeCommands(allCommands, options);
  const requested = normalize(category);

  if (requested) {
    const key = CATEGORY_ALIASES[requested] || requested;
    const definition = MENU_STRUCTURE[key];
    if (!definition) {
      return [menuHeader('Fantasminha', 'Usuário', 'MENU'), '', `${MENU_THEME.topBorder} Categoria não encontrada ┈┈╮`, `${MENU_THEME.middleBorder} Use ${prefix}menu para voltar ao portal.`, MENU_THEME.bottomBorder].join('\n');
    }

    const subgroups = organized.groups.get(key) || new Map();
    const commands = [...subgroups.values()].flat();
    const pages = chunk(commands);
    if (!pages.length) {
      return [menuHeader('Fantasminha', 'Usuário', definition.title), '', `${MENU_THEME.topBorder} ${definition.title} ┈┈╮`, `${MENU_THEME.middleBorder} Nenhum comando disponível para seu nível de acesso.`, MENU_THEME.bottomBorder].join('\n');
    }
    return pages.map((page, index) => renderPage(definition.title, prefix, page, index + 1, pages.length, commands.length)).join('\n\n');
  }

  const role = Number(options.permission ?? 10);
  const sections = Object.entries(MENU_STRUCTURE).filter(([key, definition]) => {
    if (key === 'dono') return role >= 80;
    return [...(organized.groups.get(key)?.values() || [])].some(list => list.length);
  });

  const out = [
    menuHeader('Fantasminha', 'Usuário', 'MENU PRINCIPAL'),
    '',
    '👻 *FANTASMINHA — MENU PRINCIPAL*',
    `🔐 Acesso: *${ROLE_LABEL.get(role) || 'Membro'}*`,
    `📦 Comandos canônicos visíveis: *${organized.visible.length}*`,
    '',
    'Escolha uma área:',
    ''
  ];

  for (const [key, definition] of sections) {
    const count = [...(organized.groups.get(key)?.values() || [])].reduce((n, list) => n + list.length, 0);
    out.push(`${definition.title} — *${count} comandos*`, `${MENU_THEME.itemIcon}${prefix}menu ${key}`);
  }

  out.push('', `${MENU_THEME.itemIcon}${prefix}buscar <termo>`, `${MENU_THEME.itemIcon}${prefix}ajuda <comando>`, '', menuFooter(`Catálogo dinâmico • aliases não são exibidos • ${organized.visible.length} comandos canônicos acessíveis`));
  return out.join('\n');
}

export function getCategoryMeta(category) {
  const key = CATEGORY_ALIASES[normalize(category)] || normalize(category);
  return MENU_STRUCTURE[key] || null;
}

export default { buildCatalogMenu, getCategoryMeta, organizeCommands, MENU_STRUCTURE };
