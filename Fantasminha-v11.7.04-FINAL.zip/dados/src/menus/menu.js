import { buildCatalogMenu } from './catalogMenu.js';

/**
 * Portal principal do Fantasminha.
 * A navegação inteira é derivada do Registry; nenhum comando canônico é
 * cadastrado manualmente aqui e aliases nunca são renderizados.
 */
export default async function menu(prefix = '×', botName = 'Fantasminha', userName = 'Usuário', customDesign = null, options = {}) {
  return buildCatalogMenu(prefix, options?.category || options?.categoria || null, {
    ...options,
    botName,
    userName,
    customDesign
  });
}

export { buildCatalogMenu };
