export default async function menu_triagem(prefix='×') {
  return `╭━━━ 🛡️ MENU DA TRIAGEM ━━━╮

${prefix}triagemstatus — status geral
${prefix}triagemconectar ENTRADA TRIAGEM — conectar grupos
${prefix}triagemdesconectar — desconectar
${prefix}triagemgrupos ID1 ID2 — definir destinos
${prefix}triagemgruposadicionar ID — adicionar destino
${prefix}triagemgrupostirar ID — remover destino
${prefix}triagemgruposstatus — validar destinos
${prefix}triagemgruposlimpar — limpar destinos
${prefix}triagemgruposreset — resetar destinos
${prefix}triagemguia — guia completo

📋 ${prefix}filatriagem — fila
📄 ${prefix}triagemficha ID — ficha
⚖️ ${prefix}aprovar ID — aprovar
❌ ${prefix}reprovar ID motivo — reprovar

💡 Novos membros entram automaticamente.
As perguntas continuam no PV pelo link enviado no grupo.

╰━━━━━━━━━━━━━━━━━━━━━━╯`;
}
