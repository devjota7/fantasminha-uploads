/**
 * Compatibility entrypoint for the legacy IA module.
 * Canonical implementation remains in src/services/assistantV2Core.js.
 */
export {
  ASSISTANT_V2_VERSION,
  loadMasterPrompt,
  composeAssistantPrompt,
  guardInput,
  validateAssistantResult,
  fingerprintEvent,
  incrementMetric,
  getAssistantMetrics,
  resetAssistantMetrics
} from '../../../src/services/assistantV2Core.js';
