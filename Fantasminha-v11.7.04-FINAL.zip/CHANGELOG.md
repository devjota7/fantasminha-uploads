# CHANGELOG — Fantasminha

Este arquivo é cumulativo. A regra do projeto é manter aqui o estado documental
atual do Fantasminha e registrar cada release publicada sem apagar o histórico.

## [11.7.04] — FINAL

### Arquitetura e Registry
- Consolidação do Command Registry como fonte de verdade dos comandos.
- Organização dinâmica dos menus a partir do Registry.
- Aliases mantidos como referências de comandos canônicos, sem duplicação no
  menu.
- Permissões, cooldowns, auditoria, métricas e controle de concorrência
  centralizados.

### Prefixo
- Implementação do resolvedor central de prefixo.
- Prioridade `GRUPO → GLOBAL`.
- Isolamento do prefixo entre grupos.
- Validação e fallback para valores inválidos.
- Cache com invalidação.
- Auditoria de alterações.
- Parser, menus e respostas preparados para utilizar o prefixo efetivo.

### Triagem
- Triagem persistente com estados de execução, julgamento, aprovação,
  rejeição, expiração e cancelamento.
- Fluxo PV com código de triagem.
- Configuração de grupos de entrada, triagem, gestão e aprovação.
- Snapshot de configuração no início da triagem.
- Auditoria e proteção contra duplicação.
- Aprovação humana e rejeição com motivo obrigatório.

### Jogos e Ranking
- Game Engine integrado aos fluxos compatíveis.
- Ranking Central integrado aos jogos.
- Quiz, Forca, Stop, Gartic e Memory Cups preservados.
- Forca continua após erro e finaliza corretamente ao completar a palavra.
- Stop possui fluxo completo de lobby, rodada, respostas, validação,
  pontuação e finalização.
- Gartic possui validação tolerante a acentos, plural, aliases e pequenas
  variações de escrita.

### Assistant V2
- Bridge funcional para o Assistant V2.
- Core canônico preservado.
- Guards de entrada e validação reforçados.
- Métricas protegidas contra estruturas inválidas.

### Mensagens privadas
- PV Gateway com códigos e IDs válidos para triagem e partidas.
- Comandos privados de jogos controlados por allowlist.
- Mensagens privadas arbitrárias não entram no fluxo de comandos de jogo.

### Persistência, auditoria e recuperação
- Persistência JSON com escrita atômica e proteção de concorrência.
- Idempotência em operações que exigem proteção contra retry.
- Auditoria de operações críticas.
- Backup e rollback no atualizador.
- Proteção de dados locais e arquivos não pertencentes à release.

### Release e documentação
- `latest.json` passa a ser tratado como manifesto operacional obrigatório da
  release publicada.
- `release-manifest.json` registra a integridade física do ZIP.
- Toda release deve gerar SHA-256 e tamanho a partir do ZIP real.
- A documentação e as regras permanentes devem acompanhar a evolução do código.

### Correções de estabilidade desta revisão
- Gerador de códigos do STOP corrigido para produzir sempre exatamente 8 caracteres alfanuméricos após `STP-`, sem encurtamento causado por Base64URL.
- Catálogo da expansão corrigido para não anunciar o comando inexistente `×forcax`.
- Registros canônicos duplicados da expansão removidos, preservando as implementações V2 consolidadas.
- Testes de menu atualizados para o contrato do catálogo dinâmico atual.
- Scanner de prelaunch passou a reconhecer o uso fixo e revisado de `execFileSync` em `scripts/update-safety.mjs`.
- Adicionados testes de regressão para códigos STOP e duplicação de registros.

## Regra de manutenção

Nenhuma nova release deve ser publicada sem atualizar este changelog,
as release notes aplicáveis e o manifesto `latest.json` correspondente à
release. O histórico não deve ser apagado para substituir uma versão anterior.
