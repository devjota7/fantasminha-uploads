#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { checkDatabase } from '../src/database/store.js';
import { registryStats } from '../src/core/registry.js';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import config from '../src/core/config.js';

const root = process.cwd();
const required = ['package.json','package-lock.json','dados/src/services/assistantV2Core.js','dados/src/funcs/private/ia.js'];
const missing = required.filter(x => !fs.existsSync(path.join(root,x)));
if (missing.length) throw new Error(`Runtime required files missing: ${missing.join(', ')}`);
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if (String(pkg.version) !== String(config.botVersion)) throw new Error('package/config version mismatch');
await bootstrapV2();
const db = checkDatabase();
const registry = registryStats();
if (!db) throw new Error('database health check failed');
if (!registry.valid) throw new Error('registry health check failed');
console.log('RUNTIME HEALTH OK');
console.log(`Version: ${pkg.version}`);
console.log(`Database: OK`);
console.log(`Registry: ${registry.enabled} enabled / ${registry.aliases} aliases`);
console.log('Persistence: OK');
