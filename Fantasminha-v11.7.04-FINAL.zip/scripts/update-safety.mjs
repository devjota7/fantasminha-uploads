#!/usr/bin/env node

/**
 * Fantasminha — Camada preventiva de atualização.
 *
 * Uso:
 *   npm run test:update-safety
 *   node scripts/update-safety.mjs --zip release.zip --manifest release-manifest.json
 *
 * Objetivo: impedir que "versão + SHA" sejam tratados como prova suficiente.
 * Valida simultaneamente:
 *   - versão e package.json
 *   - arquivos críticos
 *   - Assistant V2 real + import usado pela IA
 *   - imports relativos críticos sem destino quebrado
 *   - ZIP sem path traversal e sem duplicação perigosa
 *   - manifesto x ZIP (SHA/tamanho/arquivos)
 *   - scripts de rollback/backup presentes
 *   - proteção de runtime/dados
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const ROOT = process.cwd();
const args = process.argv.slice(2);
const zipArg = args.includes('--zip') ? args[args.indexOf('--zip') + 1] : null;
const manifestArg = args.includes('--manifest') ? args[args.indexOf('--manifest') + 1] : null;

const CRITICAL = [
  'package.json',
  'package-lock.json',
  'dados/src/funcs/private/ia.js',
  'dados/src/services/assistantV2Core.js',
  'src/services/assistantV2Core.js',
  'src/core/bootstrap.js',
  'src/core/registry.js',
  'src/database/store.js',
  'dados/src/.scripts/update.js',
  'scripts/validate-release.mjs',
  'scripts/validate-bootstrap.mjs',
  'scripts/validate-runtime.mjs',
  'scripts/update-safety.mjs'
];

const PROTECTED = [
  '.env', 'dados/src/config.json', 'data/auth', 'data/db', 'data/backups',
  'auth', 'session', 'sessions', 'dados/database', 'dados/midias', 'logs'
];

const fail = (msg) => { throw new Error(msg); };
const norm = (p) => String(p).split(path.sep).join('/').replace(/^\.\//, '');
const exists = (p) => fsSync.existsSync(p);

function sha256(file) {
  return crypto.createHash('sha256').update(fsSync.readFileSync(file)).digest('hex');
}

function zipList(zip) {
  return execFileSync('unzip', ['-Z1', zip], { encoding: 'utf8', maxBuffer: 30 * 1024 * 1024 })
    .split(/\r?\n/).map(norm).filter(Boolean);
}

async function readJson(file) {
  return JSON.parse(await fs.readFile(file, 'utf8'));
}

function resolveRelativeImport(fromFile, spec) {
  if (!spec.startsWith('.')) return null;
  const base = path.resolve(path.dirname(fromFile), spec);
  const candidates = [base, `${base}.js`, `${base}.mjs`, `${base}.cjs`, `${base}.json`, path.join(base, 'index.js'), path.join(base, 'index.mjs')];
  return candidates.find(exists) || null;
}

async function validateLocalTree() {
  console.log('[SAFETY] 1/7 Arquivos críticos');
  for (const rel of CRITICAL) {
    if (!exists(path.join(ROOT, rel))) fail(`CRITICAL FILE MISSING: ${rel}`);
  }

  const pkg = await readJson(path.join(ROOT, 'package.json'));
  assert.match(String(pkg.version), /^\d+\.\d+\.\d+/);
  assert.ok(pkg.scripts?.['test:update-integrity'], 'package.json sem test:update-integrity');
  assert.ok(pkg.scripts?.['test:update-safety'], 'package.json sem test:update-safety');

  console.log('[SAFETY] 2/7 Assistant V2 real');
  const ia = await fs.readFile(path.join(ROOT, 'dados/src/funcs/private/ia.js'), 'utf8');
  const bridge = await fs.readFile(path.join(ROOT, 'dados/src/services/assistantV2Core.js'), 'utf8');
  const canonical = await fs.readFile(path.join(ROOT, 'src/services/assistantV2Core.js'), 'utf8');
  for (const fn of ['composeAssistantPrompt', 'guardInput', 'validateAssistantResult', 'incrementMetric']) {
    if (!canonical.includes(`function ${fn}`) && !canonical.includes(`const ${fn}`) && !canonical.includes(`export { ${fn}`)) fail(`Assistant V2 canonical sem implementação detectável: ${fn}`);
    if (!bridge.includes(fn)) fail(`Bridge Assistant V2 sem contrato: ${fn}`);
  }
  if (!ia.includes('assistantV2Core.js') || !ia.includes('from')) {
    fail('ia.js não referencia o Assistant V2 esperado.');
  }

  console.log('[SAFETY] 3/7 Imports relativos críticos');
  const scan = [
    path.join(ROOT, 'dados/src/funcs/private/ia.js'),
    path.join(ROOT, 'dados/src/services/assistantV2Core.js'),
    path.join(ROOT, 'src/services/assistantV2Core.js'),
    path.join(ROOT, 'src/core/bootstrap.js'),
    path.join(ROOT, 'src/core/registry.js')
  ];
  for (const file of scan) {
    const text = await fs.readFile(file, 'utf8');
    const re = /(?:from\s*|import\s*\(|export\s+[^;]*?from\s*)(['"])(\.[^'"]+)\1/g;
    let m;
    while ((m = re.exec(text))) {
      const resolved = resolveRelativeImport(file, m[2]);
      if (!resolved) fail(`IMPORT BROKEN: ${norm(path.relative(ROOT, file))} -> ${m[2]}`);
    }
  }

  console.log('[SAFETY] 4/7 Update/rollback');
  const updater = await fs.readFile(path.join(ROOT, 'dados/src/.scripts/update.js'), 'utf8');
  for (const marker of ['createValidatedBackup', 'rollbackFromBackup', 'verifyProtectedState', 'validatePostUpdate', 'manifest.sha256', 'requiredFiles']) {
    if (!updater.includes(marker)) fail(`Updater perdeu proteção obrigatória: ${marker}`);
  }

  console.log('[SAFETY] 5/7 Proteção de dados');
  for (const rel of PROTECTED) {
    if (rel === 'data/backups') continue;
    // Não exigimos que runtime exista em uma instalação nova; apenas garantimos
    // que o updater conhece explicitamente o caminho protegido.
    if (!updater.includes(`'${rel}'`) && !updater.includes(`"${rel}"`)) {
      fail(`Caminho protegido não declarado no updater: ${rel}`);
    }
  }

  console.log('[SAFETY] 6/7 Syntax dos arquivos críticos');
  for (const rel of CRITICAL.filter(x => x.endsWith('.js') || x.endsWith('.mjs'))) {
    execFileSync(process.execPath, ['--check', path.join(ROOT, rel)], { stdio: 'pipe' });
  }

  console.log('[SAFETY] 7/7 Manifesto/ZIP, se fornecidos');
  if (zipArg || manifestArg) {
    if (!zipArg || !manifestArg) fail('--zip e --manifest devem ser informados juntos.');
    const zip = path.resolve(ROOT, zipArg);
    const manifestFile = path.resolve(ROOT, manifestArg);
    if (!exists(zip) || !exists(manifestFile)) fail('ZIP ou manifesto não encontrado.');
    const manifest = await readJson(manifestFile);
    const actualHash = sha256(zip);
    const actualSize = fsSync.statSync(zip).size;
    if (String(actualHash).toLowerCase() !== String(manifest.sha256).toLowerCase()) fail(`SHA mismatch: esperado ${manifest.sha256}, obtido ${actualHash}`);
    if (Number(manifest.size) !== actualSize) fail(`SIZE mismatch: manifesto ${manifest.size}, ZIP ${actualSize}`);
    const names = zipList(zip);
    if (names.some(n => n.includes('..') || n.startsWith('/') || /^[A-Za-z]:[\\/]/.test(n))) fail('ZIP contém caminho inseguro.');
    const required = Array.isArray(manifest.requiredFiles) ? manifest.requiredFiles.map(norm) : CRITICAL.slice(0, 4);
    for (const rel of required) if (!names.includes(rel) && !names.some(n => n.endsWith(`/${rel}`))) fail(`ZIP sem arquivo obrigatório: ${rel}`);
    if (!manifest.version) fail('Manifesto sem versão.');
    console.log(`[SAFETY] ZIP íntegro: v${manifest.version} | ${actualSize} bytes | SHA ${actualHash}`);
  }

  console.log(`UPDATE SAFETY OK — prevenção ativa para v${pkg.version}`);
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { await validateLocalTree(); }
  catch (error) { console.error(`[SAFETY] ❌ ${error?.stack || error}`); process.exitCode = 1; }
}

export { validateLocalTree };
