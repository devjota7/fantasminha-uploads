#!/usr/bin/env node

import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const ROOT = process.cwd();
const version = process.argv[2] || JSON.parse(fsSync.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version;
const suffix = process.argv[3] || 'FINAL';
const zipName = `Fantasminha-v${version}-${suffix}.zip`;
const outDir = path.join(ROOT, 'release-out');
const stage = path.join(outDir, `stage-${Date.now()}`);
const zipPath = path.join(outDir, zipName);
const requiredFiles = ['dados/src/services/assistantV2Core.js','dados/src/funcs/private/ia.js','package.json','package-lock.json'];
const excluded = new Set(['node_modules','.git','.update-tmp','release-out','logs','.last-update.json','latest.json','release-manifest.json','.update-owned-files.json']);
const excludedRoots = ['data/auth','data/db','data/backups','auth','session','sessions','dados/database','dados/midias','logs'];

function sha256(file) { return crypto.createHash('sha256').update(fsSync.readFileSync(file)).digest('hex'); }
function isExcluded(rel) {
  const n = rel.split(path.sep).join('/');
  if (excluded.has(n) || excluded.has(n.split('/')[0])) return true;
  return excludedRoots.some(x => n === x || n.startsWith(`${x}/`));
}
async function copyTree(src, dst, prefix='') {
  await fs.mkdir(dst, { recursive: true });
  for (const e of await fs.readdir(src, { withFileTypes: true })) {
    const rel = prefix ? `${prefix}/${e.name}` : e.name;
    if (isExcluded(rel)) continue;
    const a = path.join(src,e.name), b = path.join(dst,e.name);
    if (e.isDirectory()) await copyTree(a,b,rel);
    else if (e.isFile()) { await fs.mkdir(path.dirname(b),{recursive:true}); await fs.copyFile(a,b); }
  }
}
function zipList(zip) { return execFileSync('unzip',['-Z1',zip],{encoding:'utf8'}).split(/\r?\n/).filter(Boolean); }

await fs.rm(outDir,{recursive:true,force:true});
await fs.mkdir(outDir,{recursive:true});
await copyTree(ROOT, stage);
for (const req of requiredFiles) if (!fsSync.existsSync(path.join(stage,req))) throw new Error(`Required file missing in stage: ${req}`);
const stagedPkg = JSON.parse(await fs.readFile(path.join(stage,'package.json'),'utf8'));
if (String(stagedPkg.version) !== String(version)) throw new Error(`package.json=${stagedPkg.version}, esperado=${version}`);
execFileSync('zip',['-qr',zipPath,'.'],{cwd:stage,stdio:'inherit'});
const names = zipList(zipPath);
for (const req of requiredFiles) if (!names.includes(req)) throw new Error(`Required file missing in ZIP: ${req}`);
const hash = sha256(zipPath);
const size = fsSync.statSync(zipPath).size;
const createdAt = new Date().toISOString();
const manifest = {
  version: String(version),
  name: 'Fantasminha',
  release: `v${version}-${suffix.toLowerCase()}`,
  package: zipName,
  zip: zipName,
  sha256: hash,
  size,
  requiredFiles,
  createdAt,
  minNode: '>=20.9.0'
};
await fs.writeFile(path.join(outDir,'release-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
await fs.writeFile(path.join(outDir,'latest.json'),JSON.stringify({
  ...manifest,
  release: manifest.release,
  notes: `Fantasminha v${version} — release íntegra validada fisicamente.`
},null,2)+'\n');
execFileSync(process.execPath,[path.join(ROOT,'scripts','validate-release.mjs'),'--zip',zipPath,'--manifest',path.join(outDir,'release-manifest.json')],{cwd:ROOT,stdio:'inherit'});
await fs.rm(stage,{recursive:true,force:true});
console.log(`\nRELEASE BUILD OK\nZIP: ${zipPath}\nSHA-256: ${hash}\nSIZE: ${size}`);
