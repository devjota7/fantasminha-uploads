#!/usr/bin/env node

import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = process.cwd();
const REQUIRED = [
  'dados/src/services/assistantV2Core.js',
  'dados/src/funcs/private/ia.js',
  'package.json',
  'package-lock.json'
];
const EXTENSIONS = ['.js', '.cjs', '.mjs', '.json'];
const args = process.argv.slice(2);
const valueOf = (name) => {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : null;
};
const zipArg = valueOf('--zip');
const manifestArg = valueOf('--manifest');
const fail = [];
const ok = [];

function rel(p) { return path.relative(ROOT, p).split(path.sep).join('/'); }
function resolveSafe(p) {
  const r = path.resolve(ROOT, p);
  const root = path.resolve(ROOT) + path.sep;
  if (r !== path.resolve(ROOT) && !r.startsWith(root)) throw new Error(`caminho fora da raiz: ${p}`);
  return r;
}
function resolveArtifact(p) { return path.isAbsolute(String(p)) ? path.resolve(String(p)) : resolveSafe(p); }
function exists(p) { return fs.existsSync(resolveSafe(p)); }
function addOk(message) { ok.push(message); }
function addFail(message) { fail.push(message); }

async function walk(dir, out = []) {
  const entries = await fsp.readdir(dir, { withFileTypes: true });
  for (const e of entries) {
    if (['node_modules', '.git', '.update-tmp', 'logs'].includes(e.name)) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) await walk(full, out);
    else if (e.isFile() && EXTENSIONS.includes(path.extname(e.name).toLowerCase())) out.push(full);
  }
  return out;
}

function stripComments(source) {
  return source
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|\s)\/\/.*$/gm, '$1');
}

function resolveImport(fromFile, specifier) {
  if (!specifier.startsWith('.')) return null;
  const base = path.resolve(path.dirname(fromFile), specifier);
  const candidates = [base, ...EXTENSIONS.map(ext => `${base}${ext}`), ...EXTENSIONS.map(ext => path.join(base, `index${ext}`))];
  return candidates.find(fs.existsSync) || candidates[0];
}

async function validateImports() {
  const files = await walk(ROOT);
  let broken = 0;
  for (const file of files) {
    const source = stripComments(await fsp.readFile(file, 'utf8'));
    const specs = new Set();
    const patterns = [
      /\bimport\s+(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/g,
      /\bexport\s+(?:[\s\S]*?\s+from\s+)?['"]([^'"]+)['"]/g,
      /\brequire\(\s*['"]([^'"]+)['"]\s*\)/g,
      /\bimport\(\s*['"]([^'"]+)['"]\s*\)/g
    ];
    for (const re of patterns) for (const m of source.matchAll(re)) specs.add(m[1]);
    for (const spec of specs) {
      if (!spec.startsWith('.')) continue;
      const target = resolveImport(file, spec);
      if (!target || !fs.existsSync(target)) {
        broken++;
        addFail(`Import quebrado: ${rel(file)} -> ${spec} (destino esperado: ${rel(target || path.resolve(path.dirname(file), spec))})`);
      }
    }
  }
  if (!broken) addOk('no broken relative imports');
}

async function validateCore() {
  try {
    const coreUrl = pathToFileURL(resolveSafe('dados/src/services/assistantV2Core.js')).href;
    const core = await import(`${coreUrl}?releaseCheck=${Date.now()}`);
    for (const name of ['composeAssistantPrompt', 'guardInput', 'validateAssistantResult', 'incrementMetric']) {
      if (typeof core[name] !== 'function') throw new Error(`${name} não é função`);
      addOk(name);
    }
    if (core.guardInput('ok').allowed !== true) throw new Error('guardInput rejeitou entrada válida');
    if (core.guardInput(null).allowed !== false) throw new Error('guardInput aceitou null');
    if (core.guardInput('x'.repeat(12001)).allowed !== false) throw new Error('guardInput aceitou payload excessivo');
    if (core.validateAssistantResult({ resp: [{ resp: 'ok' }] }).valid !== true) throw new Error('validator rejeitou resultado válido');
    if (core.validateAssistantResult(null).valid !== false) throw new Error('validator aceitou null');
    addOk('assistantV2Core loaded and behavior verified');
  } catch (error) {
    addFail(`ASSISTANT V2 CORE INVALID: ${error.message}`);
  }
}

function validateRequiredFiles() {
  for (const item of REQUIRED) {
    if (exists(item)) addOk(item);
    else addFail(`Missing required file: ${item}`);
  }
}

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

function validateZip() {
  if (!zipArg) return;
  const zip = resolveArtifact(zipArg);
  if (!fs.existsSync(zip)) return addFail(`ZIP não encontrado: ${zipArg}`);
  let names;
  try {
    names = execFileSync('unzip', ['-Z1', zip], { encoding: 'utf8', maxBuffer: 30 * 1024 * 1024 })
      .split(/\r?\n/).map(s => s.trim()).filter(Boolean);
  } catch (error) {
    return addFail(`Falha ao listar ZIP: ${error.message}`);
  }
  if (names.some(n => n.includes('..') || path.isAbsolute(n) || /^[A-Za-z]:[\\/]/.test(n))) addFail('ZIP contém caminho inseguro');
  for (const item of REQUIRED) {
    if (names.includes(item) || names.some(n => n.endsWith(`/${item}`))) addOk(`ZIP inclui ${item}`);
    else addFail(`ZIP sem arquivo obrigatório: ${item}`);
  }
  const actual = sha256(zip);
  addOk(`ZIP SHA-256 ${actual}`);

  if (manifestArg) {
    const manifestPath = resolveArtifact(manifestArg);
    try {
      const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
      if (!manifest.sha256 || !/^[0-9a-f]{64}$/i.test(String(manifest.sha256))) addFail('Manifesto sem SHA-256 válido');
      else if (String(manifest.sha256).toLowerCase() !== actual.toLowerCase()) addFail(`SHA-256 divergente: manifesto=${manifest.sha256} zip=${actual}`);
      else addOk('SHA-256 verified');
      const stat = fs.statSync(zip);
      if (manifest.size !== undefined && Number(manifest.size) !== stat.size) addFail(`Tamanho divergente: manifesto=${manifest.size} zip=${stat.size}`);
      else if (manifest.size !== undefined) addOk('package size verified');
      if (manifest.requiredFiles) {
        const listed = [...new Set(manifest.requiredFiles.map(String))];
        const missing = REQUIRED.filter(item => !listed.includes(item));
        if (missing.length) addFail(`requiredFiles do manifesto não incluem obrigatórios: ${missing.join(', ')}`);
        else addOk('requiredFiles verified');
      }
    } catch (error) { addFail(`Manifesto inválido: ${error.message}`); }
  }
}

function print() {
  console.log('========================================');
  console.log(' FANTASMINHA RELEASE CHECK');
  console.log('========================================');
  console.log('\n[FILES]');
  for (const x of ok.filter(x => REQUIRED.includes(x))) console.log(`✓ ${x}`);
  for (const x of fail.filter(x => x.startsWith('Missing required file'))) console.log(`❌ ${x}`);
  console.log('\n[IMPORTS]');
  const importOk = ok.includes('no broken relative imports');
  console.log(`${importOk ? '✓' : '❌'} ${importOk ? 'no broken relative imports' : 'broken imports detected'}`);
  console.log('\n[ASSISTANT V2]');
  for (const x of ['composeAssistantPrompt','guardInput','validateAssistantResult','incrementMetric']) console.log(`${ok.includes(x) ? '✓' : '❌'} ${x}`);
  if (ok.includes('assistantV2Core loaded and behavior verified')) console.log('✓ assistantV2Core loaded and behavior verified');
  console.log('\n[ZIP/HASH]');
  for (const x of ok.filter(x => x.startsWith('ZIP inclui') || x.startsWith('ZIP SHA-256') || x.includes('SHA-256 verified') || x === 'package size verified' || x === 'requiredFiles verified')) console.log(`✓ ${x}`);
  console.log('');
  for (const x of fail) console.error(`❌ ${x}`);
  if (!fail.length) console.log('========================================\n RELEASE VALID\n========================================');
}

await (async () => {
  validateRequiredFiles();
  await validateImports();
  await validateCore();
  validateZip();
  print();
  if (fail.length) process.exitCode = 1;
})();
