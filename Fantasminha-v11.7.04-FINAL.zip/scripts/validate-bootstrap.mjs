#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const required = [
  'src/core/bootstrap.js',
  'src/core/registry.js',
  'src/database/migrate.js',
  'dados/src/services/assistantV2Core.js',
  'dados/src/funcs/private/ia.js'
];
for (const file of required) if (!fs.existsSync(path.join(root,file))) throw new Error(`Bootstrap prerequisite missing: ${file}`);

const { bootstrapV2 } = await import('../src/core/bootstrap.js');
const { registryStats } = await import('../src/core/registry.js');
const stats = await bootstrapV2();
const finalStats = registryStats();
if (!stats || !finalStats?.valid) throw new Error('Registry não ficou válido após bootstrap');
console.log('BOOTSTRAP OK');
console.log(`Registry: ${finalStats.enabled} enabled / ${finalStats.aliases} aliases`);
console.log('Migrations: loaded');
console.log('Assistant V2: loaded');
setTimeout(() => process.exit(0), 100).unref?.();
