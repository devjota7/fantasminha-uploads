#!/usr/bin/env node

import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';

const [, , zipArg, versionArg, outputDirArg] = process.argv;
if (!zipArg || !versionArg) {
  console.error('Uso: npm run release:manifest -- caminho/Fantasminha-vX.Y.Z.zip X.Y.Z [diretorio-saida]');
  process.exit(1);
}
if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(versionArg)) throw new Error(`Versão inválida: ${versionArg}`);
if (!fs.existsSync(zipArg)) throw new Error(`ZIP não encontrado: ${zipArg}`);
const zip = path.basename(zipArg);
const hash = crypto.createHash('sha256').update(fs.readFileSync(zipArg)).digest('hex');
const size = fs.statSync(zipArg).size;
const requiredFiles = ['dados/src/services/assistantV2Core.js','dados/src/funcs/private/ia.js','package.json','package-lock.json'];
const manifest = {
  version: versionArg,
  name: 'Fantasminha',
  release: `v${versionArg}-stable`,
  package: zip,
  zip,
  sha256: hash,
  size,
  requiredFiles,
  createdAt: new Date().toISOString(),
  minNode: '>=20.9.0'
};
const outputDir = path.resolve(outputDirArg || path.dirname(zipArg));
fs.mkdirSync(outputDir,{recursive:true});
fs.writeFileSync(path.join(outputDir,'release-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync(path.join(outputDir,'latest.json'),JSON.stringify({...manifest,notes:`Fantasminha v${versionArg}`},null,2)+'\n');
console.log(JSON.stringify(manifest,null,2));
console.log(`\nSHA-256: ${hash}`);
