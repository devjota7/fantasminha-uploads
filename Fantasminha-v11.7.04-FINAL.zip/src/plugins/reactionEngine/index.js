import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import manager from '../../features/reactions/ReactionManager.js';
import session from '../../features/reactions/ReactionResponseSessionService.js';
export async function register(){
  const defs=[['react','Emoji','EMOJI',['reagir']],['figreact','Figurinha','STICKER',[]],['audioreact','Áudio','AUDIO',[]],['reactimg','Imagem','IMAGE',[]]];
  manager.initializeEngine();
  for(const [name,label,type,aliases] of defs) registerCommand({name,aliases,category:'dono',plugin:'reactionEngine',priority:1001,permission:Role.OWNER,ownerOnly:true,audit:true,cooldown:0,description:`Configura reação de ${label} para respostas do bot.`,usage:`×${name}`,responseCapabilities:{supportsCustomMedia:false,isMenu:true,responseKey:`system.${name}`},handler:ctx=>(ctx.args?.[0] && ['lista','listar','editar','edit','info','stats','estatisticas','histórico','historico','ajuda','help','limpar','ativar','desativar'].includes(String(ctx.args[0]).toLowerCase()) ? manager.dispatch(ctx) : session.start(ctx,type))});
}
export default {register};
