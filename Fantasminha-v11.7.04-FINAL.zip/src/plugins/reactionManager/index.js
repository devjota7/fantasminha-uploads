import { registerCommand, getCommand, unregisterCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import manager from '../../features/reactions/ReactionManager.js';

export async function register() {
  const priority = 1000;
  // A camada nova substitui o ×react legado do megaFusion sem criar uma segunda implementação.
  for (const name of ['react','reagir','addreact','listreact','delreact']) {
    try { if (getCommand(name)?.plugin !== 'reactionManager') unregisterCommand(name); } catch {}
  }
  registerCommand({ name:'react', aliases:['reagir'], category:'utilidades', plugin:'reactionManager', priority, permission:Role.USER, ownerOnly:false, cooldown:0, audit:true, description:'Reaction Manager exclusivo do dono.', usage:'×react', handler:manager.dispatch });
  registerCommand({ name:'addreact', category:'utilidades', plugin:'reactionManager', priority, permission:Role.USER, ownerOnly:false, audit:true, hidden:true, handler:manager.dispatch });
  registerCommand({ name:'listreact', category:'utilidades', plugin:'reactionManager', priority, permission:Role.USER, ownerOnly:false, audit:true, hidden:true, handler:async ctx=>manager.list(ctx) });
  registerCommand({ name:'delreact', category:'utilidades', plugin:'reactionManager', priority, permission:Role.USER, ownerOnly:false, audit:true, hidden:true, handler:async ctx=>manager.startEdit ? manager.dispatch({ ...ctx, args:['editar', ctx.args?.[0]] }) : manager.dispatch(ctx) });
}
export default { register };
