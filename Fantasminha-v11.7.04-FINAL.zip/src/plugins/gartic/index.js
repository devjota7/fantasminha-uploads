import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import service from '../../games/gartic/GarticService.js';
export async function register(){
  registerCommand({name:'gartic',aliases:[],category:'jogos',plugin:'gartic',permission:Role.USER,groupOnly:true,cooldown:3,priority:1005,description:'Gartic visual multiplayer com desenho gerado por IA e palpites livres.',handler:ctx=>service.start(ctx)});
}
export default {register};
