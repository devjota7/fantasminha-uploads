import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { beginConfig, beginDelete, createSession, handleAnswer, handleGroupInput } from '../../games/stop/StopCore.js';
export async function register(){
  registerCommand({name:'stopcriar',category:'jogos',plugin:'stop',permission:Role.USER,groupOnly:true,cooldown:3,description:'Configura seu STOP de forma privada.',handler:beginConfig});
  registerCommand({name:'stopexcluir',category:'jogos',plugin:'stop',permission:Role.USER,groupOnly:true,cooldown:3,description:'Exclui sua configuração do STOP sem apagar histórico.',handler:beginDelete});
  registerCommand({name:'stop',aliases:['adedonha'],category:'jogos',plugin:'stop',permission:Role.USER,groupOnly:true,cooldown:3,description:'Abre uma partida STOP usando sua configuração.',handler:createSession});
}
export { handleAnswer, handleGroupInput };
export default {register,handleAnswer,handleGroupInput};
