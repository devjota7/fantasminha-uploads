import { registerCommand, getCommand, unregisterCommand } from '../../core/registry.js';
import ranking from '../../games/ranking/GameRankingService.js';
import formatter from '../../games/ranking/GameRankingFormatter.js';
import { register as registerEngine } from '../../games/ranking/index.js';
const tag=t=>`👻 *FANTASMINHA 11.7.04*\n\n${t}`;
const defs=[['quiz','🧠 Quiz','rankquiz','rankquizglobal'],['memoriacopos','🥤 Memória dos Copos','rankmemoriacopos','rankmemoriacoposglobal'],['stop','🛑 STOP','rankstop','rankstopglobal'],['forca','🔤 Forca','rankforca','rankforcaglobal'],['gartic','🎨 Gartic','rankgartic','rankgarticglobal']];
// Catálogo estático para auditoria de comandos (as rotas reais abaixo são geradas a partir de defs).
const AUDIT_COMMANDS=[['rankquiz',null],['rankquizglobal',null],['rankmemoriacopos',null],['rankmemoriacoposglobal',null],['rankstop',null],['rankstopglobal',null],['rankforca',null],['rankforcaglobal',null],['rankgartic',null],['rankgarticglobal',null],['meurank',null]];
function cleanup(names){for(const n of names){try{const c=getCommand(n);if(c)unregisterCommand(n);}catch{}}}
function reg(name,handler,description){registerCommand({name,category:'rankings',plugin:'gameRanking',groupOnly:name!=='meurank',cooldown:2,description,handler});}
export async function register(){
  await registerEngine();
  cleanup(['rankquiz','rankquizglobal','rankmemoriacopos','rankmemoriacoposglobal','rankstop','rankstopglobal','rankforca','rankforcaglobal','rankgartic','rankgarticglobal','meurank']);
  for(const [gameId,label,groupCommand,globalCommand] of defs){
    reg(groupCommand,async c=>{const meta=ranking.gameMeta(gameId),rows=ranking.group(gameId,c.from,5);return c.reply?.(tag(formatter.formatGroupRanking({game:meta,rows,adapter:meta.rankingAdapter})));},`Top 5 ${label} do grupo atual.`);
    reg(globalCommand,async c=>{const meta=ranking.gameMeta(gameId),data=ranking.global(gameId);return c.reply?.(tag(formatter.formatGlobalRanking({game:meta,...data,adapter:meta.rankingAdapter})));},`Ranking global de ${label}.`);
  }
  reg('meurank',async c=>{const uid=c.sender||'unknown',parts=defs.map(([gameId])=>{const meta=ranking.gameMeta(gameId),r=ranking.user(gameId,c.isGroup?c.from:null,uid);return formatter.formatMyRank({game:meta,rank:r,adapter:meta.rankingAdapter,userName:c.pushname||uid});});return c.reply?.(tag(`╭━━━━━━━━━━━━━━━━━━╮\n       👤 MEU RANK\n╰━━━━━━━━━━━━━━━━━━╯\n\n👤 @${String(uid).split('@')[0]}\n\n${parts.join('\n\n━━━━━━━━━━━━━━━━━━\n\n')}\n\n╰━━━━━━━━━━━━━━━━━━╯`));},'Mostra seu ranking nos cinco jogos.');
}
export default {register};
