import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import config from '../../core/config.js';
import { readCollection } from '../../database/store.js';
import { resolveUserIdentity } from '../../platform/identity/resolver.js';
import {
  beginTriageBuilder, deleteTriageConfiguration, getSettings, saveSettings, getTriage, triageFullText, triageSummaryText,
  judgeTriage, executeApprovalActions, executeRejectionActions, cancelActiveTriage, triageStats, blacklistCheck, setBlacklist, removeBlacklist,
  blacklistList, blacklistInfo, blacklistHistory, blacklistStats, STATES, handleTriageBuilderMessage,
  memberJoined, createTriage, rejectionHistory, triageLink
} from '../../services/triage.js';

const tag=t=>`👻 *FANTASMINHA — TRIAGEM*\n\n${t}`;
const target=ctx=>ctx.mentioned?.[0]||null;
const idOf=u=>String(u||'').split('@')[0];
const parseId=q=>String(q||'').trim().split(/\s+/)[0].toUpperCase();
const isBot=(id,bot)=>String(id||'').split('@')[0]===String(bot||'').split('@')[0];

export async function register(){
  registerCommand({name:'triagemcriar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Cria uma triagem simples por perguntas, sem configuração técnica',handler:async ctx=>{await beginTriageBuilder(ctx.from,ctx.sender,[ctx.senderOriginal,ctx.senderAlternate]);return ctx.reply(tag('Deseja criar uma triagem?\n\n1️⃣ Sim\n2️⃣ Cancelar triagem\n\nResponda somente com o número.'))}});
  registerCommand({name:'triagemexcluir',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await deleteTriageConfiguration(ctx.from);return ctx.reply(tag('🗑️ *TRIAGEM EXCLUÍDA*\n\nAs perguntas e a configuração desta triagem foram removidas. O grupo ficou desativado.\n\nPara criar outra: *'+config.prefix+'triagemcriar*'));}});
  registerCommand({name:'setpergunta',aliases:['editarpergunta','editpergunta'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada. Use ×triagemcriar primeiro.');const n=Number(ctx.args?.[0]);if(!Number.isInteger(n)||n<1||n>s.questions.length){return ctx.reply(tag('📝 *PERGUNTAS CONFIGURADAS*\n\n'+s.questions.map((q,i)=>`${i+1}. [${q.type}] ${q.question}`).join('\n')+'\n\nEnvie: *'+config.prefix+'setpergunta número*\nExemplo: *'+config.prefix+'setpergunta 2*'));}const r=await beginTriageEdit(ctx.from,ctx.sender,n,[ctx.senderOriginal,ctx.senderAlternate]);return ctx.reply(tag(`✏️ *EDITANDO PERGUNTA ${n}*\n\nAtual: *${r.question.question}*\nCategoria atual: *${r.question.type}*\n\nEscreva a nova pergunta.`));}});
  registerCommand({name:'triagemativar',aliases:['triagemon'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada. Use ×triagemcriar primeiro.');await saveSettings(ctx.from,{enabled:true});return ctx.reply(tag(`🟢 *TRIAGEM ATIVADA*\n\nNovos membros serão cobrados automaticamente.\nPerguntas: *${s.questions.length}/20*`));}});
  registerCommand({name:'triagemdesativar',aliases:['triagemoff'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{enabled:false});return ctx.reply(tag('🔴 *TRIAGEM DESATIVADA*\n\nA entrada de novos membros será ignorada pela triagem. Sessões existentes continuam preservadas.'));}});
  registerCommand({name:'triagemcobrar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:4,timeoutMs:300000,description:'Gera uma triagem exclusiva para cada membro do grupo',handler:async ctx=>{
  const s=await getSettings(ctx.from);
  if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada.');
  const bot=ctx.botJid||'';
  const botIdentity=await resolveUserIdentity(ctx,bot);
  const botRealJid=botIdentity.realJid||config.ownerNumber;
  const members=[...new Set((ctx.groupParticipants||[]).filter(u=>u&&!isBot(u,bot)))];
  if(!members.length)throw new ValidationError('Não consegui obter os membros deste grupo.');
  let created=0,existing=0,listed=0,skipped=0,failed=0;
  const rows=[];
  for(const u of members){
    const identity=await resolveUserIdentity(ctx,u);
    if(!identity.realJid){failed++;continue;}
    const c=await createTriage(ctx.from,u,{botJid:botRealJid,force:true,aliases:[identity.realJid,identity.lid]});
    if(!c.ok){if(c.reason==='blacklisted')skipped++;continue;}
    if(c.created)created++;else existing++;
    rows.push({user:u,mentionJid:identity.realJid,code:c.code,link:c.link}); listed++;
  }
  // Cobrança somente no grupo: a menção é real (PN/JID), nunca o texto de um LID.
  const chunks=[];
  for(let i=0;i<rows.length;i+=12) chunks.push(rows.slice(i,i+12));
  for(const chunk of chunks){
    const text=tag(`📨 *COBRANÇA DE TRIAGEM*\n\nGente, a triagem está liberada! 😄\nCada pessoa abaixo tem seu próprio acesso:\n\n${chunk.map((r,i)=>`${i+1}️⃣ @${String(r.mentionJid).split('@')[0]}\n🔐 ${r.code}\n👉 ${r.link}`).join('\n\n')}\n\nSó abrir o link/código do seu nome e responder no privado do Fantasminha. 👻`);
    try{ await ctx.reply(text,{mentions:chunk.map(r=>r.mentionJid)}); }catch{ failed+=chunk.length; }
  }
  return ctx.reply(tag(`📨 *COBRANÇA CONCLUÍDA*\n\n👥 Membros analisados: *${members.length}*\n🆕 Novas triagens: *${created}*\n♻️ Já existentes: *${existing}*\n📋 Fichas listadas no grupo: *${listed}*\n🚫 Ignorados por blacklist: *${skipped}*\n⚠️ Falhas de publicação: *${failed}*`));
}});
  registerCommand({name:'triagemficha',aliases:['fichatriagem','ficha'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Monta a ficha completa de uma triagem',handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!id||!t||t.groupId!==ctx.from)throw new ValidationError('ID de triagem não encontrado neste grupo.');return ctx.reply(triageFullText(t,(await rejectionHistory(t.userId)).length),{mentions:[t.userId]});}});
  registerCommand({name:'triagemconectar',aliases:['triagemconect'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Conecta grupo de entrada a grupo administrativo de triagem',handler:async ctx=>{
  const args=(ctx.args||[]).map(x=>String(x||'').trim()).filter(Boolean);
  const entryId=args.length>=2?args[0]:ctx.from;
  const gid=args.length>=2?args[1]:args[0];
  if(!gid||!gid.endsWith('@g.us'))throw new ValidationError('Use: ×triagemconectar ID_GRUPO_ENTRADA ID_GRUPO_TRIAGEM');
  if(entryId!==ctx.from)throw new ValidationError('O ID do grupo de entrada precisa ser o grupo onde este comando foi executado.');
  if(gid===entryId)throw new ValidationError('O grupo de triagem deve ser diferente do grupo de entrada. Sem conexão, a ficha já volta automaticamente para o grupo de entrada.');
  if(ctx.getGroupMetadata){
    const meta=await ctx.getGroupMetadata(gid).catch(()=>null);
    if(!meta)throw new ValidationError('Não consegui acessar o grupo de triagem. Confira o ID e se o bot está no grupo.');
    const bot=ctx.botJid||'';const me=(meta.participants||[]).find(p=>p?.id===bot||p?.jid===bot||p?.participant===bot);
    if(!me||!me.admin)throw new ValidationError('O Fantasminha precisa estar no grupo de triagem e ser administrador.');
  }
  await saveSettings(ctx.from,{triageGroupId:gid,archiveGroupId:gid});
  return ctx.reply(tag(`🔗 *TRIAGEM CONECTADA*\n\n📥 Entrada: *${entryId}*\n⚖️ Julgamento: *${gid}*\n\nAs próximas fichas concluídas serão enviadas para o grupo de triagem.\nTriagens antigas mantêm o snapshot original.`));
}});
  registerCommand({name:'triagemdesconectar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{triageGroupId:null,archiveGroupId:null});return ctx.reply(tag('🔌 *TRIAGEM DESCONECTADA*\n\nAs novas fichas voltarão para o próprio grupo de entrada. Triagens antigas não serão alteradas.'));}});

  async function validatePermanentGroups(ctx,ids){
    const unique=[...new Set(ids.map(x=>String(x||'').trim()).filter(Boolean))];
    if(!unique.length)return [];
    for(const gid of unique){
      if(!gid.endsWith('@g.us'))throw new ValidationError(`ID inválido: ${gid}. Use o ID completo terminando em @g.us.`);
      if(gid===ctx.from)throw new ValidationError('O grupo de entrada não pode ser cadastrado como grupo permanente.');
      if(ctx.getGroupMetadata){
        const meta=await ctx.getGroupMetadata(gid).catch(()=>null);
        if(!meta)throw new ValidationError(`Não consegui validar o grupo ${gid}. Nenhuma alteração foi realizada.`);
        const bot=ctx.botJid||'';const me=(meta.participants||[]).find(p=>p?.id===bot||p?.jid===bot||p?.participant===bot);
        if(!me||!me.admin)throw new ValidationError(`O Fantasminha precisa estar no grupo ${gid} e ser administrador. Nenhuma alteração foi realizada.`);
      }
    }
    return unique;
  }

  registerCommand({name:'triagemgrupos',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Define os grupos permanentes dos aprovados',handler:async ctx=>{
    const ids=await validatePermanentGroups(ctx,ctx.args||[]);await saveSettings(ctx.from,{approvalGroupIds:ids});return ctx.reply(tag(ids.length?`📚 *GRUPOS PERMANENTES ATUALIZADOS*\n\n${ids.map((x,i)=>`${i+1}. ${x}`).join('\n')}\n\nAprovados serão encaminhados para esses grupos e, após o processamento, removidos do grupo de entrada.`:'📚 *GRUPOS PERMANENTES LIMPOS*\n\nAprovados permanecerão no grupo de entrada.'));
  }});
  registerCommand({name:'triagemgruposadicionar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{
    const ids=await validatePermanentGroups(ctx,ctx.args||[]);if(!ids.length)throw new ValidationError('Informe pelo menos um ID de grupo.');const s=await getSettings(ctx.from);const next=[...new Set([...(s.approvalGroupIds||[]),...ids])];await saveSettings(ctx.from,{approvalGroupIds:next});return ctx.reply(tag(`➕ ${ids.length} grupo(s) adicionado(s).\n\nTotal configurado: ${next.length}`));
  }});
  registerCommand({name:'triagemgrupostirar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{
    const ids=[...new Set((ctx.args||[]).map(x=>String(x||'').trim()).filter(Boolean))];if(!ids.length)throw new ValidationError('Informe o ID do grupo que deseja remover.');const s=await getSettings(ctx.from);const current=s.approvalGroupIds||[];const next=current.filter(x=>!ids.includes(x));await saveSettings(ctx.from,{approvalGroupIds:next});return ctx.reply(tag(`➖ Remoção concluída.\n\nRemovidos: ${current.length-next.length}\nRestantes: ${next.length}`));
  }});
  registerCommand({name:'triagemgruposlimpar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{approvalGroupIds:[]});return ctx.reply(tag('🧹 *GRUPOS PERMANENTES LIMPOS*\n\nAprovados sem destinos permanentes permanecerão no grupo de entrada.'));}});
  registerCommand({name:'triagemgruposreset',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{approvalGroupIds:[]});return ctx.reply(tag('♻️ *GRUPOS PERMANENTES RESETADOS*\n\nA configuração voltou para nenhum grupo permanente.'));}});
  registerCommand({name:'triagemgruposstatus',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);const rows=[];for(const gid of s.approvalGroupIds||[]){let status='⚠️ não validado';if(ctx.getGroupMetadata){const meta=await ctx.getGroupMetadata(gid).catch(()=>null);if(meta){const bot=ctx.botJid||'';const me=(meta.participants||[]).find(p=>p?.id===bot||p?.jid===bot||p?.participant===bot);status=me?.admin?'✅ válido':'⚠️ bot não é administrador';}else status='❌ inacessível';}rows.push(`${rows.length+1}. ${status}\n   ID: ${gid}`);}return ctx.reply(tag(`📚 *GRUPOS PERMANENTES*\n\n${rows.length?rows.join('\n\n'):'⚠️ Nenhum grupo configurado.'}\n\nTotal: *${rows.length}*`));}});

  registerCommand({name:'setperguntas',aliases:['triagemperguntas'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const raw=String(ctx.q||'').trim();if(!raw)throw new ValidationError('Informe as perguntas separadas por |.');const questions=raw.split('|').map(x=>x.trim()).filter(Boolean).slice(0,20).map((q,i)=>({id:'q_'+(i+1),type:'text',required:true,question:q,order:i+1}));await saveSettings(ctx.from,{questions,maxQuestions:20,enabled:false});return ctx.reply(tag(`✅ ${questions.length} perguntas salvas. Use ${config.prefix}triagemativar para ativar.`));}});
  registerCommand({name:'triagempergunta',aliases:['addpergunta'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(tag('Use ×triagemcriar para montar a triagem de forma simples.'))});
  registerCommand({name:'verperguntas',aliases:['listarperguntas'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);return ctx.reply(tag(s.questions.length?s.questions.map((q,i)=>`${i+1}. [${q.type}] ${q.question}`).join('\n'):'Nenhuma pergunta configurada.'));}});
  registerCommand({name:'triagemstatus',aliases:['triagem'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);const mg=s.triageGroupId||ctx.from;return ctx.reply(tag(`🛡️ *STATUS DA TRIAGEM*\n\nStatus: *${s.enabled?'ATIVA':'DESATIVADA'}*\nPerguntas: *${s.questions.length}/20*\n📥 Entrada: *${ctx.from}*\n⚖️ Julgamento: *${s.triageGroupId||'mesmo grupo de entrada'}*\n📌 Destino calculado: *${mg}*\n📚 Grupos permanentes: *${(s.approvalGroupIds||[]).length}*\n🔢 Configuração: *v${s.configurationVersion||0}*`));}});
  registerCommand({name:'filatriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const d=readCollection('triage',{byId:{}});const a=Object.values(d.byId||{}).filter(t=>t.groupId===ctx.from&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(t.state)).sort((x,y)=>x.createdAt-y.createdAt);return ctx.reply(tag(a.length?a.map((t,i)=>`${i+1}. *${t.id}* — @${idOf(t.userId)} — ${t.state}`).join('\n'):'Fila vazia.'),{mentions:a.map(t=>t.userId)});}});
  registerCommand({name:'triagemstats',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await triageStats(ctx.from);return ctx.reply(tag(`📊 Total: ${s.total}\n🟡 Pendentes: ${s.pending}\n🔵 Em andamento: ${s.running}\n⚖️ Julgamento: ${s.judging}\n🟢 Aprovadas: ${s.approved}\n🔴 Reprovadas: ${s.rejected}\n⚫ Expiradas: ${s.expired}`));}});
  registerCommand({name:'conselho',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');return ctx.reply(tag(`${triageSummaryText(t,(await rejectionHistory(t.userId)).length)}\n\n${config.prefix}aprovar ${id}\n${config.prefix}reprovar ${id} motivo`),{mentions:[t.userId]});}});
  registerCommand({name:'aprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);const management=t?.managementGroupId||t?.triageGroupId||t?.entryGroupId||t?.groupId;if(!t||management!==ctx.from)throw new ValidationError('Triagem não encontrada neste grupo de julgamento.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'approve');if(!r.ok)throw new ValidationError(r.reason);const transport={user:{id:ctx.botJid||''},groupMetadata:ctx.getGroupMetadata,groupParticipantsUpdate:ctx.groupParticipantsUpdate,sendMessage:ctx.sendMessage};const actions=await executeApprovalActions(transport,r.triage);const failed=actions.results.filter(x=>!x.success).length;const removed=actions.removal?.success===true;const kept=(r.triage.approvalGroupIds||[]).length===0;return ctx.reply(tag(kept?`✅ Triagem *${id}* aprovada.\n\nℹ️ Nenhum grupo permanente configurado. O membro permanece no grupo de entrada.`:`✅ Triagem *${id}* aprovada.\n\n📚 Destinos: ${(r.triage.approvalGroupIds||[]).length}\n${failed?`⚠️ Falhas de adição: ${failed}\n`:''}${removed?'🚪 Remoção do grupo de entrada confirmada.':'⚠️ A remoção do grupo de entrada não foi confirmada.'}`),{mentions:[t.userId]});}});
  registerCommand({name:'reprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),reason=String(ctx.q).slice(id.length).trim(),t=await getTriage(id),management=t?.managementGroupId||t?.triageGroupId||t?.entryGroupId||t?.groupId;if(!t||management!==ctx.from)throw new ValidationError('Triagem não encontrada neste grupo de julgamento.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'reject',reason);if(!r.ok)throw new ValidationError(r.reason==='reason-required'?'Informe o motivo.':r.reason);const transport={user:{id:ctx.botJid||''},groupMetadata:ctx.getGroupMetadata,groupParticipantsUpdate:ctx.groupParticipantsUpdate,sendMessage:ctx.sendMessage};const actions=await executeRejectionActions(transport,r.triage);return ctx.reply(tag(`❌ Triagem *${id}* reprovada.\nMotivo: ${reason}\n\n${actions.removal?.success?'🚫 Remoção confirmada.':'⚠️ Remoção não confirmada.'}`),{mentions:[t.userId]});}});
  registerCommand({name:'cancelatriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const u=target(ctx);if(!u)throw new ValidationError('Mencione o usuário.');const t=await cancelActiveTriage(ctx.from,u,'cancelada pelo administrador');return ctx.reply(tag(t?'Triagem cancelada.':'Nenhuma triagem ativa.'));}});
  registerCommand({name:'bl',aliases:['blacklist'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,cooldown:2,handler:async ctx=>{const sub=String(ctx.args?.[0]||'check').toLowerCase();const u=target(ctx)||ctx.args?.[1]||ctx.sender;if(['list','stats'].includes(sub)){if(!ctx.isOwner)throw new ValidationError('Apenas o dono.');const r=sub==='list'?await blacklistList():await blacklistStats();return ctx.reply(tag(JSON.stringify(r,null,2)));}if(['check','info'].includes(sub)){const e=await blacklistInfo(u);return ctx.reply(tag(e?`🚫 Bloqueado\n@${idOf(u)}\nMotivo: ${e.reason}`:`🟢 @${idOf(u)} sem blacklist.`),{mentions:[u]});}if(!ctx.isOwner&&!ctx.isGroupAdmin)throw new ValidationError('Sem permissão.');if(['remove','del'].includes(sub)){return ctx.reply(tag(await removeBlacklist(u,ctx.sender)?'Blacklist removida.':'Nenhuma blacklist ativa.'));}if(['add','perm','temp'].includes(sub)){const days=sub==='temp'?Number(ctx.args?.[2]):0;const start=sub==='temp'?3:1;const reason=String(ctx.args?.slice(start).join(' ')||'').trim();if(reason.length<3)throw new ValidationError('Informe o motivo.');await setBlacklist(u,ctx.sender,reason,days*86400000,{source:'manual',level:'blacklist'});return ctx.reply(tag('🚫 Blacklist registrada.'));}throw new ValidationError('Use bl check/add/temp/remove/list/stats.');}});
  registerCommand({name:'triagemmenu',aliases:['triagemhelp'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(tag(`🧭 *MENU DA TRIAGEM*\n\n⚙️ ${config.prefix}triagemstatus — status geral\n🔗 ${config.prefix}triagemconectar ENTRADA TRIAGEM — conectar grupos\n🔌 ${config.prefix}triagemdesconectar — voltar ao modo sem conexão\n📚 ${config.prefix}triagemgrupos ID1 ID2 — definir destinos dos aprovados\n➕ ${config.prefix}triagemgruposadicionar ID — adicionar destino\n➖ ${config.prefix}triagemgrupostirar ID — remover destino\n📊 ${config.prefix}triagemgruposstatus — validar destinos\n🧹 ${config.prefix}triagemgruposlimpar — limpar destinos\n♻️ ${config.prefix}triagemgruposreset — resetar destinos\n📖 ${config.prefix}triagemguia — guia completo\n\n📋 ${config.prefix}filatriagem — fila\n📄 ${config.prefix}triagemficha ID — ficha\n⚖️ ${config.prefix}aprovar ID — aprovar\n❌ ${config.prefix}reprovar ID motivo — reprovar\n\n💡 Novos membros entram automaticamente na triagem. As perguntas são respondidas no PV pelo link publicado no grupo.`))});
  registerCommand({name:'menutriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,hidden:true,handler:async ctx=>ctx.reply(tag(`🧭 *MENU DA TRIAGEM*\n\n${config.prefix}triagemstatus — status geral\n${config.prefix}triagemconectar ENTRADA TRIAGEM — conectar grupos\n${config.prefix}triagemdesconectar — desconectar\n${config.prefix}triagemgrupos ID1 ID2 — destinos dos aprovados\n${config.prefix}triagemgruposadicionar ID — adicionar\n${config.prefix}triagemgrupostirar ID — remover\n${config.prefix}triagemgruposstatus — validar\n${config.prefix}triagemgruposlimpar — limpar\n${config.prefix}triagemgruposreset — resetar\n${config.prefix}triagemguia — guia completo`))});
  registerCommand({name:'triagemguia',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(tag(`📖 *GUIA COMPLETO DA TRIAGEM*\n\n🛡️ *Como funciona*\n1. O membro entra no grupo.\n2. A triagem é criada automaticamente.\n3. O link individual é publicado no próprio grupo.\n4. As perguntas são respondidas no PV.\n5. A ficha chega ao grupo de julgamento.\n6. Um administrador aprova ou reprova.\n\n🔗 *Conectar julgamento*\n${config.prefix}triagemconectar ID_ENTRADA ID_TRIAGEM\n\nSe não quiser conexão, não faça nada: a ficha volta para o próprio grupo de entrada.\n\n📚 *Destinos dos aprovados*\n${config.prefix}triagemgrupos ID1 ID2\nDefine/substitui os grupos permanentes.\n\n${config.prefix}triagemgruposadicionar ID\nAdiciona sem apagar os atuais.\n\n${config.prefix}triagemgrupostirar ID\nRemove somente o informado.\n\n${config.prefix}triagemgruposstatus\nMostra se os grupos estão acessíveis e se o bot é administrador.\n\n${config.prefix}triagemgruposlimpar\n${config.prefix}triagemgruposreset\nAmbos deixam a lista vazia.\n\n⚠️ *Regra de segurança*\nID inválido não substitui uma configuração válida. A validação é atômica.\n\n✅ *Aprovado sem grupos permanentes*\nO membro permanece no grupo de entrada.\n\n🚫 *Reprovado*\nExige motivo, envia o motivo no PV e remove o membro do grupo de entrada.\n\n📊 ${config.prefix}triagemstatus\nMostra entrada, julgamento, destinos e versão da configuração.`))});
}
export { handleTriageBuilderMessage, memberJoined, triageLink };
export default { register };
