import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import manager from '../../features/responseMedia/ResponseMediaManager.js';

export async function register() {
  registerCommand({
    name:'media', aliases:['responsemedia','midia'], category:'dono', plugin:'responseMedia', priority:1000,
    permission:Role.OWNER, ownerOnly:true, audit:true, cooldown:0,
    description:'Gerencia mídia personalizada das respostas do bot.', usage:'×media',
    responseCapabilities:{ supportsCustomMedia:false, isMenu:true, responseKey:'system.media' },
    handler:manager.dispatch
  });
}
export default { register };
