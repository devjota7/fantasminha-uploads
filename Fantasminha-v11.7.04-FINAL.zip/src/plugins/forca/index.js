import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { start, cancelForContext } from '../../games/forca/ForcaService.js';
import { getPlayer, rankGroup } from '../../games/forca/ForcaStatisticsService.js';

export async function register(){
  registerCommand({name:'forca',category:'jogos',plugin:'forca',permission:Role.USER,groupOnly:true,cooldown:2,description:'Forca multiplayer coletiva por grupo.',handler:start});
  registerCommand({name:'rankforca',aliases:['forcarank'],category:'jogos',plugin:'forca',permission:Role.USER,groupOnly:true,cooldown:3,description:'Ranking da Forca no grupo.',handler:async ctx=>{const rows=rankGroup(ctx.from).slice(0,10);if(!rows.length)return ctx.reply?.('🏆 Ainda não há estatísticas da FORCA neste grupo.');const lines=rows.map((x,i)=>`${i+1}. @${String(x.userId).split('@')[0]} — 🏆 ${x.wins} vitória(s) · 🔤 ${x.lettersCorrect} letras certas`);return ctx.reply?.(`╭━━━ 🏆 RANKING FORCA ━━━╮\n\n${lines.join('\n')}\n\n╰━━━━━━━━━━━━━━━━╯`,{mentions:rows.map(x=>x.userId)});}});
  registerCommand({name:'meuforca',aliases:['forcameu'],category:'jogos',plugin:'forca',permission:Role.USER,groupOnly:true,cooldown:2,description:'Suas estatísticas da Forca.',handler:async ctx=>{const p=getPlayer(ctx.from,ctx.sender);if(!p)return ctx.reply?.('👻 Você ainda não possui estatísticas na FORCA.');return ctx.reply?.(`╭━━━ 👻 MINHA FORCA ━━━╮\n\n🏆 Vitórias: ${p.wins}\n🎮 Partidas: ${p.games}\n🔤 Letras certas: ${p.lettersCorrect}\n❌ Letras erradas: ${p.lettersWrong}\n📝 Palavras tentadas: ${p.wordGuesses}\n✅ Palavras certas: ${p.wordCorrect}\n\n╰━━━━━━━━━━━━━━━━╯`);}});
}
export default {register,cancelForContext};
