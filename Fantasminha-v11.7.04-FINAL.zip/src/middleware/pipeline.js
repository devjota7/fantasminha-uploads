import { runCommand, getCommand } from '../core/registry.js';
import logger from '../core/logger.js';
import config from '../core/config.js';
import { getEffectivePrefix } from '../core/prefix.js';
import { rateLimit } from './rateLimit.js';
import { checkFlood, addWarnV2, isAutoBanEnabled } from './antiflood.js';
import { emit, Events } from '../events/index.js';
import { cooldownMultiplier } from '../services/vipBenefits.js';
import { ensureGroupClan } from '../services/groupClans.js';
import { resolveMigration, noteMigrationUsed } from '../platform/migrations/index.js';
import { enrichMessageContext } from '../core/messageContext.js';
import { recordEnvelope } from '../core/messageEnvelope.js';
import { getCustomCommand } from '../services/customCommands.js';
import { handleTriageBuilderMessage } from '../services/triage.js';
import { recordMessage } from '../services/profile.js';
import { handleInnovationMessage } from '../services/innovation.js';
import { isDuplicateMessage } from './messageDedup.js';
import { handleRawGameInput } from '../services/gameInput.js';
import { handleAnswer as handleMemoryCupsAnswer } from '../games/memory-cups/MemoryCupsService.js';
import { handleGuess as handleQuizGuess } from '../games/quiz/QuizService.js';
import { handleInput as handleForcaInput } from '../games/forca/ForcaService.js';
import { handleAnswer as handleStopPrivateInput, handleGroupInput as handleStopGroupInput } from '../games/stop/StopCore.js';
import { handlePrivateMessage as handleTriagePrivateMessage } from '../services/triage.js';
import { privateMessageAllowed } from '../services/pvGateway.js';
import { handleGuess as handleGarticGuess } from '../games/gartic/GarticService.js';
import { clearAfkFromMessage } from '../services/social.js';
import { handleSessionMessage, executeAutomatic } from '../features/reactions/ReactionManager.js';
import { handleSessionMessage as handleResponseMediaSession } from '../features/responseMedia/ResponseMediaManager.js';

export function extractCommand(text, prefix = config.prefix) {
  if (!text || typeof text !== 'string') return null;
  const t = text.trim();
  if (!t.startsWith(prefix)) return null;
  const body = t.slice(prefix.length).trim();
  if (!body) return null;
  const [cmd, ...rest] = body.split(/\s+/);
  return { command: cmd.toLowerCase(), args: rest, q: rest.join(' '), raw: body };
}

export async function handleMessage(ctx) {
  enrichMessageContext(ctx);
  // Resolve uma única vez por mensagem. Em grupo: GRUPO -> GLOBAL. Em PV: GLOBAL.
  ctx.prefix = getEffectivePrefix(ctx?.isGroup ? ctx.from : '', { globalPrefix: config.prefix });
  const incomingText = String(ctx.body || ctx.text || '').trim();

  // PV é uma superfície restrita. Primeiro entram apenas os fluxos que
  // explicitamente precisam do privado: triagem ativa/código e STOP
  // configurado/participação/resposta. Todo o resto é bloqueado sem resposta.
  if (ctx?.isPrivate && ctx?.sender && !ctx?.fromMe) {
    try {
      const triageResult = await handleTriagePrivateMessage({
        sock: ctx.sock || ctx.socket || null,
        info: ctx.message,
        sender: ctx.sender,
        text: incomingText,
        send: async text => ctx.reply?.(text)
      });
      if (triageResult?.handled) return triageResult;
    } catch (e) { logger.warn('triage', `PV: ${e.message}`); }
  }

  try {
    const stopResult = ctx?.isPrivate ? await handleStopPrivateInput(ctx) : await handleStopGroupInput(ctx);
    if (stopResult?.handled) return stopResult;
  } catch (e) { logger.warn('stop', `entrada: ${e.message}`); }

  if (ctx?.isPrivate && ctx?.sender && !privateMessageAllowed(incomingText, ctx.prefix || config.prefix)) {
    return { handled: false, pvBlocked: true };
  }

  // Reações automáticas só podem observar mensagens que passaram pela política
  // de entrada; isso impede respostas espontâneas em PV.
  const earlyIsCommand = !!incomingText && incomingText.startsWith(ctx.prefix || config.prefix);
  if (!earlyIsCommand && !ctx.fromMe && !ctx.message?.key?.fromMe) {
    try { await executeAutomatic(ctx); } catch (e) { logger.warn('reaction-manager', `execução antecipada: ${e.message}`); }
  }
  if (!ctx?.message?.__fantasminhaDedupAccepted && isDuplicateMessage(ctx)) { logger.debug?.('pipeline', 'mensagem duplicada ignorada'); return { handled:true, duplicate:true }; }
  globalThis.__fantasminhaOwnerIds = [config.ownerNumber, config.ownerLid, ...(config.ownerIds || [])].filter(Boolean);
  // AFK clássico: qualquer mensagem do próprio usuário encerra a ausência.
  // A exceção é o próprio comando ×afk/×ausente, que pode criar/atualizar o estado.
  if (ctx.sender && !ctx.fromMe) {
    try { await clearAfkFromMessage(ctx); } catch (e) { logger.debug?.('afk', `não foi possível limpar AFK: ${e.message}`); }
  }
  if (!ctx.isOwner) { const { configuredOwner } = await import('../core/permissions.js'); ctx.isOwner = configuredOwner(ctx.sender); }
  // Reaction Manager: sessões administrativas e execução automática centralizadas.
  try {
    const mediaSession = await handleResponseMediaSession(ctx);
    if (mediaSession?.handled) return mediaSession;
  } catch (e) { logger.warn('response-media', `sessão: ${e.message}`); }
  try {
    const session = await handleSessionMessage(ctx);
    if (session?.handled) return session;
  } catch (e) { logger.warn('reaction-manager', `sessão: ${e.message}`); }
  if (ctx.message) recordEnvelope(ctx.message, { readable: true, kind: ctx.message?.message?.paymentMessage ? 'payment' : 'other' });
  await emit(Events.MESSAGE, ctx);
  // Fluxo sem prefixo do construtor simples de triagem.
  try { const setup = await handleTriageBuilderMessage(ctx); if (setup?.handled) return setup; } catch (e) { logger.warn('triage-builder', e.message); }
  try { const gameInput = await handleRawGameInput(ctx); if (gameInput?.handled) return gameInput; } catch (e) { logger.warn('game-input', e.message); }
  try { const forcaInput = await handleForcaInput(ctx); if (forcaInput?.handled) return forcaInput; } catch (e) { logger.warn('forca', e.message); }
  try { const quizGuess = await handleQuizGuess(ctx); if (quizGuess?.handled) return quizGuess; } catch (e) { logger.warn('quiz', e.message); }
  try { const garticGuess = await handleGarticGuess(ctx); if (garticGuess?.handled) return garticGuess; } catch (e) { logger.warn('gartic', e.message); }
  try { const memoryCups = await handleMemoryCupsAnswer(ctx); if (memoryCups?.handled) return memoryCups; } catch (e) { logger.warn('memory-cups', e.message); }
  try { const game = await handleInnovationMessage(ctx); if (game?.handled) return game; } catch (e) { logger.warn('innovation-game', e.message); }
  if (ctx.isGroup && ctx.sender) recordMessage(ctx.sender, ctx.from);
  if (ctx.isGroup && ctx.from) {
    try { await ensureGroupClan(ctx.from, ctx.groupName || 'Grupo', ctx.participantCount || 0); }
    catch (e) { logger.warn('pipeline', 'não foi possível sincronizar Clã do Grupo', { error: e.message }); }
  }

  // Anti-flood unificado (só comandos / mensagens rápidas)
  if (ctx.sender && !ctx.isOwner && !ctx.isGroupAdmin) {
    const flood = checkFlood(`${ctx.from || 'private'}:${ctx.sender}`, { max: 10, windowMs: 7000 });
    if (flood.flooded) {
      if (ctx.isGroup && ctx.from) {
        const { warns, shouldBan } = await addWarnV2(ctx.from, ctx.sender);
        const autoban = await isAutoBanEnabled(ctx.from);
        if (ctx.reply) {
          await ctx.reply(
            `🕯️ Flood detectado. Warn *${warns}*.` +
              (shouldBan && autoban ? '\n⛔ Limite atingido — *auto-ban* sugerido (admin execute ban).' : '')
          );
        }
        ctx._floodShouldBan = shouldBan && autoban;
        ctx._floodTarget = ctx.sender;
      } else if (ctx.reply) {
        await ctx.reply('🕯️ Devagar no véu (anti-flood).');
      }
      return { handled: true, flooded: true };
    }
  }

  const parsed = extractCommand(ctx.body || ctx.text || '', ctx.prefix || config.prefix);
  if (!parsed) return { handled: false };

  ctx.command = parsed.command;
  ctx.args = parsed.args;
  ctx.q = parsed.q;

  const rl = rateLimit(ctx.sender, { scope: ctx.from || 'private', max: 20, windowMs: 10_000 });
  if (!rl.ok) {
    if (ctx.reply) await ctx.reply(`🕯️ Rate limit. Aguarde ${rl.retryAfter}s.`);
    return { handled: true, rateLimited: true };
  }

  // VIP reduz cooldown efetivo via flag no ctx
  ctx.cooldownMult = cooldownMultiplier(ctx.sender);

  if (!getCommand(parsed.command)) {
    const custom = getCustomCommand(parsed.command);
    if (custom) {
      const text = custom.text.replace(/\{user\}/gi, ctx.pushname || ctx.sender || '').replace(/\{q\}/gi, ctx.q || '');
      if (ctx.reply) await ctx.reply(text);
      return { handled: true, custom: true, command: parsed.command };
    }
    const migration = resolveMigration(parsed.command);
    if (migration && getCommand(migration.target)) {
      await noteMigrationUsed(migration, ctx);
      if (migration.mode === 'notice' && ctx.reply) await ctx.reply(`🔄 Comando atualizado: use ${ctx.prefix || config.prefix}${migration.target} daqui para frente.`);
      const result = await runCommand(migration.target, { ...ctx, command: migration.target, migratedFrom: parsed.command });
      return { handled: result.found, command: migration.target, migratedFrom: parsed.command };
    }
    return { handled: false, legacy: true, command: parsed.command };
  }

  try {
    const result = await runCommand(parsed.command, ctx);
    return { handled: result.found, command: parsed.command };
  } catch (err) {
    logger.error('pipeline', err.message, { command: parsed.command });
    if (ctx.reply && !err?.__fantasminhaUserErrorHandled) await ctx.reply(err.userMessage || err.message || '🕯️ O véu engasgou.');
    return { handled: true, error: true };
  }
}

export default { extractCommand, handleMessage };
