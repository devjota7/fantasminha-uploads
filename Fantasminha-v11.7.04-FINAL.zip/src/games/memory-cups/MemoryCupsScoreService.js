export function calculateScore({ level = 1, streak = 0, frameInterval = 250, timeout = false, correct = false } = {}) {
  if (!correct) return 0;
  const baseScore = 100;
  const levelBonus = Math.max(0, Math.floor(level - 1) * 25);
  const speedBonus = Math.max(0, Math.floor((300 - Number(frameInterval || 250)) / 4));
  const streakBonus = Math.max(0, Math.floor(streak) * 15);
  return baseScore + levelBonus + speedBonus + streakBonus + (timeout ? 0 : 0);
}

export default { calculateScore };
