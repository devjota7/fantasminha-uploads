const CUP = '🥤';
const GHOST = '👻';

const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

export function render({ cupCount, ghostPosition = null, showGhost = false, offsets = [] } = {}) {
  const count = Math.max(1, Number(cupCount) || 1);
  const cells = [];
  for (let i = 0; i < count; i += 1) {
    const offset = clamp(Number(offsets[i] || 0), -2, 2);
    const left = offset > 0 ? ' '.repeat(offset) : '';
    const right = offset < 0 ? ' '.repeat(Math.abs(offset)) : '';
    const item = showGhost && i === ghostPosition ? GHOST : CUP;
    cells.push(`${left}${item}${right}`);
  }
  return cells.join('   ');
}

export function renderRound({ level, cupCount, ghostPosition, showGhost = false, offsets = [], prompt = '' } = {}) {
  const line = render({ cupCount, ghostPosition, showGhost, offsets });
  return `👻 *MEMÓRIA DOS COPOS*\n\nNível ${level}\n\n${line}${prompt ? `\n\n${prompt}` : ''}`;
}

export function renderAnswerPrompt({ level, cupCount } = {}) {
  return renderRound({
    level,
    cupCount,
    showGhost: false,
    prompt: '👻 *Onde está o Fantasminha?*\nEnvie a posição do copo (1 até o último).'
  });
}

export function renderResult({ level, cupCount, selectedPosition, correctPosition, score, bestLevel, streak, timeout = false } = {}) {
  const ok = !timeout && Number(selectedPosition) === Number(correctPosition);
  return ok
    ? `🎯 *ACERTOU!*\n\n👻 Você encontrou o Fantasminha.\n📈 Nível concluído: ${level}\n🔥 Sequência: ${streak}\n⭐ Pontuação: ${score}\n🏆 Melhor nível: ${bestLevel}`
    : `❌ *${timeout ? 'TEMPO ESGOTADO!' : 'VOCÊ ERROU!'}*\n\n👻 O Fantasminha estava no copo *${correctPosition}*.\n📈 Nível alcançado: ${level}\n🔥 Sequência: ${streak}\n⭐ Pontuação: ${score}\n🏆 Melhor nível: ${bestLevel}`;
}

export default { render, renderRound, renderAnswerPrompt, renderResult };
