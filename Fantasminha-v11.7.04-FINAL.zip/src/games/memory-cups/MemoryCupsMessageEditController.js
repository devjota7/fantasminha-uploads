const sleep = (ms) => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));

export class MessageEditController {
  constructor({ sendMessage, jid, messageKey, minInterval = 115, maxRetries = 1, maxDuration = 45_000 } = {}) {
    if (typeof sendMessage !== 'function') throw new Error('sendMessage obrigatório');
    this.sendMessage = sendMessage;
    this.jid = jid;
    this.messageKey = messageKey;
    this.minInterval = Math.max(1, Number(minInterval) || 1);
    this.maxRetries = Math.max(0, Number(maxRetries) || 0);
    this.maxDuration = Math.max(1, Number(maxDuration) || 1);
    this.startedAt = Date.now();
    this.lastAt = 0;
    this.cancelled = false;
    this.chain = Promise.resolve();
  }

  cancel() { this.cancelled = true; }

  async _edit(text) {
    if (this.cancelled) return { skipped: true, cancelled: true };
    if (Date.now() - this.startedAt > this.maxDuration) return { skipped: true, timeout: true };
    const wait = this.lastAt ? this.minInterval - (Date.now() - this.lastAt) : 0;
    if (wait > 0) await sleep(wait);
    if (this.cancelled) return { skipped: true, cancelled: true };

    let lastError = null;
    for (let attempt = 0; attempt <= this.maxRetries; attempt += 1) {
      try {
        const result = await this.sendMessage(this.jid, { text, edit: this.messageKey });
        this.lastAt = Date.now();
        return { ok: true, result, attempt };
      } catch (error) {
        lastError = error;
        if (attempt < this.maxRetries) await sleep(Math.min(300, this.minInterval));
      }
    }
    this.lastAt = Date.now();
    return { ok: false, error: lastError };
  }

  enqueue(text) {
    this.chain = this.chain.then(() => this._edit(text));
    return this.chain;
  }

  async flush() { return this.chain; }
}

export default { MessageEditController };
