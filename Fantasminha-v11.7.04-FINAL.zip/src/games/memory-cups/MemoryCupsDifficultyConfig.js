const n = (v, d) => Number.isFinite(Number(v)) ? Number(v) : d;

export const MemoryCupsDifficultyConfig = Object.freeze({
  minLevel: 1,
  maxLevel: Number(process.env.MEMORY_CUPS_MAX_LEVEL || 1000000),
  minFrameInterval: n(process.env.MEMORY_CUPS_MIN_FRAME_INTERVAL, 115),
  maxFrameInterval: n(process.env.MEMORY_CUPS_MAX_FRAME_INTERVAL, 360),
  maxFramesPerRound: n(process.env.MEMORY_CUPS_MAX_FRAMES, 180),
  maxAnimationDuration: n(process.env.MEMORY_CUPS_MAX_ANIMATION_MS, 45_000),
  answerTimeout: n(process.env.MEMORY_CUPS_ANSWER_TIMEOUT, 30_000),
  showGhostMs: n(process.env.MEMORY_CUPS_SHOW_GHOST_MS, 900),
  hideMs: n(process.env.MEMORY_CUPS_HIDE_MS, 220),
  editRetries: n(process.env.MEMORY_CUPS_EDIT_RETRIES, 1),
  maxCups: n(process.env.MEMORY_CUPS_MAX_CUPS, 12),
  baseMoves: n(process.env.MEMORY_CUPS_BASE_MOVES, 5)
});

export function getDifficulty(level = 1) {
  const l = Math.max(1, Math.floor(Number(level) || 1));
  const tier = Math.max(0, l - 1);
  const cupCount = Math.min(
    MemoryCupsDifficultyConfig.maxCups,
    l <= 2 ? 3 : l <= 4 ? 5 : l <= 7 ? 7 : l <= 10 ? 9 : Math.min(12, 9 + Math.floor((l - 10) / 4))
  );

  const complexity = Math.min(1, 0.15 + tier * 0.035);
  const movementCount = Math.min(
    Math.max(6, MemoryCupsDifficultyConfig.maxFramesPerRound - 18),
    MemoryCupsDifficultyConfig.baseMoves + Math.floor(tier * 1.9)
  );
  const directionChanges = Math.min(movementCount - 1, Math.max(1, Math.floor(movementCount * (0.28 + Math.min(0.3, tier * 0.018)))));
  const reversalFrequency = Math.min(0.7, 0.18 + tier * 0.018);
  const frameInterval = Math.max(
    MemoryCupsDifficultyConfig.minFrameInterval,
    MemoryCupsDifficultyConfig.maxFrameInterval - Math.min(245, tier * 11)
  );
  const microFrames = Math.min(7, 3 + Math.floor(tier / 4));
  const shuffleIntensity = Math.min(1, 0.25 + tier * 0.035);

  return Object.freeze({
    level: l,
    cupCount,
    frameInterval,
    movementCount,
    microFrames,
    directionChanges,
    reversalFrequency,
    shuffleIntensity,
    trajectoryComplexity: complexity,
    roundDuration: Math.min(MemoryCupsDifficultyConfig.maxAnimationDuration, 1200 + movementCount * microFrames * frameInterval)
  });
}

export default { MemoryCupsDifficultyConfig, getDifficulty };
