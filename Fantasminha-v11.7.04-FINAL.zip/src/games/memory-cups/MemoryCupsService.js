import { createGame, getGame, listActiveGames, startGame, updateGame, finishGame } from '../../services/gameEngine.js';
import gameSessions from '../../services/gameSessionManager.js';
import { recordResult, getStats } from '../../services/statsEngine.js';
import { grant } from '../../platform/rewards/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import logger from '../../core/logger.js';
import { emit } from '../../events/index.js';
import { getDifficulty, MemoryCupsDifficultyConfig } from './MemoryCupsDifficultyConfig.js';
import { generateTrajectory, validateTrajectory } from './MemoryCupsShuffleEngine.js';
import { MemoryCupsAnimationEngine } from './MemoryCupsAnimationEngine.js';
import * as renderer from './MemoryCupsRenderer.js';
import { validateAnswer } from './MemoryCupsAnswerValidator.js';
import { calculateScore } from './MemoryCupsScoreService.js';
import { MemoryCupsPhase } from './MemoryCupsState.js';

const GAME_TYPE = 'memory-cups';
const keyFor = (groupId, userId) => `${groupId || 'private'}::${userId}`;
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
const locks = new Map();
const animations = new Map();

async function exclusive(key, fn) {
  const previous = locks.get(key) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  locks.set(key, previous.then(() => current));
  await previous;
  try { return await fn(); } finally { release(); if (locks.get(key) === current) locks.delete(key); }
}

function findPlayerGame(groupId, userId) {
  return listActiveGames(groupId).find(g => g.gameType === GAME_TYPE && g.creatorId === userId && g.participants.includes(userId)) || null;
}

function statView(groupId, userId) {
  const s = getStats(groupId, userId) || {};
  const game = s.games?.[GAME_TYPE] || {};
  return {
    gamesPlayed: Number(game.plays || 0),
    gamesWon: Number(game.wins || 0),
    gamesLost: Math.max(0, Number(game.plays || 0) - Number(game.wins || 0)),
    highestLevel: Number(game.highestLevel || 0),
    highestScore: Number(game.highestScore || 0),
    currentStreak: Number(s.streak || 0),
    bestStreak: Number(s.bestStreak || 0),
    totalScore: Number(s.score || 0)
  };
}

async function persistOutcomeStats(groupId, userId, { win, score, xp, level }) {
  const out = await recordResult({ groupId, userId, gameType: GAME_TYPE, result: win ? 'correct' : 'incorrect', win, loss: !win, score, xp });
  const current = out.games?.[GAME_TYPE] || {};
  await import('../../database/store.js').then(({ updateCollection }) => updateCollection('stats_engine', db => {
    db.players ||= {};
    const key = `${groupId || 'global'}::${userId}`;
    const p = db.players[key];
    if (!p) return db;
    p.games ||= {};
    p.games[GAME_TYPE] ||= { plays: 0, wins: 0, score: 0, xp: 0 };
    p.games[GAME_TYPE].highestLevel = Math.max(Number(p.games[GAME_TYPE].highestLevel || 0), Number(level || 0));
    p.games[GAME_TYPE].highestScore = Math.max(Number(p.games[GAME_TYPE].highestScore || 0), Number(score || 0));
    return db;
  }, { players: {} }));
  return { out, current };
}

async function audit(action, ctx, details = {}) {
  try { await recordAudit({ actor: ctx?.sender || null, target: ctx?.from || null, action, scope: ctx?.from || null, result: 'success', details }); } catch (e) { logger.debug?.('memory-cups', `audit: ${e.message}`); }
}

async function safeFinish(gameId, groupId, status, result) {
  try { return await finishGame(gameId, groupId, { status, winnerId: result?.win ? result.userId : null, reason: result?.reason || null, result }); }
  catch (e) { logger.warn('memory-cups', `finish: ${e.message}`); return null; }
}

export async function start(ctx) {
  const groupId = ctx.from || 'private';
  const userId = ctx.sender;
  if (!userId) throw new Error('Jogador não identificado.');
  const existing = findPlayerGame(groupId, userId);
  if (existing) {
    await ctx.reply?.(`⚠️ *Você já está jogando uma partida de Memória dos Copos.*\n\n🎮 Nível atual: ${existing.state?.level || 1}\nUse *×sairjogo* para cancelar.`);
    return existing;
  }

  const level = 1;
  const difficulty = getDifficulty(level);
  const ghostInitialPosition = Math.floor(Math.random() * difficulty.cupCount);
  const trajectory = generateTrajectory({ cupCount: difficulty.cupCount, level, initialPosition: ghostInitialPosition });
  const check = validateTrajectory(trajectory);
  if (!check.ok) throw new Error(`Trajetória inválida: ${check.errors.join(', ')}`);

  const game = await createGame({
    groupId,
    gameType: GAME_TYPE,
    creatorId: userId,
    maxPlayers: 1,
    timeoutMs: MemoryCupsDifficultyConfig.answerTimeout + difficulty.roundDuration + MemoryCupsDifficultyConfig.showGhostMs + MemoryCupsDifficultyConfig.hideMs + 5000,
    state: {
      phase: MemoryCupsPhase.WAITING,
      level,
      cupCount: difficulty.cupCount,
      ghostInitialPosition,
      ghostCurrentPosition: trajectory.finalPosition,
      trajectory,
      frameIndex: 0,
      messageId: null,
      score: 0,
      streak: 0,
      startedAt: Date.now(),
      expiresAt: 0,
      roundStartedAt: Date.now()
    }
  });
  await startGame(game.gameId, groupId, userId);
  await audit('MEMORY_CUPS_STARTED', ctx, { gameId: game.gameId, level, cupCount: difficulty.cupCount });

  let message;
  try {
    message = await ctx.sendMessage(groupId, {
      text: renderer.renderRound({ level, cupCount: difficulty.cupCount, ghostPosition: ghostInitialPosition, showGhost: true, prompt: '👻 *Memorize onde ele está!*' })
    });
  } catch (error) {
    await safeFinish(game.gameId, groupId, 'ABANDONED', { reason: 'initial_message_failed' });
    throw error;
  }

  const messageId = message?.key || null;
  await updateGame(game.gameId, groupId, current => {
    current.state.messageId = messageId;
    current.state.phase = MemoryCupsPhase.SHOWING_GHOST;
    current.state.expiresAt = Date.now() + difficulty.roundDuration + MemoryCupsDifficultyConfig.answerTimeout + MemoryCupsDifficultyConfig.showGhostMs + MemoryCupsDifficultyConfig.hideMs;
    return current;
  });

  gameSessions.begin(keyFor(groupId, userId), GAME_TYPE, { gameId: game.gameId });
  gameSessions.startTimer(keyFor(groupId, userId), GAME_TYPE, difficulty.roundDuration + MemoryCupsDifficultyConfig.answerTimeout + MemoryCupsDifficultyConfig.showGhostMs + MemoryCupsDifficultyConfig.hideMs + 3000, async () => {
    await timeoutGame({ ctx, gameId: game.gameId });
  });

  await sleep(MemoryCupsDifficultyConfig.showGhostMs);
  let active = getGame(game.gameId);
  if (!active || active.status !== 'ACTIVE') return active;
  await updateGame(game.gameId, groupId, current => { current.state.phase = MemoryCupsPhase.HIDING_GHOST; return current; });
  if (messageId) {
    try { await ctx.sendMessage(groupId, { text: renderer.renderRound({ level, cupCount: difficulty.cupCount, showGhost: false, prompt: '' }), edit: messageId }); }
    catch {}
  }
  await sleep(MemoryCupsDifficultyConfig.hideMs);

  active = getGame(game.gameId);
  if (!active || active.status !== 'ACTIVE') return active;
  await updateGame(game.gameId, groupId, current => { current.state.phase = MemoryCupsPhase.SHUFFLING; return current; });

  const animation = new MemoryCupsAnimationEngine({
    sendMessage: ctx.sendMessage,
    jid: groupId,
    messageKey: messageId,
    level,
    cupCount: difficulty.cupCount,
    renderer,
    trajectory,
    difficulty
  });
  animations.set(game.gameId, animation);

  let animationResult;
  try {
    animationResult = await animation.play({
      onFrame: async ({ frameIndex }) => {
        try {
          await updateGame(game.gameId, groupId, current => {
            if (current.state.phase !== MemoryCupsPhase.SHUFFLING) return current;
            current.state.frameIndex = frameIndex;
            return current;
          });
        } catch {}
      }
    });
  } finally {
    animations.delete(game.gameId);
  }

  active = getGame(game.gameId);
  if (!active || active.status !== 'ACTIVE') return active;
  if (animationResult.cancelled) return active;

  await updateGame(game.gameId, groupId, current => {
    current.state.phase = MemoryCupsPhase.WAITING_ANSWER;
    current.state.frameIndex = trajectory.frames.length - 1;
    current.state.expiresAt = Date.now() + MemoryCupsDifficultyConfig.answerTimeout;
    return current;
  });

  if (messageId) {
    try { await ctx.sendMessage(groupId, { text: renderer.renderAnswerPrompt({ level, cupCount: difficulty.cupCount }), edit: messageId }); }
    catch (e) { logger.debug?.('memory-cups', `prompt edit: ${e.message}`); }
  }

  return getGame(game.gameId);
}

export async function handleAnswer(ctx) {
  const groupId = ctx.from || 'private';
  const userId = ctx.sender;
  const raw = String(ctx.body || ctx.text || '').trim();
  if (!userId || !raw || raw.startsWith(ctx.prefix || '×')) return { handled: false };
  const game = findPlayerGame(groupId, userId);
  if (!game || game.state?.phase !== MemoryCupsPhase.WAITING_ANSWER) return { handled: false };

  return exclusive(keyFor(groupId, userId), async () => {
    animations.get(game.gameId)?.cancel();
    animations.delete(game.gameId);
    const current = getGame(game.gameId);
    if (!current || current.status !== 'ACTIVE') return { handled: false };
    if (Date.now() > Number(current.state?.expiresAt || 0)) {
      await timeoutGame({ ctx, gameId: current.gameId });
      return { handled: true, expired: true };
    }

    const answer = validateAnswer(raw, current.state.ghostCurrentPosition, current.state.cupCount);
    if (!answer.ok) {
      await ctx.reply?.(`⚠️ Responda com um número de *1 a ${current.state.cupCount}*. A rodada continua.`);
      return { handled: true, invalid: true };
    }

    const resolved = await updateGame(current.gameId, groupId, g => {
      if (g.state.phase !== MemoryCupsPhase.WAITING_ANSWER) return g;
      g.state.phase = MemoryCupsPhase.RESOLVING;
      g.state.selectedPosition = answer.selectedPosition;
      g.state.correct = answer.valid;
      return g;
    });
    if (resolved.state.phase !== MemoryCupsPhase.RESOLVING) return { handled: true, duplicate: true };

    const difficulty = getDifficulty(resolved.state.level);
    const previousStreak = Number(resolved.state.streak || 0);
    const nextStreak = answer.valid ? previousStreak + 1 : 0;
    const score = calculateScore({ level: resolved.state.level, streak: nextStreak, frameInterval: difficulty.frameInterval, correct: answer.valid });
    const xp = answer.valid ? Math.max(25, Math.floor(score / 3)) : 0;
    const statsResult = await persistOutcomeStats(groupId, userId, { win: answer.valid, score, xp, level: resolved.state.level });
    if (answer.valid) {
      try { await grant(userId, { xp, reason: 'memory_cups_win', source: GAME_TYPE, name: ctx.pushname || '' }); } catch (e) { logger.debug?.('memory-cups', `reward: ${e.message}`); }
    }
    const stats = statView(groupId, userId);
    const result = { win: answer.valid, userId, selectedPosition: answer.selectedPosition, correctPosition: resolved.state.ghostCurrentPosition + 1, score, xp, level: resolved.state.level, nextLevel: answer.valid ? resolved.state.level + 1 : null, bestLevel: Math.max(stats.highestLevel, resolved.state.level), streak: stats.currentStreak, bestStreak: stats.bestStreak };

    const finishedGame = await finishGame(current.gameId, groupId, { status: 'FINISHED', winnerId: answer.valid ? userId : null, reason: answer.valid ? 'correct' : 'incorrect', result });
    if(finishedGame) await emit('GAME_SCORE_FINALIZED',{eventId:`MEMORY-CUPS:${current.gameId}:${userId}`,gameId:'memoriacopos',gameSessionId:current.gameId,groupId,userId,points:score,won:answer.valid,stats:{level:Number(resolved.state.level||1),successfulRounds:answer.valid?1:0,failedRounds:answer.valid?0:1},groupName:ctx.groupName||'Grupo',occurredAt:Date.now()});
    gameSessions.end(keyFor(groupId, userId), GAME_TYPE);
    await audit(answer.valid ? 'MEMORY_CUPS_LEVEL_COMPLETED' : 'MEMORY_CUPS_FAILED', ctx, { gameId: current.gameId, level: resolved.state.level, result });

    if (answer.valid) {
      // Mantém a mesma mensagem também entre níveis: primeiro mostra o resultado,
      // depois transforma a própria mensagem na abertura da próxima rodada.
      if (resolved.state.messageId) {
        try {
          await ctx.sendMessage(groupId, {
            text: renderer.renderRound({
              level: resolved.state.level,
              cupCount: resolved.state.cupCount,
              showGhost: false,
              prompt: `🎯 *ACERTOU!*\n🔥 Próximo nível: *${resolved.state.level + 1}*\n⭐ +${score} pontos\n\nPrepare-se...`
            }),
            edit: resolved.state.messageId
          });
        } catch {}
      }
      await sleep(650);
      const next = await startNextLevel(ctx, resolved.state.level + 1, stats.currentStreak, stats.highestLevel, score, resolved.state.messageId);
      return { handled: true, correct: true, nextGame: next };
    }

    if (resolved.state.messageId) {
      try {
        await ctx.sendMessage(groupId, {
          text: renderer.renderRound({ level: resolved.state.level, cupCount: resolved.state.cupCount, ghostPosition: resolved.state.ghostCurrentPosition, showGhost: true, prompt: renderer.renderResult({ level: resolved.state.level, cupCount: resolved.state.cupCount, selectedPosition: answer.selectedPosition, correctPosition: resolved.state.ghostCurrentPosition + 1, score, bestLevel: stats.highestLevel, streak: stats.currentStreak }) }),
          edit: resolved.state.messageId
        });
      } catch {}
    }
    return { handled: true, correct: false, result };
  });
}

async function startNextLevel(ctx, level, streak, bestLevel, previousScore, reuseMessageId = null) {
  const groupId = ctx.from || 'private';
  const userId = ctx.sender;
  const difficulty = getDifficulty(level);
  const initial = Math.floor(Math.random() * difficulty.cupCount);
  const trajectory = generateTrajectory({ cupCount: difficulty.cupCount, level, initialPosition: initial });
  const game = await createGame({
    groupId,
    gameType: GAME_TYPE,
    creatorId: userId,
    maxPlayers: 1,
    timeoutMs: difficulty.roundDuration + MemoryCupsDifficultyConfig.answerTimeout + 7000,
    state: {
      phase: MemoryCupsPhase.WAITING,
      level,
      cupCount: difficulty.cupCount,
      ghostInitialPosition: initial,
      ghostCurrentPosition: trajectory.finalPosition,
      trajectory,
      frameIndex: 0,
      messageId: null,
      score: previousScore,
      streak,
      startedAt: Date.now(),
      expiresAt: 0,
      roundStartedAt: Date.now()
    }
  });
  await startGame(game.gameId, groupId, userId);
  await audit('MEMORY_CUPS_STARTED', ctx, { gameId: game.gameId, level, cupCount: difficulty.cupCount, continuation: true });

  let messageId = reuseMessageId || null;
  try {
    if (messageId) {
      await ctx.sendMessage(groupId, { text: renderer.renderRound({ level, cupCount: difficulty.cupCount, ghostPosition: initial, showGhost: true, prompt: '👻 *Memorize onde ele está!*' }), edit: messageId });
    } else {
      const msg = await ctx.sendMessage(groupId, { text: renderer.renderRound({ level, cupCount: difficulty.cupCount, ghostPosition: initial, showGhost: true, prompt: '👻 *Memorize onde ele está!*' }) });
      messageId = msg?.key || null;
    }
  } catch (e) {
    await safeFinish(game.gameId, groupId, 'ABANDONED', { reason: 'initial_message_failed' });
    throw e;
  }
  await updateGame(game.gameId, groupId, current => { current.state.messageId = messageId; current.state.phase = MemoryCupsPhase.SHOWING_GHOST; current.state.expiresAt = Date.now() + difficulty.roundDuration + MemoryCupsDifficultyConfig.answerTimeout + MemoryCupsDifficultyConfig.showGhostMs + MemoryCupsDifficultyConfig.hideMs; return current; });
  gameSessions.begin(keyFor(groupId, userId), GAME_TYPE, { gameId: game.gameId });
  gameSessions.startTimer(keyFor(groupId, userId), GAME_TYPE, difficulty.roundDuration + MemoryCupsDifficultyConfig.answerTimeout + MemoryCupsDifficultyConfig.showGhostMs + MemoryCupsDifficultyConfig.hideMs + 3000, async () => timeoutGame({ ctx, gameId: game.gameId }));
  await sleep(MemoryCupsDifficultyConfig.showGhostMs);
  if (!getGame(game.gameId)) return null;
  await updateGame(game.gameId, groupId, current => { current.state.phase = MemoryCupsPhase.HIDING_GHOST; return current; });
  if (messageId) { try { await ctx.sendMessage(groupId, { text: renderer.renderRound({ level, cupCount: difficulty.cupCount }), edit: messageId }); } catch {} }
  await sleep(MemoryCupsDifficultyConfig.hideMs);
  if (!getGame(game.gameId)) return null;
  await updateGame(game.gameId, groupId, current => { current.state.phase = MemoryCupsPhase.SHUFFLING; return current; });
  const animation = new MemoryCupsAnimationEngine({ sendMessage: ctx.sendMessage, jid: groupId, messageKey: messageId, level, cupCount: difficulty.cupCount, renderer, trajectory, difficulty });
  animations.set(game.gameId, animation);
  let result;
  try { result = await animation.play(); } finally { animations.delete(game.gameId); }
  const active = getGame(game.gameId);
  if (!active || active.status !== 'ACTIVE' || result.cancelled) return active;
  await updateGame(game.gameId, groupId, current => { current.state.phase = MemoryCupsPhase.WAITING_ANSWER; current.state.frameIndex = trajectory.frames.length - 1; current.state.expiresAt = Date.now() + MemoryCupsDifficultyConfig.answerTimeout; return current; });
  if (messageId) { try { await ctx.sendMessage(groupId, { text: renderer.renderAnswerPrompt({ level, cupCount: difficulty.cupCount }), edit: messageId }); } catch {} }
  return getGame(game.gameId);
}

export async function timeoutGame({ ctx, gameId }) {
  const groupId = ctx.from || 'private';
  const game = getGame(gameId);
  if (!game || game.status !== 'ACTIVE') return null;
  return exclusive(keyFor(groupId, game.creatorId), async () => {
    animations.get(gameId)?.cancel();
    animations.delete(gameId);
    const current = getGame(gameId);
    if (!current || current.status !== 'ACTIVE') return null;
    const phase = current.state?.phase;
    if (![MemoryCupsPhase.WAITING_ANSWER, MemoryCupsPhase.SHUFFLING, MemoryCupsPhase.HIDING_GHOST, MemoryCupsPhase.SHOWING_GHOST].includes(phase)) return null;
    const level = Number(current.state.level || 1);
    const stats = statView(groupId, current.creatorId);
    const result = { win: false, userId: current.creatorId, timeout: true, level, correctPosition: Number(current.state.ghostCurrentPosition) + 1, score: 0, xp: 0, bestLevel: Math.max(stats.highestLevel, level), streak: 0 };
    try { await recordResult({ groupId, userId: current.creatorId, gameType: GAME_TYPE, result: 'timeout', win: false, loss: true, score: 0, xp: 0 }); } catch {}
    const finishedGame = await finishGame(gameId, groupId, { status: 'EXPIRED', winnerId: null, reason: 'answer_timeout', result });
    if(finishedGame) await emit('GAME_SCORE_FINALIZED',{eventId:`MEMORY-CUPS:${gameId}:${current.creatorId}`,gameId:'memoriacopos',gameSessionId:gameId,groupId,userId:current.creatorId,points:0,won:false,stats:{level,successfulRounds:0,failedRounds:1},groupName:ctx.groupName||'Grupo',occurredAt:Date.now()});
    gameSessions.end(keyFor(groupId, current.creatorId), GAME_TYPE);
    await audit('MEMORY_CUPS_TIMEOUT', ctx, { gameId, level, result });
    if (current.state?.messageId) {
      try { await ctx.sendMessage(groupId, { text: renderer.renderRound({ level, cupCount: current.state.cupCount, ghostPosition: current.state.ghostCurrentPosition, showGhost: true, prompt: renderer.renderResult({ level, cupCount: current.state.cupCount, correctPosition: current.state.ghostCurrentPosition + 1, score: 0, bestLevel: stats.highestLevel, streak: 0, timeout: true }) }), edit: current.state.messageId }); } catch {}
    }
    return result;
  });
}

export async function cancelForContext(ctx) {
  const groupId = ctx.from || 'private';
  const userId = ctx.sender;
  const game = findPlayerGame(groupId, userId);
  if (!game) return { cancelled: false };
  return exclusive(keyFor(groupId, userId), async () => {
    const current = getGame(game.gameId);
    if (!current || current.status !== 'ACTIVE') return { cancelled: false };
    await finishGame(current.gameId, groupId, { status: 'CANCELLED', winnerId: null, reason: 'player_cancelled', result: { level: current.state?.level || 1 } });
    gameSessions.end(keyFor(groupId, userId), GAME_TYPE);
    await audit('MEMORY_CUPS_CANCELLED', ctx, { gameId: current.gameId, level: current.state?.level || 1 });
    return { cancelled: true, gameId: current.gameId };
  });
}

export function getActive(ctx) { return findPlayerGame(ctx.from || 'private', ctx.sender); }

export default { start, handleAnswer, timeoutGame, cancelForContext, getActive };
