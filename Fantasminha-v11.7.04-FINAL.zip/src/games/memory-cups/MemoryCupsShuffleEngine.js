import crypto from 'node:crypto';
import { getDifficulty, MemoryCupsDifficultyConfig } from './MemoryCupsDifficultyConfig.js';

const randomInt = (max) => crypto.randomInt(0, Math.max(1, max));
const sign = (v) => (v < 0 ? -1 : 1);

function chooseDirection(current, cupCount, previousDirection, difficulty, step) {
  const left = current > 0;
  const right = current < cupCount - 1;
  let direction;
  if (!left) direction = 1;
  else if (!right) direction = -1;
  else if (previousDirection && Math.random() > difficulty.reversalFrequency) direction = previousDirection;
  else direction = Math.random() < 0.5 ? -1 : 1;

  // Em níveis maiores, permitir saltos curtos controlados, sem teletransporte.
  if (difficulty.trajectoryComplexity > 0.65 && step % 5 === 0 && cupCount >= 5) {
    const maxJump = Math.min(2, Math.floor(cupCount / 3));
    const jump = 1 + randomInt(maxJump);
    if (direction < 0 && current - jump >= 0) return -jump;
    if (direction > 0 && current + jump < cupCount) return jump;
  }
  return direction;
}

function makeOffsets(cupCount, from, to, progress) {
  const offsets = Array(cupCount).fill(0);
  const delta = to - from;
  const amount = progress < 0.5 ? Math.max(0, Math.round(progress * 4)) : Math.max(0, Math.round((1 - progress) * 4));
  if (from >= 0 && from < cupCount) offsets[from] = sign(delta) * amount;
  if (to >= 0 && to < cupCount) offsets[to] = -sign(delta) * amount;
  return offsets;
}

export function generateTrajectory({ cupCount, level = 1, initialPosition } = {}) {
  const difficulty = getDifficulty(level);
  const count = Math.max(3, Math.min(MemoryCupsDifficultyConfig.maxCups, Number(cupCount) || difficulty.cupCount));
  const initial = Math.max(0, Math.min(count - 1, Number.isInteger(initialPosition) ? initialPosition : randomInt(count)));
  const tokenAtSlot = Array.from({ length: count }, (_, i) => i);
  let ghostToken = initial;
  let ghostSlot = initial;
  let previousDirection = 0;
  const frames = [];

  const pushFrame = (offsets = [], phase = 'MOVE') => {
    if (frames.length >= MemoryCupsDifficultyConfig.maxFramesPerRound) return false;
    frames.push({
      index: frames.length,
      ghostPosition: ghostSlot,
      offsets: [...offsets],
      phase
    });
    return true;
  };

  pushFrame(Array(count).fill(0), 'HOLD');

  for (let step = 0; step < difficulty.movementCount && frames.length < MemoryCupsDifficultyConfig.maxFramesPerRound; step += 1) {
    const rawDirection = chooseDirection(ghostSlot, count, previousDirection, difficulty, step);
    const distance = Math.abs(rawDirection);
    const direction = sign(rawDirection);
    const destination = Math.max(0, Math.min(count - 1, ghostSlot + direction * distance));
    if (destination === ghostSlot) continue;

    // Troca adjacente ou salto curto. A verdade muda somente no commit do movimento.
    const from = ghostSlot;
    const to = destination;
    const toToken = tokenAtSlot[to];
    tokenAtSlot[to] = ghostToken;
    tokenAtSlot[from] = toToken;
    ghostSlot = to;
    previousDirection = direction;

    const micro = difficulty.microFrames + (distance > 1 ? 2 : 0);
    for (let m = 1; m <= micro && frames.length < MemoryCupsDifficultyConfig.maxFramesPerRound; m += 1) {
      const progress = m / micro;
      pushFrame(makeOffsets(count, from, to, progress), 'MOVE');
    }
    pushFrame(Array(count).fill(0), 'SETTLE');
  }

  // Nunca terminar com um frame de movimento: o último estado visual é estável.
  if (!frames.length || frames.at(-1).phase !== 'SETTLE') pushFrame(Array(count).fill(0), 'SETTLE');
  const finalPosition = ghostSlot;
  return {
    seed: crypto.randomBytes(8).toString('hex'),
    cupCount: count,
    initialPosition: initial,
    finalPosition,
    frames,
    difficulty
  };
}

export function validateTrajectory(trajectory) {
  if (!trajectory || !Array.isArray(trajectory.frames) || !trajectory.frames.length) return { ok: false, errors: ['frames'] };
  const errors = [];
  const count = Number(trajectory.cupCount);
  if (!Number.isInteger(count) || count < 3) errors.push('cupCount');
  if (!Number.isInteger(trajectory.initialPosition) || trajectory.initialPosition < 0 || trajectory.initialPosition >= count) errors.push('initialPosition');
  if (!Number.isInteger(trajectory.finalPosition) || trajectory.finalPosition < 0 || trajectory.finalPosition >= count) errors.push('finalPosition');
  for (const [i, frame] of trajectory.frames.entries()) {
    if (!Number.isInteger(frame.ghostPosition) || frame.ghostPosition < 0 || frame.ghostPosition >= count) errors.push(`frame:${i}:ghostPosition`);
    if (!Array.isArray(frame.offsets) || frame.offsets.length !== count) errors.push(`frame:${i}:offsets`);
  }
  const last = trajectory.frames.at(-1);
  if (last?.ghostPosition !== trajectory.finalPosition) errors.push('finalPositionMismatch');
  return { ok: errors.length === 0, errors };
}

export default { generateTrajectory, validateTrajectory };
