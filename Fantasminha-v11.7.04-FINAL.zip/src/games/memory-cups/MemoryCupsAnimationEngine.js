import { MessageEditController } from './MemoryCupsMessageEditController.js';
import { MemoryCupsDifficultyConfig } from './MemoryCupsDifficultyConfig.js';

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));

export class MemoryCupsAnimationEngine {
  constructor({ sendMessage, jid, messageKey, level, cupCount, renderer, trajectory, difficulty } = {}) {
    this.trajectory = trajectory;
    this.level = level;
    this.cupCount = cupCount;
    this.renderer = renderer;
    this.difficulty = difficulty;
    this.controller = new MessageEditController({
      sendMessage,
      jid,
      messageKey,
      minInterval: difficulty?.frameInterval || MemoryCupsDifficultyConfig.minFrameInterval,
      maxRetries: MemoryCupsDifficultyConfig.editRetries,
      maxDuration: MemoryCupsDifficultyConfig.maxAnimationDuration
    });
    this.frameIndex = 0;
    this.cancelled = false;
    this.failedEdits = 0;
  }

  cancel() {
    this.cancelled = true;
    this.controller.cancel();
  }

  async play({ onFrame } = {}) {
    const frames = Array.isArray(this.trajectory?.frames) ? this.trajectory.frames : [];
    const startedAt = Date.now();
    for (let i = 0; i < frames.length; i += 1) {
      if (this.cancelled) return { ok: false, cancelled: true, frameIndex: this.frameIndex, failedEdits: this.failedEdits };
      if (Date.now() - startedAt > MemoryCupsDifficultyConfig.maxAnimationDuration) break;
      const frame = frames[i];
      this.frameIndex = i;
      const text = this.renderer.renderRound({
        level: this.level,
        cupCount: this.cupCount,
        ghostPosition: null,
        showGhost: false,
        offsets: frame.offsets
      });
      const result = await this.controller.enqueue(text);
      if (!result?.ok && !result?.skipped) this.failedEdits += 1;
      try { await onFrame?.({ frame, frameIndex: i, editResult: result }); } catch {}
      if (i < frames.length - 1 && !this.cancelled) await sleep(Math.max(0, Number(this.difficulty?.frameInterval || 115) * 0.12));
    }
    await this.controller.flush();
    return { ok: !this.cancelled, cancelled: this.cancelled, frameIndex: this.frameIndex, failedEdits: this.failedEdits };
  }
}

export default { MemoryCupsAnimationEngine };
