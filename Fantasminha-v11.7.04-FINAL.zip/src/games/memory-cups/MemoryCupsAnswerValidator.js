export function normalizePosition(value, cupCount) {
  const raw = String(value ?? '').trim();
  if (!/^\d+$/.test(raw)) return { ok: false, reason: 'not_number' };
  const position = Number(raw);
  if (!Number.isInteger(position) || position < 1 || position > Number(cupCount)) return { ok: false, reason: 'out_of_range' };
  return { ok: true, position };
}

export function validateAnswer(selectedPosition, ghostPositionZeroBased, cupCount) {
  const normalized = normalizePosition(selectedPosition, cupCount);
  if (!normalized.ok) return { ok: false, valid: false, reason: normalized.reason };
  return { ok: true, valid: normalized.position - 1 === Number(ghostPositionZeroBased), selectedPosition: normalized.position };
}

export default { normalizePosition, validateAnswer };
