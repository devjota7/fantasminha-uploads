import config from '../../core/config.js';
export class QuizImageProvider {
  async generate({prompt}){
    const provider=String(process.env.QUIZ_IMAGE_PROVIDER||'gemini').toLowerCase();
    if(provider==='gemini'||provider==='auto') return this.gemini(prompt);
    throw new Error(`Provider de imagem do Quiz não suportado: ${provider}`);
  }
  async gemini(prompt){
    const key=config.secrets.gemini; if(!key)throw new Error('GEMINI_API_KEY não configurada para o Quiz.');
    const model=process.env.QUIZ_IMAGE_MODEL||'gemini-2.5-flash-image';
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const axios=(await import('axios')).default;
    const res=await axios.post(url,{contents:[{parts:[{text:prompt}]}],generationConfig:{responseModalities:['TEXT','IMAGE'] }},{timeout:Number(process.env.QUIZ_IMAGE_TIMEOUT_MS||90000),maxContentLength:20*1024*1024,maxBodyLength:20*1024*1024});
    const parts=res.data?.candidates?.flatMap(c=>c.content?.parts||[])||[];
    const part=parts.find(p=>p.inlineData?.data);
    if(!part)throw new Error('O provider de imagem não retornou conteúdo visual.');
    return {buffer:Buffer.from(part.inlineData.data,'base64'),mimeType:part.inlineData.mimeType||'image/png',provider:'gemini'};
  }
}
export default QuizImageProvider;
