const LEVELS = ['easy','medium','hard','insane'];
const ALIASES = new Map([
  ['facil','easy'],['fácil','easy'],['easy','easy'],
  ['medio','medium'],['médio','medium'],['medium','medium'],
  ['dificil','hard'],['difícil','hard'],['hard','hard'],
  ['insano','insane'],['insane','insane'],['expert','insane']
]);
export function normalizeDifficulty(v) { return ALIASES.get(String(v ?? '').trim().toLowerCase()) || null; }
export function selectDifficulty(requested = null, random = Math.random) {
  const n = normalizeDifficulty(requested); if (n) return n;
  return LEVELS[Math.floor(random() * LEVELS.length)];
}
export function difficultyLabel(d) { return ({easy:'🟢 Fácil',medium:'🟡 Médio',hard:'🔴 Difícil',insane:'🟣 Insano'})[d] || d; }
export function difficultyMultiplier(d) { return ({easy:1,medium:1,hard:1,insane:1})[d] || 1; }
export default { normalizeDifficulty, selectDifficulty, difficultyLabel, difficultyMultiplier, LEVELS };
