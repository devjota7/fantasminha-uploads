import { categoryLabel } from './QuizCategoryEngine.js';
import { difficultyLabel } from './QuizDifficultyEngine.js';
export function maskQuestion(question){return String(question).replace(/\S/g,'_');}
export function renderQuestion(session){return [
  '🧠 *FANTASMINHA QUIZ*','',
  `${categoryLabel(session.category)}`,
  `⭐ Dificuldade: *${difficultyLabel(session.difficulty)}*`,'',
  `❓ ${session.question}`,'',
  ...session.options.map((o,i)=>`${i+1}️⃣ ${o.text}`),'',
  '⏳ Você tem *45 segundos* para responder!','',
  '👻 Boa sorte, fantasminha!'
].join('\n');}
export function renderPreparing(){return '✍️ *O Fantasminha está preparando o Quiz...*\n\n👻 Só um segundo! 🧠✨';}
export function renderBusy(){return '🧠 *QUIZ EM ANDAMENTO!*\n\nJá existe uma rodada acontecendo neste grupo.\n⏳ Aguarde ela terminar para jogar novamente!';}
export function renderError(){return '👻 *O Fantasminha tropeçou no Quiz!*\n\nNão consegui preparar esta rodada.\nTentem novamente com `×quiz`. 🧠✨';}
export function renderResult(result,mention=(id)=>`@${String(id).split('@')[0]}`){
  const winners=result.correctAnswers.sort((a,b)=>b.points-a.points||a.responseTimeMs-b.responseTimeMs);
  const podium=winners.map((x,i)=>`${['🥇','🥈','🥉'][i]||'👤'} ${mention(x.userId)} — +${x.points} pontos`).join('\n')||'Nenhum acerto.';
  return ['⏰ *TEMPO ESGOTADO!*','', '🧠 *RESULTADO DO QUIZ*','',`🎯 Resposta correta: *${result.correctAnswer}*`,`👥 Respostas: ${result.responses}`,`✅ Acertos: ${result.correctCount}`,`❌ Erros: ${result.wrongCount}`,'', '🏆 *QUEM ACERTOU:*',podium,'','👻 Parabéns aos fantasminhas que acertaram!'].join('\n');
}
export function renderRecoveryError(){return '👻 *O Quiz anterior foi encerrado.*\n\nA sessão não pôde ser recuperada com segurança. Tentem novamente com `×quiz`. 🧠';}
export default {renderQuestion,renderPreparing,renderBusy,renderError,renderResult,maskQuestion};
