import { readCollection, updateCollection } from '../../database/store.js';
const C='quiz_statistics';
const emptyPlayer=(userId,name='')=>({userId,name,totalQuizzes:0,totalResponses:0,correctAnswers:0,wrongAnswers:0,totalPoints:0,highestPoints:0,totalResponseTimeMs:0,correctResponseTimeMs:0,correctResponseCount:0,fastestCorrectResponseMs:null,currentStreak:0,bestStreak:0,lastPlayedAt:0,difficulties:{},categories:{}});
function bucket(){return {quizzes:0,responses:0,correct:0,wrong:0,points:0,responseTimeMs:0,correctResponseTimeMs:0,correctResponseCount:0};}
function applyPlayer(p,session,responses){
  p.totalQuizzes++; p.lastPlayedAt=Date.now();
  const allCorrect=responses.filter(x=>x.isCorrect); const allWrong=responses.filter(x=>!x.isCorrect);
  p.totalResponses+=responses.length; p.correctAnswers+=allCorrect.length; p.wrongAnswers+=allWrong.length;
  p.totalPoints+=responses.reduce((n,x)=>n+x.points,0); p.highestPoints=Math.max(p.highestPoints,...responses.map(x=>x.points),0);
  p.totalResponseTimeMs+=responses.reduce((n,x)=>n+x.responseTimeMs,0); p.correctResponseTimeMs+=allCorrect.reduce((n,x)=>n+x.responseTimeMs,0); p.correctResponseCount+=allCorrect.length;
  if(allCorrect.length){const fastest=Math.min(...allCorrect.map(x=>x.responseTimeMs));p.fastestCorrectResponseMs=p.fastestCorrectResponseMs==null?fastest:Math.min(p.fastestCorrectResponseMs,fastest);p.currentStreak++;p.bestStreak=Math.max(p.bestStreak,p.currentStreak);}else p.currentStreak=0;
  const d=p.difficulties[session.difficulty]??={...bucket()}; d.quizzes++;d.responses+=responses.length;d.correct+=allCorrect.length;d.wrong+=allWrong.length;d.points+=responses.reduce((n,x)=>n+x.points,0);d.responseTimeMs+=responses.reduce((n,x)=>n+x.responseTimeMs,0);d.correctResponseTimeMs+=allCorrect.reduce((n,x)=>n+x.responseTimeMs,0);d.correctResponseCount+=allCorrect.length;
  const c=p.categories[session.category]??={...bucket()}; c.quizzes++;c.responses+=responses.length;c.correct+=allCorrect.length;c.wrong+=allWrong.length;c.points+=responses.reduce((n,x)=>n+x.points,0);c.responseTimeMs+=responses.reduce((n,x)=>n+x.responseTimeMs,0);c.correctResponseTimeMs+=allCorrect.reduce((n,x)=>n+x.responseTimeMs,0);c.correctResponseCount+=allCorrect.length;
}
export async function recordQuizResult({session,responses,groupName='Grupo'}){
  return updateCollection(C,db=>{
    db.globalPlayers??={};db.groups??={};db.finalized??={};
    if(db.finalized[session.quizId]) return db;
    db.finalized[session.quizId]=Date.now();
    const group=db.groups[session.groupId]??={groupId:session.groupId,name:groupName,totalQuizzes:0,totalResponses:0,totalCorrect:0,totalWrong:0,totalPoints:0,uniquePlayers:0,lastQuizAt:0,players:{}};
    group.name=groupName||group.name||'Grupo';group.totalQuizzes++;group.totalResponses+=responses.length;group.totalCorrect+=responses.filter(x=>x.isCorrect).length;group.totalWrong+=responses.filter(x=>!x.isCorrect).length;group.totalPoints+=responses.reduce((n,x)=>n+x.points,0);group.lastQuizAt=Date.now();
    for(const r of responses){
      const gp=db.globalPlayers[r.userId]??=emptyPlayer(r.userId,r.userName);gp.name=r.userName||gp.name;applyPlayer(gp,session,[r]);
      const pl=group.players[r.userId]??=emptyPlayer(r.userId,r.userName);pl.name=r.userName||pl.name;applyPlayer(pl,session,[r]);
    }
    group.uniquePlayers=Object.keys(group.players).length;
    return db;
  },{globalPlayers:{},groups:{},finalized:{}}).then(db=>({applied:!!db.finalized?.[session.quizId],stats:db}));
}
export function getPlayerGlobal(userId){return readCollection(C,{globalPlayers:{}}).globalPlayers?.[userId]||null;}
export function getPlayerGroup(groupId,userId){return readCollection(C,{groups:{}}).groups?.[groupId]?.players?.[userId]||null;}
export function getGroup(groupId){return readCollection(C,{groups:{}}).groups?.[groupId]||null;}
export function globalPlayers(limit=10000){return Object.values(readCollection(C,{globalPlayers:{}}).globalPlayers||{}).sort((a,b)=>b.totalPoints-a.totalPoints||b.correctAnswers-a.correctAnswers||((a.fastestCorrectResponseMs??Infinity)-(b.fastestCorrectResponseMs??Infinity))).slice(0,limit);}
export function groupPlayers(groupId,limit=10000){return Object.values(readCollection(C,{groups:{}}).groups?.[groupId]?.players||{}).sort((a,b)=>b.totalPoints-a.totalPoints||b.correctAnswers-a.correctAnswers||((a.fastestCorrectResponseMs??Infinity)-(b.fastestCorrectResponseMs??Infinity))).slice(0,limit);}
export function groups(limit=100){return Object.values(readCollection(C,{groups:{}}).groups||{}).sort((a,b)=>b.totalPoints-a.totalPoints||b.totalQuizzes-a.totalQuizzes).slice(0,limit);}
export function totalGroupCount(){return Object.keys(readCollection(C,{groups:{}}).groups||{}).length;}
export function totalGlobalPlayerCount(){return Object.keys(readCollection(C,{globalPlayers:{}}).globalPlayers||{}).length;}
export function globalTotals(){const gs=Object.values(readCollection(C,{groups:{}}).groups||{});return {groups:gs.length,quizzes:gs.reduce((n,g)=>n+Number(g.totalQuizzes||0),0),responses:gs.reduce((n,g)=>n+Number(g.totalResponses||0),0),points:gs.reduce((n,g)=>n+Number(g.totalPoints||0),0),players:Object.keys(readCollection(C,{globalPlayers:{}}).globalPlayers||{}).length};}
export function rankGlobal(userId){const all=globalPlayers();return Math.max(0,all.findIndex(x=>x.userId===userId)+1);}
export function rankGroup(groupId,userId){const all=groupPlayers(groupId);return Math.max(0,all.findIndex(x=>x.userId===userId)+1);}
export default {recordQuizResult,getPlayerGlobal,getPlayerGroup,getGroup,globalPlayers,groupPlayers,groups,totalGroupCount,totalGlobalPlayerCount,globalTotals,rankGlobal,rankGroup};
