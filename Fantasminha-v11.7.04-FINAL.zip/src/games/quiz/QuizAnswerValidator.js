const norm=s=>String(s??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,' ').replace(/\s+/g,' ').trim();
export function normalizeAnswer(s){return norm(s);}
export function validateAnswer(session,text){
  const raw=String(text??'').trim(); if(!raw)return {accepted:false,reason:'empty'};
  if(!session?.options?.length)return {accepted:false,reason:'invalid-session'};
  let option=null;
  if(/^\d+$/.test(raw)){const i=Number(raw)-1;if(i>=0&&i<session.options.length) option=session.options[i]; else return {accepted:false,reason:'invalid-option'};}
  const value=norm(option?.text||raw);
  const correct=session.options.find(o=>o.id===session.correctOptionId);
  const aliases=new Set([norm(correct?.text),...(session.aliases||[]).map(norm)].filter(Boolean));
  const isCorrect=aliases.has(value);
  return {accepted:true,isCorrect,optionId:option?.id||null,normalized:value};
}
export function looksLikeQuizAnswer(session,text){const raw=String(text??'').trim();if(/^\d+$/.test(raw))return true;const n=norm(raw);if(!n||n.length>80)return false;const correct=session?.options?.find(o=>o.id===session.correctOptionId);const candidates=[...(session?.options||[]).map(o=>o.text),...(session?.aliases||[])];return candidates.some(x=>norm(x)===n);}
export default {normalizeAnswer,validateAnswer,looksLikeQuizAnswer};
