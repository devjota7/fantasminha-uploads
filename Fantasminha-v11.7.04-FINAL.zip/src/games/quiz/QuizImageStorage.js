import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
const DIR=path.join(ROOT,'data','quiz','temp');
export class QuizImageStorage {
  async save(roundId,buffer,mimeType='image/png'){
    await fs.mkdir(DIR,{recursive:true});
    const ext=mimeType.includes('jpeg')?'jpg':mimeType.includes('webp')?'webp':'png';
    const safe=String(roundId).replace(/[^A-Za-z0-9_-]/g,'');
    const file=`round-${safe}-${crypto.randomBytes(4).toString('hex')}.${ext}`;
    const filePath=path.join(DIR,file); await fs.writeFile(filePath,buffer);
    return {reference:`temp:${file}`,path:filePath,mimeType,bytes:buffer.length};
  }
  async remove(reference){if(!reference)return;const file=String(reference).replace(/^temp:/,'');if(file.includes('/')||file.includes('\\')||!file.startsWith('round-'))return;await fs.rm(path.join(DIR,file),{force:true}).catch(()=>{});}
  async cleanupOrphans(activeReferences=new Set(),maxAgeMs=2*60*60*1000){await fs.mkdir(DIR,{recursive:true});const now=Date.now();let removed=0;for(const file of await fs.readdir(DIR)){if(!file.startsWith('round-'))continue;const p=path.join(DIR,file);const st=await fs.stat(p).catch(()=>null);if(!st)continue;if(now-st.mtimeMs>maxAgeMs&&!activeReferences.has(`temp:${file}`)){await fs.rm(p,{force:true}).catch(()=>{});removed++;}}return removed;}
}
export default QuizImageStorage;
