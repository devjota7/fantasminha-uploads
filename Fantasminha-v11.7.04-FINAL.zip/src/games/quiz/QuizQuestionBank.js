import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeCategory } from './QuizCategoryEngine.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const LEGACY = path.join(ROOT, 'dados', 'src', 'funcs', 'json', 'quiz.json');
const EXTRA = [
  ['tecnologia','Qual linguagem é executada nativamente pelo Node.js?',['JavaScript','Python','HTML','CSS'],0],
  ['tecnologia','Qual sistema de controle de versão é amplamente usado em projetos de código?',['Git','FTP','SMTP','DNS'],0],
  ['games','Qual jogo popular usa blocos para construção e exploração?',['Minecraft','Tetris','Pong','Pac-Man'],0],
  ['games','Among Us é principalmente um jogo de...',['corrida','dedução social','futebol','xadrez'],1],
  ['anime','Qual personagem é conhecido por usar a técnica Rasengan?',['Naruto','Luffy','Gon','Ichigo'],0],
  ['filmes','Qual personagem usa uma capa e é associado a Gotham?',['Batman','Hulk','Thor','Flash'],0],
  ['musica','Qual instrumento normalmente possui seis cordas?',['Piano','Violão','Flauta','Trompete'],1],
  ['ciencia','Qual planeta é conhecido como Planeta Vermelho?',['Marte','Vênus','Júpiter','Mercúrio'],0],
  ['geografia','Qual é o maior oceano do mundo?',['Atlântico','Índico','Pacífico','Ártico'],2],
  ['historia','Em que país ficam as pirâmides de Gizé?',['Egito','Peru','México','Grécia'],0],
  ['esportes','Quantos jogadores um time de futebol tem em campo no início?',['9','10','11','12'],2]
];
const CATEGORY_MAP = {ciencia:'ciencia',historia:'historia',geografia:'geografia',esportes:'esportes',anime:'anime',games:'games',geral:'geral'};
let cache = null;
const norm = s => String(s??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const hashDifficulty = (text, i) => {
  const n = [...String(text)].reduce((a,c)=>((a*31+c.charCodeAt(0))>>>0), i+17);
  return ['easy','medium','hard','insane'][n % 4];
};
function makeOptions(answer, pool, index) {
  const unique = [];
  for (const x of [answer, ...pool.sort((a,b)=>norm(a).localeCompare(norm(b)))]) if (x && !unique.some(y=>norm(y)===norm(x))) unique.push(x);
  const distractors = unique.filter(x=>norm(x)!==norm(answer)).slice(0,3);
  if (distractors.length < 3) return null;
  const options = [answer, ...distractors];
  // embaralhamento determinístico por pergunta para manter testes reprodutíveis.
  for (let i=options.length-1;i>0;i--) { const j=(index*17+i*13)% (i+1); [options[i],options[j]]=[options[j],options[i]]; }
  return options.map((text,i)=>({id:`opt_${String.fromCharCode(97+i)}`,text}));
}
function build() {
  const out=[]; let index=0;
  let legacy={}; try { legacy=JSON.parse(fs.readFileSync(LEGACY,'utf8')); } catch {}
  for (const [rawCat, items] of Object.entries(legacy||{})) {
    const category=CATEGORY_MAP[rawCat] || rawCat;
    const displays=(items||[]).map(x=>x?.d).filter(Boolean);
    for (const item of items||[]) {
      if (!item?.p || !Array.isArray(item.r) || !item.r.length) continue;
      const answer=String(item.d||item.r[0]).trim();
      const options=makeOptions(answer,displays,index++); if(!options) continue;
      const correct=options.find(o=>norm(o.text)===norm(answer));
      out.push({questionId:`legacy_${out.length+1}`,question:String(item.p),category,difficulty:hashDifficulty(item.p,out.length),options,correctOptionId:correct.id,aliases:[...new Set((item.r||[]).map(String).concat(answer))],source:'legacy'});
    }
  }
  for (const [category,question,options,correctIndex] of EXTRA) {
    const opts=options.map((text,i)=>({id:`opt_${String.fromCharCode(97+i)}`,text}));
    out.push({questionId:`extra_${out.length+1}`,question,category,difficulty:hashDifficulty(question,out.length),options:opts,correctOptionId:opts[correctIndex].id,aliases:[opts[correctIndex].text],source:'curated'});
  }
  return out;
}
export function loadQuestions() { if(!cache) cache=build(); return cache.map(x=>structuredClone(x)); }
export function clearQuestionCache(){cache=null;}
export function categoriesWithQuestions(){return [...new Set(loadQuestions().map(q=>q.category))];}
export default {loadQuestions,clearQuestionCache,categoriesWithQuestions};
