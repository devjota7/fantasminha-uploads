import { groupPlayers, globalPlayers, groups, getPlayerGlobal, getPlayerGroup, rankGlobal, rankGroup, totalGroupCount, totalGlobalPlayerCount, globalTotals } from './QuizStatisticsService.js';
const pct=(n,d)=>d?((n/d)*100).toFixed(1).replace('.',','):'0,0';
export function local(groupId,limit=10){return groupPlayers(groupId,limit);}
export function globalGroups(limit=5){return groups(limit);}
export function globalPlayer(userId){return getPlayerGlobal(userId);}
export function playerGroup(groupId,userId){return getPlayerGroup(groupId,userId);}
export function playerRanks(groupId,userId){return {global:rankGlobal(userId),group:rankGroup(groupId,userId)};}
export {pct,totalGroupCount,totalGlobalPlayerCount,globalTotals};
export default {local,globalGroups,globalPlayer,playerGroup,playerRanks,pct,totalGroupCount,totalGlobalPlayerCount,globalTotals,globalPlayers};
