const CATEGORIES = Object.freeze({
  geral:{label:'🧠 Conhecimentos Gerais',aliases:['geral','conhecimentos gerais']},
  ciencia:{label:'🔬 Ciência',aliases:['ciencia','ciência','science']},
  animais:{label:'🐾 Animais',aliases:['animais','animal']},
  historia:{label:'📜 História',aliases:['historia','história','history']},
  geografia:{label:'🌎 Geografia',aliases:['geografia','geography']},
  esportes:{label:'⚽ Esportes',aliases:['esportes','sports']},
  anime:{label:'🎭 Anime',aliases:['anime']},
  games:{label:'🎮 Jogos',aliases:['games','jogos','game']},
  tecnologia:{label:'💻 Tecnologia',aliases:['tecnologia','tech','technology']},
  musica:{label:'🎵 Música',aliases:['musica','música','music']},
  filmes:{label:'🎬 Filmes e Séries',aliases:['filmes','filme','series','séries','movies']},
  curiosidades:{label:'🎲 Curiosidades',aliases:['curiosidades','curiosidade','trivia']},
  misterio:{label:'🔮 Mistério',aliases:['misterio','mistério']}
});
const aliasMap = new Map(Object.entries(CATEGORIES).flatMap(([k,v])=>v.aliases.map(a=>[a,k])));
export function normalizeCategory(v) { return aliasMap.get(String(v ?? '').trim().toLowerCase()) || null; }
export function selectCategory(requested = null, available = Object.keys(CATEGORIES), random = Math.random) {
  const n = normalizeCategory(requested); if (n && available.includes(n)) return n;
  const pool = available.filter(k=>CATEGORIES[k]);
  return pool[Math.floor(random()*pool.length)] || 'geral';
}
export function categoryLabel(k) { return CATEGORIES[k]?.label || k; }
export function listCategories() { return Object.entries(CATEGORIES).map(([id,v])=>({id,label:v.label})); }
export default { CATEGORIES, normalizeCategory, selectCategory, categoryLabel, listCategories };
