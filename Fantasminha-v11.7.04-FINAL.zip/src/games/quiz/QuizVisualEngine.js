import path from 'node:path';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { QuizImageProvider } from './QuizImageProvider.js';
import { QuizImageStorage } from './QuizImageStorage.js';
const ROOT=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../..');
export function buildVisualPrompt(q){
  return [
    'Create a contextual illustration for a WhatsApp multiple-choice quiz.',
    'The visual must represent the SUBJECT and CONTEXT of the question without revealing the correct answer.',
    `Question topic: ${q.question}`,
    `Category: ${q.category}. Difficulty: ${q.difficulty}.`,
    'Style: clean friendly educational illustration, colorful but simple, suitable for a group quiz.',
    'Do not write any words, letters, numbers, labels, captions, watermarks, signs, titles, UI or answer text in the image.',
    'Do not directly identify which option is correct. Avoid visual elements that explicitly label the answer.',
    'No logos, no screenshots, no interface. Keep the scene coherent with the question.'
  ].join('\n');
}
export async function generateForRound(question,roundId){
  const prompt=buildVisualPrompt(question);
  const provider=new QuizImageProvider();
  const generated=await provider.generate({prompt,roundId});
  if(!generated?.buffer)throw new Error('A IA não retornou uma imagem válida.');
  const storage=new QuizImageStorage();
  const ref=await storage.save(roundId,generated.buffer,generated.mimeType||'image/png');
  return {reference:ref.reference,path:ref.path,mimeType:ref.mimeType,bytes:ref.bytes,prompt,provider:generated.provider};
}
export default {buildVisualPrompt,generateForRound};
