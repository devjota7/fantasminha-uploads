import { QuizImageStorage } from './QuizImageStorage.js';
const storage=new QuizImageStorage();
export async function cleanupSession(session){await storage.remove(session?.imageReference);return true;}
export async function cleanupOrphans(activeSessions=[]){return storage.cleanupOrphans(new Set(activeSessions.map(s=>s.imageReference).filter(Boolean)),Number(process.env.QUIZ_IMAGE_ORPHAN_MAX_AGE_MS||2*60*60*1000));}
export default {cleanupSession,cleanupOrphans};
