import { readCollection, updateCollection } from '../../database/store.js';
const C='quiz_question_history';
export function recent(groupId,limit=8){const d=readCollection(C,{items:[]});return (d.items||[]).filter(x=>x.groupId===groupId).sort((a,b)=>b.usedAt-a.usedAt).slice(0,limit);}
export async function record({groupId,questionId,category,difficulty,quizId}){return updateCollection(C,d=>{d.items??=[];d.items.push({id:`QH-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,groupId,questionId,category,difficulty,quizId,usedAt:Date.now()});if(d.items.length>5000)d.items=d.items.slice(-5000);return d;},{items:[]});}
export function chooseFromHistory(pool,groupId,random=Math.random,cooldown=8){const recentIds=new Set(recent(groupId,cooldown).map(x=>x.questionId));const fresh=pool.filter(x=>!recentIds.has(x.questionId));if(fresh.length)return fresh[Math.floor(random()*fresh.length)];return [...pool].sort((a,b)=>{const ah=recent(groupId,5000).find(x=>x.questionId===a.questionId)?.usedAt||0;const bh=recent(groupId,5000).find(x=>x.questionId===b.questionId)?.usedAt||0;return ah-bh})[0]||pool[Math.floor(random()*pool.length)];}
export default {recent,record,chooseFromHistory};
