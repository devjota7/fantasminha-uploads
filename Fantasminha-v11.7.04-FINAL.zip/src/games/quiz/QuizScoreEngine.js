/** Pontuação oficial do Quiz: somente inteiros, 1..100 para acertos. */
export const QUIZ_MAX_TIME_MS = 45_000;
export function calculateQuizPoints(responseTimeMs, maxTimeMs = QUIZ_MAX_TIME_MS, isCorrect = true) {
  if (!isCorrect) return 0;
  const t = Math.max(0, Number(responseTimeMs) || 0);
  const max = Math.max(1, Number(maxTimeMs) || QUIZ_MAX_TIME_MS);
  if (t <= 0) return 100;
  if (t >= max) return 1;
  return Math.max(1, Math.min(100, Math.floor(100 - (99 * t / max))));
}
export default { calculateQuizPoints, QUIZ_MAX_TIME_MS };
