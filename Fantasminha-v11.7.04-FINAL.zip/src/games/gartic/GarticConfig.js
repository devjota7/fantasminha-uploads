import path from 'node:path';
import config from '../../core/config.js';

export const GarticConfig = Object.freeze({
  gameType: 'gartic',
  roundTimeoutMs: Math.max(10_000, Number(process.env.GARTIC_ROUND_TIMEOUT_MS || 60_000)),
  generationTimeoutMs: Math.max(5_000, Number(process.env.GARTIC_GENERATION_TIMEOUT_MS || 45_000)),
  imageMaxBytes: Math.max(512_000, Number(process.env.GARTIC_IMAGE_MAX_BYTES || 8 * 1024 * 1024)),
  historyCooldown: Math.max(0, Number(process.env.GARTIC_HISTORY_COOLDOWN || 12)),
  tempDir: path.join(config.root, 'data', 'gartic', 'temp'),
  imageApiUrl: process.env.GARTIC_IMAGE_API_URL || '',
  imageApiKey: process.env.GARTIC_IMAGE_API_KEY || '',
  imageModel: process.env.GARTIC_IMAGE_MODEL || 'gpt-image-1.5',
  imageSize: process.env.GARTIC_IMAGE_SIZE || '1024x1024',
  language: process.env.GARTIC_LANGUAGE || config.language || 'pt-BR',
  score: Object.freeze({
    easy: { base: 80, multiplier: 1.0, max: 160 },
    medium: { base: 120, multiplier: 1.25, max: 240 },
    hard: { base: 170, multiplier: 1.5, max: 340 },
    insane: { base: 240, multiplier: 2.0, max: 480 }
  })
});
