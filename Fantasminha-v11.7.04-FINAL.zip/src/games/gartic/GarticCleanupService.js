import storage from './GarticImageStorage.js';
import { readCollection } from '../../database/store.js';
export async function cleanupRound(round){if(round?.imageReference)storage.remove(round.imageReference);}
export async function cleanupOrphans(){const games=Object.values(readCollection('game_engine',{games:{}}).games||{}).filter(g=>g.gameType==='gartic'&&['WAITING','ACTIVE'].includes(g.status));const refs=new Set(games.map(g=>g.state?.imageReference).filter(Boolean));return storage.listOrphans(refs,Number(process.env.GARTIC_TEMP_MAX_AGE_MS||24*60*60*1000));}
export default {cleanupRound,cleanupOrphans};
