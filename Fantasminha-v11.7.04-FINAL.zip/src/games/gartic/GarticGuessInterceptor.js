import service from './GarticService.js';
export async function handle(ctx){return service.handleGuess(ctx);}
export default {handle};
