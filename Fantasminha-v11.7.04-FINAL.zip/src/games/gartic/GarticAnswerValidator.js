const fold = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[“”‘’'`´]/g,'').replace(/[^\p{L}\p{N}\s-]/gu,' ').replace(/[\s-]+/g,' ').trim();
const tokens = s => fold(s).split(' ').filter(Boolean);
function editDistance(a,b){const A=Array.from(a),B=Array.from(b);const prev=Array(B.length+1).fill(0);const cur=Array(B.length+1).fill(0);for(let j=0;j<=B.length;j++)prev[j]=j;for(let i=1;i<=A.length;i++){cur[0]=i;for(let j=1;j<=B.length;j++)cur[j]=A[i-1]===B[j-1]?prev[j-1]:1+Math.min(prev[j],cur[j-1],prev[j-1]);for(let j=0;j<=B.length;j++)prev[j]=cur[j];}return prev[B.length];}
function similarity(a,b){if(a===b)return 1;if(!a||!b)return 0;const max=Math.max(a.length,b.length);return max?1-editDistance(a,b)/max:0;}
function tokenSimilarity(a,b){const A=new Set(tokens(a)),B=new Set(tokens(b));if(!A.size||!B.size)return 0;let hit=0;for(const t of A)if(B.has(t))hit++;return hit/Math.max(A.size,B.size);}
export function normalize(value){return fold(value);}
export function scoreMatch(input,word,aliases=[]){const a=fold(input);const valid=[word,...aliases].map(fold).filter(Boolean);if(!a||!valid.length)return 0;let best=0;for(const target of valid){if(a===target)return 1;const lev=similarity(a,target);const tok=tokenSimilarity(a,target);const contains=(a.length>=5&&target.length>=5&&(a.includes(target)||target.includes(a)))?Math.min(a.length,target.length)/Math.max(a.length,target.length):0;best=Math.max(best,lev,tok,contains);}return best;}
export function matches(input,word,aliases=[]){const a=fold(input);const valid=[word,...aliases].map(fold).filter(Boolean);if(!a||!valid.length)return false;if(valid.includes(a))return true;const score=scoreMatch(a,word,aliases);const shortest=Math.min(a.length,...valid.map(x=>x.length));if(shortest<=3)return false;return score>=0.72 || (score>=0.65 && valid.some(t=>a.includes(t)||t.includes(a)));
}
export default {normalize,matches,scoreMatch};
