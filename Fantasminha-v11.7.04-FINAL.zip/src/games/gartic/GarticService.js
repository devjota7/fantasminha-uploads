import crypto from 'node:crypto';
import game from '../../services/gameEngine.js';
import gameSessions from '../../services/gameSessionManager.js';
import * as gameTimer from '../../services/gameTimer.js';
import { recordResult } from '../../services/statsEngine.js';
import { grant } from '../../platform/rewards/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import { emit, Events } from '../../events/index.js';
import { addWeeklyScore } from '../../services/rankings.js';
import categoryEngine from './GarticCategoryEngine.js';
import difficultyEngine from './GarticDifficultyEngine.js';
import wordEngine from './GarticWordEngine.js';
import history from './GarticWordHistory.js';
import promptEngine from './GarticPromptEngine.js';
import provider from './GarticImageProvider.js';
import storage from './GarticImageStorage.js';
import cleanup from './GarticCleanupService.js';
import stats from './GarticStatistics.js';
import validator from './GarticAnswerValidator.js';
import score from './GarticScoreEngine.js';
import { GARTIC_WORDS } from './data/words.js';
import renderer from './GarticRenderer.js';
import { GarticConfig } from './GarticConfig.js';
import logger from '../../core/logger.js';

const locks=new Map();
const playerGuesses=new Map();
const lock=async(key,fn)=>{const prev=locks.get(key)||Promise.resolve();let release;const next=new Promise(r=>release=r);locks.set(key,prev.then(()=>next));await prev;try{return await fn();}finally{release();if(locks.get(key)===next)locks.delete(key);}};
const scope=g=>g||'private';
const active=(groupId)=>game.listActiveGames(groupId).find(x=>x.gameType==='gartic')||null;
const emitSafe=(e,p)=>emit(e,p).catch?.(()=>{});

async function audit(action,ctx,details={}){try{await recordAudit({actor:ctx?.sender||null,target:ctx?.from||null,scope:ctx?.from||null,action,result:'success',details});}catch{}}

export async function start(ctx){
  if(!ctx?.isGroup) return ctx.reply?.('👻 *×gartic só pode ser jogado em grupos.*');
  const groupId=ctx.from,userId=ctx.sender;
  return lock(`create:${groupId}`,async()=>{
    if(active(groupId)) return ctx.reply?.(renderer.busy());
    const category=categoryEngine.selectCategory(ctx.args?.[0]);
    const difficulty=difficultyEngine.selectDifficulty(ctx.args?.[1]);
    const word=wordEngine.selectWord({groupId,category,difficulty});
    const gameIdHint=crypto.randomUUID();
    const prompt=promptEngine.buildPrompt({word:word.word,category,difficulty,roundId:gameIdHint});
    let g;
    try{
      g=await game.createGame({groupId,gameType:'gartic',creatorId:userId,maxPlayers:1,timeoutMs:0,state:{phase:'GENERATING_IMAGE',category,difficulty,wordId:word.wordId,word:word.word,status:'GENERATING_IMAGE',imageReference:null,startedAt:Date.now(),expiresAt:0,winnerId:null,score:null,guesses:0,guessers:[]},metadata:{roundId:gameIdHint,secretProtected:true},onePerGroup:true});
    }catch(e){if(/ativa|active|já existe/i.test(e.message||'')) return ctx.reply?.(renderer.busy());throw e;}
    await audit('GARTIC_CREATED',ctx,{gameId:g.gameId,roundId:gameIdHint,category,difficulty}); await emit(Events.MESSAGE,{type:'gartic.round.created',gameId:g.gameId,groupId});
    try{
      if (typeof ctx.sendMessage !== 'function') throw new Error('Adapter de mensagens indisponível.');
      await ctx.sendMessage(groupId,{text:renderer.preparing()});
      await audit('GARTIC_IMAGE_GENERATION_STARTED',ctx,{gameId:g.gameId});
      const image=await provider.generate(prompt);
      const stored=storage.save(gameIdHint,image);
      await game.updateGame(g.gameId,groupId,x=>{x.state.imageReference=stored.ref;x.state.imageSha256=stored.sha256;x.state.phase='READY';x.state.status='READY';x.state.roundId=gameIdHint;return x;});
      await audit('GARTIC_IMAGE_GENERATED',ctx,{gameId:g.gameId,size:stored.size});
      const caption=renderer.round({category,difficulty,word:word.word,timeoutMs:GarticConfig.roundTimeoutMs});
      const sent=await ctx.sendMessage(groupId,{image,caption});
      if(!sent?.key) throw new Error('WhatsApp não retornou a chave da mensagem do Gartic.');
      await game.updateGame(g.gameId,groupId,x=>{x.state.phase='WAITING_ANSWERS';x.state.status='WAITING_ANSWERS';x.state.messageId=sent.key;x.state.expiresAt=Date.now()+GarticConfig.roundTimeoutMs;return x;});
      gameSessions.begin(groupId,'gartic',{gameId:g.gameId});
      gameTimer.start(groupId,'gartic',GarticConfig.roundTimeoutMs,async()=>resolveTimeout(ctx,g.gameId));
      await audit('GARTIC_ROUND_CREATED',ctx,{gameId:g.gameId,roundId:gameIdHint});
      return sent;
    }catch(e){
      await audit('GARTIC_IMAGE_GENERATION_FAILED',ctx,{gameId:g.gameId,error:e.message});
      await cleanup.cleanupRound((game.getGame(g.gameId)||g).state);
      try{await game.finishGame(g.gameId,groupId,{status:'ABANDONED',reason:'generation_or_send_failed',result:{error:'image_generation_or_send_failed'}});}catch{}
      gameSessions.end(groupId,'gartic');
      try{await ctx.reply(renderer.failed());}catch{}
      return null;
    }
  });
}

async function resolveWinner(ctx,g,guess){
  const elapsed=Date.now()-Number(g.state.startedAt||Date.now());
  const pts=score.calculate(g.state.difficulty,elapsed);
  gameTimer.stop(g.groupId,'gartic'); gameSessions.end(g.groupId,'gartic');
  const finished=await game.finishGame(g.gameId,g.groupId,{status:'FINISHED',winnerId:ctx.sender,reason:'correct_guess',result:{score:pts,elapsedMs:elapsed,guess}});
  if(finished) await emit('GAME_SCORE_FINALIZED',{eventId:`GARTIC:${g.gameId}:${ctx.sender}`,gameId:'gartic',gameSessionId:g.gameId,groupId:g.groupId,userId:ctx.sender,points:pts,won:true,stats:{drawings:1,correctGuesses:1,guesses:Number(g.state.guesses||0)+1,bestRound:pts},groupName:ctx.groupName||'Grupo',occurredAt:Date.now()});
  await history.record({wordId:g.state.wordId,word:g.state.word,category:g.state.category,difficulty:g.state.difficulty,gameId:g.gameId,roundId:g.state.roundId,groupId:g.groupId});
  await stats.record({groupId:g.groupId,userId:ctx.sender,countGame:true,won:true,correct:true,score:pts,elapsedMs:elapsed,category:g.state.category,difficulty:g.state.difficulty});
  await recordResult({groupId:g.groupId,userId:ctx.sender,gameType:'gartic',result:'correct',win:true,score:pts,xp:Math.floor(pts/2)});
  await grant(ctx.sender,{coins:Math.max(1,Math.floor(pts/20)),xp:Math.floor(pts/2),reason:'gartic_win',source:'gartic',operationId:g.gameId});
  await addWeeklyScore(ctx.sender,ctx.pushname||ctx.sender.split('@')[0],'games',pts);
  await audit('GARTIC_ROUND_WON',ctx,{gameId:g.gameId,score:pts,elapsedMs:elapsed});
  await emit(Events.MESSAGE,{type:'gartic.guess.correct',gameId:g.gameId,winnerId:ctx.sender,score:pts});
  await cleanup.cleanupRound(finished||g);
  const mentions=[ctx.sender];
  return ctx.reply(renderer.won({winnerName:ctx.pushname||ctx.sender,word:g.state.word,score:pts}),{mentions});
}

async function resolveTimeoutInternal(ctx,gameId){const g=game.getGame(gameId);if(!g||g.gameType!=='gartic'||!['ACTIVE','WAITING'].includes(g.status)||g.state?.phase!=='WAITING_ANSWERS')return null;gameSessions.end(g.groupId,'gartic');const finished=await game.finishGame(gameId,g.groupId,{status:'EXPIRED',reason:'timeout',result:{guesses:g.state.guesses||0}});for(const u of (g.state.guessers||[])){await emit('GAME_SCORE_FINALIZED',{eventId:`GARTIC:${gameId}:${u}`,gameId:'gartic',gameSessionId:gameId,groupId:g.groupId,userId:u,points:0,won:false,stats:{drawings:1,correctGuesses:0,guesses:Number(g.state.guesses||0)},groupName:'Grupo',occurredAt:Date.now()});}await history.record({wordId:g.state.wordId,word:g.state.word,category:g.state.category,difficulty:g.state.difficulty,gameId:g.gameId,roundId:g.state.roundId,groupId:g.groupId});const guessers=g.state.guessers||[];for(const u of guessers)await stats.record({groupId:g.groupId,userId:u,countGame:true,won:false,correct:false,category:g.state.category,difficulty:g.state.difficulty});await audit('GARTIC_ROUND_EXPIRED',ctx,{gameId});await emit(Events.MESSAGE,{type:'gartic.round.expired',gameId});await cleanup.cleanupRound(g.state);try{return await ctx.reply(renderer.expired({word:g.state.word}));}catch{return null;}
}
async function resolveTimeout(ctx,gameId){return lock(`resolve:${gameId}`,()=>resolveTimeoutInternal(ctx,gameId));}

export async function handleGuess(ctx){
  if(!ctx?.isGroup||!ctx.sender) return {handled:false};
  const raw=String(ctx.body||ctx.text||'').trim(); if(!raw||raw.startsWith(ctx.prefix||'×'))return {handled:false};
  const g=active(ctx.from); if(!g||g.state?.phase!=='WAITING_ANSWERS')return {handled:false};
  return lock(`resolve:${g.gameId}`,async()=>{
    const current=game.getGame(g.gameId); if(!current||current.state?.phase!=='WAITING_ANSWERS'||current.status!=='ACTIVE')return {handled:false};
    if(Date.now()>Number(current.state.expiresAt||0)){await resolveTimeoutInternal(ctx,current.gameId);return {handled:true,expired:true};}
    const valid=validator.matches(raw,current.state.word,findAliases(current.state.wordId));
    await game.updateGame(current.gameId,current.groupId,x=>{x.state.guesses=Number(x.state.guesses||0)+1;x.state.guessers=[...new Set([...(x.state.guessers||[]),ctx.sender])];return x;}).catch(()=>{});
    await stats.record({groupId:current.groupId,userId:ctx.sender,countGame:false,won:false,correct:valid,wrong:!valid,category:current.state.category,difficulty:current.state.difficulty});
    if(!valid){await audit('GARTIC_GUESS_RECEIVED',ctx,{gameId:current.gameId,correct:false});return {handled:true,correct:false};}
    const n=await game.updateGame(current.gameId,current.groupId,x=>{if(x.state.phase!=='WAITING_ANSWERS')return x;x.state.phase='RESOLVING';x.state.status='RESOLVING';x.state.winnerId=ctx.sender;return x;});
    if(n.state.phase!=='RESOLVING')return {handled:true};
    const result=await resolveWinner(ctx,n,raw); return {handled:true,correct:true,result};
  });
}

function findAliases(wordId){return GARTIC_WORDS.find(x=>x.wordId===wordId)?.aliases||[];}
export async function recover(){
  const activeGames=game.listActiveGames();
  for(const g of activeGames.filter(x=>x.gameType==='gartic')){
    try {
      if(g.state?.phase==='WAITING_ANSWERS' && Number(g.state?.expiresAt||0) > 0 && Date.now() >= Number(g.state.expiresAt)) {
        await resolveTimeoutInternal({from:g.groupId,sender:g.creatorId,reply:async()=>null},g.gameId);
      } else if(g.state?.phase==='GENERATING_IMAGE') {
        await game.finishGame(g.gameId,g.groupId,{status:'ABANDONED',reason:'generation_interrupted_by_restart',result:{error:'generation_interrupted'}});
        try{storage.remove(g.state?.imageReference);}catch{}
      }
    } catch (e) { logger.debug?.('gartic', `recovery ${g.gameId}: ${e.message}`); }
  }
  return cleanup.cleanupOrphans();
}
export function providerStatus(){return provider.providerInfo();}
export default {start,handleGuess,recover,providerStatus};
