import service from './GarticService.js';
export const GarticGame = Object.freeze({ start: service.start, handleGuess: service.handleGuess, recover: service.recover });
export default GarticGame;
