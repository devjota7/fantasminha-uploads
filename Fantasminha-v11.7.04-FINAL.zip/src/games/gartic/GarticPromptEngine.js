import crypto from 'node:crypto';

const visualHints = {
  easy: 'formas grandes, poucos elementos e silhueta muito clara',
  medium: 'elementos visuais suficientes para reconhecimento, mas sem entregar a resposta literalmente',
  hard: 'composição um pouco menos óbvia, exigindo observação e interpretação',
  insane: 'representação visual criativa e desafiadora, ainda reconhecível sem texto'
};

export function buildPrompt({ word, category, difficulty, roundId }) {
  const variation = crypto.randomBytes(8).toString('hex');
  return [
    `Gere UMA imagem para um jogo de adivinhação visual chamado Gartic. Rodada ${roundId}. Variação ${variation}.`,
    `Conceito secreto a representar: ${word}. Categoria: ${category}. Dificuldade: ${difficulty}.`,
    'Estilo obrigatório: desenho infantil propositalmente malfeito, como se uma criança tivesse desenhado rapidamente no papel.',
    'Use traços irregulares, formas tortas, proporções imperfeitas, poucos detalhes, aparência espontânea e engraçada, composição simples e linhas imperfeitas.',
    `A representação deve ser ${visualHints[difficulty] || visualHints.medium}.`,
    'A imagem precisa ser visualmente reconhecível, mas não profissional, fotográfica, realista ou sofisticada.',
    'PROIBIDO: qualquer palavra, letra, número, legenda, título, balão de fala, marca d’água, explicação, pista textual, interface ou resposta escrita.',
    'Não escreva o nome do conceito em nenhum lugar. Não use texto escondido. Comunique o conceito somente por elementos visuais.',
    'Fundo simples, uma única cena, sem moldura de aplicativo e sem elementos que pareçam interface.'
  ].join('\n');
}
export default {buildPrompt};
