import { GarticConfig } from './GarticConfig.js';
export function calculate(difficulty, elapsedMs){const c=GarticConfig.score[difficulty]||GarticConfig.score.medium;const speed=Math.max(0,Math.min(1,1-(Math.max(0,elapsedMs)/GarticConfig.roundTimeoutMs)));return Math.min(c.max,Math.max(1,Math.round(c.base*c.multiplier*(0.75+speed*0.25))));}
export default {calculate};
