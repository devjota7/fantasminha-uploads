const w = (word, category, difficulty, aliases=[]) => ({ wordId: `${category}:${word}`.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'-'), word, category, difficulty, aliases, active:true });

export const GARTIC_WORDS = [
  w('elefante','animais','easy',['elefante']), w('gato','animais','easy',['gato']), w('cachorro','animais','easy',['cachorro','cao']),
  w('pinguim','animais','medium',['pinguim']), w('girafa','animais','medium',['girafa']), w('polvo','animais','hard',['polvo']),
  w('xícara de café','objetos','medium',['xicara','xícara','xicara de cafe','xícara de café']), w('guarda-chuva','objetos','easy',['guarda chuva','sombrinha']),
  w('relógio','objetos','easy',['relogio']), w('tesoura','objetos','easy',['tesoura']), w('chave de fenda','ferramentas','medium',['chave fenda']),
  w('martelo','ferramentas','easy',['martelo']), w('pizza','comidas','easy',['pizza']), w('hambúrguer','comidas','easy',['hamburguer','hambúrguer']),
  w('sushi','comidas','medium',['sushi']), w('sorvete','comidas','easy',['sorvete']), w('lasanha','comidas','medium',['lasanha']),
  w('praia','lugares','easy',['praia']), w('montanha','lugares','easy',['montanha']), w('castelo','lugares','medium',['castelo']),
  w('cachoeira','natureza','medium',['cachoeira']), w('vulcão','natureza','hard',['vulcao']), w('arco-íris','natureza','easy',['arco iris','arco-iris']),
  w('bombeiro','profissões','easy',['bombeiro']), w('médico','profissões','easy',['medico']), w('astronauta','profissões','medium',['astronauta']),
  w('carro','veículos','easy',['carro']), w('avião','veículos','easy',['aviao']), w('submarino','veículos','medium',['submarino']),
  w('bicicleta','veículos','easy',['bicicleta','bike']), w('futebol','esportes','easy',['futebol']), w('surfe','esportes','medium',['surfe','surf']),
  w('skate','esportes','easy',['skate']), w('computador','tecnologia','easy',['computador','pc']), w('robô','tecnologia','easy',['robo']),
  w('celular','tecnologia','easy',['celular','telefone']), w('dinossauro','personagens','medium',['dinossauro']), w('dragão','fantasia','medium',['dragao']),
  w('unicórnio','fantasia','easy',['unicornio']), w('varinha mágica','fantasia','hard',['varinha magica','varinha']), w('sofá','casa','easy',['sofa']),
  w('geladeira','casa','easy',['geladeira','frigorifico']), w('mochila','escola','easy',['mochila']), w('lápis','escola','easy',['lapis']),
  w('violão','música','medium',['violao']), w('microfone','música','easy',['microfone']), w('foguete','espaço','easy',['foguete']),
  w('planeta','espaço','medium',['planeta']), w('coração','corpo humano','easy',['coracao']), w('cérebro','corpo humano','medium',['cerebro']),
  w('camiseta','roupas','easy',['camiseta']), w('tênis','roupas','easy',['tenis']), w('água de coco','bebidas','medium',['agua de coco']),
  w('chá','bebidas','easy',['cha']), w('semáforo','transporte','medium',['semaforo']), w('cueca','roupas','easy',['cueca']), w('calcinha','roupas','easy',['calcinha']),
  w('espantalho','categoria surpresa','hard',['espantalho']), w('labirinto','categoria surpresa','hard',['labirinto']),
  w('sombra','categoria surpresa','insane',['sombra']), w('tempestade','categoria surpresa','insane',['tempestade'])
];

export const GARTIC_CATEGORIES = [...new Set(GARTIC_WORDS.map(x => x.category))];
export const GARTIC_DIFFICULTIES = ['easy','medium','hard','insane'];
