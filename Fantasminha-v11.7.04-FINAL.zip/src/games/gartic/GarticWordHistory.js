import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { GarticConfig } from './GarticConfig.js';
const C='gartic_word_history';
export function list(groupId=null){ const d=readCollection(C,{entries:[]}); return (d.entries||[]).filter(x=>!groupId||x.groupId===groupId); }
export function isCooling(wordId, groupId){ const rows=list(groupId).filter(x=>x.wordId===wordId).sort((a,b)=>b.usedAt-a.usedAt); if(!rows.length)return false; return rows.slice(0,GarticConfig.historyCooldown).some(Boolean); }
export function lastUsedMap(groupId){ const out=new Map(); for(const x of list(groupId)){const prev=out.get(x.wordId);if(!prev||x.usedAt>prev.usedAt)out.set(x.wordId,x);} return out; }
export async function record(entry){ return updateCollection(C,d=>{d.entries ||= []; d.entries.push({id:`GWH-${crypto.randomUUID()}`,...entry,usedAt:Date.now()}); if(d.entries.length>10000)d.entries.splice(0,d.entries.length-10000); return d;},{entries:[]}); }
export default {list,isCooling,lastUsedMap,record};
