import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { GarticConfig } from './GarticConfig.js';

fs.mkdirSync(GarticConfig.tempDir,{recursive:true});
const safe = name => /^[a-zA-Z0-9._-]+$/.test(String(name||'')) ? String(name) : null;
export function save(roundId, buffer){
  if(!Buffer.isBuffer(buffer)||!buffer.length) throw new Error('Imagem inválida.');
  if(buffer.length>GarticConfig.imageMaxBytes) throw new Error('Imagem gerada excede o limite permitido.');
  const ref=`round-${crypto.randomBytes(8).toString('hex')}.png`;
  const file=path.join(GarticConfig.tempDir,ref); fs.writeFileSync(file,buffer,{flag:'wx'}); return {ref,path:file,sha256:crypto.createHash('sha256').update(buffer).digest('hex'),size:buffer.length};
}
export function remove(ref){const s=safe(ref);if(!s)return false;try{fs.rmSync(path.join(GarticConfig.tempDir,s),{force:true});return true;}catch{return false;}}
export function listOrphans(activeRefs=new Set(), maxAgeMs=24*60*60*1000){const now=Date.now(),removed=[];for(const f of fs.readdirSync(GarticConfig.tempDir)){const p=path.join(GarticConfig.tempDir,f);let st;try{st=fs.statSync(p);}catch{continue;}if(!st.isFile()||activeRefs.has(f))continue;if(now-st.mtimeMs>maxAgeMs){try{fs.rmSync(p,{force:true});removed.push(f);}catch{}}}return removed;}
export default {save,remove,listOrphans};
