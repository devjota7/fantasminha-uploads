import { GARTIC_CATEGORIES } from './data/words.js';
export function selectCategory(preferred=null){ const c=String(preferred||'').trim().toLowerCase(); return GARTIC_CATEGORIES.includes(c)?c:GARTIC_CATEGORIES[Math.floor(Math.random()*GARTIC_CATEGORIES.length)]; }
export default {selectCategory};
