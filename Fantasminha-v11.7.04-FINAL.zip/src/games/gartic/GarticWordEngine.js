import { GARTIC_WORDS } from './data/words.js';
import history from './GarticWordHistory.js';

export function selectWord({ groupId, category, difficulty }) {
  const pool = GARTIC_WORDS.filter(x => x.active && x.category===category && x.difficulty===difficulty);
  const fallback = GARTIC_WORDS.filter(x => x.active && x.category===category);
  const candidates = pool.length ? pool : (fallback.length ? fallback : GARTIC_WORDS.filter(x=>x.active));
  if (!candidates.length) throw new Error('Banco de palavras do Gartic vazio.');
  const recent = history.list(groupId).filter(x=>x.wordId).sort((a,b)=>b.usedAt-a.usedAt).slice(0, Math.max(0, Number(process.env.GARTIC_HISTORY_COOLDOWN || 12)));
  const recentIds = new Set(recent.map(x=>x.wordId));
  const fresh = candidates.filter(x=>!recentIds.has(x.wordId));
  const source = fresh.length ? fresh : candidates;
  if (!fresh.length) {
    const last = history.lastUsedMap(groupId);
    source.sort((a,b)=>(last.get(a.wordId)?.usedAt||0)-(last.get(b.wordId)?.usedAt||0));
  }
  return source[Math.floor(Math.random()*Math.min(source.length, Math.max(1, source.length)))];
}
export default {selectWord};
