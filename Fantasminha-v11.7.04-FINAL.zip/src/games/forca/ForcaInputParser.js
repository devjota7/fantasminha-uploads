import { normalizeLetter, normalizeWord } from './ForcaStateManager.js';

export function parseForcaInput(text='') {
  const raw = String(text ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ');
  if (!raw) return { type:'NONE', accepted:false };
  const match = raw.match(/^(letra|palavra)(?:\s+(.+))?$/iu);
  if (!match) return { type:'NONE', accepted:false };
  const type = match[1].toLowerCase();
  const payload = String(match[2] ?? '').trim();
  if (type === 'letra') {
    const letter = normalizeLetter(payload);
    return letter ? { type:'LETTER', accepted:true, value:letter, raw:payload } : { type:'LETTER', accepted:false, reason:'INVALID_LETTER', raw:payload };
  }
  const word = normalizeWord(payload);
  return word ? { type:'WORD', accepted:true, value:word, raw:payload } : { type:'WORD', accepted:false, reason:'EMPTY_WORD', raw:payload };
}

export default { parseForcaInput };
