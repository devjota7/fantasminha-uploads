const timers=new Map();
export function registerTimer(gameId,timer){clearTimer(gameId);timers.set(gameId,timer);}
export function clearTimer(gameId){const t=timers.get(gameId);if(t){clearTimeout(t);timers.delete(gameId);}}
export function clearAll(){for(const id of timers.keys())clearTimer(id);}
export default {registerTimer,clearTimer,clearAll};
