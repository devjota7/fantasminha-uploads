export const FORCA_STATUS = Object.freeze({ WAITING:'WAITING', ACTIVE:'ACTIVE', RESOLVING:'RESOLVING', FINISHED:'FINISHED', CANCELLED:'CANCELLED' });
export const DEFAULT_MAX_ATTEMPTS = 6;

export function normalizeWord(value='') {
  return String(value ?? '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

export function normalizeLetter(value='') {
  const raw = String(value ?? '').normalize('NFKC').trim();
  if (!/^\p{L}$/u.test(raw)) return '';
  const normalized = normalizeWord(raw);
  return /^\p{L}$/u.test(normalized) ? normalized : '';
}

export function createRevealed(word) {
  return Array.from(normalizeWord(word), ch => ch === ' ' || ch === '-' ? ch : null);
}

export function isComplete(state) {
  const word = state?.normalizedWord || '';
  const revealed = state?.revealedLetters || [];
  const chars = Array.from(word);
  return chars.length > 0 && chars.every((ch,i) => ch === ' ' || ch === '-' || revealed[i]);
}

export function renderMasked(state) {
  const original = Array.from(String(state?.word || ''));
  const normalized = Array.from(String(state?.normalizedWord || ''));
  return normalized.map((ch,i) => {
    if (ch === ' ') return ' '; if (ch === '-') return '-';
    return state.revealedLetters?.[i] ? (original[i] || ch).toUpperCase() : '_';
  }).join(' ');
}
