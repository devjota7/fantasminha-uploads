import crypto from 'node:crypto';
import game from '../../services/gameEngine.js';
import { selectWord } from './ForcaWordSelector.js';
import { DEFAULT_MAX_ATTEMPTS, FORCA_STATUS, createRevealed } from './ForcaStateManager.js';
export async function create(ctx){
  const groupId=ctx.from; const selected=await selectWord(groupId);
  const state={gameId:null,gameType:'FORCA',groupId,createdBy:ctx.sender,createdAt:Date.now(),status:FORCA_STATUS.WAITING,word:selected.word,normalizedWord:selected.normalizedWord,hint:selected.hint,maxAttempts:DEFAULT_MAX_ATTEMPTS,remainingAttempts:DEFAULT_MAX_ATTEMPTS,usedLetters:[],revealedLetters:createRevealed(selected.word),lastPlayerId:null,winnerId:null,endedAt:null,endReason:null,actions:[],processedMessageIds:[]};
  const g=await game.createGame({groupId,gameType:'FORCA',creatorId:ctx.sender,maxPlayers:1,state,timeoutMs:0,metadata:{gameType:'FORCA'},onePerGroup:true});
  await game.updateGame(g.gameId,groupId,x=>{x.state.gameId=g.gameId;return x;});
  return game.getGame(g.gameId);
}
export default {create};
