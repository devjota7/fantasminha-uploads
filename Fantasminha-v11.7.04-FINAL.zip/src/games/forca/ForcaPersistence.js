import { updateCollection } from '../../database/store.js';
export async function recordHistory(session){return updateCollection('forca_history',db=>{db.entries ||= []; db.entries.push({gameId:session.gameId,groupId:session.groupId,normalizedWord:session.normalizedWord,endedAt:session.endedAt||Date.now()});if(db.entries.length>5000)db.entries.splice(0,db.entries.length-5000);return db;},{entries:[]});}
export default {recordHistory};
