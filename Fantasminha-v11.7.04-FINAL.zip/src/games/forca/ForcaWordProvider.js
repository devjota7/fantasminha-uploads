import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { normalizeWord } from './ForcaStateManager.js';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const DEFAULTS = [
  { palavra:'elefante', dica:'Animal grande com tromba' },
  { palavra:'computador', dica:'Máquina eletrônica' },
  { palavra:'chocolate', dica:'Doce feito de cacau' },
  { palavra:'abacaxi', dica:'Fruta tropical com coroa' },
  { palavra:'biblioteca', dica:'Lugar com muitos livros' },
  { palavra:'jacaré', dica:'Réptil encontrado em rios' },
  { palavra:'guitarra', dica:'Instrumento musical de cordas' },
  { palavra:'borboleta', dica:'Inseto colorido que voa' },
  { palavra:'astronauta', dica:'Viaja para o espaço' },
  { palavra:'dinossauro', dica:'Animal pré-histórico' },
  { palavra:'pizza', dica:'Comida italiana redonda' },
  { palavra:'futebol', dica:'Esporte popular no Brasil' },
  { palavra:'arcoiris', dica:'Fenômeno colorido após chuva' },
  { palavra:'celular', dica:'Aparelho de comunicação portátil' },
  { palavra:'oceano', dica:'Grande massa de água salgada' },
  { palavra:'vulcão', dica:'Montanha que expele lava' },
  { palavra:'pinguim', dica:'Ave que não voa e vive no gelo' },
  { palavra:'cachoeira', dica:'Queda de água natural' },
  { palavra:'relógio', dica:'Mostra as horas' },
  { palavra:'unicórnio', dica:'Criatura mítica com chifre' }
];
let cache = null;
export async function loadWords() {
  if (cache) return cache;
  try {
    const raw = JSON.parse(await readFile(path.join(ROOT,'dados/src/funcs/json/forca.json'),'utf8'));
    const list = Array.isArray(raw?.palavras) ? raw.palavras : [];
    cache = list.filter(x=>x?.palavra).map(x=>({ word:String(x.palavra), hint:String(x.dica||'') })).filter(x=>normalizeWord(x.word));
  } catch { cache = DEFAULTS; }
  return cache;
}
export default { loadWords };
