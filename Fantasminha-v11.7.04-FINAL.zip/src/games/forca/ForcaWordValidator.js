import { normalizeWord } from './ForcaStateManager.js';
export function validateWordGuess(state, value) {
  const guess = normalizeWord(value);
  if (!guess) return { ok:false, reason:'EMPTY_WORD' };
  return { ok:true, guess, correct:guess === state.normalizedWord };
}
export default { validateWordGuess };
