import game from '../../services/gameEngine.js';
import { emit } from '../../events/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import { parseForcaInput } from './ForcaInputParser.js';
import { applyLetter, applyWord } from './ForcaAttemptManager.js';
import { FORCA_STATUS } from './ForcaStateManager.js';
import { active } from './ForcaSessionManager.js';
import { create } from './ForcaGame.js';
import { renderInitial, renderPanel, renderVictory, renderDefeatAnimation } from './ForcaRenderer.js';
import { finalizeStats } from './ForcaResultService.js';
import { recordHistory } from './ForcaPersistence.js';
import { audit } from './ForcaAuditService.js';
import { clearAll } from './ForcaCleanupService.js';
import { configuredOwner } from '../../core/permissions.js';

const locks=new Map();
const lock=(key,fn)=>{const prev=locks.get(key)||Promise.resolve();let release;const cur=new Promise(r=>release=r);locks.set(key,prev.then(()=>cur));return prev.then(async()=>{try{return await fn();}finally{release();if(locks.get(key)===cur)locks.delete(key);}})};
const uid=c=>c.sender||'unknown';
const gid=c=>c.from||'private';
const messageId=c=>c.message?.key?.id||c.key?.id||null;
const mention=id=>`@${String(id).split('@')[0]}`;

async function event(name,payload){try{await emit(name,payload);}catch{}}
async function finish(gameId,groupId,ctx,reason,winnerId=null,resultType='END'){
  return lock(`${groupId}:${gameId}`,async()=>{
    const g=game.getGame(gameId); if(!g||g.groupId!==groupId||g.gameType!=='FORCA')return null;
    if(!['WAITING','ACTIVE'].includes(g.status)||[FORCA_STATUS.FINISHED,FORCA_STATUS.CANCELLED].includes(g.state?.status))return null;
    const now=Date.now();
    const updated=await game.updateGame(gameId,groupId,x=>{x.state.status=FORCA_STATUS.RESOLVING;x.state.winnerId=winnerId;x.state.endedAt=now;x.state.endReason=reason;x.winnerId=winnerId;return x;});
    const state=updated.state; const actions=state.actions||[];
    await audit(reason==='CANCELLED'?'FORCA_CANCELLED':'FORCA_FINISHING',state,{userId:uid(ctx||{}),reason});
    await finalizeStats({gameId,groupId,state,actions});
    await recordHistory(state);
    await event(reason==='CANCELLED'?'FORCA_CANCELLED':'FORCA_FINISHED',{gameId,groupId,winnerId,reason});
    const final=await game.finishGame(gameId,groupId,{status:reason==='CANCELLED'?'CANCELLED':'FINISHED',winnerId,reason,result:{type:resultType,state:{...state,word:state.word}}});
    if(final && reason!=='CANCELLED'){ for(const userId of new Set(actions.map(x=>x.userId))){ const mine=actions.filter(x=>x.userId===userId); await event('GAME_SCORE_FINALIZED',{eventId:`FORCA:${gameId}:${userId}`,gameId:'forca',gameSessionId:gameId,groupId,userId,points:0,won:userId===winnerId,stats:{correctLetters:mine.filter(x=>x.type==='LETTER'&&x.correct).length,wrongLetters:mine.filter(x=>x.type==='LETTER'&&!x.correct).length,correctWords:mine.filter(x=>x.type==='WORD'&&x.correct).length,wrongWords:mine.filter(x=>x.type==='WORD'&&!x.correct).length,wordsSolved:userId===winnerId?1:0},occurredAt:Date.now()}); }}
    clearAll();
    return {final,state};
  });
}

export async function start(ctx){
  if(!ctx.isGroup)return ctx.reply?.('⚠️ O ×forca funciona apenas em grupos.');
  if(active(gid(ctx)))return ctx.reply?.('⚠️ Já existe uma FORCA em andamento neste grupo.');
  let g; try{g=await create(ctx);}catch(e){return ctx.reply?.(`⚠️ Não foi possível iniciar a FORCA: ${e.message}`);}
  await game.updateGame(g.gameId,gid(ctx),x=>{x.status='ACTIVE';x.state.status=FORCA_STATUS.ACTIVE;return x;});
  const state=game.getGame(g.gameId).state;
  await audit('FORCA_CREATED',state,{userId:uid(ctx)}); await event('FORCA_CREATED',{gameId:g.gameId,groupId:gid(ctx),createdBy:uid(ctx)}); await event('FORCA_STARTED',{gameId:g.gameId,groupId:gid(ctx)});
  return ctx.reply?.(renderInitial(state));
}

export async function handleInput(ctx){
  if(!ctx.isGroup)return {handled:false};
  const groupId=gid(ctx),g=active(groupId); if(!g||g.state?.status!==FORCA_STATUS.ACTIVE)return {handled:false};
  const text=String(ctx.body||ctx.text||'').trim();
  if(!text||text.startsWith(ctx.prefix||'×'))return {handled:false};
  const parsed=parseForcaInput(text);
  if(parsed.type==='NONE')return {handled:false};
  if(!parsed.accepted){await event('FORCA_INPUT_REJECTED',{gameId:g.gameId,groupId,userId:uid(ctx),reason:parsed.reason});return {handled:true,invalid:true};}
  const mid=messageId(ctx); const result=await lock(`${groupId}:${g.gameId}`,async()=>{
    let stored=null;
    const current=game.getGame(g.gameId); if(!current||current.groupId!==groupId||current.state?.status!==FORCA_STATUS.ACTIVE)return {ignored:true};
    const updated=await game.updateGame(g.gameId,groupId,state=>{
      state.state.processedMessageIds ||= [];
      if(mid&&state.state.processedMessageIds.includes(mid))return state;
      if(mid)state.state.processedMessageIds.push(mid);
      if(state.state.processedMessageIds.length>200)state.state.processedMessageIds.splice(0,state.state.processedMessageIds.length-200);
      const action=parsed.type==='LETTER'?applyLetter(state.state,parsed.value,uid(ctx)):applyWord(state.state,parsed.value,uid(ctx));
      if(action.result==='ALREADY_USED'||action.result==='INVALID')return state;
      stored=action;
      state.state.actions ||= [];
      state.state.actions.push({messageId:mid,userId:uid(ctx),type:parsed.type,guess:parsed.value,correct:['CORRECT_LETTER','WORD_COMPLETED','WORD_CORRECT'].includes(action.result),at:Date.now()});
      if(action.result==='WORD_COMPLETED'){state.state.winnerId=uid(ctx);state.state.status=FORCA_STATUS.RESOLVING;state.status='ACTIVE';}
      else if(action.result==='WORD_CORRECT'){state.state.winnerId=uid(ctx);state.state.status=FORCA_STATUS.RESOLVING;state.status='ACTIVE';}
      else if(action.result==='ATTEMPTS_EXHAUSTED'){state.state.status=FORCA_STATUS.RESOLVING;state.status='ACTIVE';}
      return state;
    });
    return {updated,action:stored};
  });
  if(result?.ignored)return {handled:true};
  if(!result?.action){
    if(result?.updated?.state && parsed.type==='LETTER' && result.updated.state.usedLetters?.includes(parsed.value)){
      await event('FORCA_LETTER_ALREADY_USED',{gameId:g.gameId,groupId,userId:uid(ctx),letter:parsed.value});
      await ctx.reply?.(`⚠️ A letra ${parsed.value.toUpperCase()} já foi utilizada.`);
    }
    return {handled:true};
  }
  const a=result.action; const state=result.updated.state;
  await event(parsed.type==='LETTER'?'FORCA_LETTER_GUESSED':'FORCA_WORD_GUESSED',{gameId:g.gameId,groupId,userId:uid(ctx),guess:parsed.value});
  await event(parsed.type==='LETTER'?(a.result==='CORRECT_LETTER'?'FORCA_LETTER_CORRECT':'FORCA_LETTER_WRONG'):(a.result==='WORD_CORRECT'?'FORCA_WORD_CORRECT':'FORCA_WORD_WRONG'),{gameId:g.gameId,groupId,userId:uid(ctx)});
  await event('FORCA_STATE_UPDATED',{gameId:g.gameId,groupId,userId:uid(ctx)});
  if (a.result==='WORD_COMPLETED') { await event('FORCA_WORD_COMPLETED',{gameId:g.gameId,groupId,userId:uid(ctx)}); await event('FORCA_WINNER_DEFINED',{gameId:g.gameId,groupId,winnerId:uid(ctx)}); }
  if (a.result==='WORD_CORRECT') await event('FORCA_WINNER_DEFINED',{gameId:g.gameId,groupId,winnerId:uid(ctx)});
  if (a.result==='WRONG_LETTER'||a.result==='WRONG_WORD'||a.result==='ATTEMPTS_EXHAUSTED') await event('FORCA_ATTEMPT_LOST',{gameId:g.gameId,groupId,userId:uid(ctx)});
  await audit(`FORCA_${a.result}`,state,{userId:uid(ctx),guess:parsed.value});
  if(a.result==='WORD_COMPLETED'||a.result==='WORD_CORRECT'){
    const endReason=a.result==='WORD_COMPLETED'?'WORD_COMPLETED':'WORD_GUESS'; const f=await finish(g.gameId,groupId,ctx,endReason,uid(ctx),a.result);
    await ctx.reply?.(`🎉 ${mention(uid(ctx))} acertou a palavra!`,{mentions:[uid(ctx)]}); if(f?.state)await ctx.reply?.(renderVictory({...f.state,winnerId:uid(ctx)},uid(ctx)),{mentions:[uid(ctx)]});
    return {handled:true,finished:true,winnerId:uid(ctx)};
  }
  if(a.result==='ATTEMPTS_EXHAUSTED'){
    const f=await finish(g.gameId,groupId,ctx,'ATTEMPTS_EXHAUSTED',null,'ATTEMPTS_EXHAUSTED');
    const defeated=f?.state||state;
    const frames=['😨','😵','😵‍💫','☠️','☠️\n/|\\\n/ \\','💫 ⚰️ 💫'];
    for(const frame of frames){ await ctx.reply?.(frame); await new Promise(r=>setTimeout(r,220)); }
    await ctx.reply?.(`❌ ${mention(uid(ctx))} errou. Tentativas esgotadas!`,{mentions:[uid(ctx)]}); await ctx.reply?.(renderPanel(defeated,{final:true,defeated:true}));
    return {handled:true,finished:true};
  }
  const ok=a.result==='CORRECT_LETTER';
  const short=ok?`✅ ${mention(uid(ctx))} acertou a letra ${parsed.value.toUpperCase()}!`:`❌ ${mention(uid(ctx))} errou a letra ${parsed.value.toUpperCase()}!`;
  await ctx.reply?.(`${renderDefeatAnimation(state)}\n\n${short}`,{mentions:[uid(ctx)]});
  await ctx.reply?.(renderPanel(state));
  return {handled:true,correct:ok};
}

export async function cancelForContext(ctx){
  if(!ctx.isGroup)return {cancelled:false,handled:false};
  const g=active(gid(ctx)); if(!g)return {cancelled:false,handled:false};
  const allowed=g.state.createdBy===uid(ctx)||ctx.isGroupAdmin||ctx.isOwner||configuredOwner(uid(ctx));
  if(!allowed){await audit('FORCA_CANCEL_DENIED',g.state,{userId:uid(ctx)});await event('FORCA_CANCEL_DENIED',{gameId:g.gameId,groupId:gid(ctx),userId:uid(ctx)});await ctx.reply?.('🚫 Você não possui permissão para cancelar esta FORCA.');return {cancelled:false,handled:true,denied:true};}
  const f=await finish(g.gameId,gid(ctx),ctx,'CANCELLED',null,'CANCELLED');
  if(f){await ctx.reply?.('🛑 *FORCA CANCELADA!*\n\nA partida foi encerrada.');return {cancelled:true,handled:true};}
  return {cancelled:false,handled:true};
}

export function recover(){const sessions=game.listActiveGames().filter(g=>g.gameType==='FORCA'&&g.state?.status===FORCA_STATUS.ACTIVE); for(const g of sessions) event('FORCA_RECOVERED',{gameId:g.gameId,groupId:g.groupId}); return sessions;}
export default {start,handleInput,cancelForContext,recover};
