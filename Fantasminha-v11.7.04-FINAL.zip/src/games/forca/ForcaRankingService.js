import { rankGroup } from './ForcaStatisticsService.js';
export function getGroupRanking(groupId,limit=10){return rankGroup(groupId).slice(0,limit);}
export default {getGroupRanking};
