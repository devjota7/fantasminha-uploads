import { readCollection, updateCollection } from '../../database/store.js';
const C='forca_statistics';
const player=(groupId,userId)=>`${groupId}::${userId}`;
const empty=()=>({games:0,finished:0,wins:0,lettersCorrect:0,lettersWrong:0,wordGuesses:0,wordCorrect:0,wordWrong:0,remainingOnWin:0,updatedAt:0});
export async function recordFinal({gameId,groupId,state,actions=[]}){
  return updateCollection(C,db=>{
    db.finalized ||= {};
    if(db.finalized[gameId]) return db;
    db.finalized[gameId]=true; db.players ||= {}; db.groups ||= {};
    const group=db.groups[groupId] ||= {games:0,finished:0,wins:0,points:0,players:{}};
    group.games++; group.finished++;
    const byUser=new Map(); for(const a of actions){const p=byUser.get(a.userId)||{lettersCorrect:0,lettersWrong:0,wordGuesses:0,wordCorrect:0,wordWrong:0}; if(a.type==='LETTER'&&a.correct)p.lettersCorrect++; if(a.type==='LETTER'&&!a.correct)p.lettersWrong++; if(a.type==='WORD'){p.wordGuesses++; if(a.correct)p.wordCorrect++; else p.wordWrong++;} byUser.set(a.userId,p);}
    if(state.winnerId){group.wins++;}
    for(const [userId,m] of byUser){const k=player(groupId,userId);const p=db.players[k] ||= {groupId,userId,...empty()};p.games++;p.finished++;p.lettersCorrect+=m.lettersCorrect;p.lettersWrong+=m.lettersWrong;p.wordGuesses+=m.wordGuesses;p.wordCorrect+=m.wordCorrect;p.wordWrong+=m.wordWrong;if(state.winnerId===userId){p.wins++;p.remainingOnWin=Number(state.remainingAttempts||0);}}
    group.players ||= {}; for(const [userId,m] of byUser){group.players[userId] ||= {games:0,wins:0,lettersCorrect:0,lettersWrong:0,wordGuesses:0,wordCorrect:0,wordWrong:0};const p=group.players[userId];p.games++;p.lettersCorrect+=m.lettersCorrect;p.lettersWrong+=m.lettersWrong;p.wordGuesses+=m.wordGuesses;p.wordCorrect+=m.wordCorrect;p.wordWrong+=m.wordWrong;if(state.winnerId===userId)p.wins++;}
    return db;
  },{finalized:{},players:{},groups:{}});
}
export function getPlayer(groupId,userId){return readCollection(C,{players:{}}).players?.[player(groupId,userId)]||null;}
export function rankGroup(groupId){const d=readCollection(C,{groups:{}}).groups?.[groupId];return Object.entries(d?.players||{}).map(([userId,x])=>({userId,...x})).sort((a,b)=>b.wins-a.wins||b.lettersCorrect-a.lettersCorrect||b.wordCorrect-a.wordCorrect);}
export default {recordFinal,getPlayer,rankGroup};
