import { renderMasked } from './ForcaStateManager.js';
import { frameFor } from './ForcaAnimationEngine.js';

const letters = s => (s.usedLetters?.length ? s.usedLetters.map(x=>x.toUpperCase()).join(' • ') : 'Nenhuma');
export function renderPanel(state, {final=false, defeated=false}={}) {
  if (final && defeated) return `╭━━━ 👻 FORCA ━━━╮\n\n💀 FIM DA PARTIDA!\n\n🔤 A palavra era:\n\n${Array.from(state.word).map(x=>x.toUpperCase()).join(' ')}\n\n💡 Dica: ${state.hint}\n\n❌ Tentativas esgotadas!\n❤️ 0/${state.maxAttempts}\n\n╰━━━━━━━━━━━━━━━━╯`;
  return `╭━━━ 👻 FORCA ━━━╮\n\n💡 Dica: ${state.hint}\n\n${renderMasked(state)}\n\n❤️ Tentativas: ${state.remainingAttempts}/${state.maxAttempts}\n\n🔤 Letras usadas:\n${letters(state)}\n\n👤 Última jogada:\n${state.lastPlayerId ? `@${String(state.lastPlayerId).split('@')[0]}` : 'Nenhuma'}\n\n${final ? '' : `╰━━━━━━━━━━━━━━━━╯`}`;
}
export function renderInitial(state){ return `╭━━━ 👻 FORCA ━━━╮\n\n💡 Dica: ${state.hint}\n\n${renderMasked(state)}\n\n❤️ Tentativas: ${state.remainingAttempts}/${state.maxAttempts}\n\n🔤 Letras usadas:\nNenhuma\n\n✏️ Envie:\n\nletra A\nou\npalavra ${state.word.length ? 'seu palpite' : 'palavra'}\n\n╰━━━━━━━━━━━━━━━━╯`; }
export function renderVictory(state,winnerId){ return `╭━━━ 👻 FORCA ━━━╮\n\n🎉 PALAVRA DESCOBERTA!\n\n🔤 ${Array.from(state.word).map(x=>x.toUpperCase()).join(' ')}\n\n💡 ${state.hint}\n\n🏆 VENCEDOR:\n\n👑 @${String(winnerId).split('@')[0]}\n\n❤️ Tentativas restantes:\n${state.remainingAttempts}/${state.maxAttempts}\n\n╰━━━━━━━━━━━━━━━━╯`; }
export function renderDefeatAnimation(state){ return frameFor(state.remainingAttempts,state.maxAttempts); }
export function renderResult(state,result){
  if(result==='WORD_CORRECT'||result==='WORD_COMPLETED') return renderVictory(state,state.winnerId||state.lastPlayerId);
  return renderPanel(state,{final:true,defeated:true});
}
export default {renderPanel,renderInitial,renderVictory,renderDefeatAnimation,renderResult};
