import { normalizeLetter } from './ForcaStateManager.js';
export function validateLetterGuess(state, value) {
  const letter = normalizeLetter(value);
  if (!letter) return { ok:false, reason:'INVALID_LETTER' };
  if ((state.usedLetters || []).includes(letter)) return { ok:false, reason:'ALREADY_USED', letter };
  return { ok:true, letter, correct:Array.from(state.normalizedWord || '').includes(letter) };
}
export default { validateLetterGuess };
