import { validateLetterGuess } from './ForcaLetterValidator.js';
import { validateWordGuess } from './ForcaWordValidator.js';
import { isComplete } from './ForcaStateManager.js';

export function applyLetter(state, letter, userId) {
  const check = validateLetterGuess(state, letter);
  if (!check.ok) return { state, result:check.reason === 'ALREADY_USED' ? 'ALREADY_USED' : 'INVALID', check };
  state.usedLetters.push(check.letter);
  state.lastPlayerId = userId;
  const chars = Array.from(state.normalizedWord);
  if (check.correct) {
    chars.forEach((ch,i)=>{ if(ch===check.letter) state.revealedLetters[i]=true; });
    if (isComplete(state)) return { state, result:'WORD_COMPLETED', check };
    return { state, result:'CORRECT_LETTER', check };
  }
  state.remainingAttempts = Math.max(0, Number(state.remainingAttempts||0)-1);
  return { state, result:state.remainingAttempts===0 ? 'ATTEMPTS_EXHAUSTED' : 'WRONG_LETTER', check };
}

export function applyWord(state, guess, userId) {
  const check = validateWordGuess(state, guess);
  if (!check.ok) return { state, result:'INVALID', check };
  state.lastPlayerId = userId;
  state.wordGuesses = Number(state.wordGuesses||0)+1;
  if (check.correct) return { state, result:'WORD_CORRECT', check };
  state.remainingAttempts = Math.max(0, Number(state.remainingAttempts||0)-1);
  return { state, result:state.remainingAttempts===0 ? 'ATTEMPTS_EXHAUSTED' : 'WRONG_WORD', check };
}
export default { applyLetter, applyWord };
