import { loadWords } from './ForcaWordProvider.js';
import { readCollection } from '../../database/store.js';
import { normalizeWord } from './ForcaStateManager.js';
export async function selectWord(groupId) {
  const words = await loadWords();
  const recent = new Set((readCollection('forca_history',{entries:[]}).entries||[]).filter(x=>x.groupId===groupId).slice(-12).map(x=>x.normalizedWord));
  const pool = words.filter(x=>!recent.has(normalizeWord(x.word)));
  const source = pool.length ? pool : words;
  const picked = source[Math.floor(Math.random()*source.length)] || words[0];
  return { word:picked.word, normalizedWord:normalizeWord(picked.word), hint:picked.hint || 'Descubra a palavra.' };
}
export default { selectWord };
