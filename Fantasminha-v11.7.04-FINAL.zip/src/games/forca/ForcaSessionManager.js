import game from '../../services/gameEngine.js';
export function active(groupId){return game.listActiveGames(groupId).find(g=>g.gameType==='FORCA')||null;}
export function scoped(gameId,groupId){const g=game.getGame(gameId);return g&&g.gameType==='FORCA'&&g.groupId===groupId?g:null;}
export default {active,scoped};
