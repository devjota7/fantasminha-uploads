import { recordAudit } from '../../platform/audit/index.js';
export async function audit(action,session,details={}){try{return await recordAudit({actor:details.userId||session.lastPlayerId||session.createdBy||null,target:session.groupId,action,scope:session.groupId,result:'success',details:{gameId:session.gameId,...details}});}catch{return null;}}
export default {audit};
