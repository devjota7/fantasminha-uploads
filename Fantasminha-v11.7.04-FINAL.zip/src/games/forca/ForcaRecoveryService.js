import game from '../../services/gameEngine.js';
import { FORCA_STATUS } from './ForcaStateManager.js';
export function recover(){
  const active=game.listActiveGames().filter(g=>g.gameType==='FORCA');
  return active.filter(g=>g.state?.status===FORCA_STATUS.ACTIVE || g.state?.status===FORCA_STATUS.WAITING);
}
export default {recover};
