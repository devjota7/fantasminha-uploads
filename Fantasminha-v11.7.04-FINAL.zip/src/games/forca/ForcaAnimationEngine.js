const frames = Object.freeze([
  '🙂',
  '😐',
  '😟',
  '😰 💫',
  '😨 ⚡ 💫 ⚡',
  '😵 💫',
  '☠️ /|\\ / \\',
]);
export function frameFor(remaining,max=6){
  const errors=Math.max(0,Math.min(max,max-Number(remaining||0)));
  return frames[errors] || frames.at(-1);
}
export function finalFrames(){ return [...frames,'💫 ⚰️ 💫']; }
export default { frameFor, finalFrames };
