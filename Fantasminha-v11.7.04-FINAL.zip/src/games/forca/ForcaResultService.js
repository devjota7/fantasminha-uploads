import { recordFinal } from './ForcaStatisticsService.js';
import stats from '../../services/statsEngine.js';
export async function finalizeStats({gameId,groupId,state,actions}){
  await recordFinal({gameId,groupId,state,actions});
  const users=new Set(actions.map(x=>x.userId));
  for(const userId of users){const win=state.winnerId===userId;try{await stats.recordResult({groupId,userId,gameType:'FORCA',result:win?'win':'play',win,loss:false,draw:false,score:0,xp:0,operationId:`FORCA:${gameId}:${userId}`});}catch{}}
}
export default {finalizeStats};
