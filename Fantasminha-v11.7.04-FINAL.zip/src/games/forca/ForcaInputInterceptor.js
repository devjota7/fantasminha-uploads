import { parseForcaInput } from './ForcaInputParser.js';
export function isForcaCandidate(text=''){const p=parseForcaInput(text);return p.type!=='NONE';}
export default {isForcaCandidate};
