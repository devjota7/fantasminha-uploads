const games = new Map();
export function registerGame(def){ if(!def?.gameId) throw new Error('gameId obrigatório'); games.set(String(def.gameId), Object.freeze({...def})); return games.get(String(def.gameId)); }
export function getGame(gameId){ return games.get(String(gameId||'')) || null; }
export function listGames(){ return [...games.values()]; }
export function hasGame(gameId){ return games.has(String(gameId||'')); }
export default {registerGame,getGame,listGames,hasGame};
