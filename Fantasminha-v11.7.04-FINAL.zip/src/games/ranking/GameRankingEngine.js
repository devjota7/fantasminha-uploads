import crypto from 'node:crypto';
import registry from './GameRankingRegistry.js';
import validator from './GameRankingValidator.js';
import repo from './GameRankingRepository.js';
import cache from './GameRankingCache.js';
import { audit } from './GameRankingAudit.js';
import { emit } from '../../events/index.js';
export async function registerMatchResult(result){
  const adapter=registry.getGame(result.gameId)?.rankingAdapter;if(!adapter)throw new Error(`Adapter ausente para ${result.gameId}`);
  const players=Array.isArray(result.players)?result.players:[]; const out=[];
  for(const p of players){const event={eventId:p.eventId||`${result.gameSessionId}:${p.userId}`,gameId:result.gameId,gameSessionId:result.gameSessionId,groupId:result.groupId,userId:p.userId,points:Number(p.points)||0,won:Boolean(p.won),status:result.status||'FINISHED',occurredAt:result.occurredAt||Date.now()};const v=validator.validateScoreEvent(event);if(!v.ok)throw new Error(`Resultado de ranking inválido: ${v.errors.join(',')}`);const stats=adapter.normalizeStats?adapter.normalizeStats(p.stats||{},p,result):p.stats||{};out.push(await repo.appendScore(event,stats,result.groupName||'Grupo'));}
  cache.invalidate({gameId:result.gameId,groupId:result.groupId,userIds:players.map(x=>x.userId)});await audit('RANKING_POINTS_REGISTERED',{...result,eventId:result.eventId},{players:players.length});return out;
}
export async function consumeScoreEvent(payload){const p=payload||{};if(!p.gameId||!p.gameSessionId||!p.userId)return null;return registerMatchResult({eventId:p.eventId||crypto.randomUUID(),gameId:p.gameId,gameSessionId:p.gameSessionId,groupId:p.groupId,userId:p.userId,groupName:p.groupName,players:[{userId:p.userId,points:p.points,won:p.won,stats:p.stats}],status:'FINISHED',occurredAt:p.occurredAt});}
export async function register(){const {on}=await import('../../events/index.js');return on('GAME_SCORE_FINALIZED',consumeScoreEvent);}
export default {registerMatchResult,consumeScoreEvent,register};
