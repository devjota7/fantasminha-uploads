import { readCollection, updateCollection } from '../../database/store.js';
const C='game_ranking';
const fallback={ledger:[],processed:{},players:{},groups:{},meta:{}};
const pkey=(gameId,groupId,userId)=>`${gameId}::${groupId}::${userId}`;
const gkey=(gameId,groupId)=>`${gameId}::${groupId}`;
const ukey=(gameId,userId)=>`${gameId}::${userId}`;
export function read(){return readCollection(C,fallback);}
export async function appendScore(event,statsSnapshot={},groupName='Grupo'){
  return updateCollection(C,db=>{
    db.ledger??=[];db.processed??={};db.players??={};db.groups??={};db.meta??={};
    const unique=`${event.gameSessionId}::${event.userId}`;
    if(db.processed[unique]||db.processed[event.eventId]) return db;
    const entry={id:`RANK-${event.eventId}`,eventId:event.eventId,gameId:event.gameId,gameSessionId:event.gameSessionId,groupId:event.groupId,userId:event.userId,points:Number(event.points)||0,won:Boolean(event.won),stats_snapshot:structuredClone(statsSnapshot||{}),created_at:event.occurredAt||Date.now(),groupName:groupName||'Grupo'};
    db.ledger.push(entry);db.processed[unique]=entry.id;db.processed[event.eventId]=entry.id;
    const pk=pkey(event.gameId,event.groupId,event.userId),uk=ukey(event.gameId,event.userId),gk=gkey(event.gameId,event.groupId);
    const base={gameId:event.gameId,groupId:event.groupId,userId:event.userId,points:0,matches:0,wins:0,losses:0,stats:{},createdAt:entry.created_at,updatedAt:entry.created_at};
    const p=db.players[pk]??={...base};p.points+=entry.points;p.matches++;p.wins+=entry.won?1:0;p.losses+=event.won?0:1;p.stats=mergeStats(p.stats,entry.stats_snapshot);p.updatedAt=Date.now();
    const u=db.meta.globalPlayers??={}; const up=u[uk]??={gameId:event.gameId,userId:event.userId,points:0,matches:0,wins:0,losses:0,stats:{},createdAt:entry.created_at,updatedAt:entry.created_at};up.points+=entry.points;up.matches++;up.wins+=entry.won?1:0;up.losses+=event.won?0:1;up.stats=mergeStats(up.stats,entry.stats_snapshot);up.updatedAt=Date.now();
    const gr=db.groups[gk]??={gameId:event.gameId,groupId:event.groupId,name:groupName||'Grupo',points:0,matches:0,wins:0,updatedAt:entry.created_at,players:{}};gr.name=groupName||gr.name||'Grupo';gr.points+=entry.points;gr.matches++;gr.wins+=event.won?1:0;gr.players[event.userId]=true;gr.updatedAt=Date.now();
    return db;
  },fallback).then(db=>({applied:!!db.processed[`${event.gameSessionId}::${event.userId}`],entry:db.ledger.at(-1)}));
}
function mergeStats(a={},b={}){const out={...a};for(const [k,v] of Object.entries(b||{})){if(typeof v==='number'&&Number.isFinite(v))out[k]=(Number(out[k])||0)+v;else if(typeof v==='boolean')out[k]=Boolean(out[k])||v;else if(out[k]==null)out[k]=structuredClone(v);}return out;}
export function ledger(gameId){return read().ledger.filter(x=>x.gameId===gameId);}
export function playerRows(gameId,groupId){const d=read();return Object.values(d.players||{}).filter(x=>x.gameId===gameId&&x.groupId===groupId);}
export function globalPlayerRows(gameId){return Object.values(read().meta?.globalPlayers||{}).filter(x=>x.gameId===gameId);}
export function groupRows(gameId){return Object.values(read().groups||{}).filter(x=>x.gameId===gameId);}
export function getPlayer(gameId,groupId,userId){return read().players?.[pkey(gameId,groupId,userId)]||null;}
export function getGlobalPlayer(gameId,userId){return read().meta?.globalPlayers?.[ukey(gameId,userId)]||null;}
export function clearProjections(gameId){return updateCollection(C,db=>{for(const k of Object.keys(db.players||{}))if(db.players[k].gameId===gameId)delete db.players[k];for(const k of Object.keys(db.groups||{}))if(db.groups[k].gameId===gameId)delete db.groups[k];for(const k of Object.keys(db.meta?.globalPlayers||{}))if(db.meta.globalPlayers[k].gameId===gameId)delete db.meta.globalPlayers[k];return db;},fallback);}
export default {read,appendScore,ledger,playerRows,globalPlayerRows,groupRows,getPlayer,getGlobalPlayer,clearProjections};
