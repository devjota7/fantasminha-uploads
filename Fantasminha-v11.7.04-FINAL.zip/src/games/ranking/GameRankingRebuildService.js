import repo from './GameRankingRepository.js';
import { updateCollection } from '../../database/store.js';
import { audit } from './GameRankingAudit.js';
const C='game_ranking';
export async function rebuildGame(gameId){
  const d=repo.read(); const entries=d.ledger.filter(x=>x.gameId===gameId);
  await repo.clearProjections(gameId);
  for(const e of entries){await updateCollection(C,db=>{db.players??={};db.groups??={};db.meta??={};db.meta.globalPlayers??={};const pk=`${e.gameId}::${e.groupId}::${e.userId}`,uk=`${e.gameId}::${e.userId}`,gk=`${e.gameId}::${e.groupId}`;const p=db.players[pk]??={gameId:e.gameId,groupId:e.groupId,userId:e.userId,points:0,matches:0,wins:0,losses:0,stats:{}};p.points+=e.points;p.matches++;p.wins+=e.won?1:0;p.losses+=e.won?0:1;merge(p.stats,e.stats_snapshot);const u=db.meta.globalPlayers[uk]??={gameId:e.gameId,userId:e.userId,points:0,matches:0,wins:0,losses:0,stats:{}};u.points+=e.points;u.matches++;u.wins+=e.won?1:0;u.losses+=e.won?0:1;merge(u.stats,e.stats_snapshot);const g=db.groups[gk]??={gameId:e.gameId,groupId:e.groupId,name:e.groupName||'Grupo',points:0,matches:0,wins:0,players:{}};g.name=e.groupName||g.name;g.points+=e.points;g.matches++;g.wins+=e.won?1:0;g.players[e.userId]=true;return db;}, {ledger:[],processed:{},players:{},groups:{},meta:{globalPlayers:{}}});}
  await audit('RANKING_REBUILT',{gameId},{entries:entries.length});return {gameId,entries:entries.length};
}
function merge(a,b){for(const [k,v] of Object.entries(b||{}))if(typeof v==='number')a[k]=(a[k]||0)+v;}
export async function rebuildGroup(gameId,groupId){const entries=repo.ledger(gameId).filter(x=>x.groupId===groupId);await rebuildGame(gameId);return entries.length;}
export async function rebuildUser(gameId,userId){const entries=repo.ledger(gameId).filter(x=>x.userId===userId);await rebuildGame(gameId);return entries.length;}
export default {rebuildGame,rebuildGroup,rebuildUser};
