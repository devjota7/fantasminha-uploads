import repo from './GameRankingRepository.js';
import { rankRows } from './GameRankingCalculator.js';
export function group(gameId,groupId,limit=5){return rankRows(repo.playerRows(gameId,groupId)).slice(0,Math.max(1,Number(limit)||5));}
export function globalUsers(gameId,limit=3){return rankRows(repo.globalPlayerRows(gameId)).slice(0,Math.max(1,Number(limit)||3));}
export function globalGroups(gameId,limit=5){return [...repo.groupRows(gameId)].sort((a,b)=>b.points-a.points||b.wins-a.wins||String(a.groupId).localeCompare(String(b.groupId))).slice(0,Math.max(1,Number(limit)||5)).map((g,i)=>({...g,position:i+1,topPlayers:group(gameId,g.groupId,2)}));}
export function userRank(gameId,groupId,userId){const gr=group(gameId,groupId,Number.MAX_SAFE_INTEGER);const gu=globalUsers(gameId,Number.MAX_SAFE_INTEGER);return {group:gr.find(x=>x.userId===userId)?.position||0,global:gu.find(x=>x.userId===userId)?.position||0,groupStats:repo.getPlayer(gameId,groupId,userId),globalStats:repo.getGlobalPlayer(gameId,userId)};}
export default {group,globalUsers,globalGroups,userRank};
