const adapter={
 getGameId:()=> 'quiz',
 registerMatchResult:()=>null, registerPlayerResult:()=>null,getPlayerStats:()=>null,getGroupStats:()=>null,getGlobalStats:()=>null,getSpecificStats:s=>s,
 normalizeStats:(s,p)=>({correctAnswers:Number(s.correctAnswers??(p.won?1:0)),wrongAnswers:Number(s.wrongAnswers??(p.won?0:1)),totalAnswers:Number(s.totalAnswers??1),accuracy:Number(s.accuracy??(p.won?100:0))}),
 formatStats:s=>`🎯 Acerto: ${s.totalAnswers?Math.round((Number(s.correctAnswers||0)/Number(s.totalAnswers||0))*100):0}%`
}; export default adapter;
