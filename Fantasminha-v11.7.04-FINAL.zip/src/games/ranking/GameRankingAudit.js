import { recordAudit } from '../../platform/audit/index.js';
export async function audit(action,event={},details={}){try{return await recordAudit({actor:event.actor||null,target:event.groupId||null,scope:event.groupId||null,action,operationId:event.eventId||null,details:{gameId:event.gameId,gameSessionId:event.gameSessionId,userId:event.userId,...details}});}catch{return null;}}
export default {audit};
