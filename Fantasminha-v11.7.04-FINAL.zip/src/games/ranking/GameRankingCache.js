const cache=new Map();
export function get(key){const x=cache.get(key);if(!x)return null;if(x.expiresAt<Date.now()){cache.delete(key);return null;}return structuredClone(x.value);}
export function set(key,value,ttl=15000){cache.set(key,{value:structuredClone(value),expiresAt:Date.now()+Math.max(100,ttl)});return value;}
export function invalidate({gameId,groupId,userIds=[]}={}){for(const k of [...cache.keys()]){if(k.startsWith(`ranking:${gameId}:`)||(groupId&&k.includes(`group:${groupId}`))||userIds.some(u=>k===`ranking:${gameId}:user:${u}`))cache.delete(k);}}
export function clear(){cache.clear();}
export default {get,set,invalidate,clear};
