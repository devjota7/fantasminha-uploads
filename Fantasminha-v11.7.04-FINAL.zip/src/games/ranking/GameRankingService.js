import registry from './GameRankingRegistry.js';
import resolver from './GameRankingResolver.js';
export function group(gameId,groupId,limit=5){return resolver.resolve(gameId,'group',{groupId,limit});}
export function global(gameId){return resolver.resolve(gameId,'global');}
export function user(gameId,groupId,userId){return resolver.resolve(gameId,'user',{groupId,userId});}
export function gameMeta(gameId){return registry.getGame(gameId);}
export default {group,global,user,gameMeta};
