import registry from './GameRankingRegistry.js';
import engine from './GameRankingEngine.js';
import Quiz from './adapters/QuizRankingAdapter.js';
import Memory from './adapters/MemoryCupsRankingAdapter.js';
import Stop from './adapters/StopRankingAdapter.js';
import Forca from './adapters/ForcaRankingAdapter.js';
import Gartic from './adapters/GarticRankingAdapter.js';
const defs=[['quiz','🧠 Quiz',Quiz],['memoriacopos','🥤 Memória dos Copos',Memory],['stop','🛑 STOP',Stop],['forca','🔤 Forca',Forca],['gartic','🎨 Gartic',Gartic]];
for(const [gameId,displayName,adapter] of defs)registry.registerGame({gameId,displayName,icon:displayName.slice(0,2).trim(),rankingEnabled:true,groupRankingEnabled:true,globalRankingEnabled:true,rankingAdapter:adapter});
let registered=false;export async function register(){if(!registered){await engine.register();registered=true;}return registry.listGames();}
export {registry,engine};
export default {register,registry,engine};
