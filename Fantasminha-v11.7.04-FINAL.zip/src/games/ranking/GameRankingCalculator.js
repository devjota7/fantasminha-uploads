export function sortPlayers(rows=[]){return [...rows].sort((a,b)=>Number(b.points||0)-Number(a.points||0)||Number(b.wins||0)-Number(a.wins||0)||Number(a.matches||0)-Number(b.matches||0)||String(a.userId).localeCompare(String(b.userId)));}
export function rankRows(rows=[]){return sortPlayers(rows).map((x,i)=>({...x,position:i+1}));}
export function sum(rows,key='points'){return rows.reduce((n,x)=>n+Number(x?.[key]||0),0);}
export default {sortPlayers,rankRows,sum};
