import registry from './GameRankingRegistry.js';
import repo from './GameRankingRepository.js';
import agg from './GameRankingAggregator.js';
export function resolve(gameId,scope,{groupId=null,userId=null,limit=5}={}){if(!registry.hasGame(gameId))throw new Error(`Jogo não registrado no ranking: ${gameId}`);if(scope==='group')return agg.group(gameId,groupId,limit);if(scope==='global')return {groups:agg.globalGroups(gameId,5),users:agg.globalUsers(gameId,3)};if(scope==='user')return agg.userRank(gameId,groupId,userId);throw new Error(`Escopo inválido: ${scope}`);}
export default {resolve};
