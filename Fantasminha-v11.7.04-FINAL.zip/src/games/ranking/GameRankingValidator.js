import registry from './GameRankingRegistry.js';
const FINISHED = new Set(['FINISHED']);
export function validateScoreEvent(e){
  const errors=[];
  if(!e?.eventId) errors.push('eventId');
  if(!registry.hasGame(e?.gameId)) errors.push('gameId');
  if(!e?.gameSessionId) errors.push('gameSessionId');
  if(!e?.groupId) errors.push('groupId');
  if(!e?.userId) errors.push('userId');
  if(!Number.isFinite(Number(e?.points)) || Number(e.points)<0) errors.push('points');
  if(e?.status && !FINISHED.has(e.status)) errors.push('status');
  return {ok:errors.length===0,errors};
}
export default {validateScoreEvent};
