export function validateAIResponse(v){return !!v&&typeof v.valid==='boolean'&&typeof v.reason==='string'&&v.reason.length<=500&&Number.isFinite(Number(v.confidence))&&Number(v.confidence)>=0&&Number(v.confidence)<=1&&typeof v.letter_match==='boolean'&&typeof v.category_match==='boolean';}
export default {validateAIResponse};
