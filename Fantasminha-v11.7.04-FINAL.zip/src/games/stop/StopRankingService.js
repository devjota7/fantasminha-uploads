import { rankGroup } from './StopStatisticsService.js';
import { readCollection } from '../../database/store.js';
export function getGroupRanking(groupId,limit=10){return rankGroup(groupId,limit);}
export function getGlobalRanking(limit=20){return Object.values(readCollection('stop_statistics',{players:{}}).players||{}).sort((a,b)=>b.points-a.points||b.wins-a.wins).slice(0,Math.max(1,Math.min(50,Number(limit)||20)));}
export default {getGroupRanking,getGlobalRanking};
