/**
 * Barramento de eventos (desacopla Baileys dos comandos)
 */
import logger from '../core/logger.js';

const listeners = new Map();

export function on(event, fn) {
  if (!listeners.has(event)) listeners.set(event, new Set());
  listeners.get(event).add(fn);
  return () => listeners.get(event)?.delete(fn);
}

export async function emit(event, payload) {
  const set = listeners.get(event);
  if (!set?.size) return;
  for (const fn of [...set]) {
    try {
      await fn(payload);
    } catch (e) {
      logger.error('events', `${event}: ${e.message}`);
    }
  }
}

export const Events = {
  MESSAGE: 'message',
  GROUP_UPDATE: 'group-update',
  PARTICIPANT: 'participant-update',
  CONNECTION: 'connection-update',
  CALL: 'call',
  REACTION: 'reaction',
  ERROR: 'error',
  SHUTDOWN: 'shutdown',
  READY: 'ready',
  GAME_CREATED: 'GAME_CREATED',
  GAME_STARTED: 'GAME_STARTED',
  ROUND_FINISHED: 'ROUND_FINISHED',
  GAME_FINISHED: 'GAME_FINISHED',
  GAME_CANCELLED: 'GAME_CANCELLED',
  GAME_SCORE_FINALIZED: 'GAME_SCORE_FINALIZED'
};

export default { on, emit, Events };
