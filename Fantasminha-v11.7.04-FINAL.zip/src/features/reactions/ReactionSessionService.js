import { randomUUID } from 'node:crypto';
import { createReaction, getReaction, getReactionGroups, listReactions, updateReaction, deleteReaction } from './ReactionRepository.js';
import { audit } from './ReactionAuditService.js';
import { MATCH_MODES, SCOPES, STATUSES, normalizeText, parseMatchMode, parseScope, validateEmoji, validateTrigger } from './ReactionValidator.js';
import { resolveAvailableGroups } from './ReactionScopeResolver.js';
import config from '../../core/config.js';

const sessions = new Map();
const SESSION_TTL = Math.max(30_000, Number(process.env.REACT_SESSION_TTL_MS || 180_000));
const MAX_GROUPS = Math.max(1, Number(process.env.REACT_MAX_GROUPS || 100));
const MAX_REACTIONS = Math.max(1, Number(process.env.REACT_MAX_CONFIGS || 500));
const MAX_EXECUTIONS_WINDOW = Math.max(0, Number(process.env.REACT_MAX_EXECUTIONS_WINDOW || 0));
const executionWindow = new Map();

const owner = ctx => !!ctx?.isOwner && !ctx?.fromMe && !ctx?.message?.key?.fromMe;
const cancelValue = s => /^(0|cancelar|cancel)$/i.test(String(s || '').trim());
const yes = s => /^1$/.test(String(s || '').trim());
const no = s => /^2$/.test(String(s || '').trim());

function newSession(ctx, command = 'create') {
  const id = randomUUID();
  const s = { sessionId: id, ownerId: ctx.sender, command, step: command === 'create' ? 'trigger' : 'select', temporaryData: {}, createdAt: Date.now(), expiresAt: Date.now() + SESSION_TTL };
  sessions.set(ctx.sender, s);
  return s;
}
function getSession(userId) { const s = sessions.get(userId); if (!s) return null; if (Date.now() > s.expiresAt) return { ...s, __expired: true }; s.expiresAt = Date.now() + SESSION_TTL; return s; }
function clear(userId) { sessions.delete(userId); }
async function expired(ctx, s) { await audit('REACTION_SESSION_EXPIRED', { actorUserId: ctx.sender, metadata: { sessionId: s.sessionId } }); return ctx.reply('⏱️ *CONFIGURAÇÃO EXPIRADA*\n\nA sessão foi encerrada por inatividade.\n\nNenhuma alteração foi salva.'); }
async function cancelled(ctx, s) { clear(ctx.sender); await audit('REACTION_CONFIG_CANCELLED', { actorUserId: ctx.sender, metadata: { sessionId: s.sessionId } }); return ctx.reply('❌ *CONFIGURAÇÃO CANCELADA*\n\nNenhuma alteração foi salva.'); }
function baseNormalization() { return { foldCase: true, foldAccents: true }; }
function selectedGroups(s) { return s.temporaryData.groups || []; }
function fmtGroups(groups) { return groups.map(g => `• ${g.name || g.id}`).join('\n') || '• Nenhum'; }

export async function startCreate(ctx) {
  if (!owner(ctx)) return unauthorized(ctx);
  if (listReactions().length >= MAX_REACTIONS) return ctx.reply(`⚠️ Limite de ${MAX_REACTIONS} reações atingido.`);
  const s = newSession(ctx);
  await audit('REACTION_SESSION_STARTED', { actorUserId: ctx.sender, metadata: { sessionId: s.sessionId } });
  return ctx.reply('🤖 *CONFIGURADOR DE REAÇÕES*\n\nDigite o nome/texto que ativará a reação.\n\nDigite *0* para cancelar.\n\nExemplo: *jota*');
}

async function getGroups(ctx) {
  try { return resolveAvailableGroups(await ctx.listGroups?.()); } catch { return resolveAvailableGroups(ctx.availableGroups || []); }
}

export async function handleSession(ctx) {
  if (!owner(ctx)) return { handled: false };
  const s = getSession(ctx.sender);
  if (!s) return { handled: false };
  const text = String(ctx.body ?? ctx.text ?? '').trim();
  if (!text) return { handled: true };
  if (Date.now() > s.expiresAt) { await expired(ctx, s); return { handled: true, expired: true }; }
  if (/^\×react(?:\s|$)/i.test(text) || new RegExp(`^${escape(ctx.prefix || config.prefix)}react(?:\\s|$)`, 'i').test(text)) return { handled: false };
  if (cancelValue(text)) { await cancelled(ctx, s); return { handled: true, cancelled: true }; }

  if (s.command === 'create') {
    if (s.step === 'trigger') {
      const v = validateTrigger(text);
      if (!v.ok) { await ctx.reply('⚠️ Texto inválido.\n\nDigite novamente ou envie *0* para cancelar.'); return { handled: true }; }
      s.temporaryData.triggerText = v.value; s.temporaryData.normalizedTrigger = normalizeText(v.value, baseNormalization()); s.step = 'emoji';
      await ctx.reply('😀 *AGORA ENVIE A REAÇÃO*\n\nEnvie o emoji que o bot deverá utilizar.\n\nDigite *0* para cancelar.'); return { handled: true };
    }
    if (s.step === 'emoji') {
      const v = validateEmoji(text);
      if (!v.ok) { await ctx.reply('⚠️ Não consegui identificar uma reação válida.\n\nEnvie um emoji válido ou *0* para cancelar.'); return { handled: true }; }
      s.temporaryData.emoji = v.value; s.step = 'scope';
      await ctx.reply('🌎 *ESCOLHA O ALCANCE*\n\n1️⃣ LOCAL\nA reação funcionará somente nos grupos selecionados.\n\n2️⃣ GLOBAL\nA reação funcionará em todos os grupos abrangidos pelo modo global.\n\n3️⃣ GLOBAL + PV\nA reação funcionará nos grupos e conversas privadas abrangidos.\n\nDigite *0* para cancelar.'); return { handled: true };
    }
    if (s.step === 'scope') {
      const scope = { '1': SCOPES.LOCAL, '2': SCOPES.GLOBAL, '3': SCOPES.GLOBAL_PRIVATE }[text];
      if (!scope) { await ctx.reply('⚠️ Opção inválida.\n\n1️⃣ LOCAL\n2️⃣ GLOBAL\n3️⃣ GLOBAL + PV\n\nOu *0* para cancelar.'); return { handled: true }; }
      s.temporaryData.scope = scope;
      if (scope === SCOPES.LOCAL) { s.step = 'groups'; const groups = await getGroups(ctx); s.temporaryData.availableGroups = groups; if (!groups.length) { await ctx.reply('⚠️ Nenhum grupo disponível foi encontrado. Altere para GLOBAL ou tente novamente.'); clear(ctx.sender); return { handled: true }; } await ctx.reply(`📋 *GRUPOS DISPONÍVEIS*\n\n${groups.map((g,i)=>`${i+1}. ${g.name}`).join('\n')}\n\nEnvie os números separados por vírgula.\nExemplo: *1, 4, 7*\n\nDigite *0* para cancelar.`); return { handled: true }; }
      s.step = 'matchMode'; await ctx.reply('🔎 *COMO O TEXTO DEVE SER IDENTIFICADO?*\n\n1️⃣ EXATO\n2️⃣ PALAVRA\n3️⃣ CONTÉM\n\nDigite *0* para cancelar.'); return { handled: true };
    }
    if (s.step === 'groups') {
      const groups = s.temporaryData.availableGroups || [];
      const nums = parseIndices(text, groups.length);
      if (!nums.length || nums.length > MAX_GROUPS) { await ctx.reply(`⚠️ Seleção inválida. Escolha números válidos, sem ultrapassar ${MAX_GROUPS} grupos.`); return { handled: true }; }
      s.temporaryData.groups = [...new Map(nums.map(i => [groups[i-1].id, groups[i-1]])).values()]; s.step = 'matchMode';
      await ctx.reply(`✅ *GRUPOS SELECIONADOS*\n\n${fmtGroups(s.temporaryData.groups)}\n\nTotal: ${s.temporaryData.groups.length}\n\n🔎 *COMO O TEXTO DEVE SER IDENTIFICADO?*\n\n1️⃣ EXATO\n2️⃣ PALAVRA\n3️⃣ CONTÉM\n\nDigite *0* para cancelar.`); return { handled: true };
    }
    if (s.step === 'matchMode') {
      const mode = { '1': MATCH_MODES.EXACT, '2': MATCH_MODES.WORD, '3': MATCH_MODES.CONTAINS }[text] || parseMatchMode(text);
      if (!mode) { await ctx.reply('⚠️ Opção inválida.\n\n1️⃣ EXATO\n2️⃣ PALAVRA\n3️⃣ CONTÉM\n\nOu *0* para cancelar.'); return { handled: true }; }
      s.temporaryData.matchMode = mode; s.step = 'confirm';
      const d = s.temporaryData;
      await ctx.reply(`📋 *RESUMO DA CONFIGURAÇÃO*\n\n📝 Texto: ${d.triggerText}\n😀 Reação: ${d.emoji}\n🔎 Modo: ${d.matchMode}\n📍 Alcance: ${d.scope}\n${d.scope === SCOPES.LOCAL ? `\n👥 Grupos:\n${fmtGroups(d.groups)}\n\n📊 Total de grupos: ${d.groups.length}` : ''}\n\n🟢 Status: ATIVA\n\nDeseja salvar?\n\n1️⃣ SIM\n2️⃣ NÃO\n\nDigite 0 para cancelar.`); return { handled: true };
    }
    if (s.step === 'confirm') {
      if (no(text)) { await cancelled(ctx, s); return { handled: true }; }
      if (!yes(text)) { await ctx.reply('⚠️ Opção inválida.\n\n1️⃣ SIM\n2️⃣ NÃO\n\nOu 0 para cancelar.'); return { handled: true }; }
      const d = s.temporaryData;
      const equivalent = listReactions().find(r => r.status !== STATUSES.DELETED && r.normalizedTrigger === d.normalizedTrigger && r.scope === d.scope && (d.scope !== SCOPES.LOCAL || JSON.stringify([...(r.groups || [])].sort()) === JSON.stringify([...(d.groups || []).map(x=>x.id)].sort())));
      if (equivalent) { await ctx.reply(`⚠️ *JÁ EXISTE UMA REAÇÃO PARA ESTE TEXTO*\n\n📝 Texto: ${equivalent.triggerText}\n😀 Reação atual: ${equivalent.emoji}\n\n1️⃣ Substituir a configuração existente\n2️⃣ Cancelar`); s.step = 'duplicateConfirm'; return { handled: true }; }
      const created = await createReaction({ ownerId: ctx.sender, triggerText: d.triggerText, normalizedTrigger: d.normalizedTrigger, emoji: d.emoji, matchMode: d.matchMode, scope: d.scope, status: STATUSES.ACTIVE, groups: (d.groups || []).map(x => x.id), normalization: baseNormalization(), cooldownMs: 0 });
      await audit('REACTION_CREATED', { reactionId: created.reactionId, actorUserId: ctx.sender, oldValue: null, newValue: created }); clear(ctx.sender);
      await ctx.reply(`✅ *REAÇÃO CONFIGURADA COM SUCESSO!*\n\n📝 ${created.triggerText} → ${created.emoji}\n📍 ${created.scope}${created.scope === SCOPES.LOCAL ? `\n👥 ${created.groups.length} grupos` : ''}\n\nID:\n*${created.reactionId}*\n\n🟢 ATIVA`); return { handled: true };
    }
    if (s.step === 'duplicateConfirm') {
      if (no(text)) { await cancelled(ctx, s); return { handled: true }; }
      if (!yes(text)) { await ctx.reply('⚠️ Opção inválida.\n\n1️⃣ SUBSTITUIR\n2️⃣ CANCELAR\n\nOu 0 para cancelar.'); return { handled: true }; }
      const d = s.temporaryData; const existing = listReactions().find(r => r.status !== STATUSES.DELETED && r.normalizedTrigger === d.normalizedTrigger && r.scope === d.scope);
      if (!existing) { s.step = 'confirm'; await ctx.reply('⚠️ A configuração anterior não está mais disponível. Confirme novamente.'); return { handled: true }; }
      const before = { ...existing }; const updated = await updateReaction(existing.reactionId, { triggerText: d.triggerText, normalizedTrigger: d.normalizedTrigger, emoji: d.emoji, matchMode: d.matchMode, groups: (d.groups || []).map(x => x.id), updatedAt: Date.now(), status: STATUSES.ACTIVE, deletedAt: null }); await audit('REACTION_UPDATED', { reactionId: existing.reactionId, actorUserId: ctx.sender, oldValue: before, newValue: updated }); clear(ctx.sender); await ctx.reply(`✅ Configuração *${existing.reactionId}* substituída com sucesso.`); return { handled: true };
    }
  }
  return { handled: true };
}

export async function startEdit(ctx, id = null) {
  if (!owner(ctx)) return unauthorized(ctx);
  const reactions = listReactions();
  if (!reactions.length) return ctx.reply('🤖 Nenhuma reação configurada.');
  if (id) { const resolved = /^\d+$/.test(String(id)) ? reactions[Number(id) - 1]?.reactionId : String(id); return resolved ? showEditMenu(ctx, resolved) : ctx.reply('⚠️ Reação não encontrada.'); }
  const s = newSession(ctx, 'edit'); s.temporaryData.reactions = reactions; s.step = 'select';
  await ctx.reply(`🤖 *REAÇÕES PARA EDIÇÃO*\n\n${reactions.map((r,i)=>`${i+1}️⃣ ${r.triggerText} → ${r.emoji}`).join('\n')}\n\nDigite o número da reação que deseja editar.\n\nDigite *0* para cancelar.`); return { handled: true };
}
async function showEditMenu(ctx, id) {
  const r = getReaction(id); if (!r || r.status === STATUSES.DELETED) return ctx.reply('⚠️ Reação não encontrada.');
  const options = r.scope === SCOPES.LOCAL ? '1️⃣ Editar emoji\n2️⃣ Editar nome/texto\n3️⃣ Excluir reação\n4️⃣ Editar/trocar grupos\n5️⃣ Alterar alcance\n6️⃣ Ativar/desativar\n0️⃣ Cancelar' : '1️⃣ Editar emoji\n2️⃣ Editar nome/texto\n3️⃣ Excluir reação\n4️⃣ Alterar alcance\n5️⃣ Ativar/desativar\n0️⃣ Cancelar';
  const s = newSession(ctx, 'editAction'); s.temporaryData.reactionId = id; s.temporaryData.reaction = r; s.step = 'action';
  return ctx.reply(`⚙️ *EDITAR REAÇÃO*\n\n📝 Texto: ${r.triggerText}\n😀 Emoji: ${r.emoji}\n📍 Alcance: ${r.scope}\n🟢 Status: ${r.status}\n\nO que deseja fazer?\n${options}`);
}

async function editAction(ctx, s, text) {
  const r = getReaction(s.temporaryData.reactionId); if (!r) { clear(ctx.sender); return ctx.reply('⚠️ Reação não encontrada.'); }
  const local = r.scope === SCOPES.LOCAL;
  const map = local ? {1:'emoji',2:'text',3:'delete',4:'groups',5:'scope',6:'toggle'} : {1:'emoji',2:'text',3:'delete',4:'scope',5:'toggle'};
  const action = map[text]; if (!action) return ctx.reply('⚠️ Opção inválida.\n\nEscolha uma opção válida ou 0 para cancelar.');
  if (action === 'emoji') { s.step='newEmoji'; return ctx.reply(`😀 *EDITAR EMOJI*\n\nEmoji atual: ${r.emoji}\n\nEnvie o novo emoji.\n\nDigite 0 para cancelar.`); }
  if (action === 'text') { s.step='newText'; return ctx.reply(`📝 *EDITAR TEXTO*\n\nTexto atual: ${r.triggerText}\n\nDigite o novo texto.\n\nDigite 0 para cancelar.`); }
  if (action === 'delete') { s.step='deleteConfirm'; return ctx.reply(`⚠️ *EXCLUIR REAÇÃO*\n\n📝 Texto: ${r.triggerText}\n😀 Emoji: ${r.emoji}\n📍 Alcance: ${r.scope}\nID: ${r.reactionId}\n\nDeseja realmente excluir?\n\n1️⃣ CONFIRMAR\n2️⃣ CANCELAR`); }
  if (action === 'groups') { s.step='groupAction'; return ctx.reply('👥 *EDITAR GRUPOS*\n\n1️⃣ Substituir todos os grupos\n2️⃣ Adicionar grupos\n3️⃣ Remover grupos\n4️⃣ Voltar\n0️⃣ Cancelar'); }
  if (action === 'scope') { s.step='scopeSelect'; return ctx.reply('🌎 *ALTERAR ALCANCE*\n\n1️⃣ LOCAL\n2️⃣ GLOBAL\n3️⃣ GLOBAL + PV\n\nDigite 0 para cancelar.'); }
  if (action === 'toggle') { const next = r.status === STATUSES.ACTIVE ? STATUSES.INACTIVE : STATUSES.ACTIVE; const updated=await updateReaction(r.reactionId,{status:next}); await audit(next==='ACTIVE'?'REACTION_ENABLED':'REACTION_DISABLED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:r.status,newValue:next}); clear(ctx.sender); return ctx.reply(`${next==='ACTIVE'?'🟢':'🔴'} *REAÇÃO ${next==='ACTIVE'?'ATIVADA':'DESATIVADA'}*\n\n${r.triggerText} → ${r.emoji}`); }
}

async function editSession(ctx, s, text) {
  if (s.step === 'select') { const i=Number(text); const r=s.temporaryData.reactions?.[i-1]; if (!Number.isInteger(i)||!r) return ctx.reply('⚠️ Número inválido.'); clear(ctx.sender); return showEditMenu(ctx,r.reactionId); }
  const r=getReaction(s.temporaryData.reactionId); if(!r) {clear(ctx.sender);return ctx.reply('⚠️ Reação não encontrada.');}
  if(s.step==='action') return editAction(ctx,s,text);
  if(s.step==='newEmoji'){const v=validateEmoji(text);if(!v.ok)return ctx.reply('⚠️ Emoji inválido. Envie outro ou 0 para cancelar.');s.temporaryData.newEmoji=v.value;s.step='newEmojiConfirm';return ctx.reply(`🔄 *CONFIRMAR ALTERAÇÃO*\n\nTexto: ${r.triggerText}\nEmoji anterior: ${r.emoji}\nNovo emoji: ${v.value}\n\nSalvar alteração?\n\n1️⃣ SIM\n2️⃣ NÃO\n\n0️⃣ Cancelar`);}
  if(s.step==='newEmojiConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Alteração cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 para confirmar ou 2 para cancelar.');const before=r.emoji;const v=s.temporaryData.newEmoji;await updateReaction(r.reactionId,{emoji:v});await audit('REACTION_EMOJI_UPDATED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:before,newValue:v});clear(ctx.sender);return ctx.reply(`✅ Emoji atualizado com sucesso!\n\n${r.triggerText} → ${v}`);}
  if(s.step==='newText'){const v=validateTrigger(text);if(!v.ok)return ctx.reply('⚠️ Texto inválido.');const n=normalizeText(v.value,baseNormalization());const dup=listReactions().find(x=>x.reactionId!==r.reactionId&&x.status!=='DELETED'&&x.normalizedTrigger===n&&x.scope===r.scope);if(dup)return ctx.reply(`⚠️ Já existe *${dup.reactionId}* para este texto neste escopo.`);s.temporaryData.newText=v.value;s.temporaryData.newNormalized=n;s.step='newTextConfirm';return ctx.reply(`🔄 *CONFIRMAR ALTERAÇÃO*\n\nTexto anterior: ${r.triggerText}\nNovo texto: ${v.value}\nEmoji: ${r.emoji}\n\nSalvar?\n\n1️⃣ SIM\n2️⃣ NÃO\n\n0️⃣ Cancelar`);}
  if(s.step==='newTextConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Alteração cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 para confirmar ou 2 para cancelar.');const before=r.triggerText;const v=s.temporaryData.newText;await updateReaction(r.reactionId,{triggerText:v,normalizedTrigger:s.temporaryData.newNormalized});await audit('REACTION_TEXT_UPDATED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:before,newValue:v});clear(ctx.sender);return ctx.reply(`✅ Texto atualizado com sucesso!\n\n${v} → ${r.emoji}`);}
  if(s.step==='deleteConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Exclusão cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 para confirmar ou 2 para cancelar.');await deleteReaction(r.reactionId,ctx.sender);await audit('REACTION_DELETED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:r,newValue:{status:'DELETED'}});clear(ctx.sender);return ctx.reply(`✅ *REAÇÃO EXCLUÍDA COM SUCESSO*\n\nID: ${r.reactionId}`);}
  if(s.step==='scopeSelect'){const scope={'1':SCOPES.LOCAL,'2':SCOPES.GLOBAL,'3':SCOPES.GLOBAL_PRIVATE}[text];if(!scope)return ctx.reply('⚠️ Escopo inválido.');s.temporaryData.newScope=scope;if(scope===SCOPES.LOCAL){const groups=await getGroups(ctx);s.temporaryData.availableGroups=groups;s.step='scopeLocalGroups';return ctx.reply(`📋 *GRUPOS DISPONÍVEIS*\n\n${groups.map((g,i)=>`${i+1}. ${g.name}`).join('\n')}\n\nSelecione os números separados por vírgula.`);}s.step='scopeConfirm';return ctx.reply(`🔄 *ALTERAR PARA ${scope}*\n\nA reação passará a funcionar no escopo ${scope}.\n\nConfirmar?\n\n1️⃣ SIM\n2️⃣ NÃO`);}
  if(s.step==='scopeConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Alteração de alcance cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 ou 2.');const before=r.scope;const scope=s.temporaryData.newScope;await updateReaction(r.reactionId,{scope});await audit('REACTION_SCOPE_UPDATED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:before,newValue:scope});clear(ctx.sender);return ctx.reply(`✅ Alcance alterado para *${scope}*.`);}
  if(s.step==='scopeLocalGroups'){const groups=s.temporaryData.availableGroups||[];const nums=parseIndices(text,groups.length);if(!nums.length)return ctx.reply('⚠️ Seleção inválida.');const ids=nums.map(i=>groups[i-1].id);s.temporaryData.newGroups=ids;s.step='scopeLocalConfirm';return ctx.reply(`🔄 *CONFIRMAR ALCANCE LOCAL*\n\nGrupos selecionados: ${ids.length}\n\nSalvar?\n\n1️⃣ SIM\n2️⃣ NÃO`);}
  if(s.step==='scopeLocalConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Alteração cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 ou 2.');const before={scope:r.scope,groups:getReactionGroups(r.reactionId)};const ids=s.temporaryData.newGroups;await updateReaction(r.reactionId,{scope:SCOPES.LOCAL,groups:ids});await audit('REACTION_SCOPE_UPDATED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:before,newValue:{scope:'LOCAL',groups:ids}});clear(ctx.sender);return ctx.reply('✅ Alcance e grupos atualizados.');}
  if(s.step==='groupAction'){const a=text;if(a==='4'){clear(ctx.sender);return showEditMenu(ctx,r.reactionId);}if(!['1','2','3'].includes(a))return ctx.reply('⚠️ Escolha 1, 2, 3, 4 ou 0.');const groups=await getGroups(ctx);s.temporaryData.availableGroups=groups;s.temporaryData.groupAction=a;s.step='groupSelect';const current=getReactionGroups(r.reactionId);await ctx.reply(`👥 *${a==='1'?'SUBSTITUIR':a==='2'?'ADICIONAR':'REMOVER'} GRUPOS*\n\n${groups.map((g,i)=>`${i+1}. ${g.name}${current.includes(g.id)?' • atual':''}`).join('\n')}\n\nEnvie os números separados por vírgula.`);return {handled:true};}
  if(s.step==='groupSelect'){const groups=s.temporaryData.availableGroups||[];const nums=parseIndices(text,groups.length);if(!nums.length)return ctx.reply('⚠️ Seleção inválida.');const ids=nums.map(i=>groups[i-1].id);const current=getReactionGroups(r.reactionId);let next=ids;if(s.temporaryData.groupAction==='2')next=[...new Set([...current,...ids])];if(s.temporaryData.groupAction==='3')next=current.filter(id=>!ids.includes(id));if(!next.length)return ctx.reply('⚠️ A reação LOCAL precisa possuir pelo menos um grupo.');s.temporaryData.nextGroups=next;s.step='groupConfirm';return ctx.reply(`🔄 *CONFIRMAR GRUPOS*\n\nTotal anterior: ${current.length}\nNovo total: ${next.length}\n\nSalvar alteração?\n\n1️⃣ SIM\n2️⃣ NÃO`);}
  if(s.step==='groupConfirm'){if(no(text)){clear(ctx.sender);return ctx.reply('❌ Alteração de grupos cancelada.');}if(!yes(text))return ctx.reply('⚠️ Digite 1 ou 2.');const current=getReactionGroups(r.reactionId);const next=s.temporaryData.nextGroups;await updateReaction(r.reactionId,{scope:SCOPES.LOCAL,groups:next});await audit('REACTION_GROUPS_UPDATED',{reactionId:r.reactionId,actorUserId:ctx.sender,oldValue:current,newValue:next});clear(ctx.sender);return ctx.reply(`✅ Grupos atualizados.\n\nTotal: ${next.length}`);}
  return ctx.reply('⚠️ Sessão em estado inválido. Envie 0 para cancelar.');
}

function parseIndices(text,max){const raw=String(text).split(',').map(x=>Number(x.trim())).filter(Number.isInteger);const uniq=[...new Set(raw)];return uniq.filter(n=>n>=1&&n<=max);}
function escape(s){return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');}

export async function handleAnySession(ctx){ if(!owner(ctx)) return {handled:false}; const s=getSession(ctx.sender); if(!s)return {handled:false}; if(s.__expired){clear(ctx.sender); await expired(ctx,s); return {handled:true,expired:true};} const text=String(ctx.body??ctx.text??'').trim(); if(cancelValue(text)){await cancelled(ctx,s);return {handled:true};} if(s.command.startsWith('edit')) return editSession(ctx,s,text); return handleSession(ctx); }

async function unauthorized(ctx){ if(ctx.reply) await ctx.reply('❌ *ACESSO NEGADO*\n\nO sistema de reações é exclusivo do dono do bot.'); await audit('REACTION_UNAUTHORIZED_ACCESS',{actorUserId:ctx.sender,groupId:ctx.isGroup?ctx.from:null,metadata:{command:ctx.command||'react'}}); return {handled:true,unauthorized:true}; }
export { unauthorized, getSession, clear, SESSION_TTL, MAX_GROUPS, MAX_REACTIONS, MAX_EXECUTIONS_WINDOW };
