const providers = new Map();
export function registerProvider(provider) {
  if (!provider?.type || typeof provider.send !== 'function') throw new Error('Provider inválido.');
  providers.set(String(provider.type).toUpperCase(), Object.freeze(provider));
  return provider;
}
export function getProvider(type) { return providers.get(String(type || '').toUpperCase()) || null; }
export function hasProvider(type) { return !!getProvider(type); }
export function listProviders() { return [...providers.values()]; }
export function clearProviders() { providers.clear(); }
export default { registerProvider, getProvider, hasProvider, listProviders, clearProviders };
