import registry from './ReactionProviderRegistry.js'; import { registerProvider } from './ReactionProviderRegistry.js';
import Emoji from './providers/EmojiReactionProvider.js'; import { createMediaProvider } from './providers/MediaReactionProvider.js'; import service from './ReactionService.js';
let initialized=false;
export function initialize(){ if(initialized) return; [Emoji,createMediaProvider('STICKER','Figurinha','🎟️'),createMediaProvider('AUDIO','Áudio','🔊'),createMediaProvider('IMAGE','Imagem','🖼️')].forEach(registerProvider); initialized=true; }
export async function enrich(ctx,args){ initialize(); return service.enrich(ctx,args); }
export function providers(){ initialize(); return registry.listProviders(); }
export default {initialize,enrich,providers};
