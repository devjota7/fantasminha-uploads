import { readReactionMedia } from '../ReactionMediaStorage.js';
const TYPES={STICKER:'STICKER',AUDIO:'AUDIO',IMAGE:'IMAGE'};
function mime(type, cfg){ return cfg.mimeType || (type==='IMAGE'?'image/jpeg':type==='AUDIO'?'audio/mpeg':'image/webp'); }
export function createMediaProvider(type,label,icon){
  return { type,label,icon,
    validate(value){ return value?.reference ? {ok:true,value} : {ok:false,reason:'media_missing'}; },
    async send(ctx,config){
      if(!ctx?.sendMessage||!ctx?.from) throw new Error('Transporte indisponível.');
      const buffer=readReactionMedia(config.reference); const mt=mime(type,config);
      if(type===TYPES.STICKER) return ctx.sendMessage(ctx.from,{sticker:buffer});
      if(type===TYPES.AUDIO) return ctx.sendMessage(ctx.from,{audio:buffer,mimetype:mt,ptt:!!config.ptt});
      return ctx.sendMessage(ctx.from,{image:buffer,caption:config.caption||''});
    }
  };
}
export default { createMediaProvider };
