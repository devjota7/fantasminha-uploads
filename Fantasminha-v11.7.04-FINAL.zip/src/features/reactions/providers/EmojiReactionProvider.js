import { validateEmoji } from '../ReactionValidator.js';
export default {
  type:'EMOJI', label:'Emoji', icon:'😀',
  validate(value){ return validateEmoji(value); },
  async send(ctx, config, targetKey){
    if (!targetKey || !ctx?.sendMessage || !ctx?.from) throw new Error('Alvo de reação indisponível.');
    const v=validateEmoji(config.value); if(!v.ok) throw new Error('Emoji inválido.');
    return ctx.sendMessage(ctx.from,{react:{text:v.value,key:targetKey}});
  }
};
