import { listResponseReactions } from './ReactionRepository.js';
export function resolve(responseKey){ return listResponseReactions(responseKey).filter(x=>x.status==='ACTIVE'); }
export default {resolve};
