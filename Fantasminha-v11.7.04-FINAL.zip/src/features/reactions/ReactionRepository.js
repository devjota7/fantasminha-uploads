import { readCollection, updateCollection } from '../../database/store.js';

const CONFIG = 'reaction_configs';
const GROUPS = 'reaction_groups';
const AUDIT = 'reaction_audit';
const STATS = 'reaction_stats';

const defaults = {
  configs: {},
  nextId: 1,
  groups: {},
  audit: [],
  stats: {}
};

export function makeReactionId(n) { return `RX-${String(n).padStart(6, '0')}`; }
export function readConfigs() { return readCollection(CONFIG, { configs: {}, nextId: 1 }); }
export function readGroups() { return readCollection(GROUPS, { byReaction: {} }); }
export function readStats() { return readCollection(STATS, { byReaction: {}, totals: { executions: 0 } }); }
export function readAudit(limit = 100) {
  const d = readCollection(AUDIT, { events: [] });
  return d.events.slice(-Math.max(1, Number(limit) || 100)).reverse();
}

export async function createReaction(data) {
  const now = Date.now();
  let created;
  await updateCollection(CONFIG, db => {
    db.configs ||= {};
    db.nextId ||= 1;
    const id = makeReactionId(db.nextId++);
    const { groups: _groups, ...configData } = data;
    created = { reactionId: id, ...configData, createdAt: now, updatedAt: now, deletedAt: null, lastExecutedAt: null, executionCount: 0 };
    db.configs[id] = created;
    return db;
  }, { configs: {}, nextId: 1 });
  await updateCollection(GROUPS, db => {
    db.byReaction ||= {};
    db.byReaction[created.reactionId] = [...new Set(data.groups || [])];
    return db;
  }, { byReaction: {} });
  created.groups = [...new Set(data.groups || [])];
  return created;
}

export async function updateReaction(id, patch) {
  let out = null;
  await updateCollection(CONFIG, db => {
    const current = db.configs?.[id];
    if (!current) return db;
    out = { ...current, ...patch, updatedAt: Date.now() };
    db.configs[id] = out;
    return db;
  }, { configs: {}, nextId: 1 });
  if (patch.groups) await updateCollection(GROUPS, db => { db.byReaction ||= {}; db.byReaction[id] = [...new Set(patch.groups)]; return db; }, { byReaction: {} });
  return out;
}

export async function deleteReaction(id, actorId) {
  return updateReaction(id, { status: 'DELETED', deletedAt: Date.now(), deletedBy: actorId });
}

export async function recordExecution(id) {
  await updateCollection(CONFIG, db => {
    const c = db.configs?.[id];
    if (c) { c.executionCount = Number(c.executionCount || 0) + 1; c.lastExecutedAt = Date.now(); }
    return db;
  }, { configs: {}, nextId: 1 });
  await updateCollection(STATS, db => {
    db.byReaction ||= {};
    db.totals ||= { executions: 0 };
    const s = db.byReaction[id] ||= { executions: 0, lastExecutedAt: null };
    s.executions++;
    s.lastExecutedAt = Date.now();
    db.totals.executions++;
    return db;
  }, { byReaction: {}, totals: { executions: 0 } });
}

export async function appendAudit(event) {
  await updateCollection(AUDIT, db => {
    db.events ||= [];
    db.events.push({ eventId: event.eventId || `RXAUD-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, timestamp: Date.now(), ...event });
    if (db.events.length > 20000) db.events.splice(0, db.events.length - 20000);
    return db;
  }, { events: [] });
}

export function listReactions({ includeDeleted = false } = {}) {
  const d = readConfigs();
  const g = readGroups();
  return Object.values(d.configs || {}).filter(c => includeDeleted || c.status !== 'DELETED').map(c => ({ ...c, groups: g.byReaction?.[c.reactionId] || c.groups || [] })).sort((a, b) => a.createdAt - b.createdAt);
}

export function getReaction(id) { return readConfigs().configs?.[id] || null; }
export function getReactionGroups(id) { return readGroups().byReaction?.[id] || []; }

export default { makeReactionId, createReaction, updateReaction, deleteReaction, recordExecution, appendAudit, listReactions, getReaction, getReactionGroups, readStats, readAudit };

export function listResponseReactions(responseKey, { includeDeleted = false } = {}) {
  return listReactions({ includeDeleted }).filter(r => r.responseKey === responseKey && r.reactionType);
}
export function getResponseReaction(responseKey, reactionType) {
  return listResponseReactions(responseKey, { includeDeleted:true }).find(r => r.reactionType === String(reactionType).toUpperCase()) || null;
}
export async function upsertResponseReaction(data) {
  const type=String(data.reactionType||'').toUpperCase(); const existing=getResponseReaction(data.responseKey,type);
  if(existing) return updateReaction(existing.reactionId,{...data,reactionType:type,status:data.status||'ACTIVE',deletedAt:null});
  return createReaction({...data,reactionType:type,status:data.status||'ACTIVE'});
}
export async function recordResponseExecution(id) { return recordExecution(id); }
