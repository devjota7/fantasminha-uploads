import { configuredOwner } from '../../core/permissions.js';
import { listReactions, getReaction, getReactionGroups, updateReaction, deleteReaction } from './ReactionRepository.js';
import { audit, history } from './ReactionAuditService.js';
import { stats } from './ReactionStatsService.js';
import { startCreate, startEdit, handleAnySession, unauthorized } from './ReactionSessionService.js';
import { execute } from './ReactionExecutor.js';
import { SCOPES } from './ReactionValidator.js';
import { resolveAvailableGroups } from './ReactionScopeResolver.js';
import responseSession from './ReactionResponseSessionService.js';
import engine from './ReactionEngine.js';

export function isOwner(ctx) { return !!ctx && (ctx.isOwner === true || configuredOwner(ctx.sender)); }
export async function handleSessionMessage(ctx) { return handleAnySession(ctx); }
export async function executeAutomatic(ctx) { return execute(ctx); }

function formatReaction(r, i = null) {
  const prefix = i == null ? '' : `${i + 1}️⃣ `;
  const scope = r.scope === SCOPES.LOCAL ? '📍 LOCAL' : `🌎 ${r.scope}`;
  return `${prefix}${r.triggerText} → ${r.emoji} · ${scope} · ${r.status === 'ACTIVE' ? '🟢 ATIVA' : '🔴 INATIVA'}`;
}
function date(v) { return v ? new Date(v).toLocaleString('pt-BR') : '—'; }

export async function list(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  const rows = listReactions();
  if (!rows.length) return ctx.reply('🤖 *REAÇÕES CONFIGURADAS*\n\nNenhuma reação cadastrada.');
  const pageSize = 10;
  const page = Math.max(1, Number(ctx.args?.[1] || ctx.args?.[0] || 1) || 1);
  const pages = Math.ceil(rows.length / pageSize);
  const slice = rows.slice((page - 1) * pageSize, page * pageSize);
  let out = `🤖 *REAÇÕES — PÁGINA ${page}/${pages}*\n\n`;
  out += slice.map((r, idx) => {
    const n = (page - 1) * pageSize + idx;
    const base = formatReaction(r, n);
    if (r.scope === SCOPES.LOCAL) return `${base}\n   👥 ${(r.groups || []).length} grupo(s)\n   📅 ${date(r.createdAt)}`;
    return `${base}\n   📅 ${date(r.createdAt)}`;
  }).join('\n\n');
  out += `\n\nTotal: ${rows.length} reações\nPágina ${page} de ${pages}`;
  return ctx.reply(out);
}

export async function info(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  let id = String(ctx.args?.[0] || '').trim();
  const rows = listReactions();
  if (!id) { const first = rows[0]; if (!first) return ctx.reply('🤖 Nenhuma reação configurada.'); id = first.reactionId; }
  if (/^\d+$/.test(id)) id = rows[Number(id) - 1]?.reactionId || '';
  const r = getReaction(id);
  if (!r || r.status === 'DELETED') return ctx.reply('⚠️ Reação não encontrada.');
  const groupIds = getReactionGroups(id);
  let groupNames = groupIds.map(g => `• ${g}`);
  try { const available = resolveAvailableGroups(await ctx.listGroups?.()); const byId = new Map(available.map(g => [g.id, g.name])); groupNames = groupIds.map(g => `• ${byId.get(g) || `${g} (indisponível)`}`); } catch {}
  const out = `🤖 *DETALHES DA REAÇÃO*\n\nID:\n${r.reactionId}\n\n📝 Texto:\n${r.triggerText}\n\n😀 Reação:\n${r.emoji}\n\n🔎 Modo:\n${r.matchMode}\n\n🌎 Alcance:\n${r.scope}\n\n${r.scope === SCOPES.LOCAL ? `👥 Grupos configurados: ${groupIds.length}\n${groupNames.join('\n')}\n\n` : ''}🟢 Status:\n${r.status}\n\n📅 Criada em:\n${date(r.createdAt)}\n\n🔄 Última alteração:\n${date(r.updatedAt)}\n\n📊 Total de execuções:\n${Number(r.executionCount || 0)}`;
  return ctx.reply(out);
}

export async function showStats(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  const s = stats();
  return ctx.reply(`📊 *ESTATÍSTICAS DE REAÇÕES*\n\nTotal configuradas: ${s.total}\nAtivas: ${s.active}\nDesativadas: ${s.inactive}\nLocais: ${s.local}\nGlobais: ${s.global}\n\nTotal de execuções: ${s.executions}\n\nMais utilizada:\n${s.mostUsed ? `${s.mostUsed.emoji} ${s.mostUsed.triggerText}\nExecuções: ${Number(s.mostUsed.executionCount || 0)}` : '—'}`);
}

export async function showHistory(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  const rows = history(Math.min(50, Number(ctx.args?.[0]) || 20));
  if (!rows.length) return ctx.reply('📜 *HISTÓRICO DE REAÇÕES*\n\nNenhum evento registrado.');
  return ctx.reply(`📜 *HISTÓRICO DE REAÇÕES*\n\n${rows.map(e => `${date(e.timestamp)}\n${e.reactionId || '—'}\n${e.eventType}${e.oldValue != null || e.newValue != null ? `\n${JSON.stringify(e.oldValue)} → ${JSON.stringify(e.newValue)}` : ''}`).join('\n\n')}`);
}

export async function clearAll(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  const rows = listReactions();
  if (!rows.length) return ctx.reply('🤖 Não há configurações para limpar.');
  if (String(ctx.args?.[0] || '').toLowerCase() !== 'confirmar') {
    ctx._reactionClearPending = true;
    return ctx.reply(`⚠️ *LIMPEZA DE REAÇÕES*\n\nTotal de configurações: ${rows.length}\n\nEsta operação desativará todas as configurações ativas usando soft delete.\n\nPara confirmar, responda *CONFIRMAR* ou use:\n${ctx.prefix}react limpar confirmar\n\nPara cancelar: *0*`);
  }
  let count = 0;
  for (const r of rows) { if (r.status !== 'DELETED') { await deleteReaction(r.reactionId, ctx.sender); await audit('REACTION_DELETED', { reactionId: r.reactionId, actorUserId: ctx.sender, oldValue: r, newValue: { status: 'DELETED' }, metadata: { bulk: true } }); count++; } }
  await audit('REACTIONS_BULK_DELETED', { actorUserId: ctx.sender, metadata: { count } });
  return ctx.reply(`✅ *LIMPEZA CONCLUÍDA*\n\n${count} configuração(ões) removida(s) logicamente.`);
}

export async function help(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  return ctx.reply(`🤖 *REACTION MANAGER*\n\n${ctx.prefix}react\n→ Criar nova reação\n\n${ctx.prefix}react lista\n→ Listar reações\n\n${ctx.prefix}react editar\n→ Editar uma reação\n\n${ctx.prefix}react info [ID|número]\n→ Ver detalhes\n\n${ctx.prefix}react stats\n→ Ver estatísticas\n\n${ctx.prefix}react histórico\n→ Ver histórico\n\n${ctx.prefix}react limpar\n→ Limpeza administrativa\n\n${ctx.prefix}react ajuda\n→ Mostrar ajuda\n\n🔐 Gerenciamento exclusivo do dono.`);
}

export async function dispatch(ctx) {
  if (!isOwner(ctx)) return unauthorized(ctx);
  engine.initialize();
  const sub = String(ctx.args?.[0] || '').toLowerCase();
  // O novo ×react é uma interface do Reaction Engine baseada em responseKey.
  if (!sub) return responseSession.start(ctx, 'EMOJI');
  if (sub === 'lista' || sub === 'listar') return list(ctx);
  if (sub === 'editar' || sub === 'edit') return startEdit(ctx, ctx.args?.[1]);
  if (sub === 'info') return info({ ...ctx, args: ctx.args.slice(1) });
  if (sub === 'stats' || sub === 'estatisticas') return showStats(ctx);
  if (sub === 'histórico' || sub === 'historico') return showHistory({ ...ctx, args: ctx.args.slice(1) });
  if (sub === 'ajuda' || sub === 'help') return help(ctx);
  if (sub === 'limpar') return clearAll({ ...ctx, args: ctx.args.slice(1) });
  if (sub === 'ativar' || sub === 'desativar') {
    const id = ctx.args?.[1]; const r = getReaction(id); if (!r) return ctx.reply('⚠️ Informe um ID válido.');
    const next = sub === 'ativar' ? 'ACTIVE' : 'INACTIVE'; await updateReaction(id, { status: next }); await audit(next === 'ACTIVE' ? 'REACTION_ENABLED' : 'REACTION_DISABLED', { reactionId:id, actorUserId:ctx.sender, oldValue:r.status, newValue:next }); return ctx.reply(`${next === 'ACTIVE' ? '🟢' : '🔴'} Reação ${next === 'ACTIVE' ? 'ativada' : 'desativada'}: ${id}`);
  }
  // Compatibilidade explícita com o antigo formato ×react <gatilho> <emoji>.
  if (ctx.args?.length >= 2) return startCreate({ ...ctx, args: [], q: '', _legacyReactShortcut: { trigger: ctx.args[0], emoji: ctx.args[1] } });
  return help(ctx);
}

export async function handleResponseSession(ctx) { return responseSession.handle(ctx); }
export function initializeEngine() { return engine.initialize(); }

export default { dispatch, handleSessionMessage, handleResponseSession, executeAutomatic, initializeEngine, list, info, showStats, showHistory, clearAll, help };
