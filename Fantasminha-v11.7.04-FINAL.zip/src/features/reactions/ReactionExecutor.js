import { recordExecution } from './ReactionRepository.js';
import { audit } from './ReactionAuditService.js';
import { findMatches } from './ReactionMatcher.js';

const recent = new Map();
const processedMessages = new Map();
const keyFor = (reaction, ctx) => `${reaction.reactionId}:${ctx.from || 'private'}`;

export async function execute(ctx) {
  if (!ctx || ctx.fromMe || ctx.message?.key?.fromMe) return { executed: 0, skipped: 'self' };
  const text = String(ctx.body ?? ctx.text ?? '').trim();
  if (!text) return { executed: 0 };
  const messageId = ctx.message?.key?.id;
  const messageScope = ctx.message?.key?.remoteJid || ctx.from || 'private';
  const messageKey = messageId ? `${messageScope}:${messageId}` : null;
  if (messageKey && processedMessages.has(messageKey)) return { executed: 0, skipped: 'duplicate' };
  if (messageKey) { processedMessages.set(messageKey, Date.now()); if (processedMessages.size > 5000) processedMessages.delete(processedMessages.keys().next().value); }
  const matches = findMatches(text, ctx);
  let executed = 0;
  for (const reaction of matches) {
    const cooldown = Math.max(0, Number(reaction.cooldownMs || 0));
    const k = keyFor(reaction, ctx);
    if (cooldown && Date.now() - Number(recent.get(k) || 0) < cooldown) continue;
    const key = ctx.message?.key;
    if (!key || typeof ctx.sendMessage !== 'function' || !ctx.from) continue;
    try {
      await ctx.sendMessage(ctx.from, { react: { text: reaction.emoji, key } });
      recent.set(k, Date.now());
      await recordExecution(reaction.reactionId);
      await audit('REACTION_EXECUTED', { reactionId: reaction.reactionId, actorUserId: ctx.sender || null, groupId: ctx.isGroup ? ctx.from : null, metadata: { executionCount: reaction.executionCount } });
      executed++;
    } catch (error) {
      await audit('REACTION_EXECUTION_FAILED', { reactionId: reaction.reactionId, actorUserId: ctx.sender || null, groupId: ctx.isGroup ? ctx.from : null, metadata: { error: error.message } });
    }
  }
  return { executed };
}
export default { execute };
