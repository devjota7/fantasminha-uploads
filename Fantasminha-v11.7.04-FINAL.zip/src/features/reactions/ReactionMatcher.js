import { listReactions } from './ReactionRepository.js';
import { matchTrigger } from './ReactionValidator.js';
import { scopeAllows } from './ReactionScopeResolver.js';

export function findMatches(text, ctx) {
  return listReactions().filter(r => r.status === 'ACTIVE' && matchTrigger(text, r) && scopeAllows(r, ctx));
}
export default { findMatches };
