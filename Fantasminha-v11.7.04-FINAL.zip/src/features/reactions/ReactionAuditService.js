import { appendAudit, readAudit } from './ReactionRepository.js';

export async function audit(eventType, { reactionId = null, actorUserId = null, groupId = null, oldValue = null, newValue = null, metadata = {} } = {}) {
  return appendAudit({ reactionId, actorUserId, groupId, eventType, oldValue, newValue, metadata });
}
export function history(limit = 100) { return readAudit(limit); }
export default { audit, history };
