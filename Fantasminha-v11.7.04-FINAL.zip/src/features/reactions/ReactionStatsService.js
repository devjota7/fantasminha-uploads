import { readStats, listReactions } from './ReactionRepository.js';
export function stats() {
  const reactions = listReactions();
  const active = reactions.filter(r => r.status === 'ACTIVE');
  const inactive = reactions.filter(r => r.status === 'INACTIVE');
  const local = reactions.filter(r => r.scope === 'LOCAL');
  const global = reactions.filter(r => r.scope !== 'LOCAL');
  const ranked = [...reactions].sort((a, b) => Number(b.executionCount || 0) - Number(a.executionCount || 0));
  const db = readStats();
  return { total: reactions.length, active: active.length, inactive: inactive.length, local: local.length, global: global.length, executions: Number(db.totals?.executions || 0), mostUsed: ranked[0] || null };
}
export default { stats };
