import { SCOPES } from './ReactionValidator.js';

export function isPrivateContext(ctx) { return !!ctx.isPrivate || !ctx.isGroup; }
export function scopeAllows(reaction, ctx) {
  if (reaction.status !== 'ACTIVE') return false;
  if (reaction.scope === SCOPES.LOCAL) return !!ctx.isGroup && (reaction.groups || []).includes(ctx.from);
  if (reaction.scope === SCOPES.GLOBAL) return !!ctx.isGroup;
  if (reaction.scope === SCOPES.GLOBAL_PRIVATE) return true;
  return false;
}

export function resolveAvailableGroups(groups = []) {
  return [...new Map(groups.filter(g => g?.id).map(g => [g.id, { id: g.id, name: String(g.name || g.subject || g.id) }])).values()]
    .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
}

export default { isPrivateContext, scopeAllows, resolveAvailableGroups };
