export const MATCH_MODES = Object.freeze({ EXACT: 'EXACT', WORD: 'WORD', CONTAINS: 'CONTAINS' });
export const SCOPES = Object.freeze({ LOCAL: 'LOCAL', GLOBAL: 'GLOBAL', GLOBAL_PRIVATE: 'GLOBAL_PRIVATE' });
export const STATUSES = Object.freeze({ ACTIVE: 'ACTIVE', INACTIVE: 'INACTIVE', DELETED: 'DELETED' });

export function normalizeText(value, { foldCase = true, foldAccents = true } = {}) {
  let s = String(value ?? '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  if (foldAccents) s = s.normalize('NFD').replace(/\p{Diacritic}/gu, '');
  if (foldCase) s = s.toLowerCase();
  return s;
}

export function validateTrigger(text, max = 120) {
  const value = String(text ?? '').trim();
  if (!value) return { ok: false, reason: 'empty' };
  if (value.length > max) return { ok: false, reason: 'too_long' };
  return { ok: true, value };
}

export function validateEmoji(value, maxGraphemes = 3) {
  const emoji = String(value ?? '').trim();
  if (!emoji) return { ok: false, reason: 'empty' };
  if (emoji.length > 32) return { ok: false, reason: 'too_long' };
  let graphemes = [...emoji];
  try { if (Intl.Segmenter) graphemes = [...new Intl.Segmenter('pt-BR', { granularity: 'grapheme' }).segment(emoji)].map(x => x.segment); } catch {}
  if (!graphemes.length || graphemes.length > maxGraphemes) return { ok: false, reason: 'invalid_length' };
  const hasEmojiLike = /[\p{Extended_Pictographic}\p{Emoji_Presentation}\p{So}]/u.test(emoji);
  if (!hasEmojiLike) return { ok: false, reason: 'not_emoji' };
  return { ok: true, value: emoji };
}

export function parseMatchMode(value) {
  const v = String(value ?? '').trim().toUpperCase();
  return Object.values(MATCH_MODES).includes(v) ? v : null;
}
export function parseScope(value) {
  const v = String(value ?? '').trim().toUpperCase();
  return Object.values(SCOPES).includes(v) ? v : null;
}
export function matchTrigger(message, config) {
  const text = normalizeText(message, config.normalization || {});
  const trigger = config.normalizedTrigger || normalizeText(config.triggerText, config.normalization || {});
  if (!text || !trigger) return false;
  if (config.matchMode === MATCH_MODES.EXACT) return text === trigger;
  if (config.matchMode === MATCH_MODES.WORD) return new RegExp(`(?:^|\\s)${escapeRegex(trigger)}(?=\\s|$)`, 'u').test(text);
  return text.includes(trigger);
}
export function escapeRegex(s) { return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }

export default { MATCH_MODES, SCOPES, STATUSES, normalizeText, validateTrigger, validateEmoji, parseMatchMode, parseScope, matchTrigger };
