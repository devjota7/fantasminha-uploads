import resolver from './ReactionResolver.js'; import registry from './ReactionProviderRegistry.js'; import { audit } from './ReactionAuditService.js';
import { recordResponseExecution } from './ReactionRepository.js'; import { canEnrichResponse } from './ReactionPolicy.js'; import { getCommand } from '../../core/registry.js';
export async function enrich(ctx,{responseKey,responseMessage,responseMeta={}}={}){
  if(!responseKey) return {executed:0}; const def=getCommand(responseMeta.commandKey||ctx.command||''); const effectiveMeta={...responseMeta,capabilities:def?.responseCapabilities||responseMeta.responseCapabilities||{}}; const configs=resolver.resolve(responseKey); let executed=0;
  for(const cfg of configs){ const policy=canEnrichResponse(effectiveMeta,cfg.reactionType); if(!policy.ok) continue; const p=registry.getProvider(cfg.reactionType); if(!p) continue;
    try { await p.send(ctx,cfg,responseMessage?.key||ctx?.message?.key); await recordResponseExecution(cfg.reactionId); await audit('REACTION_EXECUTED',{reactionId:cfg.reactionId,responseKey,actorUserId:ctx.sender||null,metadata:{provider:cfg.reactionType}}); executed++; }
    catch(e){ await audit('REACTION_EXECUTION_FAILED',{reactionId:cfg.reactionId,responseKey,actorUserId:ctx.sender||null,metadata:{provider:cfg.reactionType,error:e.message}}); }
  }
  return {executed};
}
export default {enrich};
