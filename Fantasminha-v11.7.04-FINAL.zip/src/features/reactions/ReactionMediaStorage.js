import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import config from '../../core/config.js';
export const STORAGE_ROOT=path.join(config.root,'data','reaction-media');
const ensure=()=>fs.mkdirSync(STORAGE_ROOT,{recursive:true});
export function saveReactionMedia(buffer,mediaType,mimeType='application/octet-stream'){
  if(!Buffer.isBuffer(buffer)||!buffer.length) throw new Error('Buffer de mídia inválido.'); ensure();
  const hash=crypto.createHash('sha256').update(buffer).digest('hex');
  const ext=mediaType==='STICKER'?'.webp':mediaType==='AUDIO'?'.ogg':'.jpg';
  const name=`${hash}-${crypto.randomBytes(4).toString('hex')}${ext}`; const abs=path.join(STORAGE_ROOT,name); fs.writeFileSync(abs,buffer,{flag:'wx'});
  return {reference:path.relative(config.root,abs).replaceAll(path.sep,'/'),hash,size:buffer.length,mimeType};
}
export function readReactionMedia(reference){ const rel=String(reference||'').replaceAll('\\','/'); if(!rel.startsWith('data/reaction-media/')||rel.includes('..')) throw new Error('Referência de mídia inválida.'); const abs=path.resolve(config.root,rel); if(!abs.startsWith(path.resolve(STORAGE_ROOT)+path.sep)||!fs.existsSync(abs)) throw new Error('Mídia não encontrada.'); return fs.readFileSync(abs); }
export default {STORAGE_ROOT,saveReactionMedia,readReactionMedia};
