import { getCommand, listCommands } from '../../core/registry.js';
export function getResponseDefinition(responseKeyOrCommand){
  const raw=String(responseKeyOrCommand||'').replace(/^×/,''); const command=raw.startsWith('command.')?raw.split('.')[1]:raw;
  const def=getCommand(command); const cap=def?.responseCapabilities||{};
  return {responseKey:cap.responseKey||`command.${command}.default`,commandKey:command,capabilities:cap,command:def};
}
export function listResponses(){ return listCommands({includeHidden:false}).map(c=>({responseKey:c.responseCapabilities?.responseKey||`command.${c.name}.default`,commandKey:c.name,description:c.description,capabilities:c.responseCapabilities||{}})); }
export default {getResponseDefinition,listResponses};
