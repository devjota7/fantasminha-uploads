import { randomUUID } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';
import { listCommands } from '../../core/registry.js';
import { getResponseMedia, listResponseMedia } from './ResponseMediaRepository.js';
import { getCapabilities } from './ResponseMediaResolver.js';
import service from './ResponseMediaService.js';
import { audit } from './ResponseMediaAuditService.js';
import { MEDIA_TYPES } from './ResponseMediaValidator.js';

const sessions = new Map();
const TTL = Math.max(30_000, Number(process.env.RESPONSE_MEDIA_SESSION_TTL_MS || 180_000));
const cancel = x => /^(0|cancelar|cancel)$/i.test(String(x || '').trim());
const yes = x => String(x || '').trim() === '1';
const no = x => String(x || '').trim() === '2';
const owner = ctx => service.isOwner(ctx);
const LEGACY_BLOCKED = new Set(['menu','menuadmin','ajuda','help','config','admin','perfil','meuperfil','profile','sexo','surubao','goza','gozar','mamar','mamada','beijob','beijarb','tapar']);
function legacyCommands() {
  try {
    const file = path.join(config.root, 'dados', 'src', 'menus', 'commandCatalog.json');
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Object.values(data || {}).flat().map(String).map(x => x.toLowerCase().replace(/^×/, '')).filter(x => x && !LEGACY_BLOCKED.has(x));
  } catch { return []; }
}

function set(ctx, command, data = {}) { const s = { sessionId: randomUUID(), ownerId: ctx.sender, command, step: 'select', data, createdAt: Date.now(), expiresAt: Date.now() + TTL }; sessions.set(ctx.sender, s); return s; }
function get(ctx) { const s = sessions.get(ctx.sender); if (!s) return null; if (Date.now() > s.expiresAt) return { ...s, expired: true }; s.expiresAt = Date.now() + TTL; return s; }
function clear(ctx) { sessions.delete(ctx.sender); }
function compatibleCommands() {
  const registry = listCommands({ includeHidden: false })
    .map(c => ({ name:c.name, description:c.description || '', responseCapabilities:c.responseCapabilities || {} }))
    .filter(c => getCapabilities({ command: c.name }, c).supportsCustomMedia);
  const known = new Map(registry.map(c => [c.name, c]));
  for (const name of legacyCommands()) if (!known.has(name)) known.set(name, { name, description:'Resposta do catálogo legado', responseCapabilities:{ supportsCustomMedia:true, responseKey:`command.${name}.default` } });
  return [...known.values()]
    .filter(c => getCapabilities({ command: c.name }, c).supportsCustomMedia)
    .filter(c => !getCapabilities({ command: c.name }, c).hasNativeMedia && !getCapabilities({ command: c.name }, c).hasDynamicMedia)
    .filter(c => !getResponseMedia(c.responseCapabilities?.responseKey || `command.${c.name}.default`))
    .sort((a, b) => a.name.localeCompare(b.name));
}
function configuredCommands() { return listResponseMedia().map(r => ({ name:r.commandKey, description:'', responseCapabilities:{ responseKey:r.responseKey } })); }
function mediaFromMessage(ctx) {
  const m = ctx?.message?.message || {};
  const image = m.imageMessage || m.viewOnceMessage?.message?.imageMessage || m.viewOnceMessageV2?.message?.imageMessage;
  const video = m.videoMessage || m.viewOnceMessage?.message?.videoMessage || m.viewOnceMessageV2?.message?.videoMessage;
  if (image) return { message: image, mimetype: image.mimetype || 'image/jpeg', filename: 'upload.jpg', isGif: false, kind: 'image' };
  if (video) return { message: video, mimetype: video.mimetype || 'video/mp4', filename: 'upload.mp4', isGif: !!video.gifPlayback || String(video.mimetype || '').includes('gif'), kind: 'video' };
  return null;
}
async function downloadMedia(ctx, media) {
  if (!media) return null;
  const { downloadContentFromMessage } = await import('baileys');
  const stream = await downloadContentFromMessage(media.message, media.kind === 'image' ? 'image' : 'video');
  const chunks = []; for await (const chunk of stream) chunks.push(Buffer.from(chunk)); return Buffer.concat(chunks);
}
function renderSelection() {
  const rows = compatibleCommands().slice(0, 80);
  if (!rows.length) return '🎨 *CONFIGURAR MÍDIA*\n\nNenhuma resposta compatível disponível no Registry.';
  return `🎨 *CONFIGURAR MÍDIA*\n\nEscolha a resposta que deseja personalizar:\n\n${rows.map((c, i) => `${i + 1}. ×${c.name}${c.description ? ` — ${c.description}` : ''}`).join('\n')}\n\n0️⃣ Cancelar`;
}

export async function start(ctx, mode = 'create', responseKey = null) {
  if (!owner(ctx)) { await audit('RESPONSE_MEDIA_UNAUTHORIZED_ACCESS', { ctx, details: { mode } }); return ctx.reply('❌ *ACESSO NEGADO*\n\nO Response Media Manager é exclusivo do dono do bot.'); }
  if (mode === 'create') { set(ctx, 'create'); return ctx.reply(renderSelection()); }
  if (mode === 'edit') { const rows = configuredCommands(); if (!rows.length) return ctx.reply('🎨 *MÍDIAS CONFIGURADAS*\n\nNenhuma personalização cadastrada.'); set(ctx, 'edit', { rows: rows.map(c => c.name) }); return ctx.reply(`✏️ *MÍDIAS PERSONALIZADAS*\n\n${rows.map((c,i)=>`${i+1}. ×${c.name}`).join('\n')}\n\n0️⃣ Cancelar`); }
  if (mode === 'toggle') { const item = getResponseMedia(responseKey); if (!item) return ctx.reply('⚠️ Configuração não encontrada.'); return ctx.reply(`🎨 *MÍDIA*\n\nResposta: ×${item.commandKey}\nStatus: ${item.status === 'ACTIVE' ? '🟢 Ativa' : '🔴 Desativada'}\n\n1️⃣ Ativar\n2️⃣ Desativar\n0️⃣ Cancelar`); }
}

export async function handle(ctx) {
  if (!owner(ctx)) return { handled: false };
  const s = get(ctx); if (!s) return { handled: false };
  const text = String(ctx.body || ctx.text || '').trim();
  if (s.expired) { clear(ctx); await audit('RESPONSE_MEDIA_SESSION_EXPIRED', { ctx, details: { sessionId: s.sessionId } }); await ctx.reply('⏱️ *CONFIGURAÇÃO EXPIRADA*\n\nNenhuma alteração foi salva.'); return { handled: true }; }
  if (cancel(text)) { clear(ctx); await audit('RESPONSE_MEDIA_CONFIG_CANCELLED', { ctx, details: { sessionId: s.sessionId } }); await ctx.reply('❌ *CANCELADO*\n\nNenhuma alteração foi salva.'); return { handled: true, cancelled: true }; }
  if (s.command === 'create') {
    if (s.step === 'select') {
      const rows = compatibleCommands(); const n = Number(text); const selected = rows[n - 1];
      if (!selected) { await ctx.reply(renderSelection()); return { handled: true }; }
      s.data.commandKey = selected.name; s.data.responseKey = selected.responseCapabilities?.responseKey || `command.${selected.name}.default`; s.step = 'media';
      await ctx.reply(`📸 *CONFIGURANDO MÍDIA*\n\nResposta selecionada:\n×${selected.name}\n\nEnvie agora a imagem ou GIF que deverá acompanhar essa resposta.\n\n0️⃣ Cancelar`); return { handled: true };
    }
    if (s.step === 'media') {
      const media = mediaFromMessage(ctx); if (!media) { await ctx.reply('⚠️ Envie uma imagem ou GIF nesta etapa.\n\n0️⃣ Cancelar'); return { handled: true }; }
      try { const buffer = await downloadMedia(ctx, media); const tmp = service.mediaHash(buffer); s.data.media = { buffer, mimetype: media.mimetype, filename: media.filename, isGif: media.isGif, hash: tmp }; s.step = 'confirm';
        const previewCaption = `🎨 *PRÉVIA DA RESPOSTA*\n\n×${s.data.commandKey} <@user>\n\nEsta mídia será incorporada à própria mensagem de resposta.\n\nDeseja salvar?\n1️⃣ Salvar\n2️⃣ Enviar outra mídia\n0️⃣ Cancelar`;
        if (ctx.sendMessage && ctx.from) { try { await ctx.sendMessage(ctx.from, media.isGif ? { video: buffer, gifPlayback:true, caption:previewCaption } : { image:buffer, caption:previewCaption }); } catch { await ctx.reply(previewCaption); } } else await ctx.reply(previewCaption);
        return { handled: true }; } catch (e) { await audit('RESPONSE_MEDIA_VALIDATION_FAILED', { ctx, responseKey: s.data.responseKey, result: 'error', details: { reason: e.message } }); await ctx.reply(`❌ Não foi possível validar a mídia.\n\n${e.message}`); return { handled: true }; }
    }
    if (s.step === 'confirm') {
      if (no(text)) { s.step = 'media'; delete s.data.media; return ctx.reply('📸 Envie outra imagem ou GIF.\n\n0️⃣ Cancelar').then(()=>({handled:true})); }
      if (!yes(text)) { await ctx.reply('⚠️ Digite 1 para salvar, 2 para enviar outra mídia ou 0 para cancelar.'); return { handled: true }; }
      const m = s.data.media; if (!m) { s.step = 'media'; await ctx.reply('⚠️ A mídia temporária não está disponível. Envie novamente.'); return { handled: true }; }
      try { const result = await service.create(ctx, { responseKey: s.data.responseKey, commandKey: s.data.commandKey, buffer: m.buffer, mimetype: m.mimetype, filename: m.filename, isGif: m.isGif }); clear(ctx); await ctx.reply(`✅ *MÍDIA CONFIGURADA COM SUCESSO!*\n\nResposta: ×${s.data.commandKey}\nTipo: ${result.mediaType}\nStatus: 🟢 Ativa\nEscopo: 🌎 Global`); return { handled: true }; } catch (e) { await ctx.reply(`❌ Não foi possível salvar a configuração.\n\n${e.message}`); return { handled: true }; }
    }
  }
  if (s.command === 'edit') {
    if (s.step === 'select') { const n=Number(text), command=s.data.rows?.[n-1]; if(!command){await ctx.reply('⚠️ Seleção inválida.\n\n0️⃣ Cancelar');return {handled:true};} s.data.commandKey=command;s.data.responseKey=`command.${command}.default`;s.step='action';const r=getResponseMedia(s.data.responseKey);await ctx.reply(`✏️ *EDITANDO MÍDIA*\n\nResposta: ×${command}\nStatus: ${r?.status==='ACTIVE'?'🟢 Ativa':'🔴 Desativada'}\n\n1️⃣ Trocar mídia\n2️⃣ Remover mídia\n3️⃣ Ativar\n4️⃣ Desativar\n5️⃣ Visualizar\n0️⃣ Cancelar`);return {handled:true}; }
    if (s.step === 'action') { const r=getResponseMedia(s.data.responseKey); if(!r)return ctx.reply('⚠️ Configuração não encontrada.').then(()=>({handled:true})); if(text==='1'){s.step='replaceMedia';return ctx.reply('📸 Envie a nova imagem ou GIF.\n\n0️⃣ Cancelar').then(()=>({handled:true}));} if(text==='2'){s.step='removeConfirm';return ctx.reply('⚠️ *REMOVER PERSONALIZAÇÃO*\n\nA mídia personalizada desta resposta será removida.\n\n1️⃣ Confirmar\n2️⃣ Cancelar').then(()=>({handled:true}));} if(text==='3'){await service.enable(ctx,s.data.responseKey);clear(ctx);return ctx.reply('🟢 Mídia ativada.').then(()=>({handled:true}));} if(text==='4'){await service.disable(ctx,s.data.responseKey);clear(ctx);return ctx.reply('🔴 Mídia desativada.').then(()=>({handled:true}));} if(text==='5'){return ctx.reply(`🎨 *INFORMAÇÕES DA MÍDIA*\n\nResposta: ×${r.commandKey}\nTipo: ${r.mediaType}\nStatus: ${r.status==='ACTIVE'?'🟢 Ativa':'🔴 Desativada'}\nEscopo: 🌎 Global\nCriada em: ${new Date(r.createdAt).toLocaleString('pt-BR')}\nAtualizada em: ${new Date(r.updatedAt).toLocaleString('pt-BR')}`).then(()=>({handled:true}));}return ctx.reply('⚠️ Escolha 1, 2, 3, 4 ou 5.').then(()=>({handled:true})); }
    if (s.step === 'removeConfirm') { if(no(text)){clear(ctx);return ctx.reply('❌ Remoção cancelada.').then(()=>({handled:true}));} if(!yes(text))return ctx.reply('⚠️ Digite 1 para confirmar ou 2 para cancelar.').then(()=>({handled:true})); await service.remove(ctx,s.data.responseKey);clear(ctx);return ctx.reply('✅ Personalização removida. A resposta voltou ao comportamento normal.').then(()=>({handled:true})); }
    if (s.step === 'replaceMedia') { const media=mediaFromMessage(ctx);if(!media)return ctx.reply('⚠️ Envie uma imagem ou GIF.').then(()=>({handled:true}));try{const buffer=await downloadMedia(ctx,media);s.data.media={buffer,mimetype:media.mimetype,filename:media.filename,isGif:media.isGif};s.step='replaceConfirm';return ctx.reply('🎨 *NOVA MÍDIA VALIDADA*\n\n1️⃣ Salvar\n2️⃣ Enviar outra\n0️⃣ Cancelar').then(()=>({handled:true}));}catch(e){return ctx.reply(`❌ ${e.message}`).then(()=>({handled:true}));} }
    if (s.step === 'replaceConfirm') { if(no(text)){s.step='replaceMedia';return ctx.reply('📸 Envie outra mídia.').then(()=>({handled:true}));}if(!yes(text))return ctx.reply('⚠️ Digite 1, 2 ou 0.').then(()=>({handled:true}));const m=s.data.media;await service.create(ctx,{responseKey:s.data.responseKey,commandKey:s.data.commandKey,buffer:m.buffer,mimetype:m.mimetype,filename:m.filename,isGif:m.isGif});clear(ctx);return ctx.reply('✅ Mídia trocada com sucesso.').then(()=>({handled:true})); }
  }
  return { handled: false };
}

export default { start, handle, compatibleCommands };
