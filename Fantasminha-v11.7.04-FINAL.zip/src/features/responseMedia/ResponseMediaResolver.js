import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';
import { getCommand } from '../../core/registry.js';
import { getResponseMedia } from './ResponseMediaRepository.js';

const HARD_BLOCKED = new Set(['media','menu','ajuda','config','admin','menuadmin','perfil','meuperfil','profile']);
const MENU_CATEGORIES = new Set(['menus']);
const LEGACY_NATIVE_MEDIA = new Set(['perfil','admin','adm','adms','upscale','qc']);
function legacyHasNativeMedia(name) {
  const n = normalizeCommand(name);
  if (LEGACY_NATIVE_MEDIA.has(n)) return true;
  try {
    const file = path.join(config.root, 'dados', 'src', 'funcs', 'json', 'games.json');
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    const item = data?.games2?.[n];
    return !!(item?.image || item?.video);
  } catch { return false; }
}

function normalizeCommand(value) { return String(value || '').trim().toLowerCase().replace(/^×/, ''); }

export function getCapabilities(ctx = {}, commandDef = null) {
  const def = commandDef || getCommand(ctx.command || ctx.responseKey || '');
  const explicit = def?.responseCapabilities || ctx.responseCapabilities || {};
  const name = normalizeCommand(def?.name || ctx.command || '');
  const category = String(def?.category || '').toLowerCase();
  return {
    supportsCustomMedia: explicit.supportsCustomMedia !== false && !HARD_BLOCKED.has(name) && !MENU_CATEGORIES.has(category),
    hasNativeMedia: explicit.hasNativeMedia === true || legacyHasNativeMedia(name),
    hasDynamicMedia: explicit.hasDynamicMedia === true,
    isMenu: explicit.isMenu === true || MENU_CATEGORIES.has(category) || HARD_BLOCKED.has(name),
    responseKey: explicit.responseKey || ctx.responseKey || (name ? `command.${name}.default` : null)
  };
}

export function resolveForResponse(ctx = {}, responseMeta = {}) {
  const caps = getCapabilities(ctx, responseMeta.commandDef);
  if (!caps.supportsCustomMedia || caps.hasNativeMedia || caps.hasDynamicMedia || caps.isMenu) return { applicable: false, reason: 'incompatible', capabilities: caps };
  const responseKey = responseMeta.responseKey || caps.responseKey;
  if (!responseKey) return { applicable: false, reason: 'missing_response_key', capabilities: caps };
  const item = getResponseMedia(responseKey);
  if (!item || item.status !== 'ACTIVE') return { applicable: false, reason: 'not_configured', capabilities: caps, responseKey };
  return { applicable: true, responseKey, item, capabilities: caps };
}

export function listCompatibleResponses() {
  // The Registry is the primary discovery source. Legacy commands are handled by
  // the same responseKey convention when they reach the existing sender.
  return [];
}

export default { getCapabilities, resolveForResponse, listCompatibleResponses };
