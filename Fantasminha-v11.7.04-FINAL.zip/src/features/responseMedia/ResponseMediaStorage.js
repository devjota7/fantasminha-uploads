import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import config from '../../core/config.js';
import { sha256 } from './ResponseMediaRepository.js';

export const STORAGE_ROOT = path.join(config.root, 'data', 'response-media');
function ensure() { fs.mkdirSync(STORAGE_ROOT, { recursive: true }); }

export async function saveMedia(buffer, mediaType, originalName = '') {
  if (!Buffer.isBuffer(buffer) || !buffer.length) throw new Error('Buffer de mídia inválido.');
  ensure();
  const hash = sha256(buffer);
  const ext = mediaType === 'GIF' ? (String(originalName).toLowerCase().endsWith('.mp4') ? '.mp4' : '.gif') : '.jpg';
  const filename = `${hash}-${crypto.randomBytes(4).toString('hex')}${ext}`;
  const absolute = path.join(STORAGE_ROOT, filename);
  fs.writeFileSync(absolute, buffer, { flag: 'wx' });
  return { reference: path.relative(config.root, absolute).replaceAll(path.sep, '/'), absolute, hash, size: buffer.length };
}

export function readMedia(reference) {
  const rel = String(reference || '').replaceAll('\\', '/');
  if (!rel || rel.includes('..') || !rel.startsWith('data/response-media/')) throw new Error('Referência de mídia inválida.');
  const absolute = path.resolve(config.root, rel);
  if (!absolute.startsWith(path.resolve(STORAGE_ROOT) + path.sep)) throw new Error('Referência de mídia fora do armazenamento permitido.');
  if (!fs.existsSync(absolute)) throw new Error('Arquivo de mídia não encontrado.');
  return fs.readFileSync(absolute);
}

export function removeMedia(reference) {
  try { const data = readMedia(reference); void data; } catch { return false; }
  const rel = String(reference || '').replaceAll('\\', '/');
  const absolute = path.resolve(config.root, rel);
  try { fs.rmSync(absolute, { force: true }); return true; } catch { return false; }
}

export default { STORAGE_ROOT, saveMedia, readMedia, removeMedia };
