import { randomUUID, createHash } from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';

const COLLECTION = 'response_media';
const fallback = { version: 1, items: {} };
const now = () => Date.now();

function activeItems(data = readCollection(COLLECTION, fallback)) {
  return Object.values(data.items || {}).filter(x => x && !x.deletedAt);
}

export function listResponseMedia({ includeDeleted = false } = {}) {
  const d = readCollection(COLLECTION, fallback);
  return Object.values(d.items || {})
    .filter(x => x && (includeDeleted || !x.deletedAt))
    .sort((a, b) => String(a.responseKey).localeCompare(String(b.responseKey)));
}

export function getResponseMedia(responseKey) {
  const key = String(responseKey || '').trim();
  if (!key) return null;
  const d = readCollection(COLLECTION, fallback);
  const item = d.items?.[key];
  return item && !item.deletedAt ? structuredClone(item) : null;
}

export function getResponseMediaById(id) {
  const key = String(id || '').trim();
  if (!key) return null;
  return listResponseMedia().find(x => x.id === key) || null;
}

export async function createResponseMedia(input) {
  const responseKey = String(input?.responseKey || '').trim();
  if (!responseKey) throw new Error('responseKey obrigatório');
  const stamp = now();
  return updateCollection(COLLECTION, d => {
    d.version ||= 1; d.items ||= {};
    const current = d.items[responseKey];
    if (current && !current.deletedAt) throw new Error(`Já existe configuração para ${responseKey}`);
    const item = {
      id: input.id || `RM-${randomUUID().replaceAll('-', '').slice(0, 12).toUpperCase()}`,
      responseKey,
      commandKey: input.commandKey || responseKey.split('.')[0],
      mediaType: input.mediaType,
      mediaReference: input.mediaReference,
      mediaHash: input.mediaHash || null,
      mediaSize: Number(input.mediaSize || 0),
      status: input.status || 'ACTIVE',
      createdAt: stamp,
      updatedAt: stamp,
      createdBy: input.createdBy || null,
      deletedAt: null
    };
    d.items[responseKey] = item;
    return d;
  }, fallback).then(d => structuredClone(d.items[responseKey]));
}

export async function updateResponseMedia(responseKey, patch = {}) {
  const key = String(responseKey || '').trim();
  if (!key) throw new Error('responseKey obrigatório');
  let out = null;
  await updateCollection(COLLECTION, d => {
    d.version ||= 1; d.items ||= {};
    const current = d.items[key];
    if (!current || current.deletedAt) throw new Error('Configuração não encontrada');
    out = { ...current, ...patch, responseKey: key, updatedAt: now(), deletedAt: patch.deletedAt ?? current.deletedAt };
    d.items[key] = out;
    return d;
  }, fallback);
  return structuredClone(out);
}

export async function softDeleteResponseMedia(responseKey) {
  return updateResponseMedia(responseKey, { status: 'DELETED', deletedAt: now() });
}

export async function enableResponseMedia(responseKey) { return updateResponseMedia(responseKey, { status: 'ACTIVE' }); }
export async function disableResponseMedia(responseKey) { return updateResponseMedia(responseKey, { status: 'INACTIVE' }); }

export async function upsertResponseMedia(input) {
  const key = String(input?.responseKey || '').trim();
  const existing = getResponseMedia(key);
  if (existing) return updateResponseMedia(key, input);
  return createResponseMedia(input);
}

export function findByMediaHash(hash) {
  const h = String(hash || '').trim();
  if (!h) return null;
  return activeItems().find(x => x.mediaHash === h) || null;
}

export function sha256(buffer) { return createHash('sha256').update(buffer).digest('hex'); }

export default { listResponseMedia, getResponseMedia, getResponseMediaById, createResponseMedia, updateResponseMedia, softDeleteResponseMedia, enableResponseMedia, disableResponseMedia, upsertResponseMedia, findByMediaHash, sha256 };
