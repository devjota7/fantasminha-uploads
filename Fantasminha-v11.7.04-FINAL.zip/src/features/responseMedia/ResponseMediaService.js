import { configuredOwner } from '../../core/permissions.js';
import { createResponseMedia, getResponseMedia, listResponseMedia, updateResponseMedia, softDeleteResponseMedia, enableResponseMedia, disableResponseMedia, sha256 } from './ResponseMediaRepository.js';
import { saveMedia, readMedia } from './ResponseMediaStorage.js';
import { validateBuffer, validateResponseKey } from './ResponseMediaValidator.js';
import { audit } from './ResponseMediaAuditService.js';
import { resolveForResponse } from './ResponseMediaResolver.js';

function owner(ctx) { return !!ctx && !ctx.fromMe && !ctx.message?.key?.fromMe && (ctx.isOwner === true || configuredOwner(ctx.sender)); }
function assertOwner(ctx) { if (!owner(ctx)) throw Object.assign(new Error('Somente o dono pode administrar o Response Media Manager.'), { code: 'UNAUTHORIZED' }); }

export function isOwner(ctx) { return owner(ctx); }

export async function create(ctx, { responseKey, commandKey, buffer, mimetype, filename, isGif = false }) {
  assertOwner(ctx);
  const key = validateResponseKey(responseKey); if (!key.ok) throw new Error(key.reason);
  const valid = validateBuffer(buffer, { mimetype, filename, isGif }); if (!valid.ok) throw new Error(valid.reason);
  const old = getResponseMedia(key.value);
  const stored = await saveMedia(buffer, valid.mediaType, filename);
  try {
    const result = old
      ? await updateResponseMedia(key.value, { commandKey: commandKey || old.commandKey, mediaType: valid.mediaType, mediaReference: stored.reference, mediaHash: stored.hash, mediaSize: stored.size, status: 'ACTIVE' })
      : await createResponseMedia({ responseKey: key.value, commandKey, mediaType: valid.mediaType, mediaReference: stored.reference, mediaHash: stored.hash, mediaSize: stored.size, status: 'ACTIVE', createdBy: ctx.sender });
    await audit(old ? 'RESPONSE_MEDIA_UPDATED' : 'RESPONSE_MEDIA_CREATED', { ctx, responseKey: key.value, oldValue: old, newValue: result, details: { mediaReference: stored.reference } });
    return result;
  } catch (e) {
    try { await audit('RESPONSE_MEDIA_VALIDATION_FAILED', { ctx, responseKey: key.value, result: 'error', details: { reason: e.message } }); } catch {}
    throw e;
  }
}

export async function update(ctx, responseKey, patch = {}) { assertOwner(ctx); const old = getResponseMedia(responseKey); const next = await updateResponseMedia(responseKey, patch); await audit('RESPONSE_MEDIA_UPDATED', { ctx, responseKey, oldValue: old, newValue: next }); return next; }
export async function remove(ctx, responseKey) { assertOwner(ctx); const old = getResponseMedia(responseKey); const next = await softDeleteResponseMedia(responseKey); await audit('RESPONSE_MEDIA_REMOVED', { ctx, responseKey, oldValue: old, newValue: next }); return next; }
export async function enable(ctx, responseKey) { assertOwner(ctx); const old = getResponseMedia(responseKey); const next = await enableResponseMedia(responseKey); await audit('RESPONSE_MEDIA_ENABLED', { ctx, responseKey, oldValue: old, newValue: next }); return next; }
export async function disable(ctx, responseKey) { assertOwner(ctx); const old = getResponseMedia(responseKey); const next = await disableResponseMedia(responseKey); await audit('RESPONSE_MEDIA_DISABLED', { ctx, responseKey, oldValue: old, newValue: next }); return next; }

export function resolve(ctx, responseMeta = {}) { return resolveForResponse(ctx, responseMeta); }

export function getStoredBuffer(item) { return readMedia(item.mediaReference); }
export function mediaHash(buffer) { return sha256(buffer); }
export function list() { return listResponseMedia(); }

export default { isOwner, create, update, remove, enable, disable, resolve, getStoredBuffer, mediaHash, list };
