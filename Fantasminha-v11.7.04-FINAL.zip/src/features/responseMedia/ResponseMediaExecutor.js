import { resolveForResponse } from './ResponseMediaResolver.js';
import service from './ResponseMediaService.js';
import { audit } from './ResponseMediaAuditService.js';

export async function send(ctx, text, options = {}) {
  const meta = { ...options, responseKey: options.responseKey || ctx.responseKey };
  const resolved = resolveForResponse(ctx, meta);
  if (!resolved.applicable) return null;
  try {
    const buffer = service.getStoredBuffer(resolved.item);
    const mentions = options.mentions || [];
    const content = resolved.item.mediaType === 'GIF'
      ? { video: buffer, gifPlayback: true, caption: String(text ?? ''), mentions }
      : { image: buffer, caption: String(text ?? ''), mentions };
    const sendOptions = {};
    if (options.quoted) sendOptions.quoted = options.quoted;
    if (options.sendEphemeral != null) sendOptions.sendEphemeral = options.sendEphemeral;
    if (options.contextInfo) sendOptions.contextInfo = options.contextInfo;
    if (!ctx.sendMessage || !ctx.from) throw new Error('Socket indisponível');
    return await ctx.sendMessage(ctx.from, { ...content, ...sendOptions });
  } catch (e) {
    await audit('RESPONSE_MEDIA_SEND_FAILED', { ctx, responseKey: resolved.responseKey, result: 'error', details: { error: e.message } });
    return null;
  }
}

export default { send };
