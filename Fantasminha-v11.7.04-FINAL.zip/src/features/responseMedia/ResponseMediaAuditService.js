import { recordAudit } from '../../platform/audit/index.js';
import logger from '../../core/logger.js';

export async function audit(eventType, { ctx = null, responseKey = null, oldValue = null, newValue = null, result = 'success', details = {} } = {}) {
  try {
    await recordAudit({
      actor: ctx?.sender || null,
      target: ctx?.from || null,
      action: eventType,
      scope: 'global',
      requestId: ctx?.requestId || null,
      result,
      details: { responseKey, oldValue, newValue, ...details }
    });
  } catch (e) { logger.debug?.('response-media-audit', `falha: ${e.message}`); }
}
export default { audit };
