import path from 'node:path';

export const MEDIA_TYPES = Object.freeze({ IMAGE: 'IMAGE', GIF: 'GIF' });
const MAX_MB = Math.max(1, Number(process.env.RESPONSE_MEDIA_MAX_MB || 12));
export const MAX_BYTES = MAX_MB * 1024 * 1024;

const MIME = new Map([
  ['image/jpeg', MEDIA_TYPES.IMAGE], ['image/jpg', MEDIA_TYPES.IMAGE], ['image/png', MEDIA_TYPES.IMAGE], ['image/webp', MEDIA_TYPES.IMAGE],
  ['image/gif', MEDIA_TYPES.GIF], ['video/mp4', MEDIA_TYPES.GIF]
]);
const EXT = new Map([
  ['.jpg', MEDIA_TYPES.IMAGE], ['.jpeg', MEDIA_TYPES.IMAGE], ['.png', MEDIA_TYPES.IMAGE], ['.webp', MEDIA_TYPES.IMAGE],
  ['.gif', MEDIA_TYPES.GIF], ['.mp4', MEDIA_TYPES.GIF]
]);

export function classifyMedia({ mimetype = '', filename = '', isGif = false } = {}) {
  if (isGif) return MEDIA_TYPES.GIF;
  return MIME.get(String(mimetype).toLowerCase()) || EXT.get(path.extname(String(filename)).toLowerCase()) || null;
}

export function validateBuffer(buffer, meta = {}) {
  if (!Buffer.isBuffer(buffer) || !buffer.length) return { ok: false, reason: 'Mídia vazia ou inválida.' };
  if (buffer.length > MAX_BYTES) return { ok: false, reason: `A mídia ultrapassa o limite de ${MAX_MB} MB.` };
  const mediaType = classifyMedia(meta);
  if (!mediaType) return { ok: false, reason: 'Formato não suportado. Envie uma imagem ou GIF.' };
  return { ok: true, mediaType, size: buffer.length };
}

export function validateResponseKey(key) {
  const value = String(key || '').trim();
  if (!value || value.length > 180 || !/^[a-z0-9_.:-]+$/i.test(value)) return { ok: false, reason: 'Identificador de resposta inválido.' };
  return { ok: true, value };
}

export default { MEDIA_TYPES, MAX_BYTES, classifyMedia, validateBuffer, validateResponseKey };
