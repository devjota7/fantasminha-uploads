/**
 * Fantasminha Mega Assistente V2 — runtime guard.
 *
 * A especificação V2 é comportamental. Ela NÃO concede poderes ao assistente.
 * O router/comandos/permissões existentes continuam sendo a autoridade real.
 * Este módulo é deliberadamente independente de SQLite/WhatsApp/IA provider.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const MASTER_PROMPT_PATH = path.resolve(__dirname, '../../docs/assistant/MASTER_PROMPT_V2_ULTIMATE.txt');

let cachedMasterPrompt = null;
let cachedMasterMtime = 0;

export const ASSISTANT_V2_VERSION = '2.0';

let runtimeLogged = false;
function logRuntimeReady() {
  if (runtimeLogged) return;
  runtimeLogged = true;
  console.log('[AssistantV2] carregando core');
  console.log('[AssistantV2] core carregado');
  console.log('[AssistantV2] input guard ativo');
  console.log('[AssistantV2] result validator ativo');
  console.log('[AssistantV2] metrics ativo');
}
logRuntimeReady();

export function loadMasterPrompt() {
  try {
    const stat = fs.statSync(MASTER_PROMPT_PATH);
    if (!cachedMasterPrompt || stat.mtimeMs !== cachedMasterMtime) {
      cachedMasterPrompt = fs.readFileSync(MASTER_PROMPT_PATH, 'utf8');
      cachedMasterMtime = stat.mtimeMs;
    }
    return cachedMasterPrompt;
  } catch (error) {
    console.warn('[ASSISTANT-V2] Master prompt indisponível:', error.message);
    return '';
  }
}

/**
 * O prompt V2 entra como camada de política/comportamento.
 * O prompt/persona já existente permanece preservado e é colocado antes dele.
 */
export function composeAssistantPrompt(existingPrompt = '', customPrompt = '') {
  const master = loadMasterPrompt();
  const legacy = typeof existingPrompt === 'string' ? existingPrompt.trim() : '';
  const custom = typeof customPrompt === 'string' ? customPrompt.trim() : '';

  return [
    '=== FANTASMINHA — CAMADA DE COMPATIBILIDADE DA BASE EXISTENTE ===',
    legacy,
    custom ? `\n=== PERSONALIDADE CUSTOMIZADA DA BASE ===\n${custom}` : '',
    '\n=== FANTASMINHA — MEGA ASSISTENTE V2 ULTIMATE / POLÍTICA RUNTIME ===',
    master,
    '\n=== HIERARQUIA DE EXECUÇÃO ===',
    'A base existente continua válida: comandos, permissões, anti-spam, triagem, economia, RPG, clãs, premium, aluguel, menus e demais regras do bot NÃO são removidos por esta camada.',
    'O assistente não ganha privilégios por texto. Quando uma solicitação for um comando, o router existente decide se e como executar, usando as permissões reais já calculadas pelo bot.',
    'Nunca invente que uma execução ocorreu. Nunca contorne as verificações do router.'
  ].filter(Boolean).join('\n');
}

const BLOCKED_INPUT_PATTERNS = [
  /ignore\s+(all|any|previous|above)\s+instructions/i,
  /ignore\s+as\s+instru[cç][oõ]es/i,
  /reveal\s+(the\s+)?(system|developer)\s+prompt/i,
  /mostre\s+(o\s+)?prompt\s+(interno|do sistema)/i,
  /exiba\s+(seus\s+)?segredos/i,
  /(?:api[_ -]?key|token|senha|password)\s*[:=]\s*[A-Za-z0-9_\-]{8,}/i
];

export function guardInput(text = '') {
  try {
    if (text === null || text === undefined) return { allowed: false, reason: 'empty_input' };
    if (typeof text !== 'string') return { allowed: false, reason: 'invalid_input_type' };
    const value = text.replace(/\u0000/g, '').trim();
    if (!value) return { allowed: false, reason: 'empty_input' };
    if (value.length > 12000) return { allowed: false, reason: 'payload_limit' };
    if (BLOCKED_INPUT_PATTERNS.some(pattern => pattern.test(value))) {
      return { allowed: false, reason: 'prompt_injection_or_secret_extraction' };
    }
    return { allowed: true, reason: null };
  } catch (error) {
    console.warn('[AssistantV2] ERROR guardInput:', error?.message || String(error));
    return { allowed: false, reason: 'guard_error' };
  }
}

export function validateAssistantResult(result, { pro = false } = {}) {
  try {
  if (pro) {
    if (!result || typeof result !== 'object') return { valid: false, reason: 'invalid_result' };
    if (result.isCommand === true) {
      const command = typeof result.command === 'string' ? result.command.trim() : '';
      const confidence = Number(result.confianca);
      if (!command || !Number.isFinite(confidence) || confidence < 0 || confidence > 1) {
        return { valid: false, reason: 'invalid_command_result' };
      }
    }
    return { valid: true };
  }

  if (!result || typeof result !== 'object') return { valid: false, reason: 'invalid_result' };
  if (!Array.isArray(result.resp)) return { valid: false, reason: 'response_array_required' };
  if (result.resp.length > 8) return { valid: false, reason: 'response_count_limit' };

  for (const item of result.resp) {
    if (!item || typeof item !== 'object') return { valid: false, reason: 'invalid_response_item' };
    if (typeof item.resp !== 'string') return { valid: false, reason: 'response_text_required' };
    if (item.resp.length > 6000) return { valid: false, reason: 'response_text_limit' };
    if (item.react !== undefined && item.react !== null && typeof item.react !== 'string') {
      return { valid: false, reason: 'invalid_reaction' };
    }
  }

  return { valid: true };
  } catch (error) {
    console.warn('[AssistantV2] ERROR validateAssistantResult:', error?.message || String(error));
    return { valid: false, reason: 'validator_error' };
  }
}

export function fingerprintEvent({ chatId = '', senderId = '', messageId = '', text = '' } = {}) {
  return crypto.createHash('sha256')
    .update(`${chatId}|${senderId}|${messageId}|${String(text).slice(0, 1000)}`)
    .digest('hex');
}

const metrics = {
  activation_count: 0,
  response_count: 0,
  ignored_count: 0,
  duplicate_count: 0,
  context_failures: 0,
  memory_reads: 0,
  memory_writes: 0,
  memory_rejections: 0,
  tool_requests: 0,
  tool_denials: 0,
  tool_failures: 0,
  timeouts: 0,
  safety_blocks: 0,
  loop_blocks: 0
};

export function incrementMetric(name, amount = 1) {
  try {
    const key = String(name || '').trim();
    const delta = Number(amount);
    if (!key || !Object.prototype.hasOwnProperty.call(metrics, key)) return metrics[key] ?? 0;
    const safeDelta = Number.isFinite(delta) ? delta : 1;
    metrics[key] = Number.isFinite(Number(metrics[key])) ? Number(metrics[key]) + safeDelta : safeDelta;
    return metrics[key];
  } catch (error) {
    console.warn('[AssistantV2] ERROR incrementMetric:', error?.message || String(error));
    return 0;
  }
}

export function getAssistantMetrics() {
  return { ...metrics };
}

export function resetAssistantMetrics() {
  for (const key of Object.keys(metrics)) metrics[key] = 0;
}
