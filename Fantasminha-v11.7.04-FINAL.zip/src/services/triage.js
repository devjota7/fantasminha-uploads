import crypto from 'node:crypto';
import fs from 'node:fs';
import { readCollection, updateCollection } from '../database/store.js';
import config from '../core/config.js';
import { analyzeTriageImage, downloadImage, persistTriageMedia, saveTriageImageFile, getImageMessage } from './triageImage.js';

export const MAX_QUESTIONS = 50;
export const DEFAULT_QUESTIONS = [];
export const DEFAULT_SETTINGS = Object.freeze({
  enabled:false, maxQuestions:20, questions:[], archiveGroupId:null,
  startTimeoutMs:3600000, completionTimeoutMs:86400000, judgeTimeoutMs:172800000,
  reminderAfterMs:1200000, reminderEnabled:true, kickOnExpire:false, restrictPending:false,
  publicMode:'summary', defaultRejectionLevel:'network', autoBlacklistCount:3,
  autoBlacklistWindowMs:30*86400000, kickOnReject:false, photoMaxMb:12, imageAnalysis:true
});
export const STATES = Object.freeze({PENDING:'pendente',RUNNING:'em_andamento',JUDGING:'aguardando_julgamento',APPROVED:'aprovado',REJECTED:'reprovado',EXPIRED:'expirado',CANCELLED:'cancelado'});
const clone=v=>v==null?v:structuredClone(v); const now=()=>Date.now();
const clean=v=>String(v??'').trim(); const mention=j=>String(j||'').toLowerCase().endsWith('@s.whatsapp.net')?`@${idBase(j)}`:'@membro';
const idBase=v=>String(v||'').split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g,'');
const makeId=()=>`TRG-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
const normalizeUser=(a,b)=>{
  if (!a || !b) return false;
  const aa=String(a).trim(), bb=String(b).trim();
  if (aa===bb) return true;
  return idBase(aa)===idBase(bb);
};
const identityVariants=(...values)=>[...new Set(values.flatMap(v=>{
  if (Array.isArray(v)) return v;
  if (!v) return [];
  return [String(v)];
}).map(clean).filter(Boolean))];

/** Extrai texto de diferentes formatos de mensagem Baileys sem lançar exceção. */
export function extractIncomingText(info) {
  const m = info?.message || info?.msg || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.documentMessage?.caption ||
    m.buttonsResponseMessage?.selectedDisplayText ||
    m.listResponseMessage?.title ||
    m.templateButtonReplyMessage?.selectedDisplayText ||
    ''
  );
}

export const QUESTION_TYPES=Object.freeze({text:'text',date:'date',number:'number',yesno:'yesno',choice:'choice',image:'image'});
export function settingsOf(groups,groupId){
  const raw=groups.byId?.[groupId]?.triagem||{};
  const merged={...clone(DEFAULT_SETTINGS),...raw};
  const triageGroupId=Object.prototype.hasOwnProperty.call(raw,'triageGroupId')?raw.triageGroupId:(raw.archiveGroupId||null);
  const approvalGroupIds=Array.isArray(raw.approvalGroupIds)?[...new Set(raw.approvalGroupIds.map(clean).filter(Boolean))]:[];
  return {...merged,triageGroupId:triageGroupId||null,archiveGroupId:triageGroupId||null,approvalGroupIds,questions:Array.isArray(raw.questions)?clone(raw.questions).slice(0,MAX_QUESTIONS):[]};
}
export async function getSettings(groupId){return settingsOf(readCollection('groups',{byId:{}}),groupId);}
export async function saveSettings(groupId,patch){
  let out,changed=false;
  await updateCollection('groups',g=>{
    g.byId??={};g.byId[groupId]??={};
    const current=settingsOf(g,groupId);
    const nextPatch=clone(patch)||{};
    if(Object.prototype.hasOwnProperty.call(nextPatch,'archiveGroupId')&&!Object.prototype.hasOwnProperty.call(nextPatch,'triageGroupId')) nextPatch.triageGroupId=nextPatch.archiveGroupId||null;
    if(Object.prototype.hasOwnProperty.call(nextPatch,'triageGroupId')) nextPatch.archiveGroupId=nextPatch.triageGroupId||null;
    if(Object.prototype.hasOwnProperty.call(nextPatch,'approvalGroupIds')) nextPatch.approvalGroupIds=[...new Set((Array.isArray(nextPatch.approvalGroupIds)?nextPatch.approvalGroupIds:[]).map(clean).filter(Boolean))];
    const next={...current,...nextPatch,configurationVersion:(Number(current.configurationVersion)||0)+1};
    next.approvalGroupIds=[...new Set((next.approvalGroupIds||[]).map(clean).filter(Boolean))];
    next.triageGroupId=next.triageGroupId||null;next.archiveGroupId=next.triageGroupId;
    changed=JSON.stringify(current)!==JSON.stringify(next);
    g.byId[groupId].triagem=next;out=clone(next);return g;
  },{byId:{}});
  if(changed) await updateCollection('triage_audit',d=>{d.entries??=[];d.entries.push({id:crypto.randomUUID(),action:'configuration-updated',at:now(),triageId:'',groupId,userId:'',state:'',patch:clone(patch)||{}});if(d.entries.length>15000)d.entries=d.entries.slice(-15000);return d;},{entries:[]});
  return out;
}
export async function deleteTriageConfiguration(groupId){let out;await updateCollection('groups',g=>{g.byId??={};if(g.byId[groupId]){const old=clone(g.byId[groupId].triagem||DEFAULT_SETTINGS);delete g.byId[groupId].triagem;out=old;}return g;},{byId:{}});await updateCollection('triage_builder',d=>{if(d.byKey)for(const k of Object.keys(d.byKey))if(k.startsWith(`${groupId}:`))delete d.byKey[k];return d;},{byKey:{}});return out||clone(DEFAULT_SETTINGS);}

function template(code,groupId,userId,s){const ts=now();const triageGroupId=s.triageGroupId||null;const approvalGroupIds=[...new Set((s.approvalGroupIds||[]).map(clean).filter(Boolean))];return{id:code,groupId,userId,entryGroupId:groupId,triageGroupId,managementGroupId:triageGroupId||groupId,approvalGroupIds,configurationVersion:Number(s.configurationVersion)||0,state:STATES.PENDING,questionIndex:0,questions:clone(s.questions).slice(0,Math.min(MAX_QUESTIONS,Number(s.maxQuestions)||20)),answers:[],alerts:[],media:[],createdAt:ts,updatedAt:ts,startedAt:0,completedAt:0,judgedAt:0,expiresStartAt:ts+s.startTimeoutMs,expiresCompleteAt:0,expiresJudgeAt:0,reminderSentAt:0,judgeId:'',judgeName:'',reason:'',rejectionLevel:'',version:4};}
export async function getTriage(code){return readCollection('triage',{byId:{},active:{}}).byId?.[String(code||'').toUpperCase()]||null;}
export async function getActiveTriage(groupId,userId,aliases=[]){
  const d=readCollection('triage',{byId:{},active:{}});
  const direct=d.active?.[`${groupId}:${userId}`];
  if(direct && d.byId?.[direct]) return d.byId[direct];
  const variants=identityVariants(userId,aliases);
  for(const [key,code] of Object.entries(d.active||{})){
    if(!key.startsWith(`${groupId}:`)) continue;
    const stored=key.slice(String(groupId).length+1);
    if(variants.some(v=>normalizeUser(stored,v)) && d.byId?.[code]) return d.byId[code];
  }
  return null;
}
export async function isPendingMember(groupId,userId){const t=await getActiveTriage(groupId,userId);return !!(t&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(t.state));}
async function audit(action,t,extra={}){await updateCollection('triage_audit',d=>{d.entries??=[];d.entries.push({id:crypto.randomUUID(),action,at:now(),triageId:t?.id||'',groupId:t?.groupId||'',userId:t?.userId||'',state:t?.state||'',...clone(extra)});if(d.entries.length>15000)d.entries=d.entries.slice(-15000);return d;},{entries:[]});}
async function transition(code,patch){let out;await updateCollection('triage',d=>{const c=d.byId?.[code];if(!c)return d;out={...c,...clone(patch),updatedAt:now()};d.byId[code]=out;if([STATES.APPROVED,STATES.REJECTED,STATES.EXPIRED,STATES.CANCELLED].includes(out.state)&&d.active?.[`${out.groupId}:${out.userId}`]===code)delete d.active[`${out.groupId}:${out.userId}`];return d;},{byId:{},active:{}});if(out)await audit('state-change',out,patch);return out||null;}
export function triageLink(code,botJid=config.ownerNumber){const n=idBase(botJid);return n?`https://wa.me/${n}?text=${encodeURIComponent(code)}`:'';}
async function resolveTriageMentionJid(sock,t){try{const meta=await sock?.groupMetadata?.(t?.groupId);const {resolveUserIdentity}=await import('../platform/identity/resolver.js');const r=await resolveUserIdentity({groupParticipantObjects:meta?.participants||[]},t?.userId);return r.realJid||null;}catch{return null}}
export async function createTriage(groupId,userId,{botJid=null,force=false,aliases=[]}={}){const s=await getSettings(groupId);if(!s.questions.length)return{ok:false,reason:'no-questions'};if(!s.enabled&&!force)return{ok:false,reason:'disabled'};const bl=await blacklistCheck(userId);if(bl)return{ok:false,reason:'blacklisted',blacklist:bl};const old=await getActiveTriage(groupId,userId,aliases);if(old&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(old.state))return{ok:true,created:false,code:old.id,triage:old,link:triageLink(old.id,botJid)};const code=makeId(),t=template(code,groupId,userId,s);await updateCollection('triage',d=>{d.byId??={};d.active??={};d.byId[code]=t;d.active[`${groupId}:${userId}`]=code;return d;},{byId:{},active:{}});await audit('created',t);return{ok:true,created:true,code,triage:t,link:triageLink(code,botJid)};}
export async function cancelActiveTriage(groupId,userId,reason='cancelado'){const t=await getActiveTriage(groupId,userId);return t?transition(t.id,{state:STATES.CANCELLED,reason}):null;}
function validateDate(raw){const m=String(raw).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);if(!m)return false;const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]));return d.getFullYear()===Number(m[3])&&d.getMonth()===Number(m[2])-1&&d.getDate()===Number(m[1]);}
function validateTextAnswer(q,raw){
  if(!raw){
    return q.required ? 'required' : null;
  }
  if(q.type==='date'&&!validateDate(raw))return'invalid-date';
  if(q.minLength&&raw.length<q.minLength)return'too-short';
  if(q.maxLength&&raw.length>q.maxLength)return'too-long';
  if(q.type==='number'){
    const n=Number(raw);
    if(!Number.isFinite(n))return'invalid-number';
    if(q.min!=null&&n<Number(q.min))return'number-too-small';
    if(q.max!=null&&n>Number(q.max))return'number-too-large';
  }
  if(q.type==='yesno'&&!['sim','s','yes','y','1','aceito','aceita','nao','não','n','no','0'].includes(raw.toLowerCase()))return'invalid-yesno';
  if(q.type==='choice'&&q.choices?.length&&!q.choices.map(x=>String(x).toLowerCase()).includes(raw.toLowerCase()))return'invalid-choice';
  if(q.type==='choice'&&!q.choices?.length)return'invalid-choice';
  return null;
}
export async function validateAndSaveAnswer(code,answer){
  const t=await getTriage(code);
  if(!t||t.state!==STATES.RUNNING)return{ok:false,reason:t?'not-running':'not-found',triage:t};
  const q=t.questions?.[t.questionIndex];
  if(!q||q.type==='image')return{ok:false,reason:q?'image-required':'finished',question:q,triage:t};
  const raw=clean(answer).replace(/\s+/g,' ');
  const err=validateTextAnswer(q,raw);
  if(err)return{ok:false,reason:err,question:q,triage:t};
  const settings=await getSettings(t.groupId);
  let out;
  await updateCollection('triage',d=>{
    const c=d.byId?.[code];
    if(!c||c.state!==STATES.RUNNING)return d;
    c.answers??=[];
    c.answers.push({questionId:q.id,question:q.question,type:q.type,value:raw,at:now()});
    c.questionIndex++;
    c.updatedAt=now();
    if(c.questionIndex>=c.questions.length){
      c.state=STATES.JUDGING;
      c.completedAt=now();
      c.expiresJudgeAt=now()+settings.judgeTimeoutMs;
    }
    out=clone(c);
    return d;
  },{byId:{},active:{}});
  if(!out)return{ok:false,reason:'race'};
  await audit('answer',out,{questionId:q.id});
  return{ok:true,triage:out,finished:out.state===STATES.JUDGING};
}
export async function saveImageAnswer(code,info){const t=await getTriage(code);if(!t||t.state!==STATES.RUNNING)return{ok:false,reason:t?'not-running':'not-found',triage:t};const q=t.questions?.[t.questionIndex];if(!q||q.type!=='image')return{ok:false,reason:'not-image-question',triage:t};const settings=await getSettings(t.groupId);let image;try{image=await downloadImage(info);}catch(e){return{ok:false,reason:'image-download',error:e.message,triage:t};}if(!image)return{ok:false,reason:'image-required',triage:t};const answers=Object.fromEntries((t.answers||[]).map(a=>[a.questionId,a.value]));const analysis=await analyzeTriageImage(image,{answers,question:q.question,analysis:q.analysis||{enabled:true,ocr:true}});const mediaId=crypto.randomUUID();const imagePath=await saveTriageImageFile(code,mediaId,image);const media={id:mediaId,questionId:q.id,sha256:image.sha256,mime:image.mime,size:image.size,width:image.width,height:image.height,path:imagePath,analysis,at:now()};let out;await updateCollection('triage',d=>{const c=d.byId?.[code];if(!c||c.state!==STATES.RUNNING)return d;c.media??=[];c.media.push(media);c.answers??=[];c.answers.push({questionId:q.id,question:q.question,type:'image',value:'[imagem enviada]',mediaId:media.id,analysisSummary:{id:analysis.id,nickname:analysis.nickname,quality:analysis.quality,confidence:analysis.confidence,alerts:analysis.alerts},at:now()});c.alerts.push(...(analysis.alerts||[]).filter(Boolean));c.questionIndex++;c.updatedAt=now();if(c.questionIndex>=c.questions.length){c.state=STATES.JUDGING;c.completedAt=now();c.expiresJudgeAt=now()+settings.judgeTimeoutMs;}out=clone(c);return d;},{byId:{},active:{}});if(!out)return{ok:false,reason:'race'};await persistTriageMedia(code,media);await audit('image-answer',out,{questionId:q.id,mediaId:media.id});return{ok:true,triage:out,finished:out.state===STATES.JUDGING,analysis};}
export async function startTriage(code){const t=await getTriage(code);if(!t)return{ok:false,reason:'not-found'};if(t.state!==STATES.PENDING)return{ok:false,reason:'not-pending',triage:t};if(now()>t.expiresStartAt)return{ok:false,reason:'expired',triage:await transition(code,{state:STATES.EXPIRED,reason:'não iniciou no prazo'})};const s=await getSettings(t.groupId);return{ok:true,triage:await transition(code,{state:STATES.RUNNING,startedAt:now(),expiresCompleteAt:now()+s.completionTimeoutMs})};}
export function isImageQuestion(t){
  const q = t?.questions?.[t?.questionIndex];
  return q?.type === 'image';
}
export function questionText(t){const q=t?.questions?.[t.questionIndex];if(!q)return'';let extra=q.required===false?'\n\n_(opcional)_':'';if(q.type==='image')extra+='\n\n📸 Envie a imagem diretamente neste PV. A imagem será analisada pela IA e anexada à ficha.';if(q.type==='choice')extra+=`\n\nOpções: ${q.choices.join(' | ')}`;if(q.type==='date')extra+='\n\n📅 Formato obrigatório: DD/MM/AAAA';return`👻 *FICHA DA ALMA*\n\nPergunta *${t.questionIndex+1}/${t.questions.length}*\n\n${q.question}${extra}`;}
async function historyFor(userId,windowMs=null){const d=readCollection('triage_history',{byUser:{}});const l=Array.isArray(d.byUser?.[userId])?d.byUser[userId]:[];return windowMs?l.filter(x=>x.at>=now()-windowMs):l;}
export async function rejectionHistory(userId,windowMs=null){return historyFor(userId,windowMs);}
async function addHistory(t,actor,reason,level){const e={id:crypto.randomUUID(),triageId:t.id,groupId:t.groupId,userId:t.userId,judgeId:actor.id,judgeName:actor.name||'',reason,level,at:now()};await updateCollection('triage_history',d=>{d.byUser??={};d.byUser[t.userId]??=[];d.byUser[t.userId].push(e);return d;},{byUser:{}});return e;}
export async function blacklistCheck(userId){const d=readCollection('triage_blacklist',{byUser:{}}),e=d.byUser?.[userId];if(!e)return null;if(e.until&&e.until<=now()){await updateCollection('triage_blacklist',x=>{delete x.byUser?.[userId];return x;},{byUser:{}});return null;}return e;}
export async function setBlacklist(userId,actorId,reason,durationMs=0,meta={}){const e={id:crypto.randomUUID(),userId,actorId,reason:clean(reason)||'sem motivo informado',createdAt:now(),until:durationMs?now()+durationMs:0,permanent:!durationMs,source:meta.source||'manual',level:meta.level||'blacklist'};await updateCollection('triage_blacklist',d=>{d.byUser??={};d.byUser[userId]=e;return d;},{byUser:{}});await audit('blacklist-add',{userId},{actorId,reason:e.reason});return e;}
export async function removeBlacklist(userId,actorId){let existed=false;await updateCollection('triage_blacklist',d=>{d.byUser??={};existed=!!d.byUser[userId];delete d.byUser[userId];return d;},{byUser:{}});if(existed)await audit('blacklist-remove',{userId},{actorId});return existed;}
export async function blacklistList(){const d=readCollection('triage_blacklist',{byUser:{}});return Object.values(d.byUser||{}).filter(e=>!e.until||e.until>now());}
export async function blacklistInfo(userId){return blacklistCheck(userId);} export async function blacklistHistory(userId){return rejectionHistory(userId);}
export async function triageStats(groupId=null){const a=Object.values(readCollection('triage',{byId:{}}).byId||{}).filter(t=>!groupId||t.groupId===groupId);return{total:a.length,pending:a.filter(t=>t.state===STATES.PENDING).length,running:a.filter(t=>t.state===STATES.RUNNING).length,judging:a.filter(t=>t.state===STATES.JUDGING).length,approved:a.filter(t=>t.state===STATES.APPROVED).length,rejected:a.filter(t=>t.state===STATES.REJECTED).length,expired:a.filter(t=>t.state===STATES.EXPIRED).length};}
export async function blacklistStats(){const list=await blacklistList();return{active:list.length,permanent:list.filter(x=>x.permanent).length,temporary:list.filter(x=>!x.permanent).length};}
export async function networkSummary(userId){return{count:(await historyFor(userId)).length,latest:(await historyFor(userId)).at(-1)||null,blacklist:await blacklistCheck(userId)};}
export function triageSummaryText(t,h=0){return`👻 *TRIAGEM ${t.id}*\n\n👤 Membro: ${mention(t.userId)}\n📋 Status: *${t.state}*\n📝 Respostas: *${t.answers?.length||0}/${t.questions?.length||0}*\n🛡️ Histórico na rede: *${h} reprovação(ões)*${t.alerts?.length?`\n\n⚠️ Alertas:\n${t.alerts.map(x=>`• ${x}`).join('\n')}`:'\n\n✅ Sem alertas objetivos'}`;}
export function triageFullText(t,h=0){const answers=(t.answers||[]).map((x,i)=>`${i+1}. *${x.question}*\n↳ ${x.type==='image'?'📸 Imagem enviada':x.value}`).join('\n\n')||'Nenhuma resposta.';const analyses=(t.media||[]).map((m,i)=>`📸 *Imagem ${i+1}*\n• Qualidade: ${m.analysis?.quality||'n/d'}\n• Confiança: ${m.analysis?.confidence||'n/d'}\n• ID detectado: ${m.analysis?.id||'não identificado'}\n• Nick detectado: ${m.analysis?.nickname||'não identificado'}\n• Alertas IA: ${(m.analysis?.alerts||[]).join('; ')||'nenhum'}`).join('\n\n');return`👻 *FICHA DA ALMA*\nCódigo: *${t.id}*\n👤 ${mention(t.userId)}\n📋 Estado: *${t.state}*\n\n╭─「 📝 RESPOSTAS  」\n${answers}\n╰────────────────────\n${analyses?`\n╭─「 🤖 ANÁLISE IA  」\n${analyses}\n╰────────────────────\n`:''}\n🛡️ Reprovações na rede: *${h}*\n⚠️ Alertas: ${t.alerts?.length?`\n${t.alerts.map(x=>`• ${x}`).join('\n')}`:'nenhum'}`;}
export async function judgeTriage(code,actor,decision,reason='',level=null){const t=await getTriage(code);if(!t)return{ok:false,reason:'not-found'};if(t.state!==STATES.JUDGING)return{ok:false,reason:'not-judging',triage:t};const s=await getSettings(t.entryGroupId||t.groupId);if(decision==='approve'){return{ok:true,triage:await transition(code,{state:STATES.APPROVED,judgedAt:now(),judgeId:actor.id,judgeName:actor.name||'',reason:''})};}const r=clean(reason);if(r.length<3)return{ok:false,reason:'reason-required',triage:t};const l=['local','network','blacklist'].includes(String(level||'').toLowerCase())?String(level).toLowerCase():s.defaultRejectionLevel;const u=await transition(code,{state:STATES.REJECTED,judgedAt:now(),judgeId:actor.id,judgeName:actor.name||'',reason:r,rejectionLevel:l});const hist=await addHistory(u,actor,r,l);if(l==='blacklist')await setBlacklist(t.userId,actor.id,r,0,{source:'triage-blacklist',level:l});return{ok:true,triage:u,history:hist};}
export async function publishForAdmins(sock,t){
  const h=await rejectionHistory(t.userId);
  const full=triageFullText(t,h.length);
  const destinations=[t.managementGroupId||t.triageGroupId||t.entryGroupId||t.groupId].filter(Boolean);
  const sentDestinations=[];
  const mentionJid=await resolveTriageMentionJid(sock,{...t,groupId:t.entryGroupId||t.groupId});
  const mentionOptions=mentionJid?{mentions:[mentionJid]}:{};
  for(const gid of [...new Set(destinations)]){
    try{await sock.sendMessage(gid,{text:full,...mentionOptions});sentDestinations.push(gid);await audit('ficha-published',t,{destinationGroupId:gid});}catch(e){await audit('ficha-publish-failed',t,{destinationGroupId:gid,error:String(e?.message||e)});}
  }
  return{history:h,destinations:sentDestinations,failedDestinations:destinations.filter(g=>!sentDestinations.includes(g))};
}

export async function executeApprovalActions(sock,t){
  const destinations=[...new Set((t.approvalGroupIds||[]).map(clean).filter(Boolean))];
  const results=[];
  for(const gid of destinations){
    try{
      const participant=await resolveTriageMentionJid(sock,{...t,groupId:t.entryGroupId||t.groupId});
      if(!participant) throw new Error('participante não resolvido');
      const response=await sock.groupParticipantsUpdate(gid,[participant],'add');
      const ok=Array.isArray(response)?response.every(x=>String(x?.status||'200')==='200'):true;
      results.push({groupId:gid,success:ok,status:response});
      await audit(ok?'member-added-to-approval-group':'member-add-to-approval-group-failed',t,{destinationGroupId:gid,response});
    }catch(e){results.push({groupId:gid,success:false,error:String(e?.message||e)});await audit('member-add-to-approval-group-failed',t,{destinationGroupId:gid,error:String(e?.message||e)});}
  }
  let removal=null;
  if(destinations.length>0){
    try{
      const participant=await resolveTriageMentionJid(sock,{...t,groupId:t.entryGroupId||t.groupId});
      if(!participant) throw new Error('participante não resolvido');
      const response=await sock.groupParticipantsUpdate(t.entryGroupId||t.groupId,[participant],'remove');
      const ok=Array.isArray(response)?response.every(x=>String(x?.status||'200')==='200'):true;
      removal={groupId:t.entryGroupId||t.groupId,success:ok,status:response};
      await audit(ok?'member-removed-from-entry':'member-removal-failed',t,{response});
    }catch(e){removal={groupId:t.entryGroupId||t.groupId,success:false,error:String(e?.message||e)};await audit('member-removal-failed',t,{error:String(e?.message||e)});}
  } else {
    await audit('approved-without-permanent-groups',t,{keptInEntryGroup:t.entryGroupId||t.groupId});
  }
  return {results,removal};
}

export async function executeRejectionActions(sock,t){
  const groupId=t.entryGroupId||t.groupId;
  let removal=null;
  try{
    const participant=await resolveTriageMentionJid(sock,{...t,groupId});
    if(!participant) throw new Error('participante não resolvido');
    const response=await sock.groupParticipantsUpdate(groupId,[participant],'remove');
    const ok=Array.isArray(response)?response.every(x=>String(x?.status||'200')==='200'):true;
    removal={groupId,success:ok,status:response};
    await audit(ok?'rejected-member-removed':'rejected-member-removal-failed',t,{response});
  }catch(e){removal={groupId,success:false,error:String(e?.message||e)};await audit('rejected-member-removal-failed',t,{error:String(e?.message||e)});}
  try{await sock.sendMessage(t.userId,{text:`👻 *RESULTADO DA TRIAGEM*\n\nSua triagem *${t.id}* foi reprovada.\n\n📋 *Motivo:*\n${t.reason||'Não informado.'}\n\n🚫 Você foi removido(a) do grupo de entrada.`});await audit('rejection-pv-sent',t);}catch(e){await audit('rejection-pv-failed',t,{error:String(e?.message||e)});}
  return {removal};
}
export async function notifyAdmins(sock,groupId,text,mentions=[]){const meta=await sock.groupMetadata(groupId).catch(()=>null);const admins=(meta?.participants||[]).filter(p=>p.admin).map(p=>p.id||p.jid).filter(Boolean);for(const a of admins)await sock.sendMessage(a,{text,mentions}).catch(()=>{});return admins.length;}
export async function expireSweep(sendMessage=null,kick=null){const d=readCollection('triage',{byId:{}});let n=0;for(const t of Object.values(d.byId||{})){const expired=(t.state===STATES.PENDING&&t.expiresStartAt<now())||(t.state===STATES.RUNNING&&t.expiresCompleteAt<now())||(t.state===STATES.JUDGING&&t.expiresJudgeAt<now());if(!expired)continue;n++;await transition(t.id,{state:STATES.EXPIRED,reason:'tempo esgotado'});if(sendMessage)await sendMessage(t.userId,{text:`👻 Sua triagem *${t.id}* expirou.`}).catch(()=>{});if(kick){const s=await getSettings(t.groupId);if(s.kickOnExpire)await kick(t.groupId,t.userId).catch(()=>{});}}return n;}
export async function reminderSweep(sendMessage=null,sendGroup=null){const d=readCollection('triage',{byId:{}});let n=0;for(const t of Object.values(d.byId||{})){if(t.state!==STATES.PENDING||t.reminderSentAt)continue;const s=await getSettings(t.groupId);if(!s.reminderEnabled||now()<t.createdAt+s.reminderAfterMs)continue;await updateCollection('triage',x=>{if(x.byId?.[t.id])x.byId[t.id].reminderSentAt=now();return x;},{byId:{},active:{}});n++;if(sendMessage)await sendMessage(t.userId,{text:`👻 Sua triagem está aguardando você.\nCódigo: *${t.id}*\n${triageLink(t.id)}`}).catch(()=>{});if(sendGroup)await sendGroup(t.groupId,{text:'👻 Uma triagem ainda não foi concluída. Confira a fila do Além.'}).catch(()=>{});}return n;}

export async function handlePrivateMessage({sock,info,sender,text,send}){if(!sender||info?.key?.fromMe)return{handled:false};const normalized=clean(text),upper=normalized.toUpperCase();if(/^TRG-[A-F0-9]{8}$/.test(upper)){const t=await getTriage(upper);if(!t){await send('👻 Código de triagem não encontrado.');return{handled:true};}if(!normalizeUser(t.userId,sender)){await send('🚫 Este link/código pertence a outro usuário.');return{handled:true};}if(t.state===STATES.PENDING){const s=await startTriage(upper);if(!s.ok){await send('👻 Esta triagem não pode mais ser iniciada.');return{handled:true};}await send(questionText(s.triage));return{handled:true};}if(t.state===STATES.RUNNING){await send(questionText(t));return{handled:true};}await send(`👻 *TRIAGEM ${t.id}*\nStatus: *${t.state}*`);return{handled:true};}
const d=readCollection('triage',{byId:{},active:{}});
const variants=identityVariants(sender, info?.key?.remoteJid, info?.key?.remoteJidAlt, info?.key?.participant, info?.key?.participantAlt, info?.message?.participant, info?.message?.participantAlt);
const candidates=Object.entries(d.active||{}).map(([key,code])=>{
  const idx=key.indexOf(':'); if(idx<0) return null;
  const userKey=key.slice(idx+1);
  if(!variants.some(v=>normalizeUser(userKey,v))) return null;
  const triage=d.byId?.[code]; return triage ? {code,triage} : null;
}).filter(Boolean).sort((a,b)=>(b.triage.updatedAt||b.triage.createdAt||0)-(a.triage.updatedAt||a.triage.createdAt||0));
const code=candidates[0]?.code||'';
const t=code?d.byId?.[code]:null;if(!t)return{handled:false};if(t.state===STATES.RUNNING){if(t.questions?.[t.questionIndex]?.type==='image'){const image=getImageMessage(info);if(!image){await send('📸 Esta pergunta exige uma imagem.');return{handled:true};}const r=await saveImageAnswer(t.id,info);if(!r.ok){await send('⚠️ Não consegui processar a imagem. Envie uma imagem nítida.');return{handled:true};}if(r.finished){await send(`👻 *Ficha concluída!*\nCódigo: *${r.triage.id}*\nA ficha foi encaminhada para análise.`);await publishForAdmins(sock,r.triage);return{handled:true,finished:true,triage:r.triage};}await send(questionText(r.triage));return{handled:true};}const r=await validateAndSaveAnswer(t.id,normalized);if(!r.ok){const msg={required:'⚠️ Resposta obrigatória.','invalid-date':'⚠️ Use exatamente DD/MM/AAAA.','invalid-number':'⚠️ Envie um número válido.','invalid-yesno':'⚠️ Responda sim ou não.','invalid-choice':'⚠️ Escolha uma opção válida.','too-short':'⚠️ Resposta curta demais.','too-long':'⚠️ Resposta longa demais.','number-too-small':'⚠️ O número está abaixo do mínimo permitido.','number-too-large':'⚠️ O número está acima do máximo permitido.'};await send(msg[r.reason]||'⚠️ Resposta inválida.');return{handled:true};}if(r.finished){await send(`👻 *Ficha concluída!*\nCódigo: *${r.triage.id}*\nA ficha foi encaminhada para análise.`);await publishForAdmins(sock,r.triage);return{handled:true};}await send(questionText(r.triage));return{handled:true};}return{handled:true};}
export async function memberJoined(sock,groupId,userId){const s=await getSettings(groupId);if(!s.enabled)return{ok:false,reason:'disabled'};const bl=await blacklistCheck(userId);if(bl){await sock.groupParticipantsUpdate(groupId,[userId],'remove').catch(()=>{});return{ok:false,reason:'blacklisted',blacklist:bl};}const botJid=sock?.user?.id||config.ownerNumber;const c=await createTriage(groupId,userId,{botJid});if(!c.ok)return c;const mj=await resolveTriageMentionJid(sock,{groupId,userId});const content={text:`👻 *NOVA TRIAGEM*\n\nBem-vindo(a) ${mention(mj)}!\n\nAntes de participar da comunidade, você precisa concluir sua triagem.\n\n📋 ${c.triage.questions.length} perguntas\n⏱️ Prazo: 24 horas\n\n👇 Clique no link abaixo para iniciar ou continuar no PV do Fantasminha.\n\n🔗 *INICIAR TRIAGEM*\n${c.link}\n\n🔐 ID exclusivo: *${c.code}*`,...(mj?{mentions:[mj]}:{})};try{await sock.sendMessage(groupId,content);await audit('entry-message-sent',c.triage);}catch(e){await audit('entry-message-failed',c.triage,{error:String(e?.message||e)});}return{ok:true,...c};}

// ---------- CONSTRUTOR SIMPLES / SEM PREFIXO ----------
export function builderState(groupId,actor,aliases=[]){
  const d=readCollection('triage_builder',{byKey:{}});
  const variants=identityVariants(actor,aliases);
  for(const [key,state] of Object.entries(d.byKey||{})){
    const idx=key.indexOf(':'); if(idx<0||key.slice(0,idx)!==String(groupId)) continue;
    const stored=key.slice(idx+1);
    if(variants.some(v=>normalizeUser(stored,v))) return { ...clone(state), __builderKey:key };
  }
  return null;
}
async function setBuilder(groupId,actor,state){
  return updateCollection('triage_builder',d=>{
    d.byKey??={};
    if(state){
      const key=`${groupId}:${actor}`;
      d.byKey[key]=state;
    }else{
      delete d.byKey[`${groupId}:${actor}`];
      for(const key of Object.keys(d.byKey)) if(key.startsWith(`${groupId}:`) && key.endsWith(`:${actor}`)) delete d.byKey[key];
    }
    return d;
  },{byKey:{}});
}
async function clearBuilderState(groupId,st,actor,aliases=[]){
  const d=readCollection('triage_builder',{byKey:{}});
  const variants=identityVariants(actor,aliases);
  await updateCollection('triage_builder',x=>{
    x.byKey??={};
    for(const key of Object.keys(x.byKey)){
      const idx=key.indexOf(':'); if(idx<0||key.slice(0,idx)!==String(groupId)) continue;
      const stored=key.slice(idx+1);
      if(variants.some(v=>normalizeUser(stored,v)) || key===st?.__builderKey) delete x.byKey[key];
    }
    return x;
  },{byKey:{}});
}
export async function beginTriageBuilder(groupId,actor,aliases=[]){
  const state={step:'confirm',questions:[],current:null,createdAt:now(),updatedAt:now()};
  await setBuilder(groupId,actor,state);
  for(const alias of identityVariants(aliases)){
    if(alias===String(actor)) continue;
    await setBuilder(groupId,alias,state);
  }
  return true;
}
export async function cancelTriageBuilder(groupId,actor,aliases=[]){await clearBuilderState(groupId,null,actor,aliases);return true;}

const catMap={
  '1':'text','2':'date','3':'image','4':'number','5':'yesno','6':'choice',
  texto:'text',text:'text',data:'date',foto:'image',imagem:'image',
  numero:'number',simnao:'yesno',escolha:'choice'
};
function categoryText(){
  return`🧩 *TIPO DA PERGUNTA*\n\n1️⃣ Texto\n2️⃣ Data\n3️⃣ Foto\n4️⃣ Número\n5️⃣ Sim/Não\n6️⃣ Escolha\n\nResponda com o número.`;
}
function normalizeBuilderType(raw){return catMap[clean(raw).toLowerCase()]||null;}
function buildQuestion(idValue,question,type,order,choices=[]){
  const q={id:idValue||`q_${crypto.randomBytes(4).toString('hex')}`,type,required:true,question:clean(question),order};
  if(type==='image') q.analysis={enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low'};
  if(type==='choice') q.choices=choices.map(clean).filter(Boolean).slice(0,20);
  return q;
}

export async function beginTriageEdit(groupId,actor,index,aliases=[]){
  const s=await getSettings(groupId);
  const i=Number(index)-1;
  if(!Number.isInteger(i)||i<0||i>=s.questions.length)return{ok:false,reason:'not-found'};
  const q=clone(s.questions[i]);
  await beginEditBuilderState(groupId,actor,aliases,{step:'edit-question',questions:clone(s.questions),editIndex:i,current:q,createdAt:now(),updatedAt:now()});
  return{ok:true,question:q,number:i+1,total:s.questions.length};
}
async function beginEditBuilderState(groupId,actor,aliases,state){
  await setBuilder(groupId,actor,state);
  for(const alias of identityVariants(aliases)){
    if(alias===String(actor)) continue;
    await setBuilder(groupId,alias,state);
  }
}

export async function handleTriageBuilderMessage(ctx){
  if(!ctx.isGroup||!ctx.isGroupAdmin||!ctx.sender)return{handled:false};
  const aliases=identityVariants(ctx.senderOriginal,ctx.senderAlternate,ctx.participantAlt,ctx.remoteJidAlt,ctx.senderAliases);
  const st=builderState(ctx.from,ctx.sender,aliases);
  if(!st)return{handled:false};

  const raw=clean(ctx.body??ctx.text??ctx.q??'');
  const lower=raw.toLowerCase();
  const cancelWords=new Set([`${ctx.prefix||config.prefix}cancelar`,'cancelar','×cancelar']);
  if(cancelWords.has(lower)){
    await cancelTriageBuilder(ctx.from,ctx.sender,aliases);
    await ctx.reply('👻 Criação da triagem cancelada.');
    return{handled:true};
  }

  const saveState=async state=>{
    const key=st.__builderKey;
    await updateCollection('triage_builder',d=>{
      d.byKey??={};
      const keys=Object.keys(d.byKey).filter(k=>k===key || identityVariants(ctx.sender,...aliases).some(v=>normalizeUser(k.slice(k.indexOf(':')+1),v)));
      for(const k of keys)d.byKey[k]={...state,updatedAt:now()};
      if(!keys.length)d.byKey[`${ctx.from}:${ctx.sender}`]={...state,updatedAt:now()};
      return d;
    },{byKey:{}});
  };

  if(st.step==='confirm'){
    if(raw==='1'){
      await saveState({...st,step:'question',current:null});
      await ctx.reply('👻 *CONFIGURAÇÃO DA TRIAGEM*\n\nEnvie a primeira pergunta.\n\nEx.: Qual é o seu nome?\n\n• *concluir* para salvar\n• *cancelar* para sair');
    }else if(raw==='2'){
      await cancelTriageBuilder(ctx.from,ctx.sender,aliases);
      await ctx.reply('👻 Criação cancelada.');
    }else{
      await ctx.reply('Envie apenas *1* para continuar ou *2* para cancelar.');
    }
    return{handled:true};
  }

  if(st.step==='question'){
    if(lower==='concluir'){
      if(!st.questions?.length){await ctx.reply('⚠️ Cadastre pelo menos uma pergunta antes de concluir.');return{handled:true};}
      await saveSettings(ctx.from,{questions:st.questions.map((q,i)=>({...q,order:i+1})),maxQuestions:20,enabled:false});
      await cancelTriageBuilder(ctx.from,ctx.sender,aliases);
      await ctx.reply(`👻 *TRIAGEM SALVA!*\n\n📝 Perguntas: *${st.questions.length}/20*\n🔴 Status: *DESATIVADA*\n\nTeste: *${config.prefix}triagemcobrar*\nAtivar: *${config.prefix}triagemativar*`);
      return{handled:true};
    }
    if(st.questions.length>=20){await ctx.reply('⚠️ Limite de 20 perguntas atingido. Envie *concluir*.');return{handled:true};}
    if(!raw){await ctx.reply('⚠️ Escreva a pergunta.');return{handled:true};}
    await saveState({...st,step:'category',current:{question:raw}});
    await ctx.reply(categoryText());
    return{handled:true};
  }

  if(st.step==='category'){
    const type=normalizeBuilderType(raw);
    if(!type){await ctx.reply(categoryText());return{handled:true};}
    if(type==='choice'){
      await saveState({...st,step:'choice-options',current:{...st.current,type}});
      await ctx.reply('🧩 *OPÇÕES DA PERGUNTA*\n\nEnvie as opções separadas por *|*.\n\nEx.: Iniciante | Intermediário | Avançado');
      return{handled:true};
    }
    const q=buildQuestion(null,st.current.question,type,st.questions.length+1);
    const questions=[...st.questions,q];
    await saveState({...st,questions,step:'question',current:null});
    await ctx.reply(`✅ *Pergunta ${questions.length}/20 salva.*\n\nEnvie a próxima pergunta ou *concluir*.`);
    return{handled:true};
  }

  if(st.step==='choice-options'){
    const choices=raw.split('|').map(clean).filter(Boolean).slice(0,20);
    if(choices.length<2){await ctx.reply('⚠️ Informe pelo menos 2 opções separadas por *|*.');return{handled:true};}
    const q=buildQuestion(null,st.current.question,'choice',st.questions.length+1,choices);
    const questions=[...st.questions,q];
    await saveState({...st,questions,step:'question',current:null});
    await ctx.reply(`✅ *Pergunta ${questions.length}/20 salva.*\n\nOpções: ${choices.join(' | ')}\n\nEnvie a próxima pergunta ou *concluir*.`);
    return{handled:true};
  }

  if(st.step==='edit-question'){
    if(!raw){await ctx.reply('⚠️ Escreva a nova pergunta.');return{handled:true};}
    const current={...st.current,question:raw};
    await saveState({...st,step:'edit-category',current});
    await ctx.reply(categoryText()+`\n\n✏️ Editando a pergunta *${st.editIndex+1}*.`);
    return{handled:true};
  }

  if(st.step==='edit-category'){
    const type=normalizeBuilderType(raw);
    if(!type){await ctx.reply(categoryText());return{handled:true};}
    if(type==='choice'){
      await saveState({...st,step:'edit-choice-options',current:{...st.current,type}});
      await ctx.reply('🧩 *OPÇÕES DA PERGUNTA*\n\nEnvie as opções separadas por *|*.');
      return{handled:true};
    }
    const q=buildQuestion(st.current.id,st.current.question,type,st.editIndex+1);
    const questions=st.questions.map((x,i)=>i===st.editIndex?q:x);
    await saveSettings(ctx.from,{questions,maxQuestions:20});
    await cancelTriageBuilder(ctx.from,ctx.sender,aliases);
    await ctx.reply(`✏️ *PERGUNTA ${st.editIndex+1} ATUALIZADA!*\n\n${q.question}\nTipo: *${type}*`);
    return{handled:true};
  }

  if(st.step==='edit-choice-options'){
    const choices=raw.split('|').map(clean).filter(Boolean).slice(0,20);
    if(choices.length<2){await ctx.reply('⚠️ Informe pelo menos 2 opções separadas por *|*.');return{handled:true};}
    const q=buildQuestion(st.current.id,st.current.question,'choice',st.editIndex+1,choices);
    const questions=st.questions.map((x,i)=>i===st.editIndex?q:x);
    await saveSettings(ctx.from,{questions,maxQuestions:20});
    await cancelTriageBuilder(ctx.from,ctx.sender,aliases);
    await ctx.reply(`✏️ *PERGUNTA ${st.editIndex+1} ATUALIZADA!*\n\n${q.question}\nTipo: *choice*`);
    return{handled:true};
  }

  return{handled:false};
}
