import game from './gameEngine.js';

const TRIAGE_RE = /^TRG-[A-F0-9]{8}$/i;
const STOP_RE = /^STP-[A-Z0-9]{8}$/i;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const GAME_ID_COMMANDS = new Set(['entrarjogo','joingame','entrarpartida','aceitarjogo','recusarjogo','declinegame','negarjogo','convidarjogo','invitegame','convidarpartida','revanche','rematch','jogorevanche','cancelarjogo','cancelgame','cancelarpartida']);

const clean = value => String(value ?? '').trim();

export function isTriageCode(value) { return TRIAGE_RE.test(clean(value)); }
export function isStopCode(value) { return STOP_RE.test(clean(value)); }
export function isUuidGameId(value) { return UUID_RE.test(clean(value)); }

export function activeGameIdMatches(value) {
  const target = clean(value).toUpperCase();
  if (!target) return null;
  const games = game.listActiveGames();
  return games.find(g => [g.gameId, g.state?.quizId, g.state?.roundId, g.metadata?.quizId, g.metadata?.roundId, g.state?.stopSession?.stopCode]
    .filter(Boolean).some(id => clean(id).toUpperCase() === target)) || null;
}

export function privateGameCommandAllowed(text, prefix = '×') {
  const raw = clean(text);
  if (!raw.startsWith(prefix)) return false;
  const body = raw.slice(prefix.length).trim();
  const [command, id] = body.split(/\s+/);
  if (!GAME_ID_COMMANDS.has(clean(command).toLowerCase())) return false;
  if (!id) return false;
  return !!activeGameIdMatches(id);
}

export function privateMessageAllowed(text, prefix = '×') {
  const raw = clean(text);
  if (!raw) return false;
  if (isTriageCode(raw) || isStopCode(raw)) return true;
  if (isUuidGameId(raw) && activeGameIdMatches(raw)) return true;
  return privateGameCommandAllowed(raw, prefix);
}

export default { isTriageCode, isStopCode, isUuidGameId, activeGameIdMatches, privateGameCommandAllowed, privateMessageAllowed };
