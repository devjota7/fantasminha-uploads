import fs from 'node:fs';
import crypto from 'node:crypto';
import path from 'node:path';
import { DB_ROOT } from '../database/store.js';

const FILE = path.join(DB_ROOT, 'license_engine.json');
const DEFAULT={licenses:{},history:[]};
function read(){try{return JSON.parse(fs.readFileSync(FILE,'utf8'));}catch{return structuredClone(DEFAULT);}}
function write(db){fs.mkdirSync(path.dirname(FILE),{recursive:true});const tmp=`${FILE}.tmp`;fs.writeFileSync(tmp,JSON.stringify(db,null,2));fs.renameSync(tmp,FILE);}
function id(){return `LIC-${crypto.randomUUID().replaceAll('-','').slice(0,10).toUpperCase()}`;}
export function get(groupId){const db=read();return db.licenses?.[String(groupId)]||null;}
export function status(groupId){const l=get(groupId);if(!l)return {plan:'BASIC',state:'ACTIVE',premium:false};const expired=l.expiresAt&&Date.now()>l.expiresAt;return {...l,state:expired?'EXPIRED':l.state,premium:(l.plan==='PREMIUM'||l.plan==='TRIAL')&&!expired};}
export function upsert({groupId,plan='BASIC',state='ACTIVE',days=30,features=[],actor='system'}){if(!groupId)throw new Error('groupId obrigatório');const db=read();const prev=db.licenses[groupId];const now=Date.now();const license={licenseId:prev?.licenseId||id(),groupId,plan,state,features:[...new Set(features)],issuedAt:prev?.issuedAt||now,expiresAt:plan==='BASIC'?null:now+Math.max(1,days)*86400000,updatedAt:now};db.licenses[groupId]=license;db.history.push({at:now,type:prev?'UPDATED':'CREATED',actor,license:structuredClone(license)});write(db);return license;}
export function canUse(groupId,feature){ const l=status(groupId); if(l.state!=='ACTIVE' || !l.premium) return false; return !l.features?.length || l.features.includes(feature); }
export function trial(groupId,days=7,actor='system'){ return upsert({groupId,plan:'TRIAL',state:'ACTIVE',days,actor,features:['games','pets','tournaments','rankings','quiz']}); }

export function renew(groupId,days=30,actor='system'){const l=get(groupId);if(!l) return upsert({groupId,plan:'PREMIUM',days,actor});const base=Math.max(Date.now(),l.expiresAt||Date.now());return upsert({groupId,plan:l.plan,state:'ACTIVE',days:Math.ceil((base+days*86400000-Date.now())/86400000),features:l.features,actor});}
export function setState(groupId,state,actor='system'){const l=get(groupId)||upsert({groupId,actor});const db=read();db.licenses[groupId]={...l,state,updatedAt:Date.now()};db.history.push({at:Date.now(),type:'STATE_CHANGED',actor,groupId,state});write(db);return db.licenses[groupId];}
export function history(groupId){return read().history.filter(x=>!groupId||x.groupId===groupId||x.license?.groupId===groupId);}
export default {get,status,upsert,trial,renew,setState,canUse,history};
