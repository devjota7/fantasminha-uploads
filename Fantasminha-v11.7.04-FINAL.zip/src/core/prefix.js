/**
 * 👻 Fantasminha — resolvedor centralizado de prefixo.
 *
 * ÚNICA fonte de verdade para prefixos efetivos.
 * Prioridade obrigatória: GRUPO -> GLOBAL.
 *
 * Observação: process.env.PREFIX em Termux pode ser o diretório de instalação;
 * nunca tratamos esse valor como prefixo quando ele parece ser um caminho.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const ENV_FILE = path.join(ROOT, '.env');
const CONFIG_FILE = path.join(ROOT, 'dados', 'src', 'config.json');
const GROUPS_DIR = path.join(ROOT, 'dados', 'database', 'grupos');
const DB_GROUPS_FILE = path.join(ROOT, 'data', 'db', 'groups.json');
const CACHE_TTL_MS = 5000;
const cache = new Map();

function clean(value) { return String(value ?? '').trim(); }

function readEnvValue(name) {
  try {
    if (!fs.existsSync(ENV_FILE)) return '';
    const line = fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/).find(raw => raw.trim().startsWith(`${name}=`));
    if (!line) return '';
    return line.slice(line.indexOf('=') + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
  } catch { return ''; }
}

function readJson(file, fallback = {}) {
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; } catch { return fallback; }
}

export function isValidBotPrefix(value) {
  const v = clean(value);
  if (!v || v.length > 8) return false;
  if (/\s/.test(v)) return false;
  if (v.includes('/') || v.includes('\\')) return false;
  if (v.startsWith('/data/data/') || v.includes('termux/files')) return false;
  if (v === '$') return false; // reservado pelo Fantasminha/Termux.
  return true;
}

export function normalizeBotPrefix(value, fallback = '×') {
  const candidate = clean(value);
  const safeFallback = isValidBotPrefix(fallback) ? clean(fallback) : '×';
  return isValidBotPrefix(candidate) ? candidate : safeFallback;
}

export function getBotPrefix(fallback = '×') {
  const safeFallback = isValidBotPrefix(fallback) ? clean(fallback) : '×';
  const publicCfg = readJson(CONFIG_FILE, {});
  const candidates = [
    readEnvValue('BOT_PREFIX'),
    readEnvValue('PREFIX'),
    process.env.BOT_PREFIX,
    process.env.PREFIX,
    publicCfg.prefixo
  ];
  for (const candidate of candidates) if (isValidBotPrefix(candidate)) return clean(candidate);
  return safeFallback;
}

function groupFile(groupId) {
  const id = clean(groupId);
  if (!id || !id.endsWith('@g.us')) return '';
  return path.join(GROUPS_DIR, `${id}.json`);
}

function loadGroupPrefix(groupId) {
  const file = groupFile(groupId);
  if (file) {
    const data = readJson(file, {});
    if (isValidBotPrefix(data?.customPrefix)) return clean(data.customPrefix);
    if (isValidBotPrefix(data?.prefix)) return clean(data.prefix);
  }
  const db = readJson(DB_GROUPS_FILE, { byId: {} });
  const entry = db?.byId?.[clean(groupId)] || {};
  if (isValidBotPrefix(entry?.customPrefix)) return clean(entry.customPrefix);
  if (isValidBotPrefix(entry?.prefix)) return clean(entry.prefix);
  return '';
}

/**
 * Retorna sempre um prefixo válido.
 * @param {string} groupId
 * @param {{groupConfig?: object, globalPrefix?: string}} options
 */
export function getEffectivePrefix(groupId, options = {}) {
  const id = clean(groupId);
  if (id && id.endsWith('@g.us')) {
    const injected = options?.groupConfig;
    const injectedPrefix = injected && (injected.customPrefix ?? injected.prefix);
    if (isValidBotPrefix(injectedPrefix)) return clean(injectedPrefix);

    const cached = cache.get(id);
    if (cached && cached.expiresAt > Date.now()) return cached.prefix;

    const groupPrefix = loadGroupPrefix(id);
    const globalPrefix = normalizeBotPrefix(options?.globalPrefix, getBotPrefix());
    const effective = isValidBotPrefix(groupPrefix) ? groupPrefix : globalPrefix;
    cache.set(id, { prefix: effective, expiresAt: Date.now() + CACHE_TTL_MS });
    return effective;
  }
  return normalizeBotPrefix(options?.globalPrefix, getBotPrefix());
}

export function invalidatePrefixCache(groupId) {
  const id = clean(groupId);
  if (id) cache.delete(id); else cache.clear();
}

export function clearPrefixCache() { cache.clear(); }

/** Substitui prefixos literais comuns em textos de saída por um prefixo efetivo. */
export function renderCommandText(text, prefix) {
  const value = String(text ?? '');
  const effective = normalizeBotPrefix(prefix, getBotPrefix());
  // Compatibilidade com comandos documentados historicamente com ×.
  return value.replace(/(^|[\s`*_(>•])×(?=[a-zA-Z][a-zA-Z0-9_.-]*)/g, `$1${effective}`);
}

/** Registra alteração sem criar dependência circular no módulo de configuração. */
export async function auditPrefixChange({ groupId, actor = '', before = null, after = null } = {}) {
  try {
    const { recordAudit } = await import('../platform/audit/index.js');
    return await recordAudit({
      actor: actor || null,
      target: groupId || null,
      action: 'GROUP_PREFIX_CHANGED',
      scope: 'group',
      before: { prefix: before },
      after: { prefix: after },
      details: { groupId, previousPrefix: before, newPrefix: after }
    });
  } catch {
    return null;
  }
}

export default getBotPrefix;
