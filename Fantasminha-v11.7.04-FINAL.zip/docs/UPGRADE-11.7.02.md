# Fantasminha 11.7.02 — Complete Expansion Hardening

## Objetivo
A 11.7.02 mantém a versão sem retroceder funcionalidades e transforma a expansão em uma camada de prioridade determinística, corrigindo o crash de inicialização por aliases duplicados.

## Correções críticas
- Registry agora usa prioridade determinística: prioridade maior substitui prioridade menor; empate preserva o primeiro registro.
- Aliases ocupados não geram exceção fatal durante o carregamento.
- Complete Expansion registra com prioridade 1000 e reivindica seus nomes/aliases compatíveis.
- `caraoucoroa`, `calc` e `dado` deixam de produzir colisões fatais com camadas antigas.
- Partidas ganham timeout padrão para encerramento automático quando o jogo não informa um prazo.
- Game Engine ganhou aceite explícito (`acceptInvite`) e cancelamento pelo criador.
- Temporadas agora preservam `groupId` no histórico.
- Stats Engine mantém métricas diária, semanal e mensal.
- License Engine ganhou Trial, renovação e consulta de recurso.

## Política de expansão
A expansão continua integrada ao Registry real, sem comandos de fachada, sem duplicação intencional e sem reações automáticas. Reações públicas continuam somente por `×react`.

## Segurança
Nenhum comando adulto/NSFW ou recurso perigoso foi importado das bases de referência.
