# FANTASMINHA 11.7.02 — Quiz Engine

O `×quiz` foi consolidado em uma única implementação oficial baseada no Game Engine.

## Comandos

- `×quiz` — inicia um quiz multiplayer no grupo.
- `×quiz <categoria> <dificuldade>` — seleção opcional compatível com a arquitetura futura.
- `×quizresposta <1-4>` — adapter de compatibilidade; não contém lógica própria.
- `×rankquiz` — ranking do grupo atual.
- `×rankquizglobal` — TOP 5 grupos e TOP 3 jogadores de cada grupo.
- `×meurank` — posição global, posição no grupo e estatísticas.

## Regras principais

- 45 segundos completos.
- Uma tentativa por usuário.
- A primeira resposta é definitiva.
- O quiz não termina quando alguém acerta.
- Respostas corretas recebem 1–100 pontos inteiros conforme velocidade.
- Respostas erradas recebem 0.
- Não existe pontuação negativa.
- Apenas quem respondeu entra no total de respostas.
- Erros aparecem apenas no contador agregado.
- Acertadores são ordenados por pontuação e, em empate, pelo menor tempo.

## Arquitetura

`QuizService` coordena o ciclo e reutiliza `Game Engine`, persistência, auditoria, eventos e estatísticas genéricas. O domínio possui módulos separados para banco de perguntas, seleção, histórico, respostas, pontuação, visual, storage, estatísticas, ranking, cleanup e recovery.

## Imagem

O provider padrão usa Gemini com modelo configurável por `QUIZ_IMAGE_MODEL`. A imagem é contextual, temporária e enviada junto com a pergunta. Se o provider falhar, a sessão não é iniciada como rodada ativa e os temporários são limpos.

## Persistência

As estatísticas específicas ficam em `quiz_statistics`; o histórico anti-repetição fica em `quiz_question_history`. A sessão de jogo continua no `game_engine`.

## Concorrência e recuperação

A criação usa exclusividade por grupo no Game Engine. A resposta é inserida atomicamente apenas uma vez por `userId`. A resolução usa lock em memória e marcação idempotente por `quizId` nas estatísticas. Após reinício, sessões ativas são verificadas por `expiresAt` e timers são reconstruídos.
