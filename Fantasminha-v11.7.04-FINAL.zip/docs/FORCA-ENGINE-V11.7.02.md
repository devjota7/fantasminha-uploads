# 👻 FORCA ENGINE — Fantasminha v11.7.02

## Visão geral

A FORCA foi consolidada como jogo multiplayer coletivo por grupo dentro do Game Engine central.

- Comando oficial: `×forca`
- Entradas durante partida: `letra <letra>` e `palavra <palpite>`
- Cancelamento: `cancelar forca`
- Uma partida ativa por `groupId`
- Tentativas compartilhadas: 6 por partida
- Sem cronômetro
- Estado persistente em `game_engine`
- Histórico em `forca_history`
- Estatísticas em `forca_statistics`
- Jogadas serializadas por `groupId + gameId`
- Mensagens protegidas por `messageId`

## Estados

`WAITING → ACTIVE → RESOLVING → FINISHED`

ou

`ACTIVE → RESOLVING → CANCELLED`

`RESOLVING` é mantido no estado específico da FORCA enquanto o Game Engine preserva a partida top-level como ativa até a finalização atômica.

## Escopo das entradas

Sem FORCA ativa, `letra ...`, `palavra ...` e `cancelar forca` não são processados pelo jogo.

Com FORCA ativa, somente os formatos definidos pelo parser são candidatos a jogada. Mensagens comuns continuam fora do jogo.

## Regras de vitória

- Palavra correta: encerra imediatamente e define o autor como vencedor.
- Última letra necessária: encerra e define o autor dessa letra como vencedor.
- Tentativas em zero sem completar a palavra: encerra sem vencedor.
- Cancelamento autorizado: encerra sem vencedor e sem recompensa de vitória.

## Cancelamento

Pode cancelar:

1. criador da partida;
2. administrador do grupo;
3. dono do Fantasminha.

Jogadores comuns recebem negativa sem alteração do estado.

## Compatibilidade

A antiga implementação global `global.forcaGames` e os comandos `forcax`, `forcajogar` e `forcadica` foram retirados da implementação oficial da FORCA. `forcaalem` permanece separado como jogo legado do Além, sem alias `forca`.

## Validação

O release foi validado com teste específico da FORCA, testes de Memória dos Copos, Quiz, hardening v11.7.02, verificação sintática e auditoria de comandos.
