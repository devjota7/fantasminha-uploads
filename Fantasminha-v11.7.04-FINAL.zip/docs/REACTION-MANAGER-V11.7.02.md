# Reaction Manager — Fantasminha 11.7.02

Sistema nativo de gerenciamento de reações automáticas, controlado exclusivamente pelo proprietário.

## Comandos

- `×react` — inicia cadastro interativo.
- `×react lista` — lista configurações com paginação.
- `×react editar` — seleciona e edita uma configuração.
- `×react info [ID|número]` — detalhes.
- `×react stats` — estatísticas agregadas.
- `×react histórico` — auditoria do Reaction Manager.
- `×react limpar` — soft delete em massa com confirmação.
- `×react ajuda` — ajuda integrada.
- `×react ativar <ID>` / `×react desativar <ID>` — controle rápido de status.

## Escopos

- `LOCAL`: somente os `groupId` persistidos.
- `GLOBAL`: todos os grupos atualmente abrangidos pelo bot.
- `GLOBAL_PRIVATE`: grupos e conversas privadas abrangidos pelo escopo.

## Matcher

- `EXACT`: mensagem inteira normalizada deve coincidir.
- `WORD`: gatilho como palavra/token.
- `CONTAINS`: gatilho contido no texto.

A normalização preserva o texto original e, por padrão, normaliza caixa, Unicode, acentuação e espaços.

## Segurança

O handler usa a identidade oficial do proprietário (`configuredOwner`) e não aceita admin de grupo como substituto. Sessões são temporárias, possuem `sessionId`, `expiresAt` e não reutilizam índices de lista como IDs persistentes.

## Persistência

As configurações são armazenadas na camada JSON persistente do Fantasminha, separando configurações, vínculos de grupos, estatísticas e auditoria. Exclusões usam soft delete.

## Execução

O pipeline avalia o Reaction Manager para mensagens normais antes das restrições de comandos no PV, permitindo que `GLOBAL_PRIVATE` funcione conforme configurado. Mensagens do próprio bot são ignoradas e mensagens duplicadas são protegidas por uma chave de mensagem em memória.

As reações automáticas legadas do antigo `customReacts` foram desativadas para evitar dois motores concorrentes. `×react` manual continua separado do motor automático configurável.

## Prioridade

`reactionManager = 1000`, substituindo o comando `react` legado sem manter duas implementações concorrentes.
