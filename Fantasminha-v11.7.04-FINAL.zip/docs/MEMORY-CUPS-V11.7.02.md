# ×memoriacopos — Fantasminha 11.7.02

Implementação integrada ao Game Engine central.

## Fluxo

`×memoriacopos` cria uma partida `memory-cups` de um jogador, revela o Fantasminha, esconde a posição, executa uma trajetória pré-calculada com micro-movimentos e edita a mesma mensagem até chegar à tela de resposta.

A posição correta vem exclusivamente do estado persistido da partida e da trajetória. O texto do WhatsApp nunca é usado como fonte de verdade.

## Módulos

- `MemoryCupsService` — orquestra a partida e integra Game Engine, stats, rewards e audit.
- `MemoryCupsDifficultyConfig` — curva de dificuldade e limites técnicos.
- `MemoryCupsShuffleEngine` — gera trajetória determinística para a rodada.
- `MemoryCupsAnimationEngine` — executa frames sem concorrência de edições.
- `MemoryCupsMessageEditController` — fila serial, backpressure, retry e cancelamento.
- `MemoryCupsRenderer` — somente apresentação visual.
- `MemoryCupsAnswerValidator` — valida posição informada.
- `MemoryCupsScoreService` — fórmula de pontuação isolada.
- `MemoryCupsState` — estados internos da partida.

## Progressão

A curva começa em 3 copos, aumenta para 5, 7, 9 e depois cresce de forma controlada até o limite configurado. Movimentos, micro-frames, velocidade, reversões e complexidade também aumentam com o nível.

A arquitetura suporta níveis muito altos sem exigir uma tabela fixa para cada nível. Os limites técnicos continuam centralizados em `MemoryCupsDifficultyConfig`.

## Animação

A animação usa uma única mensagem. O controlador nunca dispara várias edições simultâneas. Se uma edição falhar, o estado interno não muda e o frame seguinte pode continuar normalmente.

Os copos não recebem números durante a animação. A posição numérica só é usada na resposta do jogador.

## Persistência e integração

A partida usa `src/services/gameEngine.js`. Estatísticas usam `statsEngine`; XP usa `platform/rewards`; auditoria usa `platform/audit`. Não existe banco paralelo para a partida.

Eventos registrados:

- `MEMORY_CUPS_STARTED`
- `MEMORY_CUPS_LEVEL_COMPLETED`
- `MEMORY_CUPS_FAILED`
- `MEMORY_CUPS_TIMEOUT`
- `MEMORY_CUPS_CANCELLED`

## Cancelamento e timeout

`×sairjogo` e palavras de saída do mecanismo global encerram a partida. A animação registrada é cancelada junto com a partida para impedir novas edições depois do cancelamento.

O timeout usa `expiresAt` no estado e também o timer existente do Game Session Manager.

## Configuração

Variáveis disponíveis:

- `MEMORY_CUPS_MIN_FRAME_INTERVAL`
- `MEMORY_CUPS_MAX_FRAME_INTERVAL`
- `MEMORY_CUPS_MAX_FRAMES`
- `MEMORY_CUPS_MAX_ANIMATION_MS`
- `MEMORY_CUPS_ANSWER_TIMEOUT`
- `MEMORY_CUPS_SHOW_GHOST_MS`
- `MEMORY_CUPS_HIDE_MS`
- `MEMORY_CUPS_EDIT_RETRIES`
- `MEMORY_CUPS_MAX_CUPS`
- `MEMORY_CUPS_BASE_MOVES`
