# FANTASMINHA — CHECKLIST PREVENTIVO DE RELEASE/UPDATE

Objetivo: impedir que uma atualização seja considerada válida apenas porque a versão e o SHA parecem corretos.

## 1. Antes de publicar
- [ ] `package.json` e `package-lock.json` têm a mesma versão da release.
- [ ] `dados/src/services/assistantV2Core.js` existe e é uma ponte funcional para o core real.
- [ ] `src/services/assistantV2Core.js` possui implementação real.
- [ ] `dados/src/funcs/private/ia.js` importa o Assistant V2 esperado.
- [ ] Nenhum import relativo crítico aponta para arquivo inexistente.
- [ ] Registry, bootstrap, database/store e updater existem.
- [ ] Backup/rollback e health check estão presentes.

## 2. Validação do pacote
- [ ] ZIP pode ser listado sem erro.
- [ ] ZIP não contém `..`, caminhos absolutos ou traversal.
- [ ] Todos os `requiredFiles` estão fisicamente dentro do ZIP.
- [ ] `package.json` dentro do ZIP tem a versão declarada.
- [ ] SHA-256 é calculado sobre o ZIP FINAL.
- [ ] Tamanho do ZIP corresponde ao manifesto.
- [ ] O manifesto externo contém SHA, tamanho e requiredFiles.

## 3. Atualizador
- [ ] Manifesto remoto é validado antes do download/aplicação.
- [ ] SHA é conferido depois do download.
- [ ] Conteúdo obrigatório do ZIP é conferido.
- [ ] Release é validada antes de substituir a instalação.
- [ ] Mesmo número de versão NÃO significa automaticamente "já atualizado" sem validar integridade.
- [ ] Backup validável é criado antes de substituir arquivos.
- [ ] Rollback ocorre se instalação/health check falhar.
- [ ] Arquivos desconhecidos do usuário não são apagados.
- [ ] `.env`, sessão, banco, mídias, logs e `config.json` são preservados.

## 4. Assistant V2
- [ ] `composeAssistantPrompt` real.
- [ ] `guardInput` real.
- [ ] `validateAssistantResult` real.
- [ ] `incrementMetric` real.
- [ ] Sem stub vazio/mock mascarando ausência do core.
- [ ] Import da IA e bridge continuam compatíveis.

## 5. Runtime
- [ ] Bootstrap carrega.
- [ ] Registry carrega.
- [ ] Migrations carregam.
- [ ] Database/persistence responde.
- [ ] Runtime health check passa.
- [ ] Sintaxe JS/MJS passa.
- [ ] Smoke test passa.

## 6. Baileys/sessão
- [ ] Não fechar/reabrir sessão em loop sem motivo real.
- [ ] Crash não deve destruir credenciais válidas.
- [ ] QR não deve ser solicitado novamente quando a sessão continua válida.
- [ ] Reconexão deve usar backoff e limite, evitando loops agressivos.
- [ ] Eventos `creds.update` continuam persistindo credenciais.

## 7. Publicação
- [ ] Rodar `npm run validate:release`.
- [ ] Rodar `npm run test:update-safety`.
- [ ] Rodar `npm run release:build`.
- [ ] Validar o ZIP FINAL novamente com `--zip` + `--manifest`.
- [ ] Só publicar se todos os checks passarem.
- [ ] Guardar SHA-256 do ZIP fora do próprio ZIP para evitar auto-referência.

## 8. Regra de bloqueio
Se qualquer item crítico falhar:

**NÃO PUBLICAR. NÃO INSTALAR. NÃO CONSIDERAR A VERSÃO VÁLIDA.**

O número da versão sozinho nunca é prova de integridade.
