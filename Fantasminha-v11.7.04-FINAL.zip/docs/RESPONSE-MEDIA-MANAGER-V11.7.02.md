# FANTASMINHA 11.7.02 — Response Media Manager

Camada global de apresentação que associa **uma mídia fixa** à mensagem de resposta de uma resposta compatível.

## Regras
- Escopo global do bot; não há configuração por grupo.
- Uma configuração ativa por `responseKey`.
- Suporta IMAGE e GIF/MP4 com `gifPlayback`.
- A mídia é enviada junto da resposta textual em uma única mensagem.
- Sem configuração, o comportamento original permanece.
- `×perfil`, menus e respostas marcadas como nativas/dinâmicas são protegidos.
- Falha de mídia faz fallback para a resposta textual.
- Administração exclusivamente pelo OWNER.
- Persistência em `data/db/response_media.json` e arquivos em `data/response-media/`.
- Sessões administrativas expiram e aceitam `0`/`cancelar`.

## Comandos
- `×media` — configurar
- `×media lista`
- `×media editar`
- `×media info <ID|comando>`
- `×media ativar <ID|comando>`
- `×media desativar <ID|comando>`
- `×media remover <ID|comando>`
- `×media ajuda`

## Arquitetura
`ResponseMediaManager` → `ResponseMediaSessionService` → `ResponseMediaService` → `ResponseMediaRepository` / `ResponseMediaStorage` → `ResponseMediaResolver` / `ResponseMediaExecutor` → sender existente.

A autorização reutiliza `configuredOwner`. A persistência reutiliza `src/database/store.js`. A auditoria reutiliza `src/platform/audit`.
