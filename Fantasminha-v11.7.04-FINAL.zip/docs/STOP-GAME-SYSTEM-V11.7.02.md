# 👻 Fantasminha v11.7.02 — STOP Game System

Sistema STOP multiplayer coletivo integrado ao Game Engine.

## Fluxo
- `×stopcriar` no grupo inicia configuração privada.
- Configuração: 1–10 categorias e 1–5 rodadas.
- `×stopexcluir` usa confirmação privada.
- `×stop` cria uma sessão com lobby de 60 segundos.
- Participação acontece somente pelo código/link enviado ao PV.
- O criador confirma o início com `1` ou cancela com `2`.
- Cada rodada usa uma única letra para todos e dura 120 segundos.
- Respostas são aceitas exclusivamente no PV de participantes.
- Respostas podem ser substituídas até o lock da rodada.
- Validação determinística ocorre antes da IA.
- IA retorna contrato estruturado; sua saída nunca executa comandos nem altera banco diretamente.
- Duplicidade é resolvida somente depois da validação.
- Pontuação: 10 única, 5 repetida válida, 0 inválida/vazia.
- Resultados detalhados são privados; resultado agregado vai ao grupo.
- Sessões e respostas são persistentes e recuperáveis.

## Persistência
Coleções principais:
- `stop_user_configs`
- `stop_sessions`
- `stop_participants`
- `stop_answers`
- `stop_round_results`
- `stop_statistics`

O estado operacional também fica no `Game Engine` em `game.state.stopSession`.

## Privacidade
O sistema nunca usa `group.members` para definir participantes e nunca envia folhas privadas para membros que não entraram. Mensagens comuns do grupo não são respostas STOP.

## IA
Por padrão, a validação usa Gemini se `GEMINI_API_KEY` estiver configurada. Em indisponibilidade, a política segura evita pontuar respostas que não possam ser verificadas semanticamente. A chave não é enviada a outros jogadores e respostas de terceiros não são incluídas na validação individual.

## Recuperação
Lobby e rodadas usam timestamps persistidos. Após reinício, `recover()` reconstrói os timers ou continua a transição correspondente.
