# Response Enrichment — Fantasminha 11.7.02

Camada compartilhada para Response Media e Reaction Engine.

## Núcleo
- Response Registry: capacidades por resposta/commandKey.
- Response Media Manager: mídia fixa global, 0/1 ativa por responseKey.
- Reaction Engine: resolve reações por responseKey e usa providers.
- Provider Registry: EMOJI, STICKER, AUDIO, IMAGE.
- Reaction Policy: bloqueia respostas incompatíveis e evita mídia nativa duplicada.
- Persistência: `reaction_configs` + `data/reaction-media`.
- Auditoria: infraestrutura de auditoria já existente + eventos específicos.

## Interfaces
- `×media` — Response Media.
- `×react` — Emoji.
- `×figreact` — Figurinha.
- `×audioreact` — Áudio.
- `×reactimg` — Imagem.

## Compatibilidade
`×perfil`, menus e respostas marcadas com mídia nativa/dinâmica não recebem enriquecimento incompatível. Falhas de enriquecimento não interrompem a resposta original.

## Extensão
Um novo provider deve implementar `type`, `validate` e `send`, registrar-se no `ReactionProviderRegistry` e, quando necessário, expor um comando administrativo. O núcleo não precisa conhecer detalhes do provider.
