import assert from 'node:assert/strict';
import { generateStopCode } from '../src/games/stop/StopCore.js';

const seen=new Set();
for(let i=0;i<20000;i++){
  const code=generateStopCode();
  assert.match(code,/^STP-[A-Z0-9]{8}$/);
  seen.add(code);
}
assert.equal(seen.size,20000,'colisão inesperada em 20 mil códigos');
console.log('STOP CODE CONTRACT OK — 20.000 códigos com formato STP- + 8 caracteres alfanuméricos');
