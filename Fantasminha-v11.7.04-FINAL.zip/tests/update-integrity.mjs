import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { createValidatedBackup, rollbackFromBackup } from '../dados/src/.scripts/update.js';

const backup = await createValidatedBackup();
try {
  const stat = await fs.stat(backup);
  assert.ok(stat.isFile());
  assert.ok(stat.size > 1024);
  await rollbackFromBackup(backup);
  const pkg = JSON.parse(await fs.readFile(path.join(process.cwd(), 'package.json'), 'utf8'));
  assert.equal(pkg.version, '11.7.04');
  console.log('UPDATE INTEGRITY OK — backup validado + rollback verificável');
} finally {
  await fs.rm(backup, { force: true });
}
