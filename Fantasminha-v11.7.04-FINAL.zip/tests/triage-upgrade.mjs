import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { runCommand } from '../src/core/registry.js';
import {
  saveSettings, getSettings, createTriage, startTriage, validateAndSaveAnswer,
  getTriage, publishForAdmins, STATES
} from '../src/services/triage.js';
import { handleMessage } from '../src/middleware/pipeline.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dbDir = path.join(root, 'data', 'db');
const snap = fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-triage-upgrade-'));
fs.cpSync(dbDir,snap,{recursive:true});

function baseCtx(extra={}) {
  return {
    isGroup:true, isGroupAdmin:true, isOwner:false, isBotAdmin:true,
    from:'group-upgrade@g.us', sender:'admin@lid',
    senderOriginal:'admin@lid', senderAlternate:'5511999999999@s.whatsapp.net',
    prefix:'×', body:'', text:'', q:'',
    groupParticipants:['admin@lid','user1@s.whatsapp.net','user2@s.whatsapp.net','5511888888888@s.whatsapp.net'],
    groupParticipantObjects:[{id:'admin@lid'},{id:'user1@s.whatsapp.net'},{id:'user2@s.whatsapp.net'},{id:'5511888888888@s.whatsapp.net',admin:'admin'}],
    botJid:'5511888888888@s.whatsapp.net', participantCount:4, groupName:'Upgrade',
    reply:async t=>{ replies.push(String(t)); },
    sendMessage:async()=>({ok:true}),
    ...extra
  };
}
const replies=[];

try {
  for (const f of ['groups.json','triage.json','triage_history.json','triage_blacklist.json','triage_audit.json','triage_builder.json','triage_media.json']) {
    try { fs.unlinkSync(path.join(dbDir,f)); } catch {}
  }
  await bootstrapV2();

  // 1) O bug real: identidade PN/LID diferente entre criação e resposta.
  const createCtx=baseCtx({body:'×triagemcriar',text:'×triagemcriar',q:''});
  await runCommand('triagemcriar',createCtx);
  const step1=baseCtx({
    sender:'5511999999999@s.whatsapp.net',
    senderOriginal:'5511999999999@s.whatsapp.net',
    senderAlternate:'admin@lid',
    body:'1', text:'1'
  });
  await handleMessage(step1);
  if(!replies.at(-1)?.includes('Envie a primeira pergunta')) throw new Error('builder não avançou com identidade PN/LID alternada');

  const questionCtx=baseCtx({
    sender:'5511999999999@s.whatsapp.net',
    senderOriginal:'5511999999999@s.whatsapp.net',
    senderAlternate:'admin@lid',
    body:'Qual é seu nome?', text:'Qual é seu nome?'
  });
  await handleMessage(questionCtx);
  const typeCtx={...questionCtx,body:'1',text:'1'};
  await handleMessage(typeCtx);
  const finishCtx={...questionCtx,body:'concluir',text:'concluir'};
  await handleMessage(finishCtx);
  const settings=await getSettings('group-upgrade@g.us');
  if(settings.questions.length!==1 || settings.questions[0].type!=='text' || settings.enabled) throw new Error('builder não salvou a configuração esperada');

  // 2) Cobrança em massa: cria uma triagem por membro e publica no grupo; nunca envia PV.
  replies.length=0;
  const sent=[];
  const groupPosts=[];
  await saveSettings('group-upgrade@g.us',{enabled:true});
  const chargeCtx=baseCtx({
    groupParticipants:['user1@s.whatsapp.net','user2@s.whatsapp.net','user3@s.whatsapp.net','5511888888888@s.whatsapp.net'],
    groupParticipantObjects:[{id:'user1@s.whatsapp.net'},{id:'user2@s.whatsapp.net'},{id:'user3@s.whatsapp.net'},{id:'5511888888888@s.whatsapp.net',admin:'admin'}],
    sender:'admin@lid',
    body:'×triagemcobrar', text:'×triagemcobrar',
    sendMessage:async(jid,content)=>{sent.push({jid,content});return {ok:true};},
    reply:async(t,opts)=>{groupPosts.push({text:String(t),opts});}
  });
  await runCommand('triagemcobrar',chargeCtx);
  if(sent.length!==0) throw new Error(`triagemcobrar não pode enviar PVs, enviou ${sent.length}`);
  if(!groupPosts.length) throw new Error('triagemcobrar não publicou a cobrança no grupo');
  if(!groupPosts.some(x=>x.text.includes('http'))) throw new Error('cobrança sem link');
  if(!groupPosts.some(x=>(x.opts?.mentions||[]).length)) throw new Error('cobrança sem menções');
  const td=(await import('../src/database/store.js')).readCollection('triage',{byId:{}});
  const created=Object.values(td.byId||{}).filter(t=>t.groupId==='group-upgrade@g.us');
  if(created.length!==3) throw new Error(`triagemcobrar criou ${created.length}, esperado 3`);

  // 3) Grupo de triagem: quando conectado, ficha vai para o destino oficial.
  const archive='archive-upgrade@g.us';
  await saveSettings('group-upgrade@g.us',{
    enabled:true,
    questions:[{id:'q1',type:'text',required:true,question:'Nome?',order:1}],
    archiveGroupId:archive
  });
  const c=await createTriage('group-upgrade@g.us','u3@s.whatsapp.net',{botJid:'5511888888888@s.whatsapp.net',force:true});
  const st=await startTriage(c.code);
  if(!st.ok) throw new Error('não iniciou triagem de arquivo');
  const ans=await validateAndSaveAnswer(c.code,'Teste');
  if(!ans.finished) throw new Error('ficha não concluiu');
  const published=[];
  const sock={
    sendMessage:async(jid,content)=>{published.push({jid,content});},
    groupMetadata:async()=>({participants:[
      {id:'admin1@s.whatsapp.net',admin:'admin'},
      {id:'admin2@s.whatsapp.net',admin:'admin'},
      {id:'member@s.whatsapp.net'}
    ]})
  };
  await publishForAdmins(sock,ans.triage);
  if(!published.some(x=>x.jid===archive)) throw new Error('ficha não foi para o grupo de arquivo');
  if(published.some(x=>x.jid==='group-upgrade@g.us')) throw new Error('ficha duplicada no grupo de origem após conexão');
  if(published.filter(x=>x.jid.endsWith('@s.whatsapp.net')).length!==0) throw new Error('ficha não deve ser duplicada em PVs neste modo');

  console.log('TRIAGE UPGRADE OK — builder LID/PN + cobrança em massa + grupo de triagem');
  process.exit(0);
} finally {
  fs.rmSync(dbDir,{recursive:true,force:true});
  fs.cpSync(snap,dbDir,{recursive:true});
  fs.rmSync(snap,{recursive:true,force:true});
}
