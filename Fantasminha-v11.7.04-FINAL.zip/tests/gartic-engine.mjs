import assert from 'node:assert/strict';
import { listCommands, getCommand, validateRegistry } from '../src/core/registry.js';
import * as innovation from '../src/plugins/innovation/index.js';
import * as quiz from '../src/plugins/quiz/index.js';
import * as forca from '../src/plugins/forca/index.js';
import * as stop from '../src/plugins/stop/index.js';
import * as gartic from '../src/plugins/gartic/index.js';
import { buildCatalogMenu } from '../dados/src/menus/catalogMenu.js';

await innovation.register();
await quiz.register();
await forca.register();
await stop.register();
await gartic.register();

const required = [
  'gartic', 'memoriacopos',
  'quiz', 'rankquiz', 'rankquizglobal', 'meurank',
  'forca', 'rankforca', 'meuforca',
  'stop', 'stopcriar', 'stopexcluir'
];
for (const name of required) assert.ok(getCommand(name), `Comando ausente: ${name}`);
assert.equal(getCommand('adedonha')?.name, 'stop');
assert.equal(getCommand('forcarank')?.name, 'rankforca');
assert.equal(getCommand('forcameu')?.name, 'meuforca');
assert.equal(getCommand('trivia')?.name, 'quiz');
assert.ok(validateRegistry().ok, 'Registry inválido');

const menu = buildCatalogMenu('×', 'jogos');
for (const name of required) assert.match(menu, new RegExp(`×${name.replace(/[.*+?^${}()|[\\]\\]/g, '\\\\$&')}`), `Menu não contém: ${name}`);
console.log(`GARTIC ENGINE OK — ${listCommands({category:'jogos'}).length} comandos de jogos registrados e comandos dos 5 jogos presentes no menu`);
