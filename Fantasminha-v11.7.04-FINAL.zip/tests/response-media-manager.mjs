process.env.OWNER_NUMBER = process.env.OWNER_NUMBER || '5511999999999';
process.env.RESPONSE_MEDIA_MAX_MB = '2';

const { default: service } = await import('../src/features/responseMedia/ResponseMediaService.js');
const { default: executor } = await import('../src/features/responseMedia/ResponseMediaExecutor.js');
const { getCapabilities, resolveForResponse } = await import('../src/features/responseMedia/ResponseMediaResolver.js');
const repo = await import('../src/features/responseMedia/ResponseMediaRepository.js');

const key = `test.response-media.${Date.now()}`;
const ctx = { sender: '5511999999999@s.whatsapp.net', from: '120000000000@g.us', isOwner: true, command: 'teste', sendMessage: async (jid, content) => ({ jid, content }) };
const buffer = Buffer.from('fake-image-payload');
const created = await service.create(ctx, { responseKey:key, commandKey:'teste', buffer, mimetype:'image/png', filename:'x.png' });
if (!created || created.status !== 'ACTIVE') throw new Error('create falhou');

const sent = await executor.send(ctx, 'Resposta original', { responseKey:key, mentions:['u@s.whatsapp.net'] });
if (!sent?.content?.image || sent.content.caption !== 'Resposta original') throw new Error('mídia não foi anexada à mesma mensagem');

const blocked = getCapabilities({ command:'perfil' }, { name:'perfil', responseCapabilities:{ supportsCustomMedia:true } });
if (blocked.supportsCustomMedia !== false) throw new Error('perfil deveria estar protegido');
const incompatible = resolveForResponse({ ...ctx, command:'perfil' }, { commandDef:{ name:'perfil', responseCapabilities:{ supportsCustomMedia:false, hasNativeMedia:true } } });
if (incompatible.applicable) throw new Error('resposta incompatível foi aceita');

await service.disable(ctx, key);
if (resolveForResponse(ctx, { responseKey:key }).applicable) throw new Error('mídia desativada ainda está sendo resolvida');
await service.enable(ctx, key);
if (!resolveForResponse(ctx, { responseKey:key }).applicable) throw new Error('mídia não reativou');
await service.remove(ctx, key);
if (repo.getResponseMedia(key)) throw new Error('soft delete ainda deveria ocultar configuração');

const unauthorized = await service.create({ sender:'5511888888888@s.whatsapp.net', from:ctx.from, isOwner:false }, { responseKey:`${key}.unauth`, commandKey:'teste', buffer, mimetype:'image/png', filename:'x.png' }).then(()=>false).catch(e=>e.code==='UNAUTHORIZED');
if (!unauthorized) throw new Error('owner gate falhou');

console.log('RESPONSE MEDIA MANAGER OK — owner, persistência, mídia única, fallback de resolução e proteção de perfil');
