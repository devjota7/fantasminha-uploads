import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { saveSettings, getSettings, createTriage, getTriage, memberJoined, publishForAdmins } from '../src/services/triage.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dbDir=path.join(root,'data','db');
const snap=fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-triage-704-'));
fs.cpSync(dbDir,snap,{recursive:true});
try {
  for(const f of ['groups.json','triage.json','triage_history.json','triage_blacklist.json','triage_audit.json']) try{fs.unlinkSync(path.join(dbDir,f))}catch{}
  const sent=[];
  const sock={
    user:{id:'bot@s.whatsapp.net'},
    groupMetadata:async()=>({participants:[{id:'u1@s.whatsapp.net'},{id:'bot@s.whatsapp.net',admin:'admin'}]}),
    sendMessage:async(jid,content)=>{sent.push({jid,content});},
    groupParticipantsUpdate:async()=>[{status:'200'}]
  };
  await saveSettings('entry@g.us',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome?'}]});
  let s=await getSettings('entry@g.us');
  if(s.triageGroupId!==null||s.approvalGroupIds.length!==0) throw new Error('defaults 11.7.04 inválidos');
  await saveSettings('entry@g.us',{triageGroupId:'judge@g.us',archiveGroupId:'judge@g.us',approvalGroupIds:['perm1@g.us','perm1@g.us','perm2@g.us']});
  s=await getSettings('entry@g.us');
  if(s.triageGroupId!=='judge@g.us'||s.archiveGroupId!=='judge@g.us'||s.approvalGroupIds.length!==2) throw new Error('configuração conectada inválida');
  const c=await createTriage('entry@g.us','u1@s.whatsapp.net',{botJid:'bot@s.whatsapp.net'});
  if(!c.ok||c.triage.entryGroupId!=='entry@g.us'||c.triage.triageGroupId!=='judge@g.us'||c.triage.managementGroupId!=='judge@g.us'||c.triage.approvalGroupIds.length!==2) throw new Error('snapshot da triagem inválido');
  await saveSettings('entry@g.us',{triageGroupId:null,archiveGroupId:null,approvalGroupIds:[]});
  const old=await getTriage(c.code);
  if(old.triageGroupId!=='judge@g.us'||old.managementGroupId!=='judge@g.us'||old.approvalGroupIds.length!==2) throw new Error('snapshot antigo foi alterado');
  const sent2=[];
  const sock2={...sock,sendMessage:async(jid,content)=>sent2.push({jid,content})};
  const c2=await memberJoined(sock2,'entry2@g.us','u2@s.whatsapp.net');
  if(c2.ok) throw new Error('grupo sem perguntas não deveria criar triagem');
  await saveSettings('entry2@g.us',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome?'}]});
  const c3=await memberJoined(sock2,'entry2@g.us','u2@s.whatsapp.net');
  if(!c3.ok||!sent2.some(x=>x.jid==='entry2@g.us'&&x.content.text.includes(c3.code))) throw new Error('onboarding automático não publicou link no grupo');
  await saveSettings('entry3@g.us',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome?'}]});
  const c4=await createTriage('entry3@g.us','u3@s.whatsapp.net',{botJid:'bot@s.whatsapp.net'}); const published=[];
  await publishForAdmins({groupMetadata:async()=>({participants:[]}),sendMessage:async(jid,content)=>published.push({jid,content})},c4.triage);
  if(!published.some(x=>x.jid==='entry3@g.us')) throw new Error('fallback sem conexão não publicou na entrada');
  console.log('TRIAGE 11.7.04 OK — snapshot, modo sem conexão, grupos permanentes e onboarding');
} finally {fs.rmSync(dbDir,{recursive:true,force:true});fs.cpSync(snap,dbDir,{recursive:true});fs.rmSync(snap,{recursive:true,force:true});}
