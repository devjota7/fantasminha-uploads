import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

process.env.MEMORY_CUPS_MIN_FRAME_INTERVAL = '1';
process.env.MEMORY_CUPS_MAX_FRAME_INTERVAL = '1';
process.env.MEMORY_CUPS_MAX_ANIMATION_MS = '5000';
process.env.MEMORY_CUPS_SHOW_GHOST_MS = '1';
process.env.MEMORY_CUPS_HIDE_MS = '1';
process.env.MEMORY_CUPS_ANSWER_TIMEOUT = '1000';

const root = path.resolve(new URL('..', import.meta.url).pathname);
const db = path.join(root, 'data', 'db');
for (const name of ['game_engine.json','stats_engine.json','reward_ledger.json','platform_audit.json','users.json']) {
  try { fs.rmSync(path.join(db, name), { force: true }); } catch {}
}

const { generateTrajectory, validateTrajectory } = await import('../src/games/memory-cups/MemoryCupsShuffleEngine.js');
const { renderRound } = await import('../src/games/memory-cups/MemoryCupsRenderer.js');
const { validateAnswer } = await import('../src/games/memory-cups/MemoryCupsAnswerValidator.js');
const game = await import('../src/games/memory-cups/MemoryCupsService.js');
const engine = await import('../src/services/gameEngine.js');

const t = generateTrajectory({ cupCount: 5, level: 5, initialPosition: 2 });
assert.equal(validateTrajectory(t).ok, true);
assert.equal(t.frames.at(-1).ghostPosition, t.finalPosition);
assert.ok(t.frames.length > 10, 'deve haver muitos frames');
assert.ok(t.frames.every(f => !renderRound({ level: 5, cupCount: 5, offsets: f.offsets }).includes('1️⃣')));
assert.equal(validateAnswer(String(t.finalPosition + 1), t.finalPosition, 5).valid, true);
assert.equal(validateAnswer(String(((t.finalPosition + 1) % 5) + 1), t.finalPosition, 5).valid, false);

const sent = [];
const ctx = {
  from: 'memory-group', sender: 'memory-user', pushname: 'Tester', prefix: '×', isGroup: true,
  sendMessage: async (jid, content) => { sent.push({ jid, content }); return { key: { remoteJid: jid, id: 'MEMORY-MSG-1', fromMe: true } }; },
  reply: async text => sent.push({ reply: text })
};

const started = await game.start(ctx);
assert.equal(started.state.phase, 'WAITING_ANSWER');
assert.ok(started.state.messageId?.id);
const editKeys = sent.filter(x => x.content?.edit).map(x => x.content.edit);
assert.ok(editKeys.length >= 10, 'deve editar muitas vezes');
assert.equal(new Set(editKeys.map(x => x.id)).size, 1, 'toda animação deve editar a mesma mensagem');
const animationTexts = sent.filter(x => x.content?.edit).map(x => x.content.text);
assert.ok(animationTexts.every(text => !/\n\s*1\s+2\s+3|1️⃣|2️⃣|3️⃣/.test(text)), 'não deve exibir números de posição durante a animação');

const answer = String(started.state.ghostCurrentPosition + 1);
const resolved = await game.handleAnswer({ ...ctx, body: answer, text: answer });
assert.equal(resolved.handled, true);
assert.equal(resolved.correct, true);
await new Promise(r => setTimeout(r, 30));
const next = engine.listActiveGames('memory-group').find(x => x.gameType === 'memory-cups');
assert.ok(next, 'acerto deve criar próxima rodada');
assert.equal(next.state.level, 2);
assert.equal(next.state.messageId.id, 'MEMORY-MSG-1', 'a progressão deve reutilizar a mesma mensagem');
await game.cancelForContext(ctx);
assert.equal(engine.listActiveGames('memory-group').filter(x => x.gameType === 'memory-cups').length, 0);

console.log('MEMORY CUPS OK — trajetória, micro-frames, mesma mensagem, resposta, progressão e cleanup');
