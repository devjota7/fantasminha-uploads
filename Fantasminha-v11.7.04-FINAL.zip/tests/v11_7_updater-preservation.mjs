import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { pathToFileURL } from 'url';

const sourceRoot=path.resolve('dados/src/.scripts/update.js');
const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'fantasminha-update-test-'));
const sandbox=path.join(tmp,'project');
await fs.mkdir(path.join(sandbox,'dados/database/qr-code'),{recursive:true});
await fs.mkdir(path.join(sandbox,'data/auth'),{recursive:true});
await fs.mkdir(path.join(sandbox,'data/db'),{recursive:true});
await fs.mkdir(path.join(sandbox,'logs'),{recursive:true});
await fs.mkdir(path.join(sandbox,'dados/src'),{recursive:true});
await fs.writeFile(path.join(sandbox,'dados/database/qr-code/creds.json'),'LOCAL-AUTH');
await fs.writeFile(path.join(sandbox,'data/auth/session.json'),'LOCAL-SESSION');
await fs.writeFile(path.join(sandbox,'data/db/custom.json'),'LOCAL-DATA');
await fs.writeFile(path.join(sandbox,'dados/src/config.json'),'LOCAL-CONFIG');
await fs.writeFile(path.join(sandbox,'.env'),'LOCAL-ENV');
await fs.writeFile(path.join(sandbox,'logs/local.log'),'LOCAL-LOG');
await fs.writeFile(path.join(sandbox,'meu-arquivo-local.txt'),'NUNCA-APAGAR');
await fs.writeFile(path.join(sandbox,'dados/src/old.js'),'OLD-CODE');
const original=process.cwd();
process.chdir(sandbox);
try {
  const mod=await import(pathToFileURL(sourceRoot).href+`?test=${Date.now()}`);
  // Primeira atualização: sem manifesto anterior, nada local é apagado.
  await mod.clearNonProtected();
  for (const [rel,expected] of [
    ['dados/database/qr-code/creds.json','LOCAL-AUTH'],
    ['data/auth/session.json','LOCAL-SESSION'],
    ['data/db/custom.json','LOCAL-DATA'],
    ['dados/src/config.json','LOCAL-CONFIG'],
    ['.env','LOCAL-ENV'],
    ['logs/local.log','LOCAL-LOG'],
    ['meu-arquivo-local.txt','NUNCA-APAGAR'],
    ['dados/src/old.js','OLD-CODE']
  ]) if(await fs.readFile(path.join(sandbox,rel),'utf8')!==expected) throw new Error(`arquivo local alterado/removido: ${rel}`);

  // Com manifesto, somente o código que pertence à release anterior pode ser limpo.
  await fs.writeFile(path.join(sandbox,'.update-owned-files.json'),JSON.stringify({files:['dados/src/old.js','outro-codigo-antigo.js']}));
  await mod.clearNonProtected();
  try { await fs.access(path.join(sandbox,'dados/src/old.js')); throw new Error('código pertencente à release anterior não foi removido'); } catch(e){ if(e.message.includes('não foi removido')) throw e; }
  if(await fs.readFile(path.join(sandbox,'meu-arquivo-local.txt'),'utf8')!=='NUNCA-APAGAR') throw new Error('arquivo local desconhecido foi removido');
  if(await fs.readFile(path.join(sandbox,'.env'),'utf8')!=='LOCAL-ENV') throw new Error('.env foi alterado');
  if(await fs.readFile(path.join(sandbox,'dados/src/config.json'),'utf8')!=='LOCAL-CONFIG') throw new Error('config local foi alterado');
  console.log('V11.7 UPDATER PRESERVATION OK — sessão, dados, env, config, mídias/logs e arquivos locais protegidos');
} finally { process.chdir(original); await fs.rm(tmp,{recursive:true,force:true}); }
