import fs from 'node:fs';import path from 'node:path';
import { DB_ROOT } from '../src/database/store.js';
import ranking from '../src/games/ranking/index.js';
import engine from '../src/games/ranking/GameRankingEngine.js';
import resolver from '../src/games/ranking/GameRankingResolver.js';
import integrity from '../src/games/ranking/GameRankingIntegrityService.js';
import rebuild from '../src/games/ranking/GameRankingRebuildService.js';
await ranking.register();
const f=path.join(DB_ROOT,'game_ranking.json');const old=fs.existsSync(f)?fs.readFileSync(f):null;
try{
 if(fs.existsSync(f))fs.unlinkSync(f);
 await engine.registerMatchResult({gameId:'quiz',gameSessionId:'Q-1',groupId:'A',groupName:'Grupo A',players:[{userId:'u1',points:87,won:true,stats:{correctAnswers:1,totalAnswers:1}}]});
 await engine.registerMatchResult({gameId:'quiz',gameSessionId:'Q-1',groupId:'A',groupName:'Grupo A',players:[{userId:'u1',points:87,won:true,stats:{correctAnswers:1,totalAnswers:1}}]});
 await engine.registerMatchResult({gameId:'quiz',gameSessionId:'Q-2',groupId:'A',groupName:'Grupo A',players:[{userId:'u2',points:100,won:true,stats:{correctAnswers:1,totalAnswers:1}}]});
 await engine.registerMatchResult({gameId:'quiz',gameSessionId:'Q-3',groupId:'B',groupName:'Grupo B',players:[{userId:'u1',points:50,won:false,stats:{wrongAnswers:1,totalAnswers:1}}]});
 const g=resolver.resolve('quiz','group',{groupId:'A',limit:5});if(g.length!==2||g[0].points!==100||g[1].points!==87)throw new Error('ranking de grupo inválido');
 const glob=resolver.resolve('quiz','global',{});if(glob.groups[0].groupId!=='A'||glob.users[0].userId!=='u1'||glob.users[0].points!==137)throw new Error('ranking global inválido');
 const ur=resolver.resolve('quiz','user',{groupId:'A',userId:'u1'});if(ur.group!==2||ur.global!==1)throw new Error('posição inválida');
 const v=await integrity.verifyGame('quiz');if(!v.ok||v.ledgerPoints!==237)throw new Error('integridade inválida');
 await rebuild.rebuildGame('quiz');const after=resolver.resolve('quiz','global',{});if(after.users[0].points!==137)throw new Error('rebuild inválido');
 console.log('GAME RANKING ENGINE OK — ledger real, idempotência, grupo/global, posições, integridade e rebuild');
}finally{if(old)fs.writeFileSync(f,old);else if(fs.existsSync(f))fs.unlinkSync(f);}
