import assert from 'node:assert/strict';
import { parseForcaInput } from '../src/games/forca/ForcaInputParser.js';
import { normalizeWord, normalizeLetter, createRevealed, isComplete } from '../src/games/forca/ForcaStateManager.js';
import { applyLetter, applyWord } from '../src/games/forca/ForcaAttemptManager.js';

assert.equal(normalizeWord('  CAVÁLO  '),'cavalo');
assert.equal(normalizeLetter(' A '),'a');
assert.equal(normalizeLetter('AB'),'');
assert.deepEqual(parseForcaInput('letra A'),{type:'LETTER',accepted:true,value:'a',raw:'A'});
assert.equal(parseForcaInput('letra AB').accepted,false);
assert.equal(parseForcaInput('palavra cavalo').type,'WORD');
assert.equal(parseForcaInput('CAVALO').type,'NONE');
const state={word:'CAVALO',normalizedWord:'cavalo',revealedLetters:createRevealed('CAVALO'),usedLetters:[],remainingAttempts:6,maxAttempts:6,lastPlayerId:null,wordGuesses:0};
let r=applyLetter(state,'a','u1');assert.equal(r.result,'CORRECT_LETTER');assert.equal(state.remainingAttempts,6);assert.equal(state.revealedLetters.filter(Boolean).length,2);
r=applyLetter(state,'x','u2');assert.equal(r.result,'WRONG_LETTER');assert.equal(state.remainingAttempts,5);
r=applyLetter(state,'x','u3');assert.equal(r.result,'ALREADY_USED');assert.equal(state.remainingAttempts,5);
r=applyWord(state,'cavalo','u4');assert.equal(r.result,'WORD_CORRECT');
state.revealedLetters=[true,true,true,true,true,true];assert.equal(isComplete(state),true);
console.log('FORCA ENGINE OK — parser, normalização, tentativas compartilhadas, letra repetida, palavra e conclusão');
