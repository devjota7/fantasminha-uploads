import assert from 'node:assert/strict';
import { clearRegistry, getCommand, registryStats } from '../src/core/registry.js';
import * as expansion from '../src/plugins/expansion/index.js';
import * as mega from '../src/plugins/megaFusion/index.js';
import * as complete from '../src/plugins/completeExpansion/index.js';
clearRegistry();
await expansion.register();
await mega.register();
await complete.register();
for (const name of ['calc','dado','moeda','caraoucoroa','dados','jvelha','pet','torneio','cancelarjogo']) {
  assert.ok(getCommand(name), `comando ausente: ${name}`);
}
assert.equal(getCommand('moeda').plugin, 'completeExpansion');
assert.equal(getCommand('caraoucoroa').name, 'moeda');
assert.equal(getCommand('dado').plugin, 'completeExpansion');
assert.equal(getCommand('calc').plugin, 'expansion5');
assert.equal(registryStats().valid, true);
console.log('11.7.02 HARDENING OK — sem crash de alias; expansão prioritária e Registry válido');
