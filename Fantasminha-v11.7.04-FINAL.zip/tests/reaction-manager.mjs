import assert from 'node:assert/strict';
import { startCreate, handleAnySession, clear } from '../src/features/reactions/ReactionSessionService.js';
import { executeAutomatic } from '../src/features/reactions/ReactionManager.js';
import { getReaction, listReactions, deleteReaction } from '../src/features/reactions/ReactionRepository.js';
import { matchTrigger } from '../src/features/reactions/ReactionValidator.js';

const sent = [];
const owner = '5511999999999@s.whatsapp.net';
const base = { sender: owner, isOwner: true, from: '120363000000000000@g.us', isGroup: true, isPrivate: false, prefix: '×', message: { key: { remoteJid: '120363000000000000@g.us', id: 'REACTION-TEST-1', fromMe: false } }, sendMessage: async (jid, content) => { sent.push({ jid, content }); return { ok: true }; }, reply: async text => sent.push({ reply: text }), listGroups: async () => [{ id:'120363000000000000@g.us', name:'Grupo Teste' }] };

// Owner-only gate.
const denied = [];
await startCreate({ ...base, isOwner:false, reply: async t => denied.push(t) });
assert.match(denied[0], /ACESSO NEGADO/);

// Full creation session: trigger -> emoji -> scope -> groups -> match -> confirm.
await startCreate(base);
await handleAnySession({ ...base, body:'jota-test' });
await handleAnySession({ ...base, body:'❤️' });
await handleAnySession({ ...base, body:'1' });
await handleAnySession({ ...base, body:'1' });
await handleAnySession({ ...base, body:'1' });
await handleAnySession({ ...base, body:'1' });
const created = listReactions().find(r => r.triggerText === 'jota-test');
assert.ok(created, 'reaction should be persisted');
assert.equal(created.scope, 'LOCAL');
assert.equal(created.groups[0], '120363000000000000@g.us');
assert.equal(created.matchMode, 'EXACT');

// Matcher modes.
assert.equal(matchTrigger('JOTA-TEST', { ...created, matchMode:'EXACT' }), true);
assert.equal(matchTrigger('fala JOTA-TEST', { ...created, matchMode:'WORD' }), true);
assert.equal(matchTrigger('fala JOTA-TEST agora', { ...created, matchMode:'CONTAINS' }), true);

// Automatic execution and self-ignore.
sent.length = 0;
await executeAutomatic({ ...base, body:'JOTA-TEST' });
assert.equal(sent.some(x => x.content?.react?.text === '❤️'), true);
sent.length = 0;
await executeAutomatic({ ...base, body:'JOTA-TEST', fromMe:true });
assert.equal(sent.length, 0);

await deleteReaction(created.reactionId, owner);
clear(owner);
console.log('REACTION MANAGER OK — owner gate, sessão, persistência, matcher, escopo e execução automática');
