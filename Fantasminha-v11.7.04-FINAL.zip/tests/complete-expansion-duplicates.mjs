import assert from 'node:assert/strict';
import fs from 'node:fs';

const source=fs.readFileSync('src/plugins/completeExpansion/index.js','utf8');
const names=[...source.matchAll(/safe\(\{name:'([^']+)'/g)].map(m=>m[1]);
const counts=new Map();
for(const name of names) counts.set(name,(counts.get(name)||0)+1);
const duplicates=[...counts.entries()].filter(([,count])=>count>1).map(([name,count])=>`${name}(${count})`);
assert.deepEqual(duplicates,[],`registros canônicos duplicados: ${duplicates.join(', ')}`);
assert.doesNotMatch(source,/×forcax\b/,'comando fantasma ×forcax ainda anunciado');
console.log(`COMPLETE EXPANSION REGISTRY OK — ${names.length} registros canônicos sem duplicação e sem ×forcax`);
