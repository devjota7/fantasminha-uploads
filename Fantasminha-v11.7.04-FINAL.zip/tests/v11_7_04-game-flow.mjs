import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { updateCollection, readCollection } from '../src/database/store.js';
import game from '../src/services/gameEngine.js';
import { createSession, handleAnswer, handleGroupInput, recover as recoverStop } from '../src/games/stop/StopCore.js';
import { createTriage, handlePrivateMessage, judgeTriage, STATES, saveSettings, getTriage } from '../src/services/triage.js';
import garticProvider from '../src/games/gartic/GarticImageProvider.js';
import garticStorage from '../src/games/gartic/GarticImageStorage.js';

const db=path.join(process.cwd(),'data','db'); fs.mkdirSync(db,{recursive:true});
const ids=['game_engine.json','stop_user_configs.json','stop_private_state.json','stop_sessions.json','stop_participants.json','stop_answers.json','stop_round_results.json','stop_statistics.json','groups.json','triage.json','triage_audit.json','triage_history.json','triage_blacklist.json'];
const backup={}; for(const n of ids){const f=path.join(db,n);backup[n]=fs.existsSync(f)?fs.readFileSync(f):null;}
const sent=[];
const mk=(extra={})=>({sender:'111@s.whatsapp.net',from:'120363000000000001@g.us',isGroup:true,isPrivate:false,prefix:'×',pushname:'Tester',botJid:'999999999@s.whatsapp.net',isOwner:false,isGroupAdmin:true,sendMessage:async(j,c)=>{sent.push({j,c});return {key:{id:`msg-${sent.length}`}};},reply:async(t,o)=>{sent.push({j:'120363000000000001@g.us',c:{text:t,o}});return {key:{id:`reply-${sent.length}`}};},...extra});
try {
  for(const n of ids) fs.rmSync(path.join(db,n),{force:true});

  // STOP: configurar -> criar -> entrar por código -> iniciar -> responder -> pontuar -> finalizar.
  const u='111@s.whatsapp.net';
  await updateCollection('stop_user_configs',d=>{d.byId??={};d.byId[u]={status:'ACTIVE',categories:['Animal','Comida'],roundsTotal:1,createdAt:Date.now(),updatedAt:Date.now()};return d;},{byId:{}});
  const creator=mk({sender:u});
  const created=await createSession(creator); assert.ok(created); const stopGame=game.listActiveGames(creator.from).find(x=>x.gameType==='STOP'); assert.ok(stopGame);
  const stopCode=stopGame.state.stopSession.stopCode; assert.match(stopCode,/^STP-[A-Z0-9]{8}$/);
  const join=await handleAnswer({sender:'222@s.whatsapp.net',from:'222@s.whatsapp.net',isGroup:false,isPrivate:true,body:stopCode,text:stopCode,sendMessage:async(j,c)=>sent.push({j,c}),reply:async()=>{}}); assert.equal(join.joined,true);
  await game.updateGame(stopGame.gameId,creator.from,x=>{x.state.stopSession.status='WAITING_CREATOR_START';return x;});
  const start=await handleGroupInput({...creator,body:'1',text:'1'}); assert.equal(start.started,true);
  let active=game.getGame(stopGame.gameId); assert.equal(active.state.stopSession.status,'ROUND_ACTIVE');
  const letter=active.state.stopSession.round.letter;
  const answer=letter==='A'?'Animal: abelha\nComida: arroz':`Animal: ${letter.toLowerCase()}ato\nComida: ${letter.toLowerCase()}a`; 
  const pv=await handleAnswer({sender:'222@s.whatsapp.net',from:'222@s.whatsapp.net',isGroup:false,isPrivate:true,body:answer,text:answer,message:{key:{id:'stop-answer-1'}},sendMessage:async(j,c)=>sent.push({j,c}),reply:async()=>{}}); assert.equal(pv.updated,true);
  await game.updateGame(stopGame.gameId,creator.from,x=>{x.state.stopSession.round.expiresAt=Date.now()-1;return x;});
  await recoverStop();
  assert.equal(game.getGame(stopGame.gameId),null,'STOP de 1 rodada deve finalizar');
  const stopStats=readCollection('stop_statistics',{players:{}}); assert.ok(Object.keys(stopStats.players||{}).length>=1);

  // Triagem: configuração -> criação -> código no PV -> respostas -> julgamento humano.
  const tg='120363000000000002@g.us', tu='333@s.whatsapp.net';
  await saveSettings(tg,{enabled:true,questions:[{id:'q1',type:'text',question:'Nome',required:true},{id:'q2',type:'text',question:'Nick',required:true}],maxQuestions:2,triageGroupId:null,approvalGroupIds:[]});
  const tc=await createTriage(tg,tu,{botJid:'999999999@s.whatsapp.net'}); assert.equal(tc.ok,true); assert.match(tc.code,/^TRG-[A-F0-9]{8}$/);
  const pvSent=[]; const pvSend=async text=>pvSent.push(text);
  const first=await handlePrivateMessage({info:{key:{fromMe:false}},sender:tu,text:tc.code,send:pvSend}); assert.equal(first.handled,true); assert.equal((await getTriage(tc.code)).state,STATES.RUNNING);
  const a1=await handlePrivateMessage({info:{key:{fromMe:false}},sender:tu,text:'Eduardo',send:pvSend}); assert.equal(a1.handled,true);
  const a2=await handlePrivateMessage({info:{key:{fromMe:false}},sender:tu,text:'Fantasminha',send:pvSend}); assert.equal(a2.handled,true); const done=await getTriage(tc.code); assert.equal(done.state,STATES.JUDGING); assert.equal(done.answers.length,2);
  const judged=await judgeTriage(tc.code,{id:'admin@s.whatsapp.net',name:'Admin'},'approve'); assert.equal(judged.ok,true); assert.equal((await getTriage(tc.code)).state,STATES.APPROVED);

  // Gartic: provedor consegue transformar resposta base64 em imagem real e o storage persiste.
  const oldFetch=globalThis.fetch;
  globalThis.fetch=async()=>new Response(JSON.stringify({data:[{b64_json:Buffer.from('fake-image-bytes').toString('base64')}] }),{status:200,headers:{'content-type':'application/json'}});
  process.env.XAI_API_KEY='test-key'; process.env.GARTIC_IMAGE_MODEL='test-image-model';
  const image=await garticProvider.generate('desenho de um cachorro'); assert.ok(Buffer.isBuffer(image)); assert.ok(image.length>0);
  const stored=garticStorage.save('SIM-IMAGE-TEST',image); assert.ok(fs.existsSync(stored.path)); assert.equal(stored.size,image.length); garticStorage.remove(stored.ref); globalThis.fetch=oldFetch;

  console.log('V11.7.04 GAME FLOW OK — STOP completo; triagem completa; Gartic geração/storage simulados.');
} finally { for(const n of ids){const f=path.join(db,n);if(backup[n]===null)fs.rmSync(f,{force:true});else fs.writeFileSync(f,backup[n]);} }
