import assert from 'node:assert/strict';
import game from '../src/services/gameEngine.js';
import license from '../src/services/licenseEngine.js';
const group=`test-v2-${Date.now()}`, a='u1', b='u2';
const g=await game.createGame({groupId:group,gameType:'test',creatorId:a,maxPlayers:2,state:{x:1},timeoutMs:10000});
await game.inviteGame(g.gameId,b,group); const j=await game.joinGame(g.gameId,b,group); assert.equal(j.participants.length,2); await game.startGame(g.gameId,group,a); await game.finishGame(g.gameId,group,{status:'FINISHED',winnerId:a,result:{ok:true}}); const r=await game.rematch(g.gameId,a,group); assert.equal(r.metadata.rematchOf,g.gameId); const l=license.upsert({groupId:group,plan:'PREMIUM',days:7,actor:a,features:['games']}); assert.equal(l.plan,'PREMIUM'); assert.equal(license.status(group).premium,true); console.log('COMPLETE EXPANSION V2 OK — convite, entrada, revanche, licença e persistência');
