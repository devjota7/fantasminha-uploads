import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { searchCommands, explainCommand } from '../src/services/commandSearch.js';
import { isDuplicateMessage } from '../src/middleware/messageDedup.js';
import { quizStart } from '../src/services/minigames.js';
import { handleRawGameInput } from '../src/services/gameInput.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dbDir=path.join(root,'data','db');
fs.mkdirSync(dbDir,{recursive:true});
const snap=fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-v1152-'));
fs.cpSync(dbDir,snap,{recursive:true});
try{
  await bootstrapV2();
  const wars=searchCommands('quero fazer guerras',{limit:5});
  if(wars.length!==5) throw new Error(`busca deveria retornar 5, retornou ${wars.length}`);
  if(!wars.some(x=>['clagrupoguerra','campeonato','guerragrupo'].includes(x.command.name))) throw new Error('busca sem comandos de guerra relevantes');
  if(explainCommand('stop')?.name!=='stop') throw new Error('ajuda não resolve alias/nome');
  const msg={key:{remoteJid:'g@g.us',id:'MSG-123',participant:'u@s.whatsapp.net'}};
  const ctx={message:msg,from:'g@g.us',sender:'u@s.whatsapp.net'};
  if(isDuplicateMessage(ctx)) throw new Error('primeira mensagem marcada como duplicada');
  if(!isDuplicateMessage(ctx)) throw new Error('segunda entrega não foi deduplicada');
  const q=await quizStart('v1152-game@g.us');
  const replies=[];
  const gameCtx={isGroup:true,from:'v1152-game@g.us',sender:'u@s.whatsapp.net',body:'2',text:'2',prefix:'×',reply:async t=>replies.push(String(t))};
  const result=await handleRawGameInput(gameCtx);
  if(!result.handled||!replies.length) throw new Error('resposta numérica do quiz não foi processada');
  const updater=fs.readFileSync(path.join(root,'dados','src','.scripts','update.js'),'utf8');
  if(!updater.includes('async function removeOwnedFilesOnly')) throw new Error('updater sem limpeza por ownership');
  if(!updater.includes('Nenhum manifesto de arquivos antigos')) throw new Error('updater sem modo seguro na primeira atualização');
  if(!updater.includes('config.json')) throw new Error('config local não está protegida');
  if(!updater.includes("path.join(ROOT, 'dados', 'database', 'qr-code')")) throw new Error('garantia do diretório QR ausente');
  console.log(`V11.5.3 STABILITY OK — busca ${wars.length}, ajuda, dedupe, resposta numérica e saída de jogo`);
} finally {
  fs.rmSync(dbDir,{recursive:true,force:true});
  fs.cpSync(snap,dbDir,{recursive:true});
  fs.rmSync(snap,{recursive:true,force:true});
}
