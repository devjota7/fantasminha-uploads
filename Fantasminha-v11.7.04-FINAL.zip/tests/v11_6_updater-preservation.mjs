import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { pathToFileURL } from 'url';

const sourceRoot=path.resolve('dados/src/.scripts/update.js');
const tmp=await fs.mkdtemp(path.join(os.tmpdir(),'fantasminha-update-test-'));
const sandbox=path.join(tmp,'project');
await fs.mkdir(path.join(sandbox,'dados/database/qr-code'),{recursive:true});
await fs.mkdir(path.join(sandbox,'dados/database/grupos'),{recursive:true});
await fs.mkdir(path.join(sandbox,'dados/src'),{recursive:true});
await fs.mkdir(path.join(sandbox,'data/auth'),{recursive:true});
await fs.mkdir(path.join(sandbox,'data/db'),{recursive:true});
await fs.mkdir(path.join(sandbox,'data/backups'),{recursive:true});
await fs.mkdir(path.join(sandbox,'logs'),{recursive:true});
await fs.writeFile(path.join(sandbox,'dados/database/qr-code/creds.json'),'LOCAL-AUTH');
await fs.writeFile(path.join(sandbox,'data/auth/session.json'),'LOCAL-SESSION');
await fs.writeFile(path.join(sandbox,'logs/local.log'),'LOCAL-LOG');
await fs.writeFile(path.join(sandbox,'dados/src/old.js'),'OLD-CODE');
await fs.writeFile(path.join(sandbox,'old-root.js'),'OLD-ROOT');
const original=process.cwd();
process.chdir(sandbox);
try {
  const mod=await import(pathToFileURL(sourceRoot).href+`?test=${Date.now()}`);
  await mod.clearNonProtected();
  if(await fs.readFile(path.join(sandbox,'dados/database/qr-code/creds.json'),'utf8')!=='LOCAL-AUTH') throw new Error('auth local foi removida');
  if(await fs.readFile(path.join(sandbox,'data/auth/session.json'),'utf8')!=='LOCAL-SESSION') throw new Error('session local foi removida');
  if(await fs.readFile(path.join(sandbox,'logs/local.log'),'utf8')!=='LOCAL-LOG') throw new Error('log local foi removido');
  if(await fs.readFile(path.join(sandbox,'dados/src/old.js'),'utf8')!=='OLD-CODE') throw new Error('arquivo local foi alterado sem manifesto de ownership');
  if(await fs.readFile(path.join(sandbox,'old-root.js'),'utf8')!=='OLD-ROOT') throw new Error('arquivo raiz local foi alterado sem manifesto de ownership');
  await mod.ensureRuntimeDirectories();
  await fs.access(path.join(sandbox,'dados/database/qr-code'));
  console.log('V11.6 UPDATER PRESERVATION OK — auth/session/logs e arquivos locais sobreviveram à limpeza');
} finally { process.chdir(original); await fs.rm(tmp,{recursive:true,force:true}); }
