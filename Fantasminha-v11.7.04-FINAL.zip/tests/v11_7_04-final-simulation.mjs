import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { privateMessageAllowed, isTriageCode, isStopCode } from '../src/services/pvGateway.js';
import { matches } from '../src/games/gartic/GarticAnswerValidator.js';
import { parseForcaInput } from '../src/games/forca/ForcaInputParser.js';
import { applyLetter, applyWord } from '../src/games/forca/ForcaAttemptManager.js';
import { createRevealed, isComplete } from '../src/games/forca/ForcaStateManager.js';
import { validateDeterministic } from '../src/games/stop/StopAnswerValidator.js';
import { scoreRound } from '../src/games/stop/StopScoreEngine.js';
import { listCommands, getCommand, validateRegistry } from '../src/core/registry.js';
import * as quizPlugin from '../src/plugins/quiz/index.js';
import * as forcaPlugin from '../src/plugins/forca/index.js';
import * as stopPlugin from '../src/plugins/stop/index.js';
import * as garticPlugin from '../src/plugins/gartic/index.js';
import * as rankingPlugin from '../src/plugins/ranking/index.js';
import * as innovationPlugin from '../src/plugins/innovation/index.js';

assert.equal(isTriageCode('TRG-A1B2C3D4'), true);
assert.equal(isStopCode('STP-AB12CD34'), true);
assert.equal(privateMessageAllowed('TRG-A1B2C3D4'), true);
assert.equal(privateMessageAllowed('STP-AB12CD34'), true);
assert.equal(privateMessageAllowed('oi'), false);
assert.equal(privateMessageAllowed('×menu'), false);

// Gartic: tolerância real a acentos, hífen, plural e pequenos erros de digitação.
assert.equal(matches('cachorro','cachorro'), true);
assert.equal(matches('caxorro','cachorro'), true);
assert.equal(matches('CACHORROS','cachorro',['cães']), true);
assert.equal(matches('cão','cachorro',['cao']), true);

// Forca: erro não encerra, letra correta revela, palavra correta finaliza.
const state={word:'CAVALO',normalizedWord:'cavalo',revealedLetters:createRevealed('CAVALO'),usedLetters:[],remainingAttempts:6,maxAttempts:6,lastPlayerId:null,wordGuesses:0};
assert.equal(parseForcaInput('letra A').accepted,true);
assert.equal(applyLetter(state,'a','u1').result,'CORRECT_LETTER');
assert.equal(state.remainingAttempts,6);
assert.equal(applyLetter(state,'x','u2').result,'WRONG_LETTER');
assert.equal(state.remainingAttempts,5);
assert.equal(isComplete(state),false);
assert.equal(applyWord(state,'cavalo','u3').result,'WORD_CORRECT');

// STOP: fallback sem IA continua pontuando após validação determinística.
const det=validateDeterministic({name:'Animal'},'cachorro','C');
assert.equal(det.valid,null);
const validations={u1:{animal:{status:'VALID',answerNormalized:'cachorro',points:0}},u2:{animal:{status:'VALID',answerNormalized:'gato',points:0}}};
scoreRound([{userId:'u1'},{userId:'u2'}],validations);
assert.equal(validations.u1.animal.points,10);
assert.equal(validations.u2.animal.points,10);

// Catálogo: registra os cinco jogos + ranking e verifica handlers.
await innovationPlugin.register(); await quizPlugin.register(); await forcaPlugin.register(); await stopPlugin.register(); await garticPlugin.register(); await rankingPlugin.register();
const registry=validateRegistry();
assert.equal(registry.ok,true);
const commands=listCommands();
assert.ok(commands.length >= 18);
for(const c of commands) assert.equal(typeof c.handler,'function',`Handler ausente: ${c.name}`);
for(const name of ['stop','gartic','quiz','forca','memoriacopos','rankstop','rankgartic','rankquiz','rankforca','rankmemoriacopos']) assert.ok(getCommand(name),`Comando crítico ausente: ${name}`);

const pipeline=fs.readFileSync(path.join(process.cwd(),'src/middleware/pipeline.js'),'utf8');
assert.match(pipeline,/handleTriagePrivateMessage/);
assert.match(pipeline,/privateMessageAllowed/);
const index=fs.readFileSync(path.join(process.cwd(),'dados/src/index.js'),'utf8');
assert.match(index,/const shouldRunV2 = true/);
console.log(`V11.7.04 FINAL SIMULATION OK — ${commands.length} comandos com handlers; PV restrito; Gartic tolerante; Forca continua; STOP pontua sem depender de IA.`);
