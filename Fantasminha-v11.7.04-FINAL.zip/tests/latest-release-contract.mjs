import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.cwd();
const requiredDocs = [
  'README.md',
  'CHANGELOG.md',
  'REGRAS-OBRIGATORIAS-FANTASMINHA.txt'
];
for (const file of requiredDocs) {
  if (!fs.existsSync(path.join(ROOT, file))) throw new Error(`Documento obrigatório ausente: ${file}`);
}
const pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const latestPath = path.join(ROOT, 'latest.json');
if (!fs.existsSync(latestPath)) throw new Error('latest.json ausente na raiz do projeto');
const latest = JSON.parse(fs.readFileSync(latestPath, 'utf8'));
for (const field of ['version', 'name', 'release', 'zip', 'sha256', 'notes', 'minNode']) {
  if (latest[field] === undefined || latest[field] === null || latest[field] === '') throw new Error(`latest.json sem campo obrigatório: ${field}`);
}
if (String(latest.version) !== String(pkg.version)) throw new Error(`latest.json=${latest.version}, package.json=${pkg.version}`);
if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(String(pkg.version))) throw new Error('package.json com versão inválida');
const changelog = fs.readFileSync(path.join(ROOT, 'CHANGELOG.md'), 'utf8');
if (!changelog.includes(`## [${pkg.version}]`)) throw new Error(`CHANGELOG sem seção da versão ${pkg.version}`);
const rules = fs.readFileSync(path.join(ROOT, 'REGRAS-OBRIGATORIAS-FANTASMINHA.txt'), 'utf8');
for (const term of ['38.4.', '38.5.', '38.6.', '38.11.', '38.15.']) {
  if (!rules.includes(term)) throw new Error(`Regra permanente latest ausente: ${term}`);
}
console.log(`LATEST RELEASE CONTRACT OK — documentação e regra permanente presentes para v${pkg.version}.`);
