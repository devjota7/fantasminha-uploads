import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import game from '../src/services/gameEngine.js';
import { beginConfig, handleAnswer, handleGroupInput, createSession, recover, STOP_STATES } from '../src/games/stop/StopCore.js';
import { readCollection } from '../src/database/store.js';

const dbDir=path.join(process.cwd(),'data','db'); fs.mkdirSync(dbDir,{recursive:true});
const names=['game_engine.json','stop_user_configs.json','stop_private_state.json','stop_sessions.json','stop_participants.json','stop_answers.json','stop_round_results.json','stop_statistics.json'];
const backup={}; for(const n of names){const f=path.join(dbDir,n);backup[n]=fs.existsSync(f)?fs.readFileSync(f):null;}
const sent=[]; const make=(extra={})=>({sender:'111@s.whatsapp.net',from:'120@g.us',isGroup:true,isPrivate:false,prefix:'×',pushname:'Tester',botJid:'9999999999@s.whatsapp.net',isOwner:false,isGroupAdmin:false,sendMessage:async(j,c)=>{sent.push({j,c});},reply:async(t,o)=>{sent.push({j:'120@g.us',c:{text:t,options:o}});},...extra});
try{
  for(const n of names) fs.rmSync(path.join(dbDir,n),{force:true});
  await beginConfig(make());
  let pv={sender:'111@s.whatsapp.net',from:'111@s.whatsapp.net',isGroup:false,isPrivate:true,body:'Animal, Comida, Nome',text:'Animal, Comida, Nome',sendMessage:async(j,c)=>sent.push({j,c}),reply:async()=>{}};
  assert.equal((await handleAnswer(pv)).handled,true);
  pv={...pv,body:'1',text:'1'}; assert.equal((await handleAnswer(pv)).completed,true);
  await createSession(make()); assert.ok(readCollection('stop_sessions',{}).byId);
  let g=game.listActiveGames('120@g.us').find(x=>x.gameType==='STOP'); assert.ok(g);
  const code=g.state.stopSession.stopCode;
  const firstJoin=await handleAnswer({...pv,sender:'111@s.whatsapp.net',from:'111@s.whatsapp.net',body:code,text:code});
  assert.equal(firstJoin.joined,true,'primeiro participante deve entrar pelo código');
  const secondJoin=await handleAnswer({...pv,sender:'222@s.whatsapp.net',from:'222@s.whatsapp.net',body:code,text:code});
  assert.equal(secondJoin.joined,true,'segundo participante deve entrar pelo código');
  const duplicateJoin=await handleAnswer({...pv,sender:'222@s.whatsapp.net',from:'222@s.whatsapp.net',body:code,text:code});
  assert.equal(duplicateJoin.duplicate,true,'reentrada deve ser idempotente');
  g=game.getGame(g.gameId); await game.updateGame(g.gameId,g.groupId,x=>{x.state.stopSession.lobbyExpiresAt=Date.now()-1;return x;});
  await recover();
  g=game.getGame(g.gameId); assert.equal(g.state.stopSession.status,STOP_STATES.WAITING_CREATOR_START);
  await handleGroupInput(make({body:'1',text:'1'}));
  g=game.getGame(g.gameId); assert.equal(g.state.stopSession.status,STOP_STATES.ROUND_ACTIVE); assert.equal(g.state.stopSession.round.letter.length,1);
  const letter=g.state.stopSession.round.letter;
  const ans=`${g.state.stopSession.categoriesSnapshot[0].name}: ${letter}aco`;
  for(const user of ['111@s.whatsapp.net','222@s.whatsapp.net']) await handleAnswer({...pv,sender:user,from:user,body:ans,text:ans});
  g=game.getGame(g.gameId); await game.updateGame(g.gameId,g.groupId,x=>{x.state.stopSession.round.expiresAt=Date.now()-1;return x;});
  await recover();
  assert.equal(game.getGame(g.gameId),null,'1 rodada deve finalizar a partida');
  const stats=readCollection('stop_statistics',{players:{}}); assert.equal(Object.keys(stats.players||{}).length,2);
  console.log('STOP ENGINE OK — configuração privada, lobby 60s, participação por código, criador, letra única, respostas privadas, validação, 10/5/0, persistência, finalização e estatísticas');
} finally {
  for(const n of names){const f=path.join(dbDir,n);if(backup[n]===null)fs.rmSync(f,{force:true});else fs.writeFileSync(f,backup[n]);}
}
