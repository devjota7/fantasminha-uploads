import assert from 'node:assert/strict';
import { registerCommand, clearRegistry } from '../src/core/registry.js';
import { setAfk, findAfk, clearAfkFromMessage, clearAfk } from '../src/services/social.js';
import menu from '../dados/src/menus/menu.js';

clearRegistry();
registerCommand({name:'perfil',category:'perfil',handler:async()=>{}});
registerCommand({name:'quiz',category:'jogos',handler:async()=>{}});
registerCommand({name:'saldo',category:'economia',handler:async()=>{}});
registerCommand({name:'triagem',category:'triagem',handler:async()=>{}});
registerCommand({name:'segredo',category:'admin',hidden:true,handler:async()=>{}});

const ctx = {
  sender:'5511999990002@s.whatsapp.net',
  prefix:'×',
  body:'×afk fui dormir',
  pushname:'Jota',
  isGroup:true,
  mentioned:[]
};
await setAfk(ctx,'fui dormir');
assert.ok(await findAfk(ctx,ctx.sender));
await clearAfkFromMessage({...ctx,body:'qualquer mensagem'});
assert.equal(await findAfk(ctx,ctx.sender),null);
await setAfk(ctx,'teste');
await clearAfkFromMessage({...ctx,body:'×afk outro motivo'});
assert.ok(await findAfk(ctx,ctx.sender));
await clearAfk(ctx);

const main = await menu('×','Fantasminha','Jota');
assert.match(main,/FANTASMINHA — MENU PRINCIPAL/);
assert.match(main,/Comandos canônicos visíveis:/);
assert.match(main,/×menu social/);
assert.match(main,/5/);
const sub = await menu('×','Fantasminha','Jota',null,{category:'jogos',page:1});
assert.match(sub,/🎮 JOGOS/);
assert.match(sub,/×quiz/);
assert.doesNotMatch(sub,/×segredo/);
console.log('V11.7 AFK/MENU OK — AFK clássico, menu combinado e comandos públicos por categoria');
