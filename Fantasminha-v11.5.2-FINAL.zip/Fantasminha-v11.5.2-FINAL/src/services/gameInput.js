import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
const norm=s=>String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();

export async function handleRawGameInput(ctx){
  const text=String(ctx.body||ctx.text||'').trim();
  if(!text || text.startsWith(ctx.prefix||'×')) return {handled:false};
  const key=ctx.isGroup?ctx.from:ctx.sender;
  if(['sair','sairjogo','sairjogos','cancelar','cancelarjogo','pararjogo','desistir'].includes(norm(text))){
    let removed=false;
    try{
      await updateCollection('minigames',M=>{ if(M.wordle?.[key]){delete M.wordle[key];removed=true;} if(M.stop?.[key]){delete M.stop[key];removed=true;} if(M.quiz?.[key]){delete M.quiz[key];removed=true;} if(M.bj?.[ctx.sender]){delete M.bj[ctx.sender];removed=true;} return M; },{});
    }catch{}
    for(const k of ['quizGames','wordleGames','stopGames','anagramaGames']) try{if(global[k]?.[key]){delete global[k][key];removed=true;}}catch{}
    if(!removed) return {handled:false};
    await ctx.reply?.(`🚪✨ *Jogo encerrado!*\n\nVocê saiu da partida. Quando quiser, é só começar outra. 👻`);
    return {handled:true};
  }

  // Quiz legado em banco: permite responder diretamente com número/texto sem prefixo.
  try{
    const M=readCollection('minigames',{}); const g=M.quiz?.[key];
    if(g){
      let answer=text;
      if(/^\d+$/.test(text) && Array.isArray(g.options)) answer=g.options[Number(text)-1] || text;
      const ok=(g.answers||[]).some(a=>norm(answer).includes(norm(a)));
      await updateCollection('minigames',X=>{delete X.quiz[key];return X;},{});
      await ctx.reply?.(ok?`🎉✨ *ACERTOU!*\n\n👻 O véu confirmou sua resposta.`:`🌑 *NÃO FOI DESSA!*\n\nA resposta correta era: *${g.display||'a resposta do quiz'}*`);
      return {handled:true};
    }
  }catch(e){ throw e; }

  if(global.quizGames?.[key]){
    const game=global.quizGames[key];
    let answer=text;
    if(/^\d+$/.test(text) && Array.isArray(game.opcoes)) answer=game.opcoes[Number(text)-1]||text;
    const ok=(game.respostas||[]).some(r=>norm(answer)===norm(r)||norm(answer).includes(norm(r)));
    delete global.quizGames[key];
    await ctx.reply?.(ok?'🎉✨ *ACERTOU!*':'❌ *NÃO FOI DESSA!*');
    return {handled:true};
  }
  return {handled:false};
}
export default {handleRawGameInput};
