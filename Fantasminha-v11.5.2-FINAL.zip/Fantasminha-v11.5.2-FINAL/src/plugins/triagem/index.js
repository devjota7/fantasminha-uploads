import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import config from '../../core/config.js';
import { readCollection } from '../../database/store.js';
import {
  beginTriageBuilder, deleteTriageConfiguration, getSettings, saveSettings, getTriage, triageFullText, triageSummaryText,
  judgeTriage, cancelActiveTriage, triageStats, blacklistCheck, setBlacklist, removeBlacklist,
  blacklistList, blacklistInfo, blacklistHistory, blacklistStats, STATES, handleTriageBuilderMessage,
  memberJoined, createTriage, rejectionHistory, triageLink
} from '../../services/triage.js';

const tag=t=>`👻 *FANTASMINHA — TRIAGEM*\n\n${t}`;
const target=ctx=>ctx.mentioned?.[0]||null;
const idOf=u=>String(u||'').split('@')[0];
const parseId=q=>String(q||'').trim().split(/\s+/)[0].toUpperCase();
const isBot=(id,bot)=>String(id||'').split('@')[0]===String(bot||'').split('@')[0];

export async function register(){
  registerCommand({name:'triagemcriar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Cria uma triagem simples por perguntas, sem configuração técnica',handler:async ctx=>{await beginTriageBuilder(ctx.from,ctx.sender,[ctx.senderOriginal,ctx.senderAlternate]);return ctx.reply(tag('Deseja criar uma triagem?\n\n1️⃣ Sim\n2️⃣ Cancelar triagem\n\nResponda somente com o número.'))}});
  registerCommand({name:'triagemexcluir',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await deleteTriageConfiguration(ctx.from);return ctx.reply(tag('🗑️ *TRIAGEM EXCLUÍDA*\n\nAs perguntas e a configuração desta triagem foram removidas. O grupo ficou desativado.\n\nPara criar outra: *'+config.prefix+'triagemcriar*'));}});
  registerCommand({name:'setpergunta',aliases:['editarpergunta','editpergunta'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada. Use ×triagemcriar primeiro.');const n=Number(ctx.args?.[0]);if(!Number.isInteger(n)||n<1||n>s.questions.length){return ctx.reply(tag('📝 *PERGUNTAS CONFIGURADAS*\n\n'+s.questions.map((q,i)=>`${i+1}. [${q.type}] ${q.question}`).join('\n')+'\n\nEnvie: *'+config.prefix+'setpergunta número*\nExemplo: *'+config.prefix+'setpergunta 2*'));}const r=await beginTriageEdit(ctx.from,ctx.sender,n,[ctx.senderOriginal,ctx.senderAlternate]);return ctx.reply(tag(`✏️ *EDITANDO PERGUNTA ${n}*\n\nAtual: *${r.question.question}*\nCategoria atual: *${r.question.type}*\n\nEscreva a nova pergunta.`));}});
  registerCommand({name:'triagemativar',aliases:['triagemon'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada. Use ×triagemcriar primeiro.');await saveSettings(ctx.from,{enabled:true});return ctx.reply(tag(`🟢 *TRIAGEM ATIVADA*\n\nNovos membros serão cobrados automaticamente.\nPerguntas: *${s.questions.length}/20*`));}});
  registerCommand({name:'triagemdesativar',aliases:['triagemoff'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{enabled:false});return ctx.reply(tag('🔴 *TRIAGEM DESATIVADA*\n\nA entrada de novos membros será ignorada pela triagem. Sessões existentes continuam preservadas.'));}});
  registerCommand({name:'triagemcobrar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:4,timeoutMs:300000,description:'Gera uma triagem exclusiva para cada membro do grupo',handler:async ctx=>{
  const s=await getSettings(ctx.from);
  if(!s.questions.length)throw new ValidationError('Nenhuma pergunta configurada.');
  const bot=ctx.botJid||'';
  const members=[...new Set((ctx.groupParticipants||[]).filter(u=>u&&!isBot(u,bot)))];
  if(!members.length)throw new ValidationError('Não consegui obter os membros deste grupo.');
  let created=0,existing=0,listed=0,skipped=0,failed=0;
  const rows=[];
  for(const u of members){
    const c=await createTriage(ctx.from,u,{botJid:bot,force:true});
    if(!c.ok){if(c.reason==='blacklisted')skipped++;continue;}
    if(c.created)created++;else existing++;
    rows.push({user:u,code:c.code,link:c.link}); listed++;
  }
  // Nunca envia cobrança individual no PV. A cobrança é um aviso informal no grupo,
  // com cada @usuário, código e link da própria ficha.
  const chunks=[];
  for(let i=0;i<rows.length;i+=12) chunks.push(rows.slice(i,i+12));
  for(const chunk of chunks){
    const text=tag(`📨 *COBRANÇA DE TRIAGEM*\n\nGente, a triagem está liberada! 😄\nCada pessoa abaixo tem seu próprio acesso:\n\n${chunk.map((r,i)=>`${i+1}️⃣ @${String(r.user).split('@')[0]}\n🔐 ${r.code}\n👉 ${r.link}`).join('\n\n')}\n\nSó abrir o link/código do seu nome e responder no privado do Fantasminha. 👻`);
    try{ await ctx.reply(text,{mentions:chunk.map(r=>r.user)}); }catch{ failed+=chunk.length; }
  }
  return ctx.reply(tag(`📨 *COBRANÇA CONCLUÍDA*\n\n👥 Membros analisados: *${members.length}*\n🆕 Novas triagens: *${created}*\n♻️ Já existentes: *${existing}*\n📋 Fichas listadas no grupo: *${listed}*\n🚫 Ignorados por blacklist: *${skipped}*\n⚠️ Falhas de publicação: *${failed}*`));
}});
  registerCommand({name:'triagemficha',aliases:['fichatriagem','ficha'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Monta a ficha completa de uma triagem',handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!id||!t||t.groupId!==ctx.from)throw new ValidationError('ID de triagem não encontrado neste grupo.');return ctx.reply(triageFullText(t,(await rejectionHistory(t.userId)).length),{mentions:[t.userId]});}});
  registerCommand({name:'triagemconectar',aliases:['triagemconect'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,description:'Conecta a triagem atual a um grupo de arquivo de fichas',handler:async ctx=>{
  const gid=String(ctx.args?.[0]||'').trim();
  if(!gid.endsWith('@g.us'))throw new ValidationError('Informe o ID do grupo destino, terminando em @g.us.');
  if(gid===ctx.from)throw new ValidationError('O grupo de origem já é o destino padrão. Use outro grupo de arquivo.');
  if(ctx.getGroupMetadata){
    const meta=await ctx.getGroupMetadata(gid).catch(()=>null);
    if(!meta)throw new ValidationError('Não consegui acessar o grupo destino. Confira o ID e se o bot está no grupo.');
    const bot=ctx.botJid||'';
    const me=(meta.participants||[]).find(p=>p?.id===bot||p?.jid===bot||p?.participant===bot);
    if(!me||!me.admin)throw new ValidationError('O Fantasminha precisa estar no grupo de arquivo e ser administrador.');
  }
  await saveSettings(ctx.from,{archiveGroupId:gid});
  return ctx.reply(tag(`🔗 *GRUPO DE FICHAS CONECTADO*\n\nOrigem: *${ctx.from}*\nDestino: *${gid}*\n\nTodas as próximas fichas concluídas desta triagem serão enviadas para esse grupo.\nOs administradores do grupo de origem continuam recebendo a ficha no privado.`));
}});
  registerCommand({name:'triagemdesconectar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{archiveGroupId:null});return ctx.reply(tag('🔌 Grupo de arquivo desconectado.'));}});
  registerCommand({name:'setperguntas',aliases:['triagemperguntas'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const raw=String(ctx.q||'').trim();if(!raw)throw new ValidationError('Informe as perguntas separadas por |.');const questions=raw.split('|').map(x=>x.trim()).filter(Boolean).slice(0,20).map((q,i)=>({id:'q_'+(i+1),type:'text',required:true,question:q,order:i+1}));await saveSettings(ctx.from,{questions,maxQuestions:20,enabled:false});return ctx.reply(tag(`✅ ${questions.length} perguntas salvas. Use ${config.prefix}triagemativar para ativar.`));}});
  registerCommand({name:'triagempergunta',aliases:['addpergunta'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(tag('Use ×triagemcriar para montar a triagem de forma simples.'))});
  registerCommand({name:'verperguntas',aliases:['listarperguntas'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);return ctx.reply(tag(s.questions.length?s.questions.map((q,i)=>`${i+1}. [${q.type}] ${q.question}`).join('\n'):'Nenhuma pergunta configurada.'));}});
  registerCommand({name:'triagemstatus',aliases:['triagem'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);return ctx.reply(tag(`Status: *${s.enabled?'ATIVA':'DESATIVADA'}*\nPerguntas: *${s.questions.length}/20*\nArquivo: *${s.archiveGroupId||'não conectado'}*`));}});
  registerCommand({name:'filatriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const d=readCollection('triage',{byId:{}});const a=Object.values(d.byId||{}).filter(t=>t.groupId===ctx.from&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(t.state)).sort((x,y)=>x.createdAt-y.createdAt);return ctx.reply(tag(a.length?a.map((t,i)=>`${i+1}. *${t.id}* — @${idOf(t.userId)} — ${t.state}`).join('\n'):'Fila vazia.'),{mentions:a.map(t=>t.userId)});}});
  registerCommand({name:'triagemstats',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,hidden:true,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await triageStats(ctx.from);return ctx.reply(tag(`📊 Total: ${s.total}\n🟡 Pendentes: ${s.pending}\n🔵 Em andamento: ${s.running}\n⚖️ Julgamento: ${s.judging}\n🟢 Aprovadas: ${s.approved}\n🔴 Reprovadas: ${s.rejected}\n⚫ Expiradas: ${s.expired}`));}});
  registerCommand({name:'conselho',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');return ctx.reply(tag(`${triageSummaryText(t,(await rejectionHistory(t.userId)).length)}\n\n${config.prefix}aprovar ${id}\n${config.prefix}reprovar ${id} motivo`),{mentions:[t.userId]});}});
  registerCommand({name:'aprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'approve');if(!r.ok)throw new ValidationError(r.reason);return ctx.reply(tag(`✅ Triagem *${id}* aprovada.`),{mentions:[t.userId]});}});
  registerCommand({name:'reprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),reason=String(ctx.q).slice(id.length).trim(),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'reject',reason);if(!r.ok)throw new ValidationError(r.reason==='reason-required'?'Informe o motivo.':r.reason);return ctx.reply(tag(`❌ Triagem *${id}* reprovada.\nMotivo: ${reason}`),{mentions:[t.userId]});}});
  registerCommand({name:'cancelatriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const u=target(ctx);if(!u)throw new ValidationError('Mencione o usuário.');const t=await cancelActiveTriage(ctx.from,u,'cancelada pelo administrador');return ctx.reply(tag(t?'Triagem cancelada.':'Nenhuma triagem ativa.'));}});
  registerCommand({name:'bl',aliases:['blacklist'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,cooldown:2,handler:async ctx=>{const sub=String(ctx.args?.[0]||'check').toLowerCase();const u=target(ctx)||ctx.args?.[1]||ctx.sender;if(['list','stats'].includes(sub)){if(!ctx.isOwner)throw new ValidationError('Apenas o dono.');const r=sub==='list'?await blacklistList():await blacklistStats();return ctx.reply(tag(JSON.stringify(r,null,2)));}if(['check','info'].includes(sub)){const e=await blacklistInfo(u);return ctx.reply(tag(e?`🚫 Bloqueado\n@${idOf(u)}\nMotivo: ${e.reason}`:`🟢 @${idOf(u)} sem blacklist.`),{mentions:[u]});}if(!ctx.isOwner&&!ctx.isGroupAdmin)throw new ValidationError('Sem permissão.');if(['remove','del'].includes(sub)){return ctx.reply(tag(await removeBlacklist(u,ctx.sender)?'Blacklist removida.':'Nenhuma blacklist ativa.'));}if(['add','perm','temp'].includes(sub)){const days=sub==='temp'?Number(ctx.args?.[2]):0;const start=sub==='temp'?3:1;const reason=String(ctx.args?.slice(start).join(' ')||'').trim();if(reason.length<3)throw new ValidationError('Informe o motivo.');await setBlacklist(u,ctx.sender,reason,days*86400000,{source:'manual',level:'blacklist'});return ctx.reply(tag('🚫 Blacklist registrada.'));}throw new ValidationError('Use bl check/add/temp/remove/list/stats.');}});
  registerCommand({name:'triagemmenu',aliases:['triagemhelp'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(tag(`🧭 *TRIAGEM — COMANDOS PRINCIPAIS*\n\n⚙️ ${config.prefix}triagemcriar — criar perguntas\n🟢 ${config.prefix}triagemativar — cobrar novos membros\n📨 ${config.prefix}triagemcobrar — cobrar todos agora\n📋 ${config.prefix}filatriagem — ver pendentes\n📄 ${config.prefix}triagemficha ID — abrir ficha\n⚖️ ${config.prefix}aprovar ID — aprovar\n❌ ${config.prefix}reprovar ID motivo — reprovar\n🔗 ${config.prefix}triagemconectar ID_GRUPO — enviar fichas ao arquivo\n📊 ${config.prefix}triagemstatus — ver status\n\n🔧 Avançados continuam disponíveis, mas não ficam no menu principal.`))});
}
export { handleTriageBuilderMessage, memberJoined, triageLink };
export default { register };
