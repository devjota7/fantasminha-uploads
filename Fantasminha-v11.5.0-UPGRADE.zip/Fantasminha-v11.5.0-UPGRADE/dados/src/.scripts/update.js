#!/usr/bin/env node

/**
 * 👻 Fantasminha — Atualizador oficial por release GitHub
 *
 * Segurança/robustez:
 * - consulta latest.json no repositório configurado
 * - aceita download_url OU zip (deriva URL raw do GitHub)
 * - valida versão, ZIP, caminhos e package.json
 * - valida SHA-256 quando informado
 * - preserva .env, sessão WhatsApp, banco e logs
 * - NÃO congela config.json: ela pode evoluir com a nova versão
 * - NÃO cria backups do código/dados durante a atualização
 * - instala dependências somente quando necessário
 * - valida a instalação antes de concluir
 * - registra .last-update.json
 */

import fs from 'fs/promises';
import fsSync from 'fs';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import { fileURLToPath } from 'url';

const execFileAsync = promisify(execFile);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = process.cwd();

const CONFIG_FILE = path.join(ROOT, 'dados', 'src', 'config.json');
const ENV_FILE = path.join(ROOT, '.env');
const TEMP_ROOT = path.join(ROOT, '.update-tmp');

const DEFAULT_OWNER = 'devjota7';
const DEFAULT_REPO = 'fantasminha-uploads';
const DEFAULT_BRANCH = 'main';

// Dados locais que NUNCA devem ser substituídos por uma release.
const protectedRelative = [
  '.env',
  'data/auth',
  'data/db',
  'data/backups',
  'auth',
  'session',
  'sessions',
  'dados/database',
  'dados/midias',
  'logs'
];

function log(message) { console.log(`[FANTASMINHA UPDATE] ${message}`); }
function fail(message) { console.error(`[FANTASMINHA UPDATE] ❌ ${message}`); }

function normalize(p) {
  return p.split(path.sep).join('/').replace(/^\.\//, '');
}

function isProtected(rel) {
  const n = normalize(rel);
  return protectedRelative.some(item => n === item || n.startsWith(`${item}/`));
}

function safeResolve(rel) {
  const target = path.resolve(ROOT, rel);
  const root = path.resolve(ROOT) + path.sep;
  if (target !== path.resolve(ROOT) && !target.startsWith(root)) {
    throw new Error(`Caminho inseguro: ${rel}`);
  }
  return target;
}

function envValue(name) {
  try {
    if (!fsSync.existsSync(ENV_FILE)) return '';
    const text = fsSync.readFileSync(ENV_FILE, 'utf8');
    const line = text.split(/\r?\n/).find(l => l.trim().startsWith(`${name}=`));
    return line ? line.slice(line.indexOf('=') + 1).trim().replace(/^['"]|['"]$/g, '') : '';
  } catch {
    return '';
  }
}

async function readLocalConfig() {
  try {
    return JSON.parse(await fs.readFile(CONFIG_FILE, 'utf8'));
  } catch {
    return {};
  }
}

function githubInfo(config) {
  let owner = envValue('GITHUB_OWNER') || config.githubOwner || config.autor || DEFAULT_OWNER;
  let repo = envValue('GITHUB_REPO') || config.githubRepo || config.repositorio || DEFAULT_REPO;
  const branch = envValue('GITHUB_BRANCH') || DEFAULT_BRANCH;

  // github_ofc é a fonte mais direta quando não há override no .env/config.
  if (!envValue('GITHUB_OWNER') && !envValue('GITHUB_REPO') && config.github_ofc) {
    const m = String(config.github_ofc).match(/^https?:\/\/github\.com\/([^/]+)\/([^/#?]+)/i);
    if (m) {
      owner = m[1];
      repo = m[2].replace(/\.git$/i, '');
    }
  }

  const base = `https://raw.githubusercontent.com/${owner}/${repo}/${branch}`;
  return { owner, repo, branch, base, manifestUrl: `${base}/latest.json` };
}

function headers() {
  return {
    Accept: 'application/json'
  };
}

async function fetchJson(url) {
  const response = await fetch(url, { headers: headers(), redirect: 'follow' });
  if (!response.ok) throw new Error(`HTTP ${response.status} ao acessar ${url}`);
  return response.json();
}

function releaseDownloadUrl(manifest, github) {
  if (manifest.download_url) return String(manifest.download_url);
  if (manifest.zip) {
    const zip = path.posix.basename(String(manifest.zip));
    if (!/^Fantasminha-v[\w.-]+\.zip$/i.test(zip)) {
      throw new Error('Nome do ZIP inválido no latest.json.');
    }
    return `${github.base}/${encodeURIComponent(zip)}`;
  }
  throw new Error('latest.json precisa informar download_url ou zip.');
}

function assertReleaseUrl(url, github) {
  let parsed;
  try { parsed = new URL(url); } catch { throw new Error('download_url inválido.'); }
  const expected = new URL(github.base + '/');
  const isGithubRaw = parsed.hostname === expected.hostname && parsed.pathname.startsWith(expected.pathname);
  const isGithubRelease = parsed.hostname === 'github.com' && parsed.pathname.startsWith(`/${github.owner}/${github.repo}/`);
  if (!isGithubRaw && !isGithubRelease) {
    throw new Error('download_url precisa apontar para o GitHub configurado.');
  }
}

function compareVersions(a, b) {
  const pa = String(a).replace(/^v/i, '').split('.').map(x => Number.parseInt(x, 10) || 0);
  const pb = String(b).replace(/^v/i, '').split('.').map(x => Number.parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) {
    if ((pa[i] || 0) > (pb[i] || 0)) return 1;
    if ((pa[i] || 0) < (pb[i] || 0)) return -1;
  }
  return 0;
}

async function download(url, destination) {
  assertReleaseUrl(url, await readLocalConfig().then(c => githubInfo(c)));
  const response = await fetch(url, { headers: headers(), redirect: 'follow' });
  if (!response.ok) throw new Error(`HTTP ${response.status} ao baixar ZIP`);
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length < 100) throw new Error('Download do ZIP parece vazio ou inválido');
  await fs.writeFile(destination, buffer);
  return buffer.length;
}

async function sha256(file) {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash('sha256');
    const stream = fsSync.createReadStream(file);
    stream.on('data', chunk => hash.update(chunk));
    stream.on('error', reject);
    stream.on('end', () => resolve(hash.digest('hex')));
  });
}

async function zipList(zipFile) {
  const { stdout } = await execFileAsync('unzip', ['-Z1', zipFile], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
  return stdout.split(/\r?\n/).map(x => x.trim()).filter(Boolean);
}

async function extract(zipFile, destination) {
  await fs.mkdir(destination, { recursive: true });
  await execFileAsync('unzip', ['-q', zipFile, '-d', destination], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
}

async function detectPayloadDir(extracted) {
  const entries = await fs.readdir(extracted, { withFileTypes: true });
  const dirs = entries.filter(e => e.isDirectory() && e.name !== '__MACOSX');
  const files = entries.filter(e => e.isFile());
  if (files.length || dirs.length !== 1) return extracted;
  const candidate = path.join(extracted, dirs[0].name);
  const nestedEntries = await fs.readdir(candidate);
  if (nestedEntries.some(n => n === 'package.json' || n === 'dados' || n === 'src')) return candidate;
  return extracted;
}

async function currentVersion() {
  try {
    const pkg = JSON.parse(await fs.readFile(path.join(ROOT, 'package.json'), 'utf8'));
    return pkg.version || envValue('BOT_VERSION') || 'desconhecida';
  } catch {
    return envValue('BOT_VERSION') || 'desconhecida';
  }
}

async function copyTreeFiltered(source, destination, filterProtected = true) {
  await fs.mkdir(destination, { recursive: true });
  const entries = await fs.readdir(source, { withFileTypes: true });
  for (const entry of entries) {
    const rel = entry.name;
    if (rel === '__MACOSX') continue;
    if (filterProtected && isProtected(rel)) continue;
    if (rel === 'node_modules' || rel === '.update-tmp') continue;
    const src = path.join(source, rel);
    const dst = path.join(destination, rel);
    await fs.mkdir(path.dirname(dst), { recursive: true });
    await fs.cp(src, dst, { recursive: true, force: true });
  }
}

async function clearNonProtected() {
  log('🧹 Removendo código antigo sem tocar nos dados protegidos...');
  const entries = await fs.readdir(ROOT, { withFileTypes: true });
  for (const entry of entries) {
    const rel = entry.name;
    if (rel === '.update-tmp' || isProtected(rel) || rel === 'node_modules') continue;
    await fs.rm(path.join(ROOT, rel), { recursive: true, force: true });
  }
}

async function copyPayload(payload) {
  log('🚀 Aplicando a nova versão...');
  await copyTreeFiltered(payload, ROOT, true);
}

function packageDependenciesChanged(oldPackage, newPackage) {
  if (!oldPackage || !newPackage) return true;
  const keys = ['dependencies', 'devDependencies', 'optionalDependencies', 'peerDependencies', 'packageManager'];
  return keys.some(k => JSON.stringify(oldPackage[k] || {}) !== JSON.stringify(newPackage[k] || {}));
}

async function installDependencies() {
  log('📦 Instalando/verificando dependências...');
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  await execFileAsync(npm, ['install', '--no-audit', '--no-fund'], {
    cwd: ROOT,
    maxBuffer: 30 * 1024 * 1024
  });
}

async function validateInstall(expectedVersion) {
  log('🧪 Validando a instalação...');
  const pkgPath = path.join(ROOT, 'package.json');
  if (!fsSync.existsSync(pkgPath)) throw new Error('package.json não existe após a atualização');
  const pkg = JSON.parse(await fs.readFile(pkgPath, 'utf8'));
  if (expectedVersion && String(pkg.version) !== String(expectedVersion)) {
    throw new Error(`package.json ficou na versão ${pkg.version}, mas a release declara ${expectedVersion}`);
  }
  const syntaxScript = path.join(ROOT, 'scripts', 'syntax-check.mjs');
  if (fsSync.existsSync(syntaxScript)) {
    await execFileAsync(process.execPath, [syntaxScript], { cwd: ROOT, maxBuffer: 20 * 1024 * 1024 });
  } else {
    const indexPath = path.join(ROOT, 'dados', 'src', 'index.js');
    if (fsSync.existsSync(indexPath)) await execFileAsync(process.execPath, ['--check', indexPath], { cwd: ROOT });
  }
}


const UPDATE_BACKUP_ROOT = path.join(ROOT, 'data', 'backups');
const MAX_UPDATE_BACKUPS = 2;

async function snapshotForRollback(version) {
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const dir = path.join(UPDATE_BACKUP_ROOT, `update-${String(version).replace(/[^\w.-]/g, '_')}-${stamp}`);
  await fs.mkdir(dir, { recursive: true });
  const entries = await fs.readdir(ROOT, { withFileTypes: true });
  for (const entry of entries) {
    const rel = entry.name;
    if (isProtected(rel) || rel === 'node_modules' || rel === '.update-tmp') continue;
    await fs.cp(path.join(ROOT, rel), path.join(dir, rel), { recursive: true, force: true });
  }
  await fs.writeFile(path.join(dir, '.rollback-meta.json'), JSON.stringify({ version, createdAt: new Date().toISOString() }, null, 2));
  await pruneUpdateBackups();
  return dir;
}

async function pruneUpdateBackups() {
  await fs.mkdir(UPDATE_BACKUP_ROOT, { recursive: true });
  const entries = (await fs.readdir(UPDATE_BACKUP_ROOT, { withFileTypes: true }))
    .filter(e => e.isDirectory() && e.name.startsWith('update-'));
  entries.sort((a, b) => b.name.localeCompare(a.name));
  for (const old of entries.slice(MAX_UPDATE_BACKUPS)) {
    await fs.rm(path.join(UPDATE_BACKUP_ROOT, old.name), { recursive: true, force: true });
  }
}

async function rollbackFromSnapshot(snapshotDir) {
  if (!snapshotDir || !fsSync.existsSync(snapshotDir)) throw new Error('Snapshot de rollback não encontrado.');
  log('↩️ Falha detectada. Restaurando versão anterior...');
  await clearNonProtected();
  await copyTreeFiltered(snapshotDir, ROOT, false);
  log('↩️ Rollback do código concluído. Dados protegidos permaneceram intactos.');
}

async function main() {
  const config = await readLocalConfig();
  const github = githubInfo(config);
  const temp = path.join(TEMP_ROOT, `run-${Date.now()}`);
  const zipFile = path.join(temp, 'release.zip');
  const extracted = path.join(temp, 'extracted');
  let applied = false;
  let rollbackSnapshot = null;
  let oldPackageSnapshot = null;

  try {
    log(`🔎 Consultando ${github.owner}/${github.repo}...`);
    const manifest = await fetchJson(github.manifestUrl);
    if (!manifest || !manifest.version) throw new Error('latest.json inválido: versão ausente');
    if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(String(manifest.version))) {
      throw new Error(`Versão inválida no latest.json: ${manifest.version}`);
    }

    const oldVersion = await currentVersion();
    const cmp = compareVersions(manifest.version, oldVersion);
    log(`📌 Versão instalada: ${oldVersion}`);
    log(`🚀 Release encontrada: ${manifest.version}`);

    if (cmp === 0 && manifest.force !== true) {
      log('✅ O bot já está na versão mais recente.');
      return;
    }
    if (cmp < 0 && manifest.allow_downgrade !== true && manifest.force !== true) {
      throw new Error(`A release ${manifest.version} é anterior à instalada ${oldVersion}. Downgrade bloqueado.`);
    }

    const downloadUrl = releaseDownloadUrl(manifest, github);
    assertReleaseUrl(downloadUrl, github);

    await fs.mkdir(temp, { recursive: true });
    log('📥 Baixando a versão do GitHub...');
    const size = await download(downloadUrl, zipFile);
    log(`📥 Download concluído (${Math.round(size / 1024)} KB).`);

    if (manifest.sha256) {
      if (!/^[0-9a-f]{64}$/i.test(String(manifest.sha256))) throw new Error('SHA-256 inválido no latest.json');
      const actualHash = await sha256(zipFile);
      if (actualHash.toLowerCase() !== String(manifest.sha256).toLowerCase()) {
        throw new Error(`SHA-256 não confere!\nEsperado: ${manifest.sha256}\nObtido:   ${actualHash}`);
      }
      log('🔐 SHA-256 verificado com sucesso.');
    } else {
      log('⚠️ Release sem SHA-256; seguindo por compatibilidade.');
    }

    const names = await zipList(zipFile);
    if (!names.some(n => /(^|\/)package\.json$/.test(n))) throw new Error('ZIP não contém package.json');
    if (names.some(n => n.includes('..') || path.isAbsolute(n) || /^[A-Za-z]:[\\/]/.test(n))) {
      throw new Error('ZIP contém caminho inseguro');
    }

    await extract(zipFile, extracted);
    const payload = await detectPayloadDir(extracted);
    const packagePath = path.join(payload, 'package.json');
    const newPkg = JSON.parse(await fs.readFile(packagePath, 'utf8'));
    const oldPackagePath = path.join(ROOT, 'package.json');
    const oldPkg = fsSync.existsSync(oldPackagePath) ? JSON.parse(await fs.readFile(oldPackagePath, 'utf8')) : null;
    oldPackageSnapshot = oldPkg;

    if (String(newPkg.version) !== String(manifest.version)) {
      throw new Error(`package.json da release é ${newPkg.version}, mas latest.json declara ${manifest.version}`);
    }

    rollbackSnapshot = await snapshotForRollback(oldVersion);
    log(`📦 Backup de rollback criado: ${path.basename(rollbackSnapshot)}`);
    await clearNonProtected();
    await copyPayload(payload);
    applied = true;

    if (packageDependenciesChanged(oldPkg, newPkg) || !fsSync.existsSync(path.join(ROOT, 'node_modules'))) {
      await installDependencies();
    }

    await validateInstall(manifest.version);

    await fs.writeFile(
      path.join(ROOT, '.last-update.json'),
      JSON.stringify({
        from: oldVersion,
        version: manifest.version,
        updatedAt: new Date().toISOString(),
        source: downloadUrl,
        sha256: manifest.sha256 || null
      }, null, 2)
    );

    log(`🎉 Atualização ${oldVersion} → ${manifest.version} concluída.`);
    log('🔐 .env, sessão WhatsApp e banco foram preservados sem criar backup extra.');
    log('🔄 Encerrando com código 0 para o supervisor reiniciar o bot.');
  } catch (error) {
    fail(error?.stack || error?.message || String(error));
    if (applied && rollbackSnapshot) {
      try {
        await rollbackFromSnapshot(rollbackSnapshot);
        if (oldPackageSnapshot) {
          await fs.writeFile(path.join(ROOT, 'package.json'), JSON.stringify(oldPackageSnapshot, null, 2) + '\n');
        }
        if (fsSync.existsSync(path.join(ROOT, 'package.json'))) {
          try { await installDependencies(); } catch (depErr) { fail(`Dependências do rollback não puderam ser verificadas: ${depErr.message}`); }
        }
        await fs.writeFile(path.join(ROOT, '.last-update.json'), JSON.stringify({ status:'rollback', failedAt:new Date().toISOString(), restoredFrom:rollbackSnapshot, error:String(error?.message || error) }, null, 2));
      } catch (rollbackError) {
        fail(`ROLLBACK FALHOU: ${rollbackError?.stack || rollbackError?.message || rollbackError}`);
      }
    }
    process.exitCode = 1;
  } finally {
    try { await fs.rm(temp, { recursive: true, force: true }); } catch {}
  }
}

main();
