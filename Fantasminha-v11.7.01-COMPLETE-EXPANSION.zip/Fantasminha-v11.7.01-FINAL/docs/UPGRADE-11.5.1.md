# Fantasminha 11.5.1 — Correção do atualizador

## Triagem
- Corrigida a continuação do construtor sem prefixo quando a identidade do administrador alterna entre LID e PN.
- `1` agora avança diretamente para o cadastro da primeira pergunta.
- `cancelar` funciona em qualquer etapa do construtor.
- Construtor simplificado: pergunta → tipo → próxima pergunta → concluir.
- Perguntas do tipo escolha agora exigem e salvam opções reais.
- Validação de número passou a respeitar mínimo/máximo.
- Respostas opcionais vazias deixaram de ser rejeitadas incorretamente.
- Tempo de julgamento passou a respeitar a configuração do grupo.
- Blacklist é verificada antes de criar novas triagens.
- `triagemcobrar` agora envia a cobrança individual no privado de cada membro, incluindo administradores, sem expor links no grupo.
- `triagemcobrar` preserva triagens ativas e informa novas/existentes/falhas/blacklist.
- `triagemconectar ID_GRUPO` valida acesso ao grupo destino quando possível.
- Quando há grupo de arquivo conectado, as fichas concluídas passam a ter esse grupo como destino oficial, além dos administradores do grupo de origem no privado.
- Menu de triagem reduzido de 37 para 15 comandos visíveis.
- Ferramentas avançadas permanecem disponíveis, mas ficam ocultas do menu principal.
- Adicionado teste de integração cobrindo LID/PN, cobrança em massa e grupo de arquivo.

## Base geral
- Versão do projeto atualizada para 11.5.0.
- `package-lock.json` sincronizado pelo npm.
- Regras obrigatórias atualizadas para a linha 11.5.0.
- Validação completa executada com sucesso.
- Nenhuma dependência nova foi adicionada.


## Atualizador
- Corrigido `snapshotForRollback()`: a pasta raiz `data` não é copiada para o snapshot localizado em `data/backups`, evitando `ERR_FS_CP_EINVAL` por tentativa de cópia de uma pasta para dentro de si mesma.
- Dados protegidos continuam preservados durante a atualização.
