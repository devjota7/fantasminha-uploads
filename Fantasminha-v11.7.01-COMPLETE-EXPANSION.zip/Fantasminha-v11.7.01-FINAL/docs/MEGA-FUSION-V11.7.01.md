# Fantasminha v11.7.01 — Mega Fusion

## Limites e regras

1. A versão continua `11.7.01`.
2. Nenhuma base externa substitui o núcleo do Fantasminha sem análise de compatibilidade.
3. Comando equivalente existente é reutilizado; quando fizer sentido, nomes alternativos viram aliases.
4. Alias conflitante nunca é forçado.
5. Menus devem usar o Registry e não podem listar comandos inexistentes.
6. Não existem reações automáticas de espera/sucesso/erro. Reação pública é somente `×react`.
7. Animações podem usar edição da própria mensagem, sem reação automática.
8. API keys, tokens e segredos ficam no `.env`.
9. Execução arbitrária e comandos perigosos não são importados das bases externas.
10. Dados persistentes continuam separados por usuário/membership/grupo quando aplicável.
11. Não há backup automático nesta atualização.
12. Prioridade: estabilidade > segurança > organização > compatibilidade > performance > novos recursos.

## Bases consolidadas

- Takeshi: UX, downloads, TTP, menu, padrões de resposta e providers.
- Hiyuki: organização por áreas, administração, mídia, RPG e menus.
- Subaru: separação de comandos/serviços e utilidades.
- Phoenix: organização modular de plugins e utilidades.
- TheMystic: grande catálogo de ideias de ferramentas, jogos, pesquisa, moderação e RPG; somente recursos compatíveis e seguros são aproveitados.
- King-RANUX: referência complementar de organização/configuração.
- Silva: agente IA, intenção local, memória contextual e fallback de providers.
- Fantasminha: Registry, middleware, persistência, identidade, triagem, social, economia, mundo e compatibilidade.

## Novidades desta consolidação

- `src/plugins/megaFusion/` com comandos de utilidade, brincadeiras, informação e compatibilidade.
- `registerAlias()` no Registry para aliases seguros sem duplicar handlers.
- `quotedKey` no contexto V2 para operações sobre mensagens respondidas.
- `×react` manual.
- Animações por edição para comandos recreativos.
- Reações automáticas desativadas globalmente.
- Configurações de UX/IA no `.env.example`.
