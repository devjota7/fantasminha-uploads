FANTASMINHA MEGA ASSISTENTE V2 ULTIMATE
===========================================

Este pacote é uma expansão do Mega Assistente original.

Preserva:
- o arquivo original;
- a separação Assistente != Router/Admin;
- a regra de não inventar execução;
- ativação ON/OFF;
- memória segura;
- contexto;
- proteção contra injection;
- testes e fallbacks.

Adiciona:
- motor de personalidade em camadas;
- Humor Engine;
- Mood Mirror;
- Conversation Threads;
- Memory Health;
- Confidence Aware Answers;
- Callback Engine;
- Silence Intelligence;
- Personality Sliders;
- Tool Gate;
- observabilidade;
- replay;
- chaos testing;
- feature flags;
- contratos;
- schemas;
- matriz de testes;
- integração contratual com RPG/economia/pets/NPCs/família/empresas/clãs/premium/aluguel.

SOBRE AS "50 MILHÕES DE LINHAS"
--------------------------------
A versão anterior continha uma matriz lógica de 50 milhões de IDs geráveis.
Esta V2 adiciona uma SEGUNDA matriz lógica de 50 milhões de unidades,
totalizando 100.000.000 de unidades lógicas quando geradas.

Não é recomendado armazenar 100 milhões de linhas repetitivas dentro do prompt:
isso aumenta o tamanho sem aumentar proporcionalmente a inteligência.
O pacote entrega geradores determinísticos para materializar a matriz quando
realmente necessário.

O que foi ampliado aqui não é "lixo de linhas": são contratos, sistemas,
comportamentos, estados, testes e funcionalidades diferentes.

ORDEM DE IMPLEMENTAÇÃO
----------------------
1. Orchestrator + Context
2. Memory 2.0
3. Personality + Humor
4. Security + Tool Gate
5. Persistence
6. Observability
7. Test Harness
8. Feature flags
9. Integrações por domínio
10. E2E no Termux/WhatsApp real

NOTA:
A especificação não concede permissões administrativas ao assistente.
Qualquer execução deve continuar no sistema autorizado do Fantasminha.

CONTROLE DO MEGA ASSISTENTE V2

O controle explícito por grupo usa:
- ×assistente on — ativa o Mega Assistente V2.
- ×assistente off — desativa o Mega Assistente V2.
- ×assistente status — mostra o estado atual.

Somente administrador do grupo pode alterar o estado. O restante dos comandos e regras do Fantasminha permanece independente e continua funcionando.
