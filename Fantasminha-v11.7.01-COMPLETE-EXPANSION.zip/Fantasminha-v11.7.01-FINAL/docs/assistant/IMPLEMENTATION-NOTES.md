# Integração do Mega Assistente V2

A versão do bot permanece **11.7.0**.

A V2 foi aplicada como camada de runtime sobre o assistente existente:
- prompt mestre em `docs/assistant/MASTER_PROMPT_V2_ULTIMATE.txt`;
- personalidades e regras existentes preservadas;
- guard de entrada, validação de saída, fingerprint e métricas;
- modo PRO continua entregando a execução ao router/permissões reais;
- nenhuma dependência nova foi adicionada.

A V2 não substitui os sistemas do Fantasminha. Comandos, permissões, triagem,
economia, RPG, clãs, premium, aluguel, menus, anti-spam, updater e demais
regras continuam pertencendo à base.

Validação: `npm run test:assistant-v2`, `npm run test:syntax` e `npm test`.

## Camada System Excellence — mesma versão

Implementada sem alterar `package.json`/versão:
- `src/core/systemOrchestrator.js` centraliza snapshot operacional e doctor;
- comandos `×doctor`, `×centralstatus`, `×auditoriav2` e `×featuresv2` adicionados sem colisões com comandos legados;
- auditoria automática para comandos administrativos/owner no registry;
- cargo `MODERATOR` adicionado à hierarquia sem alterar os níveis existentes;
- teste `tests/system-excellence.mjs` e script `npm run test:system`;
- validações de sintaxe, smoke, Assistente V2, segurança e System Excellence aprovadas;
- suíte `npm run validate:extreme` aprovada.

A versão oficial continua **11.7.0**.
