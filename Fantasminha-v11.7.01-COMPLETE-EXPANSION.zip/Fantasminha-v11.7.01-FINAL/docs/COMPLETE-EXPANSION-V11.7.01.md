# Fantasminha 11.7.01 — Complete Expansion

Esta atualização executa a especificação de expansão fornecida no prompt master de 50 mil linhas como contrato de implementação. O objetivo é transformar os módulos de jogos, brincadeiras, pets, ranking, conquistas, temporadas, torneios e estatísticas em recursos persistentes e integrados, preservando o núcleo existente.

## Motores

- `Game Engine`: partidas, IDs, estados, participantes, turnos, timeout, desistência, histórico, persistência e isolamento por grupo.
- `Stats Engine`: partidas, vitórias, derrotas, empates, XP, pontuação, streak e métricas por jogo/grupo.
- `Ranking Engine`: classificação por desempenho e grupo.
- `Achievement Engine`: primeira partida, primeira vitória, volume, streak, pontuação e catálogo expansível.
- `Pet Engine`: adoção, atributos, ações, evolução, histórico e duelos recreativos.
- `Season Engine`: temporada atual e arquivamento.
- `Tournament Engine`: criação, entrada, início, chave, resultados e avanço de rodada.
- `Interaction Engine`: sorteios, dados, moeda, escolhas, compatibilidade recreativa e perguntas seguras.

## Jogos

Incluídos ou expandidos: jogo da velha, pedra/papel/tesoura, forca, anagrama, enigmas, desafios matemáticos, quiz/trivia, memória, campo minado e Quem Sou Eu.

Os estados críticos são persistidos para sobreviver ao restart. Operações são validadas e associadas ao `groupId`.

## Aliases

Aliases apontam para comandos canônicos. Não há implementação duplicada para cada nome alternativo. Conflitos existentes não são sobrescritos.

## Animação e UX

A política continua sendo: nenhuma reação automática. Quando a infraestrutura permitir, animações usam edição da mensagem. O comando `×react` continua sendo a forma explícita de reação.

## Segurança

Não foram importados comandos NSFW/adultos ou recursos perigosos das bases de referência. Brincadeiras sociais foram mantidas em formato seguro e não invasivo.

## Compatibilidade

A versão permanece `11.7.01`. O Registry continua sendo a fonte de verdade e o menu deve ser derivado dos comandos reais.
