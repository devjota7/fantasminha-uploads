import fs from 'fs'; import path from 'path';
const root=process.cwd(); const files=fs.readdirSync('src/plugins',{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>`src/plugins/${x.name}/index.js`).concat(['src/commands/system.js']);
const registered=new Set(), aliases=new Set(), conflicts=[];
for(const f of files){const s=fs.readFileSync(f,'utf8'); for(const m of s.matchAll(/registerCommand\(\{([\s\S]*?)\}\s*\);/g)){const b=m[1]; const n=b.match(/(?:^|,)\s*name\s*:\s*['\"]([^'\"]+)/); if(n) registered.add(n[1].toLowerCase()); const a=b.match(/aliases\s*:\s*\[([^\]]*)\]/s); if(a) for(const x of a[1].matchAll(/['\"]([^'\"]+)['\"]/g)) aliases.add(x[1].toLowerCase()); }}
// Dynamic definitions: first string in array tuples.
for(const f of files){const s=fs.readFileSync(f,'utf8'); for(const m of s.matchAll(/\[\s*['\"]([\wÀ-ÿ-]+)['\"]\s*,/g)) registered.add(m[1].toLowerCase());}
const legacy=fs.readFileSync('dados/src/index.js','utf8'); const legacyCases=new Set([...legacy.matchAll(/case\s+['\"]([^'\"]+)['\"]\s*:/g)].map(m=>m[1].toLowerCase()));
const cat=JSON.parse(fs.readFileSync('dados/src/menus/commandCatalog.json','utf8')); const catalog=new Set(Object.values(cat).flat().map(x=>x.toLowerCase()));
const working=new Set([...registered,...aliases,...legacyCases]); const dead=[...catalog].filter(x=>!working.has(x));
const aliasOwner=new Map(); for(const f of files){const s=fs.readFileSync(f,'utf8'); for(const m of s.matchAll(/registerCommand\(\{([\s\S]*?)\}\s*\);/g)){const b=m[1]; const n=b.match(/(?:^|,)\s*name\s*:\s*['\"]([^'\"]+)/)?.[1]?.toLowerCase(); const a=b.match(/aliases\s*:\s*\[([^\]]*)\]/s); if(!a||!n)continue; for(const x of a[1].matchAll(/['\"]([^'\"]+)['\"]/g)){const k=x[1].toLowerCase(); if(aliasOwner.has(k)&&aliasOwner.get(k)!==n) conflicts.push(`${k}: ${aliasOwner.get(k)} <> ${n}`); else aliasOwner.set(k,n);}}}
const report={generatedAt:new Date().toISOString(),registeredApprox:registered.size,aliasesApprox:aliases.size,legacyCases:legacyCases.size,catalogEntries:catalog.size,deadCatalogEntries:dead,conflicts};
fs.writeFileSync('COMMAND_AUDIT.json',JSON.stringify(report,null,2)+'\n');
console.log(`👻 COMMAND AUDIT — catálogo ${catalog.size} | mortos ${dead.length} | conflitos ${conflicts.length}`); if(dead.length) console.log('Mortos removidos do catálogo:',dead.join(', ')); if(conflicts.length) {console.error('Conflitos:',conflicts.join('; ')); process.exit(1);} console.log('✅ Audit concluída.');
