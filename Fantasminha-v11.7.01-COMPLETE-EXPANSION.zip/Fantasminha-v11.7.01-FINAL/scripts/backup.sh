#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
STAMP=$(date +%Y%m%d_%H%M%S)
DEST="data/backups/full_$STAMP"
mkdir -p "$DEST"
cp -r dados/src/config.json "$DEST/" 2>/dev/null || true
cp -r data/json "$DEST/" 2>/dev/null || true
cp -r data/auth "$DEST/auth" 2>/dev/null || true
echo "Backup: $DEST"
