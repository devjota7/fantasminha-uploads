#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
pkill -f "dados/src/.scripts/start.js" 2>/dev/null || true
sleep 1
exec bash scripts/start.sh
