import fs from 'fs';
import { execFileSync } from 'child_process';
import path from 'path';
const root = process.cwd();
const fail = []; const warn = [];
const pkg = JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const major = Number(process.versions.node.split('.')[0]);
if (major < 20) fail.push(`Node.js ${process.versions.node} detectado; mínimo 20.`);
if (!fs.existsSync('.env')) { if (fs.existsSync('.env.example')) warn.push('Arquivo .env ausente; será criado pelo instalador a partir de .env.example.'); else fail.push('Arquivo .env ausente e .env.example também não existe.'); }
let env = '';
if (fs.existsSync('.env')) env = fs.readFileSync('.env','utf8');
const get = k => env.split(/\r?\n/).find(l => l.trim().startsWith(k+'='))?.split('=').slice(1).join('=').trim() || process.env[k] || '';
if (!get('OWNER_NUMBER')) warn.push('OWNER_NUMBER não configurado; pairing code e permissões de dono dependerão de OWNER_IDS/OWNER_LID ou configuração posterior.');
if (!get('ALLOWED_GROUP_IDS')) warn.push('ALLOWED_GROUP_IDS vazio: o bot aceitará grupos além do grupo de teste.');
if (get('ALLOW_OWNER_SHELL') === 'true' || get('ALLOW_OWNER_EVAL') === 'true') fail.push('Execução de shell/eval do owner está habilitada; desative antes do lançamento.');
try { execFileSync('ffmpeg',['-version'],{stdio:'ignore'}); } catch { warn.push('FFmpeg não encontrado: comandos de mídia que dependem dele podem falhar.'); }
if (!fs.existsSync('data/auth')) fs.mkdirSync('data/auth',{recursive:true});
if (!fs.existsSync('dados/midias')) fs.mkdirSync('dados/midias',{recursive:true});
if (!fs.existsSync('data/db')) fs.mkdirSync('data/db',{recursive:true});
console.log(`👻 FANTASMINHA PREFLIGHT ${pkg.version}`);
for (const x of warn) console.log(`⚠️ ${x}`);
if (fail.length) { for (const x of fail) console.error(`❌ ${x}`); process.exit(1); }
console.log('✅ PREFLIGHT OK');
