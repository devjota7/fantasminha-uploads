import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';
const root = path.resolve(process.cwd());
const ignored = new Set(['node_modules','.git','data','logs','backups']);
function walk(dir, out=[]) { for (const e of fs.readdirSync(dir,{withFileTypes:true})) { if (ignored.has(e.name)) continue; const p=path.join(dir,e.name); if(e.isDirectory()) walk(p,out); else if(/\.(js|mjs)$/.test(e.name)) out.push(p); } return out; }
const files=walk(root); const failures=[];
for(const file of files){ try { execFileSync(process.execPath,['--check',file],{stdio:'pipe'}); } catch(e){ failures.push({file:path.relative(root,file), error:String(e.stderr||e.message).trim()}); } }
if(failures.length){ console.error('SYNTAX FAIL'); for(const f of failures) console.error(`\n${f.file}\n${f.error}`); process.exit(1); }
console.log(`SYNTAX OK — ${files.length} arquivos JS/MJS verificados.`);
