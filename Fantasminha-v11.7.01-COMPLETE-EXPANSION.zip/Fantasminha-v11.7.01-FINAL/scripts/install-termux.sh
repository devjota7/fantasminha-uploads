#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
APP_NAME='Fantasminha'; TARGET="${FANTASMINHA_TARGET:-$HOME/Bots/fantasminha}"; ZIP="${1:-${FANTASMINHA_ZIP:-}}"; BACKUP_ROOT="$HOME/Bots/.fantasminha-install-backups"; say(){ printf '%s\n' "$*"; }; die(){ say "❌ $*"; exit 1; }
[ -n "$ZIP" ] || die 'Informe o ZIP da release.'; [ -f "$ZIP" ] || die "ZIP não encontrado: $ZIP"; command -v pkg >/dev/null 2>&1 || die 'Este instalador foi feito para Termux.'
ANDROID=0; [ "$(uname -o 2>/dev/null || true)" = Android ] && ANDROID=1; ARCH="$(uname -m 2>/dev/null || true)"; NODE_MAJOR=0
command -v unzip >/dev/null 2>&1 || pkg install -y unzip
command -v node >/dev/null 2>&1 || { pkg install -y nodejs-lts || pkg install -y nodejs; }
command -v npm >/dev/null 2>&1 || die 'npm não disponível.'
NODE_MAJOR="$(node -p 'Number(process.versions.node.split(".")[0])')"; [ "$NODE_MAJOR" -ge 20 ] || die "Node >=20 obrigatório (detectado $(node -v))."
mkdir -p "$TARGET" "$BACKUP_ROOT"
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
say "📱 Ambiente: $(uname -o 2>/dev/null || echo desconhecido) / $ARCH / Node $(node -v)"
unzip -t "$ZIP" >/dev/null || die 'ZIP inválido.'; unzip -q "$ZIP" -d "$TMP/extracted"
PAYLOAD="$TMP/extracted"; shopt -s nullglob dotglob; entries=("$PAYLOAD"/*); if [ "${#entries[@]}" -eq 1 ] && [ -d "${entries[0]}" ] && [ -f "${entries[0]}/package.json" ]; then PAYLOAD="${entries[0]}"; fi
[ -f "$PAYLOAD/package.json" ] || die 'package.json não encontrado.'
node -e "const p=require(process.argv[1]); if(p.name!=='fantasminha'||!/^11\\./.test(p.version)) process.exit(2); console.log('Release',p.version)" "$PAYLOAD/package.json" || die 'Release incompatível.'
TS="$(date +%Y%m%d-%H%M%S)"; BK="$BACKUP_ROOT/preinstall-$TS"; mkdir -p "$BK"
# Preserva configurações, sessão, banco e mídia; código continua sendo atualizado.
for item in .env data/auth data/db data/fantasminha.sqlite dados/database dados/midias logs; do if [ -e "$TARGET/$item" ]; then mkdir -p "$BK/$(dirname "$item")"; cp -a "$TARGET/$item" "$BK/$item"; fi; done
say "🛡️ Backup de dados: $BK"
# Remove a árvore de código antiga, preservando apenas os dados explicitamente protegidos.
find "$TARGET" -mindepth 1 -maxdepth 1 ! -name '.env' ! -name 'data' ! -name 'logs' -exec rm -rf -- {} +
cp -a "$PAYLOAD"/. "$TARGET"/
mkdir -p "$TARGET/data/auth" "$TARGET/data/db" "$TARGET/data/backups" "$TARGET/logs" "$TARGET/dados/database/qr-code" "$TARGET/dados/database/grupos" "$TARGET/dados/midias"
# Restaura dados antigos sobre a nova árvore, sem sobrescrever o código.
for item in data/auth data/db data/fantasminha.sqlite dados/database dados/midias logs; do if [ -e "$BK/$item" ]; then rm -rf "$TARGET/$item"; mkdir -p "$(dirname "$TARGET/$item")"; cp -a "$BK/$item" "$TARGET/$item"; fi; done
if [ -f "$BK/.env" ]; then cp -a "$BK/.env" "$TARGET/.env"; elif [ ! -f "$TARGET/.env" ] && [ -f "$TARGET/.env.example" ]; then cp "$TARGET/.env.example" "$TARGET/.env"; chmod 600 "$TARGET/.env" || true; fi
if [ "$ANDROID" -eq 1 ]; then
  say '🧩 Termux/Android detectado: instalando runtime WASM do sharp.'
  npm install --no-audit --no-fund --include=optional sharp@^0.35.4 @img/sharp-wasm32@^0.35.4
else
  npm install --no-audit --no-fund --include=optional
fi
mkdir -p dados/midias
npm run test:syntax
npm run audit:commands
npm test
node tests/release-hardening.mjs
say '✅ Instalação/release validada.'; say "📁 $TARGET"; say '⚠️ Confira .env e então execute: npm start'
