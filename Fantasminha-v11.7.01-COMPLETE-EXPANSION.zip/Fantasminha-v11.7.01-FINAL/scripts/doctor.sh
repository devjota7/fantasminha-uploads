#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
echo "👻 Fantasminha doctor"
echo -n "Node: "; node -v 2>/dev/null || echo "AUSENTE"
echo -n "npm: "; npm -v 2>/dev/null || echo "AUSENTE"
echo -n ".env: "; [ -f .env ] && echo "ok" || echo "FALTA (cp .env.example .env)"
echo -n "config.json: "; [ -f dados/src/config.json ] && echo "ok" || echo "FALTA"
echo -n "espaço: "; df -h . | tail -1
node --input-type=module -e "
import config from './src/core/config.js';
const v = config.validate();
console.log('config validate:', v);
console.log('features:', config.features);
console.log('ai keys:', config.hasAnyAiKey() ? 'presentes' : 'nenhuma');
" 2>/dev/null || echo "doctor module check skipped"
