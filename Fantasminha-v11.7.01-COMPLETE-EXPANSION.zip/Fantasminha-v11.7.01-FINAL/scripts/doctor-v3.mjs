import fs from 'fs';
import path from 'path';
import os from 'os';
import { execFileSync } from 'child_process';
const root=process.cwd();
const checks=[];
const ok=(name,value,detail='',severity='error')=>checks.push({name,ok:!!value,detail,severity});
let pkg={}; try{pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));}catch(e){ }
ok('Node >= 20', Number(process.versions.node.split('.')[0])>=20, process.version);
ok('package.json', !!pkg.name, pkg.name || 'ausente');
ok('connect.js', fs.existsSync(path.join(root,'dados/src/connect.js')));
ok('config.json', fs.existsSync(path.join(root,'dados/src/config.json')));
ok('node_modules', fs.existsSync(path.join(root,'node_modules')), fs.existsSync(path.join(root,'node_modules')) ? 'instalado' : 'rode npm install antes de iniciar', 'warn');
ok('data/db gravável', (()=>{try{const d=path.join(root,'data','db');fs.mkdirSync(d,{recursive:true});const f=path.join(d,'.doctor.tmp');fs.writeFileSync(f,'ok');fs.rmSync(f);return true;}catch{return false;}})());
ok('Termux', fs.existsSync('/data/data/com.termux'), os.platform(), 'warn');
try{execFileSync(process.execPath,['--check','dados/src/.scripts/start.js'],{stdio:'pipe'});ok('start.js sintaxe',true);}catch(e){ok('start.js sintaxe',false,String(e.stderr||e.message));}
for(const c of checks) console.log(`${c.ok?'🟢':(c.severity==='warn'?'🟡':'🔴')} ${c.name}${c.detail?` — ${c.detail}`:''}`);
if(checks.some(c=>!c.ok && c.severity==='error')) process.exit(1);
console.log('\n👻 Doctor V3: ambiente básico saudável.');
