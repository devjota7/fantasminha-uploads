#!/data/data/com.termux/files/usr/bin/bash
cd "$(dirname "$0")/.."
mkdir -p logs data/auth
node dados/src/.scripts/start.js
