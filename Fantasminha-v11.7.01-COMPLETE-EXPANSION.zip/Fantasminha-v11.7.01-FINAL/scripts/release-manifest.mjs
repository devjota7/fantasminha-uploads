#!/usr/bin/env node

import fs from 'fs';
import crypto from 'crypto';
import path from 'path';

const [, , zipArg, versionArg] = process.argv;
if (!zipArg || !versionArg) {
  console.error('Uso: npm run release:manifest -- caminho/Fantasminha-vX.Y.Z.zip X.Y.Z');
  process.exit(1);
}

const zip = path.basename(zipArg);
if (!/^Fantasminha-v\d+\.\d+\.\d+(?:[-+][\w.-]+)?\.zip$/i.test(zip)) {
  console.error('Nome do ZIP inválido.');
  process.exit(1);
}
if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(versionArg)) {
  console.error('Versão inválida.');
  process.exit(1);
}
if (!fs.existsSync(zipArg)) {
  console.error(`ZIP não encontrado: ${zipArg}`);
  process.exit(1);
}

const hash = crypto.createHash('sha256').update(fs.readFileSync(zipArg)).digest('hex');
const manifest = {
  version: versionArg,
  name: 'Fantasminha',
  release: 'stable',
  zip,
  sha256: hash,
  notes: `Fantasminha v${versionArg}`,
  minNode: '20.0.0'
};

fs.writeFileSync('latest.json', JSON.stringify(manifest, null, 2) + '\n');
console.log(JSON.stringify(manifest, null, 2));
console.log(`\nSHA-256: ${hash}`);
console.log('\nEnvie o ZIP e latest.json para a raiz do repositório GitHub configurado.');
