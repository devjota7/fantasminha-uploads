/**
 * Ponte v1.2 ↔ v2 foundation
 * Importar no connect/start quando quiser ativar o registry.
 */
import { bootstrapV2 } from '../../src/core/bootstrap.js';
import { handleMessage } from '../../src/middleware/pipeline.js';
import { getCommand } from '../../src/core/registry.js';
import logger from '../../src/core/logger.js';
import config from '../../src/core/config.js';

let ready = false;

export async function initV2() {
  if (ready) return true;
  try {
    await bootstrapV2();
    ready = true;
    return true;
  } catch (e) {
    ready = false;
    logger.error('v2bridge', e.message);
    return false;
  }
}

export async function tryV2Command(ctx) {
  if (!ready) return { handled: false };
  if (ctx.command && !getCommand(ctx.command)) return { handled: false, legacy: true };
  return handleMessage(ctx);
}

export async function tryV2Message(ctx) {
  if (!ready) return { handled: false };
  return handleMessage(ctx);
}

export function isReady() { return ready; }

export { config, logger, handleMessage, getCommand };
export default { initV2, tryV2Command, tryV2Message };
