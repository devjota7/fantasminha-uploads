import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_downloads(prefix='×') { return buildCatalogMenu(prefix, 'downloads'); }
