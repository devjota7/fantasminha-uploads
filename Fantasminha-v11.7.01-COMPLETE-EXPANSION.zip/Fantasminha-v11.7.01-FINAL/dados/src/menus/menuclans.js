import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_clans(prefix='×') { return buildCatalogMenu(prefix, 'clans'); }
