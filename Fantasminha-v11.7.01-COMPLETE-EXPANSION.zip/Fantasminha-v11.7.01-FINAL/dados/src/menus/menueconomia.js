import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_economia(prefix='×') { return buildCatalogMenu(prefix, 'economia'); }
