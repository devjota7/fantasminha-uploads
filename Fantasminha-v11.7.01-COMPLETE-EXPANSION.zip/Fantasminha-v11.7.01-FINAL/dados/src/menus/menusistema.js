import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_sistema(prefix='×') { return buildCatalogMenu(prefix, 'sistema'); }
