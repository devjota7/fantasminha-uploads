import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_figurinhas(prefix='×') { return buildCatalogMenu(prefix, 'figurinhas'); }
