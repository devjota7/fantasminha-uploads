import { buildCatalogMenu } from './catalogMenu.js';
export default async function menuMundo(prefix='×'){ return buildCatalogMenu(prefix,'mundo'); }
