import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_rpg(prefix='×') { return buildCatalogMenu(prefix, 'rpg'); }
