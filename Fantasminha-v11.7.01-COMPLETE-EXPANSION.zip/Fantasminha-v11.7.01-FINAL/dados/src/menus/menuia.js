import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_ia(prefix='×') { return buildCatalogMenu(prefix, 'ia'); }
