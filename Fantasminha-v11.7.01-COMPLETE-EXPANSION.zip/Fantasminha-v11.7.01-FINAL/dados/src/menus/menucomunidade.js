import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_comunidade(prefix='×') { return buildCatalogMenu(prefix, 'comunidade'); }
