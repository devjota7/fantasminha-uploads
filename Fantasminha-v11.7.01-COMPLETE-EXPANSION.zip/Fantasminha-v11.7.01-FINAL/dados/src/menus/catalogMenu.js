import { MENU_THEME, menuHeader, menuFooter } from './theme.js';
import { listCommands } from '../../../src/core/registry.js';

const HIDDEN_FROM_PUBLIC_MENUS = new Set(['apostar','bet','blackjack','coinflip','crash','horserace','loteria','lottery','roulette','slotmachine','slots']);

const meta = {
  alem: ['🌑 ALÉM', ['alem']],
  economia: ['💰 ECONOMIA', ['economia']],
  jogos: ['🎮 JOGOS', ['jogos']],
  rpg: ['⚔️ RPG', ['rpg']],
  clans: ['🏰 CLÃS & GUERRAS', ['clans','group-clan','wars','campeonato']],
  guerras: ['⚔️ GUERRAS & CAMPEONATOS', ['wars','campeonato']],
  ia: ['🤖 INTELIGÊNCIA', ['ia']],
  downloads: ['📥 DOWNLOADS', ['downloads']],
  figurinhas: ['🖼️ FIGURINHAS', ['figurinhas']],
  ferramentas: ['🔧 FERRAMENTAS', ['ferramentas','produtividade']],
  admin: ['🛡️ ADMINISTRAÇÃO', ['admin']],
  triagem: ['⚖️ TRIAGEM', ['triagem']],
  premium: ['💎 PREMIUM', ['premium']],
  sistema: ['⚙️ SISTEMA', ['sistema','seguranca']],
  dono: ['👑 DONO', ['dono']],
  comunidade: ['👥 COMUNIDADE', ['comunidade','personal']],
  mundo: ['🌎 MUNDO VIVO', ['mundo','world-engine']],
  perfil: ['👻 PERFIL & PROGRESSÃO', ['perfil']],
  mega: ['🚀 EXPANSÕES', ['mega-expansao','expansion','platform']]
};

function chunk(items, size=45){const out=[];for(let i=0;i<items.length;i+=size)out.push(items.slice(i,i+size));return out;}

export function buildCatalogMenu(prefix='×', category){
  const [title, cats] = meta[category] || [String(category||'geral').toUpperCase(), [category]];
  const allowed = new Set(cats);
  const commands = listCommands().filter(c => allowed.has(c.category) && !c.hidden && !HIDDEN_FROM_PUBLIC_MENUS.has(c.name)).sort((a,b)=>a.name.localeCompare(b.name));
  const pages=chunk(commands,45);
  const header=menuHeader('Fantasminha','Usuário',title);
  if(!commands.length) return [header,'',`${MENU_THEME.topBorder} ${title} ┈┈╮`,`${MENU_THEME.middleBorder} Nenhum comando disponível.`,MENU_THEME.bottomBorder,'',menuFooter(`×menu — volte ao portal principal.`)].join('\n');
  return pages.map((page,pi)=>{
    const label=pages.length>1?` • PÁGINA ${pi+1}/${pages.length}`:'';
    const lines=page.map((cmd,i)=>`${MENU_THEME.middleBorder}${String(i+1).padStart(2,'0')} ${MENU_THEME.itemIcon}${prefix}${cmd.name}${cmd.description?` — ${cmd.description}`:''}`);
    return [header,'',`${MENU_THEME.topBorder} ${title}${label} ┈┈╮`,MENU_THEME.middleBorder,...lines,MENU_THEME.middleBorder,`${MENU_THEME.middleBorder}✦ ${commands.length} comandos ativos nesta categoria.`,MENU_THEME.bottomBorder,'',`${MENU_THEME.itemIcon}${prefix}menu • voltar`].join('\n');
  }).join('\n\n');
}
export function getCategoryMeta(category){return meta[category]||null;}
export default {buildCatalogMenu,getCategoryMeta};
