import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_triagem(prefix='×') { return buildCatalogMenu(prefix, 'triagem'); }
