import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_premium(prefix='×') { return buildCatalogMenu(prefix, 'premium'); }
