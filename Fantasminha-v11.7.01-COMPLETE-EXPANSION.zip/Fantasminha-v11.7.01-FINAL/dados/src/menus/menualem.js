import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_alem(prefix='×') { return buildCatalogMenu(prefix, 'alem'); }
