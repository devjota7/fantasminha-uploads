import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_guerras(prefix='×') { return buildCatalogMenu(prefix, 'guerras'); }
