// 👻 FANTASMINHA — DESIGN SYSTEM V11
// Estrutura visual inspirada no padrão clássico do Nazuna,
// com identidade própria do Fantasminha. Um único padrão para menus,
// cabeçalhos, seções, rodapés e respostas.

export const MENU_THEME = Object.freeze({
  topBorder: '╭┈',
  bottomBorder: '╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯',
  middleBorder: '┊',
  itemIcon: '•.̇𖥨֗👻⭟',
  separatorIcon: '❁',
  titleIcon: '👻ฺꕸ▸',
  footerIcon: '🌑',
  ghost: '👻',
  soul: '🩶',
  veil: '🌑',
  cute: '🫧',
  spark: '✦',
  warning: '⚠️',
  success: '✅',
  error: '❌',
  lock: '🔒',
  crown: '👑'
});

const MOODS = Object.freeze({
  success: [
    '👻 Tudo certo. O Além aprovou.',
    '✦ Concluído. Até o pós-vida cooperou.',
    '🩶 Feito. Pode seguir sem medo.',
    '🌑 Operação concluída no Além.'
  ],
  error: [
    '👻 O Além recusou a solicitação. Revise os dados.',
    '🌑 O Véu fechou a passagem. Tente novamente.',
    '⚠️ Algo saiu do caminho. Corrija os dados e tente outra vez.'
  ],
  info: [
    '🌑 Informação entregue pelo Além.',
    '👻 Aqui está. Organizado para você.',
    '✦ O Além respondeu.'
  ],
  warning: [
    '⚠️ Atenção: o Véu detectou algo que merece cuidado.',
    '👻 Cuidado, criatura. Confira os dados antes de continuar.',
    '🌑 Atenção antes de atravessar esta passagem.'
  ]
});

function hashText(text) {
  let h = 0;
  for (const ch of String(text)) h = ((h << 5) - h + ch.charCodeAt(0)) | 0;
  return Math.abs(h);
}

function moodFor(text) {
  const s = String(text || '').trim();
  if (/❌|🚫|erro|falha|inválid|não encontrado|não consegui|recusad/i.test(s)) return 'error';
  if (/⚠️|atenção|cuidado|limite|bloquead/i.test(s)) return 'warning';
  if (/✅|sucesso|concluíd|adicionad|removid|salvo|ativad|desativad|funcion/i.test(s)) return 'success';
  return 'info';
}

function looksLikeStructuredMessage(text) {
  const s = String(text || '');
  const lines = s.split(/\r?\n/);
  return (
    s.includes('╭┈') ||
    s.includes('╭─') ||
    s.includes('╰─') ||
    s.includes('━━━━━━━━') ||
    s.includes('```') ||
    s.length > 1400 ||
    lines.length > 18 ||
    /^\s*[{[]/.test(s)
  );
}

/**
 * Respostas normais permanecem no estilo limpo do Nazuna.
 * A moldura só é aplicada quando o código pedir explicitamente force=true.
 */
export function decorateResponse(text, { force = false, mood = null } = {}) {
  const s = String(text ?? '').trim();
  if (!s || !force) return s;
  if (looksLikeStructuredMessage(s)) return s;

  const kind = mood || moodFor(s);
  const phrases = MOODS[kind] || MOODS.info;
  const phrase = phrases[hashText(s) % phrases.length];

  const label = {
    success: 'ALMA TRANQUILA',
    error: 'TROPEÇO NO VÉU',
    warning: 'SINAL DO ALÉM',
    info: 'SUSSURRO DO ALÉM'
  }[kind] || 'SUSSURRO DO ALÉM';

  const body = s.split(/\r?\n/).map(line => `┊ ${line}`).join('\n');

  return [
    `╭┈⊰ 👻 『 *FANTASMINHA* 』`,
    `┊ ${label}`,
    '┊',
    body,
    `┊ ✦ ${phrase}`,
    '╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯'
  ].join('\n');
}

export function menuHeader(botName = 'Fantasminha', userName = 'Usuário', subtitle = '') {
  const safeBotName = String(botName || 'Fantasminha');
  const safeUserName = String(userName || 'Usuário');
  const title = subtitle ? `👻 ${safeBotName} • ${subtitle}` : `👻 ${safeBotName}`;

  return [
    `╭┈⊰ 👻 『 *${safeBotName}* 』`,
    `┊Olá, ${safeUserName}!`,
    subtitle ? `┊🌑 ${subtitle}` : '',
    '╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯'
  ].filter(Boolean).join('\n');
}

export function menuFooter(text = 'Use ×ajuda para consultar o Além') {
  return [
    '╭┈⊰ 🌑 『 *FIM DO MENU* 』',
    `┊${text}`,
    '┊👻 O Fantasminha continua por aqui.',
    '╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯'
  ].join('\n');
}

export function section(title, lines = [], prefix = '×', hint = '') {
  const body = lines.map(line => `┊${MENU_THEME.itemIcon}${prefix}${line}`).join('\n');
  return [
    `${MENU_THEME.topBorder}${MENU_THEME.separatorIcon} *${title}*`,
    MENU_THEME.middleBorder,
    body,
    hint ? `${MENU_THEME.middleBorder}\n${MENU_THEME.middleBorder}🌑 ${hint}` : '',
    MENU_THEME.bottomBorder
  ].filter(Boolean).join('\n');
}

export function normalizeHeader(header, botName, userName, subtitle) {
  if (!header) return menuHeader(botName, userName, subtitle);
  return header
    .replace(/#user#/g, userName)
    .replace(/\*\$\{botName\}\*/g, botName);
}
