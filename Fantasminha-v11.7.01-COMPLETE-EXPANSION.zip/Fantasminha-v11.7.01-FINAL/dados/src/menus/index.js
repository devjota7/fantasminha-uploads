// Loader ESM-safe para todos os menus — Fantasminha

const menuModules = {
    menu: './menu.js',
    menuAlterador: './alteradores.js',
    menudown: './menudown.js',
    menuadm: './menuadm.js',
    menubn: './menubn.js',
    menuLogos: './menulogo.js',
    menuedits: './menuedits.js',
    menuDono: './menudono.js',
    menuMembros: './menumemb.js',
    menuFerramentas: './ferramentas.js',
    menuSticker: './menufig.js',
    menuTopCmd: './topcmd.js',
    menuRPG: './menurpg.js',
    menuVIP: './menuvip.js',
    menuJogos: './menujogos.js',
    menuAlem: './menualem.js',
    menuEconomia: './menueconomia.js',
    menuClans: './menuclans.js',
    menuGuerras: './menuguerras.js',
    menuIa: './menuia.js',
    menuTriagem: './menutriagem.js',
    menuMundo: './menumundo.js',
    menuPremium: './menupremium.js',
    menuSistema: './menusistema.js',
    menuComunidade: './menucomunidade.js'
};

let menusPromise;

async function loadMenus() {
    if (menusPromise) return menusPromise;

    menusPromise = (async () => {
        const menus = {};

        for (const [name, relPath] of Object.entries(menuModules)) {
            try {
                const mod = await import(new URL(relPath, import.meta.url));
                const fn = mod.default || mod[name];

                if (typeof fn === 'function') {
                    menus[name] = fn;
                } else {
                    console.error(
                        `[${new Date().toISOString()}] [AVISO] Menu '${name}' em ${relPath} não exporta função válida.`
                    );
                }
            } catch (err) {
                console.error(
                    `[${new Date().toISOString()}] [AVISO] Falha ao carregar o menu '${name}' de ${relPath}: ${err.message}`
                );
            }
        }

        const failed = Object.keys(menuModules).filter((name) => !menus[name]);
        if (failed.length > 0) {
            console.error(
                `[${new Date().toISOString()}] [AVISO] Menus não carregados: ${failed.join(', ')}.`
            );
        }

        return menus;
    })();

    return menusPromise;
}

export async function getMenus() {
    return await loadMenus();
}

const menus = await loadMenus();
export default menus;
