import { menuHeader } from './theme.js';
export default async function menuedits(prefix, botName = "Fantasminha", userName = "Usuário", {
    header = null,
    menuTopBorder = "╭┈",
    bottomBorder = "╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯",
    menuTitleIcon = "◆",
    menuItemIcon = "•.̇𖥨֗👻⭟",
    separatorIcon = "❁",
    middleBorder = "┊"
} = {}) {
    const formattedHeader = header ? header.replace(/#user#/g, userName) : menuHeader(botName, userName, 'CENTRAL DO ALÉM');
    return `${formattedHeader}

${menuTopBorder}${separatorIcon} *MENU EDITS*
${middleBorder}
${middleBorder}${menuItemIcon}${prefix}jornal
${middleBorder}${menuItemIcon}${prefix}cinema
${middleBorder}${menuItemIcon}${prefix}blackwhite
${middleBorder}${menuItemIcon}${prefix}desfoque
${middleBorder}${menuItemIcon}${prefix}wojakreaction
${bottomBorder}`;
}