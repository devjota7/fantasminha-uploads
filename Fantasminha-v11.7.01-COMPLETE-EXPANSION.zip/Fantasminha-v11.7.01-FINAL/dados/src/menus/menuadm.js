import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_admin(prefix='×') { return buildCatalogMenu(prefix, 'admin'); }
