import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_jogos(prefix='×') { return buildCatalogMenu(prefix, 'jogos'); }
