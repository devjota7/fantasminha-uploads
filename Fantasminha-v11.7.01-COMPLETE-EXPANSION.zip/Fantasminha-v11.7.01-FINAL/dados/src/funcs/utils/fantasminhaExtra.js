/**
 * Fantasminha — comandos extras, jogos e identidade
 * Tema: pós-vida / purgatório / submundo / dark
 */

import fs from 'fs';
import path from 'path';

const FRASES_ALEM = [
  "No purgatório o café esfria, mas a fila nunca acaba.",
  "Do outro lado do véu o wi-fi é eterno. A paciência, não.",
  "Almas não mentem — só omitem o anexo.",
  "A morte é só o loading screen da próxima fase.",
  "Seu karma pediu reembolso. Negado.",
  "O submundo tem regras. Ninguém as lê.",
  "Fantasmas não dormem. Só fingem.",
  "Julgamento final: falta carimbo.",
  "Você não está perdido. Está em modo espectador.",
  "O véu é fino. Sua desculpa, mais ainda.",
  "Bem-vindo ao limbo. Senha: esqueci.",
  "Eco do além: pare de gritar no grupo.",
  "Cemitério digital: aqui descansam os comandos sem prefixo.",
  "Sombra não te segue. Ela já chegou.",
  "Ceifador de plantão: só coleta conversa hoje."
];

const ORACULOS = [
  "Os ossos dizem: hoje não. Amanhã também não.",
  "Três velas, um aviso: evite decisões impulsivas.",
  "A roda gira. Você está no meio.",
  "Sorte cinza: nem bênção, nem maldição. Só terça-feira.",
  "Uma porta se abre. É a do banheiro. Ainda assim, avance.",
  "O oráculo tossiu. Interprete como quiser.",
  "Destino carimbado: 'em análise'.",
  "As estrelas estão offline. Tente o submundo."
];

const PEADOS = ["preguiça etérea", "ironia excessiva", "furar fila no limbo", "zoar o ceifador", "spam de sticker", "prometer e não voltar", "ler e não responder"];
const VIRTUDES = ["paciência de túmulo", "lealdade de sombra", "humor negro saudável", "escuta ativa do além", "coragem de atravessar o véu"];

const PALAVRAS_FORCA = ["purgatorio", "fantasma", "submundo", "cemiterio", "esqueleto", "caveira", "esquecimento", "barqueiro", "limbo", "sussurro", "velorio", "obituario", "necroterio", "alma", "espirito"];
const QUIZ = [
  { q: "Quem rema as almas no rio?", a: ["barqueiro", "caronte", "charon"] },
  { q: "Lugar entre o céu e o inferno?", a: ["purgatorio", "limbo"] },
  { q: "Nome comum para espírito residual?", a: ["fantasma", "alma", "espectro"] },
  { q: "Objeto que ilumina túmulos em clichês?", a: ["vela", "lanterna"] },
  { q: "Documento da morte (humor)?", a: ["obituario", "atestado"] }
];

function rand(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function pct(seed = "") {
  let h = 0;
  const s = String(seed) + Date.now().toString().slice(0, -5);
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return (h % 101);
}

function ensureDir(p) {
  const d = path.dirname(p);
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

function loadGameState(baseDir, groupId) {
  const file = path.join(baseDir, "games_alem", `${groupId.replace(/[^a-zA-Z0-9@._-]/g, "_")}.json`);
  ensureDir(file);
  if (!fs.existsSync(file)) return { file, data: {} };
  try {
    return { file, data: JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return { file, data: {} };
  }
}

function saveGameState(file, data) {
  ensureDir(file);
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}


function scoresFile(baseDir, groupId) {
  return path.join(baseDir, "games_alem", `scores_${String(groupId).replace(/[^a-zA-Z0-9@._-]/g, "_")}.json`);
}

function loadScores(baseDir, groupId) {
  const file = scoresFile(baseDir, groupId);
  ensureDir(file);
  if (!fs.existsSync(file)) return { file, data: { players: {} } };
  try {
    return { file, data: JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return { file, data: { players: {} } };
  }
}

function addScore(baseDir, groupId, userId, userName, points, game) {
  const { file, data } = loadScores(baseDir, groupId);
  const id = String(userId || "x").replace(/[^a-zA-Z0-9@._-]/g, "_");
  if (!data.players[id]) data.players[id] = { name: userName || id.split("@")[0], points: 0, wins: 0, games: {} };
  data.players[id].name = userName || data.players[id].name;
  data.players[id].points += points;
  if (points > 0) data.players[id].wins += 1;
  if (!data.players[id].games[game]) data.players[id].games[game] = 0;
  data.players[id].games[game] += points;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return data.players[id];
}

function rankText(baseDir, groupId, limit = 10) {
  const { data } = loadScores(baseDir, groupId);
  const list = Object.entries(data.players || {})
    .map(([id, p]) => ({ id, ...p }))
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);
  if (!list.length) return "🏆 *Placar do Além*\\n\\nNenhuma alma pontuou ainda.";
  const lines = list.map((p, i) => `${i + 1}. *${p.name}* — ${p.points} pts (${p.wins} vitórias)`);
  return `🏆 *Placar do Além*\\n\\n${lines.join("\\n")}`;
}

export function placarAlem(baseDir, groupId) {
  return rankText(baseDir, groupId);
}


export function fraseAlem() {
  return `🕯️ *Eco do véu*\n\n_${rand(FRASES_ALEM)}_\n\n— Fantasminha`;
}

export function statusAlem() {
  const estados = ["observando a fila", "carimbando almas", "reiniciando o limbo", "apagando velas", "contando ecos", "zoando o ceifador"];
  return `👻 *Status do Além*\n\n• Fantasminha: *online no véu*\n• Submundo: *${rand(estados)}*\n• Fila do purgatório: *${20 + Math.floor(Math.random() * 980)} almas*\n• Wi-fi eterno: *estável*\n• Humor negro: *ativo*`;
}

export function oraculo() {
  return `👁️ *Oráculo do Submundo*\n\n${rand(ORACULOS)}`;
}

export function veuMsg() {
  return `🌑 *O Véu*\n\nFino o bastante para ouvir o grupo.\nEspesso o bastante para você não fugir do prefixo.\n\nAtravesse com: comandos, não com desculpas.`;
}

export function purgatorioMsg() {
  return `⛓️ *Purgatório*\n\nRegras:\n1. Espere.\n2. Reespere.\n3. Aceite o meme.\n\nCafé: frio.\nFila: eterna.\nVocê: ainda aqui.`;
}

export function submundoMsg() {
  return `🕳️ *Submundo*\n\nNão é inferno. É escritório com iluminação pior.\nAqui o Fantasminha manda nos menus.\nVocê manda... nos stickers.`;
}

export function cemiterioMsg() {
  return `⚰️ *Cemitério Digital*\n\nAqui descansam:\n• comandos sem prefixo\n• promessas de "já volto"\n• figuris que ninguém salvou\n\nDescanse em paz (ou reinicie o bot).`;
}

export function ecoMsg(text) {
  if (!text) return `📢 *Eco*\nUse: eco <texto>\nO além repete. Sem filtro emocional.`;
  return `📢 *Eco do além*\n\n${text}\n\n_${text}_\n\n**${text}**`;
}

export function almaMsg(nome) {
  const n = nome || "Alguém";
  return `👻 *Análise de alma — ${n}*\n\n• Transparência: ${pct(n)}%\n• Peso espiritual: ${1 + (pct(n + "p") % 99)} kg de ironia\n• Pecado favorito: ${rand(PEADOS)}\n• Virtude residual: ${rand(VIRTUDES)}\n• Veredito: ${pct(n) > 50 ? "pode atravessar o véu" : "volta pra fila"}`;
}

export function julgamentoMsg(nome) {
  const n = nome || "o réu";
  const vereditos = ["absolvido por falta de provas", "condenado a 3 stickers", "liberdade vigiada no limbo", "trabalhos forçados: ler o menu", "pena suspensa por humor aceitável"];
  return `⚖️ *Julgamento Final*\n\nRéu: *${n}*\nAcusação: existir em grupo de WhatsApp\n\nVeredito: *${rand(vereditos)}*\n\n— Fantasminha, juíza interina do submundo`;
}

export function perfilAlem(nome) {
  const n = nome || "Viajante";
  return `🌑 *Perfil do Além — ${n}*\n\n• Classe: ${rand(["Espectro", "Sombra", "Barqueiro trainee", "Alma inquieta", "Ceifador júnior"])}\n• Nível no limbo: ${1 + (pct(n) % 50)}\n• Karma: ${pct(n + "k") - 50}\n• Inventário: vela, ironia, 1 ticket de fila\n• Status: *consciente do meme*`;
}

export function sombraMsg(nome) {
  return `🌑 *Sombra de ${nome || "você"}*\n\nEla não copia seus passos.\nCopia suas desculpas.\n\nHoje a sombra está: *${rand(["silenciosa", "julgando", "rindo baixo", "adiantada"])}*.`;
}

export function destinoMsg() {
  const d = ["fila preferencial no limbo", "dia de silêncio etéreo", "sorte cinza", "convite pro purgatório VIP", "reset de karma parcial", "missão: ler o menudono"];
  return `🔮 *Destino puxado do véu*\n\n→ *${rand(d)}*`;
}

export function pecadoMsg() { return `😈 *Pecado do dia*\n\n${rand(PEADOS)}\n\nMulta: 1 reflexão.`; }
export function virtudeMsg() { return `✨ *Virtude residual*\n\n${rand(VIRTUDES)}\n\nBônus: +1 paciência.`; }

export function karmaMsg(nome) {
  const k = pct(nome || "x") - 50;
  return `☯️ *Karma — ${nome || "você"}*\n\nSaldo: *${k > 0 ? "+" : ""}${k}*\n${k >= 20 ? "Fila rápida." : k <= -20 ? "Volta pro fim." : "Fila normal. Como sempre."}`;
}

export function horarioVeu() {
  const now = new Date();
  const br = now.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
  return `🕯️ *Horário do Véu*\n\nLado de cá (BR): *${br}*\nLado de lá: *sempre tarde demais*\nTurno do Fantasminha: *eterno*`;
}

export function contagemAlmas(n) {
  const q = typeof n === "number" ? n : Math.floor(Math.random() * 200) + 12;
  return `👻 *Contagem de almas no grupo*\n\nDetectadas: *${q}*\n(incluindo quem só visualiza)`;
}

export function shipAlem(a, b) {
  const s = pct((a || "") + (b || ""));
  return `💀 *Ship do Cemitério*\n\n${a || "Alma A"} ⚰️ ${b || "Alma B"}\nCompatibilidade etérea: *${s}%*\n${s > 70 ? "Casamento no limbo liberado." : s > 40 ? "Amizade de túmulo." : "Melhor cada um no seu caixão."}`;
}

export function percentualAlma(nome) {
  return `📊 *Percentual de alma — ${nome || "você"}*\n\n• Humanidade: ${pct(nome)}%\n• Fantasma: ${100 - pct(nome)}%\n• Ironia: ${pct(nome + "i")}%`;
}

export function verdadeAlem() {
  const v = ["Você já abriu o menu e fingiu que leu.", "Alguém no grupo deve um sticker.", "O dono viu e não comentou.", "Seu último áudio tinha eco do além.", "O bot não esquece. Só finge."];
  return `🕯️ *Verdade do além*\n\n${rand(v)}`;
}

export function desafioAlem() {
  const d = ["Mande um elogio sarcástico.", "Fique 5 min sem sticker.", "Leia o menualem inteiro.", "Admita um pecado digital.", "Marque alguém e peça perdão teatral."];
  return `⚔️ *Desafio do purgatório*\n\n${rand(d)}\n\nFalhou? Volta pra fila.`;
}

export function conselhoAlem() {
  const c = ["Menos impulso, mais véu.", "Se não cabe num comando, cabe num silêncio.", "Ironia resolve 60%. O resto é sticker.", "Durma. O limbo não paga hora extra.", "Respeite o prefixo. Ele respeita você."];
  return `📜 *Conselho do Fantasminha*\n\n${c[Math.floor(Math.random() * c.length)]}`;
}

export function diarioAlem() {
  return `📓 *Diário do Além — entrada aleatória*\n\nHoje a fila andou ${Math.floor(Math.random() * 3)} passos.\nO ceifador pediu café.\nNinguém levou.\nFim do registro.`;
}

// ——— JOGOS ———

export function startForca(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  const palavra = rand(PALAVRAS_FORCA);
  data.forca = {
    palavra,
    masked: palavra.replace(/./g, "▮"),
    tentativas: 6,
    usadas: [],
    by: user
  };
  saveGameState(file, data);
  return `🎲 *Forca do Além*\n\nPalavra: \`${data.forca.masked}\`\nTentativas: ${data.forca.tentativas}\n\nChute: \`letra <x>\` ou use o comando com a letra.\nTema: submundo.`;
}

export function playForca(baseDir, groupId, letra, user = null, userName = null) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.forca) return "Nenhuma forca ativa. Use *forcaalem*.";
  const L = (letra || "").toLowerCase().replace(/[^a-zà-ú]/gi, "").slice(0, 1);
  if (!L) return "Envie uma letra. Ex: letra a";
  const g = data.forca;
  if (g.usadas.includes(L)) return `Letra *${L}* já usada.
\`${g.masked}\` — tentativas: ${g.tentativas}`;
  g.usadas.push(L);
  const name = userName || (user ? String(user).split("@")[0] : "alma");
  if (g.palavra.includes(L)) {
    g.masked = g.palavra.split("").map((ch) => (g.usadas.includes(ch) ? ch : "▮")).join("");
    if (user) addScore(baseDir, groupId, user, name, 2, "forca");
    if (g.masked === g.palavra) {
      if (user) addScore(baseDir, groupId, user, name, 13, "forca");
      delete data.forca;
      saveGameState(file, data);
      return `✨ *Acertou!* A palavra era *${g.palavra}*.
*${name}* +15 pts

${rankText(baseDir, groupId, 5)}`;
    }
    saveGameState(file, data);
    return `✅ *${L}* existe. (+2 pts)
\`${g.masked}\`
Tentativas: ${g.tentativas}`;
  }
  g.tentativas--;
  if (g.tentativas <= 0) {
    const w = g.palavra;
    delete data.forca;
    saveGameState(file, data);
    return `💀 *Enforcado no limbo.*
A palavra era *${w}*.`;
  }
  saveGameState(file, data);
  return `❌ *${L}* não tem.
\`${g.masked}\`
Tentativas: ${g.tentativas}`;
}

export function startQuiz(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  const item = rand(QUIZ);
  data.quiz = { ...item };
  saveGameState(file, data);
  return `❓ *Quiz do Além*\n\n${item.q}\n\nResponda com: *respostaquiz <texto>*`;
}

export function answerQuiz(baseDir, groupId, ans, user = null, userName = null) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.quiz) return "Nenhum quiz ativo. Use *quizalem*.";
  const answers = data.quiz.a || [];
  const ok = answers.some((a) => (ans || "").toLowerCase().includes(a));
  delete data.quiz;
  saveGameState(file, data);
  if (ok) {
    const name = userName || (user ? String(user).split("@")[0] : "alma");
    if (user) addScore(baseDir, groupId, user, name, 10, "quiz");
    return `✅ *Correto.* O véu aprova.
*${name}* +10 pts

${rankText(baseDir, groupId, 5)}`;
  }
  return `❌ *Errado.* O além ri baixo.
Respostas válidas: ${answers.join(", ") || "segredo"}`;
}

export function roletaAlem(baseDir = null, groupId = null, user = null, userName = null) {
  const slots = [
    { t: "💀 alma perdida", pts: -5 },
    { t: "🕯️ vela extra", pts: 5 },
    { t: "⛓️ +1 fila", pts: -2 },
    { t: "👻 fantasma aliado", pts: 8 },
    { t: "🌑 nada (clássico)", pts: 0 },
    { t: "✨ karma +10", pts: 10 },
    { t: "⚰️ reset parcial", pts: -8 }
  ];
  const pick = rand(slots);
  let extra = "";
  if (baseDir && groupId && user && pick.pts !== 0) {
    const name = userName || String(user).split("@")[0];
    addScore(baseDir, groupId, user, name, pick.pts, "roleta");
    extra = "\n\n" + rankText(baseDir, groupId, 5);
  }
  return `🎰 *Roleta da Alma*\n\n→ *${pick.t}*\nPontos: *${pick.pts > 0 ? "+" : ""}${pick.pts}*${extra}`;
}

export function batalhaAlmas(a, b) {
  const pa = pct(a || "a");
  const pb = pct(b || "b");
  const vencedor = pa >= pb ? (a || "Alma A") : (b || "Alma B");
  return `⚔️ *Batalha de Almas*\n\n${a || "Alma A"} (${pa}) vs ${b || "Alma B"} (${pb})\n\nVencedor etéreo: *${vencedor}*\nO perdedor volta pra fila com dignidade duvidosa.`;
}

export function caminhoVeu(escolha) {
  const map = {
    esquerda: "Você acha um corredor de ecos. +1 mistério, -1 certeza.",
    direita: "Porta do purgatório. Fila andou 2 metros. Parabéns?",
    frente: "O véu se abre. É só o menu de novo. Ainda assim, avanço.",
    tras: "Voltar não é opção. O chão sumiu."
  };
  const e = (escolha || "").toLowerCase();
  if (!map[e]) return `🛤️ *Caminho do Véu*\n\nEscolha: *esquerda*, *direita*, *frente* ou *tras*\nEx: caminhoveu frente`;
  return `🛤️ *Caminho do Véu — ${e}*\n\n${map[e]}`;
}

export function memoriaFantasma() {
  const simb = ["👻", "💀", "🕯️", "⛓️", "🌑", "⚰️"];
  const seq = [rand(simb), rand(simb), rand(simb), rand(simb)];
  return `🧠 *Memória Fantasma*\n\nSequência (decore e repita no chat):\n${seq.join(" ")}\n\n_O além não confere. Sua consciência sim._`;
}

export function anagramaAlma() {
  const palavra = rand(PALAVRAS_FORCA);
  const mist = palavra.split("").sort(() => Math.random() - 0.5).join("");
  return `🔤 *Anagrama da Alma*\n\nDesembaralhe: *${mist}*\n\n(Tema: além. Resposta no coração — ou no quiz.)`;
}

export function cacaAlma() {
  const grid = "F A N T A S M A\nP U R G A T O R\nL I M B O X Y Z\nS O M B R A Q W\nC E I F A D O R";
  return `🔎 *Caça-Alma*\n\n\`\`\`\n${grid}\n\`\`\`\nAche: FANTASMA, LIMBO, SOMBRA, CEIFADOR, PURGATOR (quase).`;
}

export function juizFinal(opcao) {
  const o = (opcao || "").toLowerCase();
  if (!["culpado", "inocente", "limbo"].includes(o)) {
    return `⚖️ *Juiz Final*\nVote: *culpado*, *inocente* ou *limbo*\nEx: juizfinal limbo`;
  }
  return `⚖️ *Urna do Submundo*\n\nSeu voto: *${o}*\nComputado nas sombras.\nResultado oficial: *${rand(["empate eterno", "limbo vence", "adiado", "carimbado"])}*`;
}

export function torreLimbo(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.torre) data.torre = {};
  const u = user || "anon";
  data.torre[u] = (data.torre[u] || 0) + 1;
  const andar = data.torre[u];
  saveGameState(file, data);
  const eventos = ["degrau range", "eco responde", "vela apaga", "fila atravessa", "nada acontece (pior)"];
  return `🗼 *Torre do Limbo*\n\n${u.split("@")[0]} subiu para o andar *${andar}*.\nEvento: ${rand(eventos)}\n\nContinue com *torrelimbo* para subir de novo.`;
}

export function topAlmasFake() {
  return `🏆 *Top Almas (simbólico)*\n\n1. Quem lê o menu\n2. Quem usa prefixo certo\n3. Quem não spamma\n4. O dono\n5. O Fantasminha (fora de competição)`;
}



export function batalhaDesafiar(baseDir, groupId, challenger, challengerName, targetId, targetName) {
  if (!targetId) return "⚔️ Use: *batalhaalmas @user* — alvo aceita com *aceitarbatalha*.";
  const { file, data } = loadGameState(baseDir, groupId);
  data.batalha = { from: challenger, fromName: challengerName || String(challenger).split("@")[0], to: targetId, toName: targetName || String(targetId).split("@")[0], at: Date.now() };
  saveGameState(file, data);
  return `⚔️ *Desafio*\n*${data.batalha.fromName}* vs *${data.batalha.toName}*\nAceitar: *aceitarbatalha* | Recusar: *recusarbatalha*`;
}

export function batalhaAceitar(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.batalha) return "Nenhum desafio ativo.";
  const a = pct(data.batalha.from + Date.now());
  const b = pct(data.batalha.to + Date.now() + 7);
  const winA = a >= b;
  const winner = winA ? data.batalha.from : data.batalha.to;
  const winnerName = winA ? data.batalha.fromName : data.batalha.toName;
  addScore(baseDir, groupId, winner, winnerName, 12, "batalha");
  const msg = `⚔️ *Batalha*\\n${data.batalha.fromName} (${a}) vs ${data.batalha.toName} (${b})\n🏆 *${winnerName}* +12 pts\n\n${rankText(baseDir, groupId, 5)}`;
  delete data.batalha;
  saveGameState(file, data);
  return msg;
}

export function batalhaRecusar(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.batalha) return "Nenhum desafio ativo.";
  delete data.batalha;
  saveGameState(file, data);
  return "🏳️ Desafio recusado.";
}

export function startMemoria(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  const simb = ["👻", "💀", "🕯️", "⛓️", "🌑", "⚰️"];
  const seq = [rand(simb), rand(simb), rand(simb), rand(simb)];
  data.memoria = { seq, seqStr: seq.join(" ") };
  saveGameState(file, data);
  return `🧠 *Memória Fantasma*\\n\\n${seq.join(" ")}\\n\\nRepita: *respostamemoria 👻 💀 ...* (+8 pts)`;
}

export function answerMemoria(baseDir, groupId, ans, user, userName) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.memoria) return "Use *memoriafantasma* primeiro.";
  const clean = (ans || "").replace(/\\s+/g, " ").trim();
  const ok = clean === data.memoria.seqStr || clean.replace(/ /g, "") === data.memoria.seq.join("");
  delete data.memoria;
  saveGameState(file, data);
  if (ok && user) {
    const name = userName || String(user).split("@")[0];
    addScore(baseDir, groupId, user, name, 8, "memoria");
    return `✅ *${name}* +8 pts\n\n${rankText(baseDir, groupId, 5)}`;
  }
  return ok ? "✅ Correto!" : "❌ Sequência errada.";
}

export function juizStart(baseDir, groupId, alvo) {
  const { file, data } = loadGameState(baseDir, groupId);
  data.juiz = { alvo: alvo || "réu anônimo", votos: {} };
  saveGameState(file, data);
  return `⚖️ *Julgamento* — réu: *${data.juiz.alvo}*\\nVote: *juizfinal culpado|inocente|limbo*\\nEncerre: *encerrarjuiz*`;
}

export function juizVotar(baseDir, groupId, opcao, user, userName) {
  const { file, data } = loadGameState(baseDir, groupId);
  const o = (opcao || "").toLowerCase();
  if (!data.juiz) return juizStart(baseDir, groupId, "réu misterioso");
  if (!["culpado", "inocente", "limbo"].includes(o)) return "Vote: culpado, inocente ou limbo";
  data.juiz.votos[String(user)] = { voto: o, name: userName || String(user).split("@")[0] };
  saveGameState(file, data);
  return `🗳️ Voto *${o}* registrado. Total: ${Object.keys(data.juiz.votos).length}. Encerre: *encerrarjuiz*`;
}

export function juizEncerrar(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.juiz) return "Nenhuma sessão ativa.";
  const counts = { culpado: 0, inocente: 0, limbo: 0 };
  for (const v of Object.values(data.juiz.votos)) counts[v.voto] = (counts[v.voto] || 0) + 1;
  const winner = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  const alvo = data.juiz.alvo;
  const total = Object.keys(data.juiz.votos).length;
  delete data.juiz;
  saveGameState(file, data);
  return `⚖️ *Encerrado* — réu *${alvo}* | votos ${total}\\nCulpado ${counts.culpado} | Inocente ${counts.inocente} | Limbo ${counts.limbo}\\nVeredito: *${winner[0]}*`;
}

export function menuInfoHeader({ botName, userName, cargo, ownerName }) {
  return `╭┈─◌ 𓇬 ◌ 🌑 ◌ 𓇬 ◌─┈╮
┊ 👻 ⋆˚｡ 𝐈𝐍𝐅𝐎𝐒 𝐃𝐎 𝐁𝐎𝐓 ｡˚⋆
┊ 🤖 ʙᴏᴛ: ${botName || "Fantasminha"}
┊ 👤 ᴜsᴜᴀʀɪᴏ: ${userName || "Viajante"}
┊ 🛡️ ᴄᴀʀɢᴏ: ${cargo || "Membro"}
┊ 👑 ᴅᴏɴᴏ: ${ownerName || "Jota"}
╰┈─◌ 𓇬 ◌ 🌑 ◌ 𓇬 ◌─┈╯`;
}

export function errMsg(detail) {
  return `🕯️ *O véu engasgou.*\n${detail || "Tente de novo."}\n— Fantasminha`;
}

export function cmdNotFoundMsg(prefix, cmd) {
  const p = prefix || "×";
  const cm = cmd || "?";
  return `🌑 *Comando não encontrado no além.*\n\n· \`${p}${cm}\` não existe neste plano.\n· Tente \`${p}menu\` ou \`${p}menualem\`.\n\n— Fantasminha`;
}

export function statusBotDetailed({ nomebot, prefix, uptimeSec, nodeVersion }) {
  const h = Math.floor(uptimeSec / 3600);
  const m = Math.floor((uptimeSec % 3600) / 60);
  const mem = process.memoryUsage();
  const mb = (n) => (n / 1024 / 1024).toFixed(1);
  return `👻 *Status Fantasminha*\n\n• Bot: *${nomebot}*\n• Prefixo: *${prefix}*\n• Uptime: *${h}h ${m}m*\n• Node: *${nodeVersion}*\n• RAM: *${mb(mem.heapUsed)} MB*\n• Tema: além / purgatório`;
}

export function backupConfig(configPath, backupDir) {
  ensureDir(backupDir + "/x");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dest = path.join(backupDir, `config_${stamp}.json`);
  fs.copyFileSync(configPath, dest);
  return dest;
}

export default {
  fraseAlem, statusAlem, oraculo, veuMsg, purgatorioMsg, submundoMsg, cemiterioMsg, ecoMsg,
  almaMsg, julgamentoMsg, perfilAlem, sombraMsg, destinoMsg, pecadoMsg, virtudeMsg, karmaMsg,
  horarioVeu, contagemAlmas, shipAlem, percentualAlma, verdadeAlem, desafioAlem, conselhoAlem, diarioAlem,
  startForca, playForca, startQuiz, answerQuiz, roletaAlem, batalhaAlmas, caminhoVeu, memoriaFantasma,
  anagramaAlma, cacaAlma, juizFinal, torreLimbo, topAlmasFake, placarAlem,
  batalhaDesafiar, batalhaAceitar, batalhaRecusar, startMemoria, answerMemoria,
  juizStart, juizVotar, juizEncerrar, menuInfoHeader, errMsg, cmdNotFoundMsg,
  statusBotDetailed, backupConfig
};
