import { updateCollection, readCollection } from '../database/store.js';
import logger from '../core/logger.js';

const buckets = new Map(); // scope:userId -> { times: number[] }
const MAX_BUCKETS = 20_000;

/**
 * checkFlood(userId, { max, windowMs })
 */
export function checkFlood(userId, { max = 8, windowMs = 8000 } = {}) {
  const now = Date.now();
  let b = buckets.get(userId);
  if (!b) b = { times: [], warns: 0 };
  b.times = b.times.filter((t) => now - t < windowMs);
  b.times.push(now);
  buckets.set(userId, b);
  if (buckets.size > MAX_BUCKETS) { for (const [k, v] of buckets) if (!v.times.length || now - v.times[v.times.length - 1] > windowMs * 2) buckets.delete(k); while (buckets.size > MAX_BUCKETS) buckets.delete(buckets.keys().next().value); }
  if (b.times.length > max) {
    return { flooded: true, count: b.times.length };
  }
  return { flooded: false, count: b.times.length };
}

export async function addWarnV2(groupId, userId) {
  let shouldBan = false;
  let warns = 0;
  await updateCollection('groups', (G) => {
    if (!G.byId) G.byId = {};
    if (!G.byId[groupId]) G.byId[groupId] = { warns: {}, settings: { maxWarns: 3, antiflood: true } };
    const g = G.byId[groupId];
    if (!g.warns) g.warns = {};
    g.warns[userId] = (g.warns[userId] || 0) + 1;
    warns = g.warns[userId];
    const max = g.settings?.maxWarns || 3;
    if (warns >= max) shouldBan = true;
    return G;
  }, { byId: {} });
  return { warns, shouldBan };
}

export async function isAutoBanEnabled(groupId) {
  const G = readCollection('groups', { byId: {} });
  return G.byId?.[groupId]?.settings?.autoban !== false;
}

export async function setGroupModeration(groupId, patch) {
  await updateCollection('groups', (G) => {
    if (!G.byId) G.byId = {};
    if (!G.byId[groupId]) G.byId[groupId] = { warns: {}, settings: {} };
    G.byId[groupId].settings = { ...G.byId[groupId].settings, ...patch };
    return G;
  }, { byId: {} });
}

export default { checkFlood, addWarnV2, isAutoBanEnabled, setGroupModeration };
