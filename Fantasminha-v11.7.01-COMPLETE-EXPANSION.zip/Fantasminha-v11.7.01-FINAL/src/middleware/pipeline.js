import { runCommand, getCommand } from '../core/registry.js';
import logger from '../core/logger.js';
import config from '../core/config.js';
import { rateLimit } from './rateLimit.js';
import { checkFlood, addWarnV2, isAutoBanEnabled } from './antiflood.js';
import { emit, Events } from '../events/index.js';
import { cooldownMultiplier } from '../services/vipBenefits.js';
import { ensureGroupClan } from '../services/groupClans.js';
import { resolveMigration, noteMigrationUsed } from '../platform/migrations/index.js';
import { enrichMessageContext } from '../core/messageContext.js';
import { recordEnvelope } from '../core/messageEnvelope.js';
import { getCustomCommand } from '../services/customCommands.js';
import { handleTriageBuilderMessage } from '../services/triage.js';
import { recordMessage } from '../services/profile.js';
import { handleInnovationMessage } from '../services/innovation.js';
import { isDuplicateMessage } from './messageDedup.js';
import { handleRawGameInput } from '../services/gameInput.js';
import { clearAfkFromMessage } from '../services/social.js';

export function extractCommand(text, prefix = config.prefix) {
  if (!text || typeof text !== 'string') return null;
  const t = text.trim();
  if (!t.startsWith(prefix)) return null;
  const body = t.slice(prefix.length).trim();
  if (!body) return null;
  const [cmd, ...rest] = body.split(/\s+/);
  return { command: cmd.toLowerCase(), args: rest, q: rest.join(' '), raw: body };
}

export async function handleMessage(ctx) {
  enrichMessageContext(ctx);
  if (ctx?.isPrivate && ctx?.sender) {
    const { isPvAllowed } = await import('../services/pvPermissions.js');
    if (!ctx.isOwner && !isPvAllowed(ctx.sender)) {
      if (ctx.command || String(ctx.body || ctx.text || '').trim().startsWith(ctx.prefix || config.prefix)) {
        if (ctx.reply) await ctx.reply('🔒 *PV RESTRITO*\n\nEste bot está configurado para não processar comandos no privado sem autorização do dono.');
        return { handled:true, pvBlocked:true };
      }
      return { handled:false, pvBlocked:true };
    }
  }
  if (!ctx?.message?.__fantasminhaDedupAccepted && isDuplicateMessage(ctx)) { logger.debug?.('pipeline', 'mensagem duplicada ignorada'); return { handled:true, duplicate:true }; }
  globalThis.__fantasminhaOwnerIds = [config.ownerNumber, config.ownerLid, ...(config.ownerIds || [])].filter(Boolean);
  // AFK clássico: qualquer mensagem do próprio usuário encerra a ausência.
  // A exceção é o próprio comando ×afk/×ausente, que pode criar/atualizar o estado.
  if (ctx.sender && !ctx.fromMe) {
    try { await clearAfkFromMessage(ctx); } catch (e) { logger.debug?.('afk', `não foi possível limpar AFK: ${e.message}`); }
  }
  if (!ctx.isOwner) { const { configuredOwner } = await import('../core/permissions.js'); ctx.isOwner = configuredOwner(ctx.sender); }
  if (ctx.message) recordEnvelope(ctx.message, { readable: true, kind: ctx.message?.message?.paymentMessage ? 'payment' : 'other' });
  await emit(Events.MESSAGE, ctx);
  // Fluxo sem prefixo do construtor simples de triagem.
  try { const setup = await handleTriageBuilderMessage(ctx); if (setup?.handled) return setup; } catch (e) { logger.warn('triage-builder', e.message); }
  try { const gameInput = await handleRawGameInput(ctx); if (gameInput?.handled) return gameInput; } catch (e) { logger.warn('game-input', e.message); }
  try { const game = await handleInnovationMessage(ctx); if (game?.handled) return game; } catch (e) { logger.warn('innovation-game', e.message); }
  if (ctx.isGroup && ctx.sender) recordMessage(ctx.sender, ctx.from);
  if (ctx.isGroup && ctx.from) {
    try { await ensureGroupClan(ctx.from, ctx.groupName || 'Grupo', ctx.participantCount || 0); }
    catch (e) { logger.warn('pipeline', 'não foi possível sincronizar Clã do Grupo', { error: e.message }); }
  }

  // Anti-flood unificado (só comandos / mensagens rápidas)
  if (ctx.sender && !ctx.isOwner && !ctx.isGroupAdmin) {
    const flood = checkFlood(`${ctx.from || 'private'}:${ctx.sender}`, { max: 10, windowMs: 7000 });
    if (flood.flooded) {
      if (ctx.isGroup && ctx.from) {
        const { warns, shouldBan } = await addWarnV2(ctx.from, ctx.sender);
        const autoban = await isAutoBanEnabled(ctx.from);
        if (ctx.reply) {
          await ctx.reply(
            `🕯️ Flood detectado. Warn *${warns}*.` +
              (shouldBan && autoban ? '\n⛔ Limite atingido — *auto-ban* sugerido (admin execute ban).' : '')
          );
        }
        ctx._floodShouldBan = shouldBan && autoban;
        ctx._floodTarget = ctx.sender;
      } else if (ctx.reply) {
        await ctx.reply('🕯️ Devagar no véu (anti-flood).');
      }
      return { handled: true, flooded: true };
    }
  }

  const parsed = extractCommand(ctx.body || ctx.text || '', ctx.prefix || config.prefix);
  if (!parsed) return { handled: false };

  ctx.command = parsed.command;
  ctx.args = parsed.args;
  ctx.q = parsed.q;

  const rl = rateLimit(ctx.sender, { scope: ctx.from || 'private', max: 20, windowMs: 10_000 });
  if (!rl.ok) {
    if (ctx.reply) await ctx.reply(`🕯️ Rate limit. Aguarde ${rl.retryAfter}s.`);
    return { handled: true, rateLimited: true };
  }

  // VIP reduz cooldown efetivo via flag no ctx
  ctx.cooldownMult = cooldownMultiplier(ctx.sender);

  if (!getCommand(parsed.command)) {
    const custom = getCustomCommand(parsed.command);
    if (custom) {
      const text = custom.text.replace(/\{user\}/gi, ctx.pushname || ctx.sender || '').replace(/\{q\}/gi, ctx.q || '');
      if (ctx.reply) await ctx.reply(text);
      return { handled: true, custom: true, command: parsed.command };
    }
    const migration = resolveMigration(parsed.command);
    if (migration && getCommand(migration.target)) {
      await noteMigrationUsed(migration, ctx);
      if (migration.mode === 'notice' && ctx.reply) await ctx.reply(`🔄 Comando atualizado: use ${ctx.prefix || config.prefix}${migration.target} daqui para frente.`);
      const result = await runCommand(migration.target, { ...ctx, command: migration.target, migratedFrom: parsed.command });
      return { handled: result.found, command: migration.target, migratedFrom: parsed.command };
    }
    return { handled: false, legacy: true, command: parsed.command };
  }

  try {
    const result = await runCommand(parsed.command, ctx);
    return { handled: result.found, command: parsed.command };
  } catch (err) {
    logger.error('pipeline', err.message, { command: parsed.command });
    if (ctx.reply && !err?.__fantasminhaUserErrorHandled) await ctx.reply(err.userMessage || err.message || '🕯️ O véu engasgou.');
    return { handled: true, error: true };
  }
}

export default { extractCommand, handleMessage };
