const hits = new Map();
const MAX_BUCKETS = 20_000;
export function rateLimit(userId, { scope = '', max = 15, windowMs = 10_000 } = {}) {
  const now = Date.now(); const k = `${scope}:${String(userId || 'anon')}`;
  let b = hits.get(k);
  if (!b || now - b.start >= windowMs) b = { start: now, count: 0 };
  b.count++; hits.set(k, b);
  if (hits.size > MAX_BUCKETS) {
    for (const [key, value] of hits) if (now - value.start > windowMs * 2) hits.delete(key);
    while (hits.size > MAX_BUCKETS) hits.delete(hits.keys().next().value);
  }
  if (b.count > max) return { ok: false, retryAfter: Math.max(1, Math.ceil((windowMs - (now - b.start)) / 1000)) };
  return { ok: true, remaining: Math.max(0, max - b.count) };
}
export function clearRateLimits() { hits.clear(); }
export default { rateLimit, clearRateLimits };
