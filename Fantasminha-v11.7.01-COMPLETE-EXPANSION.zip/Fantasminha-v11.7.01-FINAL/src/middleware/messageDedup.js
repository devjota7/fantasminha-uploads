const TTL_MS=60_000;
const seen=new Map();
function keyOf(ctx){
  const k=ctx?.message?.key;
  if(!k?.id||k?.fromMe)return null;
  return `${k.remoteJid||ctx.from||''}:${k.id}:${k.participant||k.participantAlt||ctx.sender||''}`;
}
export function isDuplicateMessage(ctx){
  const key=keyOf(ctx); if(!key)return false;
  const now=Date.now();
  for(const [k,t] of seen) if(now-t>TTL_MS) seen.delete(k);
  if(seen.has(key)) return true;
  seen.set(key,now); return false;
}
export default {isDuplicateMessage};
