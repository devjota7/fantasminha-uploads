import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { updateCollection, readCollection } from '../../database/store.js';
import { ValidationError } from '../../core/errors.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCommand({
    name: 'warn',
    aliases: ['advertir'],
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    description: 'Advertir usuário',
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (!target) throw new ValidationError('Marque alguém: warn @user');
      const groups = await updateCollection('groups', (G) => {
        if (!G.byId) G.byId = {};
        if (!G.byId[ctx.from]) G.byId[ctx.from] = { warns: {}, settings: {} };
        const w = G.byId[ctx.from].warns;
        w[target] = (w[target] || 0) + 1;
        return G;
      }, { byId: {} });
      const n = groups.byId[ctx.from].warns[target];
      await ctx.reply(tag(`⚠️ Advertência *${n}* para @${String(target).split('@')[0]}.\nLimite sugerido: 3.`));
    }
  });

  registerCommand({
    name: 'warns',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0] || ctx.sender;
      const G = readCollection('groups', { byId: {} });
      const n = G.byId?.[ctx.from]?.warns?.[target] || 0;
      await ctx.reply(tag(`⚠️ Warns: *${n}*`));
    }
  });

  registerCommand({
    name: 'resetwarn',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (!target) throw new ValidationError('resetwarn @user');
      await updateCollection('groups', (G) => {
        if (G.byId?.[ctx.from]?.warns) G.byId[ctx.from].warns[target] = 0;
        return G;
      }, { byId: {} });
      await ctx.reply(tag('Warns zerados.'));
    }
  });

  registerCommand({
    name: 'setregra',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('setregra <texto>');
      await updateCollection('groups', (G) => {
        if (!G.byId) G.byId = {};
        if (!G.byId[ctx.from]) G.byId[ctx.from] = { warns: {}, settings: {} };
        G.byId[ctx.from].settings.rules = ctx.q;
        return G;
      }, { byId: {} });
      await ctx.reply(tag('📜 Regras do grupo atualizadas no véu.'));
    }
  });

  registerCommand({
    name: 'regras',
    category: 'admin',
    plugin: 'admin',
    permission: Role.USER,
    cooldown: 5,
    handler: async (ctx) => {
      const G = readCollection('groups', { byId: {} });
      const rules = G.byId?.[ctx.from]?.settings?.rules || 'Nenhuma regra registrada. Admin: setregra <texto>';
      await ctx.reply(tag(`📜 *Regras*\n\n${rules}`));
    }
  });

  registerCommand({
    name: 'grupoinfo',
    category: 'admin',
    plugin: 'admin',
    permission: Role.USER,
    cooldown: 5,
    handler: async (ctx) => {
      const G = readCollection('groups', { byId: {} });
      const g = G.byId?.[ctx.from] || { settings: {}, warns: {} };
      await ctx.reply(tag(`🛡️ *Grupo no além*\n\n• Antilink: ${g.settings?.antilink ? 'on' : 'off'}\n• Warns registrados: ${Object.keys(g.warns || {}).length}\n• Regras: ${g.settings?.rules ? 'sim' : 'não'}`));
    }
  });

  registerCommand({
    name: 'antilinkcfg',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    handler: async (ctx) => {
      const on = !readCollection('groups', { byId: {} }).byId?.[ctx.from]?.settings?.antilink;
      await updateCollection('groups', (G) => {
        if (!G.byId) G.byId = {};
        if (!G.byId[ctx.from]) G.byId[ctx.from] = { warns: {}, settings: {} };
        G.byId[ctx.from].settings.antilink = on;
        return G;
      }, { byId: {} });
      await ctx.reply(tag(`Antilink (flag v2): *${on ? 'ON' : 'OFF'}*\n_O enforcement completo usa também o legado admin._`));
    }
  });

  registerCommand({
    name: 'autoban',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    handler: async (ctx) => {
      const { setGroupModeration } = await import('../../middleware/antiflood.js');
      const on = !((await import('../../database/store.js')).readCollection('groups', { byId: {} }).byId?.[ctx.from]?.settings?.autoban === false);
      // toggle
      const G = (await import('../../database/store.js')).readCollection('groups', { byId: {} });
      const cur = G.byId?.[ctx.from]?.settings?.autoban;
      const next = cur === false ? true : false;
      await setGroupModeration(ctx.from, { autoban: next, maxWarns: 3, antiflood: true });
      await ctx.reply(tag(`⛔ Auto-ban por warns: *${next ? 'ON' : 'OFF'}*\nAnti-flood v2 ativo no pipeline.`));
    }
  });

  registerCommand({
    name: 'maxwarns',
    category: 'admin',
    plugin: 'admin',
    permission: Role.GROUP_ADMIN,
    cooldown: 3,
    handler: async (ctx) => {
      const n = Math.min(10, Math.max(1, Number(ctx.q) || 3));
      const { setGroupModeration } = await import('../../middleware/antiflood.js');
      await setGroupModeration(ctx.from, { maxWarns: n });
      await ctx.reply(tag(`⚠️ Max warns: *${n}*`));
    }
  });

}

export default { register };
