import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import * as eco from '../../services/economy.js';
import { ValidationError } from '../../core/errors.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  const shop = await import('../../services/shop.js');
  const market = await import('../../services/market.js');
  const ranks = await import('../../services/rankings.js');

  registerCommand({
    name: 'saldo',
    aliases: ['balance', 'carteira', 'ghostcoins', 'gc'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const b = await eco.getBalance(ctx.sender);
      await ctx.reply(tag(`💰 *Ghostcoins*\n\n• Bolso: *${b.wallet}*\n• Banco: *${b.bank}*\n• Total: *${b.total}*`));
    }
  });

  registerCommand({
    name: 'daily',
    aliases: ['diario'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const r = await eco.daily(ctx.sender, ctx.pushname);
      await ctx.reply(tag(`🌅 *Daily*\n\n+*${r.gained}* GC\nBolso: *${r.wallet}*`));
    }
  });

  registerCommand({
    name: 'weekly',
    aliases: ['semanal'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const r = await eco.weekly(ctx.sender, ctx.pushname);
      await ctx.reply(tag(`📅 *Weekly*\n\n+*${r.gained}* GC\nBolso: *${r.wallet}*`));
    }
  });

  registerCommand({
    name: 'work',
    aliases: ['trabalhar'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const jobs = ['carregar caixões', 'organizar a fila do limbo', 'acender velas', 'carimbar almas', 'limpar o véu'];
      const r = await eco.work(ctx.sender, ctx.pushname);
      const job = jobs[Math.floor(Math.random() * jobs.length)];
      await ctx.reply(tag(`⚒️ Você foi *${job}*.\n+*${r.gained}* GC\nBolso: *${r.wallet}*`));
    }
  });

  registerCommand({
    name: 'depositar',
    aliases: ['dep'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const amount = ctx.q === 'all' || ctx.q === 'tudo' ? 'all' : ctx.q;
      if (!amount) throw new ValidationError('depositar <valor|all>');
      const e = await eco.deposit(ctx.sender, amount);
      await ctx.reply(tag(`🏦 Bolso: *${e.wallet}* | Banco: *${e.bank}*`));
    }
  });

  registerCommand({
    name: 'sacar',
    aliases: ['withdraw'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const amount = ctx.q === 'all' || ctx.q === 'tudo' ? 'all' : ctx.q;
      if (!amount) throw new ValidationError('sacar <valor|all>');
      const e = await eco.withdraw(ctx.sender, amount);
      await ctx.reply(tag(`🏦 Bolso: *${e.wallet}* | Banco: *${e.bank}*`));
    }
  });

  registerCommand({
    name: 'pix',
    aliases: ['transferir', 'pay'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const to = ctx.mentioned?.[0];
      const amount = Number(ctx.args?.find((a) => /^\d+$/.test(a)));
      if (!to || !amount) throw new ValidationError('pix @user <valor>');
      await eco.transfer(ctx.sender, to, amount, ctx.pushname, ctx.mentionName);
      await ctx.reply(tag(`💸 *${amount}* GC transferidos.`));
    }
  });

  registerCommand({
    name: 'rankgc',
    aliases: ['topgc', 'rankmoney'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const list = eco.richRanking(10);
      if (!list.length) return ctx.reply(tag('Ninguém tem GC ainda.'));
      await ctx.reply(tag(`🏆 *Top Ghostcoins*\n\n${list.map((p, i) => `${i + 1}. *${p.name}* — ${p.total} GC`).join('\n')}`));
    }
  });

  registerCommand({
    name: 'crime',
    category: 'economia',
    plugin: 'economia',
    cooldown: 30,
    handler: async (ctx) => {
      const ok = Math.random() > 0.45;
      if (ok) {
        const gain = 100 + Math.floor(Math.random() * 400);
        await eco.addWallet(ctx.sender, gain, 'crime', ctx.pushname);
        await ctx.reply(tag(`🔫 Crime deu certo. +*${gain}* GC`));
      } else {
        const loss = 50 + Math.floor(Math.random() * 200);
        try { await eco.addWallet(ctx.sender, -loss, 'crime_fail', ctx.pushname); } catch {}
        await ctx.reply(tag(`🚔 Pegaram você. -*${loss}* GC`));
      }
    }
  });

  registerCommand({
    name: 'loja',
    aliases: ['shop'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const items = shop.listShop();
      const lines = items.map((i) => `• *${i.id}* — ${i.name} — ${i.price} GC`);
      await ctx.reply(tag(`🛒 *Loja*\n\n${lines.join('\n')}\n\n×comprar <id> · ×inv`));
    }
  });

  registerCommand({
    name: 'comprar',
    aliases: ['buy'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('comprar <id>');
      const r = await shop.buy(ctx.sender, ctx.q.trim().toLowerCase(), ctx.pushname);
      await ctx.reply(tag(`🛒 *${r.item.name}* por ${r.item.price} GC.`));
    }
  });

  registerCommand({
    name: 'inv',
    aliases: ['inventario', 'inventory'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const inv = await shop.inventory(ctx.sender);
      const lines = Object.entries(inv).map(([k, v]) => { const item = shop.CATALOG[k]; const sell = item ? Math.floor(item.price * item.sellRate) : 0; return `• ${k} x${v}${sell ? ` — revenda ${sell} GC/un` : ''}`; });
      await ctx.reply(tag(`🎒 *Inventário*\n\n${lines.join('\n') || 'Vazio.'}\n\n×usaritem <id>`));
    }
  });

  registerCommand({
    name: 'venderitem',
    aliases: ['sellitem', 'vender'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const [item, qty = '1'] = (ctx.q || '').trim().split(/\s+/);
      if (!item) throw new ValidationError('venderitem <item> [quantidade|all]');
      const r = await shop.sell(ctx.sender, item.toLowerCase(), qty, ctx.pushname);
      await ctx.reply(tag(`💰 *Venda concluída*\n\n🎒 ${r.item.name} ×${r.qty}\n💵 +${r.value} GC\n💰 Bolso: ${r.wallet} GC\n📦 Restam: ${r.remaining}`));
    }
  });

  registerCommand({
    name: 'usaritem',
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('usaritem <id>');
      const r = await shop.useItem(ctx.sender, ctx.q.trim().toLowerCase(), ctx.pushname);
      await ctx.reply(tag(`✨ Usou *${r.itemId}*.${r.extra || ''}`));
    }
  });

  registerCommand({
    name: 'mercado',
    aliases: ['market'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 3,
    handler: async (ctx) => {
      const offers = await market.listOffers();
      if (!offers.length) return ctx.reply(tag('📭 Mercado vazio.\n×anunciar <item> <preço>'));
      const lines = offers.slice(0, 15).map((o) => `• *${o.id}* ${o.itemId} x${o.qty} — ${o.price}GC`);
      await ctx.reply(tag(`🏪 *Mercado P2P*\n\n${lines.join('\n')}\n\n×compraroferta <id>`));
    }
  });

  registerCommand({
    name: 'anunciar',
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const [item, price, qty] = (ctx.q || '').split(/\s+/);
      if (!item || !price) throw new ValidationError('anunciar <item> <preço> [qtd]');
      const id = await market.createOffer(ctx.sender, item, price, qty || 1, ctx.pushname);
      await ctx.reply(tag(`🏪 Oferta *${id}* criada.`));
    }
  });

  registerCommand({
    name: 'compraroferta',
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('compraroferta <id>');
      const o = await market.buyOffer(ctx.sender, ctx.q.trim(), ctx.pushname);
      await ctx.reply(tag(`🏪 Comprou *${o.itemId}* x${o.qty}.`));
    }
  });

  registerCommand({
    name: 'ranksemana',
    aliases: ['weeklyrank', 'ranksemanal'],
    category: 'economia',
    plugin: 'economia',
    cooldown: 5,
    handler: async (ctx) => {
      const cat = (ctx.args?.[0] || 'economy').toLowerCase();
      const key = cat === 'jogos' || cat === 'games' ? 'games' : 'economy';
      const top = ranks.getWeeklyTop(key, 10);
      const wk = ranks.currentWeek();
      if (!top.length) return ctx.reply(tag(`Rank semanal (${wk}) vazio.`));
      await ctx.reply(tag(`📅 *Rank ${wk}* (${key})\n\n${top.map((p, i) => `${i + 1}. *${p.name}* — ${p.points}`).join('\n')}`));
    }
  });
}

export default { register };
