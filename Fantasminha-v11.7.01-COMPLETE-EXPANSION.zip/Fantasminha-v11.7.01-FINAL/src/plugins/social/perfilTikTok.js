import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fetchTikTokProfile, downloadTikTokImage } from '../../services/social/tiktokService.js';
import { formatSocialProfile, usageMessage, notFoundMessage, errorMessage } from '../../services/social/socialProfileFormatter.js';

export async function registerPerfilTikTok() {
  registerCommand({
    name: 'perfiltiktok',
    aliases: [],
    category: 'comunidade',
    plugin: 'social',
    permission: Role.USER,
    cooldown: 5,
    timeoutMs: 20_000,
    description: 'Consulta informações públicas de um perfil do TikTok.',
    usage: '×perfiltiktok <usuario>',
    examples: ['×perfiltiktok mrbeast', '×perfiltiktok @mrbeast'],
    handler: async ctx => {
      const raw = String(ctx.q || ctx.args?.[0] || '').trim();
      if (!raw) return ctx.reply(usageMessage('tiktok', ctx.prefix || '×'));
      const data = await fetchTikTokProfile(raw);
      if (data.status === 'invalid') return ctx.reply(usageMessage('tiktok', ctx.prefix || '×'));
      if (data.status === 'not_found') return ctx.reply(notFoundMessage);
      if (data.status !== 'ok') return ctx.reply(errorMessage);

      const caption = formatSocialProfile(data, `${ctx.prefix || '×'}perfiltiktok`);
      const image = await downloadTikTokImage(data.avatarUrl);
      if (image && typeof ctx.sendMessage === 'function') {
        try {
          await ctx.sendMessage(ctx.from, { image, caption });
          return;
        } catch {}
      }
      return ctx.reply(caption);
    }
  });
}
export default { registerPerfilTikTok };
