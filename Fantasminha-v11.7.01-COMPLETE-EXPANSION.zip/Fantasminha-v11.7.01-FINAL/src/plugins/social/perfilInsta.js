import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fetchInstagramProfile, downloadInstagramImage } from '../../services/social/instagramService.js';
import { formatSocialProfile, usageMessage, notFoundMessage, errorMessage } from '../../services/social/socialProfileFormatter.js';

export async function registerPerfilInstagram() {
  registerCommand({
    name: 'perfilinsta',
    aliases: [],
    category: 'comunidade',
    plugin: 'social',
    permission: Role.USER,
    cooldown: 5,
    timeoutMs: 20_000,
    description: 'Consulta informações públicas de um perfil do Instagram.',
    usage: '×perfilinsta <usuario>',
    examples: ['×perfilinsta cristiano', '×perfilinsta @cristiano'],
    handler: async ctx => {
      const raw = String(ctx.q || ctx.args?.[0] || '').trim();
      if (!raw) return ctx.reply(usageMessage('instagram', ctx.prefix || '×'));
      const data = await fetchInstagramProfile(raw);
      if (data.status === 'invalid') return ctx.reply(usageMessage('instagram', ctx.prefix || '×'));
      if (data.status === 'not_found') return ctx.reply(notFoundMessage);
      if (data.status !== 'ok') return ctx.reply(errorMessage);

      const caption = formatSocialProfile(data, `${ctx.prefix || '×'}perfilinsta`);
      const image = await downloadInstagramImage(data.avatarUrl);
      if (image && typeof ctx.sendMessage === 'function') {
        try {
          await ctx.sendMessage(ctx.from, { image, caption });
          return;
        } catch {}
      }
      return ctx.reply(caption);
    }
  });
}
export default { registerPerfilInstagram };
