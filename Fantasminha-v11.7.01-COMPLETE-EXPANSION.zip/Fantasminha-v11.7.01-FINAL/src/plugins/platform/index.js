import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fantasminhaId } from '../../platform/identity/index.js';
import { getPersonal, updatePersonal, setCustom, isVip } from '../../platform/personal/index.js';

const tag = s => `👻 *FANTASMINHA 10.3.0*\n\n${s}`;

/**
 * Comandos exclusivos da camada Platform.
 * Diagnóstico, snapshots, auditoria e migrações ficam no Owner Power,
 * evitando duas fontes de verdade para a mesma operação.
 */
export async function register() {
  const defs = [
    { name:'fantasminhaid', aliases:['fid','meuid'], category:'personal', permission:Role.USER, cooldown:3,
      handler: async ctx => ctx.reply(tag(`🪪 *Fantasminha ID*\n\n${fantasminhaId(ctx.sender)}`)) },
    { name:'personal', aliases:['fpersonal','personalizar'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:3,
      handler: async ctx => { const p=getPersonal(ctx.sender); return ctx.reply(tag(`⚙️ *Fantasminha Personal*\n\nIdioma: ${p.language}\nTema: ${p.theme}\nEstilo: ${p.responseStyle}\nNotificações: ${p.notifications?'ON':'OFF'}\nPlano: ${isVip(ctx.sender)?'💎 VIP':'🆓 FREE'}`)); } },
    { name:'preferencia', aliases:['pref'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:2,
      handler: async ctx => { const [k,...rest]=ctx.args||[]; if(!k) return ctx.reply(tag('Use: ×preferencia chave valor')); const value=rest.join(' '); const p=await updatePersonal(ctx.sender,{[k]:value},{actor:ctx.sender,requestId:ctx.requestId}); return ctx.reply(tag(`⚙️ ${k} = ${p[k]}`)); } },
    { name:'personaltema', aliases:['tema'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:3,
      handler: async ctx => { const theme=ctx.args?.[0]; if(!theme) return ctx.reply(tag('Temas: limbo, cosmos, neon, minimal')); const allowed=['limbo','cosmos','neon','minimal']; if(!allowed.includes(theme)) return ctx.reply(tag('Tema inválido.')); await updatePersonal(ctx.sender,{theme},{actor:ctx.sender}); return ctx.reply(tag(`🎨 Tema pessoal: *${theme}*`)); } },
    { name:'personalcustom', aliases:['customizar'], category:'personal', permission:Role.VIP, privateOnly:true, cooldown:3,
      handler: async ctx => { const [key,...rest]=ctx.args||[]; if(!key||!rest.length) return ctx.reply(tag('Uso VIP: ×personalcustom chave valor')); await setCustom(ctx.sender,key,rest.join(' '),{premium:true,actor:ctx.sender}); return ctx.reply(tag(`💎 Personalização salva: *${key}*`)); } },
    { name:'buscarcomando', aliases:['buscarcmd','findcmd'], category:'sistema', permission:Role.USER, cooldown:2,
      handler: async ctx => { const q=String(ctx.q||'').toLowerCase().trim(); if(!q) return ctx.reply(tag('Use: ×buscarcomando termo')); const {listCommands}=await import('../../core/registry.js'); const hits=listCommands().filter(c=>[c.name,c.description,c.category,...c.aliases].join(' ').toLowerCase().includes(q)).slice(0,12); return ctx.reply(tag(hits.length?`🔎 *Resultados:* ${q}\n\n${hits.map(c=>`• ${c.name}${c.description?` — ${c.description}`:''}`).join('\n')}`:'Nenhum comando encontrado.')); } }
  ];
  for (const def of defs) registerCommand({ ...def, plugin:'platform', version:'6.0.0' });
}
export default { register };
