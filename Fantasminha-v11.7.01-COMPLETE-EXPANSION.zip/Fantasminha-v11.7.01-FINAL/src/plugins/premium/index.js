import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { getUser, upsertUser, readCollection } from '../../database/store.js';
import { ValidationError } from '../../core/errors.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCommand({
    name: 'vip',
    aliases: ['premium', 'meuvip'],
    category: 'premium',
    plugin: 'premium',
    cooldown: 3,
    handler: async (ctx) => {
      const u = getUser(ctx.sender);
      const p = u?.premium || { active: false };
      const active = p.active && (!p.until || p.until > Date.now());
      const { vipSummary } = await import('../../services/vipBenefits.js');
      const s = vipSummary(ctx.sender);
      await ctx.reply(tag(
        active
          ? `💎 *Premium ativo*\nPlano: *${p.plan || 'custom'}*\nAté: *${p.until ? new Date(p.until).toLocaleDateString('pt-BR') : '∞'}*\nCooldown ×${s.cooldownMult}\nDaily bônus +${s.dailyBonus} GC\nLimites maiores de download/IA`
          : `💎 Sem premium (free).\naddvip @user <dias> [bronze|prata|ouro]`
      ));
    }
  });

  registerCommand({
    name: 'addvip',
    category: 'premium',
    plugin: 'premium',
    permission: Role.OWNER,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      const days = Number(ctx.args?.find((a) => /^\d+$/.test(a))) || 30;
      const plan = ctx.args?.find((a) => /bronze|prata|ouro/i.test(a)) || 'prata';
      if (!target) throw new ValidationError('addvip @user <dias> [plano]');
      const until = Date.now() + days * 86400000;
      await upsertUser(target, { premium: { active: true, until, plan } });
      await ctx.reply(tag(`💎 VIP *${plan}* por *${days}* dias.`));
    }
  });

  registerCommand({
    name: 'delvip',
    category: 'premium',
    plugin: 'premium',
    permission: Role.OWNER,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (!target) throw new ValidationError('delvip @user');
      await upsertUser(target, { premium: { active: false, until: 0, plan: null } });
      await ctx.reply(tag('💎 Premium removido.'));
    }
  });

  registerCommand({
    name: 'planosvip',
    category: 'premium',
    plugin: 'premium',
    cooldown: 5,
    handler: async (ctx) => {
      const plans = readCollection('premium_plans', {});
      const lines = Object.entries(plans).map(([k, v]) => `• *${k}* — ${v.days}d`);
      await ctx.reply(tag(`💎 *Planos*\n\n${lines.join('\n') || 'Nenhum'}`));
    }
  });
}

export default { register };
