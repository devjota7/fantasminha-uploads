/**
 * Plugin: Além — tema Fantasminha
 */
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../../..');

let extra = null;
async function getExtra() {
  if (extra) return extra;
  try {
    extra = await import(path.join(ROOT, 'dados/src/funcs/utils/fantasminhaExtra.js'));
    return extra;
  } catch (e) {
    extra = {};
    return extra;
  }
}

function replyText(ctx, text) {
  return ctx.reply(typeof text === 'string' ? `× 👻 FANTASMINHA\n\n${text}` : text);
}

export async function register() {
  const fx = await getExtra();

  const simple = [
    ['statusalem', () => fx.statusAlem?.()],
    ['frasealem', () => fx.fraseAlem?.()],
    ['oraculo', () => fx.oraculo?.()],
    ['veu', () => fx.veuMsg?.()],
    ['purgatorio', () => fx.purgatorioMsg?.()],
    ['submundo', () => fx.submundoMsg?.()],
    ['cemiterio', () => fx.cemiterioMsg?.()],
    ['destino', () => fx.destinoMsg?.()],
    ['pecado', () => fx.pecadoMsg?.()],
    ['virtude', () => fx.virtudeMsg?.()],
    ['horarioveu', () => fx.horarioVeu?.()],
    ['verdadealem', () => fx.verdadeAlem?.()],
    ['desafioalem', () => fx.desafioAlem?.()],
    ['conselhoalem', () => fx.conselhoAlem?.()],
    ['diarioalem', () => fx.diarioAlem?.()],
    ['topalmas', () => fx.topAlmasFake?.()],
    ['perfilalem', (ctx) => fx.perfilAlem?.(ctx.pushname)],
    ['eco', (ctx) => fx.ecoMsg?.(ctx.q)],
    ['alma', (ctx) => fx.almaMsg?.(ctx.q || ctx.pushname)],
    ['julgamento', (ctx) => fx.julgamentoMsg?.(ctx.q || ctx.pushname)],
    ['sombra', (ctx) => fx.sombraMsg?.(ctx.q || ctx.pushname)],
    ['karma', (ctx) => fx.karmaMsg?.(ctx.q || ctx.pushname)],
    ['shipalem', (ctx) => fx.shipAlem?.(ctx.args?.[0], ctx.args?.[1] || ctx.pushname)],
    ['percentualalma', (ctx) => fx.percentualAlma?.(ctx.q || ctx.pushname)],
    ['contagemalmas', (ctx) => fx.contagemAlmas?.(ctx.participantCount || 0)]
  ];

  for (const [name, fn] of simple) {
    registerCommand({
      name,
      category: 'alem',
      plugin: 'alem',
      permission: Role.USER,
      cooldown: 2,
      description: `Comando do além: ${name}`,
      handler: async (ctx) => {
        const text = typeof fn === 'function' ? await fn(ctx) : fn;
        if (text) await replyText(ctx, text);
      }
    });
  }
}

export default { register };
