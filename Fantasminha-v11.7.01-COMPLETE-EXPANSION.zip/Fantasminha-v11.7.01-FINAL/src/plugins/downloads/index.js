import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { downloadMedia, searchYoutube, probeUrl } from '../../services/download.js';
import { ValidationError } from '../../core/errors.js';
import { canUseVipBenefit } from '../../services/vipBenefits.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCommand({
    name: 'play',
    aliases: ['yt', 'ytmp3'],
    category: 'downloads',
    plugin: 'downloads',
    cooldown: 8,
    description: 'Busca e info YouTube (via DownloadService)',
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('play <nome da música>');
      const limit = await canUseVipBenefit(ctx.sender, 'download');
      if (!limit.ok) throw new ValidationError(limit.msg);
      await ctx.reply(tag('🔎 Buscando no véu…'));
      const r = await searchYoutube(ctx.q);
      if (!r?.ok) throw new ValidationError(r?.msg || 'Nada encontrado.');
      const d = r.data;
      await ctx.reply(tag(
        `🎵 *${d.title}*\n👤 ${d.author || '?'}\n⏱ ${d.timestamp || d.seconds || '?'}\n🔗 ${d.url}\n\nBaixar áudio legado: use o menu *down* / comandos yt do bot.\n_Service: OK (${d.videoId || 'id'})_`
      ));
    }
  });

  registerCommand({
    name: 'dl',
    aliases: ['download', 'baixar'],
    category: 'downloads',
    plugin: 'downloads',
    cooldown: 10,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('dl <url>');
      const limit = await canUseVipBenefit(ctx.sender, 'download');
      if (!limit.ok) throw new ValidationError(limit.msg);
      await ctx.reply(tag('📥 Processando via DownloadService…'));
      const r = await downloadMedia({ url: ctx.q.trim(), type: 'auto' });
      if (!r.ok) throw new ValidationError(r.message || 'Falha no download.');
      await ctx.reply(tag(
        `✅ *${r.provider}* OK (${r.ms}ms)\n${r.title ? `📌 ${r.title}\n` : ''}${r.url ? `🔗 ${r.url}\n` : ''}_Se o arquivo não anexar aqui, o buffer fica no módulo legado — use também play/tiktok do menu._`
      ));
    }
  });

  registerCommand({
    name: 'probeurl',
    category: 'downloads',
    plugin: 'downloads',
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('probeurl <url>');
      const p = await probeUrl(ctx.q);
      await ctx.reply(tag(`🔬 Provider: *${p.provider}*\nStatus: ${p.status || p.error}\nTipo: ${p.contentType || '?'}\nSize: ${p.size || 0}`));
    }
  });
}

export default { register };
