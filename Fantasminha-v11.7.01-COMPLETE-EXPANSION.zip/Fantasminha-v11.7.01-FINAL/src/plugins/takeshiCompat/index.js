import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { downloadMedia } from '../../services/download.js';
import { ttp } from '../../services/spider-x-api.js';
import { getUser, upsertUser } from '../../database/store.js';
import { addBestFriend, removeBestFriend, listBestFriends } from '../../services/social.js';
import config from '../../core/config.js';

const tag = text => `╭━━⪩ 👻 FANTASMINHA ⪨━━╮\n${text}\n╰━━━━━━━━━━━━━━━━━━━━╯`;
const urlArg = ctx => String(ctx.q || '').trim();
const target = ctx => ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || null;

export async function register() {
  registerCommand({ name:'to-mp3', aliases:['video2mp3','mp3'], category:'downloads', plugin:'takeshiCompat', permission:Role.USER, cooldown:8, description:'Converte um vídeo em áudio MP3.', usage:'×to-mp3 (responda ou anexe um vídeo)', handler:async ctx=>{
    if (!ctx.media?.isVideo && !ctx.message?.message?.videoMessage) throw new ValidationError('Por favor, envie este comando em resposta a um vídeo ou com um vídeo anexado.');
    await ctx.sendWaitReact();
    const file = await ctx.downloadVideo(ctx.message);
    const output = await ctx.extractAudioToMp3(file);
    try { await ctx.sendSuccessReact(); await ctx.sendAudioFromFile(output); } finally { await ctx.cleanupTemp(file); await ctx.cleanupTemp(output); }
  }});

  registerCommand({ name:'ttp', category:'media', plugin:'takeshiCompat', permission:Role.USER, cooldown:5, description:'Faz figurinhas de texto.', usage:'×ttp teste', handler:async ctx=>{
    const text = String(ctx.q || '').trim();
    if (!text) throw new ValidationError('Você precisa informar o texto que deseja transformar em figurinha.');
    await ctx.sendWaitReact();
    const url = await ttp(text);
    const response = await fetch(url, { signal: AbortSignal.timeout(20000) });
    if (!response.ok) throw new ValidationError(`A Spider X API recusou a figurinha (HTTP ${response.status}).`);
    await ctx.sendSuccessReact();
    await ctx.sendStickerFromURL(url);
  }});

  for (const [name, aliases, provider, label] of [
    ['instagram',['ig','inst','insta'],'instagram','Instagram'],
    ['tik-tok',['ttk','tik'],'tiktok','TikTok']
  ]) registerCommand({ name, aliases, category:'downloads', plugin:'takeshiCompat', permission:Role.USER, cooldown:10, description:`Faço o download de vídeos do ${label}.`, usage:`×${name} URL`, handler:async ctx=>{
    const url = urlArg(ctx);
    if (!url) throw new ValidationError(`Você precisa enviar uma URL do ${label}!`);
    const lower = url.toLowerCase();
    const valid = provider === 'instagram' ? /instagram\.com|instagr\.am/.test(lower) : /tiktok\.com|vt\.tiktok\.com/.test(lower);
    if (!valid) throw new ValidationError(`O link não é do ${label}!`);
    await ctx.sendWaitReact();
    const result = await downloadMedia({ url, type:'video' });
    const videoUrl = result?.url || result?.data?.download_link || result?.data?.url || result?.data?.video?.url;
    if (!result?.ok || !videoUrl) throw new ValidationError(result?.message || 'Nenhum resultado encontrado!');
    await ctx.sendSuccessReact();
    await ctx.sendVideoFromURL(videoUrl);
  }});

  registerCommand({ name:'meubest', aliases:['meubf','best'], category:'perfil', plugin:'takeshiCompat', permission:Role.USER, cooldown:3, description:'Mostra seus vínculos de Best Friend.', usage:'×meubest', handler:async ctx=>{
    const list = listBestFriends(ctx.sender);
    if (!list.length) return ctx.reply(tag('🫂 *MEUS BEST FRIENDS*\n\nVocê ainda não tem Best Friend registrado.'));
    const lines = list.map((id,i)=>`${i+1}. 🫂 @${String(id).split('@')[0]}`);
    return ctx.reply(tag(`🫂 *MEUS BEST FRIENDS*\n\n${lines.join('\n')}\n\n✨ Limite: 3 vínculos.`), { mentions:list });
  }});

  return true;
}
export default { register };
