import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection } from '../../database/store.js';
import { ValidationError } from '../../core/errors.js';
import config from '../../core/config.js';
import * as eco from '../../services/economy.js';
import * as global from '../../services/globalClans.js';
import * as groups from '../../services/groupClans.js';
import * as wars from '../../services/wars.js';
import * as clanWorld from '../../services/clanWorld.js';

const tag = (t) => `× 👻 FANTASMINHA\n\n${t}`;
const clean = (v) => String(v || '').trim();

async function ensureGroup(ctx) {
  if (!ctx.isGroup || !ctx.from) throw new ValidationError('Este comando precisa ser usado em um grupo.');
  await groups.ensureGroupClan(ctx.from, ctx.groupName || 'Grupo', ctx.participantCount || 0);
  return groups.getGroupClan(ctx.from);
}

function currentGlobal(userId) { return global.getGlobalClanOf(userId); }
function currentGroup(groupId) { return groups.getGroupClan(groupId); }

function activeWarForSide(type, sideId) {
  return wars.listWars(type).find(w => ['pending','preparation','active'].includes(w.status) && (w.attackerId === sideId || w.defenderId === sideId)) || null;
}

async function sendToGroup(ctx, jid, text) {
  if (typeof ctx.sendMessage !== 'function') return false;
  try { await ctx.sendMessage(jid, { text }); return true; } catch { return false; }
}

function adminOnly(ctx) {
  if (!ctx.isGroup || !ctx.isGroupAdmin) throw new ValidationError('Somente administradores do grupo podem administrar o Clã do Grupo.');
}

export async function register() {
  const enabled = () => config.features.clans !== false;

  // ===== CLÃ PESSOAL DO JOGADOR + CAMADA GLOBAL =====
  registerCommand({ name:'clacriar', aliases:['criarcla'], category:'clans', plugin:'clans', cooldown:10,
    usage:'clacriar <nome>', handler:async ctx => {
      if (!enabled()) throw new ValidationError('FEATURE_CLANS está desativado.');
      const c = await global.createGlobalClan(ctx.sender, ctx.q, { visibility:'private' });
      const clan = c.byId[c.byMember[ctx.sender]];
      await ctx.reply(tag(`🏰 *CLÃ CRIADO!*\n\n🏷️ ${clan.name}\n👑 Líder: ${ctx.pushname || ctx.sender}\n👥 Membros: 1\n🔒 Visibilidade: PRIVADO\n\nTorne-o público com:\n×clapublico`));
    }});

  registerCommand({ name:'clapublico', aliases:['tornarpublicocla','clapublicar'], category:'clans', plugin:'clans', cooldown:10,
    usage:'clapublico', handler:async ctx => {
      const c=currentGlobal(ctx.sender); if(!c) throw new ValidationError('Crie um Clã primeiro.');
      if(c.visibility==='public') return ctx.reply(tag('🌐 Seu Clã já é público.'));
      const cost=global.costs.publicCreation;
      const wallet=eco.getEcoUser(ctx.sender)?.wallet||0;
      if(wallet<cost) throw new ValidationError(`Tornar o Clã público custa ${cost.toLocaleString('pt-BR')} GC. Você possui ${wallet.toLocaleString('pt-BR')}.`);
      await eco.addWallet(ctx.sender,-cost,'clan_public_creation',ctx.pushname);
      await global.makePublic(ctx.sender);
      await ctx.reply(tag(`🌐 *CLÃ AGORA É PÚBLICO!*

🏰 ${c.name}
💰 Custo: ${cost.toLocaleString('pt-BR')} GC
👥 Limite: 100 membros
🌎 Agora pode receber solicitações.

O status Global continua dependendo da autorização do administrador.`));
    }});

  registerCommand({ name:'clainfo', aliases:['meucla','clastatus'], category:'clans', plugin:'clans', cooldown:3,
    handler:async ctx => {
      const c=currentGlobal(ctx.sender); if(!c) return ctx.reply(tag('🏰 Você ainda não possui Clã.\n\n×clacriar <nome>'));
      const war=activeWarForSide('global',c.id);
      await ctx.reply(tag(`🏰 *CLÃ — ${c.name}*\n\n👑 Líder: ${c.leader===ctx.sender?(ctx.pushname||'Você'):c.leader}\n👥 Membros: ${c.members.length}\n⭐ Nível: ${c.level}\n⚡ Poder: ${c.power||100}\n💰 Tesouro: ${c.bank||0} GC\n🌐 Visibilidade: ${(c.visibility||'private').toUpperCase()}\n${c.globalAuthorized?'🟢 Global: AUTORIZADO':'⚪ Global: não autorizado'}\n⚔️ V/D: ${c.wins||0}/${c.losses||0}\n${war?`⚔️ Guerra: ${war.attackerId===c.id?war.defenderName:war.attackerName} — ${war.status}`:'🕊️ Sem guerra ativa'}`));
    }});

  registerCommand({ name:'clabuscar', aliases:['clapublicos','listarcla'], category:'clans', plugin:'clans', cooldown:5,
    handler:async ctx=>{const q=clean(ctx.q);if(q){const c=global.getClanByName(q);if(!c)return ctx.reply(tag('🏰 Clã não encontrado.'));return ctx.reply(tag(`🏰 *${c.name}*\n👥 ${c.members.length}/100\n⭐ Nv.${c.level}\n🌐 ${c.visibility==='public'?'PÚBLICO':'PRIVADO'}\n${c.globalAuthorized?'🟢 GLOBAL AUTORIZADO':'⚪ GLOBAL NÃO AUTORIZADO'}\n\n${c.visibility==='public'?'×claentrar '+c.id:'Convite necessário.'}`));}const list=global.listPublicClans(15);return ctx.reply(tag(`🌐 *CLÃS PÚBLICOS*\n\n${list.length?list.map((c,i)=>`${i+1}. 🏰 *${c.name}* — ${c.members.length}/100 · Nv.${c.level} ${c.globalAuthorized?'🟢':''}`).join('\n'):'Nenhum Clã público ainda.'}`));}});

  registerCommand({ name:'claentrar', aliases:['entrarcla'], category:'clans', plugin:'clans', cooldown:5,
    usage:'claentrar <nome/id>', handler:async ctx=>{const c=await global.joinGlobalClan(ctx.sender,ctx.q);await ctx.reply(tag(`📨 Solicitação enviada para *${c.name}*.\n\nO líder/vice precisa aprovar sua entrada.`));}});
  registerCommand({ name:'claaprovar', aliases:['aprovarcla'], category:'clans', plugin:'clans', cooldown:5,
    usage:'claaprovar <@usuario>', handler:async ctx=>{const me=currentGlobal(ctx.sender);if(!me)throw new ValidationError('Você não possui Clã.');const u=ctx.mentionedJid?.[0]||ctx.mentioned?.[0]||clean(ctx.q).split(/\s+/)[0];if(!u)throw new ValidationError('Mencione o usuário.');await global.approveJoin(ctx.sender,me.id,u);await ctx.reply(tag(`✅ ${u} foi aceito no Clã *${me.name}*.`));}});
  registerCommand({ name:'claconvidar', aliases:['convidarcla'], category:'clans', plugin:'clans', cooldown:5,
    usage:'claconvidar <@usuario>', handler:async ctx=>{const u=ctx.mentionedJid?.[0]||ctx.mentioned?.[0]||clean(ctx.q).split(/\s+/)[0];if(!u)throw new ValidationError('Mencione o usuário.');const c=await global.invite(ctx.sender,u);const me=currentGlobal(ctx.sender);await ctx.reply(tag(`📨 Convite enviado para ${u} para entrar em *${me.name}*.\n🆔 Clã: ${me.id}\nUse ×claaceitar ${me.id}`));}});
  registerCommand({ name:'claaceitar', aliases:['aceitarcla'], category:'clans', plugin:'clans', cooldown:5,
    usage:'claaceitar <id_cla>', handler:async ctx=>{const id=clean(ctx.q).split(/\s+/)[0];if(!id)throw new ValidationError('Informe o ID do Clã.');await global.acceptInvite(ctx.sender,id);const c=currentGlobal(ctx.sender);await ctx.reply(tag(`🤝 Você entrou no Clã *${c.name}*.`));}});
  registerCommand({ name:'clapendencias', aliases:['clarequests'], category:'clans', plugin:'clans', cooldown:3,
    handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã.');const r=global.listJoinRequests(c.id);await ctx.reply(tag(`📨 *SOLICITAÇÕES — ${c.name}*\n\n${r.length?r.map((x,i)=>`${i+1}. ${x.userId} — ${new Date(x.at).toLocaleString('pt-BR')}`).join('\n'):'Nenhuma solicitação pendente.'}`));}});
  registerCommand({ name:'clasair', aliases:['saircla'], category:'clans', plugin:'clans', cooldown:5,
    handler:async ctx=>{await global.leaveGlobalClan(ctx.sender);await ctx.reply(tag('🏰 Você saiu do Clã.'));}});
  registerCommand({ name:'cladissolver', aliases:['dissolvercla'], category:'clans', plugin:'clans', cooldown:10,
    handler:async ctx=>{await global.dissolveGlobalClan(ctx.sender);await ctx.reply(tag('💀 Seu Clã foi dissolvido.'));}});
  registerCommand({ name:'clavice', aliases:['nomearvice'], category:'clans', plugin:'clans', cooldown:5,
    usage:'clavice <@usuario>', handler:async ctx=>{const u=ctx.mentionedJid?.[0]||ctx.mentioned?.[0]||clean(ctx.q).split(/\s+/)[0];if(!u)throw new ValidationError('Mencione o membro.');await global.setVice(ctx.sender,u);await ctx.reply(tag(`👑 ${u} agora é vice-líder do Clã.`));}});
  registerCommand({ name:'clanrank', aliases:['clarank','rankcla'], category:'clans', plugin:'clans', cooldown:5,
    handler:async ctx=>{const list=global.listGlobalClans(20);await ctx.reply(tag(`🌐 *RANKING DOS CLÃS GLOBAIS*\n\n${list.length?list.map((c,i)=>`${i<3?['🥇','🥈','🥉'][i]:`${i+1}.`} *${c.name}* — Nv.${c.level} · ⚡${c.power} · ${c.wins||0}V/${c.losses||0}D`).join('\n'):'Nenhum Clã Global autorizado ainda.'}`));}});

  // Autorização é administrativa e separada da criação do Clã.
  registerCommand({ name:'claautorizar', aliases:['autorizarcla','claglobalautorizar'], category:'owner', plugin:'clans', permission:Role.BOT_ADMIN, cooldown:3,
    usage:'claautorizar <id_cla>', handler:async ctx=>{const id=clean(ctx.q).split(/\s+/)[0];if(!id)throw new ValidationError('Informe o ID do Clã.');const c=await global.authorizeGlobal(ctx.sender,id);await ctx.reply(tag(`🟢 *CLÃ AUTORIZADO NO ECOSSISTEMA GLOBAL*\n\n🏰 ${c.byId[id].name}\n🌐 Status: AUTORIZADO\n🏆 Agora participa do ranking, campeonato e eventos globais.`));}});
  registerCommand({ name:'clarevogar', aliases:['revogarcla'], category:'owner', plugin:'clans', permission:Role.BOT_ADMIN, cooldown:3,
    usage:'clarevogar <id_cla> [motivo]', handler:async ctx=>{const [id,...reason]=clean(ctx.q).split(/\s+/);if(!id)throw new ValidationError('Informe o ID do Clã.');const c=await global.revokeGlobal(ctx.sender,id,reason.join(' '));await ctx.reply(tag(`🟡 Autorização Global revogada para *${c.byId[id].name}*.\nMotivo: ${reason.join(' ')||'não informado'}`));}});
  registerCommand({ name:'claglobal', aliases:['statusglobalcla'], category:'clans', plugin:'clans', cooldown:3,
    handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)return ctx.reply(tag('Você ainda não possui Clã.'));await ctx.reply(tag(`🌐 *STATUS GLOBAL*\n\n🏰 ${c.name}\n🌐 Visibilidade: ${(c.visibility||'private').toUpperCase()}\n🛡️ Autorização: ${c.globalAuthorized?'🟢 AUTORIZADO':'⚪ NÃO AUTORIZADO'}\n${c.globalAuthorized?'🏆 Participa do ecossistema global.':'📜 Torne o Clã público e aguarde autorização administrativa.'}`));}});
  registerCommand({ name:'claaudit', aliases:['clahistoricoaudit'], category:'clans', plugin:'clans', cooldown:5,
    handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã.');const rows=global.listAudit(50).filter(x=>x.clanId===c.id).slice(0,15);await ctx.reply(tag(`📜 *AUDITORIA DO CLÃ*\n\n${rows.map(x=>`• ${new Date(x.at).toLocaleString('pt-BR')} — ${x.action}`).join('\n')||'Sem eventos registrados.'}`));}});

  registerCommand({ name:'clagrupomenu', aliases:['menugrupocla'], category:'group-clan', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => await ctx.reply(tag(`👥 *MENU DO CLÃ DO GRUPO*\n\n×clagrupo — informações\n×guerragrupo listar — adversários\n×guerragrupo status — guerra atual\n×guerragrupoentrar — participar\n×guerragrupoataque [tipo] — atacar\n×guerragrupodefesa — defender\n×guerragrupomembros — participantes\n×guerragrupohistorico — histórico\n\n👑 ADM: ×clagrupoguerra on/off | ×guerragrupo desafiar | aceitar | recusar`)) });

  registerCommand({ name:'clagruporank', aliases:['rankgrupocla'], category:'group-clan', plugin:'clans', groupOnly:true, cooldown:5,
    handler:async ctx => { await ensureGroup(ctx); const list=Object.values(readCollection('group_clans',{byId:{}}).byId||{}).sort((a,b)=>(b.xp||0)-(a.xp||0)).slice(0,10); await ctx.reply(tag(`🏆 *RANKING DOS CLÃS DE GRUPO*\n\n${list.map((c,i)=>`${i+1}. 🏰 ${c.name} — Nv.${c.level} | ⚡${c.power} | ${c.wins||0}V/${c.losses||0}D`).join('\n')||'Nenhum grupo registrado.'}`)); }
  });

  registerCommand({ name:'guerragrupoplacar', aliases:['placarguerra'], category:'wars', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra ativa.'); await ctx.reply(tag(`🏆 *PLACAR DA GUERRA*\n\n🏰 ${w.attackerName}\n⚔️ ${w.score.attacker} pontos\n\n🏰 ${w.defenderName}\n🛡️ ${w.score.defender} pontos\n\n👥 ${w.participants.attacker.length} × ${w.participants.defender.length} participantes\n⏳ ${w.durationDays} dia(s) | ${w.status}`)); }
  });

  registerCommand({ name:'guerragrupodefesa', aliases:['guerradefesa','defesaguerra'], category:'wars', plugin:'clans', groupOnly:true, cooldown:10,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra ativa.'); const side=w.attackerId===c.id?'attacker':'defender'; await wars.defend(w.id,side,ctx.sender); const u=wars.getWar(w.id); const enemyId=side==='attacker'?u.defenderId:u.attackerId; await sendToGroup(ctx,enemyId,`🛡️ 👻 DEFESA ATIVADA!\n\n${c.name} fortaleceu sua posição na guerra.`); await ctx.reply(tag(`🛡️ *DEFESA CONCLUÍDA!*\n\n+ pontos para ${c.name}.\n🏆 ${u.score.attacker} × ${u.score.defender}`)); }
  });

  registerCommand({ name:'guerragrupoataques', aliases:['historicoataques'], category:'wars', plugin:'clans', groupOnly:true, cooldown:5,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra ativa.'); const side=w.attackerId===c.id?'attacker':'defender'; const list=(w.attacks||[]).filter(a=>a.side===side).slice(-15).reverse(); await ctx.reply(tag(`⚔️ *SEUS ÚLTIMOS ATAQUES*\n\n${list.map(a=>`• ${a.kind} +${a.points} — ${new Date(a.at).toLocaleTimeString('pt-BR')}`).join('\n')||'Nenhum ataque ainda.'}`)); }
  });

  registerCommand({ name:'guerragrupomvp', aliases:['mvpguerra'], category:'wars', plugin:'clans', groupOnly:true, cooldown:5,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra ativa.'); const all=[...(w.attacks||[]).map(a=>({...a,kind:'ataque'})),...(w.defenses||[]).map(a=>({...a,kind:'defesa'}))].sort((a,b)=>b.points-a.points).slice(0,5); await ctx.reply(tag(`👑 *MVP DA GUERRA*\n\n${all.map((a,i)=>`${i+1}. ${a.userId} — ${a.kind} +${a.points}`).join('\n')||'Ainda não há ações registradas.'}`)); }
  });

  // ===== CLÃ DO GRUPO =====
  registerCommand({ name:'clagrupo', aliases:['grupocla','clacomunidade'], category:'group-clan', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => {
      const c=await ensureGroup(ctx); const war=activeWarForSide('group',c.id);
      await ctx.reply(tag(`👥 *CLÃ DO GRUPO*\n\n🏰 ${c.name}\n👥 Membros do grupo: ${c.participantCount}\n⭐ Nível: ${c.level}\n⚡ Poder: ${c.power}\n🏆 V/D: ${c.wins||0}/${c.losses||0}\n⚔️ Guerras: ${c.warEnabled?'🟢 ATIVADAS':'🔴 DESATIVADAS'}\n${war?`🔥 Guerra: ${war.attackerId===c.id?war.defenderName:war.attackerName} — ${war.status}`:'🕊️ Sem guerra ativa'}\n\nSomente ADM controla a participação em guerras.`));
    }});

  registerCommand({ name:'clagrupoadmin', aliases:['clanoadm'], category:'group-clan', plugin:'clans', groupOnly:true, permission:Role.GROUP_ADMIN, cooldown:3,
    handler:async ctx => { adminOnly(ctx); const c=await ensureGroup(ctx); await ctx.reply(tag(`👑 *PAINEL DO CLÃ DO GRUPO*\n\n🏰 ${c.name}\n⚔️ Guerras: ${c.warEnabled?'🟢 ATIVADAS':'🔴 DESATIVADAS'}\n\nComandos:\n• ×clagrupoguerra on/off\n• ×guerragrupo listar\n• ×guerragrupo desafiar <nome|id> [1-5]\n• ×guerragrupo aceitar\n• ×guerragrupo recusar\n• ×guerragrupo status\n• ×guerragrupomembros`)); }
  });

  registerCommand({ name:'clagrupoguerra', aliases:['participarguerra','guerraonoff'], category:'group-clan', plugin:'clans', groupOnly:true, permission:Role.GROUP_ADMIN, cooldown:5,
    usage:'clagrupoguerra <on|off>', handler:async ctx => { adminOnly(ctx); const c=await ensureGroup(ctx); const value=clean(ctx.q).toLowerCase(); if(!['on','off'].includes(value)) throw new ValidationError('Use ×clagrupoguerra on ou off.'); await groups.setGroupWarEnabled(c.id,value==='on',c.name,c.participantCount); await ctx.reply(tag(`${value==='on'?'⚔️ *GUERRAS ATIVADAS!*':'🛡️ *MODO PACÍFICO ATIVADO!*'}\n\n🏰 ${c.name}\n${value==='on'?'Este grupo agora pode desafiar e receber guerras.':'Novos desafios estão bloqueados; o RPG continua normalmente.'}`)); }
  });

  registerCommand({ name:'guerragrupo', aliases:['gguerra','guerra_clan'], category:'wars', plugin:'clans', groupOnly:true, cooldown:10,
    usage:'guerragrupo <listar|desafiar|aceitar|recusar|status> ...', handler:async ctx => {
      const me=await ensureGroup(ctx); const [action,...rest]=clean(ctx.q).split(/\s+/); const a=(action||'status').toLowerCase();
      if(a==='listar'||a==='lista') {
        const list=groups.listWarEligibleGroups(me.id).slice(0,15); return ctx.reply(tag(`⚔️ *ADVERSÁRIOS ELEGÍVEIS*\n\n${list.length?list.map((x,i)=>`${i+1}. 🏰 *${x.name}*\n   ⚡ Poder ${x.power} | 👥 ${x.participantCount} | 🆔 ${x.id}`).join('\n\n'):'Nenhum Clã do Grupo elegível foi registrado ainda.'}`));
      }
      if(a==='status') { const w=activeWarForSide('group',me.id); return ctx.reply(tag(w?`⚔️ *GUERRA ${w.status.toUpperCase()}*\n\n🏰 ${w.attackerName}: ${w.score.attacker}\n🏰 ${w.defenderName}: ${w.score.defender}\n⏳ ${w.durationDays} dia(s)\n🆔 ${w.id}`:`🕊️ ${me.name} não possui guerra ativa.`)); }
      if(a==='desafiar'||a==='desafio') {
        adminOnly(ctx); if(!me.warEnabled) throw new ValidationError('Ative ×clagrupoguerra on antes de desafiar.'); if(activeWarForSide('group',me.id)) throw new ValidationError('Seu grupo já possui uma guerra/desafio.');
        const target=rest.shift(); const days=rest.shift()||'3'; if(!target) throw new ValidationError('Uso: ×guerragrupo desafiar <nome|id> [1-5]');
        const eligible=groups.listWarEligibleGroups(me.id); const enemy=eligible.find(x=>x.id===target || x.name.toLowerCase()===target.toLowerCase() || x.name.toLowerCase().includes(target.toLowerCase())); if(!enemy) throw new ValidationError('Clã do Grupo não encontrado entre os adversários elegíveis.');
        const W=await wars.createChallenge({type:'group',attackerId:me.id,defenderId:enemy.id,duration:days,attackerName:me.name,defenderName:enemy.name,attackerMembers:me.members,defenderMembers:enemy.members});
        const id=Object.keys(W.byId).at(-1); const sent=await sendToGroup(ctx,enemy.id,`🚨 👻 FANTASMINHA — DESAFIO DE GUERRA\n\n🏰 *${me.name}* desafiou este grupo!\n\n⏳ Duração: ${days} dia(s)\n🆔 Guerra: ${id}\n\n👑 Um ADM pode responder:\n×guerragrupo aceitar\n×guerragrupo recusar`);
        return ctx.reply(tag(`⚔️ *DESAFIO ENVIADO!*\n\n🏰 ${me.name}\nVS\n🏰 ${enemy.name}\n\n🆔 ${id}\n📨 Aviso ao grupo adversário: ${sent?'✅ enviado':'⚠️ não enviado (o socket de envio não está disponível nesta ponte)'}`));
      }
      if(a==='aceitar') {
        adminOnly(ctx); if(!me.warEnabled) throw new ValidationError('Ative as guerras antes de aceitar.'); const w=activeWarForSide('group',me.id); if(!w||w.status!=='pending'||w.defenderId!==me.id) throw new ValidationError('Nenhum desafio pendente para este grupo.'); await wars.acceptChallenge(w.id,me.id); return ctx.reply(tag(`⚔️ *GUERRA ACEITA!*\n\n🏰 ${w.attackerName}\nVS\n🏰 ${w.defenderName}\n\n⏳ Preparação iniciada.`));
      }
      if(a==='recusar') {
        adminOnly(ctx); const w=activeWarForSide('group',me.id); if(!w||w.status!=='pending'||w.defenderId!==me.id) throw new ValidationError('Nenhum desafio pendente.'); await wars.rejectChallenge(w.id,me.id); return ctx.reply(tag('🕊️ Desafio recusado.'));
      }
      throw new ValidationError('Ação inválida. Use listar, desafiar, aceitar, recusar ou status.');
    }});

  registerCommand({ name:'guerragrupoentrar', aliases:['guerraentrar'], category:'wars', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Não há guerra ativa/preparação.'); const side=w.attackerId===c.id?'attacker':'defender'; await wars.joinWar(w.id,side,ctx.sender); await ctx.reply(tag(`⚔️ Você entrou na guerra *${w.id}*.`)); }
  });

  registerCommand({ name:'guerragruposair', aliases:['guerrasair'], category:'wars', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Não há guerra.'); const side=w.attackerId===c.id?'attacker':'defender'; await wars.leaveWar(w.id,side,ctx.sender); await ctx.reply(tag('🕊️ Você saiu durante a preparação.')); }
  });

  registerCommand({ name:'guerragrupoataque', aliases:['guerraataque'], category:'wars', plugin:'clans', groupOnly:true, cooldown:10,
    usage:'guerragrupoataque [normal|forte|especial]', handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra ativa.'); const side=w.attackerId===c.id?'attacker':'defender'; await wars.attack(w.id,side,ctx.sender,clean(ctx.q)||'normal'); const u=wars.getWar(w.id); const enemyId=side==='attacker'?u.defenderId:u.attackerId; const enemyName=side==='attacker'?u.defenderName:u.attackerName; await sendToGroup(ctx,enemyId,`🚨 ⚔️ ATAQUE!\n\n${c.name} realizou uma ofensiva contra *${enemyName}*.\n🏆 Pontuação atual: ${u.score.attacker} × ${u.score.defender}`); await ctx.reply(tag(`⚔️ *ATAQUE REALIZADO!*\n\n🏰 ${u.attackerName}: ${u.score.attacker}\n🏰 ${u.defenderName}: ${u.score.defender}`)); }
  });

  registerCommand({ name:'guerragrupomembros', aliases:['guerrajogadores'], category:'wars', plugin:'clans', groupOnly:true, cooldown:3,
    handler:async ctx => { const c=await ensureGroup(ctx); const w=activeWarForSide('group',c.id); if(!w) throw new ValidationError('Nenhuma guerra.'); const side=w.attackerId===c.id?'attacker':'defender'; const list=w.participants[side]||[]; await ctx.reply(tag(`👥 *PARTICIPANTES DA GUERRA*\n\n🏰 ${c.name}\n⚔️ ${list.length} inscrito(s)\n\n${list.slice(0,30).map((id,i)=>`${i+1}. ${id}`).join('\n')||'Nenhum inscrito ainda.'}`)); }
  });

  registerCommand({ name:'guerragrupohistorico', aliases:['historicoiguerras'], category:'wars', plugin:'clans', groupOnly:true, cooldown:5,
    handler:async ctx => { const c=await ensureGroup(ctx); const list=wars.listHistory('group',10).filter(w=>w.attackerId===c.id||w.defenderId===c.id); await ctx.reply(tag(`📜 *HISTÓRICO DE GUERRAS*\n\n${list.length?list.map(w=>`• ${w.attackerName} vs ${w.defenderName} — ${w.winner==='draw'?'🤝 Empate':w.winner==='attacker'?`🏆 ${w.attackerName}`:`🏆 ${w.defenderName}`}`).join('\n'):'Nenhuma guerra encerrada.'}`)); }
  });

  // ===== CLÃ 3.0 — WORLD / DOMÍNIO / DINASTIA =====
  registerCommand({ name:'claworld', aliases:['clanworld','cla3'], category:'clans', plugin:'clans', cooldown:3,
    handler:async ctx=>{ const c=currentGlobal(ctx.sender); if(!c) throw new ValidationError('Você não possui Clã Global.'); const x=await clanWorld.ensure(c); const ts=x.territories.map(id=>clanWorld.territories().find(t=>t.id===id)?.name||id); const bs=Object.entries(x.buildings).map(([k,v])=>`${clanWorld.buildings()[k]?.name||k} Nv.${v}`).join(' | '); await ctx.reply(tag(`🌌 *CLÃ WORLD ENGINE — ${c.name}*\n\n🏰 Sede: Nv.${x.buildings.sede||1}\n🗺️ Territórios: ${ts.length}\n${ts.length?ts.map(t=>` └─ ${t}`).join('\n'):' └─ Nenhum'}\n💰 Tesouro: ${x.treasury||0} GC\n🏗️ ${bs||'Sem construções'}\n🤝 Alianças: ${(x.alliances||[]).length}\n🐾 Mascote: ${x.mascot?`${x.mascot.name} (${x.mascot.species}) Nv.${x.mascot.level}`:'nenhum'}\n👑 Legado: ${x.legacy||0}`)); }});
  registerCommand({ name:'clasede', aliases:['claestrutura'], category:'clans', plugin:'clans', cooldown:5, usage:'clasede <sede|muralha|mina|oficina|santuario>', handler:async ctx=>{const c=currentGlobal(ctx);if(!c)throw new ValidationError('Sem Clã Global.');const k=clean(ctx.q).toLowerCase();const x=await clanWorld.build(c,k);const y=clanWorld.get(c.id);await ctx.reply(tag(`🏗️ *CONSTRUÇÃO CONCLUÍDA*\n\n🏰 ${clanWorld.buildings()[k].name}\n⭐ Nível: ${y.buildings[k]}\n💰 Tesouro: ${y.treasury} GC`));}});
  registerCommand({ name:'claterritorios', aliases:['clamapa','cladominio'], category:'clans', plugin:'clans', cooldown:4, handler:async ctx=>{const c=currentGlobal(ctx);if(!c)throw new ValidationError('Sem Clã Global.');const x=await clanWorld.ensure(c);const owned=new Set(x.territories);await ctx.reply(tag(`🗺️ *TERRITÓRIOS DO ALÉM*\n\n${clanWorld.territories().map(t=>`${owned.has(t.id)?'🟢':'⚪'} ${t.name} — +${t.income} GC/ciclo | 🛡️ ${t.defense}`).join('\n')}\n\n×claconquistar <id> — conquistar um território`));}});
  registerCommand({ name:'claconquistar', aliases:['claterritorio'], category:'clans', plugin:'clans', cooldown:10, usage:'claconquistar <cemiterio|floresta|purgatorio|abismo|reino>', handler:async ctx=>{const c=currentGlobal(ctx);if(!c)throw new ValidationError('Sem Clã Global.');const id=clean(ctx.q).split(/\s+/)[0].toLowerCase();await clanWorld.claimTerritory(c,id);const t=clanWorld.territories().find(a=>a.id===id);await ctx.reply(tag(`🗺️ *NOVO TERRITÓRIO CONQUISTADO!*\n\n🏰 ${c.name}\n📍 ${t.name}\n💰 Renda: +${t.income} GC/ciclo`));}});
  registerCommand({ name:'clacoletar', aliases:['clareceita'], category:'clans', plugin:'clans', cooldown:30, handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');await clanWorld.ensure(c);await clanWorld.collectIncome(c);const x=clanWorld.get(c.id);await ctx.reply(tag(`💰 *RECEITA DO DOMÍNIO*\n\n🏰 ${c.name}\n💰 Tesouro: ${x.treasury} GC\n🗺️ Territórios: ${x.territories.length}`));}});
  registerCommand({ name:'clacofre', aliases:['clatesouro'], category:'clans', plugin:'clans', cooldown:3, handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const x=await clanWorld.ensure(c);await ctx.reply(tag(`🏦 *COFRE DO CLÃ*\n\n🏰 ${c.name}\n💰 ${x.treasury} GC\n📈 Renda territorial: ${x.territories.reduce((s,id)=>s+(clanWorld.territories().find(t=>t.id===id)?.income||0),0)} GC/ciclo`));}});
  registerCommand({ name:'cladepositar2', aliases:['cladepositoworld'], category:'clans', plugin:'clans', cooldown:5, usage:'cladepositar2 <valor>', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const n=Math.floor(Number(ctx.q));if(!n||n<1)throw new ValidationError('Informe um valor.');await eco.addWallet(ctx.sender,-n,'clan_world_deposit',ctx.pushname);await clanWorld.deposit(c,n);await ctx.reply(tag(`🏦 +${n} GC enviados ao cofre do domínio.`));}});
  registerCommand({ name:'clacargos', aliases:['clacargo'], category:'clans', plugin:'clans', cooldown:4, usage:'clacargo @usuario <cargo>', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');if(c.leader!==ctx.sender&&c.vice!==ctx.sender)throw new ValidationError('Somente líder/vice.');const target=ctx.mentionedJid?.[0]||ctx.quotedSender||clean(ctx.q).split(/\s+/)[0];const role=clean(ctx.q).split(/\s+/).at(-1).toLowerCase();if(!target)throw new ValidationError('Mencione o membro.');await clanWorld.ensure(c);await clanWorld.setRole(c,ctx.sender,target,role);await ctx.reply(tag(`👑 Cargo atualizado.\n\n👤 ${target}\n🛡️ ${role}`));}});
  registerCommand({ name:'cladiplomacia', aliases:['cladiplomata'], category:'clans', plugin:'clans', cooldown:8, usage:'cladiplomacia <cla_id> <alianca|trégua|embargo|guerra>', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');if(c.leader!==ctx.sender&&c.vice!==ctx.sender)throw new ValidationError('Somente líder/vice.');const [id,action]=clean(ctx.q).split(/\s+/);const o=global.getGlobalClan(id);if(!o)throw new ValidationError('Clã alvo não encontrado.');await clanWorld.ensure(c);await clanWorld.ensure(o);await clanWorld.diplomacy(c,o,action);await ctx.reply(tag(`🤝 *DIPLOMACIA ATUALIZADA*\n\n🏰 ${c.name}\n↔️ ${o.name}\n📜 Status: ${action}`));}});
  registerCommand({ name:'claespiao', aliases:['claespionar'], category:'clans', plugin:'clans', cooldown:30, usage:'claespiao <cla_id>', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const o=global.getGlobalClan(clean(ctx.q));if(!o)throw new ValidationError('Clã não encontrado.');const x=await clanWorld.ensure(o);await ctx.reply(tag(`🕵️ *RELATÓRIO DE INTELIGÊNCIA*\n\n🏰 ${o.name}\n👥 Membros: ${o.members.length}\n⭐ Nível: ${o.level}\n⚡ Poder: ${o.power}\n🗺️ Territórios conhecidos: ${x.territories.length}\n🏗️ Sede: Nv.${x.buildings.sede||1}\n💰 Cofre estimado: ${Math.floor((x.treasury||0)*0.7)}–${Math.floor((x.treasury||0)*1.2)} GC`));}});
  registerCommand({ name:'clamascote', aliases:['clapet','clamascoteclan'], category:'clans', plugin:'clans', cooldown:8, usage:'clamascote <nome> [espécie]', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');if(c.leader!==ctx.sender&&c.vice!==ctx.sender)throw new ValidationError('Somente líder/vice.');const [name,species='espírito']=clean(ctx.q).split(/\s+/);if(!name)throw new ValidationError('Dê um nome ao mascote.');await clanWorld.ensure(c);await clanWorld.mascot(c,name,species);await ctx.reply(tag(`🐾 *MASCOTE DO CLÃ CRIADO!*\n\n${name}\n🧬 Espécie: ${species}\n⭐ Nível 1`));}});
  registerCommand({ name:'clamissao', aliases:['clamissoes'], category:'clans', plugin:'clans', cooldown:5, usage:'clamissao <objetivo> [recompensa]', handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');if(c.leader!==ctx.sender&&c.vice!==ctx.sender)throw new ValidationError('Somente líder/vice.');const parts=clean(ctx.q).split(/\s+/);const reward=parts.at(-1);const title=Number(reward)?parts.slice(0,-1).join(' '):parts.join(' ');await clanWorld.ensure(c);await clanWorld.mission(c,title,Number(reward)||500);await ctx.reply(tag(`🎯 *MISSÃO DO CLÃ CRIADA*\n\n📜 ${title}\n💰 Recompensa: ${Number(reward)||500} GC`));}});
  registerCommand({ name:'clarankworld', aliases:['rankcla3','rankdominio'], category:'clans', plugin:'clans', cooldown:5, handler:async ctx=>{const list=clanWorld.rank(10);await ctx.reply(tag(`👑 *RANKING DOS DOMÍNIOS*\n\n${list.map((x,i)=>`${i+1}. 🏰 ${x.name} — 🗺️${x.territories.length} | 💰${x.treasury} | 👑${x.legacy||0}`).join('\n') || 'Nenhum domínio expandido ainda.'}`));}});
  registerCommand({ name:'clacronicas', aliases:['clahistoria','clalog'], category:'clans', plugin:'clans', cooldown:4, handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const x=await clanWorld.ensure(c);const logs=(x.logs||[]).slice(-12).reverse();await ctx.reply(tag(`📜 *CRÔNICAS DO CLÃ*\n\n${logs.map(l=>`• ${new Date(l.at).toLocaleString('pt-BR')} — ${l.type}`).join('\n')||'As crônicas ainda estão vazias.'}`));}});
  registerCommand({ name:'cladinastia', aliases:['clalegado','clalegacy'], category:'clans', plugin:'clans', cooldown:4, handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const x=await clanWorld.ensure(c);const title=(x.legacy||0)>=10000?'👑 DINASTIA':(x.legacy||0)>=3000?'🏰 CASA MAIOR':'🌑 CASA ESPIRITUAL';await ctx.reply(tag(`👑 *${title}*\n\n🏰 ${c.name}\n📜 Legado: ${x.legacy||0}\n🗺️ Territórios: ${x.territories.length}\n🏆 Vitórias: ${c.wins||0}\n⭐ Nível: ${c.level}`));}});
  registerCommand({ name:'clahall', aliases:['clahallfama','clafama'], category:'clans', plugin:'clans', cooldown:4, handler:async ctx=>{const c=currentGlobal(ctx.sender);if(!c)throw new ValidationError('Sem Clã Global.');const x=await clanWorld.ensure(c);await ctx.reply(tag(`🏆 *HALL DA FAMA*\n\n🏰 ${c.name}\n👑 Líder atual: ${c.leader}\n⚔️ Vitórias: ${c.wins||0}\n🗺️ Territórios: ${x.territories.length}\n📜 Registros: ${(x.logs||[]).length}\n\nO legado histórico do clã é preservado conforme novas temporadas forem concluídas.`));}});

}

export default { register };
