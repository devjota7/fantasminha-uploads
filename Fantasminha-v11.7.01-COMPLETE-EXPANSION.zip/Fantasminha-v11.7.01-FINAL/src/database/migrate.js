import { metaGet, metaSet, readCollection, writeCollection } from './store.js';
import logger from '../core/logger.js';

const migrations = [
  {
    version: 1,
    name: 'init_collections',
    up() {
      if (!readCollection('users', null)) writeCollection('users', { byId: {} });
      writeCollection('users', readCollection('users', { byId: {} }));
      writeCollection('groups', readCollection('groups', { byId: {} }));
      writeCollection('economy_ledger', readCollection('economy_ledger', { entries: [] }));
      writeCollection('clans', readCollection('clans', { byId: {} }));
    }
  },
  {
    version: 2,
    name: 'indexes_meta',
    up() {
      writeCollection('_indexes', readCollection('_indexes', {
        richTop: [],
        xpTop: []
      }));
    }
  },
  {
    version: 3,
    name: 'premium_and_rate',
    up() {
      writeCollection('premium_plans', {
        bronze: { price: 0, days: 7, benefits: { cooldownMult: 0.8 } },
        prata: { price: 0, days: 30, benefits: { cooldownMult: 0.5, dailyBonus: 500 } },
        ouro: { price: 0, days: 30, benefits: { cooldownMult: 0.3, dailyBonus: 1500 } }
      });
    }
  },
  {
    version: 4,
    name: 'fantasminha_world_clans_wars',
    up() {
      const old = readCollection('clans', { byId: {} });
      const current = readCollection('global_clans', { byId: {}, byMember: {} });
      current.byId ||= {}; current.byMember ||= {};
      for (const c of Object.values(old.byId || {})) {
        if (current.byId[c.id]) continue;
        const migrated = { ...c, type: 'global', members: [...new Set(c.members || [])], updatedAt: Date.now() };
        current.byId[c.id] = migrated;
        for (const member of migrated.members) current.byMember[member] = migrated.id;
      }
      writeCollection('global_clans', current);
      writeCollection('group_clans', readCollection('group_clans', { byId: {} }));
      writeCollection('wars', readCollection('wars', { byId: {}, history: [] }));
    }
  },

  {
    version: 5,
    name: 'core_platform_v6',
    up() {
      writeCollection('platform_audit', readCollection('platform_audit', { events: [] }));
      writeCollection('platform_operations', readCollection('platform_operations', { byKey: {} }));
    }
  },
  {
    version: 6,
    name: 'member_rpg_economy_platform_v7',
    up() {
      writeCollection('members', readCollection('members', { byId: {} }));
      writeCollection('nicks', readCollection('nicks', { byId: {} }));
      writeCollection('nick_policies', readCollection('nick_policies', { byGroup: {} }));
      writeCollection('birthdays', readCollection('birthdays', { byId: {} }));
      writeCollection('preferences', readCollection('preferences', { byUser: {} }));
      writeCollection('reward_ledger', readCollection('reward_ledger', { entries: [] }));
      writeCollection('views', readCollection('views', { byGroup: {} }));
      writeCollection('platform_migrations', readCollection('platform_migrations', { used: {} }));
    }
  },
  {
    version: 7,
    name: 'v7_hardening_and_indexes',
    up() {
      writeCollection('nick_history', readCollection('nick_history', { entries: [] }));
      writeCollection('birthday_history', readCollection('birthday_history', { entries: [] }));
      writeCollection('platform_metrics', readCollection('platform_metrics', { counters: {} }));
      writeCollection('platform_search', readCollection('platform_search', { version: 1 }));
      writeCollection('platform_feature_audit', readCollection('platform_feature_audit', { events: [] }));
    }
  },

];

export function runMigrations() {
  const meta = metaGet();
  let v = meta.version || 0;
  for (const m of migrations) {
    if (m.version <= v) continue;
    logger.db('migrate', `v${m.version} ${m.name}`);
    m.up();
    v = m.version;
    metaSet({ version: v, lastMigration: m.name, at: Date.now() });
  }
  return v;
}

export default { runMigrations };
