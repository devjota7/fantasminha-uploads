/** Compatibilidade: toda persistência passa pela store única. */
export {
  readCollection, writeCollection, updateCollection,
  getUser, upsertUser, metaGet, metaSet,
  checkDatabase, backupDatabase, DB_ROOT
} from './store.js';

export function jsonStore(name) {
  const { readCollection, writeCollection, updateCollection } = requireless();
  return {
    read: (fallback = {}) => readCollection(name, fallback),
    write: data => writeCollection(name, data),
    update: fn => updateCollection(name, fn)
  };
}

function requireless() {
  // Os exports acima são estáticos; esta função existe apenas para manter a API antiga sem CommonJS.
  return { readCollection, writeCollection, updateCollection };
}

import { readCollection, writeCollection, updateCollection } from './store.js';
export async function backupJsonStores() { const { backupDatabase } = await import('./store.js'); return backupDatabase(); }
export default { jsonStore, backupJsonStores };
