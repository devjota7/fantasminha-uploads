/**
 * Persistência JSON robusta para Termux.
 * - escrita atômica
 * - lock por coleção em memória
 * - lock entre processos via mkdir exclusivo
 * - recuperação de lock antigo
 * - API compatível com a V2 atual
 *
 * Mantemos JSON nesta versão para não exigir módulo nativo no Android.
 * A camada fica isolada para futura migração transparente para SQLite.
 */
import fs from 'fs';
import path from 'path';
import config from '../core/config.js';
import logger from '../core/logger.js';

export const DB_ROOT = path.join(config.root, 'data', 'db');
const LOCK_ROOT = path.join(DB_ROOT, '.locks');
const locks = new Map();
const LOCK_STALE_MS = 120_000;
const LOCK_WAIT_MS = 25;
const LOCK_TIMEOUT_MS = 30_000;

function clone(value) { return value == null ? value : structuredClone(value); }
function ensure() { fs.mkdirSync(DB_ROOT, { recursive: true }); fs.mkdirSync(LOCK_ROOT, { recursive: true }); }
function safeName(collection) { const name = String(collection || '').replace(/[^a-zA-Z0-9_.-]/g, '_'); if (!name) throw new Error('Coleção inválida'); return name; }
function fileFor(collection) { return path.join(DB_ROOT, `${safeName(collection)}.json`); }
function lockFor(collection) { return path.join(LOCK_ROOT, `${safeName(collection)}.lock`); }

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function acquireProcessLock(collection) {
  ensure();
  const lock = lockFor(collection);
  const started = Date.now();
  while (true) {
    try {
      fs.mkdirSync(lock);
      fs.writeFileSync(path.join(lock, 'owner.json'), JSON.stringify({ pid: process.pid, at: Date.now() }));
      return () => { try { fs.rmSync(lock, { recursive: true, force: true }); } catch {} };
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      try {
        const st = fs.statSync(lock);
        if (Date.now() - st.mtimeMs > LOCK_STALE_MS) fs.rmSync(lock, { recursive: true, force: true });
      } catch {}
      if (Date.now() - started > LOCK_TIMEOUT_MS) throw new Error(`Timeout de lock da coleção ${collection}`);
      await sleep(LOCK_WAIT_MS);
    }
  }
}

async function withLock(collection, fn) {
  const prev = locks.get(collection) || Promise.resolve();
  let releaseMemory;
  const next = new Promise(r => { releaseMemory = r; });
  locks.set(collection, prev.then(() => next));
  await prev;
  let releaseFile;
  try {
    releaseFile = await acquireProcessLock(collection);
    return await fn();
  } finally {
    try { releaseFile?.(); } catch {}
    releaseMemory();
    if (locks.get(collection) === next) locks.delete(collection);
  }
}

export function readCollection(collection, fallback = {}) {
  ensure();
  const f = fileFor(collection);
  try {
    if (!fs.existsSync(f)) return clone(fallback);
    const parsed = JSON.parse(fs.readFileSync(f, 'utf8'));
    return parsed ?? clone(fallback);
  } catch (e) {
    logger.db('read', e.message, { collection });
    return clone(fallback);
  }
}

export function writeCollection(collection, data) {
  ensure();
  const f = fileFor(collection);
  const tmp = `${f}.${process.pid}.${Date.now()}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmp, f);
}

export async function updateCollection(collection, updater, fallback = {}) {
  return withLock(collection, async () => {
    const cur = readCollection(collection, fallback);
    const next = (await updater(cur)) ?? cur;
    writeCollection(collection, next);
    return next;
  });
}

export function getUser(userId) {
  if (!userId) return null;
  const users = readCollection('users', { byId: {} });
  return users.byId?.[userId] || null;
}

export async function upsertUser(userId, patch = {}) {
  if (!userId) throw new Error('userId obrigatório');
  return updateCollection('users', users => {
    if (!users.byId) users.byId = {};
    const prev = users.byId[userId] || {
      id: userId, name: '', createdAt: Date.now(),
      economy: { wallet: 0, bank: 0, lastDaily: 0, lastWeekly: 0, lastWork: 0, inventory: {} },
      rpg: { class: null, level: 1, xp: 0, hp: 100, maxHp: 100 },
      premium: { active: false, until: 0, plan: null }, warns: 0
    };
    users.byId[userId] = { ...prev, ...patch,
      economy: { ...prev.economy, ...(patch.economy || {}) },
      rpg: { ...prev.rpg, ...(patch.rpg || {}) },
      premium: { ...prev.premium, ...(patch.premium || {}) }, updatedAt: Date.now() };
    return users;
  }, { byId: {} });
}

export function metaGet() { return readCollection('_meta', { version: 0 }); }
export function metaSet(patch) { const cur = metaGet(); writeCollection('_meta', { ...cur, ...patch }); }

export function checkDatabase() {
  try {
    ensure();
    const probe = path.join(DB_ROOT, `.health-${process.pid}.tmp`);
    fs.writeFileSync(probe, 'ok'); fs.rmSync(probe, { force: true });
    readCollection('_meta', { version: 0 });
    return true;
  } catch (e) {
    logger.db('health', e.message);
    return false;
  }
}

export function backupDatabase() {
  ensure();
  const dest = path.join(config.root, 'data', 'backups', `db_${Date.now()}`);
  fs.mkdirSync(dest, { recursive: true });
  for (const f of fs.readdirSync(DB_ROOT)) {
    if (f === '.locks' || f.endsWith('.tmp')) continue;
    const src = path.join(DB_ROOT, f);
    if (fs.statSync(src).isFile()) fs.copyFileSync(src, path.join(dest, f));
  }
  logger.db('backup', 'ok', { dest });
  return dest;
}

export default { readCollection, writeCollection, updateCollection, getUser, upsertUser, metaGet, metaSet, checkDatabase, backupDatabase, DB_ROOT };
