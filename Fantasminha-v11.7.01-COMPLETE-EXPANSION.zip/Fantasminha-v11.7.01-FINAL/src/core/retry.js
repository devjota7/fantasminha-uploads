/** Retry/backoff centralizado para I/O e APIs. */
export async function withRetry(fn, {
  retries = 3,
  baseDelayMs = 350,
  maxDelayMs = 4000,
  factor = 2,
  shouldRetry = () => true,
  onRetry = null
} = {}) {
  let lastError;
  const total = Math.max(1, Number(retries) + 1);
  for (let attempt = 1; attempt <= total; attempt++) {
    try { return await fn({ attempt, remaining: total - attempt }); }
    catch (error) {
      lastError = error;
      if (attempt >= total || !shouldRetry(error, attempt)) throw error;
      const delay = Math.min(maxDelayMs, Math.round(baseDelayMs * (factor ** (attempt - 1))));
      try { await onRetry?.({ error, attempt, delay }); } catch {}
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  throw lastError;
}

export function retryableStatus(error) {
  const status = Number(error?.status || error?.response?.status || 0);
  return !status || status === 408 || status === 425 || status === 429 || status >= 500;
}

export default { withRetry, retryableStatus };
