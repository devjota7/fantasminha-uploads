/**
 * 👻 Fantasminha — resolvedor único de prefixo.
 *
 * Termux define process.env.PREFIX como o diretório da instalação
 * (/data/data/com.termux/files/usr). Isso NÃO é o prefixo do bot.
 * O .env do projeto tem prioridade para PREFIX.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const ENV_FILE = path.join(ROOT, '.env');

function readEnvValue(name) {
  try {
    if (!fs.existsSync(ENV_FILE)) return '';
    const line = fs.readFileSync(ENV_FILE, 'utf8')
      .split(/\r?\n/)
      .find((raw) => raw.trim().startsWith(`${name}=`));
    if (!line) return '';
    return line.slice(line.indexOf('=') + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
  } catch {
    return '';
  }
}

function isValidBotPrefix(value) {
  const v = String(value ?? '').trim();
  if (!v || v.length > 8) return false;
  if (v.includes('/') || v.includes('\\')) return false;
  if (v.startsWith('/data/data/') || v.includes('termux/files')) return false;
  return true;
}

export function getBotPrefix(fallback = '×') {
  const filePrefix = readEnvValue('PREFIX');
  if (isValidBotPrefix(filePrefix)) return filePrefix;

  const envPrefix = process.env.BOT_PREFIX;
  if (isValidBotPrefix(envPrefix)) return String(envPrefix).trim();

  const processPrefix = process.env.PREFIX;
  if (isValidBotPrefix(processPrefix)) return String(processPrefix).trim();

  return fallback;
}

export function normalizeBotPrefix(value, fallback = '×') {
  return isValidBotPrefix(value) ? String(value).trim() : fallback;
}

export default getBotPrefix;
