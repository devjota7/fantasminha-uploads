/** Métricas leves em memória, sem dependências externas. */
const commands = new Map();
const counters = new Map();
const startedAt = Date.now();

function bump(map, key, amount = 1) { map.set(key, (map.get(key) || 0) + amount); }

export function increment(name, amount = 1) { bump(counters, name, amount); }

export function commandStarted(name) {
  const c = commands.get(name) || { calls: 0, success: 0, errors: 0, totalMs: 0, maxMs: 0 };
  c.calls += 1;
  commands.set(name, c);
}

export function commandFinished(name, { ok = true, durationMs = 0 } = {}) {
  const c = commands.get(name) || { calls: 0, success: 0, errors: 0, totalMs: 0, maxMs: 0 };
  if (ok) c.success += 1; else c.errors += 1;
  c.totalMs += durationMs;
  c.maxMs = Math.max(c.maxMs, durationMs);
  commands.set(name, c);
}

export function snapshot() {
  const commandStats = [...commands.entries()].map(([name, c]) => ({
    name, ...c, avgMs: c.calls ? Number((c.totalMs / c.calls).toFixed(1)) : 0
  })).sort((a, b) => b.calls - a.calls);
  return { uptimeMs: Date.now() - startedAt, counters: Object.fromEntries(counters), commands: commandStats };
}

export function resetMetrics() { commands.clear(); counters.clear(); }

export default { increment, commandStarted, commandFinished, snapshot, resetMetrics };
