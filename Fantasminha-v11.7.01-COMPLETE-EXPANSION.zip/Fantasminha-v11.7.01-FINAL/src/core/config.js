/** Config centralizada: ambiente + config.json, sem duplicar versões. */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { getBotPrefix } from './prefix.js';
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
function loadDotEnv(envPath = path.join(ROOT, '.env')) {
  if (!fs.existsSync(envPath)) return;
  for (const line of fs.readFileSync(envPath, 'utf8').split('\n')) {
    const t = line.trim(); if (!t || t.startsWith('#')) continue;
    const i = t.indexOf('='); if (i < 0) continue;
    const k = t.slice(0, i).trim(); let v = t.slice(i + 1).trim();
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[k] === undefined) process.env[k] = v;
  }
}
loadDotEnv();
const CONFIG_JSON = path.join(ROOT, 'dados', 'src', 'config.json');
function readJsonSafe(file, fallback = {}) { try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; } catch { return fallback; } }
const publicCfg = readJsonSafe(CONFIG_JSON, {});
let pkg = {};
try { pkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')); } catch {}
const bool = (key, fallback = true) => process.env[key] === undefined ? fallback : process.env[key] !== 'false';
export function normalizeOwnerId(value) {
  const raw = String(value ?? '').trim().toLowerCase();
  if (!raw) return '';
  const at = raw.indexOf('@');
  if (at < 0) return raw.split(':')[0].replace(/[^0-9a-z_-]/g, '');
  const base = raw.slice(0, at).split(':')[0].replace(/[^0-9a-z_-]/g, '');
  const domain = raw.slice(at + 1).trim();
  if (!base || !domain) return '';
  // O domínio faz parte da identidade: não permita que um LID ou JID estranho
  // coincida acidentalmente com o número do dono.
  return domain === 's.whatsapp.net' ? base : `${base}@${domain}`;
}
export function ownerIdentitySet() {
  return new Set([
    process.env.OWNER_NUMBER || publicCfg.numerodono || '',
    ...String(process.env.OWNER_IDS || '').split(','),
    process.env.OWNER_LID || ''
  ].map(normalizeOwnerId).filter(Boolean));
}

export const config = {
  root: ROOT, env: process.env.NODE_ENV || 'production', botName: process.env.BOT_NAME || publicCfg.nomebot || 'Fantasminha',
  botVersion: pkg.version || process.env.BOT_VERSION || '0.0.0', ownerName: process.env.OWNER_NAME || publicCfg.nomedono || 'Jota',
  ownerNumber: process.env.OWNER_NUMBER || publicCfg.numerodono || '', ownerIds: [...ownerIdentitySet()], ownerLid: process.env.OWNER_LID || '', prefix: getBotPrefix(publicCfg.prefixo || '×'), language: process.env.DEFAULT_LANGUAGE || 'pt-BR',
  features: { rpg: bool('FEATURE_RPG'), economy: bool('FEATURE_ECONOMY'), ai: bool('FEATURE_AI'), downloads: bool('FEATURE_DOWNLOADS'), clans: bool('FEATURE_CLANS'), games: bool('FEATURE_GAMES'), alem: bool('FEATURE_ALEM'), dashboard: bool('FEATURE_DASHBOARD', true) },
  secrets: { groq: process.env.GROQ_API_KEY || '', gemini: process.env.GEMINI_API_KEY || '', cerebras: process.env.CEREBRAS_API_KEY || '', nvidia: process.env.NVIDIA_API_KEY || process.env.API_KEY || '', githubToken: process.env.GITHUB_UPDATE_TOKEN || '', tenor: process.env.TENOR_API_KEY || '' },
  aiProvider: (process.env.AI_PROVIDER || 'auto').toLowerCase(), logLevel: process.env.LOG_LEVEL || 'info', authDir: process.env.AUTH_DIR || path.join(ROOT, 'data', 'auth'), dbFile: process.env.DB_FILE || path.join(ROOT, 'data', 'fantasminha.sqlite'), public: publicCfg,
  validate() { const missing=[]; if(!this.ownerNumber) missing.push('OWNER_NUMBER'); if(!this.prefix) missing.push('PREFIX'); return { ok: !missing.length, missing }; },
  hasAnyAiKey() { return Object.values(this.secrets).some(v => !!v) && !!(this.secrets.groq || this.secrets.gemini || this.secrets.cerebras || this.secrets.nvidia); }
};
export default config;
