/** Registry seguro de ferramentas para agentes de IA. A IA nunca executa código arbitrário. */
import { getCommand } from './registry.js';
import { canRun } from './permissions.js';
import { ValidationError, PermissionError } from './errors.js';

const tools = new Map();

export function registerTool({ name, description = '', args = [], command = null, handler = null, permission = 10 } = {}) {
  const key = String(name || '').trim().toLowerCase();
  if (!key || (!command && typeof handler !== 'function')) throw new Error('Ferramenta inválida');
  tools.set(key, Object.freeze({ name: key, description, args, command, handler, permission }));
  return tools.get(key);
}

export function listTools() { return [...tools.values()].map(({ handler, ...tool }) => tool); }

export async function executeTool(name, ctx, input = {}) {
  const tool = tools.get(String(name || '').toLowerCase());
  if (!tool) throw new ValidationError(`Ferramenta não encontrada: ${name}`);
  if (!canRun(ctx, tool.permission)) throw new PermissionError('Você não tem permissão para esta ação.');
  if (tool.command) {
    const cmd = getCommand(tool.command);
    if (!cmd) throw new ValidationError(`Comando da ferramenta indisponível: ${tool.command}`);
    const args = Array.isArray(input) ? input : Object.values(input);
    return cmd.handler({ ...ctx, args, q: args.join(' '), command: cmd.name });
  }
  return tool.handler(ctx, input);
}

export default { registerTool, listTools, executeTool };
