/** Ciclo de vida central do Fantasminha. */
import { stopAllJobs } from '../platform/jobs/index.js';
import { emit, Events } from '../events/index.js';
import logger from './logger.js';
import { cleanupResources } from './resourceManager.js';
import { stopControlCenter } from '../platform/controlCenter/index.js';

let shuttingDown = false;

export function isShuttingDown() { return shuttingDown; }

export async function shutdown(reason = 'manual') {
  if (shuttingDown) return;
  shuttingDown = true;
  logger.info('lifecycle', `encerrando (${reason})`);
  try { stopAllJobs(); } catch (e) { logger.warn('lifecycle', 'falha ao parar jobs', { error: e.message }); }
  try { await emit(Events.SHUTDOWN, { reason, at: Date.now() }); } catch (e) { logger.warn('lifecycle', 'falha no evento shutdown', { error: e.message }); }
  try { await cleanupResources(); } catch (e) { logger.warn('lifecycle', 'falha ao limpar recursos', { error: e.message }); }
  try { await stopControlCenter(); } catch (e) { logger.warn('lifecycle', 'falha ao parar control center', { error: e.message }); }
}

export function installLifecycleHandlers() {
  if (globalThis.__fantasmaLifecycleInstalled) return;
  globalThis.__fantasmaLifecycleInstalled = true;
  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.once(signal, () => { shutdown(signal).finally(() => process.exit(0)); });
  }
}

export default { shutdown, isShuttingDown, installLifecycleHandlers };
