/**
 * Fantasminha — Logger profissional
 */
import fs from 'fs';
import path from 'path';
import config from './config.js';

const LOG_DIR = path.join(config.root, 'logs');
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });

const LEVELS = { error: 0, warn: 1, info: 2, debug: 3, command: 2, db: 2, perf: 2 };
const current = LEVELS[config.logLevel] ?? 2;

function stamp() {
  return new Date().toISOString();
}

function line(level, scope, msg, meta) {
  const base = `[${stamp()}] [${level.toUpperCase()}] [${scope}] ${msg}`;
  if (meta && Object.keys(meta).length) {
    try {
      return base + ' ' + JSON.stringify(sanitize(meta));
    } catch {
      return base;
    }
  }
  return base;
}

function sanitize(obj) {
  const secretKeys = /key|token|secret|password|authorization|apikey/i;
  const out = {};
  for (const [k, v] of Object.entries(obj || {})) {
    if (secretKeys.test(k)) out[k] = '***';
    else out[k] = v;
  }
  return out;
}

function write(level, scope, msg, meta) {
  if ((LEVELS[level] ?? 2) > current) return;
  const text = line(level, scope, msg, meta);
  const fn = level === 'error' ? console.error : level === 'warn' ? console.warn : console.log;
  fn(text);
  try {
    const day = new Date().toISOString().slice(0, 10);
    fs.appendFileSync(path.join(LOG_DIR, `${day}.log`), text + '\n');
  } catch { /* ignore disk errors */ }
}

export const logger = {
  error: (scope, msg, meta) => write('error', scope, msg, meta),
  warn: (scope, msg, meta) => write('warn', scope, msg, meta),
  info: (scope, msg, meta) => write('info', scope, msg, meta),
  debug: (scope, msg, meta) => write('debug', scope, msg, meta),
  command: (scope, msg, meta) => write('command', scope, msg, meta),
  db: (scope, msg, meta) => write('db', scope, msg, meta),
  perf: (scope, msg, meta) => write('perf', scope, msg, meta),
  connection: (msg, meta) => write('info', 'connection', msg, meta)
};

export default logger;
