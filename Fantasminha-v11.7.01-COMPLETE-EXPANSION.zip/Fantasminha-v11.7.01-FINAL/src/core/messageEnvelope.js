/** Registro volátil de envelopes recebidos; conservador após restart. */
const TTL_MS = 60 * 60 * 1000;
const MAX_PER_SCOPE = 1200;
const registry = new Map();

function prune(map) {
  const now = Date.now();
  for (const [id, item] of map) if (now - item.ts > TTL_MS) map.delete(id);
  while (map.size > MAX_PER_SCOPE) map.delete(map.keys().next().value);
}

export function recordEnvelope(message, { readable = true, kind = 'other' } = {}) {
  const key = message?.key;
  const scope = key?.remoteJid;
  const id = key?.id;
  const participant = key?.participant || key?.participantAlt || message?.participant;
  if (!scope || !id) return null;
  let map = registry.get(scope);
  if (!map) registry.set(scope, map = new Map());
  const entry = { id, scope, participant: participant || null, kind: readable ? kind : 'unreadable', ts: Date.now() };
  map.set(id, entry);
  prune(map);
  return entry;
}

export function verifyEnvelope({ scope, id, participant = null, kind = null } = {}) {
  const entry = registry.get(scope)?.get(id);
  if (!entry) return { known: false, corroborated: false, contradicted: false };
  const sameParticipant = !participant || entry.participant === participant;
  const sameKind = !kind || entry.kind === kind;
  return {
    known: true,
    corroborated: sameParticipant && sameKind && entry.kind !== 'unreadable',
    contradicted: !sameParticipant || (!sameKind && entry.kind !== 'unreadable'),
    entry
  };
}

export function envelopeStats() {
  let total = 0;
  for (const map of registry.values()) total += map.size;
  return { scopes: registry.size, entries: total, ttlMs: TTL_MS, maxPerScope: MAX_PER_SCOPE };
}

export function clearEnvelopeRegistry() { registry.clear(); }
export default { recordEnvelope, verifyEnvelope, envelopeStats, clearEnvelopeRegistry };
