import config from './config.js';
import { registryStats } from './registry.js';
import { checkDatabase } from '../database/store.js';
import { snapshot as metricsSnapshot } from './metrics.js';
import fs from 'fs';

function mb(n) { return (n / 1024 / 1024).toFixed(1); }
function formatUptime(sec) { const s=Math.floor(sec), d=Math.floor(s/86400), h=Math.floor((s%86400)/3600), m=Math.floor((s%3600)/60); return d ? `${d}d ${h}h ${m}m` : `${h}h ${m}m`; }

export function healthSnapshot({ waConnected = false, dbOk = null } = {}) {
  const mem = process.memoryUsage();
  const db = dbOk === null ? checkDatabase() : !!dbOk;
  const r = registryStats();
  const disk = (() => { try { const st=fs.statSync(config.root); return st ? 'ok' : 'erro'; } catch { return 'erro'; } })();
  return {
    ok: !!waConnected && db && r.valid,
    bot: config.botName, version: config.botVersion, uptime: formatUptime(process.uptime()),
    uptimeSeconds: Math.floor(process.uptime()), ram: `${mb(mem.heapUsed)} / ${mb(mem.heapTotal)} MB`,
    rss: `${mb(mem.rss)} MB`, node: process.version, wa: waConnected ? 'online' : 'offline',
    db: db ? 'ok' : 'erro', disk, ai: config.hasAnyAiKey() ? 'keys ok' : 'sem keys',
    features: config.features, commands: r, metrics: metricsSnapshot()
  };
}

export function healthText(snap) {
  const dot = ok => ok ? '🟢' : '🔴';
  return `× 👻 *STATUS — FANTASMINHA*\n\n${dot(snap.wa === 'online')} WhatsApp: *${snap.wa}*\n${dot(snap.db === 'ok')} Banco: *${snap.db}*\n${dot(snap.disk === 'ok')} Armazenamento: *${snap.disk}*\n${dot(snap.features.economy)} Economia: *${snap.features.economy ? 'on':'off'}*\n${dot(snap.features.rpg)} RPG: *${snap.features.rpg ? 'on':'off'}*\n${dot(snap.features.downloads)} Downloads: *${snap.features.downloads ? 'on':'off'}*\n${dot(snap.features.games)} Jogos: *${snap.features.games ? 'on':'off'}*\n${dot(snap.ai === 'keys ok')} IA: *${snap.ai}*\n\n⏱ Uptime: *${snap.uptime}*\n💾 Heap: *${snap.ram}*\n🧠 RSS: *${snap.rss}*\n📦 Versão: *v${snap.version}*\n⚙️ Registry: *${snap.commands.enabled}* comandos / *${snap.commands.aliases}* aliases\n${snap.commands.valid ? '✅ Registry íntegro' : '⚠️ Registry com problemas'}\n`;
}

export default { healthSnapshot, healthText };
