import logger from './logger.js';
import { reportCrash } from './crashReporter.js';

let installed = false;

export function installAntiCrash() {
  if (installed) return;
  installed = true;

  process.on('uncaughtException', (err) => {
    reportCrash(err, { type: 'uncaughtException' });
    logger.error('antiCrash', 'uncaughtException — processo marcado para encerramento controlado');
    // Uma exceção não capturada pode deixar o processo inconsistente.
    // O supervisor externo é responsável pelo restart.
    setTimeout(() => process.exit(1), 50).unref?.();
  });

  process.on('unhandledRejection', (reason) => {
    const err = reason instanceof Error ? reason : new Error(String(reason));
    reportCrash(err, { type: 'unhandledRejection' });
    logger.error('antiCrash', 'unhandledRejection', { message: err.message });
  });

  process.on('warning', (w) => logger.warn('antiCrash', w.message));
  logger.info('antiCrash', 'handlers instalados');
}

export default { installAntiCrash };
