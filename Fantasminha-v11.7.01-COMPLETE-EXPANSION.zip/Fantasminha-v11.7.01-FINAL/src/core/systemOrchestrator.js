/**
 * System Orchestrator — camada de coordenação operacional da base.
 * Não substitui o dispatcher legado: centraliza diagnóstico, políticas e
 * observabilidade sem quebrar os contratos existentes.
 */
import os from 'node:os';
import fs from 'node:fs';
import config from './config.js';
import { registryStats } from './registry.js';
import { checkDatabase } from '../database/store.js';
import { snapshot as metricsSnapshot } from './metrics.js';
import { auditStats } from '../platform/audit/index.js';
import { getFeatureFlags } from '../platform/flags/index.js';
import { listJobs } from '../platform/jobs/index.js';
import { resourceStats } from './resourceManager.js';
import { getAssistantMetrics } from '../services/assistantV2Core.js';
import { queues } from './queue.js';

const startedAt = Date.now();

function memory() {
  const m = process.memoryUsage();
  return { rss: m.rss, heapUsed: m.heapUsed, heapTotal: m.heapTotal, external: m.external };
}

function diskStatus() {
  try { fs.accessSync(config.root, fs.constants.R_OK | fs.constants.W_OK); return true; }
  catch { return false; }
}

export function collectSystemSnapshot({ waConnected = false } = {}) {
  const registry = registryStats();
  const db = checkDatabase();
  const mem = memory();
  const features = getFeatureFlags();
  const audit = auditStats();
  const resources = resourceStats();
  const queueStatus = Object.fromEntries(Object.entries(queues).map(([name, q]) => [name, q.getStatus()]));
  const jobs = listJobs();
  const assistant = getAssistantMetrics();
  const checks = {
    whatsapp: !!waConnected,
    database: db,
    registry: registry.valid,
    storage: diskStatus(),
    memory: mem.heapTotal === 0 || (mem.heapUsed / mem.heapTotal) < 0.92,
    jobs: jobs.every(j => j.status !== 'failed'),
  };
  return {
    ok: Object.values(checks).every(Boolean),
    version: config.botVersion,
    name: config.botName,
    uptimeMs: Date.now() - startedAt,
    node: process.version,
    platform: `${process.platform}/${process.arch}`,
    checks,
    registry,
    database: { ok: db },
    memory: mem,
    features,
    jobs: jobs.map(j => ({ name: j.name, status: j.status })),
    queues: queueStatus,
    resources: { active: resources.active },
    audit: { total: audit.total, lastAt: audit.last?.at || null },
    assistant,
    host: { cpus: os.cpus().length, totalMem: os.totalmem(), freeMem: os.freemem() }
  };
}

export function systemDoctor(snapshot = collectSystemSnapshot()) {
  const issues = [];
  if (!snapshot.checks.database) issues.push('Banco indisponível ou sem escrita.');
  if (!snapshot.checks.registry) issues.push('Registry de comandos inválido.');
  if (!snapshot.checks.storage) issues.push('Diretório raiz sem acesso de leitura/escrita.');
  if (!snapshot.checks.memory) issues.push('Uso do heap acima de 92%; reduza cargas concorrentes.');
  if (!snapshot.checks.jobs) issues.push('Há jobs operacionais em estado de falha.');
  return { ok: issues.length === 0, issues, snapshot };
}

export function systemSummary(snapshot = collectSystemSnapshot()) {
  const d = systemDoctor(snapshot);
  const dot = x => x ? '🟢' : '🔴';
  return [
    '× 👻 *FANTASMINHA — CENTRAL DO SISTEMA*', '',
    `${dot(snapshot.checks.database)} Banco: *${snapshot.checks.database ? 'OK' : 'ERRO'}*`,
    `${dot(snapshot.checks.registry)} Registry: *${snapshot.checks.registry ? 'OK' : 'ERRO'}*`,
    `${dot(snapshot.checks.storage)} Armazenamento: *${snapshot.checks.storage ? 'OK' : 'ERRO'}*`,
    `${dot(snapshot.checks.memory)} Memória: *${Math.round(snapshot.memory.heapUsed / Math.max(snapshot.memory.heapTotal, 1) * 100)}% heap*`,
    `${dot(snapshot.checks.jobs)} Jobs: *${snapshot.jobs.length} registrados*`,
    `🧠 Assistente V2: *${snapshot.assistant.response_count} respostas / ${snapshot.assistant.safety_blocks} bloqueios*`,
    `📦 Comandos: *${snapshot.registry.enabled}* | aliases: *${snapshot.registry.aliases}*`,
    `⏱️ Uptime: *${Math.floor(snapshot.uptimeMs / 3600000)}h ${Math.floor(snapshot.uptimeMs / 60000) % 60}m*`,
    '',
    d.ok ? '✅ *Sistema saudável.*' : `⚠️ *Atenção:*\n${d.issues.map(x => `• ${x}`).join('\n')}`
  ].join('\n');
}

export default { collectSystemSnapshot, systemDoctor, systemSummary };
