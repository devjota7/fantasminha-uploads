/** Gerenciador de recursos temporários: arquivos, streams e limpeza segura. */
const resources = new Map();
const timers = new Map();

export function trackResource(id, resource, { ttlMs = 15 * 60_000, dispose = null, meta = {} } = {}) {
  if (!id) throw new Error('resource id obrigatório');
  releaseResource(id);
  resources.set(id, { id, resource, meta, createdAt: Date.now(), lastTouch: Date.now(), dispose });
  if (ttlMs > 0) timers.set(id, setTimeout(() => releaseResource(id), ttlMs).unref?.() || setTimeout(() => {}, 0));
  return resource;
}

export function touchResource(id) {
  const item = resources.get(id);
  if (!item) return false;
  item.lastTouch = Date.now();
  return true;
}

export async function releaseResource(id) {
  const item = resources.get(id);
  if (!item) return false;
  resources.delete(id);
  const timer = timers.get(id); if (timer) clearTimeout(timer); timers.delete(id);
  try { if (typeof item.dispose === 'function') await item.dispose(item.resource); else if (typeof item.resource?.destroy === 'function') item.resource.destroy(); else if (typeof item.resource?.close === 'function') await item.resource.close(); } catch {}
  return true;
}

export async function cleanupResources() {
  for (const id of [...resources.keys()]) await releaseResource(id);
  return true;
}

export function resourceStats() {
  return { active: resources.size, resources: [...resources.values()].map(({ id, meta, createdAt, lastTouch }) => ({ id, meta, ageMs: Date.now() - createdAt, idleMs: Date.now() - lastTouch })) };
}

export default { trackResource, touchResource, releaseResource, cleanupResources, resourceStats };
