/** Worker pool genérico para operações pesadas. */
export class TaskQueue {
  constructor({ name='queue', concurrency=4, maxSize=500, timeoutMs=30_000 }={}) {
    this.name=name; this.concurrency=concurrency; this.maxSize=maxSize; this.timeoutMs=timeoutMs; this.pending=[]; this.active=0;
    this.stats={enqueued:0, completed:0, failed:0, dropped:0, totalMs:0};
  }
  add(task, { priority=0, timeoutMs=this.timeoutMs }={}) {
    if (this.pending.length >= this.maxSize) { this.stats.dropped++; return Promise.reject(new Error(`Fila ${this.name} cheia`)); }
    return new Promise((resolve,reject)=>{ this.pending.push({task,priority,timeoutMs,resolve,reject,createdAt:Date.now()}); this.pending.sort((a,b)=>b.priority-a.priority || a.createdAt-b.createdAt); this.stats.enqueued++; this.#drain(); });
  }
  async #run(item) {
    this.active++;
    const start=Date.now(); let timer;
    try {
      const timeout=new Promise((_,rej)=>timer=setTimeout(()=>rej(new Error(`Timeout na fila ${this.name}`)), item.timeoutMs));
      const value=await Promise.race([Promise.resolve().then(item.task),timeout]);
      this.stats.completed++; this.stats.totalMs += Date.now()-start; item.resolve(value);
    } catch(e) { this.stats.failed++; item.reject(e); } finally { clearTimeout(timer); this.active--; this.#drain(); }
  }
  #drain(){ while(this.active<this.concurrency && this.pending.length) this.#run(this.pending.shift()); }
  getStatus(){ return {name:this.name, pending:this.pending.length, active:this.active, concurrency:this.concurrency, ...this.stats, avgMs:this.stats.completed ? Math.round(this.stats.totalMs/this.stats.completed) : 0}; }
  clear(reason='fila limpa'){ const e=new Error(reason); for(const i of this.pending.splice(0)) i.reject(e); }
}

export const queues = {
  messages: new TaskQueue({name:'messages', concurrency:6, maxSize:1000, timeoutMs:30_000}),
  downloads: new TaskQueue({name:'downloads', concurrency:2, maxSize:50, timeoutMs:120_000}),
  ai: new TaskQueue({name:'ai', concurrency:3, maxSize:100, timeoutMs:60_000}),
  media: new TaskQueue({name:'media', concurrency:2, maxSize:50, timeoutMs:90_000})
};
export default { TaskQueue, queues };
