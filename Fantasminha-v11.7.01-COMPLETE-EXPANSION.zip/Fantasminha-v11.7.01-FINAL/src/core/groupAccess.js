/**
 * 👻 Fantasminha — allowlist de grupos.
 *
 * ALLOWED_GROUP_IDS aceita IDs separados por vírgula, ponto e vírgula ou
 * quebra de linha. Lista vazia = todos os grupos (compatibilidade).
 */
export function parseAllowedGroups(value) {
  if (Array.isArray(value)) return [...new Set(value.map(normalize).filter(Boolean))];
  return [...new Set(String(value ?? '')
    .split(/[;,\n\r]+/)
    .map(normalize)
    .filter(Boolean))];
}

function normalize(value) {
  return String(value ?? '').trim();
}

export function isGroupAllowed(jid, allowedGroups) {
  const remote = normalize(jid);
  if (!remote.endsWith('@g.us')) return true;
  const list = Array.isArray(allowedGroups) ? allowedGroups.filter(Boolean) : parseAllowedGroups(allowedGroups);
  if (list.length === 0) return true;
  return list.includes(remote);
}

export default { parseAllowedGroups, isGroupAllowed };
