import fs from 'fs';
import path from 'path';
import os from 'os';
import config from './config.js';
import logger from './logger.js';

const DIR = path.join(config.root, 'logs', 'crashes');

export function reportCrash(error, context = {}) {
  try {
    fs.mkdirSync(DIR, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const mem = process.memoryUsage();
    const payload = {
      at: new Date().toISOString(),
      bot: config.botName,
      version: config.botVersion,
      node: process.version,
      platform: `${os.platform()} ${os.arch()}`,
      uptimeMs: Math.round(process.uptime() * 1000),
      memory: mem,
      error: { name: error?.name, message: error?.message, stack: error?.stack },
      context: context || {}
    };
    const file = path.join(DIR, `crash-${stamp}.json`);
    fs.writeFileSync(file, JSON.stringify(payload, null, 2));
    logger.error('crashReporter', 'diagnóstico salvo', { file });
    return file;
  } catch (e) {
    logger.error('crashReporter', `falha ao salvar diagnóstico: ${e.message}`);
    return null;
  }
}

export default { reportCrash };
