/** Configuração em runtime. Apenas chaves explicitamente permitidas podem mudar sem restart. */
const values = new Map();
const definitions = new Map();

export function defineRuntime(key, { defaultValue = null, validate = () => true, secret = false } = {}) {
  if (!definitions.has(key)) definitions.set(key, { validate, secret });
  if (!values.has(key)) values.set(key, defaultValue);
}
export function getRuntime(key, fallback = null) { return values.has(key) ? values.get(key) : fallback; }
export function setRuntime(key, value) {
  const def = definitions.get(key);
  if (!def) throw new Error(`Chave de runtime não permitida: ${key}`);
  if (!def.validate(value)) throw new Error(`Valor inválido para ${key}`);
  values.set(key, value); return value;
}
export function listRuntime({ includeSecrets = false } = {}) {
  return [...definitions.entries()].filter(([,d]) => includeSecrets || !d.secret).map(([key,d]) => ({ key, value: d.secret ? '••••••' : values.get(key), secret: d.secret }));
}
export function resetRuntime() { values.clear(); for (const [k,d] of definitions) values.set(k, d.defaultValue ?? null); }

// Chaves seguras para alteração em produção.
defineRuntime('ai.enabled', { defaultValue: true, validate: v => typeof v === 'boolean' });
defineRuntime('ai.provider', { defaultValue: process.env.AI_PROVIDER || 'auto', validate: v => typeof v === 'string' && v.length < 40 });
defineRuntime('logs.level', { defaultValue: process.env.LOG_LEVEL || 'info', validate: v => ['trace','debug','info','warn','error','silent'].includes(v) });
defineRuntime('features.dashboard', { defaultValue: true, validate: v => typeof v === 'boolean' });
defineRuntime('features.aiAgent', { defaultValue: true, validate: v => typeof v === 'boolean' });

export default { defineRuntime, getRuntime, setRuntime, listRuntime, resetRuntime };
