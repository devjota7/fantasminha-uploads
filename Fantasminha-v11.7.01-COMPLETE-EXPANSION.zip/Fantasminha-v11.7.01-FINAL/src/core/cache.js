/** Cache LRU/TTL simples e limitado para evitar Maps infinitos. */
export class TTLCache {
  constructor({ max = 1000, ttlMs = 300_000, name = 'cache' } = {}) {
    this.max = max; this.ttlMs = ttlMs; this.name = name; this.map = new Map();
  }
  get(key) {
    const item = this.map.get(key);
    if (!item) return undefined;
    if (item.expiresAt <= Date.now()) { this.map.delete(key); return undefined; }
    this.map.delete(key); this.map.set(key, item); return item.value;
  }
  set(key, value, ttlMs = this.ttlMs) {
    this.map.delete(key); this.map.set(key, { value, expiresAt: Date.now() + ttlMs });
    while (this.map.size > this.max) this.map.delete(this.map.keys().next().value);
    return value;
  }
  delete(key) { return this.map.delete(key); }
  clear() { this.map.clear(); }
  get size() { return this.map.size; }
  stats() { return { name: this.name, size: this.size, max: this.max, ttlMs: this.ttlMs }; }
}

export const caches = {
  users: new TTLCache({ max: 5000, ttlMs: 120_000, name: 'users' }),
  groups: new TTLCache({ max: 2000, ttlMs: 120_000, name: 'groups' }),
  generic: new TTLCache({ max: 2000, ttlMs: 300_000, name: 'generic' })
};

setInterval(() => {
  for (const cache of Object.values(caches)) {
    for (const key of [...cache.map.keys()]) cache.get(key);
  }
}, 60_000).unref?.();

export default { TTLCache, caches };
