/** Contexto de mensagem unificado. Mantém compatibilidade com o ctx legado. */
export function enrichMessageContext(ctx = {}) {
  if (!ctx || typeof ctx !== 'object') return ctx;
  if (!ctx.send) {
    ctx.send = {
      text: async (text, options = {}) => {
        if (typeof ctx.sendMessage === 'function' && ctx.from) {
          return ctx.sendMessage(ctx.from, { text: String(text), ...options });
        }
        return ctx.reply?.(text);
      },
      to: async (jid, content, options = {}) => ctx.sendMessage?.(jid, content, options),
      reaction: async () => null // reações automáticas desativadas; use ×react
    };
  }
  if (!ctx.media) {
    ctx.media = {
      isImage: !!ctx.message?.message?.imageMessage,
      isVideo: !!ctx.message?.message?.videoMessage,
      isAudio: !!ctx.message?.message?.audioMessage,
      isSticker: !!ctx.message?.message?.stickerMessage,
      quoted: ctx.message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null
    };
  }
  ctx.retry ??= async (fn, options) => (await import('./retry.js')).withRetry(fn, options);
  return ctx;
}
export default { enrichMessageContext };
