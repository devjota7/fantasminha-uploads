/**
 * Cooldown central por usuário + comando
 */
const buckets = new Map();

function key(userId, command) {
  return `${userId || 'anon'}:${command || '*'}`;
}

export function checkCooldown(userId, command, seconds = 0) {
  if (!seconds || seconds <= 0) return { ok: true, remaining: 0 };
  const k = key(userId, command);
  const until = buckets.get(k) || 0;
  const now = Date.now();
  if (now < until) {
    return { ok: false, remaining: Math.ceil((until - now) / 1000) };
  }
  return { ok: true, remaining: 0 };
}

export function setCooldown(userId, command, seconds = 0) {
  if (!seconds || seconds <= 0) return;
  buckets.set(key(userId, command), Date.now() + seconds * 1000);
}

export function clearCooldown(userId, command) {
  buckets.delete(key(userId, command));
}

/** limpeza periódica */
setInterval(() => {
  const now = Date.now();
  for (const [k, until] of buckets) {
    if (until < now) buckets.delete(k);
  }
}, 60_000).unref?.();

export default { checkCooldown, setCooldown, clearCooldown };
