import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import * as global from './globalClans.js';
import * as clanWorld from './clanWorld.js';

const DEFAULT = {
  current: null,
  seasons: [],
  records: {},
  eras: [{ id:'era-1', name:'Era I — O Despertar', startedAt: Date.now(), seasonWins:{} }],
  activity: {},
  bosses: {},
  cup: null
};
const DAY = 86_400_000;
const PREP = 15 * DAY;
const WAR = 15 * DAY;
const clean = v => String(v ?? '').trim();
const uid = v => clean(v).replace(/[^a-zA-Z0-9:_-]/g,'').slice(0,80);
const now = () => Date.now();
const clamp = (n,min,max) => Math.max(min, Math.min(max,n));

function scoreValue(c, world) {
  const territories = world?.territories?.length || 0;
  const defense = Object.values(world?.buildings || {}).reduce((s,v)=>s + Number(v||0),0);
  const treasury = Math.floor((world?.treasury||0) / 1000);
  return (c.wins||0)*100 + (c.xp||0)/10 + territories*150 + defense*30 + treasury;
}
function phaseOf(season, t=now()) {
  if (!season) return 'preparation';
  if (t < season.preparationEndsAt) return 'preparation';
  if (t < season.warEndsAt) return 'war';
  return 'finished';
}
function leagueFor(clan, all) {
  const sorted = [...all].sort((a,b)=>scoreValue(b,b._world)-scoreValue(a,a._world));
  const i = Math.max(0, sorted.findIndex(x=>x.id===clan.id));
  const n = sorted.length || 1;
  if (i < Math.ceil(n*.1)) return 'Soberana';
  if (i < Math.ceil(n*.35)) return 'Abismo';
  if (i < Math.ceil(n*.7)) return 'Espírito';
  return 'Alma';
}
function makeSeason(start=now()) {
  const id = `GDA-${new Date(start).toISOString().slice(0,10)}-${Math.random().toString(36).slice(2,7).toUpperCase()}`;
  return { id, number: 1, startedAt:start, preparationEndsAt:start+PREP, warEndsAt:start+PREP+WAR, status:'preparation', scores:{}, players:{}, battles:[], objectives:{}, createdAt:start, finalizedAt:null };
}

export function getState() { return readCollection('clan_championship', DEFAULT); }
export function current() { return getState().current; }

export async function ensureSeason() {
  return updateCollection('clan_championship', C => {
    if (!C.current) {
      const latest = C.seasons?.length || 0;
      C.current = makeSeason(now());
      C.current.number = latest + 1;
    }
    const phase = phaseOf(C.current);
    C.current.status = phase;
    return C;
  }, DEFAULT);
}

function ensureClanScore(S, clanId) {
  S.scores ||= {};
  if (!S.scores[clanId]) S.scores[clanId] = { total:0, combat:0, domain:0, missions:0, bosses:0, defense:0, economy:0, participation:0, wins:0, losses:0, territoriesPeak:0 };
  return S.scores[clanId];
}
function ensurePlayer(S, userId, clanId) {
  S.players ||= {};
  if (!S.players[userId]) S.players[userId] = { userId, clanId, points:0, combat:0, missions:0, boss:0, defense:0, participation:0, lastActionAt:0, actions:0 };
  S.players[userId].clanId = clanId;
  return S.players[userId];
}

function standingsFromState(C, S) {
  const clans=global.listGlobalClans(100).map(c=>{const x=clanWorld.get(c.id)||{}; return {...c,_world:x};});
  return clans.map(c=>{const s=S.scores?.[c.id]||{total:0}; return { ...c, league:leagueFor(c,clans), score:s.total||0, breakdown:s, territories:c._world.territories?.length||0 }; }).sort((a,b)=>b.score-a.score || (b.xp||0)-(a.xp||0));
}

function finalizeInside(C) {
  const S=C.current; if(!S || S.finalizedAt) return false;
  const table=standingsFromState(C,S), top=table.slice(0,8), winner=table[0];
  const seasonRecord={id:S.id,number:S.number,startedAt:S.startedAt,finishedAt:now(),winnerId:winner?.id||null,winnerName:winner?.name||null,top:table.slice(0,10).map(x=>({id:x.id,name:x.name,score:x.score,league:x.league})),championMvp:Object.values(S.players||{}).sort((a,b)=>b.points-a.points)[0]||null};
  C.seasons ||= []; C.seasons.push(seasonRecord); C.records ||= {};
  if(winner){ C.records.mostChampionships ||= {}; C.records.mostChampionships[winner.id]=(C.records.mostChampionships[winner.id]||0)+1; C.records.bestScore=Math.max(C.records.bestScore||0,winner.score); }
  C.cup={seasonId:S.id,bracket:top.map((x,i)=>({seed:i+1,clanId:x.id,name:x.name,status:i<2?'finalist':'qualified'})),championId:top[0]?.id||null};
  const era=C.eras?.at(-1); if(era){ era.seasonWins ||= {}; if(winner) era.seasonWins[winner.id]=(era.seasonWins[winner.id]||0)+1; }
  if(C.seasons.length>=5 && (!C.eras?.at(-1)?.seasonWins || Object.keys(C.eras.at(-1).seasonWins).length>=3)){ const nextNo=(C.eras?.length||1)+1; const romans=['I','II','III','IV','V','VI','VII','VIII','IX','X']; C.eras ||= []; C.eras.push({id:`era-${nextNo}`,name:`Era ${romans[nextNo-1]||nextNo} — ${nextNo%2?'A Ruptura do Véu':'Ascensão das Dinastias'}`,startedAt:now(),seasonWins:{}}); }
  S.finalizedAt=now(); S.status='finished'; C.current=makeSeason(now()); C.current.number=C.seasons.length+1; return true;
}

export async function tick() {
  return updateCollection('clan_championship', C => {
    if (!C.current) { C.current=makeSeason(now()); C.current.number=(C.seasons?.length||0)+1; return C; }
    const phase=phaseOf(C.current); C.current.status=phase;
    if(phase==='finished') finalizeInside(C);
    return C;
  }, DEFAULT);
}

export async function participate(userId) {
  const c = global.getGlobalClanOf(userId);
  if (!c) throw new ValidationError('Você precisa pertencer a um Clã Global.');
  await ensureSeason();
  return updateCollection('clan_championship', C => {
    const S=C.current; if (phaseOf(S)==='finished') throw new ValidationError('A temporada terminou. Aguarde o próximo ciclo.');
    const p=ensurePlayer(S,userId,c.id); p.participation++; p.points+=5; p.actions++;
    const s=ensureClanScore(S,c.id); s.participation+=5; s.total+=5;
    return C;
  }, DEFAULT);
}

export async function contribute(userId, amount=1) {
  const c=global.getGlobalClanOf(userId); if(!c) throw new ValidationError('Sem Clã Global.');
  await ensureSeason();
  amount=clamp(Math.floor(Number(amount)||1),1,20);
  return updateCollection('clan_championship', C=>{
    const S=C.current; if(phaseOf(S)!=='war') throw new ValidationError('A contribuição de guerra só funciona durante os 15 dias de guerra.');
    const p=ensurePlayer(S,userId,c.id); const s=ensureClanScore(S,c.id);
    const gain=amount*10; p.points+=gain; p.combat+=gain; p.actions+=amount; p.lastActionAt=now(); s.total+=gain; s.combat+=gain; s.wins+=amount;
    S.battles.push({at:now(),type:'contribution',clanId:c.id,userId,points:gain});
    if(S.battles.length>1000) S.battles=S.battles.slice(-1000);
    return C;
  }, DEFAULT);
}

export async function battle(userId, targetId, style='normal') {
  const c=global.getGlobalClanOf(userId); if(!c) throw new ValidationError('Sem Clã Global.');
  const target=global.getGlobalClan(targetId); if(!target) throw new ValidationError('Clã alvo não encontrado.');
  if(target.id===c.id) throw new ValidationError('Você não pode atacar seu próprio clã.');
  await ensureSeason();
  return updateCollection('clan_championship', C=>{
    const S=C.current; if(phaseOf(S)!=='war') throw new ValidationError('Ataques só podem ocorrer durante a fase de guerra.');
    const p=ensurePlayer(S,userId,c.id), s=ensureClanScore(S,c.id), e=ensureClanScore(S,target.id);
    const world=clanWorld.get(c.id)||{}; const enemyWorld=clanWorld.get(target.id)||{};
    const power=(c.power||100)+(world.buildings?.muralha||0)*10+(world.territories?.length||0)*20;
    const enemy=(target.power||100)+(enemyWorld.buildings?.muralha||0)*10+(enemyWorld.territories?.length||0)*20;
    const bonus=style==='forte'?18:style==='especial'?30:10;
    const ratio=power/(power+enemy||1);
    const win=((userId.length*31 + S.battles.length*17) % 100)/100 < ratio;
    const gain=win?bonus:Math.max(3,Math.floor(bonus/3));
    p.points+=gain; p.combat+=gain; p.actions++; p.lastActionAt=now(); s.total+=gain; s.combat+=gain;
    if(win){s.wins++; e.losses++; e.total=Math.max(0,e.total-3);} else {s.losses++; e.wins++;}
    S.battles.push({at:now(),type:'battle',attacker:c.id,target:target.id,userId,style,result:win?'win':'loss',points:gain});
    if(S.battles.length>1000) S.battles=S.battles.slice(-1000);
    return { result:win?'win':'loss', points:gain, attacker:c, target, scores:S.scores };
  }, DEFAULT);
}

export async function scoreEvent(clanId, category, points) {
  points=Math.floor(Number(points)||0); if(points<=0) return getState();
  await ensureSeason();
  return updateCollection('clan_championship', C=>{ const s=ensureClanScore(C.current,clanId); s[category]=(s[category]||0)+points; s.total+=points; return C;},DEFAULT);
}

export async function bossAttack(userId, bossId='rei-abismo') {
  const c=global.getGlobalClanOf(userId); if(!c) throw new ValidationError('Sem Clã Global.');
  await ensureSeason();
  return updateCollection('clan_championship', C=>{
    const S=C.current; if(phaseOf(S)!=='war') throw new ValidationError('O Boss Global só pode ser enfrentado durante a guerra.');
    C.bosses ||= {}; const b=C.bosses[bossId] ||= {id:bossId,name:'Rei do Abismo',hp:100000,maxHp:100000,season:S.id,damage:0,contributors:{}};
    if(b.season!==S.id){ b.season=S.id;b.hp=100000;b.maxHp=100000;b.damage=0;b.contributors={}; }
    const dmg=250+(c.power||100); b.hp=Math.max(0,b.hp-dmg); b.damage+=dmg; b.contributors[c.id]=(b.contributors[c.id]||0)+dmg;
    const s=ensureClanScore(S,c.id), p=ensurePlayer(S,userId,c.id); const pts=Math.floor(dmg/25); s.bosses+=pts;s.total+=pts;p.boss+=pts;p.points+=pts;
    return {boss:b,damage:dmg,points:pts};
  },DEFAULT);
}

export function standings(limit=50) { const C=getState(), S=C.current; if(!S) return []; return standingsFromState(C,S).slice(0,limit); }
export function playerRank(limit=20){ const S=getState().current; return Object.values(S?.players||{}).sort((a,b)=>b.points-a.points).slice(0,limit); }

export async function finalize() { return updateCollection('clan_championship', C => { if(!C.current) return C; if(phaseOf(C.current)!=='finished') throw new ValidationError('A temporada ainda não terminou.'); finalizeInside(C); return C; }, DEFAULT); }
export function history(limit=20){return getState().seasons?.slice(-limit).reverse()||[];}
export function records(){return getState().records||{};}
export function era(){const C=getState();return C.eras?.at(-1)||null;}
export function boss(bossId='rei-abismo'){return getState().bosses?.[bossId]||null;}
export function cup(){return getState().cup||null;}
export function phaseInfo(){const S=current(); if(!S) return null; const phase=phaseOf(S); const end=phase==='preparation'?S.preparationEndsAt:S.warEndsAt; return {season:S.number,id:S.id,phase,endsAt:end,remainingMs:Math.max(0,end-now()),preparationEndsAt:S.preparationEndsAt,warEndsAt:S.warEndsAt};}
export default {getState,current,ensureSeason,tick,participate,contribute,battle,scoreEvent,bossAttack,standings,playerRank,finalize,history,records,era,boss,cup,phaseInfo};
