import { createIncident } from '../platform/incidents/index.js';
import { readCollection, updateCollection } from '../database/store.js';

const DEFAULTS = { groups: {} };
export function getConfig(group) { return readCollection('anti_scam', DEFAULTS).groups?.[group] || { enabled:false, action:'alert' }; }
export async function setConfig(group, patch={}) { let out; await updateCollection('anti_scam', d => { d.groups ??= {}; d.groups[group] = { ...getConfig(group), ...patch, updatedAt:Date.now() }; out=d.groups[group]; return d; }, DEFAULTS); return out; }

const CATEGORIES = [
  ['phishing', [/\b(verify|confirm|validate)\b.{0,50}\b(account|password|otp|code|pin)\b/i, /\b(otp|password|pin)\b.{0,30}\b(send|share|enter)\b/i]],
  ['giveaway', [/\b(congratulations|you won|winner|prize)\b.{0,60}\b(claim|click|link)\b/i, /\bfree\b.{0,25}\b(iphone|money|cash|gift)\b/i]],
  ['investment', [/\b(guaranteed|daily|weekly)\b.{0,25}\b(profit|return|income|roi)\b/i, /\bdouble\b.{0,25}\b(money|investment)\b/i, /\bponzi\b|\bpyramid scheme\b/i]],
  ['money-mule', [/\btransfer\b.{0,30}\b(money|funds|cash)\b.{0,30}\b(for me|on my behalf)\b/i]],
  ['fake-job', [/\b(work from home|part[- ]time job|data entry)\b.{0,50}\b(earn|salary|money)\b/i]]
];

export function analyzeScam(text = '') {
  const value = String(text);
  const hits = [];
  for (const [category, patterns] of CATEGORIES) {
    for (const pattern of patterns) if (pattern.test(value)) { hits.push(category); break; }
  }
  const unique = [...new Set(hits)];
  const score = Math.min(100, unique.length * 24 + (/\bhttps?:\/\//i.test(value) ? 15 : 0) + (/\b(otp|password|pin|wallet|seed phrase)\b/i.test(value) ? 20 : 0));
  return { score, categories: unique, risk: score >= 80 ? 'critical' : score >= 60 ? 'high' : score >= 30 ? 'medium' : 'low', detected: score >= 30 };
}

export async function reportScam({ text, group, sender, actor = 'anti-scam' } = {}) {
  const result = analyzeScam(text);
  if (result.detected) {
    await createIncident({
      title: `Possível golpe: ${result.categories.join(', ')}`,
      severity: result.score >= 80 ? 'P1' : result.score >= 60 ? 'P2' : 'P3',
      source: 'anti-scam',
      actor,
      details: { group, sender, score: result.score, risk: result.risk, categories: result.categories }
    });
  }
  return result;
}
export default { analyzeScam, reportScam, getConfig, setConfig };
