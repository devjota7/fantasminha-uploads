import { readCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import { transact } from '../platform/transactions/index.js';

export async function listOffers() {
  const M = readCollection('market', { offers: [] });
  return (M.offers || []).filter(o => o.active !== false);
}

export async function createOffer(sellerId, itemId, price, qty = 1, sellerName = '') {
  const p = Math.floor(Number(price));
  const q = Math.floor(Number(qty));
  if (!itemId || !Number.isInteger(p) || p <= 0 || !Number.isInteger(q) || q <= 0 || q > 100000 || p * q > Number.MAX_SAFE_INTEGER) throw new ValidationError('anunciar <item> <preço> [qtd] — quantidade deve ser positiva.');
  let id = '';
  await transact([
    { collection: 'users', update: users => {
      users.byId ??= {}; const u = users.byId[sellerId];
      if (!u) throw new ValidationError('Usuário não encontrado.');
      u.economy ??= {}; u.economy.inventory ??= {};
      if ((u.economy.inventory[itemId] || 0) < q) throw new ValidationError('Sem item no inventário.');
      u.economy.inventory[itemId] -= q; if (u.economy.inventory[itemId] <= 0) delete u.economy.inventory[itemId];
      if (sellerName) u.name = sellerName; users.byId[sellerId] = u; return users;
    }},
    { collection: 'market', update: M => { M.offers ??= []; id = `o${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`; M.offers.push({ id, sellerId, sellerName, itemId, price:p, qty:q, active:true, at:Date.now() }); return M; }}
  ], { actor: sellerId, type: 'market.create', itemId, qty:q, price:p });
  return id;
}

export async function buyOffer(buyerId, offerId, buyerName = '') {
  let purchased;
  await transact([
    { collection: 'market', update: M => {
      M.offers ??= []; const offer = M.offers.find(o => o.id === offerId && o.active !== false);
      if (!offer) throw new ValidationError('Oferta não encontrada ou já vendida.');
      if (offer.sellerId === buyerId) throw new ValidationError('Não compra a própria oferta.');
      if (!Number.isInteger(offer.qty) || offer.qty <= 0 || offer.qty > 100000 || !Number.isFinite(offer.price) || offer.price <= 0 || offer.price * offer.qty > Number.MAX_SAFE_INTEGER) throw new ValidationError('Oferta inválida.');
      purchased = { ...offer }; offer.active = false; offer.soldAt = Date.now(); return M;
    }},
    { collection: 'users', update: users => {
      users.byId ??= {}; const buyer = users.byId[buyerId];
      if (!buyer) throw new ValidationError('Usuário comprador não encontrado.');
      const sellerId = purchased?.sellerId;
      if (!sellerId) return users;
      const seller = users.byId[sellerId];
      if (!seller) throw new ValidationError('Vendedor não encontrado.');
      buyer.economy ??= {}; seller.economy ??= {}; buyer.economy.inventory ??= {};
      const total = purchased.price * purchased.qty;
      if ((buyer.economy.wallet || 0) < total) throw new ValidationError('GC insuficientes.');
      buyer.economy.wallet -= total; seller.economy.wallet = Math.min(50_000_000, (seller.economy.wallet || 0) + total);
      buyer.economy.inventory[purchased.itemId] = (buyer.economy.inventory[purchased.itemId] || 0) + purchased.qty;
      if (buyerName) buyer.name = buyerName; users.byId[buyerId] = buyer; users.byId[sellerId] = seller; return users;
    }},
    { collection: 'economy_ledger', update: L => { L.entries ??= []; if (!purchased) throw new ValidationError('Oferta inválida.'); const total=purchased.price*purchased.qty; L.entries.push({userId:buyerId,amount:-total,reason:'market_buy',offerId,at:Date.now()},{userId:purchased.sellerId,amount:total,reason:'market_sell',offerId,at:Date.now()}); if(L.entries.length>5000)L.entries=L.entries.slice(-3000); return L; }}
  ], { actor: buyerId, type: 'market.buy', offerId });
  return purchased;
}

export default { listOffers, createOffer, buyOffer };
