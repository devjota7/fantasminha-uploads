import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import { addClanXp } from './globalClans.js';
import { addGroupWarXp } from './groupClans.js';

const DEFAULT = { byId: {}, history: [] };
const DAY = 24 * 60 * 60 * 1000;
const now = () => Date.now();
const warId = (type, a, b) => `${type}-${now().toString(36)}-${Math.random().toString(36).slice(2,8)}`;

function durationDays(value) {
  const n = Math.floor(Number(value));
  if (!Number.isInteger(n) || n < 1 || n > 5) throw new ValidationError('A duração da guerra deve ser de 1 a 5 dias.');
  return n;
}

function scorePower(entity, memberCount = 1) {
  return 100 + (entity.level || 1) * 25 + memberCount * 8;
}

export async function createChallenge({ type, attackerId, defenderId, duration, attackerName, defenderName, attackerMembers = [], defenderMembers = [] }) {
  if (!attackerId || !defenderId || attackerId === defenderId) throw new ValidationError('Adversário inválido.');
  const days = durationDays(duration);
  return updateCollection('wars', W => {
    W.byId ||= {}; W.history ||= [];
    const existing = Object.values(W.byId).find(w => w.status === 'pending' && ((w.attackerId === attackerId && w.defenderId === defenderId) || (w.attackerId === defenderId && w.defenderId === attackerId)));
    if (existing) throw new ValidationError('Já existe um desafio pendente entre esses lados.');
    const id = warId(type, attackerId, defenderId);
    W.byId[id] = {
      id, type, status: 'pending', attackerId, defenderId,
      attackerName, defenderName, durationDays: days,
      preparationMs: Math.min(12 * 60 * 60 * 1000, Math.max(60 * 60 * 1000, Math.floor(days * DAY / 8))),
      maxParticipants: Math.min(50, Math.max(5, Math.min(attackerMembers.length || 5, defenderMembers.length || 5))),
      participants: { attacker: [...new Set(attackerMembers)], defender: [...new Set(defenderMembers)] },
      score: { attacker: 0, defender: 0 }, attacks: [], createdAt: now(), updatedAt: now()
    };
    return W;
  }, DEFAULT);
}

export async function acceptChallenge(warIdValue, sideId) {
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || w.status !== 'pending') throw new ValidationError('Guerra/desafio não encontrado ou já resolvido.');
    if (![w.defenderId, w.attackerId].includes(sideId)) throw new ValidationError('Este lado não pode aceitar esta guerra.');
    w.status = 'preparation'; w.acceptedAt = now(); w.startsAt = now() + w.preparationMs; w.endsAt = w.startsAt + w.durationDays * DAY; w.updatedAt = now();
    return W;
  }, DEFAULT);
}

export async function rejectChallenge(warIdValue, sideId) {
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || w.status !== 'pending') throw new ValidationError('Desafio não encontrado.');
    if (![w.defenderId, w.attackerId].includes(sideId)) throw new ValidationError('Sem autoridade neste desafio.');
    w.status = 'rejected'; w.rejectedAt = now(); w.updatedAt = now();
    W.history ||= []; W.history.push({ ...w, archivedAt: now() }); delete W.byId[warIdValue];
    return W;
  }, DEFAULT);
}

export async function syncWarStates() {
  const changes = [];
  await updateCollection('wars', W => {
    W.byId ||= {}; W.history ||= [];
    for (const [id, w] of Object.entries(W.byId)) {
      if (w.status === 'pending' && now() - w.createdAt > 48 * 60 * 60 * 1000) {
        w.status = 'expired'; w.finishedAt = now(); W.history.push({ ...w, archivedAt: now() }); delete W.byId[id]; changes.push({ type:'expired', war:w }); continue;
      }
      if (w.status === 'preparation' && now() >= w.startsAt) { w.status = 'active'; w.updatedAt = now(); changes.push({ type:'started', war:w }); }
      if (w.status === 'active' && now() >= w.endsAt) {
        const winner = w.score.attacker === w.score.defender ? 'draw' : (w.score.attacker > w.score.defender ? 'attacker' : 'defender');
        w.status = 'finished'; w.winner = winner; w.finishedAt = now();
        W.history.push({ ...w, archivedAt: now() }); delete W.byId[id]; changes.push({ type:'finished', war:w });
      }
    }
    if (W.history.length > 1000) W.history = W.history.slice(-800);
    return W;
  }, DEFAULT);
  for (const c of changes) {
    const w = c.war;
    if (c.type !== 'finished') continue;
    const winnerId = w.winner === 'attacker' ? w.attackerId : w.winner === 'defender' ? w.defenderId : null;
    const loserId = w.winner === 'attacker' ? w.defenderId : w.winner === 'defender' ? w.attackerId : null;
    if (w.type === 'global') {
      if (winnerId) await updateCollection('global_clans', C => { const win=C.byId?.[winnerId], lose=C.byId?.[loserId]; if(win) win.wins=(win.wins||0)+1; if(lose) lose.losses=(lose.losses||0)+1; return C; }, {byId:{},byMember:{}});
      if (w.winner === 'attacker') { await addClanXp(w.attackerId, 250); await addClanXp(w.defenderId, 100); }
      else if (w.winner === 'defender') { await addClanXp(w.defenderId, 250); await addClanXp(w.attackerId, 100); }
      else { await addClanXp(w.attackerId, 150); await addClanXp(w.defenderId, 150); }
    } else {
      if (winnerId) await updateCollection('group_clans', C => { const win=C.byId?.[winnerId], lose=C.byId?.[loserId]; if(win) win.wins=(win.wins||0)+1; if(lose) lose.losses=(lose.losses||0)+1; return C; }, {byId:{}});
      if (w.winner === 'attacker') { await addGroupWarXp(w.attackerId, 250); await addGroupWarXp(w.defenderId, 100); }
      else if (w.winner === 'defender') { await addGroupWarXp(w.defenderId, 250); await addGroupWarXp(w.attackerId, 100); }
      else { await addGroupWarXp(w.attackerId, 150); await addGroupWarXp(w.defenderId, 150); }
    }
  }
  return changes;
}

export function getWar(id) { return readCollection('wars', DEFAULT).byId?.[id] || null; }
export function listWars(type = null) {
  const W = readCollection('wars', DEFAULT);
  return Object.values(W.byId || {}).filter(w => !type || w.type === type).sort((a,b) => b.createdAt-a.createdAt);
}
export function listHistory(type = null, limit = 10) {
  const W = readCollection('wars', DEFAULT);
  return (W.history || []).filter(w => !type || w.type === type).slice(-Math.min(50, Math.max(1, limit))).reverse();
}

export async function joinWar(warIdValue, side, userId) {
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || !['preparation','active'].includes(w.status)) throw new ValidationError('Guerra não está aceitando participantes.');
    if (!['attacker','defender'].includes(side)) throw new ValidationError('Lado inválido.');
    const arr = w.participants[side] ||= [];
    if (!arr.includes(userId) && arr.length >= w.maxParticipants) throw new ValidationError(`Limite de ${w.maxParticipants} participantes atingido neste lado.`);
    if (!arr.includes(userId)) arr.push(userId);
    w.updatedAt = now(); return W;
  }, DEFAULT);
}

export async function leaveWar(warIdValue, side, userId) {
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || w.status !== 'preparation') throw new ValidationError('Só é possível sair durante a preparação.');
    w.participants[side] = (w.participants[side] || []).filter(id => id !== userId); w.updatedAt = now(); return W;
  }, DEFAULT);
}

export async function attack(warIdValue, side, userId, kind = 'normal') {
  const kinds = { normal:{cost:10, points:[40,80]}, forte:{cost:20,points:[70,120]}, especial:{cost:35,points:[110,180]} };
  const k = kinds[kind] || kinds.normal;
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || w.status !== 'active') throw new ValidationError('A guerra não está ativa.');
    if (!w.participants?.[side]?.includes(userId)) throw new ValidationError('Você não está inscrito no lado desta guerra.');
    const last = [...(w.attacks || [])].reverse().find(a => a.userId === userId);
    if (last && now() - last.at < 10 * 60 * 1000) throw new ValidationError('Seu próximo ataque estará disponível em alguns minutos.');
    const points = k.points[0] + Math.floor(Math.random() * (k.points[1]-k.points[0]+1));
    w.score[side] = (w.score[side] || 0) + points;
    w.attacks ||= []; w.attacks.push({ userId, side, kind, points, at: now() });
    if (w.attacks.length > 5000) w.attacks = w.attacks.slice(-3000);
    w.updatedAt = now(); return W;
  }, DEFAULT);
}


export async function defend(warIdValue, side, userId) {
  return updateCollection('wars', W => {
    const w = W.byId?.[warIdValue];
    if (!w || w.status !== 'active') throw new ValidationError('A guerra não está ativa.');
    if (!w.participants?.[side]?.includes(userId)) throw new ValidationError('Você não está inscrito neste lado.');
    const last = [...(w.defenses || [])].reverse().find(a => a.userId === userId);
    if (last && now() - last.at < 10 * 60 * 1000) throw new ValidationError('Sua próxima defesa estará disponível em alguns minutos.');
    const points = 25 + Math.floor(Math.random() * 46);
    w.score[side] = (w.score[side] || 0) + points;
    w.defenses ||= []; w.defenses.push({ userId, side, points, at: now() });
    if (w.defenses.length > 5000) w.defenses = w.defenses.slice(-3000);
    w.updatedAt = now(); return W;
  }, DEFAULT);
}

export function powerPreview(entity, members = 0) { return scorePower(entity, members); }
export { DAY };
