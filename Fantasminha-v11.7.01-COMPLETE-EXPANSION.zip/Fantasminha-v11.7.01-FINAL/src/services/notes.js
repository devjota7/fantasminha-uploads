import { readCollection, updateCollection } from '../database/store.js';
const DEFAULTS={items:{}};
const keyOf=(scope,name)=>`${scope}::${String(name||'').trim().toLowerCase().slice(0,60)}`;
export function listNotes(scope){return Object.values(readCollection('notes',DEFAULTS).items||{}).filter(x=>x.scope===scope).sort((a,b)=>b.updatedAt-a.updatedAt);}
export async function upsertNote({scope,name,text,actor}={}){if(!scope||!name||!text)throw new Error('Nota inválida');const key=keyOf(scope,name);await updateCollection('notes',d=>{d.items??={};d.items[key]={scope,name:String(name).trim().slice(0,60),text:String(text).trim().slice(0,4000),actor,updatedAt:Date.now()};return d;},DEFAULTS);return listNotes(scope).find(x=>keyOf(x.scope,x.name)===key);}
export async function removeNote(scope,name){let removed=false;const key=keyOf(scope,name);await updateCollection('notes',d=>{if(d.items?.[key]){delete d.items[key];removed=true;}return d;},DEFAULTS);return removed;}
export default{listNotes,upsertNote,removeNote};
