import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';

const DEFAULT = { byClan:{}, diplomacy:{}, territories:{}, hall:[], logs:[] };
const now = () => Date.now();
const clean = v => String(v||'').trim();
const idKey = v => clean(v).toLowerCase().replace(/[^a-z0-9_-]/gi,'').slice(0,32);
const TERRITORIES = [
  {id:'cemiterio',name:'Cemitério Antigo',income:250,defense:50},
  {id:'floresta',name:'Floresta Sombria',income:400,defense:80},
  {id:'purgatorio',name:'Purgatório',income:650,defense:120},
  {id:'abismo',name:'Abismo',income:1000,defense:180},
  {id:'reino',name:'Reino dos Mortos',income:1500,defense:250}
];
const BUILDINGS = { sede:{name:'Sede',max:5,base:1000}, muralha:{name:'Muralha',max:5,base:1500}, mina:{name:'Mina Espiritual',max:5,base:1800}, oficina:{name:'Oficina',max:5,base:2000}, santuario:{name:'Santuário',max:5,base:2500} };
function normalize(c){ c.members ||= []; c.territories ||= []; c.buildings ||= {}; c.roles ||= {}; c.alliances ||= []; c.mascot ||= null; c.treasury ||= 0; c.missions ||= []; c.legacy ||= 0; c.hall ||= []; c.logs ||= []; return c; }
export function get(clanId){ return readCollection('clan_world',DEFAULT).byClan?.[clanId] || null; }
export async function ensure(clan){
  if(!clan?.id) throw new ValidationError('Clã inválido.');
  return updateCollection('clan_world', C=>{ C.byClan ||= {}; let x=C.byClan[clan.id]; if(!x){ x={id:clan.id,name:clan.name,territories:[],buildings:{sede:1},roles:{},alliances:[],mascot:null,treasury:clan.bank||0,missions:[],legacy:0,hall:[],createdAt:now()}; C.byClan[clan.id]=x; } normalize(x); x.name=clan.name; return C; },DEFAULT).then(C=>C.byClan[clan.id]);
}
export async function setRole(clan,userId,target,role){
 return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; if(!x) throw new ValidationError('Expansão do clã não inicializada.'); normalize(x); if(!x.members?.includes(target)) throw new ValidationError('O usuário não é membro do clã.'); const roles=['membro','recruta','capitao','general','conselheiro','tesoureiro','guardiao','vice']; if(!roles.includes(role)) throw new ValidationError(`Cargo inválido. Use: ${roles.join(', ')}`); x.roles[target]=role; x.logs.push({at:now(),type:'role',by:userId,target,role}); return C;},DEFAULT);
}
export async function build(clan,building){ return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; normalize(x); const b=BUILDINGS[building]; if(!b) throw new ValidationError('Construção inválida.'); const lvl=x.buildings[building]||0; if(lvl>=b.max) throw new ValidationError('Essa construção já atingiu o nível máximo.'); const cost=b.base*(lvl+1); if((x.treasury||0)<cost) throw new ValidationError(`Tesouro insuficiente. Custo: ${cost} GC.`); x.treasury-=cost; x.buildings[building]=lvl+1; x.logs.push({at:now(),type:'build',building,level:lvl+1,cost}); return C;},DEFAULT); }
export async function claimTerritory(clan,territory){ return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; normalize(x); const t=TERRITORIES.find(a=>a.id===territory); if(!t) throw new ValidationError('Território desconhecido.'); const owner=Object.values(C.byClan||{}).find(a=>a.territories?.includes(t.id)); if(owner && owner.id!==clan.id) throw new ValidationError(`Território controlado por ${owner.name}.`); if(x.territories.includes(t.id)) throw new ValidationError('Seu clã já controla esse território.'); if((x.treasury||0)<t.income*4) throw new ValidationError(`Custo de anexação: ${t.income*4} GC.`); x.treasury-=t.income*4; x.territories.push(t.id); x.logs.push({at:now(),type:'territory',territory:t.id}); return C;},DEFAULT); }
export async function deposit(clan,amount){amount=Math.floor(Number(amount)||0); if(amount<=0) throw new ValidationError('Valor inválido.'); return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; normalize(x); x.treasury+=amount; return C;},DEFAULT);}
export async function collectIncome(clan){ return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; normalize(x); const income=x.territories.reduce((s,id)=>s+(TERRITORIES.find(t=>t.id===id)?.income||0),0); const bonus=(x.buildings.mina||0)*100+(x.buildings.oficina||0)*75; const total=income+bonus; x.treasury+=total; x.lastIncome={at:now(),total}; return C;},DEFAULT); }
export async function diplomacy(clan,other,action){ return updateCollection('clan_world',C=>{C.diplomacy ||= {}; const key=[clan.id,other.id].sort().join(':'); const valid=['alianca','trégua','embargo','guerra']; if(!valid.includes(action)) throw new ValidationError('Diplomacia: alianca, trégua, embargo ou guerra.'); C.diplomacy[key]={a:clan.id,b:other.id,status:action,updatedAt:now()}; return C;},DEFAULT); }
export async function mascot(clan,name,species='espírito'){ return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id]; normalize(x); if(x.mascot && x.mascot.name===name) throw new ValidationError('Esse mascote já está registrado.'); x.mascot={name:clean(name).slice(0,24),species:clean(species).slice(0,20)||'espírito',level:1,xp:0,createdAt:now()}; return C;},DEFAULT); }
export async function mission(clan,title,reward=500){return updateCollection('clan_world',C=>{const x=C.byClan?.[clan.id];normalize(x); if(x.missions.some(m=>m.active)) throw new ValidationError('Já existe uma missão ativa.'); x.missions.push({id:`m${now()}`,title:clean(title).slice(0,100),reward:Math.max(100,Math.floor(Number(reward)||500)),progress:0,target:10,active:true,createdAt:now()}); return C;},DEFAULT);}
export function territories(){return TERRITORIES;}
export function buildings(){return BUILDINGS;}
export function rank(limit=10){const C=readCollection('clan_world',DEFAULT);return Object.values(C.byClan||{}).map(normalize).sort((a,b)=>((b.territories?.length||0)-(a.territories?.length||0))||((b.treasury||0)-(a.treasury||0))||((b.legacy||0)-(a.legacy||0))).slice(0,limit);}
