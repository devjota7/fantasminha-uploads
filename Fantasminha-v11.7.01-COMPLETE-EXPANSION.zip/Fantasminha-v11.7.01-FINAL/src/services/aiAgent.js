/** Intent Router determinístico; APIs de IA podem alimentá-lo sem ganhar execução irrestrita. */
const intents = [
  { id: 'status', patterns: [/\b(status|ping|saúde|health)\b/i], command: 'status' },
  { id: 'menu', patterns: [/\b(menu|comandos|o que você faz)\b/i], command: 'ajuda' },
  { id: 'economy', patterns: [/\b(saldo|dinheiro|economia|carteira)\b/i], command: 'saldo' },
  { id: 'rpg', patterns: [/\brpg\b|\baventura\b/i], command: 'perfilrpg' },
  { id: 'games', patterns: [/\b(jogo|jogar|game)\b/i], command: 'jogos' }
];

export function resolveIntent(text = '', available = new Set()) {
  for (const intent of intents) {
    if (intent.patterns.some(p => p.test(text)) && (!available.size || available.has(intent.command))) {
      return { ...intent, confidence: 0.78, args: [] };
    }
  }
  return null;
}
export function buildToolPrompt(tools = []) {
  return `Ferramentas autorizadas: ${tools.map(t => `${t.name}: ${t.description}`).join('; ')}`.slice(0, 6000);
}
export default { resolveIntent, buildToolPrompt };
