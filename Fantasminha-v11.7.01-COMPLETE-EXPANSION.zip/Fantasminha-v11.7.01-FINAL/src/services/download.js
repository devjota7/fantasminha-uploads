/**
 * DownloadService — camada única
 * Delega aos módulos legados (youtube, tiktok, ig, etc.)
 */
import path from 'path';
import { fileURLToPath } from 'url';
import logger from '../core/logger.js';
import config from '../core/config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const DL = path.join(ROOT, 'dados/src/funcs/downloads');

const MAX_BYTES = 80 * 1024 * 1024;
const cache = new Map();
const CACHE_TTL = 30 * 60 * 1000;

function cacheGet(k) {
  const x = cache.get(k);
  if (!x) return null;
  if (Date.now() - x.ts > CACHE_TTL) {
    cache.delete(k);
    return null;
  }
  return x.val;
}
function cacheSet(k, val) {
  if (cache.size > 200) {
    const first = cache.keys().next().value;
    cache.delete(first);
  }
  cache.set(k, { val, ts: Date.now() });
}

async function loadMod(name) {
  try {
    return await import(path.join(DL, `${name}.js`));
  } catch (e) {
    logger.warn('download', `módulo ${name}: ${e.message}`);
    return null;
  }
}

function detectProvider(url = '') {
  const u = url.toLowerCase();
  if (u.includes('youtube.com') || u.includes('youtu.be')) return 'youtube';
  if (u.includes('tiktok.com') || u.includes('vt.tiktok.com')) return 'tiktok';
  if (u.includes('instagram.com') || u.includes('instagr.am')) return 'instagram';
  if (u.includes('facebook.com') || u.includes('fb.watch')) return 'facebook';
  if (u.includes('pinterest.')) return 'pinterest';
  if (u.includes('soundcloud.com')) return 'soundcloud';
  if (u.includes('spotify.com')) return 'spotify';
  if (u.includes('kwai')) return 'kwai';
  return 'auto';
}

export async function probeUrl(url, timeout = 15000) {
  if (!url || !/^https?:\/\//i.test(url)) {
    const err = new Error('URL inválida');
    err.userMessage = '🌑 URL inválida.';
    throw err;
  }
  try {
    const axios = (await import('axios')).default;
    const res = await axios.head(url, { timeout, maxRedirects: 5, validateStatus: () => true });
    const len = Number(res.headers['content-length'] || 0);
    return {
      ok: res.status < 400,
      status: res.status,
      contentType: res.headers['content-type'] || 'unknown',
      size: len,
      tooLarge: len > MAX_BYTES,
      provider: detectProvider(url)
    };
  } catch (e) {
    return { ok: false, error: e.message, provider: detectProvider(url) };
  }
}

async function withRetry(fn, retries = 2) {
  let last;
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (e) {
      last = e;
      if (i < retries) await new Promise((r) => setTimeout(r, 800 * (i + 1)));
    }
  }
  throw last;
}

/**
 * downloadMedia({ url, type, query })
 * type: mp3 | mp4 | video | audio | auto
 */
export async function downloadMedia({ url, type = 'auto', query = null, onProgress } = {}) {
  const started = Date.now();
  if (query && !url) {
    const yt = await loadMod('youtube');
    if (!yt?.search) {
      return { ok: false, message: 'Módulo YouTube indisponível.' };
    }
    const ck = `search:${query}`;
    let search = cacheGet(ck);
    if (!search) {
      search = await withRetry(() => yt.search(query));
      if (search?.ok) cacheSet(ck, search);
    }
    if (!search?.ok) return { ok: false, message: search?.msg || 'Nada encontrado.' };
    url = search.data?.url;
    if (onProgress) await onProgress(`🔎 ${search.data?.title || query}`);
  }

  if (!url) return { ok: false, message: 'Informe URL ou busca.' };

  const provider = detectProvider(url);
  const cacheKey = `${provider}:${type}:${url}`;
  const hit = cacheGet(cacheKey);
  if (hit) {
    logger.info('download', 'cache hit', { provider, type });
    return { ...hit, cached: true, ms: Date.now() - started };
  }

  if (onProgress) await onProgress(`📥 ${provider}…`);

  let result = { ok: false, message: 'Provider não suportado.' };

  try {
    if (provider === 'youtube') {
      const yt = await loadMod('youtube');
      if (!yt) throw new Error('youtube module missing');
      if (type === 'mp3' || type === 'audio') {
        result = await withRetry(() => yt.mp3?.(url, 128) ?? yt.download?.(url));
      } else {
        result = await withRetry(() => yt.mp4?.(url) ?? yt.dl?.(url) ?? yt.download?.(url));
      }
    } else if (provider === 'tiktok') {
      const tk = await loadMod('tiktok');
      result = await withRetry(() => tk.dl?.(url) ?? tk.download?.(url));
    } else if (provider === 'instagram') {
      const ig = await loadMod('igdl');
      result = await withRetry(() => ig.dl?.(url) ?? ig.download?.(url));
    } else if (provider === 'facebook') {
      const fb = await loadMod('facebook');
      result = await withRetry(() => fb.dl?.(url) ?? fb.download?.(url));
    } else if (provider === 'pinterest') {
      const pin = await loadMod('pinterest');
      result = await withRetry(() => pin.dl?.(url) ?? pin.download?.(url));
    } else if (provider === 'soundcloud') {
      const sc = await loadMod('soundcloud');
      result = await withRetry(() => sc.dl?.(url) ?? sc.download?.(url));
    } else if (provider === 'spotify') {
      const sp = await loadMod('spotify');
      result = await withRetry(() => sp.dl?.(url) ?? sp.download?.(url));
    } else if (provider === 'kwai') {
      const kw = await loadMod('kwai');
      result = await withRetry(() => kw.dl?.(url) ?? kw.download?.(url));
    } else {
      // try youtube search as fallback if looks like text
      result = { ok: false, message: `Provider *${provider}* não mapeado. Use URL completa.` };
    }
  } catch (e) {
    logger.error('download', e.message, { provider });
    result = { ok: false, message: e.message || 'Falha no download.' };
  }

  // normalize
  if (result && result.ok !== false && (result.buffer || result.url || result.data)) {
    result.ok = result.ok !== false ? true : result.ok;
  }

  const out = {
    ok: !!result?.ok,
    provider,
    type,
    data: result?.data || result,
    buffer: result?.buffer,
    url: result?.url || result?.data?.url,
    title: result?.title || result?.data?.title,
    message: result?.msg || result?.message,
    ms: Date.now() - started,
    maxBytes: MAX_BYTES
  };

  if (out.ok) cacheSet(cacheKey, { ...out, buffer: undefined }); // don't cache buffers
  return out;
}

export async function searchYoutube(query) {
  const yt = await loadMod('youtube');
  if (!yt?.search) return { ok: false, message: 'YouTube indisponível' };
  return withRetry(() => yt.search(query));
}

export default { downloadMedia, probeUrl, searchYoutube, detectProvider, MAX_BYTES };
