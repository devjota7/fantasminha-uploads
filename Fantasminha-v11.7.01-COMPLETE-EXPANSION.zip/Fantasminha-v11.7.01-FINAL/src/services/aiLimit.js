import { canUseVipBenefit } from './vipBenefits.js';
import { updateCollection, readCollection } from '../database/store.js';
import logger from '../core/logger.js';

/** Estimativa simples de custo em "créditos fantasma" */
export function estimateCost(chars = 0, model = 'default') {
  const base = Math.max(1, Math.ceil(chars / 500));
  const mult = model.includes('gpt') || model.includes('gemini') ? 2 : 1;
  return base * mult;
}

export async function checkAndConsumeAi(userId, chars = 100) {
  const limit = await canUseVipBenefit(userId, 'ai');
  if (!limit.ok) return limit;

  const cost = estimateCost(chars);
  await updateCollection('ai_costs', (A) => {
    if (!A.byUser) A.byUser = {};
    if (!A.byUser[userId]) A.byUser[userId] = { total: 0, calls: 0 };
    A.byUser[userId].total += cost;
    A.byUser[userId].calls += 1;
    A.global = (A.global || 0) + cost;
    return A;
  }, { byUser: {}, global: 0 });

  logger.info('aiLimit', 'consume', { userId: String(userId).slice(0, 15), cost });
  return { ok: true, cost, ...limit };
}

export function aiStats() {
  return readCollection('ai_costs', { byUser: {}, global: 0 });
}

export default { estimateCost, checkAndConsumeAi, aiStats };
