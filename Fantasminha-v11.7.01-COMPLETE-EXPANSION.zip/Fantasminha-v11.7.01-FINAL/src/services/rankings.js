import { readCollection, updateCollection } from '../database/store.js';

function weekKey() {
  const d = new Date();
  const onejan = new Date(d.getFullYear(), 0, 1);
  const week = Math.ceil(((d - onejan) / 86400000 + onejan.getDay() + 1) / 7);
  return `${d.getFullYear()}-W${week}`;
}

export async function addWeeklyScore(userId, name, category, points) {
  const wk = weekKey();
  await updateCollection('weekly_ranks', (R) => {
    if (!R.weeks) R.weeks = {};
    if (!R.weeks[wk]) R.weeks[wk] = {};
    if (!R.weeks[wk][category]) R.weeks[wk][category] = {};
    if (!R.weeks[wk][category][userId]) {
      R.weeks[wk][category][userId] = { name, points: 0 };
    }
    R.weeks[wk][category][userId].points += points;
    R.weeks[wk][category][userId].name = name || R.weeks[wk][category][userId].name;
    return R;
  }, { weeks: {} });
}

export function getWeeklyTop(category, limit = 10) {
  const wk = weekKey();
  const R = readCollection('weekly_ranks', { weeks: {} });
  const map = R.weeks?.[wk]?.[category] || {};
  return Object.entries(map)
    .map(([id, v]) => ({ id, name: v.name, points: v.points }))
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);
}

export function currentWeek() {
  return weekKey();
}

export default { addWeeklyScore, getWeeklyTop, currentWeek };
