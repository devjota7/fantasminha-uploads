import { scrapingClient, downloadMedia } from '../../../dados/src/utils/httpClient.js';
import { TTLCache } from '../../core/cache.js';

const cache = new TTLCache({ max: 300, ttlMs: 90_000, name: 'instagram-profiles' });
const inflight = new Map();
const USERNAME_RE = /^[A-Za-z0-9._]{1,30}$/;

export function normalizeSocialUsername(input, platform = 'instagram') {
  let value = String(input ?? '').trim();
  if (!value) return '';
  value = value.split(/\s+/)[0];
  value = value.replace(/^@+/, '');
  try {
    if (/^https?:\/\//i.test(value)) {
      const url = new URL(value);
      const host = url.hostname.toLowerCase();
      if (platform === 'instagram' && !host.endsWith('instagram.com')) return '';
      if (platform === 'tiktok' && !host.endsWith('tiktok.com')) return '';
      const parts = url.pathname.split('/').filter(Boolean);
      value = parts[0] || '';
      if (platform === 'tiktok' && value === 'user') value = parts[1] || '';
    }
  } catch {}
  value = value.replace(/^@+/, '').trim();
  return USERNAME_RE.test(value) ? value : '';
}

function parseJsonScript(html, id) {
  const re = new RegExp(`<script[^>]+id=["']${id}["'][^>]*>([\\s\\S]*?)<\\/script>`, 'i');
  const m = String(html || '').match(re);
  if (!m) return null;
  try { return JSON.parse(m[1]); } catch { return null; }
}

function deepFind(root, keys, limit = 100000) {
  const wanted = new Set(keys.map(k => k.toLowerCase()));
  const stack = [root]; let seen = 0;
  while (stack.length && seen++ < limit) {
    const value = stack.pop();
    if (!value || typeof value !== 'object') continue;
    if (Array.isArray(value)) { for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]); continue; }
    for (const [key, child] of Object.entries(value)) {
      if (wanted.has(key.toLowerCase()) && child != null) return child;
      if (child && typeof child === 'object') stack.push(child);
    }
  }
  return null;
}

function firstDeep(root, keys) {
  for (const key of keys) {
    const found = deepFind(root, [key]);
    if (found !== null && found !== undefined && found !== '') return found;
  }
  return null;
}

function parseCount(value) {
  if (value == null) return null;
  const s = String(value).replace(/\u00a0/g, ' ').trim();
  const m = s.match(/([\d.,]+)\s*([kKmMbB])?/);
  if (!m) return null;
  let n = Number(m[1].replace(/\./g, '').replace(',', '.'));
  if (!Number.isFinite(n)) return null;
  const suffix = (m[2] || '').toLowerCase();
  if (suffix === 'k') n *= 1e3;
  if (suffix === 'm') n *= 1e6;
  if (suffix === 'b') n *= 1e9;
  return Math.round(n);
}

function parseMeta(html) {
  const out = {};
  const metas = String(html || '').matchAll(/<meta\s+[^>]*>/gi);
  for (const raw of metas) {
    const tag = raw[0];
    const name = tag.match(/(?:property|name)=["']([^"']+)["']/i)?.[1]?.toLowerCase();
    const content = tag.match(/content=["']([^"']*)["']/i)?.[1];
    if (name && content) out[name] = content.replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
  }
  return out;
}

function extractJsonBlobs(html) {
  const blobs = [];
  const patterns = [
    /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi,
    /<script[^>]*id=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/gi,
    /<script[^>]*id=["']__additionalDataLoaded["'][^>]*>([\s\S]*?)<\/script>/gi
  ];
  for (const re of patterns) for (const m of String(html || '').matchAll(re)) {
    try { blobs.push(JSON.parse(m[1])); } catch {}
  }
  return blobs;
}

export function parseInstagramProfileHtml(html, username) {
  const meta = parseMeta(html);
  const blobs = extractJsonBlobs(html);
  const shared = String(html || '').match(/window\._sharedData\s*=\s*(\{[\s\S]*?\});<\/script>/i)?.[1];
  if (shared) { try { blobs.push(JSON.parse(shared)); } catch {} }

  const root = blobs.length === 1 ? blobs[0] : blobs;
  const profile = firstDeep(root, ['user','owner','profile','account']) || {};
  const result = {
    platform: 'instagram',
    username,
    name: firstDeep(profile, ['full_name','fullName','name','display_name']) || meta['og:title']?.replace(/\s*\(@[^)]+\).*/, '').trim() || null,
    bio: firstDeep(profile, ['biography','bio','description']) || null,
    avatarUrl: firstDeep(profile, ['profile_pic_url_hd','profile_pic_url','profilePicUrl','avatar','image']) || meta['og:image'] || null,
    followers: parseCount(firstDeep(profile, ['edge_followed_by','followers','follower_count','followersCount'])),
    following: parseCount(firstDeep(profile, ['edge_follow','following','following_count','followingCount'])),
    posts: parseCount(firstDeep(profile, ['edge_owner_to_timeline_media','media_count','posts','post_count','postsCount'])),
    verified: Boolean(firstDeep(profile, ['is_verified','verified','isVerified'])),
    private: Boolean(firstDeep(profile, ['is_private','private','isPrivate'])),
    recent: null,
    profileUrl: `https://www.instagram.com/${username}/`
  };

  const desc = meta['og:description'] || '';
  if (result.followers == null) result.followers = parseCount(desc.match(/([\d.,]+\s*[KMB]?)\s*Followers/i)?.[1]);
  if (result.following == null) result.following = parseCount(desc.match(/([\d.,]+\s*[KMB]?)\s*Following/i)?.[1]);
  if (result.posts == null) result.posts = parseCount(desc.match(/([\d.,]+\s*[KMB]?)\s*Posts?/i)?.[1]);

  const post = firstDeep(root, ['latestPost','recentPost','latestMedia','edge_owner_to_timeline_media']);
  if (post) {
    const node = Array.isArray(post) ? post[0] : (post.edges?.[0]?.node || post);
    if (node && typeof node === 'object') {
      result.recent = {
        imageUrl: firstDeep(node, ['display_url','thumbnail_src','image','thumbnailUrl','thumbnail_url']) || null,
        caption: firstDeep(node, ['caption','title','description']) || null,
        date: firstDeep(node, ['taken_at_timestamp','timestamp','date','created_time']) || null,
        type: firstDeep(node, ['media_type','product_type','type']) || null,
        url: node.shortcode ? `https://www.instagram.com/p/${node.shortcode}/` : null
      };
    }
  }
  return result;
}

export async function fetchInstagramProfile(input, { force = false } = {}) {
  const username = normalizeSocialUsername(input, 'instagram');
  if (!username) return { status: 'invalid' };
  const key = username.toLowerCase();
  if (!force) {
    const hit = cache.get(key);
    if (hit) return hit;
    if (inflight.has(key)) return inflight.get(key);
  }

  const task = (async () => {
    try {
      const url = `https://www.instagram.com/${encodeURIComponent(username)}/`;
      const response = await scrapingClient.get(url, { timeout: 15_000, maxContentLength: 5 * 1024 * 1024 });
      if (response.status === 404) return { status: 'not_found', username };
      const data = parseInstagramProfileHtml(response.data, username);
      const pageText = String(response.data || '');
      if (/Page Not Found|Sorry, this page isn't available/i.test(pageText) && !data.name && !data.bio) return { status: 'not_found', username };
      data.status = 'ok';
      cache.set(key, data);
      return data;
    } catch (error) {
      if (error?.response?.status === 404) return { status: 'not_found', username };
      return { status: 'error', username, error: error?.code || 'external_error' };
    } finally { inflight.delete(key); }
  })();
  inflight.set(key, task);
  return task;
}

export async function downloadInstagramImage(url) {
  if (!url || typeof url !== 'string') return null;
  try {
    const data = await downloadMedia(url, { timeout: 10_000, maxContentLength: 4 * 1024 * 1024 });
    return Buffer.isBuffer(data) ? data : Buffer.from(data);
  } catch { return null; }
}

export default { normalizeSocialUsername, fetchInstagramProfile, downloadInstagramImage, parseInstagramProfileHtml };
