import { scrapingClient, downloadMedia } from '../../../dados/src/utils/httpClient.js';
import { TTLCache } from '../../core/cache.js';

const cache = new TTLCache({ max: 300, ttlMs: 90_000, name: 'tiktok-profiles' });
const inflight = new Map();
const USERNAME_RE = /^[A-Za-z0-9._-]{1,40}$/;

export function normalizeTikTokUsername(input) {
  let value = String(input ?? '').trim().split(/\s+/)[0] || '';
  value = value.replace(/^@+/, '');
  try {
    if (/^https?:\/\//i.test(value)) {
      const url = new URL(value);
      if (!url.hostname.toLowerCase().endsWith('tiktok.com')) return '';
      const parts = url.pathname.split('/').filter(Boolean);
      value = parts[0] === 'user' ? (parts[1] || '') : (parts[0] || '');
    }
  } catch {}
  value = value.replace(/^@+/, '').trim();
  return USERNAME_RE.test(value) ? value : '';
}

function parseJsonScripts(html) {
  const out = [];
  for (const re of [
    /<script[^>]*id=["']__UNIVERSAL_DATA_FOR_REHYDRATION__["'][^>]*>([\s\S]*?)<\/script>/gi,
    /<script[^>]*id=["']SIGI_STATE["'][^>]*>([\s\S]*?)<\/script>/gi,
    /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi
  ]) {
    for (const m of String(html || '').matchAll(re)) {
      try { out.push(JSON.parse(m[1])); } catch {}
    }
  }
  return out;
}

function deepFind(root, keys) {
  const wanted = new Set(keys.map(k => k.toLowerCase()));
  const stack = [root]; let steps = 0;
  while (stack.length && steps++ < 100000) {
    const v = stack.pop();
    if (!v || typeof v !== 'object') continue;
    if (Array.isArray(v)) { for (let i=v.length-1;i>=0;i--) stack.push(v[i]); continue; }
    for (const [k,c] of Object.entries(v)) {
      if (wanted.has(k.toLowerCase()) && c != null && c !== '') return c;
      if (c && typeof c === 'object') stack.push(c);
    }
  }
  return null;
}
function parseCount(value) {
  if (value == null) return null;
  const s=String(value).trim().replace(/\s/g,'');
  const m=s.match(/^([\d.,]+)([KMB])?$/i); if(!m) return null;
  let n=Number(m[1].replace(/\./g,'').replace(',','.')); if(!Number.isFinite(n)) return null;
  const u=(m[2]||'').toLowerCase(); if(u==='k')n*=1e3;if(u==='m')n*=1e6;if(u==='b')n*=1e9;
  return Math.round(n);
}
function parseMeta(html) {
  const out={};
  for(const m of String(html||'').matchAll(/<meta\s+[^>]*>/gi)){
    const tag=m[0], key=tag.match(/(?:property|name)=["']([^"']+)["']/i)?.[1]?.toLowerCase(), val=tag.match(/content=["']([^"']*)["']/i)?.[1];
    if(key&&val)out[key]=val.replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
  }
  return out;
}

export function parseTikTokProfileHtml(html, username) {
  const meta=parseMeta(html), blobs=parseJsonScripts(html);
  const root=blobs.length===1?blobs[0]:blobs;
  const user=deepFind(root,['userInfo','user','author','creator']) || {};
  const stats=deepFind(root,['stats','statsV2']) || {};
  const name=deepFind(user,['nickname','nickName','name','display_name']) || meta['og:title'] || null;
  const handle=deepFind(user,['uniqueId','unique_id','username']) || username;
  const result={
    platform:'tiktok', username:handle || username,
    name, bio:deepFind(user,['signature','bio','description']) || meta['og:description'] || null,
    avatarUrl:deepFind(user,['avatarLarger','avatarMedium','avatarThumb','avatar','avatar_url','image']) || meta['og:image'] || null,
    followers:parseCount(deepFind(stats,['followerCount','followers','followersCount'])),
    following:parseCount(deepFind(stats,['followingCount','following','following_count'])),
    likes:parseCount(deepFind(stats,['heartCount','heart','likes','likeCount'])),
    videos:parseCount(deepFind(stats,['videoCount','videos','video_count'])),
    verified:Boolean(deepFind(user,['verified','isVerified','verification'])),
    recent:null,
    profileUrl:`https://www.tiktok.com/@${encodeURIComponent(username)}`
  };
  const item=deepFind(root,['itemList','video','itemStruct','latestVideo','latestItem']);
  if(item){
    const node=Array.isArray(item)?item[0]:(item?.itemStruct || item?.items?.[0] || item);
    if(node&&typeof node==='object'){
      const id=deepFind(node,['id','videoId']);
      result.recent={
        imageUrl:deepFind(node,['cover','originCover','dynamicCover','thumbnail','thumbnail_url','coverUrl']) || null,
        caption:deepFind(node,['desc','description','title']) || null,
        date:deepFind(node,['createTime','createdAt','date','timestamp']) || null,
        type:'video',
        url:id?`https://www.tiktok.com/@${encodeURIComponent(username)}/video/${id}`:null
      };
    }
  }
  return result;
}

async function fetchOEmbed(username) {
  try {
    const url=`https://www.tiktok.com/oembed?url=${encodeURIComponent(`https://www.tiktok.com/@${username}`)}`;
    const r=await scrapingClient.get(url,{timeout:4_000,maxContentLength:512*1024});
    return r.status<400 && r.data ? r.data : null;
  } catch { return null; }
}

export async function fetchTikTokProfile(input,{force=false}={}) {
  const username=normalizeTikTokUsername(input); if(!username)return {status:'invalid'};
  const key=username.toLowerCase();
  if(!force){const hit=cache.get(key);if(hit)return hit;if(inflight.has(key))return inflight.get(key);}
  const task=(async()=>{
    try{
      const url=`https://www.tiktok.com/@${encodeURIComponent(username)}`;
      const response=await scrapingClient.get(url,{timeout:12_000,maxContentLength:6*1024*1024});
      if(response.status===404)return {status:'not_found',username};
      const data=parseTikTokProfileHtml(response.data,username);
      const embed=await fetchOEmbed(username);
      if(embed){
        data.name ||= embed.author_name || null;
        data.username ||= embed.author_unique_id || username;
        data.avatarUrl ||= embed.author_url ? null : null;
        data.recent ||= embed.title ? {imageUrl:embed.thumbnail_url||null,caption:embed.title,date:null,type:'video',url:embed.author_url||data.profileUrl}:null;
      }
      const text=String(response.data||'');
      if(/Couldn't find this account|page not found|user not found/i.test(text)&&!data.name)return {status:'not_found',username};
      data.status='ok'; cache.set(key,data); return data;
    }catch(error){
      if(error?.response?.status===404)return {status:'not_found',username};
      return {status:'error',username,error:error?.code||'external_error'};
    }finally{inflight.delete(key);}
  })();
  inflight.set(key,task); return task;
}
export async function downloadTikTokImage(url){
  if(!url||typeof url!=='string')return null;
  try{const data=await downloadMedia(url,{timeout:10_000,maxContentLength:4*1024*1024});return Buffer.isBuffer(data)?data:Buffer.from(data);}catch{return null;}
}
export default {normalizeTikTokUsername,fetchTikTokProfile,downloadTikTokImage};
