const MAX_BIO = 240;
const MAX_CAPTION = 220;

function clean(value) {
  if (value == null) return null;
  const s = String(value).replace(/\s+/g, ' ').trim();
  return s || null;
}
function esc(value) {
  return clean(value)?.replace(/[*_~`]/g, '') || null;
}
function count(value) {
  return Number.isFinite(value) ? value.toLocaleString('pt-BR') : null;
}
function date(value) {
  if (value == null) return null;
  let n = Number(value);
  if (Number.isFinite(n) && n > 1e12) n /= 1000;
  const d = Number.isFinite(n) && n > 1e9 ? new Date(n * 1000) : new Date(String(value));
  if (Number.isNaN(d.getTime())) return null;
  return d.toLocaleDateString('pt-BR');
}
function crop(value, max) {
  const s = esc(value); if (!s) return null;
  return s.length > max ? `${s.slice(0, max - 1).trim()}…` : s;
}

export function formatSocialProfile(data, command) {
  const isInsta = data.platform === 'instagram';
  const title = isInsta ? 'ᴘᴇʀғɪʟ ᴅᴏ ɪɴsᴛᴀɢʀᴀᴍ' : 'ᴘᴇʀғɪʟ ᴅᴏ ᴛɪᴋᴛᴏᴋ';
  const icon = isInsta ? '📸' : '🎵';
  const lines = [`👻 *${title}*`, '', `${icon} *${command} ${esc(data.username)}*`, '', '━━━━━━━━━━━━━━', '', `👤 *${esc(data.name) || data.username}*`, `🔗 \`${esc(data.username)}\``];
  if (data.bio) lines.push(`📝 *Bio:* ${crop(data.bio, MAX_BIO)}`);
  const stats = [];
  if (count(data.followers) != null) stats.push(`👥 Seguidores: ${count(data.followers)}`);
  if (count(data.following) != null) stats.push(`👤 Seguindo: ${count(data.following)}`);
  if (isInsta && count(data.posts) != null) stats.push(`📷 Posts: ${count(data.posts)}`);
  if (!isInsta && count(data.likes) != null) stats.push(`❤️ Curtidas: ${count(data.likes)}`);
  if (!isInsta && count(data.videos) != null) stats.push(`🎬 Vídeos: ${count(data.videos)}`);
  if (stats.length) lines.push(stats.join('  '));
  const flags = [];
  if (data.verified) flags.push('☑️ Verificada');
  if (data.private) flags.push('🔒 Privada');
  if (flags.length) lines.push(flags.join('  '));
  if (data.recent) {
    lines.push('', '━━━━━━━━━━━━━━', '', isInsta ? '📸 *ᴘᴏsᴛ ʀᴇᴄᴇɴᴛᴇ*' : '🎬 *ᴠɪ́ᴅᴇᴏ ʀᴇᴄᴇɴᴛᴇ*');
    if (data.recent.type) lines.push(`📌 ${esc(data.recent.type)}`);
    if (data.recent.date) lines.push(`🗓️ ${date(data.recent.date)}`);
    if (data.recent.caption) lines.push(`💬 ${crop(data.recent.caption, MAX_CAPTION)}`);
    if (data.recent.url) lines.push(`🔗 ${data.recent.url}`);
  } else if (data.private) {
    lines.push('', '━━━━━━━━━━━━━━', '', '🔒 *ᴘᴇʀғɪʟ ᴘʀɪᴠᴀᴅᴏ*', 'Os posts públicos não estão disponíveis.');
  }
  if (data.profileUrl) lines.push('', `🔗 ${data.profileUrl.replace(/^https?:\/\//, '')}`);
  lines.push('', '━━━━━━━━━━━━━━', '', '👻 _ᴄᴏɴsᴜʟᴛᴀ ʀᴇᴀʟɪᴢᴀᴅᴀ ᴘᴇʟᴏ ᴠᴇʀᴛɪᴅᴏ._');
  return lines.join('\n');
}

export function usageMessage(platform, prefix='×') {
  return platform === 'instagram'
    ? `👻 *ᴘᴇʀғɪʟ ɪɴsᴛᴀɢʀᴀᴍ*\n\nᴜsᴇ:\n\n\`${prefix}perfilinsta usuario\``
    : `👻 *ᴘᴇʀғɪʟ ᴛɪᴋᴛᴏᴋ*\n\nᴜsᴇ:\n\n\`${prefix}perfiltiktok usuario\``;
}

export const notFoundMessage = '❌ *ᴘᴇʀғɪʟ ɴᴀ̃ᴏ ᴇɴᴄᴏɴᴛʀᴀᴅᴏ.*\n\n*ɴᴀ̃ᴏ ᴄᴏɴsᴇɢᴜɪ ᴇɴᴄᴏɴᴛʀᴀʀ ᴜᴍ ᴘᴇʀғɪʟ ᴘᴜ́ʙʟɪᴄᴏ ᴄᴏᴍ ᴇssᴇ ɴᴏᴍᴇ.*';
export const errorMessage = '⚠️ *ɴᴀ̃ᴏ ᴄᴏɴsᴇɢᴜɪ ᴄᴏɴsᴜʟᴛᴀʀ ᴇssᴇ ᴘᴇʀғɪʟ.*\n\n*ᴛᴇɴᴛᴇ ɴᴏᴠᴀᴍᴇɴᴛᴇ ᴅᴀǫᴜɪ ᴀ ᴘᴏᴜᴄᴏ.*';
export default {formatSocialProfile,usageMessage,notFoundMessage,errorMessage};
