/** Camada de entrega: fila única para mensagens com prioridade, retry e deduplicação leve. */
import { queues } from '../core/queue.js';
import { withRetry, retryableStatus } from '../core/retry.js';
import { increment } from '../core/metrics.js';

const recent = new Map();
const DEDUPE_MS = 5_000;

export function enqueueMessage(sendFn, { priority = 0, dedupeKey = null, retries = 2, timeoutMs = 30_000 } = {}) {
  if (dedupeKey) {
    const now = Date.now(); const old = recent.get(dedupeKey);
    if (old && now - old < DEDUPE_MS) { increment('message.deduplicated'); return Promise.resolve({ deduplicated: true }); }
    recent.set(dedupeKey, now);
  }
  return queues.messages.add(() => withRetry(() => sendFn(), { retries, shouldRetry: retryableStatus }), { priority, timeoutMs }).then(r => { increment('message.sent'); return r; }).catch(e => { increment('message.failed'); throw e; });
}

setInterval(() => { const now=Date.now(); for (const [k,t] of recent) if(now-t>DUP_MS) recent.delete(k); }, 60_000).unref?.();
const DUP_MS = DEDUPE_MS;
export default { enqueueMessage };
