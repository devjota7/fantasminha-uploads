import { listCommands } from '../core/registry.js';

const STOP = new Set(['quero','quero','fazer','faca','fazer','me','um','uma','o','a','os','as','de','do','da','dos','das','no','na','em','para','por','com','como','que','qual','quais','preciso','procuro','procurar','buscar','comando','comandos','meu','minha','algo','sobre','pra','vai','vou','eu']);
const SYN = new Map(Object.entries({
  guerra:['guerra','guerras','batalha','batalhas','confronto','clã','cla','campeonato','war'],
  parar:['parar','sair','cancelar','encerrar','stop','desistir','jogo','jogos'],
  foto:['foto','fotografia','imagem','imagens','menu','mídia','midia'],
  video:['video','vídeo','mídia','midia'],
  audio:['audio','áudio','som'],
  triagem:['triagem','ficha','entrada','membro','cobrar','aprovar','reprovar'],
  dinheiro:['dinheiro','economia','saldo','moeda','comprar','vender','pagamento'],
  usuario:['usuário','usuario','membro','nick','aniversário','aniversario','perfil'],
  ajuda:['ajuda','help','explicar','explicação','tutorial','como','usar'],
  download:['baixar','download','baixar','música','musica','vídeo','video'],
  rpg:['rpg','personagem','xp','nível','nivel','missão','missao'],
  admin:['admin','administrador','grupo','banir','bloquear','configurar']
}));

const norm=s=>String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
function tokens(q){
  const raw=norm(q).split(/[^a-z0-9@]+/).filter(Boolean);
  const out=new Set(raw.filter(x=>x.length>1&&!STOP.has(x)));
  for(const t of raw){ for(const [k,vals] of SYN){ if(vals.some(v=>norm(v)===t)){ out.add(k); for(const v of vals) out.add(norm(v)); } } }
  return [...out];
}
function levenshtein(a,b){
  a=norm(a); b=norm(b);
  if(a===b)return 0;
  if(!a.length)return b.length;
  if(!b.length)return a.length;
  let prev=Array.from({length:b.length+1},(_,i)=>i);
  for(let i=1;i<=a.length;i++){
    const cur=[i];
    for(let j=1;j<=b.length;j++) cur[j]=Math.min(cur[j-1]+1,prev[j]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    prev=cur;
  }
  return prev[b.length];
}
function editSimilarity(a,b){
  a=norm(a); b=norm(b); if(!a||!b)return 0;
  return Math.max(0,1-levenshtein(a,b)/Math.max(a.length,b.length));
}
function scoreCommand(c, ts){
  const fields={name:norm(c.name),aliases:(c.aliases||[]).map(norm),description:norm(c.description),usage:norm(c.usage),category:norm(c.category),subcategory:norm(c.subcategory)};
  const candidates=[fields.name,...fields.aliases];
  let score=0;
  for(const t of ts){
    const bestEdit=Math.max(...candidates.map(v=>editSimilarity(t,v)));
    if(bestEdit>=0.45) score+=Math.round(bestEdit*60);
    if(fields.name===t) score+=40;
    else if(fields.name.includes(t)) score+=22;
    if(fields.aliases.some(a=>a===t)) score+=30;
    else if(fields.aliases.some(a=>a.includes(t))) score+=16;
    if(fields.description.includes(t)) score+=12;
    if(fields.category.includes(t)||fields.subcategory.includes(t)) score+=8;
  }
  return score;
}

export function searchCommands(query,{limit=5}={}){
  const ts=tokens(query);
  if(!ts.length)return [];
  return listCommands().map(c=>({command:c,score:scoreCommand(c,ts)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.command.name.localeCompare(b.command.name)).slice(0,limit);
}
export function explainCommand(name){
  const key=norm(name).replace(/^×/,'');
  return listCommands({includeHidden:true}).find(c=>norm(c.name)===key || c.aliases.some(a=>norm(a)===key)) || null;
}
export default {searchCommands,explainCommand};
