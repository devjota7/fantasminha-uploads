import manager from './gameSessionManager.js';
export function start(scope, game, ms, onExpire){return manager.startTimer(scope,game,ms,onExpire);}
export function stop(scope,game){return manager.stopTimer(scope,game);}
export function remaining(scope,game){return manager.remaining(scope,game);}
export default {start,stop,remaining};
