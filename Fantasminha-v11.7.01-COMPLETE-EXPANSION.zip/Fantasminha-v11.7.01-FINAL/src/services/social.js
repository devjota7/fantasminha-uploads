import { getUser, upsertUser, readCollection, updateCollection } from '../database/store.js';
import { resolveMentionTargets, resolveUserIdentity } from '../platform/identity/resolver.js';

export function listBestFriends(userId) {
  const current = getUser(userId) || {};
  const list = Array.isArray(current.bestFriends) ? current.bestFriends : (current.bestFriend ? [current.bestFriend] : []);
  return [...new Set(list.filter(Boolean))].slice(0, 3);
}

export async function addBestFriend(ctx, target = null) {
  const [person] = await resolveMentionTargets(ctx, target ? [target] : null);
  if (!person?.realJid) throw new Error('Não consegui resolver o número real desse usuário. Mencione a pessoa ou responda à mensagem dela.');
  const me = (await resolveUserIdentity(ctx, ctx.sender)).realJid || ctx.sender;
  if (person.realJid === me) throw new Error('Você não pode adicionar a si mesmo como Best Friend.');
  const list = listBestFriends(ctx.sender);
  if (list.includes(person.realJid)) return { changed: false, person, list };
  if (list.length >= 3) throw new Error('Você já atingiu o limite de 3 Best Friends. Remova um antes de adicionar outro.');
  const next = [...list, person.realJid];
  await upsertUser(ctx.sender, { bestFriends: next, bestFriend: next[0] || null, bestFriendUpdatedAt: Date.now() });
  return { changed: true, person, list: next };
}

export async function removeBestFriend(ctx, target = null) {
  const [person] = await resolveMentionTargets(ctx, target ? [target] : null);
  if (!person?.realJid) throw new Error('Não consegui resolver o número real desse usuário.');
  const list = listBestFriends(ctx.sender);
  if (!list.includes(person.realJid)) return { changed: false, person, list };
  const next = list.filter(x => x !== person.realJid);
  await upsertUser(ctx.sender, { bestFriends: next, bestFriend: next[0] || null, bestFriendUpdatedAt: Date.now() });
  return { changed: true, person, list: next };
}

export function afkKey(jid) { return String(jid || '').trim().toLowerCase(); }
export async function setAfk(ctx, reason = '') {
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const key = afkKey(me.realJid || ctx.sender);
  const rec = { userId: key, lid: me.lid || ctx.sender, name: ctx.pushname || me.pushName || 'Alguém', reason: String(reason || 'foi passear pelo Além').slice(0, 180), since: Date.now() };
  await updateCollection('afk', d => { d.byUser ??={}; d.byUser[key]=rec; return d; }, {byUser:{}});
  return rec;
}
export async function clearAfk(ctx) {
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const keys = [me.realJid, ctx.sender, ctx.senderOriginal, ctx.senderAlternate].filter(Boolean).map(afkKey);
  const current = readCollection('afk', {byUser:{}});
  const existingKey = keys.find(k => current.byUser?.[k]);
  if (!existingKey) return null;
  let removed = current.byUser[existingKey];
  await updateCollection('afk', d => { d.byUser ??={}; for (const k of keys) if (d.byUser[k]) delete d.byUser[k]; return d; }, {byUser:{}});
  return removed;
}

export async function clearAfkFromMessage(ctx) {
  if (!ctx?.sender) return null;
  const body = String(ctx.body || ctx.text || '').trim();
  const prefix = String(ctx.prefix || '×');
  // Permite reconfigurar/reativar AFK sem o pipeline apagar o novo estado antes do comando.
  const isAfkCommand = body.toLowerCase().startsWith(`${prefix}afk`) || body.toLowerCase().startsWith(`${prefix}ausente`);
  if (isAfkCommand) return null;
  return clearAfk(ctx);
}

export async function findAfk(ctx, target) {
  const person = await resolveUserIdentity(ctx, target);
  const d = readCollection('afk',{byUser:{}});
  const keys=[person.realJid,person.lid,target].filter(Boolean).map(afkKey);
  for(const k of keys) if(d.byUser?.[k]) return {record:d.byUser[k],person};
  return null;
}

const POOLS = Object.freeze({
  aparencia:['CEO de alguma coisa que ninguém sabe explicar','lenda urbana com Wi‑Fi','protagonista de um anime que só existe no grupo','espírito de segunda-feira'],
  hobby:['treinar 3 dias e contar por 30','abrir o WhatsApp e esquecer por que abriu','sumir quando chega a cobrança','colecionar histórias que começam com “não foi minha culpa”'],
  profissao:['Influencer do próprio grupo','consultor de decisões questionáveis','gerente do caos','especialista em responder “já vou”'],
  horario:['quando ninguém está cobrando resposta','03:17, horário oficial das ideias duvidosas','na hora exata em que o grupo dorme','quando aparece uma fofoca'],
  musica:['aquela que toca na cabeça quando faz besteira','trilha sonora de fuga em câmera lenta','um remix que ninguém pediu','o silêncio antes da próxima confusão'],
  clima:['32°C e reclamando que está calor','chuva com vontade de dormir','frio suficiente para justificar o sumiço','qualquer clima que permita ficar no celular'],
  signo:['Capricórnio do Além','Gêmeos em modo espectral','Escorpião da Cripta','Libra do Limbo'],
  animal:['um pombo com confiança demais','um gato julgando todo mundo','uma capivara com acesso de administrador','um corvo com fofoca'],
  qualidade:['faz o grupo rir sem perceber','aparece exatamente quando precisa','tem criatividade para situações improváveis','transforma qualquer conversa em história'],
  defeito:['responde na cabeça e esquece de enviar','some por tempo espiritualmente indefinido','promete “rapidinho” e desaparece','tem talento para escolher a pior hora'],
  energia:['92% caos controlado','68% protagonista','100% entidade online','47% mistério, 53% improviso'],
  profissaoAlem:['guardião da porta errada','contador de almas atrasadas','fiscal de fantasmas','moderador do Limbo'],
  poder:['teletransportar só até a cozinha','saber quem visualizou e não respondeu','invocar uma desculpa em 0,2 segundos','encontrar Wi‑Fi onde ninguém encontra'],
  preso:['por abrir 17 abas e esquecer todas','por excesso de opinião em assunto aleatório','por perturbação da paz do cemitério','por fugir de uma cobrança oficial do Além'],
  talento:['decorar detalhes completamente inúteis','aparecer com uma resposta na última hora','criar apelidos instantaneamente','sobreviver a conversas que deveriam ter acabado'],
  frase:['“calma que eu resolvo”','“já tô indo”','“foi sem querer”','“eu nem vi”']
});
function pick(a){return a[Math.floor(Math.random()*a.length)];}
const last = new Map();
export function personality(targetName='Pessoa', targetKey='') {
  let out;
  for(let tries=0;tries<6;tries++){
    out={aparencia:pick(POOLS.aparencia),hobby:pick(POOLS.hobby),profissao:pick(POOLS.profissao),horario:pick(POOLS.horario),musica:pick(POOLS.musica),clima:pick(POOLS.clima),signo:pick(POOLS.signo),animal:pick(POOLS.animal),qualidade:pick(POOLS.qualidade),defeito:pick(POOLS.defeito),energia:pick(POOLS.energia),profissaoAlem:pick(POOLS.profissaoAlem),poder:pick(POOLS.poder),preso:pick(POOLS.preso),talento:pick(POOLS.talento),frase:pick(POOLS.frase)};
    const sig=JSON.stringify(out); if(last.get(targetKey)!==sig){last.set(targetKey,sig);break;}
  }
  return {name:targetName,...out};
}
export default {addBestFriend,removeBestFriend,setAfk,clearAfk,clearAfkFromMessage,findAfk,personality};
