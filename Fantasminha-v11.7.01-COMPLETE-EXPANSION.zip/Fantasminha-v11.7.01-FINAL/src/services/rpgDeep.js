import { getUser, upsertUser, readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';

export const EQUIP = {
  foice_enferrujada: { slot: 'arma', atk: 8, name: 'Foice Enferrujada', price: 2000 },
  lamina_veu: { slot: 'arma', atk: 18, name: 'Lâmina do Véu', price: 8000 },
  manto_sombra: { slot: 'armadura', def: 10, name: 'Manto Sombra', price: 5000 },
  coroa_limbo: { slot: 'armadura', def: 20, name: 'Coroa do Limbo', price: 12000 }
};

export const BOSSES = [
  { id: 'caronte', name: 'Caronte', hp: 120, atk: 15, xp: 80, gold: 400, minLevel: 1 },
  { id: 'cerbero', name: 'Cérbero', hp: 220, atk: 25, xp: 160, gold: 900, minLevel: 3 },
  { id: 'hadoes', name: 'Sombra de Hades', hp: 400, atk: 40, xp: 350, gold: 2000, minLevel: 6 }
];

export const DUNGEONS = [
  { id: 'cripta', name: 'Cripta Úmida', floors: 3, minLevel: 1, xpPerFloor: 40, goldPerFloor: 150 },
  { id: 'rio_estilo', name: 'Rio Estige', floors: 5, minLevel: 3, xpPerFloor: 70, goldPerFloor: 280 },
  { id: 'trono', name: 'Trono Quebrado', floors: 7, minLevel: 6, xpPerFloor: 120, goldPerFloor: 500 }
];

function ensureRpg(u) {
  if (!u.rpg) u.rpg = {};
  const r = u.rpg;
  if (!r.class) r.class = null;
  r.level = r.level || 1;
  r.xp = r.xp || 0;
  r.hp = r.hp ?? 100;
  r.maxHp = r.maxHp || 100;
  r.atk = r.atk || 10;
  r.def = r.def || 5;
  r.equip = r.equip || { arma: null, armadura: null };
  r.bag = r.bag || {};
  return r;
}

export function power(r) {
  let atk = r.atk || 10;
  let def = r.def || 5;
  if (r.equip?.arma && EQUIP[r.equip.arma]) atk += EQUIP[r.equip.arma].atk || 0;
  if (r.equip?.armadura && EQUIP[r.equip.armadura]) def += EQUIP[r.equip.armadura].def || 0;
  return { atk, def, score: atk + def + (r.level || 1) * 3 };
}

export async function equipItem(userId, itemId) {
  const item = EQUIP[itemId];
  if (!item) throw new ValidationError('Equip desconhecido.');
  const u = getUser(userId);
  if (!u?.rpg?.class) throw new ValidationError('Crie personagem: rpgcriar');
  const r = ensureRpg(u);
  if (!(r.bag[itemId] > 0)) throw new ValidationError('Você não tem esse item na bag.');
  r.bag[itemId]--;
  if (r.bag[itemId] <= 0) delete r.bag[itemId];
  const old = r.equip[item.slot];
  if (old) r.bag[old] = (r.bag[old] || 0) + 1;
  r.equip[item.slot] = itemId;
  await upsertUser(userId, { rpg: r });
  return { item, r };
}

export async function buyEquip(userId, itemId, name = '') {
  const item = EQUIP[itemId];
  if (!item) throw new ValidationError('Item inválido.');
  const { addWallet, getBalance } = await import('./economy.js');
  const bal = await getBalance(userId);
  if (bal.wallet < item.price) throw new ValidationError('GC insuficientes.');
  await addWallet(userId, -item.price, 'rpg_equip', name);
  const u = getUser(userId) || (await upsertUser(userId, { name }), getUser(userId));
  const r = ensureRpg(u);
  if (!r.class) {
    r.class = 'Alma Errante';
    r.level = 1;
  }
  r.bag[itemId] = (r.bag[itemId] || 0) + 1;
  await upsertUser(userId, { name, rpg: r });
  return item;
}

export async function fightBoss(userId, bossId, name = '') {
  const boss = BOSSES.find((b) => b.id === bossId);
  if (!boss) throw new ValidationError('Boss: caronte | cerbero | hadoes');
  const u = getUser(userId);
  if (!u?.rpg?.class) throw new ValidationError('rpgcriar primeiro');
  const r = ensureRpg(u);
  if (r.level < boss.minLevel) throw new ValidationError(`Nível mínimo ${boss.minLevel}.`);
  if (r.hp < 20) throw new ValidationError('HP baixo. Use rpgcurar.');

  const p = power(r);
  let bHp = boss.hp;
  let log = [];
  let turns = 0;
  while (bHp > 0 && r.hp > 0 && turns < 20) {
    turns++;
    const dmg = Math.max(1, p.atk + Math.floor(Math.random() * 10) - Math.floor(boss.atk / 5));
    bHp -= dmg;
    log.push(`Você: -${dmg} no boss`);
    if (bHp <= 0) break;
    const bd = Math.max(1, boss.atk - Math.floor(p.def / 2) + Math.floor(Math.random() * 8));
    r.hp -= bd;
    log.push(`Boss: -${bd} em você`);
  }

  const win = bHp <= 0 && r.hp > 0;
  if (win) {
    r.xp = (r.xp || 0) + boss.xp;
    r.level = Math.floor(Math.sqrt(r.xp / 50)) + 1;
    r.maxHp = 100 + r.level * 10;
    r.hp = Math.min(r.maxHp, r.hp + 20);
    const { addWallet } = await import('./economy.js');
    await addWallet(userId, boss.gold, 'boss', name);
  } else {
    r.hp = Math.max(1, Math.floor((r.maxHp || 100) * 0.3));
  }
  await upsertUser(userId, { name, rpg: r });
  return { win, boss, hp: r.hp, xp: r.xp, level: r.level, log: log.slice(-6), gold: win ? boss.gold : 0 };
}

export async function runDungeon(userId, dungeonId, name = '') {
  const d = DUNGEONS.find((x) => x.id === dungeonId);
  if (!d) throw new ValidationError('Dungeon: cripta | rio_estilo | trono');
  const u = getUser(userId);
  if (!u?.rpg?.class) throw new ValidationError('rpgcriar primeiro');
  const r = ensureRpg(u);
  if (r.level < d.minLevel) throw new ValidationError(`Nível mínimo ${d.minLevel}.`);

  let floorsClear = 0;
  let totalXp = 0;
  let totalGold = 0;
  const p = power(r);
  for (let f = 1; f <= d.floors; f++) {
    const enemyAtk = 8 + f * 5 + d.minLevel * 2;
    const chance = p.score / (p.score + enemyAtk + Math.random() * 20);
    if (chance < 0.35) {
      r.hp = Math.max(1, r.hp - enemyAtk);
      break;
    }
    floorsClear++;
    totalXp += d.xpPerFloor;
    totalGold += d.goldPerFloor;
    r.hp = Math.max(1, r.hp - Math.floor(enemyAtk / 3));
  }
  r.xp += totalXp;
  r.level = Math.floor(Math.sqrt(r.xp / 50)) + 1;
  r.maxHp = 100 + r.level * 10;
  await upsertUser(userId, { name, rpg: r });
  if (totalGold) {
    const { addWallet } = await import('./economy.js');
    await addWallet(userId, totalGold, 'dungeon', name);
  }
  return { dungeon: d, floorsClear, totalXp, totalGold, hp: r.hp, level: r.level };
}

export async function heal(userId, name = '') {
  const { getBalance, addWallet } = await import('./economy.js');
  const cost = 300;
  const bal = await getBalance(userId);
  if (bal.wallet < cost) throw new ValidationError(`Precisa ${cost} GC`);
  await addWallet(userId, -cost, 'heal', name);
  const u = getUser(userId);
  const r = ensureRpg(u || {});
  r.hp = r.maxHp || 100;
  await upsertUser(userId, { name, rpg: r });
  return r;
}

export default { EQUIP, BOSSES, DUNGEONS, power, equipItem, buyEquip, fightBoss, runDungeon, heal };
