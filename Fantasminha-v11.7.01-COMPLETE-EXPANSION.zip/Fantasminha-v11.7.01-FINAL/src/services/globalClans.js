import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';

const DEFAULT = { byId: {}, byMember: {}, requests: {}, invitations: {}, audit: [] };
const cleanName = (v) => String(v || '').trim().replace(/\s+/g, ' ');
const slug = (v) => cleanName(v).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 32);
const now = () => Date.now();
const PUBLIC_LIMIT = 100;
const PRIVATE_LIMIT = 50;
const PUBLIC_CREATION_COST = 25000;

function normalize(C) {
  C.byId ||= {}; C.byMember ||= {}; C.requests ||= {}; C.invitations ||= {}; C.audit ||= [];
  for (const c of Object.values(C.byId)) {
    c.members ||= [];
    c.visibility ||= 'private';
    c.globalAuthorized = !!c.globalAuthorized;
    c.status ||= c.globalAuthorized ? 'authorized' : 'private';
    c.roles ||= {};
    c.roles[c.leader] = 'leader';
    c.bank = Number(c.bank || 0);
    c.xp = Number(c.xp || 0);
    c.level = Math.max(1, Number(c.level || 1));
    c.power = Number(c.power || 100);
    for (const m of c.members) C.byMember[m] = c.id;
  }
  return C;
}
function appendAudit(C, action, actor, clanId, details = {}) {
  C.audit.push({ id: `CLA-${Math.random().toString(36).slice(2, 9).toUpperCase()}`, at: now(), action, actor, clanId, details });
  C.audit = C.audit.slice(-5000);
}

export function getGlobalClan(clanId) {
  const C = normalize(readCollection('global_clans', DEFAULT));
  return C.byId?.[clanId] || null;
}
export function getGlobalClanOf(userId) {
  const C = normalize(readCollection('global_clans', DEFAULT));
  const id = C.byMember?.[userId];
  return id ? C.byId?.[id] || null : null;
}
export function getClanByName(query) {
  const C = normalize(readCollection('global_clans', DEFAULT));
  const q = cleanName(query).toLowerCase();
  const s = slug(query);
  return C.byId?.[s] || Object.values(C.byId).find(c => c.name.toLowerCase() === q) || null;
}

export async function createGlobalClan(userId, name, options = {}) {
  const display = cleanName(name);
  if (display.length < 3 || display.length > 28) throw new ValidationError('O nome do Clã deve ter entre 3 e 28 caracteres.');
  const id = slug(display);
  if (!id) throw new ValidationError('Nome de clã inválido.');
  const visibility = options.visibility === 'public' ? 'public' : 'private';
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0);
    if (C.byMember[userId]) throw new ValidationError('Você já pertence a um Clã.');
    if (C.byId[id]) throw new ValidationError('Esse Clã já existe. Escolha outro nome.');
    const clan = {
      id, name: display, leader: userId, vice: null, members: [userId],
      visibility, public: visibility === 'public', globalAuthorized: false,
      status: visibility === 'public' ? 'public' : 'private',
      roles: { [userId]: 'leader' },
      xp: 0, level: 1, bank: 0, wins: 0, losses: 0, power: 100,
      war: null, createdAt: now(), updatedAt: now(), publicCreatedAt: visibility === 'public' ? now() : null,
      stats: { recruited: 0, donations: 0, battles: 0, territories: 0 }
    };
    C.byId[id] = clan; C.byMember[userId] = id;
    appendAudit(C, 'created', userId, id, { visibility });
    return C;
  }, DEFAULT);
}

export async function makePublic(userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const id = C.byMember[userId]; const c = id && C.byId[id];
    if (!c) throw new ValidationError('Você não possui Clã.');
    if (c.leader !== userId) throw new ValidationError('Somente o líder pode tornar o Clã público.');
    if (c.visibility === 'public') throw new ValidationError('Seu Clã já é público.');
    c.visibility = 'public'; c.public = true; c.status = 'public'; c.publicCreatedAt = now(); c.updatedAt = now();
    appendAudit(C, 'made_public', userId, c.id);
    return C;
  }, DEFAULT);
}

export async function requestJoin(userId, query) {
  const clan = getClanByName(query);
  if (!clan) throw new ValidationError('Clã não encontrado.');
  if (clan.visibility !== 'public') throw new ValidationError('Esse Clã é privado. O líder precisa convidar você.');
  if (clan.members.length >= PUBLIC_LIMIT) throw new ValidationError('Esse Clã público atingiu o limite de 100 membros.');
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); C.requests[clan.id] ||= {};
    if (C.byMember[userId]) throw new ValidationError('Você já pertence a um Clã.');
    C.requests[clan.id][userId] = { userId, at: now() };
    appendAudit(C, 'join_requested', userId, clan.id);
    return C;
  }, DEFAULT);
}

export async function approveJoin(actor, clanId, userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const c = C.byId[clanId];
    if (!c) throw new ValidationError('Clã não encontrado.');
    if (c.leader !== actor && c.vice !== actor) throw new ValidationError('Somente líder/vice pode aprovar membros.');
    if (!C.requests[clanId]?.[userId]) throw new ValidationError('Não existe solicitação desse usuário.');
    if (C.byMember[userId]) throw new ValidationError('Esse usuário já pertence a um Clã.');
    if (c.members.length >= (c.visibility === 'public' ? PUBLIC_LIMIT : PRIVATE_LIMIT)) throw new ValidationError('Limite de membros atingido.');
    c.members.push(userId); c.roles[userId] = 'member'; c.stats.recruited++; c.updatedAt = now(); C.byMember[userId] = c.id;
    delete C.requests[clanId][userId]; appendAudit(C, 'join_approved', actor, clanId, { userId });
    return C;
  }, DEFAULT);
}

export async function invite(actor, userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const id = C.byMember[actor]; const c = id && C.byId[id];
    if (!c) throw new ValidationError('Você não possui Clã.');
    if (c.leader !== actor && c.vice !== actor) throw new ValidationError('Somente líder/vice pode convidar.');
    if (C.byMember[userId]) throw new ValidationError('Esse usuário já pertence a um Clã.');
    if (c.members.length >= (c.visibility === 'public' ? PUBLIC_LIMIT : PRIVATE_LIMIT)) throw new ValidationError('Limite de membros atingido.');
    C.invitations[userId] ||= {}; C.invitations[userId][c.id] = { clanId: c.id, at: now(), by: actor };
    appendAudit(C, 'invited', actor, c.id, { userId }); return C;
  }, DEFAULT);
}

export async function acceptInvite(userId, clanId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const c = C.byId[clanId];
    if (!c) throw new ValidationError('Clã não encontrado.');
    if (!C.invitations[userId]?.[clanId]) throw new ValidationError('Convite não encontrado.');
    if (C.byMember[userId]) throw new ValidationError('Você já pertence a um Clã.');
    if (c.members.length >= (c.visibility === 'public' ? PUBLIC_LIMIT : PRIVATE_LIMIT)) throw new ValidationError('Limite de membros atingido.');
    c.members.push(userId); c.roles[userId] = 'member'; c.updatedAt = now(); C.byMember[userId] = c.id;
    delete C.invitations[userId][clanId]; appendAudit(C, 'invite_accepted', userId, clanId); return C;
  }, DEFAULT);
}

export async function joinGlobalClan(userId, query) { await requestJoin(userId, query); const clan = getClanByName(query); return clan; }

export async function leaveGlobalClan(userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const id = C.byMember[userId]; const clan = id && C.byId[id];
    if (!clan) throw new ValidationError('Você não pertence a um Clã.');
    if (clan.leader === userId) throw new ValidationError('O líder deve transferir a liderança ou dissolver o Clã antes de sair.');
    clan.members = clan.members.filter(m => m !== userId); delete clan.roles[userId]; delete C.byMember[userId]; clan.updatedAt = now();
    appendAudit(C, 'left', userId, clan.id); return C;
  }, DEFAULT);
}

export async function dissolveGlobalClan(userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const id = C.byMember[userId]; const clan = id && C.byId[id];
    if (!clan) throw new ValidationError('Você não possui Clã.');
    if (clan.leader !== userId) throw new ValidationError('Somente o líder pode dissolver o Clã.');
    for (const m of clan.members || []) delete C.byMember[m];
    delete C.byId[id]; delete C.requests[id];
    for (const inv of Object.values(C.invitations)) delete inv[id];
    appendAudit(C, 'dissolved', userId, id); return C;
  }, DEFAULT);
}

export async function setVice(actor, userId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const id = C.byMember[actor]; const c = id && C.byId[id];
    if (!c || c.leader !== actor) throw new ValidationError('Somente o líder pode nomear vice.');
    if (!c.members.includes(userId)) throw new ValidationError('O usuário precisa ser membro do Clã.');
    c.vice = userId; c.roles[userId] = 'vice'; c.updatedAt = now(); appendAudit(C, 'vice_changed', actor, c.id, { userId }); return C;
  }, DEFAULT);
}

export async function authorizeGlobal(actor, clanId) {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const c = C.byId[clanId];
    if (!c) throw new ValidationError('Clã não encontrado.');
    if (c.visibility !== 'public') throw new ValidationError('Somente Clãs públicos podem receber autorização Global.');
    c.globalAuthorized = true; c.status = 'authorized'; c.globalAuthorizedAt = now(); c.globalAuthorizedBy = actor; c.updatedAt = now();
    appendAudit(C, 'global_authorized', actor, c.id); return C;
  }, DEFAULT);
}
export async function revokeGlobal(actor, clanId, reason = '') {
  return updateCollection('global_clans', C0 => {
    const C = normalize(C0); const c = C.byId[clanId]; if (!c) throw new ValidationError('Clã não encontrado.');
    c.globalAuthorized = false; c.status = c.visibility === 'public' ? 'public' : 'private'; c.globalRevokedAt = now(); c.globalRevokedBy = actor; c.globalRevokedReason = reason.slice(0,200); c.updatedAt = now();
    appendAudit(C, 'global_revoked', actor, c.id, { reason }); return C;
  }, DEFAULT);
}

export function listGlobalClans(limit = 10) {
  const C = normalize(readCollection('global_clans', DEFAULT));
  return Object.values(C.byId || {}).filter(c => c.globalAuthorized).sort((a,b) => ((b.xp||0)-(a.xp||0)) || ((b.wins||0)-(a.wins||0))).slice(0, Math.max(1, Math.min(100, limit)));
}
export function listPublicClans(limit = 20) {
  const C = normalize(readCollection('global_clans', DEFAULT));
  return Object.values(C.byId || {}).filter(c => c.visibility === 'public').sort((a,b)=>((b.level||1)-(a.level||1))||((b.members?.length||0)-(a.members?.length||0))).slice(0, Math.max(1, Math.min(50, limit)));
}
export function listJoinRequests(clanId) { const C=normalize(readCollection('global_clans',DEFAULT)); return Object.values(C.requests?.[clanId]||{}); }
export function listInvites(userId) { const C=normalize(readCollection('global_clans',DEFAULT)); return Object.keys(C.invitations?.[userId]||{}).map(id=>C.byId[id]).filter(Boolean); }
export function listAudit(limit=50){return normalize(readCollection('global_clans',DEFAULT)).audit.slice(-limit).reverse();}

export async function addClanXp(clanId, amount) {
  amount = Math.max(0, Math.floor(Number(amount) || 0));
  if (!amount) return getGlobalClan(clanId);
  return updateCollection('global_clans', C0 => { const C=normalize(C0); const c=C.byId?.[clanId]; if(!c)return C; c.xp=(c.xp||0)+amount; c.level=Math.max(1,Math.floor(Math.sqrt(c.xp/100))+1); c.power=100+c.level*25+(c.members?.length||0)*5; c.updatedAt=now(); return C; }, DEFAULT);
}
export const costs = { publicCreation: PUBLIC_CREATION_COST };
export default { getGlobalClan,getGlobalClanOf,getClanByName,createGlobalClan,makePublic,requestJoin,approveJoin,invite,acceptInvite,joinGlobalClan,leaveGlobalClan,dissolveGlobalClan,setVice,authorizeGlobal,revokeGlobal,listGlobalClans,listPublicClans,listJoinRequests,listInvites,listAudit,addClanXp,costs };
