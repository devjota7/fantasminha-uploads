import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import config from '../core/config.js';
import { updateCollection } from '../database/store.js';

const MAX_IMAGE_BYTES = 12 * 1024 * 1024;

function unwrapMessage(message) {
  let m = message;
  for (let i = 0; i < 5 && m; i++) {
    if (m.ephemeralMessage?.message) m = m.ephemeralMessage.message;
    else if (m.viewOnceMessage?.message) m = m.viewOnceMessage.message;
    else if (m.viewOnceMessageV2?.message) m = m.viewOnceMessageV2.message;
    else break;
  }
  return m || {};
}

export function getImageMessage(info) {
  const m = unwrapMessage(info?.message);
  if (m.imageMessage) return { type: 'image', message: m.imageMessage };
  if (m.documentWithCaptionMessage?.message?.documentMessage?.mimetype?.startsWith('image/')) return { type: 'document-image', message: m.documentWithCaptionMessage.message.documentMessage };
  if (m.documentMessage?.mimetype?.startsWith('image/')) return { type: 'document-image', message: m.documentMessage };
  return null;
}

async function streamToBuffer(stream) {
  const chunks = [];
  let size = 0;
  for await (const chunk of stream) {
    size += chunk.length;
    if (size > MAX_IMAGE_BYTES) throw new Error('imagem acima do limite de 12 MB');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

export async function downloadImage(info) {
  const found = getImageMessage(info);
  if (!found) return null;
  const { default: sharp } = await import('sharp');
  const { downloadContentFromMessage } = await import('baileys');
  const mediaType = found.type === 'image' ? 'image' : 'document';
  const buffer = await streamToBuffer(await downloadContentFromMessage(found.message, mediaType));
  const meta = await sharp(buffer, { failOn: 'none' }).metadata();
  return {
    buffer,
    mime: found.message.mimetype || 'image/jpeg',
    width: meta.width || 0,
    height: meta.height || 0,
    format: meta.format || 'unknown',
    size: buffer.length,
    sha256: crypto.createHash('sha256').update(buffer).digest('hex')
  };
}

function extractJson(text) {
  const raw = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(raw); } catch {}
  const match = raw.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try { return JSON.parse(match[0]); } catch { return null; }
}

async function geminiVision(buffer, mime, context = {}) {
  const key = config.secrets.gemini;
  if (!key) return { available: false, reason: 'GEMINI_API_KEY não configurada' };
  const model = process.env.GEMINI_VISION_MODEL || 'gemini-2.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
  const policy = context.analysis || {};
  const instruction = policy.instruction || 'Analise objetivamente apenas as informações visíveis e relevantes para esta pergunta de triagem.';
  const compare = Array.isArray(policy.compareQuestionIds) ? policy.compareQuestionIds : [];
  const prompt = `Você é o módulo de análise multimodal de uma triagem administrativa. Analise SOMENTE o conteúdo visual que realmente estiver presente. Não invente campos, não confirme autenticidade, propriedade de conta, identidade da pessoa ou existência de dados em serviços externos. A análise é um sinal de apoio para um administrador humano, não uma prova. Pergunta original: ${context.question || ''}. Instrução personalizada do administrador: ${instruction}. OCR solicitado: ${policy.ocr !== false ? 'sim' : 'não'}. IDs de perguntas cujas respostas podem ser comparadas: ${JSON.stringify(compare)}. Respostas da ficha: ${JSON.stringify(context.answers || {})}. Retorne SOMENTE JSON válido com: {"documentType":"", "fields":{}, "visibleFields":[], "unreadableFields":[], "quality":"", "confidence":"low|medium|high", "alerts":[], "comparisons":[], "summary":""}.`;

  try {
    const { default: axios } = await import('axios');
    const response = await axios.post(url, {
      contents: [{ parts: [
        { text: prompt },
        { inline_data: { mime_type: mime || 'image/jpeg', data: buffer.toString('base64') } }
      ] }],
      generationConfig: { temperature: 0.1, responseMimeType: 'application/json' }
    }, { timeout: 45_000, maxContentLength: 20 * 1024 * 1024 });
    const text = response.data?.candidates?.[0]?.content?.parts?.map(p => p.text || '').join('') || '';
    return { available: true, ...((extractJson(text) || {})), raw: undefined, provider: 'gemini' };
  } catch (error) {
    return { available: false, reason: `falha na análise IA: ${error.response?.data?.error?.message || error.message}` };
  }
}

function localQuality(image) {
  const pixels = (image.width || 0) * (image.height || 0);
  if (!pixels) return 'desconhecida';
  if (pixels < 400 * 400) return 'baixa';
  if (pixels < 1000 * 700) return 'média';
  return 'boa';
}

export async function analyzeTriageImage(image, context = {}) {
  const local = {
    quality: localQuality(image),
    width: image.width,
    height: image.height,
    size: image.size,
    sha256: image.sha256,
    alerts: []
  };
  if (local.quality === 'baixa') local.alerts.push('imagem com resolução baixa');
  const ai = await geminiVision(image.buffer, image.mime, context);
  const result = {
    available: ai.available,
    provider: ai.provider || null,
    documentType: ai.documentType || 'não identificado',
    id: ai.id ?? ai.fields?.id ?? null,
    nickname: ai.nickname ?? ai.fields?.nickname ?? ai.fields?.nick ?? null,
    fields: ai.fields && typeof ai.fields === 'object' ? ai.fields : {},
    summary: ai.summary || '',
    level: ai.level ?? null,
    region: ai.region ?? null,
    visibleFields: Array.isArray(ai.visibleFields) ? ai.visibleFields : [],
    unreadableFields: Array.isArray(ai.unreadableFields) ? ai.unreadableFields : [],
    quality: ai.quality || local.quality,
    confidence: ai.confidence || 'low',
    alerts: [...local.alerts, ...(Array.isArray(ai.alerts) ? ai.alerts : [])],
    comparisons: Array.isArray(ai.comparisons) ? ai.comparisons : [],
    analyzedAt: Date.now(),
    sha256: image.sha256,
    dimensions: { width: image.width, height: image.height },
    unavailableReason: ai.available ? '' : ai.reason
  };
  return result;
}


export async function saveTriageImageFile(triageId, mediaId, image) {
  const dir = path.join(config.root, 'data', 'triage-media');
  fs.mkdirSync(dir, { recursive: true });
  const ext = image.format && /^[a-z0-9]+$/i.test(image.format) ? image.format.toLowerCase() : 'jpg';
  const file = path.join(dir, `${triageId}-${mediaId}.${ext}`);
  fs.writeFileSync(file, image.buffer);
  return file;
}

export async function persistTriageMedia(triageId, mediaRecord) {
  await updateCollection('triage_media', db => {
    db.byTriage ||= {};
    db.byTriage[triageId] ||= [];
    db.byTriage[triageId].push(mediaRecord);
    if (db.byTriage[triageId].length > 10) db.byTriage[triageId] = db.byTriage[triageId].slice(-10);
    return db;
  }, { byTriage: {} });
}

export default { getImageMessage, downloadImage, analyzeTriageImage, persistTriageMedia };
