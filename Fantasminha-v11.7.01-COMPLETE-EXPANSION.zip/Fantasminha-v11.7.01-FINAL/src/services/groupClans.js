import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';

const DEFAULT = { byId: {} };
const key = (v) => String(v || '').trim();
const now = () => Date.now();

export function getGroupClan(groupId) {
  if (!groupId) return null;
  return readCollection('group_clans', DEFAULT).byId?.[groupId] || null;
}

export async function ensureGroupClan(groupId, groupName = 'Grupo', participantCount = 0) {
  if (!groupId) throw new ValidationError('Grupo inválido.');
  return updateCollection('group_clans', C => {
    C.byId ||= {};
    const existing = C.byId[groupId];
    if (!existing) {
      C.byId[groupId] = {
        id: groupId,
        name: String(groupName || 'Grupo').trim() || 'Grupo',
        type: 'group',
        warEnabled: false,
        war: null,
        members: [],
        participantCount: Math.max(0, Number(participantCount) || 0),
        xp: 0, level: 1, power: 100,
        wins: 0, losses: 0,
        createdAt: now(), updatedAt: now()
      };
    } else {
      existing.name = String(groupName || existing.name || 'Grupo').trim() || existing.name;
      existing.participantCount = Math.max(0, Number(participantCount) || existing.participantCount || 0);
      existing.members ||= [];
      existing.updatedAt = now();
    }
    return C;
  }, DEFAULT);
}

export async function setGroupWarEnabled(groupId, enabled, groupName = 'Grupo', participantCount = 0) {
  // Idempotente: uma configuração administrativa nunca deve falhar só porque o registro
  // acabou de ser criado nesta mesma sequência de eventos.
  await ensureGroupClan(groupId, groupName, participantCount);
  if (!enabled) {
    const W = readCollection('wars', { byId: {} });
    const busy = Object.values(W.byId || {}).some(w => ['pending','preparation','active'].includes(w.status) && (w.attackerId === groupId || w.defenderId === groupId));
    if (busy) throw new ValidationError('Não é possível desativar guerras enquanto existe um desafio ou guerra ativa.');
  }
  return updateCollection('group_clans', C => {
    C.byId ||= {};
    const c = C.byId[groupId];
    if (!c) throw new ValidationError('Clã do Grupo ainda não foi inicializado.');
    c.warEnabled = !!enabled; c.updatedAt = now(); return C;
  }, DEFAULT);
}

export async function setGroupMembers(groupId, members) {
  const ids = [...new Set((members || []).map(key).filter(Boolean))];
  return updateCollection('group_clans', C => {
    const c = C.byId?.[groupId]; if (!c) throw new ValidationError('Clã do Grupo não encontrado.');
    c.members = ids; c.participantCount = ids.length; c.updatedAt = now(); return C;
  }, DEFAULT);
}

export async function addGroupWarXp(groupId, amount) {
  amount = Math.max(0, Math.floor(Number(amount) || 0));
  return updateCollection('group_clans', C => {
    const c = C.byId?.[groupId]; if (!c) return C;
    c.xp = (c.xp || 0) + amount;
    c.level = Math.max(1, Math.floor(Math.sqrt(c.xp / 150)) + 1);
    c.power = 100 + c.level * 30 + (c.participantCount || 0) * 8;
    c.updatedAt = now(); return C;
  }, DEFAULT);
}

export function listWarEligibleGroups(excludeId) {
  const C = readCollection('group_clans', DEFAULT);
  const W = readCollection('wars', { byId: {} });
  const busy = new Set();
  for (const w of Object.values(W.byId || {})) {
    if (['pending','preparation','active'].includes(w.status)) { busy.add(w.attackerId); busy.add(w.defenderId); }
  }
  return Object.values(C.byId || {})
    .filter(c => c.id !== excludeId && c.warEnabled && !busy.has(c.id))
    .sort((a,b) => ((b.power||0)-(a.power||0)) || ((b.participantCount||0)-(a.participantCount||0)));
}
