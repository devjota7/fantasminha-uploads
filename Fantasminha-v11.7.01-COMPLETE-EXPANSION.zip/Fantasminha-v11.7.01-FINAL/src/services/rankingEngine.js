import { listStats } from './statsEngine.js';
export function ranking(groupId,limit=10){return listStats(groupId).slice(0,Math.max(1,Math.min(50,Number(limit)||10))).map((x,i)=>({...x,position:i+1}));}
export function periodKey(period='all',now=new Date()){const y=now.getUTCFullYear(),m=String(now.getUTCMonth()+1).padStart(2,'0'),d=String(now.getUTCDate()).padStart(2,'0'); if(period==='daily')return `${y}-${m}-${d}`; if(period==='weekly'){const day=(now.getUTCDay()+6)%7; const n=new Date(now);n.setUTCDate(n.getUTCDate()-day);return n.toISOString().slice(0,10);} if(period==='monthly')return `${y}-${m}`; return 'all';}
export default {ranking,periodKey};
