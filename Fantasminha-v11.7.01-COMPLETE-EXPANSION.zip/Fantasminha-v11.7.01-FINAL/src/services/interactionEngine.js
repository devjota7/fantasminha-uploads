const choices=['A','B','C','D'];
export function choose(items){const arr=Array.isArray(items)?items.filter(Boolean):[];return arr.length?arr[Math.floor(Math.random()*arr.length)]:null;}
export function chance(){return Math.floor(Math.random()*101);}
export function dice(sides=6){return Math.floor(Math.random()*Math.max(2,Number(sides)||6))+1;}
export function coin(){return Math.random()<.5?'🪙 Cara':'🪙 Coroa';}
export function compatibility(a,b){const seed=[String(a||''),String(b||'')].join('|').split('').reduce((n,c)=>(n*31+c.charCodeAt(0))%100000,7);return seed%101;}
export function pickGroup(members=[]){return choose(members);}
export function option(){return choose(choices);}
export default {choose,chance,dice,coin,compatibility,pickGroup,option};
