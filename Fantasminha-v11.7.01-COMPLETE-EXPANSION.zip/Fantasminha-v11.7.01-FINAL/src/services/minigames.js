import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import gameSessions from './gameSessionManager.js';

const WORDS = [
  'ALMA', 'VELO', 'LIMBO', 'SOMBRA', 'FANTASMA', 'TUNEL', 'RITUAL', 'CEMITERIO',
  'ESPECTRO', 'ABISMO', 'NOITE', 'BRUMA', 'OSSO', 'LAMENTO', 'PURGA'
];

function key(groupId) {
  return groupId || 'global';
}

export async function wordleStart(groupId) {
  const scope=key(groupId);
  const active=gameSessions.activeForScope(scope);
  if(active) throw new ValidationError(`Já existe uma sessão de ${active.game} neste grupo.`);
  gameSessions.begin(scope,'wordle');
  const word = WORDS[Math.floor(Math.random() * WORDS.length)];
  await updateCollection('minigames', (M) => {
    if (!M.wordle) M.wordle = {};
    M.wordle[key(groupId)] = { word, tries: 0, max: 6, guesses: [], done: false };
    return M;
  }, {});
  return { len: word.length, max: 6 };
}

export async function wordleGuess(groupId, guess, userId, name) {
  guess = (guess || '').toUpperCase().replace(/[^A-Z]/g, '');
  const M = readCollection('minigames', {});
  const g = M.wordle?.[key(groupId)];
  if (!g || g.done) throw new ValidationError('Inicie: wordle');
  if (guess.length !== g.word.length) throw new ValidationError(`A palavra tem ${g.word.length} letras.`);
  g.tries++;
  g.guesses.push(guess);
  let pattern = '';
  for (let i = 0; i < guess.length; i++) {
    if (guess[i] === g.word[i]) pattern += '🟩';
    else if (g.word.includes(guess[i])) pattern += '🟨';
    else pattern += '⬛';
  }
  let win = guess === g.word;
  if (win || g.tries >= g.max) { g.done = true; gameSessions.end(key(groupId),'wordle'); }
  await updateCollection('minigames', (X) => {
    if (!X.wordle) X.wordle = {};
    X.wordle[key(groupId)] = g;
    return X;
  }, {});
  if (win) {
    try {
      const { addWeeklyScore } = await import('./rankings.js');
      await addWeeklyScore(userId, name, 'games', 30);
      const { addWallet } = await import('./economy.js');
      await addWallet(userId, 150, 'wordle', name);
    } catch {}
  }
  return { pattern, tries: g.tries, max: g.max, win, lose: g.done && !win, word: g.done ? g.word : null };
}

export async function quizStart(groupId) {
  const questions=[
    {question:'Qual é o maior planeta do Sistema Solar?',options:['Terra','Júpiter','Marte','Vênus'],answer:'Júpiter'},
    {question:'Quanto é 7 × 8?',options:['54','56','64','48'],answer:'56'},
    {question:'Qual é a capital do Brasil?',options:['Rio de Janeiro','Brasília','São Paulo','Salvador'],answer:'Brasília'}
  ];
  const q=questions[Math.floor(Math.random()*questions.length)];
  const scope=key(groupId);
  const current=gameSessions.get(scope,'quiz');
  if(current?.active) throw new ValidationError('Já existe um quiz ativo neste grupo.');
  gameSessions.begin(scope,'quiz',{endsAt:Date.now()+30000});
  await updateCollection('minigames',M=>{M.quiz??={};M.quiz[scope]={question:q.question,options:q.options,answers:[q.answer],display:q.answer,startedAt:Date.now(),endsAt:Date.now()+30000};return M;},{});
  return {...q,endsAt:Date.now()+30000};
}
export async function quizAnswer(groupId,answer,userId,name){
  const scope=key(groupId);
  const M=readCollection('minigames',{}); const g=M.quiz?.[scope];
  if(!g) throw new ValidationError('Nenhum quiz ativo.');
  if(g.endsAt && Date.now()>g.endsAt){ await updateCollection('minigames',X=>{if(X.quiz) delete X.quiz[scope];return X;},{}); gameSessions.end(scope,'quiz'); throw new ValidationError('⏰ Tempo esgotado. O quiz foi encerrado.'); }
  const value=/^\d+$/.test(String(answer||'')) ? g.options[Number(answer)-1] : answer;
  const ok=(g.answers||[]).some(a=>String(a).toLowerCase()===String(value||'').toLowerCase());
  await updateCollection('minigames',X=>{delete X.quiz[scope];return X;},{});
  gameSessions.end(scope,'quiz');
  return {ok,display:g.display,options:g.options};
}

export async function stopStart(groupId, letter) {
  const scope=key(groupId);
  const active=gameSessions.activeForScope(scope);
  if(active) throw new ValidationError(`Já existe uma sessão de ${active.game} neste grupo.`);
  gameSessions.begin(scope,'stop');
  letter = (letter || 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'[Math.floor(Math.random() * 26)]).toUpperCase()[0];
  await updateCollection('minigames', (M) => {
    if (!M.stop) M.stop = {};
    M.stop[key(groupId)] = {
      letter,
      answers: {},
      categories: ['nome', 'animal', 'alma', 'lugar', 'objeto'],
      endsAt: Date.now() + 90000
    };
    return M;
  }, {});
  return letter;
}

export async function stopAnswer(groupId, userId, name, text) {
  const M = readCollection('minigames', {});
  const s = M.stop?.[key(groupId)];
  if (!s) throw new ValidationError('stop para iniciar');
  if (Date.now() > s.endsAt) throw new ValidationError('⏰ Tempo esgotado. Use ×stopfim para ver o placar.');
  // formato: nome:X animal:Y ...
  const parts = {};
  for (const cat of s.categories) {
    const re = new RegExp(`${cat}\\s*[:=]\\s*([^,;]+)`, 'i');
    const m = text.match(re);
    if (m) parts[cat] = m[1].trim();
  }
  if (!Object.keys(parts).length) throw new ValidationError('Ex: nome:Ana animal:Aranha alma:Aflita');
  for (const [c, v] of Object.entries(parts)) {
    if (!v.toUpperCase().startsWith(s.letter)) throw new ValidationError(`${c} deve começar com ${s.letter}`);
  }
  s.answers[userId] = { name, parts };
  await updateCollection('minigames', (X) => {
    X.stop[key(groupId)] = s;
    return X;
  }, {});
  return { letter: s.letter, parts };
}

export async function stopEnd(groupId) {
  const M = readCollection('minigames', {});
  const s = M.stop?.[key(groupId)];
  if (!s) throw new ValidationError('Nenhum stop ativo');
  const scores = {};
  for (const [uid, ans] of Object.entries(s.answers || {})) {
    let pts = 0;
    for (const [cat, val] of Object.entries(ans.parts || {})) {
      const others = Object.values(s.answers).filter((a) => a.parts?.[cat]?.toLowerCase() === val.toLowerCase());
      pts += others.length <= 1 ? 10 : 5;
    }
    scores[uid] = { name: ans.name, pts };
    try {
      const { addWeeklyScore } = await import('./rankings.js');
      await addWeeklyScore(uid, ans.name, 'games', pts);
    } catch {}
  }
  gameSessions.end(key(groupId),'stop');
  await updateCollection('minigames', (X) => {
    delete X.stop[key(groupId)];
    return X;
  }, {});
  return { letter: s.letter, scores };
}

export async function quitGame(groupId, userId) {
  const gk=key(groupId);
  let removed=[];
  await updateCollection('minigames', M=>{
    if(M.wordle?.[gk]){delete M.wordle[gk];removed.push('Wordle');}
    if(M.stop?.[gk]){delete M.stop[gk];removed.push('Stop');}
    if(M.bj?.[userId]){delete M.bj[userId];removed.push('Blackjack');}
    return M;
  },{});
  gameSessions.end(gk,'wordle');
  gameSessions.end(gk,'stop');
  gameSessions.end(gk,'quiz');
  return removed;
}

function handValue(cards) {
  let v = 0;
  let aces = 0;
  for (const c of cards) {
    if (c.v === 1) {
      aces++;
      v += 11;
    } else v += c.v;
  }
  while (v > 21 && aces) {
    v -= 10;
    aces--;
  }
  return v;
}

function draw() {
  const n = 1 + Math.floor(Math.random() * 13);
  const v = n > 10 ? 10 : n;
  const faces = { 1: 'A', 11: 'J', 12: 'Q', 13: 'K' };
  return { n, v, face: faces[n] || String(n) };
}

export async function bjStart(userId, bet, name) {
  bet = Math.floor(Number(bet));
  if (!bet || bet < 50) throw new ValidationError('bj <aposta>=50+');
  const { getBalance, addWallet } = await import('./economy.js');
  const bal = await getBalance(userId);
  if (bal.wallet < bet) throw new ValidationError('Saldo insuficiente');
  await addWallet(userId, -bet, 'bj_bet', name);
  const player = [draw(), draw()];
  const dealer = [draw(), draw()];
  await updateCollection('minigames', (M) => {
    if (!M.bj) M.bj = {};
    M.bj[userId] = { bet, player, dealer, done: false, name };
    return M;
  }, {});
  return {
    player: player.map((c) => c.face).join(' '),
    pVal: handValue(player),
    dealerShow: dealer[0].face
  };
}

export async function bjHit(userId) {
  const M = readCollection('minigames', {});
  const g = M.bj?.[userId];
  if (!g || g.done) throw new ValidationError('bj <aposta> primeiro');
  g.player.push(draw());
  const val = handValue(g.player);
  let result = null;
  if (val > 21) {
    g.done = true;
    result = { bust: true, val, bet: g.bet };
  }
  await updateCollection('minigames', (X) => {
    X.bj[userId] = g;
    return X;
  }, {});
  return {
    player: g.player.map((c) => c.face).join(' '),
    val,
    ...result
  };
}

export async function bjStand(userId) {
  const M = readCollection('minigames', {});
  const g = M.bj?.[userId];
  if (!g || g.done) throw new ValidationError('Sem jogo ativo');
  while (handValue(g.dealer) < 17) g.dealer.push(draw());
  const pv = handValue(g.player);
  const dv = handValue(g.dealer);
  g.done = true;
  let win = 0;
  if (pv <= 21 && (dv > 21 || pv > dv)) win = g.bet * 2;
  else if (pv === dv) win = g.bet;
  if (win) {
    const { addWallet } = await import('./economy.js');
    await addWallet(userId, win, 'bj_win', g.name);
    try {
      const { addWeeklyScore } = await import('./rankings.js');
      await addWeeklyScore(userId, g.name, 'games', Math.floor(win / 10));
    } catch {}
  }
  await updateCollection('minigames', (X) => {
    X.bj[userId] = g;
    return X;
  }, {});
  return {
    player: g.player.map((c) => c.face).join(' '),
    dealer: g.dealer.map((c) => c.face).join(' '),
    pv,
    dv,
    win,
    bet: g.bet
  };
}

export default { wordleStart, wordleGuess, quizStart, quizAnswer, stopStart, stopAnswer, stopEnd, quitGame, bjStart, bjHit, bjStand };
