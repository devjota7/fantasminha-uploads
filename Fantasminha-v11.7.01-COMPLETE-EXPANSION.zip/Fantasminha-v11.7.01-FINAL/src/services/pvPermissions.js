import { readCollection, updateCollection } from '../database/store.js';
import { configuredOwner } from '../core/permissions.js';

const normalize = value => String(value ?? '').trim().toLowerCase();
const variants = value => {
  const raw = normalize(value);
  if (!raw) return [];
  const base = raw.split('@')[0].split(':')[0];
  return [...new Set([raw, base])];
};

export function isPvAllowed(userId) {
  if (!userId) return false;
  if (configuredOwner(userId)) return true;
  const d = readCollection('pv_permissions', { byUser: {} });
  const v = variants(userId);
  return Object.entries(d.byUser || {}).some(([key, row]) => row?.active !== false && v.some(x => variants(key).includes(x)));
}

export async function grantPvPermission(userId, actor = null) {
  if (!userId) throw new Error('Usuário inválido.');
  const key = normalize(userId);
  return updateCollection('pv_permissions', d => {
    d.byUser ??= {};
    const previous = d.byUser[key] || {};
    d.byUser[key] = { userId: key, active: true, grantedAt: previous.grantedAt || Date.now(), updatedAt: Date.now(), grantedBy: actor || previous.grantedBy || null };
    return d;
  }, { byUser: {} });
}

export async function revokePvPermission(userId, actor = null) {
  if (!userId) throw new Error('Usuário inválido.');
  const key = normalize(userId);
  let changed = false;
  await updateCollection('pv_permissions', d => {
    d.byUser ??= {};
    const row = d.byUser[key];
    if (row?.active !== false) changed = !!row;
    if (row) d.byUser[key] = { ...row, active: false, revokedAt: Date.now(), revokedBy: actor || null };
    return d;
  }, { byUser: {} });
  return changed;
}

export function listPvPermissions() {
  const d = readCollection('pv_permissions', { byUser: {} });
  return Object.values(d.byUser || {}).filter(x => x?.active !== false).sort((a,b) => (a.userId || '').localeCompare(b.userId || ''));
}

export default { isPvAllowed, grantPvPermission, revokePvPermission, listPvPermissions };
