import { readCollection, updateCollection } from '../database/store.js';

const sessions = new Map();
const timers = new Map();
const keyOf = (scope, game) => `${scope}:${game}`;

export function begin(scope, game, data = {}) {
  const key = keyOf(scope, game);
  const current = sessions.get(key);
  if (current?.active) return { ok:false, current };
  const session = { scope, game, active:true, createdAt:Date.now(), ...data };
  sessions.set(key, session);
  return { ok:true, session };
}
export function get(scope, game) { return sessions.get(keyOf(scope, game)) || null; }
export function activeForScope(scope) { return [...sessions.values()].find(s => s.scope === scope && s.active) || null; }
export function end(scope, game) {
  const key=keyOf(scope,game); const s=sessions.get(key)||null; sessions.delete(key); stopTimer(scope,game); return s;
}
export function stopTimer(scope,game){ const key=keyOf(scope,game); const t=timers.get(key); if(t){clearTimeout(t.timeout);clearInterval(t.interval);timers.delete(key);} }
export function startTimer(scope, game, ms, onExpire) {
  stopTimer(scope,game);
  const key=keyOf(scope,game); const startedAt=Date.now();
  const timeout=setTimeout(async()=>{try{await onExpire?.();}finally{timers.delete(key);}},Math.max(1,ms));
  timeout.unref?.();
  timers.set(key,{timeout,startedAt,endsAt:startedAt+ms});
  return {endsAt:startedAt+ms};
}
export function remaining(scope,game){const t=timers.get(keyOf(scope,game));return t?Math.max(0,t.endsAt-Date.now()):null;}
export function snapshot(){return [...sessions.values()].filter(s=>s.active).map(s=>({...s}));}
export function clearAll(){for(const k of timers.keys()){const t=timers.get(k);clearTimeout(t.timeout);clearInterval(t.interval);}timers.clear();sessions.clear();}
export default {begin,get,activeForScope,end,startTimer,stopTimer,remaining,snapshot,clearAll};
