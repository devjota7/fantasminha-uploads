/** Knowledge Engine local: consulta textual segura antes de respostas de suporte/IA. */
const docs = new Map();

export function registerKnowledge(id, { title = id, text = '', tags = [] } = {}) {
  if (!id || !text) throw new Error('documento de conhecimento inválido');
  docs.set(String(id), { id: String(id), title, text: String(text), tags: [...tags], updatedAt: Date.now() });
  return docs.get(String(id));
}

export function removeKnowledge(id) { return docs.delete(String(id)); }
export function listKnowledge() { return [...docs.values()].map(({ id,title,tags,updatedAt }) => ({ id,title,tags,updatedAt })); }

export function searchKnowledge(query = '', { limit = 5 } = {}) {
  const terms = String(query).toLowerCase().split(/\s+/).filter(Boolean);
  if (!terms.length) return [];
  return [...docs.values()].map(d => {
    const hay = `${d.title} ${d.text} ${d.tags.join(' ')}`.toLowerCase();
    const score = terms.reduce((n,t) => n + (hay.includes(t) ? 1 : 0), 0);
    return { ...d, score };
  }).filter(x => x.score > 0).sort((a,b)=>b.score-a.score).slice(0,limit);
}

registerKnowledge('fantasminha-core', { title: 'Fantasminha', tags:['bot','comandos','suporte'], text: 'O Fantasminha usa Registry central, permissões, auditoria, analytics, triagem, snapshots, economia, RPG, IA e plugins.' });
registerKnowledge('triagem', { title: 'Triagem', tags:['suporte','ticket'], text: 'A triagem pode coletar dados configurados, registrar respostas, controlar status, expiração e lembretes.' });

export default { registerKnowledge, removeKnowledge, listKnowledge, searchKnowledge };
