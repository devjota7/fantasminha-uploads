const base = String(process.env.SPIDER_API_BASE_URL || 'https://api.spiderx.com.br/api').replace(/\/$/, '');
function token() { return String(process.env.SPIDER_API_TOKEN || process.env.SPIDERX_API_TOKEN || '').trim(); }
function requireToken() { const t = token(); if (!t) throw new Error('Token da Spider X API não configurado. Defina SPIDER_API_TOKEN no .env.'); return t; }
async function get(path, params = {}) {
  const apiKey = requireToken();
  const qs = new URLSearchParams({ ...Object.fromEntries(Object.entries(params).map(([k,v])=>[k,String(v)])), api_key:apiKey });
  const res = await fetch(`${base}${path}?${qs}`, { signal: AbortSignal.timeout(20000) });
  const data = await res.json().catch(()=>({message:`HTTP ${res.status}`}));
  if (!res.ok) throw new Error(data?.message || `Spider X API HTTP ${res.status}`);
  return data;
}
export async function download(type, url) { if (!url) throw new Error('URL obrigatória.'); return get(`/downloads/${type}`, { url }); }
export async function ttp(text) { if (!text) throw new Error('Texto obrigatório.'); return `${base}/stickers/ttp?text=${encodeURIComponent(text)}&api_key=${encodeURIComponent(requireToken())}`; }
export async function tts(text, voice='joao') { return get('/ai/tts', { text, voice }); }
export default { download, ttp, tts };
