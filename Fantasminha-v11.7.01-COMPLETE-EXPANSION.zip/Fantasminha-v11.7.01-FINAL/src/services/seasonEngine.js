import { readCollection, updateCollection } from '../database/store.js';
const C='season_engine';
export async function current(groupId){const db=readCollection(C,{groups:{}});let s=db.groups?.[groupId];if(s&&s.endsAt>Date.now()&&!s.archived)return s;const now=Date.now();const number=(s?.number||0)+1;const next={id:`S${number}`,number,name:`Temporada ${number}`,startedAt:now,endsAt:now+30*86400000,archived:false};await updateCollection(C,d=>{d.groups ||= {};if(s)d.groups[groupId]={...s,archived:true};d.groups[groupId]=next;d.archive ||= [];if(s)d.archive.push(s);return d;},{groups:{},archive:[]});return next;}
export function history(groupId){return readCollection(C,{archive:[]}).archive.filter(s=>s.groupId===groupId||!s.groupId);}
export default {current,history};
