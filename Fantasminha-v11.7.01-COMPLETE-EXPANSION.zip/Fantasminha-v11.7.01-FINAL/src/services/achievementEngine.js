import { updateCollection, readCollection } from '../database/store.js';
const C='achievement_engine';
const defs=[
 ['first-play','Primeiro Passo','Jogue sua primeira partida.','comum'],['first-win','Primeira Vitória','Vença sua primeira partida.','comum'],['ten-games','Veterano','Complete 10 partidas.','raro'],['streak-5','Imparável','Alcance uma sequência de 5 vitórias/acertos.','épico'],['score-1000','Pontuação 1000','Acumule 1000 pontos.','épico'],['pet-master','Mestre dos Pets','Evolua um pet até o nível 10.','lendário']
];
export function definitions(){return defs.map(([id,title,description,rarity])=>({id,title,description,rarity}));}
export async function unlock(groupId,userId,id,meta={}){const def=defs.find(x=>x[0]===id);if(!def)return null;return updateCollection(C,db=>{db.items ||= {};const k=`${groupId||'global'}::${userId}`;const a=db.items[k] ||= {}; if(a[id])return db; a[id]={id,title:def[1],description:def[2],rarity:def[3],at:Date.now(),meta};return db;},{items:{}}).then(db=>db.items[`${groupId||'global'}::${userId}`][id]);}
export function list(groupId,userId){return Object.values(readCollection(C,{items:{}}).items?.[`${groupId||'global'}::${userId}`]||{});}
export default {definitions,unlock,list};
