import crypto from 'crypto';
import { readCollection, updateCollection } from '../database/store.js';

const COLLECTION = 'game_engine';
const STATUSES = new Set(['WAITING','ACTIVE','FINISHED','DRAW','ABANDONED','EXPIRED','CANCELLED']);
const id = (prefix='G') => `${prefix}-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
const clone = v => structuredClone(v);
const scopeKey = (groupId, gameType) => `${groupId || 'private'}::${gameType}`;

export const GameStatus = Object.freeze({ WAITING:'WAITING', ACTIVE:'ACTIVE', FINISHED:'FINISHED', DRAW:'DRAW', ABANDONED:'ABANDONED', EXPIRED:'EXPIRED', CANCELLED:'CANCELLED' });

function load(){ return readCollection(COLLECTION,{games:{}, history:[]}); }
function assertStatus(status){ if(!STATUSES.has(status)) throw new Error(`Status de partida inválido: ${status}`); }

export async function createGame({ groupId, gameType, creatorId, maxPlayers=2, state={}, timeoutMs=0, metadata={} }) {
  if(!gameType || !creatorId) throw new Error('gameType e creatorId são obrigatórios');
  const game = { gameId:id(gameType.slice(0,5).toUpperCase()), groupId:groupId || 'private', gameType, creatorId, participants:[creatorId], maxPlayers:Math.max(1,Number(maxPlayers)||2), status:'WAITING', turn:null, state:clone(state), timeoutMs:Math.max(0,Number(timeoutMs)||0), metadata:clone(metadata), createdAt:Date.now(), updatedAt:Date.now(), endedAt:null, history:[] };
  return updateCollection(COLLECTION, db=>{
    db.games ||= {}; db.history ||= [];
    const active = Object.values(db.games).find(g=>g.groupId===game.groupId && g.gameType===game.gameType && ['WAITING','ACTIVE'].includes(g.status) && g.participants.includes(creatorId));
    if(active) throw new Error(`Você já possui uma partida ativa de ${gameType}: ${active.gameId}`);
    db.games[game.gameId]=game; return db;
  },{games:{},history:[]}).then(db=>db.games[game.gameId]);
}

export function getGame(gameId){ return load().games?.[String(gameId||'').toUpperCase()] || load().games?.[String(gameId||'')] || null; }
export function listActiveGames(groupId){ return Object.values(load().games||{}).filter(g=>g.groupId===groupId && ['WAITING','ACTIVE'].includes(g.status)); }
export function listHistory(groupId, gameType){ return (load().history||[]).filter(g=>(!groupId||g.groupId===groupId)&&(!gameType||g.gameType===gameType)); }

export async function joinGame(gameId, playerId, groupId){
  if(!playerId) throw new Error('playerId obrigatório');
  return updateCollection(COLLECTION, db=>{
    const g=db.games?.[gameId]; if(!g) throw new Error('Partida não encontrada.');
    if(groupId && g.groupId!==groupId) throw new Error('Partida pertence a outro grupo.');
    if(g.status!=='WAITING') throw new Error('A partida não está aceitando jogadores.');
    if(g.participants.includes(playerId)) return db;
    if(g.participants.length>=g.maxPlayers) throw new Error('A partida está cheia.');
    g.participants.push(playerId); g.updatedAt=Date.now(); g.history.push({at:Date.now(),type:'PLAYER_JOINED',playerId});
    return db;
  },{games:{},history:{}}).then(db=>db.games[gameId]);
}

export async function startGame(gameId, groupId, turn){
  return updateCollection(COLLECTION, db=>{
    const g=db.games?.[gameId]; if(!g) throw new Error('Partida não encontrada.');
    if(groupId && g.groupId!==groupId) throw new Error('Partida pertence a outro grupo.');
    if(g.status!=='WAITING') throw new Error('Partida já iniciada.');
    if(g.participants.length<2 && g.maxPlayers>1) throw new Error('Ainda faltam jogadores.');
    g.status='ACTIVE'; g.turn=turn ?? g.participants[0] ?? null; g.updatedAt=Date.now(); g.history.push({at:Date.now(),type:'STARTED',turn:g.turn}); return db;
  },{games:{},history:[]}).then(db=>db.games[gameId]);
}

export async function updateGame(gameId, groupId, updater){
  return updateCollection(COLLECTION, db=>{
    const g=db.games?.[gameId]; if(!g) throw new Error('Partida não encontrada.');
    if(groupId && g.groupId!==groupId) throw new Error('Partida pertence a outro grupo.');
    if(!['WAITING','ACTIVE'].includes(g.status)) throw new Error('Partida não está ativa.');
    const next=updater(clone(g)); if(!next) throw new Error('Atualização inválida.');
    assertStatus(next.status); next.updatedAt=Date.now(); db.games[gameId]=next; return db;
  },{games:{},history:[]}).then(db=>db.games[gameId]);
}

export async function finishGame(gameId, groupId, { status='FINISHED', winnerId=null, reason=null, result=null }={}){
  assertStatus(status); if(!['FINISHED','DRAW','ABANDONED','EXPIRED','CANCELLED'].includes(status)) throw new Error('Status final inválido.');
  return updateCollection(COLLECTION, db=>{
    const g=db.games?.[gameId]; if(!g) throw new Error('Partida não encontrada.');
    if(groupId && g.groupId!==groupId) throw new Error('Partida pertence a outro grupo.');
    if(!['WAITING','ACTIVE'].includes(g.status)) return db;
    g.status=status; g.winnerId=winnerId; g.reason=reason; g.result=clone(result); g.endedAt=Date.now(); g.updatedAt=Date.now();
    g.history.push({at:Date.now(),type:'FINISHED',status,winnerId,reason,result:clone(result)});
    db.history ||= []; db.history.push(clone(g)); delete db.games[gameId]; return db;
  },{games:{},history:[]}).then(db=>db.history.at(-1));
}

export async function abandonGame(gameId, playerId, groupId){
  const g=getGame(gameId); if(!g) throw new Error('Partida não encontrada.');
  if(!g.participants.includes(playerId)) throw new Error('Você não participa desta partida.');
  return finishGame(gameId,groupId,{status:'ABANDONED',reason:`${playerId} desistiu`});
}

export async function expireGames(now=Date.now()){
  const active=Object.values(load().games||{}).filter(g=>g.timeoutMs>0&&['WAITING','ACTIVE'].includes(g.status)&&now-g.updatedAt>=g.timeoutMs);
  for(const g of active){ try{ await finishGame(g.gameId,g.groupId,{status:'EXPIRED',reason:'timeout'}); }catch{} }
  return active.length;
}

export function validateGame(game){
  const errors=[]; if(!game?.gameId) errors.push('gameId'); if(!game?.groupId) errors.push('groupId'); if(!game?.gameType) errors.push('gameType'); if(!STATUSES.has(game?.status)) errors.push('status'); if(!Array.isArray(game?.participants)||!game.participants.length) errors.push('participants'); if(game?.participants?.length>game?.maxPlayers) errors.push('participants>maxPlayers'); return {ok:!errors.length,errors};
}

export default { createGame,getGame,listActiveGames,listHistory,joinGame,startGame,updateGame,finishGame,abandonGame,expireGames,validateGame,GameStatus,scopeKey };
