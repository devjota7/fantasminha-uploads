/**
 * Ghostcoins — economia transacional e resistente a race conditions.
 * Todas as mutações críticas passam pela camada de transações.
 */
import { getUser, upsertUser, readCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import { transact } from '../platform/transactions/index.js';

const DAILY = 1000;
const WEEKLY = 5000;
const WORK_MIN = 200;
const WORK_MAX = 800;
const WORK_CD = 60 * 60 * 1000;
const DAILY_CD = 20 * 60 * 60 * 1000;
const WEEKLY_CD = 6 * 24 * 60 * 60 * 1000;
const MAX_WALLET = 50_000_000;

function ensureEco(u) {
  u.economy ??= { wallet: 0, bank: 0, lastDaily: 0, lastWeekly: 0, lastWork: 0, inventory: {} };
  u.economy.inventory ??= {};
  return u.economy;
}

async function atomicUserAndLedger(userId, mutate, ledgerEntry = null) {
  const steps = [{
    collection: 'users',
    update: (users) => {
      users.byId ??= {};
      const u = users.byId[userId] || { id: userId, name: '', economy: {} };
      ensureEco(u);
      users.byId[userId] = mutate(u) || u;
      users.byId[userId].updatedAt = Date.now();
      return users;
    }
  }];
  if (ledgerEntry) steps.push({
    collection: 'economy_ledger',
    update: (L) => {
      L.entries ??= [];
      L.entries.push({ ...ledgerEntry, at: Date.now() });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000);
      return L;
    }
  });
  return transact(steps, { actor: userId, type: 'economy.atomic' });
}

export async function getBalance(userId) {
  const u = getUser(userId) || (await upsertUser(userId), getUser(userId));
  const e = ensureEco(u || { economy: {} });
  return { wallet: Number(e.wallet || 0), bank: Number(e.bank || 0), total: Number(e.wallet || 0) + Number(e.bank || 0) };
}

export async function addWallet(userId, amount, reason = 'adjust', name = '') {
  if (!Number.isFinite(Number(amount)) || Number(amount) === 0) throw new ValidationError('Valor inválido.');
  const delta = Number(amount);
  let finalWallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name;
    const e = ensureEco(u);
    const next = (e.wallet || 0) + delta;
    if (next < 0) throw new ValidationError('Saldo insuficiente.');
    finalWallet = Math.min(MAX_WALLET, next);
    e.wallet = finalWallet;
    return u;
  }, { userId, amount: delta, reason, wallet: finalWallet });
  return ensureEco(getUser(userId));
}

export async function transfer(fromId, toId, amount, fromName = '', toName = '') {
  const value = Math.floor(Number(amount));
  if (!Number.isInteger(value) || value <= 0 || fromId === toId) throw new ValidationError('Transferência inválida.');
  await transact([
    { collection: 'users', update: (users) => {
      users.byId ??= {};
      const from = users.byId[fromId] || { id: fromId, economy: {} };
      const to = users.byId[toId] || { id: toId, economy: {} };
      const ef = ensureEco(from), et = ensureEco(to);
      if ((ef.wallet || 0) < value) throw new ValidationError('Saldo insuficiente no bolso.');
      if ((et.wallet || 0) + value > MAX_WALLET) throw new ValidationError('Carteira do destinatário atingiu o limite.');
      ef.wallet -= value; et.wallet += value;
      if (fromName) from.name = fromName; if (toName) to.name = toName;
      from.updatedAt = to.updatedAt = Date.now(); users.byId[fromId] = from; users.byId[toId] = to; return users;
    }},
    { collection: 'economy_ledger', update: (L) => {
      L.entries ??= [];
      L.entries.push({ userId: fromId, amount: -value, reason: 'transfer_out', to: toId, at: Date.now() });
      L.entries.push({ userId: toId, amount: value, reason: 'transfer_in', from: fromId, at: Date.now() });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000); return L;
    }}
  ], { actor: fromId, type: 'economy.transfer', from: fromId, to: toId, amount: value });
  return { amount: value };
}

export async function deposit(userId, amount) {
  const value = amount === 'all' ? Number(getUser(userId)?.economy?.wallet || 0) : Math.floor(Number(amount));
  if (!Number.isInteger(value) || value <= 0) throw new ValidationError('Valor inválido.');
  await atomicUserAndLedger(userId, (u) => { const e = ensureEco(u); if ((e.wallet || 0) < value) throw new ValidationError('Saldo insuficiente.'); e.wallet -= value; e.bank = (e.bank || 0) + value; return u; }, { userId, amount: value, reason: 'deposit' });
  return ensureEco(getUser(userId));
}

export async function withdraw(userId, amount) {
  const value = amount === 'all' ? Number(getUser(userId)?.economy?.bank || 0) : Math.floor(Number(amount));
  if (!Number.isInteger(value) || value <= 0) throw new ValidationError('Valor inválido.');
  await atomicUserAndLedger(userId, (u) => { const e = ensureEco(u); if ((e.bank || 0) < value) throw new ValidationError('Banco insuficiente.'); e.bank -= value; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + value); return u; }, { userId, amount: value, reason: 'withdraw' });
  return ensureEco(getUser(userId));
}

export async function daily(userId, name = '') {
  let gained = DAILY;
  try { const { dailyBonus } = await import('./vipBenefits.js'); gained += dailyBonus(userId) || 0; } catch {}
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastDaily && now - e.lastDaily < DAILY_CD) throw new ValidationError(`Daily já coletado. Volte em ~${Math.ceil((DAILY_CD - (now - e.lastDaily)) / 3600000)}h.`);
    e.lastDaily = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + gained); wallet = e.wallet; return u;
  }, { userId, amount: gained, reason: 'daily' });
  try { const { addWeeklyScore } = await import('./rankings.js'); await addWeeklyScore(userId, name, 'economy', gained); } catch {}
  return { gained, wallet };
}

export async function weekly(userId, name = '') {
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastWeekly && now - e.lastWeekly < WEEKLY_CD) throw new ValidationError('Weekly ainda em cooldown.');
    e.lastWeekly = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + WEEKLY); wallet = e.wallet; return u;
  }, { userId, amount: WEEKLY, reason: 'weekly' });
  return { gained: WEEKLY, wallet };
}

export async function work(userId, name = '') {
  const gained = WORK_MIN + Math.floor(Math.random() * (WORK_MAX - WORK_MIN + 1));
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastWork && now - e.lastWork < WORK_CD) throw new ValidationError(`Descansando. Trabalho em ${Math.ceil((WORK_CD - (now - e.lastWork)) / 60000)} min.`);
    e.lastWork = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + gained); wallet = e.wallet; return u;
  }, { userId, amount: gained, reason: 'work' });
  return { gained, wallet };
}

export function richRanking(limit = 10) {
  const users = readCollection('users', { byId: {} });
  return Object.values(users.byId || {}).map(u => ({ id: u.id, name: u.name || u.id?.split?.('@')[0], total: (u.economy?.wallet || 0) + (u.economy?.bank || 0) })).sort((a,b) => b.total-a.total).slice(0, limit);
}

export default { getBalance, addWallet, transfer, deposit, withdraw, daily, weekly, work, richRanking };
