import { updateCollection, readCollection } from '../database/store.js';
import achievements from './achievementEngine.js';
const C='stats_engine';
const key=(group,user)=>`${group||'global'}::${user}`;
export async function recordResult({groupId,userId,gameType,result='play',score=0,xp=0,win=false,loss=false,draw=false}){
  return updateCollection(C,db=>{db.players ||= {}; const k=key(groupId,userId); const p=db.players[k] ||= {groupId,userId,plays:0,wins:0,losses:0,draws:0,xp:0,score:0,streak:0,bestStreak:0,games:{},updatedAt:0}; p.plays++; p.wins+=win?1:0; p.losses+=loss?1:0; p.draws+=draw?1:0; p.xp+=Math.max(0,Number(xp)||0); p.score+=Number(score)||0; p.streak=win||result==='correct'?p.streak+1:0; p.bestStreak=Math.max(p.bestStreak,p.streak); p.games[gameType] ||= {plays:0,wins:0,score:0,xp:0}; p.games[gameType].plays++; p.games[gameType].wins+=win?1:0; p.games[gameType].score+=Number(score)||0; p.games[gameType].xp+=Math.max(0,Number(xp)||0); p.updatedAt=Date.now(); return db;},{players:{}}).then(async db=>{ const out=db.players[key(groupId,userId)]; try { if(out.plays>=1) await achievements.unlock(groupId,userId,'first-play'); if(out.wins>=1) await achievements.unlock(groupId,userId,'first-win'); if(out.plays>=10) await achievements.unlock(groupId,userId,'ten-games'); if(out.bestStreak>=5) await achievements.unlock(groupId,userId,'streak-5'); if(out.score>=1000) await achievements.unlock(groupId,userId,'score-1000'); } catch {} return out; });
}
export function getStats(groupId,userId){return readCollection(C,{players:{}}).players?.[key(groupId,userId)]||null;}
export function listStats(groupId){return Object.values(readCollection(C,{players:{}}).players||{}).filter(x=>x.groupId===groupId).sort((a,b)=>b.score-a.score||b.xp-a.xp);}
export default {recordResult,getStats,listStats};
