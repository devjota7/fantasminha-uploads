import { readCollection, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';

const DEFAULTS = { items: {} };

export function normalizeCustomName(name) {
  const n = String(name || '').trim().toLowerCase().replace(/[^a-z0-9_.-]/g, '');
  return n.slice(0, 40);
}
export function getCustomCommand(name) {
  const key = normalizeCustomName(name);
  const items = readCollection('custom_commands', DEFAULTS).items || {};
  if (items[key]) return items[key];
  return Object.values(items).find(x => Array.isArray(x.aliases) && x.aliases.includes(key)) || null;
}
export function listCustomCommands() {
  return Object.values(readCollection('custom_commands', DEFAULTS).items || {}).sort((a,b)=>a.name.localeCompare(b.name));
}
export async function upsertCustomCommand({ name, text, actor, aliases = [] } = {}) {
  const key = normalizeCustomName(name);
  if (!key || !text?.trim()) throw new ValidationError('Informe nome e resposta do comando.');
  await updateCollection('custom_commands', d => {
    d.items ??= {};
    d.items[key] = { name:key, text:String(text).trim().slice(0, 4000), aliases:[...new Set(aliases.map(normalizeCustomName).filter(Boolean))], actor, updatedAt:Date.now() };
    return d;
  }, DEFAULTS);
  return getCustomCommand(key);
}
export async function removeCustomCommand(name) {
  const key = normalizeCustomName(name);
  let removed = false;
  await updateCollection('custom_commands', d => { if (d.items?.[key]) { delete d.items[key]; removed=true; } return d; }, DEFAULTS);
  return removed;
}
export default { normalizeCustomName, getCustomCommand, listCustomCommands, upsertCustomCommand, removeCustomCommand };
