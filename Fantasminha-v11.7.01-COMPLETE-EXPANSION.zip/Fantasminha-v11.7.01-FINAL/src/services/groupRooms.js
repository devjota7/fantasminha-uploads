import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../../dados/database');
const FILE = path.join(DATA_DIR, 'groupRooms.json');

function ensureStore() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify({}, null, 2));
}
function readStore() {
  ensureStore();
  try {
    const data = JSON.parse(fs.readFileSync(FILE, 'utf8'));
    return data && typeof data === 'object' ? data : {};
  } catch (e) {
    console.error('[GROUP_ROOMS] banco inválido, recuperando:', e.message);
    return {};
  }
}
function writeStore(data) {
  ensureStore();
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, FILE);
}
function cleanCode(code) {
  return String(code ?? '').trim().replace(/\s+/g, ' ').slice(0, 100);
}

export function getRoom(groupId) {
  if (!groupId) return null;
  return readStore()[groupId] || null;
}

export function setRoom(groupId, code, userId) {
  if (!groupId) throw new Error('Grupo inválido.');
  const clean = cleanCode(code);
  if (!clean) throw new Error('Informe o código da sala.');
  const store = readStore();
  const now = new Date().toISOString();
  const previous = store[groupId];
  store[groupId] = {
    code: clean,
    createdAt: now,
    createdBy: userId || null,
    updatedAt: now,
    updatedBy: userId || null
  };
  writeStore(store);
  return store[groupId];
}

export function removeRoom(groupId) {
  if (!groupId) return false;
  const store = readStore();
  if (!store[groupId]) return false;
  delete store[groupId];
  writeStore(store);
  return true;
}

export function roomStatus(groupId) {
  return getRoom(groupId);
}

export default { getRoom, setRoom, removeRoom, roomStatus };
