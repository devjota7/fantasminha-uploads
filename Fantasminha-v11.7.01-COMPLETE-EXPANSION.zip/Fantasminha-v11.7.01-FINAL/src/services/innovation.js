import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../database/store.js';

const now=()=>Date.now(); const clean=v=>String(v??'').trim();
const save=(c,fn,f={})=>updateCollection(c,fn,f);
const pct=n=>Math.max(0,Math.min(100,Math.round(Number(n)||0)));

export async function world(groupId){const d=readCollection('living_world',{byGroup:{}});let w=d.byGroup?.[groupId];if(!w){w={groupId,season:1,phase:'Lua Nova',weather:'Estável',danger:10,activity:0,updatedAt:now()};await save('living_world',x=>{x.byGroup??={};x.byGroup[groupId]=w;return x;},{byGroup:{}});}return w;}
export async function updateWorld(groupId,patch){return save('living_world',d=>{d.byGroup??={};const w={...(d.byGroup[groupId]||awaitableWorld(groupId)),...patch,updatedAt:now()};d.byGroup[groupId]=w;return d;},{byGroup:{}});}
function awaitableWorld(groupId){return{groupId,season:1,phase:'Lua Nova',weather:'Estável',danger:10,activity:0,updatedAt:now()};}
export async function season(groupId){const d=readCollection('innovation_seasons',{byGroup:{}});return d.byGroup?.[groupId]||{number:1,name:'Primeiro Véu',startedAt:now(),endsAt:now()+30*86400000};}
export async function setSeason(groupId,patch){let out;await save('innovation_seasons',d=>{d.byGroup??={};out={...(d.byGroup[groupId]||{}),...patch};d.byGroup[groupId]=out;return d;},{byGroup:{}});return out;}
export async function boss(groupId){const d=readCollection('world_boss',{byGroup:{}});return d.byGroup?.[groupId]||null;}
export async function spawnBoss(groupId,name='O Devorador',hp=100000){let out;await save('world_boss',d=>{d.byGroup??={};out={id:`BOSS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,groupId,name,hp,maxHp:hp,damageByUser:{},active:true,createdAt:now()};d.byGroup[groupId]=out;return d;},{byGroup:{}});return out;}
export async function hitBoss(groupId,userId,damage){let out;await save('world_boss',d=>{const b=d.byGroup?.[groupId];if(!b||!b.active)throw new Error('Nenhum boss ativo.');const n=Math.max(1,Math.min(5000,Number(damage)||1));b.hp=Math.max(0,b.hp-n);b.damageByUser??={};b.damageByUser[userId]=(b.damageByUser[userId]||0)+n;if(b.hp<=0){b.hp=0;b.active=false;b.defeatedAt=now();}out=structuredClone(b);return d;},{byGroup:{}});return out;}
export async function addAchievement(userId,key,title){let out;await save('innovation_achievements',d=>{d.byUser??={};d.byUser[userId]??=[];if(!d.byUser[userId].some(x=>x.key===key)){out={key,title,at:now()};d.byUser[userId].push(out);}return d;},{byUser:{}});return out;}
export function achievements(userId){return readCollection('innovation_achievements',{byUser:{}}).byUser?.[userId]||[];}
export async function investigation(groupId,title='Caso do Véu'){let out;await save('investigations',d=>{d.byGroup??={};out={id:`CASO-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,groupId,title,clues:[],participants:[],status:'aberto',createdAt:now()};d.byGroup[groupId]=out;return d;},{byGroup:{}});return out;}
export async function addClue(groupId,text){let out;await save('investigations',d=>{const x=d.byGroup?.[groupId];if(!x)throw new Error('Nenhum caso ativo.');x.clues??=[];x.clues.push({id:crypto.randomUUID(),text,at:now()});out=structuredClone(x);return d;},{byGroup:{}});return out;}
export async function expedition(groupId,userId,place){const rewards=['Fragmento Lunar','Mapa Antigo','Essência do Limbo','Relíquia Perdida'];const reward=rewards[Math.floor(Math.random()*rewards.length)];return save('expeditions',d=>{d.items??=[];d.items.push({id:crypto.randomUUID(),groupId,userId,place,reward,at:now()});if(d.items.length>10000)d.items=d.items.slice(-10000);return d;},{items:[]}).then(()=>({place,reward}));}
export async function event(groupId,type='aleatorio'){const names=['Eclipse do Limbo','Chuva de Fragmentos','Portal Instável','Noite dos Fantasmas','Festival do Véu'];let out;await save('world_events',d=>{d.byGroup??={};out={id:`EVT-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,groupId,type,name:names[Math.floor(Math.random()*names.length)],endsAt:now()+30*60000,createdAt:now()};d.byGroup[groupId]=out;return d;},{byGroup:{}});return out;}
export function records(groupId){return readCollection('world_events',{byGroup:{}}).byGroup?.[groupId]||null;}
export async function title(userId,value){return save('titles',d=>{d.byUser??={};d.byUser[userId]??=[];if(!d.byUser[userId].includes(value))d.byUser[userId].push(value);return d;},{byUser:{}}).then(()=>value);}
export function titles(userId){return readCollection('titles',{byUser:{}}).byUser?.[userId]||[];}
export function museum(groupId){const seasons=readCollection('innovation_seasons',{byGroup:{}}).byGroup?.[groupId]||{};const bossData=readCollection('world_boss',{byGroup:{}}).byGroup?.[groupId]||null;const ev=records(groupId);return{season:seasons.number||1,bosses:bossData&&!bossData.active?1:0,lastEvent:ev?.name||null};}
export function newspaper(groupId){const w=readCollection('living_world',{byGroup:{}}).byGroup?.[groupId];const e=records(groupId);const b=readCollection('world_boss',{byGroup:{}}).byGroup?.[groupId];return`📰 *JORNAL DO LIMBO*\n\n🌎 Mundo: ${w?.phase||'Lua Nova'} • ${w?.weather||'Estável'}\n⚠️ Perigo: ${w?.danger??10}%\n🌌 Evento: ${e?.name||'Nenhum'}\n👹 Boss: ${b?.active?`${b.name} — ${b.hp}/${b.maxHp}`:'Nenhum ativo'}`;}

export async function findErrorGame({sendMessage,jid,level=1,answer=null}){const size=Math.min(10,3+Math.floor((Number(level)-1)/3));const base='🔵',wrong='🔷';const total=size*size;const pos=Math.floor(Math.random()*total);const grid=Array.from({length:total},(_,i)=>i===pos?wrong:base);const correct=pos+1;const msg=await sendMessage(jid,{text:`🔎 *ACHEI UM ERRO*\n\nNível ${level} • ${size}×${size}\n\n${grid.map((x,i)=>`${x}${(i+1)%size===0?'\n':' '}`).join('')}\nResponda com a posição (1-${total}).`});return{key:msg?.key,correct,size,level};}
export async function memoryGame({sendMessage,jid,level=1}){
  const cups=Math.min(9,3+Math.floor((Number(level)-1)/4));
  const hidden=Math.floor(Math.random()*cups)+1;
  let order=Array.from({length:cups},(_,i)=>i+1);
  const render=(values,showGhost=false)=>values.map((x)=>showGhost&&x===hidden?'👻':'🥤').join('   ');
  const msg=await sendMessage(jid,{text:`🥤 *MEMÓRIA DOS COPOS*\n\nNível ${level}\n\n${render(order,true)}\n\n👻 Memorize onde está o fantasma...`});
  const key=msg?.key;
  const steps=Math.min(7,1+Math.floor(Number(level)/4));
  for(let i=0;i<steps;i++){
    for(let j=order.length-1;j>0;j--){const k=Math.floor(Math.random()*(j+1));[order[j],order[k]]=[order[k],order[j]];}
    await new Promise(r=>setTimeout(r,550));
    await sendMessage(jid,{text:`🥤 *MEMÓRIA DOS COPOS*\n\nNível ${level}\n\n${render(order)}\n\n🔄 Movimento ${i+1}/${steps}...`,...(key?{edit:key}:{})});
  }
  const correct=order.indexOf(hidden)+1;
  await new Promise(r=>setTimeout(r,500));
  await sendMessage(jid,{text:`🥤 *MEMÓRIA DOS COPOS*\n\nNível ${level}\n\n${order.map((_,i)=>`${i+1}️⃣`).join('   ')}\n\n👻 Onde está o fantasma? Responda com o número.`,...(key?{edit:key}:{})});
  return{key,correct,hidden,level,cups};
}

export async function saveGameState(groupId,userId,state){return save('innovation_games',d=>{d.byKey??={};d.byKey[`${groupId}:${userId}`]={...state,groupId,userId,updatedAt:now()};return d;},{byKey:{}});}
export function getGameState(groupId,userId){return readCollection('innovation_games',{byKey:{}}).byKey?.[`${groupId}:${userId}`]||null;}
export async function clearGameState(groupId,userId){return save('innovation_games',d=>{delete d.byKey?.[`${groupId}:${userId}`];return d;},{byKey:{}});}
export async function handleInnovationMessage(ctx){
  if(!ctx.sender)return{handled:false};
  const st=getGameState(ctx.from||'private',ctx.sender); if(!st)return{handled:false};
  const raw=clean(ctx.body||ctx.text||'');
  if(st.game==='find-error'){
    const n=Number(raw); if(!Number.isInteger(n)){await ctx.reply('🔎 Responda somente com a posição.');return{handled:true};}
    await clearGameState(ctx.from,ctx.sender);
    const ok=n===st.correct; await ctx.reply(ok?`🎉 *ACERTOU!*\n\nNível ${st.level}\n+XP • +💰\n\nTente ${ctx.prefix}acheiumerro ${st.level+1} para subir de nível.`:`❌ *ERROU!*\n\nA posição correta era *${st.correct}*.\nNível alcançado: ${st.level}`); return{handled:true};
  }
  if(st.game==='memory'){
    const n=Number(raw); if(!Number.isInteger(n)){await ctx.reply('🥤 Responda somente com o número do copo.');return{handled:true};}
    await clearGameState(ctx.from,ctx.sender); const ok=n===st.correct;
    await ctx.reply(ok?`🎉 *MEMÓRIA PERFEITA!*\n\nNível ${st.level} concluído.\n+XP • +💰`:`💥 *A memória falhou.*\n\nO fantasma estava no copo *${st.correct}*.\nNível alcançado: ${st.level}`);return{handled:true};
  }
  return{handled:false};
}


export async function recordHistory(groupId, type, title, summary, meta={}){
  let out; await save('world_history',d=>{d.byGroup??={};d.byGroup[groupId]??=[];out={id:`HIS-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,groupId,type,title,summary,meta,at:now()};d.byGroup[groupId].push(out);if(d.byGroup[groupId].length>500)d.byGroup[groupId]=d.byGroup[groupId].slice(-500);return d;},{byGroup:{}});return out;
}
export function history(groupId){return readCollection('world_history',{byGroup:{}}).byGroup?.[groupId]||[];}
export async function createMystery(groupId,title='O Mistério do Véu',durationDays=7){let out;await save('weekly_mysteries',d=>{d.byGroup??={};out={id:`CASO-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,groupId,title,status:'aberto',clues:[],suspects:[],participants:[],createdAt:now(),endsAt:now()+durationDays*86400000};d.byGroup[groupId]=out;return d;},{byGroup:{}});return out;}
export function mystery(groupId){return readCollection('weekly_mysteries',{byGroup:{}}).byGroup?.[groupId]||null;}
export async function mysteryClue(groupId,text){let out;await save('weekly_mysteries',d=>{const m=d.byGroup?.[groupId];if(!m)throw new Error('Nenhum mistério ativo.');m.clues??=[];out={id:crypto.randomUUID(),text,at:now()};m.clues.push(out);return d;},{byGroup:{}});return out;}
export async function joinMystery(groupId,userId){let out;await save('weekly_mysteries',d=>{const m=d.byGroup?.[groupId];if(!m)throw new Error('Nenhum mistério ativo.');m.participants??=[];if(!m.participants.includes(userId))m.participants.push(userId);out=structuredClone(m);return d;},{byGroup:{}});return out;}
