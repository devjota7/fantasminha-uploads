import crypto from 'crypto';
import { getSettings, saveSettings, MAX_QUESTIONS } from './triage.js';

export const QUESTION_TYPES = Object.freeze({
  text:'text', number:'number', yesno:'yesno', choice:'choice', image:'image'
});
const aliases = { texto:'text', text:'text', resposta:'text', numero:'number', number:'number', simnao:'yesno', yesno:'yesno', escolha:'choice', choice:'choice', foto:'image', imagem:'image', image:'image' };
const clean = v => String(v ?? '').trim();
const id = () => `q_${Date.now().toString(36)}_${crypto.randomBytes(2).toString('hex')}`;

export function normalizeType(v) { return aliases[clean(v).toLowerCase()] || null; }
export function normalizeQuestion(q, index=0) {
  const type = normalizeType(q?.type) || 'text';
  const out = {
    id: clean(q?.id) || id(), type, required: q?.required !== false,
    question: clean(q?.question), title: clean(q?.title), help: clean(q?.help),
    placeholder: clean(q?.placeholder), minLength: q?.minLength == null ? undefined : Number(q.minLength),
    maxLength: q?.maxLength == null ? undefined : Number(q.maxLength),
    min: q?.min == null ? undefined : Number(q.min), max: q?.max == null ? undefined : Number(q.max),
    choices: Array.isArray(q?.choices) ? q.choices.map(clean).filter(Boolean).slice(0,50) : [],
    analysis: q?.analysis && typeof q.analysis === 'object' ? {
      enabled: q.analysis.enabled !== false, instruction: clean(q.analysis.instruction),
      ocr: q.analysis.ocr !== false, compareQuestionIds: Array.isArray(q.analysis.compareQuestionIds) ? q.analysis.compareQuestionIds.map(clean).filter(Boolean) : [],
      requireReadable: !!q.analysis.requireReadable, confidenceFloor: ['low','medium','high'].includes(q.analysis.confidenceFloor) ? q.analysis.confidenceFloor : 'low'
    } : undefined,
    order: index + 1
  };
  if (!out.question) throw new Error('A pergunta não pode ficar vazia.');
  if (type === 'choice' && out.choices.length < 2) throw new Error('Pergunta de escolha precisa de pelo menos 2 opções.');
  if (type === 'number') { out.min ??= 0; out.max ??= 999999999; }
  if (type === 'image') out.analysis ??= { enabled:true, instruction:'Analise objetivamente apenas o que estiver visível na imagem.', ocr:true, compareQuestionIds:[], requireReadable:false, confidenceFloor:'low' };
  return out;
}

export async function addQuestion(groupId, spec) {
  const s = await getSettings(groupId);
  if (s.questions.length >= MAX_QUESTIONS) throw new Error(`Limite de ${MAX_QUESTIONS} perguntas atingido.`);
  const q = normalizeQuestion(spec, s.questions.length);
  const questions = [...s.questions, q];
  return saveSettings(groupId, { questions });
}
export async function editQuestion(groupId, index, patch) {
  const s = await getSettings(groupId); const i = Number(index)-1;
  if (!Number.isInteger(i) || !s.questions[i]) throw new Error('Índice de pergunta inválido.');
  const merged = normalizeQuestion({...s.questions[i], ...patch, id:s.questions[i].id}, i);
  const questions = s.questions.map((x,n)=>n===i?merged:x);
  return saveSettings(groupId, { questions });
}
export async function deleteQuestion(groupId, index) {
  const s = await getSettings(groupId); const i = Number(index)-1;
  if (!Number.isInteger(i) || !s.questions[i]) throw new Error('Índice de pergunta inválido.');
  return saveSettings(groupId, { questions:s.questions.filter((_,n)=>n!==i).map((x,n)=>({...x,order:n+1})) });
}
export async function moveQuestion(groupId, from, to) {
  const s = await getSettings(groupId); const a=Number(from)-1,b=Number(to)-1;
  if(!Number.isInteger(a)||!Number.isInteger(b)||!s.questions[a]||b<0||b>=s.questions.length) throw new Error('Posições inválidas.');
  const q=[...s.questions]; const [item]=q.splice(a,1); q.splice(b,0,item);
  return saveSettings(groupId,{questions:q.map((x,n)=>({...x,order:n+1}))});
}
export async function duplicateQuestion(groupId,index){
  const s=await getSettings(groupId); const i=Number(index)-1;
  if(!Number.isInteger(i)||!s.questions[i]) throw new Error('Índice de pergunta inválido.');
  if(s.questions.length>=MAX_QUESTIONS) throw new Error(`Limite de ${MAX_QUESTIONS} perguntas atingido.`);
  const copy=normalizeQuestion({...s.questions[i],id:id(),title:`${s.questions[i].title||''} (cópia)`},i+1);
  const q=[...s.questions];q.splice(i+1,0,copy);return saveSettings(groupId,{questions:q.map((x,n)=>({...x,order:n+1}))});
}
export async function setQuestionAnalysis(groupId,index,patch){
  const s=await getSettings(groupId); const i=Number(index)-1;
  if(!Number.isInteger(i)||!s.questions[i]) throw new Error('Índice de pergunta inválido.');
  if(s.questions[i].type!=='image') throw new Error('A análise IA só pode ser configurada em perguntas de imagem.');
  const current=s.questions[i].analysis||{};
  return editQuestion(groupId,index,{analysis:{...current,...patch,enabled:patch.enabled!==false}});
}
export async function exportFlow(groupId){
  const s=await getSettings(groupId);
  return {version:1,kind:'fantasminha-triage-flow',exportedAt:new Date().toISOString(),settings:{enabled:s.enabled,maxQuestions:s.maxQuestions,questions:s.questions,startTimeoutMs:s.startTimeoutMs,completionTimeoutMs:s.completionTimeoutMs,judgeTimeoutMs:s.judgeTimeoutMs,reminderAfterMs:s.reminderAfterMs,reminderEnabled:s.reminderEnabled,kickOnExpire:s.kickOnExpire,kickOnReject:s.kickOnReject,restrictPending:s.restrictPending,publicMode:s.publicMode,imageAnalysis:s.imageAnalysis}};
}
export async function importFlow(groupId,payload){
  if(!payload||payload.kind!=='fantasminha-triage-flow') throw new Error('Arquivo/JSON de fluxo inválido.');
  const qs=(payload.settings?.questions||[]).slice(0,MAX_QUESTIONS).map((q,i)=>normalizeQuestion({...q,id:id()},i));
  return saveSettings(groupId,{...payload.settings,questions:qs});
}
