import { resolveMentionTargets, resolveUserIdentity, buildIdentityIndex } from '../platform/identity/resolver.js';

export async function mentionTargets(ctx, targets = null) { return resolveMentionTargets(ctx, targets); }
export function mentionText(jids = []) { return jids.map(j => `@${String(j).split('@')[0]}`).join(' '); }
export function cleanMentionText(text) { return String(text || '').replace(/(^|\s)@[0-9A-Za-z._-]+(?=\s|$)/g, '$1').replace(/\s{2,}/g, ' ').trim(); }
export async function mentionAll(ctx, text, { excludeBot = true } = {}) {
  if (!ctx.isGroup) throw new Error('Este comando só funciona em grupos.');
  let participants = Array.isArray(ctx.groupParticipantObjects) ? ctx.groupParticipantObjects : [];
  if (!participants.length && ctx.getGroupMetadata) {
    const meta = await ctx.getGroupMetadata(ctx.from);
    participants = meta?.participants || [];
  }
  const targets = [];
  const index=buildIdentityIndex(participants);
  const botIdentity=excludeBot?await resolveUserIdentity({...ctx, groupParticipantObjects: participants},ctx.botJid||''):null;
  for (const p of participants) {
    const id = p?.id || p?.jid || p?.participant;
    if (!id) continue;
    const normalizedId = String(id).trim().toLowerCase();
    if (!normalizedId) continue;
    const r = index.byAny.get(normalizedId) || await resolveUserIdentity({...ctx, groupParticipantObjects: participants}, id);
    if (!r?.realJid) continue;
    if (excludeBot && botIdentity?.realJid && r.realJid===botIdentity.realJid) continue;
    if (!targets.some(x => x.realJid === r.realJid)) targets.push(r);
  }
  if (!targets.length) throw new Error('Não encontrei números reais dos participantes para mencionar com segurança.');
  return { text: String(text || '').trim(), mentions: targets.map(x => x.realJid), targets };
}
export default { mentionTargets, mentionText, cleanMentionText, mentionAll };
