import { readCollection, updateCollection } from '../database/store.js';

const DEFAULTS = { hidden: {} };
let cache = null;
let cacheAt = 0;
function data() { if (!cache || Date.now()-cacheAt > 5000) { cache=readCollection('command_visibility', DEFAULTS); cacheAt=Date.now(); } return cache; }

export function isCommandHidden(name) {
  return !!data().hidden?.[String(name).toLowerCase()];
}

export async function setCommandHidden(name, hidden = true, actor = null) {
  const key = String(name || '').trim().toLowerCase();
  if (!key) throw new Error('Comando obrigatório');
  await updateCollection('command_visibility', d => {
    d.hidden ??= {};
    if (hidden) d.hidden[key] = { hidden: true, actor, updatedAt: Date.now() };
    else delete d.hidden[key];
    return d;
  }, DEFAULTS);
  cache = null;
  return !hidden;
}

export function hiddenCommands() { return Object.keys(data().hidden || {}); }
export default { isCommandHidden, setCommandHidden, hiddenCommands };
