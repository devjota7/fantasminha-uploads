import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';

const FILE = path.join(config.root, 'data', 'platform', 'layered-config.json');
const DEFAULTS = { global: {}, groups: {}, users: {}, commands: {} };
function ensure() { fs.mkdirSync(path.dirname(FILE), { recursive: true }); if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify(DEFAULTS, null, 2)); }
function load() { ensure(); try { return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch { return structuredClone(DEFAULTS); } }
function merge(...xs) { return Object.assign({}, ...xs.filter(Boolean)); }
export function getLayers() { return load(); }
export function resolveConfig({ groupId = null, userId = null, command = null } = {}) {
  const d = load();
  return merge(d.global, groupId && d.groups[groupId], userId && d.users[userId], command && d.commands[command]);
}
export function setLayer(layer, id, patch) {
  const d = load();
  if (!['global', 'groups', 'users', 'commands'].includes(layer)) throw new Error('Camada inválida');
  if (layer === 'global') d.global = merge(d.global, id || {}, patch || {});
  else { const key = String(id || '').trim(); if (!key) throw new Error('id obrigatório'); d[layer][key] = merge(d[layer][key], patch); }
  fs.writeFileSync(FILE, JSON.stringify(d, null, 2)); return d;
}
export default { getLayers, resolveConfig, setLayer };
