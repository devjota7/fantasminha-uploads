/** Control Center HTTP sem dependência externa. API local opcional + dashboard JSON/HTML. */
import http from 'node:http';
import { platformAnalytics } from '../analytics.js';
import config from '../../core/config.js';
import { registryStats, listCommands } from '../../core/registry.js';
import { resourceStats } from '../../core/resourceManager.js';
import { queues } from '../../core/queue.js';
import { listRuntime } from '../../core/runtimeConfig.js';
import { listKnowledge } from '../../services/knowledge/index.js';
import logger from '../../core/logger.js';

let server = null;
const html = () => `<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Fantasminha Control Center</title><style>body{font-family:system-ui;margin:24px;max-width:1100px}pre{white-space:pre-wrap}section{border:1px solid #ddd;border-radius:12px;padding:14px;margin:12px 0}</style></head><body><h1>👻 FANTASMINHA × CONTROL CENTER</h1><p>Dashboard operacional local.</p><section><h2>Overview</h2><pre id="o">carregando…</pre></section><section><h2>Queues</h2><pre id="q">carregando…</pre></section><section><h2>Runtime</h2><pre id="r">carregando…</pre></section><script>async function load(){const d=await fetch('/api/overview').then(r=>r.json());o.textContent=JSON.stringify(d.analytics,null,2);q.textContent=JSON.stringify(d.queues,null,2);r.textContent=JSON.stringify(d.runtime,null,2)}load();setInterval(load,3000)</script></body></html>`;

export function controlSnapshot(){ return { analytics: platformAnalytics(), registry: registryStats(), queues:Object.fromEntries(Object.entries(queues).map(([k,v])=>[k,v.getStatus()])), resources:resourceStats(), runtime:listRuntime(), knowledge:listKnowledge(), commands:listCommands({includeHidden:true}).map(c=>({name:c.name,category:c.category,plugin:c.plugin,hidden:c.hidden})) }; }
export function startControlCenter({ host=process.env.DASHBOARD_HOST || '127.0.0.1', port=Number(process.env.DASHBOARD_PORT || 8787) } = {}) {
  if (server) return server.address();
  server=http.createServer((req,res)=>{ const path=(req.url||'/').split('?')[0]; res.setHeader('Content-Type','application/json; charset=utf-8'); if(path==='/'){res.setHeader('Content-Type','text/html; charset=utf-8'); return res.end(html());} if(path==='/api/health'){return res.end(JSON.stringify({ok:true,version:config.botVersion,uptimeMs:process.uptime()*1000}));} if(path==='/api/overview') return res.end(JSON.stringify(controlSnapshot())); res.statusCode=404; res.end(JSON.stringify({error:'not found'})); });
  server.on('error', e=>logger.error('control-center', e.message)); server.listen(port,host,()=>logger.info('control-center',`dashboard em http://${host}:${port}`)); return { host, port };
}
export async function stopControlCenter(){ if(!server) return; await new Promise(resolve=>server.close(()=>resolve())); server=null; }
export default { startControlCenter, stopControlCenter, controlSnapshot };
