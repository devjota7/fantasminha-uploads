import { snapshot as metricsSnapshot } from '../core/metrics.js';
import { readCollection } from '../database/store.js';
import { registryStats } from '../core/registry.js';
import { resourceStats } from '../core/resourceManager.js';
import { queues } from '../core/queue.js';

export function platformAnalytics(){
  const m=metricsSnapshot();
  const incidents=readCollection('platform_incidents',{items:{}}).items||{};
  const audit=readCollection('platform_audit',{events:[]}).events||[];
  return {
    registry:registryStats(), uptimeMs:m.uptimeMs, commands:m.commands.slice(0,50),
    incidents:{open:Object.values(incidents).filter(x=>x.status==='open').length,total:Object.keys(incidents).length},
    auditEvents:audit.length, resources:resourceStats(),
    queues:Object.fromEntries(Object.entries(queues).map(([k,v])=>[k,v.getStatus()]))
  };
}
export function analyticsText(a=platformAnalytics()){
  return `📊 *FANTASMINHA ANALYTICS*\n\nComandos: ${a.registry.total}\nAliases: ${a.registry.aliases}\nIncidentes abertos: ${a.incidents.open}\nAuditoria: ${a.auditEvents}\nRecursos ativos: ${a.resources.active}\n\n🏆 Top comandos\n${a.commands.slice(0,10).map((x,i)=>`${i+1}. ${x.name} — ${x.calls} usos — ${x.avgMs}ms`).join('\n')||'Sem dados.'}`;
}
export default {platformAnalytics,analyticsText};
