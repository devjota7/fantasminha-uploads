import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { getMember, ensureMember } from '../member/index.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';

const normalize = s => String(s || '').trim();
const key = s => normalize(s).normalize('NFKC').toLocaleLowerCase('pt-BR');
function policy(groupId) { const d = readCollection('nick_policies', { byGroup: {} }); return { unique: true, minLength: 2, maxLength: 24, ...d.byGroup?.[groupId] }; }
function validateNick(nick, p) { if (!nick) throw new Error('Informe o nick.'); if (nick.length < p.minLength || nick.length > p.maxLength) throw new Error(`Nick deve ter ${p.minLength}-${p.maxLength} caracteres.`); if (/[\n\r]/.test(nick)) throw new Error('Nick inválido.'); return nick; }
export function listNicks(groupId = null, { section = null, order = 'alpha' } = {}) {
  const d = readCollection('nicks', { byId: {} }); let list = Object.values(d.byId || {}).filter(x => x.active !== false && (!groupId || x.groupId === groupId));
  if (section) list = list.filter(x => x.sectionId === section);
  if (order === 'alpha') list.sort((a,b) => key(a.nick).localeCompare(key(b.nick),'pt-BR'));
  else if (order === 'reverse') list.sort((a,b) => key(b.nick).localeCompare(key(a.nick),'pt-BR'));
  else if (order === 'newest') list.sort((a,b) => b.updatedAt-a.updatedAt);
  else if (order === 'oldest') list.sort((a,b) => a.createdAt-b.createdAt);
  return list;
}
export async function setNick(platformId, nick, { groupId = null, actor = platformId, sectionId = null, reason = null } = {}) {
  nick = validateNick(normalize(nick), policy(groupId));
  const member = await ensureMember(platformId);
  const memberId = member.memberId;
  const p = policy(groupId);
  let before, after;
  await updateCollection('nicks', d => { d.byId ||= {}; const existing = Object.values(d.byId).find(x => x.active !== false && x.groupId === groupId && key(x.nick) === key(nick) && x.memberId !== memberId); if (p.unique && existing) throw new Error('Esse nick já está em uso.'); const id = d.byId[memberId]?.id || `NICK-${crypto.randomUUID()}`; before = d.byId[memberId] || null; after = { id, memberId, platformId: platformId, groupId, nick, sectionId: sectionId ?? before?.sectionId ?? null, active: true, createdAt: before?.createdAt || Date.now(), updatedAt: Date.now() }; d.byId[memberId] = after; return d; }, { byId: {} });
  await recordAudit({ actor, target: memberId, action: 'NICK_CHANGED', before, after, reason });
  await emit(PlatformEvents.PROFILE_CHANGED, { type: 'nick', memberId, before, after });
  await emit(PlatformEvents.NICK_CHANGED, { memberId, groupId, before, after });
  return after;
}
export async function removeNick(memberId, meta = {}) { let before, after; await updateCollection('nicks', d => { before=d.byId?.[memberId]||null; if(!before) throw new Error('Nick não encontrado.'); after={...before,active:false,updatedAt:Date.now()}; d.byId[memberId]=after; return d; }, {byId:{}}); await recordAudit({actor:meta.actor,target:memberId,action:'NICK_REMOVED',before,after,reason:meta.reason}); return after; }
export async function setSectionPolicy(groupId, patch) { let out; await updateCollection('nick_policies', d => { d.byGroup ||= {}; out = d.byGroup[groupId] = { ...policy(groupId), ...patch }; return d; }, {byGroup:{}}); return out; }
export function missingNicks(groupId, currentIds=[]) { const current = new Set(currentIds); return currentIds.length ? currentIds.filter(id => !Object.values(readCollection('nicks',{byId:{}}).byId||{}).some(n => n.groupId===groupId && n.active!==false && (n.platformId===id || n.memberId===id))) : []; }
export default { listNicks, setNick, removeNick, setSectionPolicy, missingNicks };
