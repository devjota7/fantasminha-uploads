import { readCollection, updateCollection, getUser, upsertUser } from '../../database/store.js';
import { setLayer, resolveConfig } from '../config/index.js';
import { recordAudit } from '../audit/index.js';

const DEFAULT = { language: 'pt-BR', notifications: true, theme: 'limbo', responseStyle: 'normal', favorites: [], custom: {}, plan: 'free' };
export function getPersonal(userId) { const d = readCollection('personal', { byUser: {} }); return { ...DEFAULT, ...(d.byUser?.[userId] || {}) }; }
export async function updatePersonal(userId, patch, meta = {}) { const before = getPersonal(userId); const after = { ...before, ...patch, updatedAt: Date.now() }; await updateCollection('personal', d => { d.byUser ||= {}; d.byUser[userId] = after; return d; }, { byUser: {} }); await upsertUser(userId, { preferences: after }); await recordAudit({ actor: meta.actor || userId, action: 'PERSONAL_UPDATED', before, after, requestId: meta.requestId, operationId: meta.operationId }); return after; }
export function isVip(userId) { const u = getUser(userId); return !!(u?.premium?.active && Number(u.premium.until || 0) > Date.now()); }
export async function setCustom(userId, key, value, { premium = false, actor = userId } = {}) { if (premium && !isVip(userId)) throw new Error('Este recurso de personalização exige VIP.'); const p = getPersonal(userId); const custom = { ...(p.custom || {}), [key]: value }; return updatePersonal(userId, { custom }, { actor }); }
export function resolvePersonal(userId, groupId = null, command = null) { return { ...resolveConfig({ groupId, userId, command }), ...getPersonal(userId) }; }
export default { getPersonal, updatePersonal, isVip, setCustom, resolvePersonal };
