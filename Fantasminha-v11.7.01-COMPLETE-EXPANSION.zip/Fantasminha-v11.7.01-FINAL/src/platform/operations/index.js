import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { recordAudit } from '../audit/index.js';

export async function beginOperation({ key, actor = null, command = null, requestId = null, ttlMs = 24 * 3600_000 } = {}) {
  if (!key) throw new Error('operation key obrigatório');
  const now = Date.now();
  let existing;
  await updateCollection('platform_operations', d => {
    d.items ||= {};
    const old = d.items[key];
    if (old && now - old.createdAt < ttlMs) { existing = old; return d; }
    d.items[key] = existing = { id: `OP-${crypto.randomUUID()}`, key, actor, command, requestId, createdAt: now, status: 'running' };
    return d;
  }, { items: {} });
  return { created: !existing || existing.status === 'running' && existing.createdAt === now, operation: existing };
}

export async function finishOperation(key, result = {}) {
  let operation;
  await updateCollection('platform_operations', d => { d.items ||= {}; operation = d.items[key]; if (operation) d.items[key] = { ...operation, ...result, status: result.status || 'completed', finishedAt: Date.now() }; return d; }, { items: {} });
  return operation;
}

export async function runIdempotent({ key, actor = null, command = null, requestId = null, handler }) {
  if (typeof handler !== 'function') throw new Error('handler obrigatório');
  const started = await beginOperation({ key, actor, command, requestId });
  if (!started.created && ['completed', 'failed'].includes(started.operation?.status)) return { replay: true, result: started.operation.result };
  try {
    const result = await handler(started.operation);
    await finishOperation(key, { status: 'completed', result });
    await recordAudit({ actor, action: 'OPERATION_COMPLETED', operationId: started.operation.id, requestId, result: 'success', details: { key, command } });
    return { replay: false, result, operation: started.operation };
  } catch (error) {
    await finishOperation(key, { status: 'failed', result: { error: error.message } });
    await recordAudit({ actor, action: 'OPERATION_FAILED', operationId: started.operation.id, requestId, result: 'error', details: { key, command, error: error.message } });
    throw error;
  }
}
export default { beginOperation, finishOperation, runIdempotent };
