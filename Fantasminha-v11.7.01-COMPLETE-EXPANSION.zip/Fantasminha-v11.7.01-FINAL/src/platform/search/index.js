import { readCollection } from '../../database/store.js';
const norm=s=>String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
export function searchGlobal(query,{limit=10}={}){const q=norm(query);if(q.length<2)return[];const out=[];const users=readCollection('users',{byId:{}}).byId||{};for(const u of Object.values(users)){const hay=norm([u.id,u.fantasminhaId,u.name,u.preferences?.custom?.nick].join(' '));if(hay.includes(q))out.push({type:'member',id:u.fantasminhaId||u.id,name:u.name||u.id,score:hay===q?3:1});if(out.length>=limit)break;}return out;}
export default {searchGlobal};
