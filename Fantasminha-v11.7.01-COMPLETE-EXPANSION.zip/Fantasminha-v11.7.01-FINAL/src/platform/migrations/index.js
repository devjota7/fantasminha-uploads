import fs from 'node:fs';
import path from 'node:path';
import { emit, PlatformEvents } from '../events/index.js';
import config from '../../core/config.js';
const FILE=path.join(config.root,'data','platform','migration-registry.json');const migrations=new Map();
function ensure(){fs.mkdirSync(path.dirname(FILE),{recursive:true});if(!fs.existsSync(FILE))fs.writeFileSync(FILE,JSON.stringify({used:{}},null,2));}
function load(){ensure();try{return JSON.parse(fs.readFileSync(FILE,'utf8'));}catch{return{used:{}};}}
export function registerMigration({legacy,target,mode='silent',enabled=true,note=null}={}){if(!legacy||!target)throw new Error('Migração exige legacy e target');const m={legacy:String(legacy).toLowerCase(),target:String(target).toLowerCase(),mode,enabled,note};migrations.set(m.legacy,m);return m;}
export function resolveMigration(name){const m=migrations.get(String(name||'').toLowerCase());return m?.enabled?m:null;}
export async function noteMigrationUsed(m,ctx={}){const d=load();d.used[m.legacy]=(d.used[m.legacy]||0)+1;fs.writeFileSync(FILE,JSON.stringify(d,null,2));await emit(PlatformEvents.MIGRATION_USED,{migration:m,ctx,count:d.used[m.legacy]});}
export function listMigrations(){return[...migrations.values()].map(m=>({...m,uses:load().used?.[m.legacy]||0}));}
export default{registerMigration,resolveMigration,noteMigrationUsed,listMigrations};
