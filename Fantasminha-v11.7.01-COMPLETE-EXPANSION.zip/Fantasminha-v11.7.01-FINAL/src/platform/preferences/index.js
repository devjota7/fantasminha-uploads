import { readCollection, updateCollection } from '../../database/store.js';
import { isVip } from '../personal/index.js';
import { recordAudit } from '../audit/index.js';
const DEFAULT={language:'pt-BR',theme:'limbo',responseStyle:'normal',notifications:true,birthdayMentions:true,birthdayReminders:true,nickDisplay:'official',searchPageSize:10};
const allowed=new Set(Object.keys(DEFAULT));
export function getPreferences(userId){const d=readCollection('preferences',{byUser:{}});return {...DEFAULT,...(d.byUser?.[userId]||{})};}
export async function setPreference(userId,key,value,{actor=userId, premium=false}={}){if(!allowed.has(key)&&!key.startsWith('custom.'))throw new Error('Preferência não permitida.');if(premium&&!isVip(userId))throw new Error('Este recurso exige VIP.');const before=getPreferences(userId);let after;await updateCollection('preferences',d=>{d.byUser||={};after={...before,[key]:value,updatedAt:Date.now()};d.byUser[userId]=after;return d;},{byUser:{}});await recordAudit({actor,target:userId,action:'PREFERENCE_CHANGED',before,after});return after;}
export async function setCustom(userId,key,value,meta={}){return setPreference(userId,`custom.${key}`,value,{...meta,premium:true});}
export default {getPreferences,setPreference,setCustom};
