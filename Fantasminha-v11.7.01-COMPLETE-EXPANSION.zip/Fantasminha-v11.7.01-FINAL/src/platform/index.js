import { ensureIdentity } from './identity/index.js';
import { registerJob, startAllJobs } from './jobs/index.js';
import { createSnapshot } from './snapshots/index.js';
import { runIntegrity } from './integrity/index.js';
import { recordAudit } from './audit/index.js';
import { featureEnabled } from './flags/index.js';
import { registerMigration } from './migrations/index.js';
import { defineDependencies } from './dependencies/index.js';
import { on, PlatformEvents } from './events/index.js';
import logger from '../core/logger.js';
import config from '../core/config.js';
import { startControlCenter } from './controlCenter/index.js';

let ready = false;
export async function bootstrapPlatform() {
  if (ready) return { ready: true };
  if (featureEnabled('platform.identity')) {
    // Identity is lazy per user; this only verifies the service is importable.
  }
  if (featureEnabled('platform.migrations')) {
    registerMigration({ legacy: 'menu', target: 'ajuda', mode: 'notice', note: 'Mapa inicial de compatibilidade' });
    registerMigration({ legacy: 'statusbot', target: 'status', mode: 'silent' });
    registerMigration({ legacy: 'health', target: 'status', mode: 'silent' });
  }
  defineDependencies('economy.transfer', ['identity', 'transactions', 'audit']);
  defineDependencies('personal.customize', ['identity', 'preferences']);
  defineDependencies('triage.judge', ['identity', 'audit', 'events']);
  defineDependencies('member.nick', ['identity', 'audit', 'events']);
  defineDependencies('member.birthday', ['identity', 'audit']);
  defineDependencies('rpg.training', ['identity', 'rewards', 'progression']);
  defineDependencies('economy.sell', ['identity', 'transactions', 'audit']);
  defineDependencies('community.search', ['identity']);
  on(PlatformEvents.INTEGRITY_CHECKED, payload => logger.info('platform', 'integrity checked', payload));
  registerJob({ name: 'platform:integrity', intervalMs: 15 * 60_000, run: async () => runIntegrity() });
  registerJob({ name: 'platform:snapshot', intervalMs: 6 * 60 * 60_000, run: async () => createSnapshot('scheduled') });
  registerJob({ name: 'platform:birthday-daily', intervalMs: 60 * 60_000, run: async () => { /* automação de aniversário fica pronta para integração com o dispatcher */ } });
  startAllJobs();
  if (config.features.dashboard && process.env.DASHBOARD_ENABLED === 'true') startControlCenter();
  await recordAudit({ action: 'PLATFORM_BOOTSTRAP', result: 'success', details: { version: config.botVersion, architecture: 'multi-base-fusion-control-center' } });
  ready = true;
  return { ready: true };
}
export { ensureIdentity };
export * from './identity/index.js';
export * from './flags/index.js';
export * from './config/index.js';
export * from './audit/index.js';
export * from './operations/index.js';
export * from './transactions/index.js';
export * from './snapshots/index.js';
export * from './jobs/index.js';
export * from './dependencies/index.js';
export * from './migrations/index.js';
export * from './personal/index.js';
export * from './integrity/index.js';
export * from './incidents/index.js';
export * from './analytics.js';
export * from './events/index.js';
export default { bootstrapPlatform };
