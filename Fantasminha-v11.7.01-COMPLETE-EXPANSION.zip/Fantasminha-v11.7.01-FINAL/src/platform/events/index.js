import { on, emit, Events } from '../../events/index.js';

export const PlatformEvents = Object.freeze({
  COMMAND_STARTED: 'platform:command.started',
  COMMAND_FINISHED: 'platform:command.finished',
  OPERATION_STARTED: 'platform:operation.started',
  OPERATION_FINISHED: 'platform:operation.finished',
  ECONOMY_TRANSFERRED: 'platform:economy.transferred',
  PROFILE_CHANGED: 'platform:profile.changed',
  PREFERENCE_CHANGED: 'platform:preference.changed',
  INCIDENT_CREATED: 'platform:incident.created',
  SNAPSHOT_CREATED: 'platform:snapshot.created',
  MIGRATION_USED: 'platform:migration.used',
  FEATURE_CHANGED: 'platform:feature.changed',
  INTEGRITY_CHECKED: 'platform:integrity.checked',
  JOB_FAILED: 'platform:job.failed',
  JOB_FINISHED: 'platform:job.finished',
  NICK_CHANGED: 'platform:nick.changed',
  BIRTHDAY_CHANGED: 'platform:birthday.changed',
  MEMBER_CHANGED: 'platform:member.changed',
  REWARD_GRANTED: 'platform:reward.granted'
});

export { on, emit, Events };
export default { on, emit, Events, PlatformEvents };
