import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';

const FILE = path.join(config.root, 'data', 'platform', 'feature-flags.json');
const defaults = {
  'platform.identity': true,
  'platform.audit': true,
  'platform.operations': true,
  'platform.transactions': true,
  'platform.jobs': true,
  'platform.personal': true,
  'platform.migrations': true,
  'platform.integrity': true,
  'platform.search': true
};

function ensure() {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  if (!fs.existsSync(FILE)) fs.writeFileSync(FILE, JSON.stringify({ ...defaults }, null, 2));
}
function load() { ensure(); try { return { ...defaults, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch { return { ...defaults }; } }
export function featureEnabled(name, fallback = false) { const v = load()[name]; return v === undefined ? fallback : !!v; }
export function getFeatureFlags() { return load(); }
export function setFeatureFlag(name, value) {
  const flags = load(); flags[String(name)] = !!value; fs.writeFileSync(FILE, JSON.stringify(flags, null, 2)); return flags[String(name)];
}
export default { featureEnabled, getFeatureFlags, setFeatureFlag };
