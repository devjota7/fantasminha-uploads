import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';
import { registryStats, validateRegistry } from '../../core/registry.js';
import { checkDatabase } from '../../database/store.js';
import { getFeatureFlags } from '../flags/index.js';
import { dependencyGraph } from '../dependencies/index.js';
import { listMigrations } from '../migrations/index.js';
import { auditStats } from '../audit/index.js';
export function runIntegrity() {
  const checks = [];
  const add = (name, ok, details = null) => checks.push({ name, ok: !!ok, details });
  const reg = validateRegistry(); add('registry', reg.ok, reg.errors.slice(0, 20)); add('database', checkDatabase()); add('package', fs.existsSync(path.join(config.root, 'package.json'))); add('config', config.validate().ok, config.validate().missing); add('feature-flags', Object.keys(getFeatureFlags()).length > 0); add('migrations', Array.isArray(listMigrations())); add('audit', auditStats().total >= 0); add('dependencies', Object.keys(dependencyGraph()).length >= 0);
  return { ok: checks.every(x => x.ok), checks, registry: registryStats(), at: Date.now() };
}
export function integrityText(r = runIntegrity()) { return `👻 *FANTASMINHA DOCTOR 5.1*\n\n${r.checks.map(c => `${c.ok ? '🟢' : '🔴'} ${c.name}`).join('\n')}\n\nComandos: ${r.registry.total}\nAliases: ${r.registry.aliases}\nResultado: *${r.ok ? 'SAUDÁVEL' : 'ATENÇÃO'}*`; }
export default { runIntegrity, integrityText };
