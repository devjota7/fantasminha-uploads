import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';

export async function recordAudit({ actor = null, target = null, action, scope = null, before = null, after = null, reason = null, requestId = null, operationId = null, result = 'success', details = {} } = {}) {
  if (!action) throw new Error('action obrigatório');
  const event = { id: `AUD-${crypto.randomUUID()}`, at: Date.now(), actor, target, action, scope, before, after, reason, requestId, operationId, result, details };
  await updateCollection('platform_audit', d => { d.events ||= []; d.events.push(event); if (d.events.length > 20000) d.events.splice(0, d.events.length - 20000); return d; }, { events: [] });
  return event;
}
export function auditStats() { const d = readCollection('platform_audit', { events: [] }); return { total: d.events.length, last: d.events.at(-1) || null }; }
export function auditFind(predicate) { return readCollection('platform_audit', { events: [] }).events.filter(predicate); }
export default { recordAudit, auditStats, auditFind };
