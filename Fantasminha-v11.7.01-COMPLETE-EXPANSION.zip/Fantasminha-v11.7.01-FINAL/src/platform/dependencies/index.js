const graph = new Map();
export function defineDependencies(command, dependencies = []) { graph.set(command, [...new Set(dependencies.filter(Boolean))]); return graph.get(command); }
export function dependenciesOf(command) { return graph.get(command) || []; }
export function dependencyGraph() { return Object.fromEntries([...graph.entries()].map(([k, v]) => [k, [...v]])); }
export function validateDependencies(command, available = []) { const set = new Set(available); const missing = dependenciesOf(command).filter(x => !set.has(x)); return { ok: !missing.length, missing }; }
export default { defineDependencies, dependenciesOf, dependencyGraph, validateDependencies };
