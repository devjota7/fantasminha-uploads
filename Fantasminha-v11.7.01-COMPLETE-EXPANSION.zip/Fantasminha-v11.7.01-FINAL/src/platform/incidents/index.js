import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';
export const IncidentSeverity = Object.freeze({ P1: 4, P2: 3, P3: 2, P4: 1 });
export async function createIncident({ title, severity = 'P3', source = 'manual', actor = null, details = {}, dedupeWindowMs = 30_000 } = {}) {
  if (!title) throw new Error('Título do incidente obrigatório');
  const recent = listIncidents('open').find(x => x.source === source && x.title === title && Date.now() - x.createdAt <= dedupeWindowMs);
  if (recent) {
    const merged = await updateIncident(recent.id, { details: { ...(recent.details || {}), ...details }, occurrences: Number(recent.occurrences || 1) + 1 }, actor);
    return { ...merged, deduplicated: true };
  }
  const incident={id:`INC-${crypto.randomUUID().slice(0,8).toUpperCase()}`,title,severity,source,status:'open',actor,details,occurrences:1,createdAt:Date.now(),updatedAt:Date.now(),timeline:[{at:Date.now(),event:'created',actor}]};
  await updateCollection('platform_incidents',d=>{d.items??={};d.items[incident.id]=incident;return d;},{items:{}});
  await recordAudit({actor,action:'INCIDENT_CREATED',result:'success',details:incident}); await emit(PlatformEvents.INCIDENT_CREATED,incident); return incident;
}
export async function updateIncident(id,patch={},actor=null){let out;await updateCollection('platform_incidents',d=>{const item=d.items?.[id];if(!item)throw new Error('Incidente não encontrado');out={...item,...patch,updatedAt:Date.now(),timeline:[...(item.timeline||[]),{at:Date.now(),event:patch.status||'updated',actor}]};d.items[id]=out;return d;},{items:{}});await recordAudit({actor,action:'INCIDENT_UPDATED',result:'success',details:{id,patch}});return out;}
export function listIncidents(status=null){const d=readCollection('platform_incidents',{items:{}});return Object.values(d.items||{}).filter(x=>!status||x.status===status).sort((a,b)=>b.createdAt-a.createdAt);}
export default {createIncident,updateIncident,listIncidents,IncidentSeverity};
