import crypto from 'node:crypto';
import { getUser, upsertUser, readCollection, updateCollection } from '../../database/store.js';
import { fantasminhaId } from '../identity/index.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';

const now = () => Date.now();
function ensureRecord(d, id, patch = {}) {
  d.byId ||= {};
  const prev = d.byId[id] || { memberId: id, createdAt: now(), status: 'active', profile: {}, nick: null, birthday: null, sections: [] };
  d.byId[id] = { ...prev, ...patch, updatedAt: now() };
  return d.byId[id];
}
export async function ensureMember(platformId, patch = {}) {
  if (!platformId) throw new Error('platformId obrigatório');
  const memberId = fantasminhaId(platformId);
  let member;
  await updateCollection('members', d => { member = ensureRecord(d, memberId, { platformId: String(platformId), ...patch }); return d; }, { byId: {} });
  await upsertUser(platformId, { fantasminhaId: memberId, ...(patch.name ? { name: patch.name } : {}) });
  return member;
}
export function getMember(memberIdOrPlatform) {
  const memberId = String(memberIdOrPlatform || '').startsWith('FNT-') ? String(memberIdOrPlatform) : fantasminhaId(memberIdOrPlatform);
  return readCollection('members', { byId: {} }).byId?.[memberId] || null;
}
export async function updateMember(memberId, patch, meta = {}) {
  let before, after;
  await updateCollection('members', d => { before = d.byId?.[memberId] || null; if (!before) throw new Error('Membro não encontrado'); after = { ...before, ...patch, updatedAt: now() }; d.byId[memberId] = after; return d; }, { byId: {} });
  await recordAudit({ actor: meta.actor, target: memberId, action: 'MEMBER_UPDATED', before, after, reason: meta.reason, requestId: meta.requestId, operationId: meta.operationId });
  await emit(PlatformEvents.PROFILE_CHANGED, { memberId, before, after });
  return after;
}
export async function setMembership(memberId, status, meta = {}) {
  if (!['active','left','removed','banned','reinstated'].includes(status)) throw new Error('status de membro inválido');
  return updateMember(memberId, { status, membershipAt: now() }, meta);
}
export function listMembers({ status = null, groupId = null } = {}) {
  const all = Object.values(readCollection('members', { byId: {} }).byId || {});
  return all.filter(m => !status || m.status === status).filter(m => !groupId || m.groups?.includes(groupId));
}
export default { ensureMember, getMember, updateMember, setMembership, listMembers };
