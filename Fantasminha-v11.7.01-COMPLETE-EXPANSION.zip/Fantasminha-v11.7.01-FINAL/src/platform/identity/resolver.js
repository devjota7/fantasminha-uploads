import { isLid, normalizeJid, phoneFromJid } from './lid.js';

const asJid = v => normalizeJid(v);
const pn = v => {
  const s = normalizeJid(v);
  if (!s) return null;
  if (s.endsWith('@s.whatsapp.net')) return s;
  const digits = s.replace(/\D/g, '');
  return digits ? `${digits}@s.whatsapp.net` : null;
};

function participantCandidates(p = {}) {
  return [p.jid, p.id, p.participant, p.phoneNumber, p.pn, p.phone, p.number].filter(Boolean).map(asJid);
}

export function participantRealJid(p = {}) {
  const candidates = participantCandidates(p);
  const direct = candidates.find(x => x.endsWith('@s.whatsapp.net'));
  if (direct) return direct;
  const rawPhone = p.phoneNumber || p.pn || p.phone || p.number;
  return pn(rawPhone);
}

export function buildIdentityIndex(participants = []) {
  const byAny = new Map();
  const rows = [];
  for (const p of participants || []) {
    if (!p) continue;
    const realJid = participantRealJid(p);
    const lid = [p.lid, p.id, p.participant].map(asJid).find(isLid) || null;
    const row = { realJid, lid, name: p.name || p.notify || p.pushName || p.pushname || '', pushName: p.pushName || p.pushname || p.notify || p.name || '', raw: p };
    rows.push(row);
    for (const x of participantCandidates(p)) byAny.set(x, row);
    if (lid) byAny.set(lid, row);
    if (realJid) byAny.set(realJid, row);
  }
  return { byAny, rows };
}

export async function resolveUserIdentity(ctx = {}, target = null) {
  const requested = normalizeJid(target || ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.sender || '');
  const requestedBase = requested.split('@')[0].split(':')[0];
  let participants = Array.isArray(ctx.groupParticipantObjects) ? ctx.groupParticipantObjects : [];
  if (!participants.length && ctx.getGroupMetadata && ctx.from?.endsWith('@g.us')) {
    try { participants = (await ctx.getGroupMetadata(ctx.from))?.participants || []; } catch {}
  }
  const index = buildIdentityIndex(participants);
  let row = index.byAny.get(requested);
  if (!row && requestedBase) row = index.rows.find(x => [x.realJid, x.lid].some(v => v?.split('@')[0].split(':')[0] === requestedBase));
  const senderAlternates = [ctx.sender, ctx.senderOriginal, ctx.senderAlternate].filter(Boolean).map(asJid);
  if (!row) for (const alt of senderAlternates) { row = index.byAny.get(alt); if (row) break; }

  const realJid = row?.realJid || (!isLid(requested) ? pn(requested) : null);
  const lid = row?.lid || (isLid(requested) ? requested : null);
  const number = phoneFromJid(realJid) || (row?.raw?.phoneNumber ? String(row.raw.phoneNumber).replace(/\D/g, '') : null);
  return {
    requested,
    number,
    realJid,
    lid,
    name: row?.name || ctx.pushname || '',
    pushName: row?.pushName || ctx.pushname || '',
    mentionJid: realJid || null,
    isResolvable: !!realJid,
    raw: row?.raw || null
  };
}

export async function resolveMentionTargets(ctx, targets = null) {
  const raw = targets || (ctx.mentioned?.length ? ctx.mentioned : ctx.quotedParticipant ? [ctx.quotedParticipant] : [ctx.sender]);
  const out = [];
  for (const target of raw) {
    const r = await resolveUserIdentity(ctx, target);
    if (r.realJid && !out.some(x => x.realJid === r.realJid)) out.push(r);
  }
  return out;
}

export default { resolveUserIdentity, resolveMentionTargets, buildIdentityIndex, participantRealJid };
