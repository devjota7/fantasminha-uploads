/** Normalização de JID/LID: evita que cada serviço implemente sua própria regra. */
export function normalizeJid(value = '') { return String(value || '').trim().toLowerCase(); }
export function isGroupJid(value = '') { return normalizeJid(value).endsWith('@g.us'); }
export function isUserJid(value = '') { const v = normalizeJid(value); return v.endsWith('@s.whatsapp.net') || v.endsWith('@lid'); }
export function isLid(value = '') { return normalizeJid(value).endsWith('@lid'); }
export function phoneFromJid(value = '') { const v = normalizeJid(value).split('@')[0]; return /^\d+$/.test(v) ? v : null; }
export function sameIdentity(a, b) { return normalizeJid(a) === normalizeJid(b); }
export default { normalizeJid, isGroupJid, isUserJid, isLid, phoneFromJid, sameIdentity };
