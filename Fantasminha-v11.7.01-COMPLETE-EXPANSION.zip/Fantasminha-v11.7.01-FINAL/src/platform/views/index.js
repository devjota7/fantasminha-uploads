import { readCollection, updateCollection } from '../../database/store.js';
export function getView(groupId,name){return readCollection('views',{byGroup:{}}).byGroup?.[groupId]?.[name]||null;}
export async function setView(groupId,name,patch){let out;await updateCollection('views',d=>{d.byGroup||={};d.byGroup[groupId]||={};out=d.byGroup[groupId][name]={...(d.byGroup[groupId][name]||{}),...patch,updatedAt:Date.now()};return d;},{byGroup:{}});return out;}
export default {getView,setView};
