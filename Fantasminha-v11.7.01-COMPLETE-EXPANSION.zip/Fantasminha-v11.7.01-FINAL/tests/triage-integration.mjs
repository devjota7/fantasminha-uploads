import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { saveSettings, memberJoined, handlePrivateMessage, getTriage, judgeTriage, STATES, rejectionHistory } from '../src/services/triage.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dbDir = path.join(root, 'data', 'db');
const snap = fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-triage-int-'));
fs.cpSync(dbDir,snap,{recursive:true});
try {
  for (const f of ['groups.json','triage.json','triage_history.json','triage_blacklist.json','triage_audit.json']) try { fs.unlinkSync(path.join(dbDir,f)); } catch {}
  const sent=[];
  const sock={
    groupMetadata: async () => ({participants:[{id:'admin@s.whatsapp.net',admin:'admin'},{id:'u1@s.whatsapp.net'}]}),
    sendMessage: async (jid,content) => { sent.push({jid,content}); },
    groupParticipantsUpdate: async () => ({ok:true})
  };
  await saveSettings('g1',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome?'},{id:'q2',type:'number',required:true,question:'Idade?',min:1,max:120}]});
  const join=await memberJoined(sock,'g1','u1@s.whatsapp.net');
  if(!join.ok || !join.code || !sent.some(x=>x.content?.text?.includes(join.code))) throw new Error('join/link não registrado');
  let t=await getTriage(join.code); if(t.state!==STATES.PENDING) throw new Error('estado inicial');
  const replies=[];
  const info={key:{remoteJid:'u1@s.whatsapp.net',fromMe:false},message:{conversation:join.code}};
  await handlePrivateMessage({sock,info,sender:'u1@s.whatsapp.net',text:join.code,send:async x=>replies.push(x)});
  t=await getTriage(join.code); if(t.state!==STATES.RUNNING || !replies.length) throw new Error('início PV falhou');
  await handlePrivateMessage({sock,info,sender:'u1@s.whatsapp.net',text:'Alice',send:async x=>replies.push(x)});
  await handlePrivateMessage({sock,info,sender:'u1@s.whatsapp.net',text:'16',send:async x=>replies.push(x)});
  t=await getTriage(join.code); if(t.state!==STATES.JUDGING || t.answers.length!==2) throw new Error('respostas/ficha falharam');
  const full=sent.find(x=>x.jid==='admin@s.whatsapp.net' && x.content?.text?.includes('FICHA DA ALMA'));
  if(!full) throw new Error('ficha não chegou ao admin');
  const j=await judgeTriage(join.code,{id:'admin@s.whatsapp.net',name:'Admin'},'reject','teste de reprovação','network');
  if(!j.ok || j.triage.state!==STATES.REJECTED) throw new Error('julgamento falhou');
  if((await rejectionHistory('u1@s.whatsapp.net')).length!==1) throw new Error('histórico não salvo');
  console.log(`TRIAGE INTEGRATION OK — ${join.code} | PV | ficha admin | julgamento`);
} finally { fs.rmSync(dbDir,{recursive:true,force:true}); fs.cpSync(snap,dbDir,{recursive:true}); fs.rmSync(snap,{recursive:true,force:true}); }
