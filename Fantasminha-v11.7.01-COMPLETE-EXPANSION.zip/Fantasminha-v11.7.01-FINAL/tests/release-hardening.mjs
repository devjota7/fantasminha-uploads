import fs from 'fs';
import path from 'path';
import { execFileSync } from 'child_process';
const root=process.cwd(); const fail=[]; const ok=[];
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
if(!/^\d+\.\d+\.\d+/.test(pkg.version)) fail.push(`versão inválida: ${pkg.version}`); else ok.push(`package version ${pkg.version}`);
for(const p of ['.env.example','scripts/install-termux.sh','scripts/release-manifest.mjs','src/services/triage.js','src/core/registry.js','dados/src/menus/catalogMenu.js','dados/src/menus/menu.js','src/platform/identity/resolver.js','src/services/mentionManager.js','src/services/gameSessionManager.js','src/services/gameTimer.js','src/services/social.js','src/plugins/social/index.js']) if(!fs.existsSync(path.join(root,p))) fail.push(`arquivo ausente: ${p}`); else ok.push(p);
const tri=fs.readFileSync('src/services/triage.js','utf8'); if(!/resolveUserIdentity/.test(fs.readFileSync('src/plugins/triagem/index.js','utf8'))) fail.push('triagem sem resolução central de identidade'); else ok.push('triage identity resolver'); if(!/export\s+function\s+extractIncomingText/.test(tri)) fail.push('extractIncomingText não exportada'); else ok.push('triage export');
const we=fs.readFileSync('src/plugins/worldEngine/index.js','utf8'); if(/\['pista',\s*\['pistacaso'\]/.test(we)) fail.push('alias pistacaso ainda duplicado'); else ok.push('pistacaso conflict removed');
const idx=fs.readFileSync('dados/src/index.js','utf8'); if(/\bLogos2\b/.test(idx)) fail.push('referência Logos2 morta'); else ok.push('Logos2 removed'); if(/patchBaileysNewsletterFollow/.test(idx)) fail.push('patch newsletterFollow obsoleto ainda presente'); else ok.push('newsletter patch removed');
const cat=JSON.parse(fs.readFileSync('dados/src/menus/commandCatalog.json','utf8')); const dead=['gada','infoff','likeff','menudow','triagemcria','triagemsetperguntas','wl']; for(const d of dead) if(Object.values(cat).some(a=>a.includes(d))) fail.push(`comando morto ainda no catálogo: ${d}`); else ok.push(`dead catalog removed: ${d}`);
try { execFileSync(process.execPath,['--check','dados/src/index.js']); ok.push('legacy syntax'); } catch { fail.push('dados/src/index.js syntax'); }
console.log('RELEASE HARDENING'); for(const x of ok) console.log('✅ '+x); for(const x of fail) console.error('❌ '+x); if(fail.length) process.exit(1); console.log('RELEASE HARDENING OK');
