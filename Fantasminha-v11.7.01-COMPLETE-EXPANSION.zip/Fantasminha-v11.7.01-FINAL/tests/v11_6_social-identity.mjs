import { bootstrapV2 } from '../src/core/bootstrap.js';
import { getCommand } from '../src/core/registry.js';
import { resolveUserIdentity } from '../src/platform/identity/resolver.js';
import { mentionAll } from '../src/services/mentionManager.js';
import { addBestFriend, removeBestFriend, setAfk, findAfk, clearAfk } from '../src/services/social.js';
import { readCollection, updateCollection } from '../src/database/store.js';

import { saveSettings } from '../src/services/triage.js';
import { getCommand as getCmd } from '../src/core/registry.js';

await bootstrapV2();
for (const name of ['addbestfriend','rmvbestfriend','todos','t','personalidade','afk']) if (!getCommand(name)) throw new Error(`comando ausente: ${name}`);
const participants=[
  {id:'111111@lid',jid:'5511999990001@s.whatsapp.net',phoneNumber:'5511999990001@s.whatsapp.net',name:'Ana'},
  {id:'222222@lid',jid:'5511999990002@s.whatsapp.net',phoneNumber:'5511999990002@s.whatsapp.net',name:'Bia'},
  {id:'333333@lid',jid:'5511999990003@s.whatsapp.net',phoneNumber:'5511999990003@s.whatsapp.net',name:'Cau'},
  {id:'444444@lid',jid:'5511999990004@s.whatsapp.net',phoneNumber:'5511999990004@s.whatsapp.net',name:'Bot'}
];
const ctx={isGroup:true,from:'social-test@g.us',sender:'111111@lid',senderOriginal:'111111@lid',senderAlternate:'5511999990001@s.whatsapp.net',pushname:'Ana',mentioned:['222222@lid'],groupParticipantObjects:participants,groupParticipants:participants.map(x=>x.id),botJid:'444444@lid',reply:async()=>{}};
const identity=await resolveUserIdentity(ctx,'222222@lid');
if(identity.realJid!=='5511999990002@s.whatsapp.net') throw new Error('LID não resolveu para JID real');
const payload=await mentionAll({...ctx,q:'oieeee pessoal' },'oieeee pessoal');
if(payload.mentions.includes('444444@lid') || payload.mentions.some(x=>x.endsWith('@lid'))) throw new Error('mentionAll usou LID');
if(payload.text!=='oieeee pessoal') throw new Error('texto do todos foi alterado');
await addBestFriend(ctx,'222222@lid');
if(readCollection('users',{byId:{}}).byId?.['111111@lid']?.bestFriend!=='5511999990002@s.whatsapp.net') throw new Error('Best Friend não salvo com JID real');
await removeBestFriend(ctx,'222222@lid');
await setAfk(ctx,'comendo');
const afk=await findAfk(ctx,'111111@lid');
if(!afk || afk.record.reason!=='comendo') throw new Error('AFK não encontrado');
await clearAfk(ctx);
await saveSettings('triage-social@g.us',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome',order:1}]});
const triageReplies=[];
const triageCtx={...ctx,from:'triage-social@g.us',isGroup:true,isGroupAdmin:true,groupParticipants:participants.map(x=>x.id),groupParticipantObjects:participants,botJid:'444444@lid',reply:async(t,o={})=>{triageReplies.push({text:String(t),mentions:o.mentions||[]});}};
const cobrar=getCmd('triagemcobrar'); await cobrar.handler(triageCtx);
const posted=triageReplies.filter(x=>x.mentions.length);
if(!posted.length || posted.some(x=>x.mentions.some(j=>String(j).endsWith('@lid')))) throw new Error('triagemcobrar publicou LID');
const before=readCollection('triage',{byId:{}}); const countBefore=Object.keys(before.byId||{}).length;
await cobrar.handler(triageCtx); const after=readCollection('triage',{byId:{}}); const countAfter=Object.keys(after.byId||{}).length;
if(countAfter!==countBefore) throw new Error('triagemcobrar criou triagens duplicadas');
await updateCollection('triage',d=>{d.byId={};d.active={};return d;},{byId:{},active:{}});
console.log('V11.6 SOCIAL/IDENTITY OK — LID→JID, menções reais, BF, AFK e cobrança sem duplicidade');
