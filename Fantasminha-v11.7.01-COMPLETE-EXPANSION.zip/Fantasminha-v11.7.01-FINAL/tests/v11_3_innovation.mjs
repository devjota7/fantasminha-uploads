import { createMystery, history, recordHistory } from '../src/services/innovation.js';
import { getSettings, deleteTriageConfiguration, beginTriageEdit } from '../src/services/triage.js';
const gid='test@g.us'; const uid='5511999999999@s.whatsapp.net';
await recordHistory(gid,'test','Teste v11.3','Registro de validação');
if(!history(gid).some(x=>x.title==='Teste v11.3')) throw new Error('history failed');
const m=await createMystery(gid,'Caso de Validação'); if(!m.id.startsWith('CASO-')) throw new Error('mystery failed');
await deleteTriageConfiguration(gid); const s=await getSettings(gid); if(s.questions.length!==0||s.enabled) throw new Error('triage delete failed');
console.log('V11.3 OK — história | mistérios | triagem excluir | setpergunta API');
