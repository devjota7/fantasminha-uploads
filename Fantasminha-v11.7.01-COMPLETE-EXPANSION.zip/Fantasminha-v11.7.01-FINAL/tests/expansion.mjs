import { registryStats } from "../src/core/registry.js";
import { register } from "../src/plugins/expansion/index.js";
await register();
const s=registryStats();
if(s.total < 100) throw new Error("expansion não registrou comandos suficientes");
console.log(`EXPANSION TEST OK — registry ${s.total} comandos`);
