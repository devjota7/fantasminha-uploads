import assert from 'node:assert/strict';
import fs from 'node:fs';
import { clearRegistry, registryStats, listCommands, getCommand } from '../src/core/registry.js';
import { register } from '../src/plugins/completeExpansion/index.js';
import game from '../src/services/gameEngine.js';
import stats from '../src/services/statsEngine.js';
import pets from '../src/services/petEngine.js';

const root=new URL('../data/db/',import.meta.url).pathname;
const collections=['game_engine','stats_engine','achievement_engine','pet_engine','season_engine','tournament_engine'];
for(const c of collections) try{fs.rmSync(`${root}${c}.json`,{force:true});}catch{}
clearRegistry();
await register();
const rs=registryStats();
assert.equal(rs.valid,true);
assert.ok(rs.total>=40);
for(const name of ['jvelha','jogada','jogopp','forcax','forcajogar','anagrama','enigma','matematica','quiz','quizresposta','memoria','memoriacarta','campominado','minajogar','quemsoueu','quemsoueuresposta','pet','adotapet','petacao','rankjogos','conquistas','temporada','torneio','entorneio','iniciartorneio','dados','moeda','chance','escolher','sorteio','voceprefere','compatibilidade']) assert.ok(getCommand(name),`missing ${name}`);
const G='test-expansion', U='u@test';
const g=await game.createGame({groupId:G,gameType:'test',creatorId:U,maxPlayers:2,state:{x:1}});
assert.equal(game.getGame(g.gameId).groupId,G);
await game.joinGame(g.gameId,'p@test',G); await game.startGame(g.gameId,G,U); await game.finishGame(g.gameId,G,{status:'FINISHED',winnerId:U});
await stats.recordResult({groupId:G,userId:U,gameType:'test',win:true,score:100,xp:50});
assert.equal(stats.getStats(G,U).wins,1);
const pet=await pets.adopt(G,U,'Teste'); assert.equal(pet.name,'Teste');
assert.equal(pets.list(G,U).length,1);
for(const c of collections) try{fs.rmSync(`${root}${c}.json`,{force:true});}catch{}
console.log(`COMPLETE EXPANSION OK — ${rs.total} comandos, ${rs.aliases} aliases`);
