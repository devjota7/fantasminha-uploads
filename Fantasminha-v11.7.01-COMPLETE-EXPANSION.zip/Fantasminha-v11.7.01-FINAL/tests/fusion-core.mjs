import assert from 'node:assert/strict';
import { registerCommand, getCommand, listCommands, clearRegistry } from '../src/core/registry.js';
import { withRetry } from '../src/core/retry.js';
import { analyzeScam } from '../src/services/antiScam.js';
import { resolveIntent } from '../src/services/aiAgent.js';
import { enrichMessageContext } from '../src/core/messageContext.js';

clearRegistry();
registerCommand({name:'fusion-test',category:'test',handler:async()=>{}});
assert.equal(!!getCommand('fusion-test'), true);
assert.equal(listCommands().some(x=>x.name==='fusion-test'), true);

let attempts=0;
const result=await withRetry(async()=>{ attempts++; if(attempts<3) throw new Error('temporary'); return 42; }, {retries:3,baseDelayMs:1});
assert.equal(result,42);
assert.equal(attempts,3);

assert.equal(analyzeScam('verify your account and send your OTP').detected,true);
assert.equal(resolveIntent('mostre meu status',new Set(['status']))?.command,'status');

const ctx={from:'x@g.us',sendMessage:async()=>({}),reply:async()=>{}};
enrichMessageContext(ctx);
assert.equal(typeof ctx.send.text,'function');
assert.equal(typeof ctx.retry,'function');

clearRegistry();
console.log('fusion-core: OK');
