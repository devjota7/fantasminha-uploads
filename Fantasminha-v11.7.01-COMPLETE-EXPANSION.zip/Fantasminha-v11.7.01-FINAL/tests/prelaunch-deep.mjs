import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
const errors = [];
const files = [];
function walk(dir) {
  for (const ent of fs.readdirSync(dir, { withFileTypes: true })) {
    if (['node_modules','.git','data/auth'].includes(ent.name)) continue;
    const p = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(p);
    else if (/\.(?:js|mjs|cjs)$/.test(ent.name)) files.push(p);
  }
}
walk(root);

// 1) Syntax + executable script inventory.
for (const f of files) {
  try { execFileSync(process.execPath, ['--check', f], { stdio: 'pipe' }); }
  catch (e) { errors.push(`syntax: ${path.relative(root,f)}`); }
}

// 2) Relative import targets must exist.
const importRe = /(?:import\s+(?:[^'";]+?\s+from\s+)?|export\s+[^'";]+?\s+from\s+|import\s*\()(['"])(\.\.?\/[^'"\n]+)\1/g;
for (const f of files) {
  const text = fs.readFileSync(f,'utf8');
  const scanText = text.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  for (const m of scanText.matchAll(importRe)) {
    const line = text.slice(0, m.index).split('\n').pop() || '';
    if (/^\s*\//.test(line)) continue;
    let spec = m[2];
    if (/\.(?:js|mjs|cjs)$/.test(spec) === false) spec += '.js';
    const target = path.resolve(path.dirname(f), spec);
    if (!fs.existsSync(target)) errors.push(`missing-import: ${path.relative(root,f)} -> ${spec}`);
  }
}

// 3) package dependency declarations and Node built-ins.
const pkg = JSON.parse(fs.readFileSync('package.json','utf8'));
const declared = new Set([...Object.keys(pkg.dependencies||{}), ...Object.keys(pkg.devDependencies||{})]);
const bareRe = /(?:from\s+|import\s*\(\s*|require\(\s*)['"]([^'"./][^'"\n]*)['"]/g;
const builtin = new Set(['assert','child_process','readline','readline/promises','crypto','events','fs','http','https','module','net','os','path','perf_hooks','process','stream','string_decoder','timers','url','util','worker_threads','zlib','node:assert','node:child_process','node:crypto','node:events','node:fs','node:http','node:https','node:module','node:net','node:os','node:path','node:perf_hooks','node:process','node:stream','node:string_decoder','node:timers','node:url','node:util','node:worker_threads','node:zlib']);
for (const f of files) {
  const text = fs.readFileSync(f,'utf8');
  for (const m of text.matchAll(bareRe)) {
    const top = m[1].startsWith('@') ? m[1].split('/').slice(0,2).join('/') : m[1].split('/')[0];
    if (!builtin.has(top) && !builtin.has(m[1]) && !m[1].startsWith('node:') && !declared.has(top)) errors.push(`undeclared-dep: ${path.relative(root,f)} -> ${top}`);
  }
}

// 4) Dangerous execution sinks: report only unexpected dynamic use.
const allow = new Set([
  'dados/src/.scripts/config.js',
  'dados/src/.scripts/start.js',
  'dados/src/connect.js',
  'dados/src/funcs/private/ia.js',
  'dados/src/index.js:exec-owner-shell',
  'dados/src/index.js:eval-owner-only',
  'dados/src/index.js:exec-ffmpeg-fixed-effects',
  'dados/src/index.js:execsync-disk-info',
  'dados/src/utils/systemMonitor.js:execsync-df',
  'dados/src/utils/autoRestarter.js:exec-fixed-temp-cleanup',
  'dados/src/utils/autoRestarter.js:spawn-restart'
]);
for (const f of files) {
  const text = fs.readFileSync(f,'utf8');
  if (/\b(?:eval|exec|execSync|spawn|spawnSync|fork|Function)\s*\(/.test(text)) {
    const rel = path.relative(root,f);
    if (!rel.startsWith('tests/')) {
      // Static review flag, not an automatic vulnerability verdict.
      if (!allow.has(rel) && !['dados/src/index.js','dados/src/utils/systemMonitor.js','dados/src/utils/autoRestarter.js'].includes(rel)) {
        errors.push(`unexpected-exec-sink: ${rel}`);
      }
    }
  }
}

// 5) Required package metadata and security-sensitive defaults.
for (const key of ['@hapi/boom','axios','baileys','cheerio','fluent-ffmpeg','form-data','linkedom','node-cache','node-cron','node-webpmux','pino','qrcode-terminal','sharp','@img/sharp-wasm32']) {
  if (!declared.has(key)) errors.push(`missing-dependency: ${key}`);
}
if (!fs.existsSync('.env.example')) errors.push('missing:.env.example');
if (!fs.existsSync('scripts/install.sh')) errors.push('missing:scripts/install.sh');
if (!fs.existsSync('scripts/install-termux.sh')) errors.push('missing:scripts/install-termux.sh');

if (errors.length) {
  console.error('PRELAUNCH DEEP FAIL');
  for (const e of errors) console.error(' -',e);
  process.exit(1);
}
console.log(`PRELAUNCH DEEP OK — ${files.length} JS/MJS/CJS files; imports, dependencies, sinks and release prerequisites checked`);
