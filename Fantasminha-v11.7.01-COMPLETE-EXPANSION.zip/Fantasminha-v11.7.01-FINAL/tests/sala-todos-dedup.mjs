import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getRoom, setRoom, removeRoom } from '../src/services/groupRooms.js';
import { mentionAll } from '../src/services/mentionManager.js';
import { isDuplicateMessage } from '../src/middleware/messageDedup.js';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { getCommand } from '../src/core/registry.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const group='test-room-group@g.us';
removeRoom(group);
assert.equal(getRoom(group), null);
setRoom(group,'TESTES','5511999999999@s.whatsapp.net');
assert.equal(getRoom(group).code,'TESTES');
setRoom(group,'WXYZ','5511999999999@s.whatsapp.net');
assert.equal(getRoom(group).code,'WXYZ');
assert.equal(removeRoom(group),true);
assert.equal(removeRoom(group),false);

const ctx={
  isGroup:true, from:group, botJid:'bot@s.whatsapp.net',
  groupParticipantObjects:[{id:'1@s.whatsapp.net'},{id:'2@s.whatsapp.net'},{id:'1@s.whatsapp.net'},{id:'bot@s.whatsapp.net'}],
  getGroupMetadata:async()=>({participants:[{id:'1@s.whatsapp.net'},{id:'2@s.whatsapp.net'},{id:'bot@s.whatsapp.net'}]})
};
const payload=await mentionAll(ctx,'OIEEE',{excludeBot:true});
assert.equal(payload.text,'OIEEE');
assert.deepEqual(payload.mentions,['1@s.whatsapp.net','2@s.whatsapp.net']);

const msg={message:{conversation:'×t'},key:{remoteJid:group,id:'DEDUP-1',participant:'1@s.whatsapp.net'}};
assert.equal(isDuplicateMessage({message:msg}),false);
assert.equal(isDuplicateMessage({message:msg}),true);

await bootstrapV2();
assert.equal(getCommand('todos'), getCommand('t'));
let sent=[];
const handler=getCommand('todos').handler;
const base={isGroup:true,from:group,sender:'admin@s.whatsapp.net',isGroupAdmin:true,isOwner:false,groupParticipantObjects:[{id:'1@s.whatsapp.net'},{id:'2@s.whatsapp.net'},{id:'bot@s.whatsapp.net'}],botJid:'bot@s.whatsapp.net',getGroupMetadata:async()=>({participants:[{id:'1@s.whatsapp.net'},{id:'2@s.whatsapp.net'},{id:'bot@s.whatsapp.net'}]}),reply:async(t,o)=>{sent.push({t,o});}};
await handler({...base,q:'',quotedText:'OIEEE',command:'t'});
assert.equal(sent.at(-1).t,'OIEEE');
sent=[]; await handler({...base,q:'BOM DIA',quotedText:'OIEEE',command:'todos'}); assert.equal(sent.at(-1).t,'BOM DIA');
sent=[]; await handler({...base,q:'',quotedText:'',command:'todos'}); assert.equal(sent.at(-1).t.includes('MARCAÇÃO GLOBAL'),true);
console.log('SALA/TODOS/DEDUP OK');
