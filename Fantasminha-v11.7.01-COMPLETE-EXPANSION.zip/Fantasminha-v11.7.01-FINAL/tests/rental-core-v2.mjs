import assert from 'node:assert/strict';
import crypto from 'node:crypto';
const format = raw => {
 const clean=String(raw).trim().toUpperCase().replace(/[^A-Z0-9]/g,'').replace(/^FANT/,'');
 return `FANT-${clean.slice(-24).padStart(24,'0').match(/.{1,4}/g).join('-')}`;
};
const set=new Set();
for(let i=0;i<100;i++){const c=format(crypto.randomBytes(18).toString('base64url'));assert.match(c,/^FANT-(?:[A-Z0-9]{4}-){5}[A-Z0-9]{4}$/);set.add(c)}
assert.equal(set.size,100); console.log('Rental Core V2: PASS');
