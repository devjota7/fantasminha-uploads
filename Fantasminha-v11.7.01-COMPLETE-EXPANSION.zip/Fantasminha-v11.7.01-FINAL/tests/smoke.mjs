import { bootstrapV2 } from '../src/core/bootstrap.js';
import { getCommand, registryStats, validateRegistry } from '../src/core/registry.js';
import { checkDatabase } from '../src/database/store.js';

const stats = await bootstrapV2();
if (!stats.valid) throw new Error('registry inválido');
if (stats.enabled < 50) throw new Error(`poucos comandos: ${stats.enabled}`);
if (!getCommand('saldo') || !getCommand('daily')) throw new Error('economia ausente');
if (!checkDatabase()) throw new Error('banco indisponível');
const validation = validateRegistry();
if (!validation.ok) throw new Error(validation.errors.join('\n'));
console.log(`SMOKE OK — ${stats.enabled} comandos, ${stats.aliases} aliases, ${stats.categories} categorias`);
process.exit(0);
