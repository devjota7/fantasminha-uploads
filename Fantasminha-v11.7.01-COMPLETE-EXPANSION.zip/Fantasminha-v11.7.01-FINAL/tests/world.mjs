import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { register } from '../src/plugins/clans/index.js';
import { getCommand, validateRegistry } from '../src/core/registry.js';
import { listWars } from '../src/services/wars.js';
import { getGroupClan } from '../src/services/groupClans.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dbDir = path.join(root, 'data', 'db');
const snapshot = fs.mkdtempSync(path.join(os.tmpdir(), 'fantasminha-world-'));
fs.cpSync(dbDir, snapshot, { recursive: true });

try {
  for (const f of ['group_clans.json','global_clans.json','wars.json','users.json','economy_ledger.json']) {
    try { fs.unlinkSync(path.join(dbDir, f)); } catch {}
  }
  await register();
  const reg = validateRegistry();
  if (!reg.ok) throw new Error(reg.errors.join('\n'));
  const ctx = (o={}) => ({ sender:'u', pushname:'Tester', isGroup:false, isGroupAdmin:false, isOwner:false, from:'', q:'', reply:async()=>{}, sendMessage:async()=>{}, ...o });
  await getCommand('clacriar').handler(ctx({sender:'u1',q:'Fantasmas'}));
  for (const [id,name,user,count] of [['gA','COSMOS 宇','u1',10],['gB','VIDRADOS ㊦','u2',12]]) {
    await getCommand('clagrupo').handler(ctx({sender:user,isGroup:true,isGroupAdmin:true,from:id,groupName:name,participantCount:count}));
    await getCommand('clagrupoguerra').handler(ctx({sender:user,isGroup:true,isGroupAdmin:true,from:id,groupName:name,participantCount:count,q:'on'}));
  }
  if (getGroupClan('gB').name !== 'VIDRADOS ㊦') throw new Error('nome do Clã do Grupo corrompido');
  await getCommand('guerragrupo').handler(ctx({sender:'u1',isGroup:true,isGroupAdmin:true,from:'gA',groupName:'COSMOS 宇',participantCount:10,q:'desafiar VIDRADOS 2'}));
  let w=listWars('group')[0];
  if (!w || w.durationDays !== 2 || w.status !== 'pending') throw new Error('desafio inválido');
  await getCommand('guerragrupo').handler(ctx({sender:'u2',isGroup:true,isGroupAdmin:true,from:'gB',groupName:'VIDRADOS ㊦',participantCount:12,q:'aceitar'}));
  await getCommand('guerragrupoentrar').handler(ctx({sender:'u3',isGroup:true,from:'gA',groupName:'COSMOS 宇',participantCount:10}));
  await getCommand('guerragrupoentrar').handler(ctx({sender:'u4',isGroup:true,from:'gB',groupName:'VIDRADOS ㊦',participantCount:12}));
  w=listWars('group')[0];
  if (w.status !== 'preparation' || w.participants.attacker.length !== 1 || w.participants.defender.length !== 1) throw new Error('participação inválida');
  console.log(`WORLD TEST OK — ${w.id} | ${w.durationDays} dias | preparação | 1x1`);
} finally {
  fs.rmSync(dbDir, { recursive: true, force: true });
  fs.cpSync(snapshot, dbDir, { recursive: true });
  fs.rmSync(snapshot, { recursive: true, force: true });
}
