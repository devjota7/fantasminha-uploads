import assert from 'node:assert/strict';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { getCommand, registryStats, validateRegistry, registerCommand, unregisterCommand } from '../src/core/registry.js';
import { listJobs } from '../src/platform/jobs/index.js';

const stats = await bootstrapV2();
assert.equal(stats.valid, true);
assert.ok(stats.enabled >= 300, `registry pequeno: ${stats.enabled}`);
assert.ok(getCommand('saldo'));
assert.ok(getCommand('fantasminhaid'));
assert.ok(getCommand('integridade'));
assert.ok(listJobs().length >= 2);
assert.equal(validateRegistry().ok, true);

registerCommand({ name:'__reform_test__', aliases:['__reform_alias__'], handler:async()=>{} });
registerCommand({ name:'__reform_test__', aliases:['__reform_alias_2__'], handler:async()=>{} });
assert.ok(getCommand('__reform_alias_2__'));
assert.equal(getCommand('__reform_alias__'), null);
unregisterCommand('__reform_test__');
assert.equal(getCommand('__reform_test__'), null);
console.log(`REFORM OK — ${stats.enabled} comandos, ${stats.aliases} aliases, ${listJobs().length} jobs`);
process.exit(0);
