import assert from 'node:assert/strict';
import menuDono from '../dados/src/menus/menudono.js';
import { registerCommand } from '../src/core/registry.js';

for (const name of ['brat', 'renomearpet', 'contratarnpc', 'migracoes']) {
  registerCommand({
    name,
    category: 'dono',
    description: `teste ${name}`,
    handler: async () => {}
  });
}

const m = await menuDono('×');

// O menu do dono da v11 é gerado pelo catálogo/registry, não pelas seções fixas da v10.
assert.match(m, /👑 DONO/);
assert.match(m, /comandos ativos nesta categoria/i);
for (const command of ['brat', 'renomearpet', 'contratarnpc', 'migracoes']) {
  assert.match(m, new RegExp(`×${command}\\b`), `×${command} não apareceu no menu`);
}
assert.doesNotMatch(m, /PODER DO DONO|PLATAFORMA & ARQUITETURA/);

console.log('MENU DONO ATUAL OK — catálogo dinâmico v11');
