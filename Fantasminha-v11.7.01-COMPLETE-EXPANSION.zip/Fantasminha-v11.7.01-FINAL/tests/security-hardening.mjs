import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { upsertUser, getUser, updateCollection } from '../src/database/store.js';
import * as economy from '../src/services/economy.js';
import * as market from '../src/services/market.js';

const root = path.dirname(fileURLToPath(import.meta.url));
const ids = [`SEC-${Date.now()}-A`, `SEC-${Date.now()}-B`, `SEC-${Date.now()}-C`];
const [a,b,c] = ids;

async function seed(id, wallet=0, inventory={}) {
  await upsertUser(id, { name:id, economy:{wallet,bank:0,lastDaily:0,lastWeekly:0,lastWork:0,inventory} });
}

await seed(a, 100, { vela: 1 });
await seed(b, 0, {});
await seed(c, 0, {});

// Negative quantities must never create inventory.
await assert.rejects(() => market.createOffer(a, 'vela', 10, -5), /quantidade deve ser positiva/i);
assert.equal(getUser(a).economy.inventory.vela, 1);

// Concurrent transfers must serialize: only one 80 GC transfer can succeed from a 100 GC wallet.
const transferResults = await Promise.allSettled([
  economy.transfer(a, b, 80),
  economy.transfer(a, c, 80)
]);
assert.equal(transferResults.filter(x => x.status === 'fulfilled').length, 1);
assert.equal(getUser(a).economy.wallet, 20);
assert.equal((getUser(b).economy.wallet || 0) + (getUser(c).economy.wallet || 0), 80);

// Daily/work/weekly cooldowns must be atomic under concurrency.
await seed(a, 0, {});
const daily = await Promise.allSettled([economy.daily(a), economy.daily(a)]);
assert.equal(daily.filter(x => x.status === 'fulfilled').length, 1);
assert.equal(getUser(a).economy.wallet, 1000);

await seed(b, 0, {});
const work = await Promise.allSettled([economy.work(b), economy.work(b)]);
assert.equal(work.filter(x => x.status === 'fulfilled').length, 1);
assert.ok(getUser(b).economy.wallet >= 200 && getUser(b).economy.wallet <= 800);

// Marketplace sale is reserved before payment, so concurrent buyers cannot both buy one offer.
await seed(a, 0, { cristal: 1 });
await seed(b, 100, {});
await seed(c, 100, {});
const offerId = await market.createOffer(a, 'cristal', 100, 1);
const buys = await Promise.allSettled([market.buyOffer(b, offerId), market.buyOffer(c, offerId)]);
assert.equal(buys.filter(x => x.status === 'fulfilled').length, 1);
const buyersWithItem = [b,c].filter(id => (getUser(id).economy.inventory.cristal || 0) === 1);
assert.equal(buyersWithItem.length, 1);
assert.equal(getUser(a).economy.wallet, 100);

// Source must not contain a hardcoded GitHub token.
const updater = fs.readFileSync(path.join(root, '..', 'dados/src/funcs/utils/update-verify.js'), 'utf8');
assert.ok(!/ghp_[A-Za-z0-9_]+/.test(updater));
assert.match(updater, /process\.env\.GITHUB_TOKEN/);

console.log('SECURITY HARDENING: PASS');
