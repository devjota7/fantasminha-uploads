import assert from 'node:assert/strict';
import { clearRegistry, getCommand, listCommands } from '../src/core/registry.js';
import { normalizeSocialUsername, parseInstagramProfileHtml } from '../src/services/social/instagramService.js';
import { normalizeTikTokUsername, parseTikTokProfileHtml } from '../src/services/social/tiktokService.js';
import { formatSocialProfile, usageMessage } from '../src/services/social/socialProfileFormatter.js';
import { isDuplicateMessage } from '../src/middleware/messageDedup.js';
import { registerPerfilInstagram } from '../src/plugins/social/perfilInsta.js';
import { registerPerfilTikTok } from '../src/plugins/social/perfilTikTok.js';

assert.equal(normalizeSocialUsername('@Cristiano'), 'Cristiano');
assert.equal(normalizeSocialUsername('https://www.instagram.com/cristiano/'), 'cristiano');
assert.equal(normalizeSocialUsername('×perfilinsta cristiano'), '');
assert.equal(normalizeTikTokUsername('@mrbeast'), 'mrbeast');
assert.equal(normalizeTikTokUsername('https://www.tiktok.com/@mrbeast'), 'mrbeast');
assert.equal(normalizeTikTokUsername('https://example.com/mrbeast'), '');

const instaHtml = `<meta property="og:title" content="Cristiano Ronaldo (@cristiano)"><meta property="og:description" content="600M Followers, 600 Following, 3 Posts"><meta property="og:image" content="https://example.test/avatar.jpg"><script id="__NEXT_DATA__" type="application/json">{"user":{"full_name":"Cristiano Ronaldo","biography":"Public bio","is_verified":true,"is_private":false,"edge_followed_by":{"count":600000000},"edge_follow":{"count":600},"edge_owner_to_timeline_media":{"count":3,"edges":[{"node":{"shortcode":"ABC","display_url":"https://example.test/post.jpg","taken_at_timestamp":1700000000,"caption":"Hello"}}]}}}</script>`;
const insta = parseInstagramProfileHtml(instaHtml, 'cristiano');
assert.equal(insta.name, 'Cristiano Ronaldo');
assert.equal(insta.bio, 'Public bio');
assert.equal(insta.followers, 600000000);
assert.equal(insta.posts, 3);
assert.equal(insta.verified, true);
assert.equal(insta.recent.url, 'https://www.instagram.com/p/ABC/');

const ttHtml = `<meta property="og:title" content="MrBeast"><meta property="og:image" content="https://example.test/avatar.jpg"><script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">{"userInfo":{"user":{"nickname":"MrBeast","uniqueId":"mrbeast","signature":"Bio","verified":true,"avatarLarger":"https://example.test/avatar.jpg"},"stats":{"followerCount":1000,"followingCount":10,"heartCount":2000,"videoCount":30}}}</script>`;
const tt = parseTikTokProfileHtml(ttHtml, 'mrbeast');
assert.equal(tt.name, 'MrBeast');
assert.equal(tt.username, 'mrbeast');
assert.equal(tt.followers, 1000);
assert.equal(tt.likes, 2000);
assert.equal(tt.videos, 30);
assert.equal(tt.verified, true);

const fake = { platform:'instagram', username:'cristiano', name:'Cristiano Ronaldo', bio:'Bio pública', followers:1000, following:20, posts:3, verified:true, private:false, profileUrl:'https://www.instagram.com/cristiano/' };
const formatted = formatSocialProfile(fake, '×perfilinsta');
assert.match(formatted, /×perfilinsta cristiano/);
assert.doesNotMatch(formatted, /@cristiano/);
assert.doesNotMatch(formatted, /551/);
assert.match(usageMessage('instagram'), /×perfilinsta usuario/);

clearRegistry();

const duplicateCtx = { from:'123@g.us', sender:'5511999990002@s.whatsapp.net', message:{ key:{ remoteJid:'123@g.us', id:'SOCIAL-DEDUP-1', participant:'5511999990002@s.whatsapp.net' } } };
assert.equal(isDuplicateMessage(duplicateCtx), false);
assert.equal(isDuplicateMessage(duplicateCtx), true);

await registerPerfilInstagram();
await registerPerfilTikTok();
assert.ok(getCommand('perfilinsta'));
assert.ok(getCommand('perfiltiktok'));
assert.equal(listCommands({category:'comunidade'}).filter(c=>['perfilinsta','perfiltiktok'].includes(c.name)).length,2);
console.log('SOCIAL PROFILE OK — registry, normalização, parser, formatter e ausência de menções WhatsApp.');
