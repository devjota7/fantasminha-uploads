import assert from 'node:assert/strict';
import { registerCommand, runCommand, clearRegistry } from '../src/core/registry.js';
let calls = 0;
clearRegistry();
registerCommand({ name: '__race_test__', cooldown: 60, handler: async () => { calls++; await new Promise(r => setTimeout(r, 50)); } });
const results = await Promise.allSettled([
  runCommand('__race_test__', { sender: 'race-user' }),
  runCommand('__race_test__', { sender: 'race-user' })
]);
assert.equal(calls, 1);
assert.equal(results.filter(x => x.status === 'fulfilled').length, 1);
assert.equal(results.filter(x => x.status === 'rejected').length, 1);
console.log('REGISTRY CONCURRENCY OK');
