import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { listCommands, runCommand } from '../src/core/registry.js';
import { Role } from '../src/core/permissions.js';
import { configuredOwner } from '../src/core/permissions.js';
import { writeCollection, readCollection } from '../src/database/store.js';
import * as economy from '../src/services/economy.js';

globalThis.__fantasminhaOwnerIds = ['5511999999999'];
await bootstrapV2();

// Owner identity must not cross-contaminate domains or accept forged suffixes.
assert.equal(configuredOwner('5511999999999@s.whatsapp.net'), true);
assert.equal(configuredOwner('5511999999999:1@s.whatsapp.net'), true);
assert.equal(configuredOwner('+5511999999999@s.whatsapp.net'), true);
assert.equal(configuredOwner('5511999999999@lid'), false);
assert.equal(configuredOwner('5511999999999@s.whatsapp.net.evil'), false);

const commands = listCommands({ includeHidden:true });
assert.ok(commands.length >= 500);
const user={sender:'audit-user@s.whatsapp.net',from:'audit@g.us',isGroup:true,isOwner:false,isBotAdmin:false,isGroupAdmin:false,isVip:false,isPremium:false,args:[],q:'',reply:async()=>({})};
const admin={...user,sender:'audit-admin@s.whatsapp.net',isGroupAdmin:true};
for(const c of commands){
  if(c.permission >= Role.GROUP_ADMIN){
    await assert.rejects(()=>runCommand(c.name,user), /cargo suficiente|Somente o dono|permissão/i, `user bypass: ${c.name}`);
  }
  if(c.permission >= Role.OWNER){
    await assert.rejects(()=>runCommand(c.name,admin), /cargo suficiente|Somente o dono|permissão/i, `admin bypass: ${c.name}`);
  }
  if(c.groupOnly) await assert.rejects(()=>runCommand(c.name,{...user,isGroup:false,from:'private'}), /grupos/i, `groupOnly bypass: ${c.name}`);
  if(c.privateOnly) await assert.rejects(()=>runCommand(c.name,user), /privado/i, `privateOnly bypass: ${c.name}`);
}

// Corrupt JSON must degrade to fallback without throwing or deleting unrelated data.
const probe='__audit_corrupt';
const f=path.join(process.cwd(),'data','db',`${probe}.json`);
fs.mkdirSync(path.dirname(f),{recursive:true});
fs.writeFileSync(f,'{"broken":');
assert.deepEqual(readCollection(probe,{ok:true}),{ok:true});
writeCollection(probe,{ok:true,afterRecovery:true});
assert.deepEqual(readCollection(probe,{}),{ok:true,afterRecovery:true});

// 50 concurrent transfers must serialize atomically.
const a='audit-race-a@s.whatsapp.net', b='audit-race-b@s.whatsapp.net';
writeCollection('users',{byId:{[a]:{id:a,economy:{wallet:5000,bank:0,inventory:{}}},[b]:{id:b,economy:{wallet:0,bank:0,inventory:{}}}}});
const tx=await Promise.allSettled(Array.from({length:50},()=>economy.transfer(a,b,100)));
assert.equal(tx.filter(x=>x.status==='fulfilled').length,50);
assert.equal(readCollection('users',{byId:{}}).byId[a].economy.wallet,0);
assert.equal(readCollection('users',{byId:{}}).byId[b].economy.wallet,5000);

// Expansion smoke must terminate instead of leaking a referenced timer.
const child=spawnSync(process.execPath,['tests/expansion.mjs'],{encoding:'utf8',timeout:5000});
assert.equal(child.error,undefined,`expansion child error: ${child.error?.message}`);
assert.equal(child.status,0,`expansion exit=${child.status}\n${child.stdout}\n${child.stderr}`);

console.log(`EXTREME AUDIT OK — ${commands.length} comandos, permissões, identidade, corrupção, concorrência e encerramento`);
