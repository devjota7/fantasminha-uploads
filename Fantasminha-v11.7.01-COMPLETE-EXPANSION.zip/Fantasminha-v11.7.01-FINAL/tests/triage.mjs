import fs from 'fs';
import path from 'path';
import os from 'os';
import { fileURLToPath } from 'url';
import { bootstrapV2 } from '../src/core/bootstrap.js';
import { getCommand, validateRegistry } from '../src/core/registry.js';
import { saveSettings, createTriage, startTriage, validateAndSaveAnswer, judgeTriage, getTriage, rejectionHistory, STATES } from '../src/services/triage.js';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dbDir = path.join(root, 'data', 'db');
const snap = fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-triage-'));
fs.cpSync(dbDir,snap,{recursive:true});
try {
  for (const f of ['groups.json','triage.json','triage_history.json','triage_blacklist.json','triage_audit.json']) try { fs.unlinkSync(path.join(dbDir,f)); } catch {}
  await bootstrapV2();
  if (!getCommand('triagem') || !getCommand('triagemhelp') || !getCommand('setperguntas') || !getCommand('aprovar') || !getCommand('conselho')) throw new Error('comandos de triagem ausentes');
  const vr=validateRegistry(); if(!vr.ok) throw new Error(vr.errors.join('\n'));
  await saveSettings('g1',{enabled:true,questions:[{id:'q1',type:'text',required:true,question:'Nome?'},{id:'q2',type:'number',required:true,question:'Idade?',min:1,max:120}]});
  const c=await createTriage('g1','u1@s.whatsapp.net'); if(!c.ok) throw new Error('create falhou');
  const st=await startTriage(c.code); if(!st.ok) throw new Error('start falhou');
  let r=await validateAndSaveAnswer(c.code,'Teste'); if(!r.ok) throw new Error('q1 falhou');
  r=await validateAndSaveAnswer(c.code,'15'); if(!r.ok || !r.finished) throw new Error('q2/finalização falhou');
  const j=await judgeTriage(c.code,{id:'admin@s.whatsapp.net',name:'Admin'},'reject','Motivo de teste','local');
  if(!j.ok || j.triage.state!==STATES.REJECTED) throw new Error('reprovação falhou');
  const h=await rejectionHistory('u1@s.whatsapp.net'); if(h.length!==1) throw new Error('histórico falhou');
  console.log(`TRIAGE TEST OK — ${c.code} | ${j.triage.state} | histórico ${h.length}`);
process.exit(0);
} finally { fs.rmSync(dbDir,{recursive:true,force:true}); fs.cpSync(snap,dbDir,{recursive:true}); fs.rmSync(snap,{recursive:true,force:true}); }
