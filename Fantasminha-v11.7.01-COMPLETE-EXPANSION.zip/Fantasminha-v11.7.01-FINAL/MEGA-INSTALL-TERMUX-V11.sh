#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail
ZIP="${1:-$HOME/Fantasminha-v11.0.0-PRODUCTION.zip}"
[ -f "$ZIP" ] || { echo "❌ ZIP não encontrado: $ZIP"; echo "Coloque o ZIP em: $HOME/Fantasminha-v11.0.0-PRODUCTION.zip"; exit 1; }
command -v unzip >/dev/null 2>&1 || pkg install -y unzip
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
unzip -q "$ZIP" -d "$TMP/release"
PAYLOAD="$TMP/release"
shopt -s nullglob dotglob
entries=("$PAYLOAD"/*)
if [ "${#entries[@]}" -eq 1 ] && [ -d "${entries[0]}" ] && [ -f "${entries[0]}/package.json" ]; then PAYLOAD="${entries[0]}"; fi
[ -f "$PAYLOAD/scripts/install-termux.sh" ] || { echo '❌ Instalador da release não encontrado.'; exit 1; }
bash "$PAYLOAD/scripts/install-termux.sh" "$ZIP"
