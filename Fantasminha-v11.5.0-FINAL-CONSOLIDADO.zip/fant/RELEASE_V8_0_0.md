# 👻 Fantasminha 8.0.0 — Eternal Dominion

## Visão
Grande expansão da arquitetura de mundo persistente, com foco em Clãs Globais e no Campeonato Global do Além.

## Campeonato Global do Além
- Temporadas de 30 dias.
- 15 dias de preparação.
- 15 dias de guerra.
- Ranking global por pontuação.
- Ligas: Alma, Espírito, Abismo e Soberana.
- Ranking individual de guerreiros.
- Boss Global: Rei do Abismo.
- Copa/Playoffs dos 8 melhores.
- Histórico de temporadas.
- Recordes.
- Eras do mundo.
- Rotação automática de temporada no scheduler.

## Clã / Dominion preservado
A versão mantém e integra os sistemas existentes de Clã Global, Clã de Grupo, sede, construções, territórios, tesouro, cargos, diplomacia, espionagem, mascote, missões, crônicas, legado e Hall da Fama.

## Arquitetura
- `src/services/clanChampionship.js`: domínio/persistência do campeonato.
- `src/plugins/championship/index.js`: camada de comandos WhatsApp.
- `src/services/clanWorld.js`: domínio do Clan Dominion.
- `src/plugins/clans/index.js`: comandos de Clã existentes.
- Persistência isolada por coleção JSON para compatibilidade com Termux.
- Scheduler independente do socket.

## Comandos principais
- `×campeonato`
- `×campeonatostatus`
- `×campeonatoparticipar`
- `×campeonatorank`
- `×ataquecampeonato <cla> [normal|forte|especial]`
- `×guerracontribuir [1-20]`
- `×bossalem`
- `×bossstatus`
- `×copa`
- `×guerreiros`
- `×historicotemporadas`
- `×recordesalem`
- `×eraalem`
- `×mvpglobal`
- `×ligaglobal`
- `×campanhas`

## Compatibilidade
A camada foi adicionada sem remover os módulos anteriores. O banco de campeonato é criado sob demanda.
