# 👻 Fantasminha 11.4.0 — Triagem Improved

## O que foi melhorado

- 🎨 Novo padrão visual para entrada, perguntas, painel, fila, conselho, aprovação, reprovação e blacklist.
- 🧭 Assistente de criação mais claro, com categorias e confirmação visual.
- 🔘 Perguntas do tipo escolha agora permitem cadastrar opções no próprio assistente usando `|`.
- ✏️ Edição de perguntas preserva o fluxo e permite configurar novamente o tipo/opções.
- 🔢 Validação de números respeita limites mínimo/máximo quando configurados.
- 📅 Campos opcionais não são rejeitados quando ficam vazios.
- 🔘 Perguntas de escolha aceitam tanto o texto da opção quanto seu número.
- ⏱️ O prazo de julgamento agora respeita a configuração do grupo, em vez de cair sempre no padrão global.
- 🔗 Lembretes usam o JID do bot salvo na triagem, evitando links apontando para o dono quando o bot tem outro número.
- 🪪 Cada membro continua recebendo código exclusivo e sessão individual.
- 🛡️ Fluxo de blacklist e auditoria foi preservado.
- 🤖 IA de imagem continua sendo auxiliar, sem tratar análise visual como prova definitiva.

## Validação

A suíte de produção foi executada com sucesso após as alterações:

- `npm run validate:production` — PASS
- Syntax — 228 arquivos JS/MJS
- Smoke — 511 comandos / 807 aliases / 25 categorias
- Triage — PASS
- Triage integration — PASS
- Triage image — PASS
- Platform — PASS
- Security hardening — PASS
- Menu dono — PASS

## Observação

O preflight continua avisando quando `.env`, `OWNER_NUMBER` ou `ALLOWED_GROUP_IDS` ainda não estão configurados. Isso é esperado para um pacote pré-lançamento e deve ser preenchido no ambiente do proprietário antes da conexão real com o WhatsApp.
