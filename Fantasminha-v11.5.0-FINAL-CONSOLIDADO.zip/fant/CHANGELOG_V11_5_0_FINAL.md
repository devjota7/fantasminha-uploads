# 👻 Fantasminha v11.5.0 FINAL — Triagem + Brincadeiras

## 🔥 Consolidação

Esta versão consolida em um único pacote a atualização de **Brincadeiras Expandidas v11.5.0** e a revisão da **Triagem Melhorada v11.4.0**.

## 👻 Triagem

- Designer completo e padronizado nas telas da triagem.
- Barra de progresso durante as perguntas.
- Ficha individual por participante.
- Código exclusivo e link direto para o PV.
- Perguntas text, date, number, yesno, choice e image.
- Escolhas aceitam número da opção ou texto.
- Validação de número com mínimo/máximo.
- Perguntas opcionais.
- Editor CRUD completo de perguntas.
- Reordenação e duplicação.
- Exportação/importação JSON.
- IA/OCR/comparação como recursos auxiliares para perguntas de imagem.
- Conselho com julgamento humano.
- Histórico, auditoria, fila, arquivo e blacklist.
- Prazos e lembretes respeitando a configuração do grupo.

## 🎉 Brincadeiras

- Menu de brincadeiras reorganizado.
- Jogos, desafios, frases, interações, relacionamentos e rankings.
- Central do Caos com dicas dinâmicas.
- Compatibilidade com modo Lite.

## 🔧 Correções de release

- Metadados e testes atualizados para a versão consolidada.
- Removidas sessões WhatsApp/autenticação do pacote final.
- Sintaxe e testes principais executados antes da montagem.
