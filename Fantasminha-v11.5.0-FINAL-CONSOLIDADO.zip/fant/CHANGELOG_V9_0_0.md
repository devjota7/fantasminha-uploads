# Changelog — Fantasminha v9.0.0

## 🏰 Clãs pessoais
- Reestruturado o antigo conceito de Clã Global para Clã pessoal do jogador.
- Um usuário pode criar um Clã independente do grupo do WhatsApp.
- Criação começa privada.
- Publicação custa 25.000 Ghostcoins.
- Limites: 50 membros privados e 100 públicos.
- Convites, solicitações, aprovação e vice-liderança.

## 🌐 Autorização Global
- Global deixou de ser um segundo tipo de Clã.
- É um status administrativo aplicado a um Clã público.
- Somente Clãs autorizados entram no campeonato/ranking/eventos globais.
- Autorização e revogação possuem auditoria.

## 🐾 RPG / vida social
- Aranha adicionada ao catálogo de pets.
- Renomeação de pets.
- Alimentar, brincar e treinar pets.
- Relacionamentos User × User separados de User × NPC.
- NPCs passam a registrar memórias persistentes das interações.
- Consulta de memórias de NPC.
- Empresas ganharam expansão de nível, filiais e marketing.

## ⚔️ Competição
- Guerras Globais exigem Clãs autorizados.
- Campeonato continua com 15 dias de preparação + 15 dias de guerra.
- Ranking global considera somente Clãs autorizados.
