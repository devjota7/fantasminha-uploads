# Fantasminha v11.5.0

## 🎉 Brincadeiras renovadas

- `menubn` / `menubrincadeiras` reformulado para uma experiência mais animada.
- Menu reorganizado em blocos: jogos, desafios do Além, frases, interações, relacionamentos e rankings.
- Mais comandos de jogos já existentes no catálogo foram expostos no menu.
- Adicionada seção dinâmica `CENTRAL DO CAOS` com dica aleatória a cada abertura.
- Mensagens de orientação para marcação de usuários e desafios em grupo.
- Modo Lite continua suportado, com redução de conteúdo mais pesado.
- Removidas entradas políticas/ofensivas do menu de brincadeiras; o foco passa a ser diversão e interação.
- Mantida compatibilidade com o sistema atual de `getMenuDesignWithDefaults`.

## 🔧 Qualidade

- Versão do pacote atualizada para `11.5.0`.
- Renderização do menu validada.
- Comandos exibidos no menu conferidos contra o catálogo atual.
- Sintaxe do projeto validada após a alteração.
