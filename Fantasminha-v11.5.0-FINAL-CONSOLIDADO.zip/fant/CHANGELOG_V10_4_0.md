# Fantasminha v10.4.0 — MULTI-BASE FUSION

Integração arquitetural inspirada nas bases WhatsAppBotMultiDevice, WhatsApp AI Bot e Python WhatsApp Bot, sem copiar implementações externas.

## Adicionado
- Control Center HTTP local opcional com API JSON e atualização automática.
- Event-ready architecture via Event Bus existente.
- Runtime Config com chaves seguras e validação.
- Resource Manager para streams/recursos temporários.
- Identity JID/LID normalization helpers.
- Message Delivery Engine sobre a fila resiliente existente.
- Knowledge Engine local para FAQ/contexto de IA.
- Analytics ampliado com filas e recursos.
- Comandos: analytics, controlcenter, filas, recursos, runtime, conhecimento e jobs.

## Mantido e melhorado
- Registry central.
- Message Envelope Registry.
- Retry/backoff.
- Anti-Scam.
- Incidentes.
- Custom Commands.
- Notes.
- Command Visibility.
- Scheduler, snapshots, triagem e Owner Center.

## Estratégia
Os comandos e ideias das bases externas são tratados como referência funcional. Duplicatas são fundidas e implementações incompatíveis não entram no núcleo.
