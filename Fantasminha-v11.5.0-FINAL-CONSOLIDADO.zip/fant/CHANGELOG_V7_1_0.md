# Changelog — Fantasminha 7.1.0

## 🌌 World Engine
- Mundo persistente do Além com 7 regiões e viagens.
- Energia, descanso, exploração e reputação.
- Perfil, conquistas, temporadas, eventos e ranking mundial.
- Casas, propriedades e upgrades.
- Inventário, loja e itens.
- Banco, depósitos, saques, extrato e investimentos.
- Mercado econômico fictício.
- Duelos, bosses e dungeons.
- NPCs com relações, afinidade, confiança, respeito e memórias.
- Linhagem e legado.
- Empresas 2.0: upgrades, filiais, treinamento, promoções e folha.
- Reinos: fundação, tesouro, território, alianças e ranking.
- Sistema de mistérios/investigações com pistas e resolução.

## 🔧 Arquitetura
- Novo plugin isolado: `src/plugins/worldEngine/`.
- Registro pelo bootstrap V2.
- Persistência via camada de banco existente.
- Nenhuma nova dependência nativa adicionada.
- Mantida compatibilidade com a Mega Expansão 7.0.1.
