# Fantasminha v10.5.6

## Correções
- Corrigido o conflito entre o `PREFIX` interno do Termux e o prefixo do bot.
- `PREFIX=×` do `.env` agora é respeitado mesmo quando o Termux injeta `/data/data/com.termux/files/usr`.
- Core, conexão legada e dispatcher usam o mesmo resolvedor de prefixo.
- `×ping`, `×menu` e demais comandos legados voltam a passar pelo dispatcher quando não estiverem registrados na V2.
- Atualizador `×atualizar` não cria backups adicionais e preserva `.env`, sessão e banco.
- Dependências continuam sendo instaladas/verificadas quando a release exigir.

## Operação
Após instalação limpa, o projeto deve iniciar com:

```bash
npm start
```

E a atualização pelo bot continua disponível para o dono principal com:

```text
×atualizar
```
