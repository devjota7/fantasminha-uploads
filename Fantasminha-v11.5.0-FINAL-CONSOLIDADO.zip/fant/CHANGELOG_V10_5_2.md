# 👻 Fantasminha v10.5.2 — Menu Design System

## Reforma visual

- Novo Design System centralizado em `dados/src/menus/theme.js`.
- Cabeçalho, molduras, separadores, itens e rodapés unificados.
- Menu principal redesenhado.
- Menus catalogados (Economia, Clãs, Guerras, IA, Premium, Sistema, Triagem e Comunidade) redesenhados.
- Menus tradicionais de RPG, administração, dono, downloads, jogos, VIP, membros, além, ferramentas, edição, figurinhas, logos, BN e TopCmd receberam o novo padrão visual.
- Inventário de comandos preservado; a atualização é visual/estrutural e não remove comandos.
- Paginação do catálogo reduzida para 60 comandos por página para melhorar leitura no WhatsApp.
- Fallback visual centralizado quando um menu não fornece cabeçalho customizado.

## Validação

- Todos os arquivos JavaScript de `dados/src/menus` passaram no `node --check`.
- Os 24 menus carregados pelo `dados/src/menus/index.js` foram executados em smoke test.
- Nenhum menu apresentou saída vazia ou erro durante o teste.
