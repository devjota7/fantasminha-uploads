# 👻 Fantasminha 11.5.0 — Release Ready Checklist

## Feito nesta etapa

- [x] Registry com serialização por usuário/comando para reduzir bypass de cooldown por corrida.
- [x] Allowlist de grupos via `ALLOWED_GROUP_IDS`.
- [x] Comando `×idgrupo` para descobrir o ID do grupo atual.
- [x] Shell/eval do owner desativados por padrão.
- [x] Calculadora sem `Function()`.
- [x] Limite máximo da fila de mensagens.
- [x] Preflight de produção.
- [x] Teste de allowlist.
- [x] Teste de concorrência do Registry.
- [x] README de lançamento controlado.
- [x] Artefatos de teste removidos do pacote.

## Ainda depende do ambiente do proprietário

- [ ] `npm install` no Termux.
- [ ] preencher `.env`.
- [ ] preencher `OWNER_NUMBER`.
- [ ] descobrir e preencher `ALLOWED_GROUP_IDS`.
- [ ] instalar/verificar FFmpeg.
- [ ] conectar o WhatsApp via QR/pairing.
- [ ] testar `×ping`, `×menu`, `×idgrupo`, `×saldo`.
- [ ] testar admin com bot administrador.
- [ ] testar reconexão e reinício.
- [ ] testar mídia real.
- [ ] fazer backup antes do primeiro uso.

**Importante:** não declarar o E2E WhatsApp real como validado antes desses passos.
