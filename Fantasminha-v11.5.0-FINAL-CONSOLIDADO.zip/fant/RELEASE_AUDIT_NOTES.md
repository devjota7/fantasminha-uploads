# Fantasminha 11.4.0 — Auditoria

Esta release endurece Termux/Android ARM64, preserva dados na instalação, remove referências mortas do catálogo e usa menus derivados do registry ativo.
