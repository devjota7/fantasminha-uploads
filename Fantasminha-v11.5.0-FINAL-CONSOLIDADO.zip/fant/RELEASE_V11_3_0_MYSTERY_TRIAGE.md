# Fantasminha v11.3.0 — Mystery + Triage Refinement

## Triagem
- `×triagemcriar`: fluxo guiado sem prefixo durante a configuração.
- máximo de 20 perguntas.
- categorias por número: texto, data, foto/IA, número, sim/não e escolha.
- `×triagemexcluir`: remove a configuração atual e desativa a triagem.
- `×setpergunta`: lista perguntas quando usado sem número; com número inicia edição daquela pergunta e permite trocar texto e categoria.

## Universo
- `×misterio`, `×misteriocriar`, `×misteriopista`, `×misterioparticipar`.
- `×historia` e `×historiaregistrar`.
- Registros históricos separados e persistentes.
