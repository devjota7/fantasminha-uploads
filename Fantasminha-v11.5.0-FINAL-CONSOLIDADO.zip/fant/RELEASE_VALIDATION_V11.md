# Fantasminha 11.0.0 — validação da release

## Validado automaticamente

- Sintaxe: 219 arquivos JS/MJS.
- Smoke: 481 comandos, 768 aliases, 24 categorias.
- Platform: OK.
- Reform: OK.
- Security hardening: PASS.
- Triage: OK.
- Triage integration: OK.
- Triage image: OK.
- World: OK.
- V7 core: OK.
- Mega 7.0.1: OK.
- Rental Core V2: PASS.
- Championship: OK.
- Clan expansion: OK.
- Clan personal: OK.
- Registry concurrency: OK.

## Correções desta release

- Corrigido módulo ausente `src/core/groupAccess.js`, responsável por quebrar a inicialização da V10.5.6.
- `.env.example` incluído.
- `.env` carregado antes do startup e nunca sobrescrito automaticamente.
- `WA_AUTH_METHOD=qr|pairing|prompt`.
- Pairing pode usar `OWNER_NUMBER` configurado.
- Sessão existente é detectada por `creds.json`.
- Erro 403 não apaga automaticamente a sessão.
- Updater ganhou snapshot de rollback e retenção de 2 snapshots.
- Design V11 mantido separado da lógica de comandos.

## Não declarado como validado

A autenticação real com WhatsApp não pode ser simulada neste ambiente. QR Code, código de pareamento, sessão real, rede e reconexão real precisam ocorrer no Termux do proprietário.
