# Changelog — 8.0.0

- Adicionado Campeonato Global do Além.
- Adicionado ciclo persistente preparação/guerra de 15 + 15 dias.
- Adicionado ranking global e ligas.
- Adicionado pontuação individual.
- Adicionado Boss Global.
- Adicionado Copa/Playoffs.
- Adicionado histórico e recordes.
- Adicionadas Eras.
- Scheduler passou a acompanhar a fase do campeonato.
- Mantido Clan Dominion existente.
- Mantida separação de responsabilidades entre serviço de domínio e plugin de comandos.
