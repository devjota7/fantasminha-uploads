# Fantasminha 11.2.0 — Production Innovation

## Triagem simplificada
- `×triagemcriar` inicia um construtor guiado.
- Confirmação numérica sem prefixo durante o fluxo.
- Até 20 perguntas.
- Categorias: texto, data, foto+IA, número, sim/não e escolha.
- `concluir` salva o formulário sem ativá-lo.
- `×triagemativar` cobra automaticamente novos membros.
- `×triagemdesativar` interrompe a cobrança automática.
- `×triagemcobrar` cria uma sessão/código exclusivo por membro.
- `×triagemficha ID` monta a ficha completa.
- `×triagemconectar GROUP_ID` envia fichas concluídas para um grupo de arquivo.
- `×triagemdesconectar` remove o grupo de arquivo.
- Fichas preservam respostas separadas da análise de imagens.

## Perfil público
- `×perfil` e `×perfil @usuário`.
- Identificação, nick, nascimento, cargo, premium e status.
- Registro de mensagens/interações/ranking/vacilos.
- Presença, atividade, prestígio e caos recreativo.
- Número mascarado publicamente.
- Ficha de triagem e data de registro quando disponíveis.

## Jogos
- `×acheiumerro [nível]`: observação progressiva.
- `×memoriacopos [nível]`: memória com edição da mensagem e níveis.

## Universo vivo
- Mundo vivo, temporadas, eventos, boss mundial, expedições, investigação, títulos, conquistas e museu.

## Segurança
- Reconhecimento de dono pode usar `OWNER_NUMBER`, `OWNER_LID` e `OWNER_IDS`.
- Permissões permanecem centralizadas.
- Não é permitido executar código arbitrário através da triagem/UI.
