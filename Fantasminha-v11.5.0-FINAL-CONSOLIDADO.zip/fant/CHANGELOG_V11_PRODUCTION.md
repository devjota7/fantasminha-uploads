# Fantasminha 11.0.0 — Production

- Design geral alinhado ao padrão Nazuna Style, mantendo identidade 👻.
- `groupAccess.js` restaurado para corrigir o import quebrado da V10.5.6.
- `.env.example` incluído e carregamento local do `.env` no startup.
- `WA_AUTH_METHOD=qr|pairing|prompt` para escolha automática/opcional.
- Pairing pode usar `OWNER_NUMBER` sem pedir o número novamente.
- Detecção de sessão baseada em `creds.json`.
- Updater preparado para release sem substituir `.env`, autenticação, banco e logs.
- Validação de sintaxe e preflight mantidos.
