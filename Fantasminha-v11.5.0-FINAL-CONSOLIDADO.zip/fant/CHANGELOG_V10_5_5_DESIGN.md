# 👻 Fantasminha v10.5.5 — Design Spectral

## Identidade visual
- Design System global centralizado em `dados/src/menus/theme.js`.
- Cabeçalhos, seções, rodapés e catálogos com identidade única do Fantasminha.
- Estética sobrenatural, tecnológica, fofa e arrogantemente debochada.
- Trocadilhos e mensagens temáticas para sucesso, erro, aviso e informação.

## Respostas
- `reply()` agora aplica decoração automática a respostas textuais curtas.
- Menus estruturados, JSON, código e mensagens longas são preservados.
- Erros, sucessos e avisos recebem linguagem temática sem esconder a informação técnica.

## Compatibilidade
- Comandos e aliases não foram renomeados.
- `.env`, banco, sessão e dados locais não fazem parte deste pacote.
- O prefixo padrão continua `×`.
