# Fantasminha V11 — Reforma Visual

- Design global alinhado ao padrão visual estrutural do Nazuna.
- Cabeçalhos, bordas, separadores, ícones e espaçamento padronizados.
- Identidade visual mantida como Fantasminha, com 👻/🌑/🩶.
- Respostas comuns deixaram de receber moldura automática.
- Mantido suporte a respostas estilizadas explícitas via `decorateResponse(..., { force: true })`.
- Menus e comandos existentes preservados.
