# 👻 Fantasminha 11.5.0 — FINAL CONSOLIDADO

O Fantasminha 11.5.0 é uma plataforma modular de bot WhatsApp com Registry de comandos, plugins, serviços, economia, RPG, clãs, triagem, downloads, IA opcional, observabilidade e persistência JSON otimizada para Termux.

## 🚀 Primeiro lançamento: 1 grupo

Esta versão possui **allowlist de grupos** para lançamento controlado. Configure no `.env`:

```env
NODE_ENV=production
OWNER_NUMBER=SEU_NUMERO
PREFIX=×
ALLOWED_GROUP_IDS=ID_DO_SEU_GRUPO@g.us
ALLOW_OWNER_SHELL=false
ALLOW_OWNER_EVAL=false
DASHBOARD_ENABLED=false
```

Com `ALLOWED_GROUP_IDS` preenchido, grupos fora da lista são ignorados. PVT continua disponível para os fluxos privados previstos.

### Descobrir o ID do grupo

Depois de conectar o bot no grupo de teste, use:

```text
×idgrupo
```

Copie o ID retornado para `ALLOWED_GROUP_IDS` e reinicie o bot.

## Instalação no Termux

```bash
bash scripts/install.sh
nano .env
npm run preflight
npm run validate:release
npm start
```

Requisitos:

- Node.js 20+
- npm 9+
- FFmpeg para recursos de mídia que o utilizam
- sessão WhatsApp válida

## 🔐 Proteções de produção

Por padrão, a execução arbitrária do owner fica desativada:

```env
ALLOW_OWNER_SHELL=false
ALLOW_OWNER_EVAL=false
```

Não habilite essas opções em um bot exposto sem necessidade operacional clara.

IA é opcional. Para o primeiro teste ela pode permanecer desligada:

```env
FEATURE_AI=false
```

O Dashboard também permanece desligado por padrão:

```env
DASHBOARD_ENABLED=false
```

## 🧪 Validação

```bash
npm run preflight
npm run validate:release
```

A validação de release cobre sintaxe, Registry, allowlist, smoke, World, Triagem, expansão, Platform, reforma, V7, Mega 7.0.1, Clãs, Owner Menu, Fusion Core, segurança e Championship.

## 🛡️ Hardening aplicado

- Economia com operações atômicas e proteção contra concorrência.
- Marketplace protegido contra quantidade negativa e dupla compra.
- Daily/Weekly/Work protegidos contra chamadas simultâneas.
- Registry serializa a execução do mesmo comando pelo mesmo usuário para impedir bypass de cooldown por corrida.
- `cortarvideo` não monta shell com parâmetros de tempo do usuário.
- Calculadora não usa `eval`/`Function`.
- Execução de shell/eval do owner fica desativada por padrão.
- Allowlist de grupos para lançamento controlado.
- Limite da fila de mensagens para evitar crescimento ilimitado.
- Preflight verifica configuração mínima e FFmpeg.
- Testes específicos de concorrência e allowlist.
- `.gitignore` protege sessão, `.env`, bancos e temporários.

## 🏗️ Arquitetura

```text
WhatsApp / Baileys
        ↓
connect.js
        ↓
V2 Bridge
        ↓
Pipeline / Rate Limit / Anti-flood
        ↓
Command Registry
        ↓
Permissions
        ↓
Plugins / Services
        ↓
Database / Transactions / Cache / Events / Metrics
```

O legado `dados/src/index.js` permanece como fallback durante a migração. Novos recursos devem entrar na V2; não aumente o monólito legado.

## 💾 Persistência

A V2 usa JSON com escrita atômica e locks para manter compatibilidade com Termux sem exigir módulos nativos. O banco runtime é criado em `data/db/`.

Faça backup antes de mudanças importantes:

```bash
npm run backup
```

## ⚠️ Critério de lançamento público

Primeiro mantenha `ALLOWED_GROUP_IDS` apontando para **um único grupo**. Só amplie a lista depois de observar o bot em uso real, incluindo reconexão, comandos administrativos, economia, RPG, triagem e mídia.
