# 👻 Fantasminha 11.0.0 — instalação limpa no Termux

O instalador é direcionado: só altera `~/Bots/fantasminha` (ou `FANTASMINHA_TARGET`). Não usa comandos como `rm -rf ~`.

Se o ZIP estiver em `~/Fantasminha-v11.0.0-PRODUCTION.zip`:

```bash
bash /caminho/para/scripts/install-termux.sh ~/Fantasminha-v11.0.0-PRODUCTION.zip
```

Se estiver instalando a partir de um pacote extraído, rode o script de dentro dele.

Depois:

```bash
cd ~/Bots/fantasminha
nano .env
npm start
```

## Atualização futura

O comando WhatsApp `×atualizar` consulta `latest.json`, verifica versão e SHA-256, cria snapshot de rollback, preserva `.env`, sessão, banco e logs, aplica a release, instala dependências e valida sintaxe. Se a aplicação/validação falhar, tenta restaurar o código anterior.
