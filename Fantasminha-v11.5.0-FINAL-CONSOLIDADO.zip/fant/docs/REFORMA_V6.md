# 👻 Fantasminha 6.0 — Reforma Total

A V6 mantém o legado da Nazuna como fallback, mas transforma todo o desenvolvimento novo em uma plataforma modular.

## Mudanças principais
- Core de ciclo de vida e encerramento controlado.
- Registry idempotente: re-registro não deixa aliases órfãos.
- Validação de colisão entre nomes e aliases.
- Event Bus com eventos READY, ERROR e SHUTDOWN.
- Jobs com `unref()` e parada global no shutdown.
- Bootstrap agora inicializa a Platform de verdade antes dos plugins.
- Banco com fachada única: `src/database/index.js` não cria uma segunda implementação.
- Suite de regressão da reforma.
- Scripts de validação consolidados.
- Documentação atualizada para V6.

## Regra arquitetural
Novos recursos entram em `src/commands`, `src/services`, `src/plugins`, `src/platform`, `src/core`, `src/middleware` ou `src/database`.

O `dados/src/index.js` continua apenas como Legacy Bridge até a migração de cada domínio.
