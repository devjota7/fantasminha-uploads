# Fantasminha 10.4.0 — Multi-Base Fusion

## Bases estudadas
- WhatsAppBotMultiDevice: cache, fila, dashboard, WebSocket/event stream, recursos, analytics, LID e scheduler persistente.
- WhatsApp AI Bot: runtime config, serviços de IA, memória, rate limit, painel/admin API.
- Python WhatsApp Bot: camada de conhecimento/FAQ, abstração de IA e segurança declarativa.

## Princípio
Nenhuma base externa foi incorporada como núcleo. As ideias foram adaptadas à arquitetura ESM/Registry/Platform do Fantasminha.

## Novas camadas
- `src/platform/controlCenter/`: dashboard HTTP local opcional + API JSON.
- `src/core/runtimeConfig.js`: configurações seguras em runtime.
- `src/core/resourceManager.js`: ciclo de vida de recursos temporários.
- `src/platform/identity/lid.js`: normalização JID/LID.
- `src/services/messageDelivery.js`: entrega via fila + retry + deduplicação.
- `src/services/knowledge/`: Knowledge Base local para FAQ/contexto.
- analytics inclui filas e recursos.

## Segurança do dashboard
O dashboard é opcional e, por padrão, não inicia. Quando ativado, usa `127.0.0.1` por padrão. Não exponha a porta diretamente à internet sem adicionar autenticação e TLS/proxy.

## Próxima fase
Após esta consolidação, o próximo trabalho será o inventário dos ~500 comandos prioritários das bases, comparando cada um com o Registry atual:
1. já existe → melhorar;
2. existe em várias bases → fundir;
3. ausente e útil → adicionar;
4. obsoleto/inseguro → descartar.
