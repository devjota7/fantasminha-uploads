# Fantasminha 7.0.1 — Mega Expansion

- Pets 2.0: catálogo ampliado, Aranha 🕷️, renomeação, raridades e atributos.
- Família 2.0: filiação biológica 🧬, adoção 🍼, adoção solo, árvore com gerações e distinção dos vínculos.
- Relacionamentos separados: User × User e User × NPC.
- Empresas: criação, capital, painel, contratação/demissão e NPCs persistentes.
- Botstats: atividade, ranking e métricas do registry.
- Status e suporte com painéis temáticos.
- Brat: geração local de figurinha com fundo branco, sem depender de API externa.
- Rankings de empresas, pets e famílias.
- Persistência em coleções JSON via camada de banco existente.
