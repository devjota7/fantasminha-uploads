# 👻 Triagem Universal — Fantasminha 11.5.0

## Visão geral

Existe uma configuração de triagem por grupo e cada participante recebe uma sessão/ficha individual. A triagem pode ser feita no PV do Fantasminha e termina em uma ficha para análise humana.

## 🚀 Começo rápido

1. `×triagemcriar` — abre o assistente visual.
2. Responda `1` para começar.
3. Envie cada pergunta e escolha o tipo.
4. Envie `concluir` quando terminar.
5. Use `×verperguntas` para conferir.
6. Use `×triagemcobrar` para testar/cobrar os membros atuais.
7. Use `×triagemativar` para ativar automaticamente para novos membros.

Atalho rápido: `×setperguntas pergunta 1 | pergunta 2 | pergunta 3`.

## 🧩 Editor completo

- `×triagempergunta help` — ajuda completa.
- `×triagempergunta lista` — lista perguntas.
- `×triagempergunta add text Pergunta` — adiciona pergunta.
- `×triagempergunta editar 1 Nova pergunta` — edita texto.
- `×triagempergunta remover 1` — remove.
- `×triagempergunta mover 3 1` — reorganiza.
- `×triagempergunta duplicar 2` — duplica.
- `×triagempergunta tipo 1 choice` — altera tipo.
- `×triagempergunta opcoes 1 A|B|C` — configura escolhas.
- `×triagempergunta obrigatoria 1 on` — torna obrigatória.
- `×triagempergunta ia 1 on` — liga análise auxiliar de IA.
- `×triagempergunta ocr 1 on` — liga OCR auxiliar.
- `×triagempergunta comparar 1 q1|q2` — configura comparação de respostas.
- `×triagempergunta confianca 1 high` — define piso de confiança.
- `×triagempergunta exportar` — exporta configuração em JSON.
- `×triagempergunta importar JSON` — importa configuração exportada.

Tipos: `text`, `date`, `number`, `yesno`, `choice`, `image`.

## 📸 Foto + IA

Perguntas `image` aceitam imagem diretamente no PV. A análise pode registrar qualidade, OCR, dados visíveis e alertas objetivos. A IA é somente auxiliar; a decisão final continua com a equipe.

## ⚖️ Conselho

Após todas as respostas, a sessão passa para `aguardando_julgamento`.

- `×triagemficha TRG-XXXXXX` — ficha completa.
- `×conselho TRG-XXXXXX` — resumo para análise.
- `×aprovar TRG-XXXXXX` — aprova.
- `×reprovar TRG-XXXXXX motivo` — reprova com motivo.
- `×cancelatriagem @membro` — cancela sessão ativa.

Não existe votação automática: o julgamento é individual e humano.

## 🛡️ Segurança

- `×bl check @membro` — consulta bloqueio.
- `×bl add @membro motivo` — bloqueio permanente.
- `×bl temp @membro dias motivo` — bloqueio temporário.
- `×bl remove @membro` — remove bloqueio.
- `×bl list` / `×bl stats` — visão global para o dono.

Reprovações e alterações relevantes ficam registradas em auditoria/histórico.

## 📊 Operação

- `×triagemstatus` — painel.
- `×triagemstats` — estatísticas.
- `×filatriagem` — fila ativa.
- `×triagemconectar ID_GRUPO` — conecta arquivo.
- `×triagemdesconectar` — remove arquivo.
- `×triagemexcluir` — remove configuração.
- `×triagemmenu` — central de ajuda.

## ⏱️ Prazos

A configuração possui prazo para iniciar, concluir e julgar, além de lembrete. Sessões expiram conforme as regras configuradas e podem ser mantidas ou removidas automaticamente conforme a política do grupo.
