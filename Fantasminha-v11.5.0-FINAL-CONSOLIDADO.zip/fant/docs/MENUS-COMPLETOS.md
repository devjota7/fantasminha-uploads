# 👻 Fantasminha — Menus completos

O `×menu` é somente o índice. Os submenus são gerados a partir de `dados/src/menus/commandCatalog.json`. Cada comando catalogado aparece em exatamente uma categoria, com o prefixo configurado pelo bot.

## Menu principal

`×menu` → categorias → submenu correspondente.

- 🌑 ALÉM: `24` entradas
- 💰 ECONOMIA: `83` entradas
- 🎮 JOGOS: `284` entradas
- ⚔️ RPG: `109` entradas
- 🏰 CLÃS: `18` entradas
- ⚔️ GUERRAS: `5` entradas
- 🤖 IA: `34` entradas
- 📥 DOWNLOADS: `33` entradas
- 🖼️ FIGURINHAS: `25` entradas
- 🔧 FERRAMENTAS: `124` entradas
- 🛡️ ADMINISTRAÇÃO: `151` entradas
- ⚖️ TRIAGEM: `5` entradas
- 💎 PREMIUM: `10` entradas
- ⚙️ SISTEMA: `224` entradas
- 👑 DONO: `63` entradas
- 👥 COMUNIDADE: `23` entradas

**Total catalogado:** `1215` entradas (com aliases/legado quando presentes no código/menu).

> Observação: o catálogo é derivado da V4 atual (código e menus existentes). As outras bases analisadas anteriormente ainda não são declaradas como integradas só por estarem no relatório de comparação.
