# Fantasminha V11 — Design System

## Objetivo
Reaproximar todo o visual do Fantasminha ao padrão estrutural do Nazuna, sem copiar a identidade do Nazuna.

## Padrão global
- Cabeçalho compacto `╭┈⊰ ...`
- Saudação com `┊`
- Fechamento ornamental `◜👻◞`
- Itens com `•.̇𖥨֗👻⭟`
- Separadores `❁`
- Bordas e espaçamento consistentes em todos os menus
- RPG mantém `⚔️` como acento funcional
- Respostas comuns voltam a ser limpas, como no Nazuna
- Molduras especiais ficam disponíveis somente quando solicitadas explicitamente

## Identidade
A estrutura é inspirada no padrão visual do Nazuna, mas a identidade usa:
- 👻 Fantasminha
- 🌑 Além/Véu
- 🩶 alma
- 👻 ornamento principal

## Compatibilidade
Nenhum comando foi removido ou renomeado nesta alteração. A mudança é focada em apresentação/UX.
