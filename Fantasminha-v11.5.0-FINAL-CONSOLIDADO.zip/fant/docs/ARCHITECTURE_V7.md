# 👻 Fantasminha World 7.0 — Arquitetura

## Núcleo
- **Command Registry**: fonte única de comandos, aliases, permissões, cooldown e timeout.
- **Unified Context / Identity**: cada execução possui `requestId`, `operationId` e Fantasminha ID.
- **Operations**: idempotência para evitar duplicação de ações.
- **Transactions**: commit/rollback de múltiplas coleções com lock global ordenado.
- **Audit**: alterações administrativas e operações importantes deixam trilha.
- **Event Bus**: eventos internos desacoplam módulos.
- **Jobs**: execução periódica com proteção contra overlap e retry.
- **Feature Flags**: ativação progressiva sem remover código.
- **Layered Config**: global → grupo → usuário → comando.
- **Snapshot/Restore**: restauração verificada e snapshot automático pré-restore.
- **Integrity / Incident Response**: diagnóstico e tratamento operacional.

## Member Engine
A identidade interna é o `memberId` derivado do identificador da plataforma. Nick, display name e menção são representações, não chaves.

Módulos:
- Nick Engine
- Birthday Engine
- Admission/Triage
- Membership Reconciliation
- Collection Views
- History/Audit

## Economia
- Loja e inventário.
- Venda de itens com preço de revenda por item.
- Ledger econômico.
- Transferência crítica usa transação multi-coleção.
- A moeda do projeto continua sendo **Ghostcoins**.

## RPG
- Classes e modificadores.
- Treinamento de atributos.
- Stat Engine.
- Progression/Reward Engine.
- O RPG legado continua disponível durante a migração gradual.

## Personalização
Preferências ficam separadas de dados de identidade. Personalizações customizadas podem exigir VIP via Entitlement/Personal layer.

## Interface
O sistema prefere comandos curtos e consultas direcionadas a menus gigantes. Fluxos interativos continuam possíveis quando uma operação exige várias etapas.

## Migração Legacy → Core
Não é uma substituição abrupta. O Legacy permanece executável e novas áreas usam o Core. O Migration Registry registra compatibilidade e uso para que domínios possam ser migrados progressivamente.
