# Fantasminha 5.1 — Core Platform

## Objetivo
A V5.1 não tenta aumentar o catálogo de comandos. Ela transforma a V5 em uma plataforma coesa e preparada para a migração Legacy → V5.

## Camadas

```text
WhatsApp / Baileys
        ↓
Message Pipeline
        ↓
Unified Context
        ↓
Command Registry
        ↓
Services / Domain
        ↓
Event Bus
        ↓
Platform Core
        ↓
JSON Store / futuro SQLite
```

## Novos pilares
- Fantasminha ID e contexto unificado
- Idempotência por Operation ID
- Auditoria estruturada
- Transações econômicas com staging/rollback compensatório
- Event Bus de plataforma
- Jobs
- Feature Flags
- Configuração por camadas
- Dependency Graph
- Snapshot/Restore verificado
- Integrity/Doctor
- Command Migration Registry
- Fantasminha Personal

## Legacy
O Legacy não é apagado na V5.1. Ele continua como fallback. A migração deve ser feita por domínio, com mapa de compatibilidade e feature flags. Quando todos os comandos de um domínio estiverem no Registry V5, o fallback daquele domínio pode ser desligado.

## Regra de ouro
Novas funcionalidades devem entrar em `src/platform`, `src/services` ou plugins pequenos. Evite voltar a concentrar centenas de handlers em um único arquivo.
