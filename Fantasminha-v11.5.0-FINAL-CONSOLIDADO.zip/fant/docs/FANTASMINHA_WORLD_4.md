# Fantasminha World 4.0

## Dois níveis de clã

### 🌐 Clã Global
Criado pelo jogador e independente de um grupo. Um jogador pode pertencer a um único Clã Global por vez.

### 👥 Clã do Grupo
Criado automaticamente para cada grupo que interage com a fundação V2. O nome acompanha o nome do grupo e sua participação em guerras é controlada exclusivamente por administradores do WhatsApp.

## Guerra de Grupo

1. ADM usa `×clagrupoguerra on`.
2. ADM consulta `×guerragrupo listar`.
3. ADM usa `×guerragrupo desafiar <nome|id> [1-5]`.
4. O grupo adversário recebe o aviso quando o socket estiver disponível.
5. ADM adversário usa `×guerragrupo aceitar` ou `×guerragrupo recusar`.
6. Membros usam `×guerragrupoentrar` durante preparação.
7. Durante a guerra, participantes usam `×guerragrupoataque [normal|forte|especial]`.
8. `×guerragrupo status` mostra a pontuação.
9. `×guerragrupohistorico` mostra guerras encerradas.

## Guerra Global

`×claguerra <id_cla> [1-5]` cria um desafio. O adversário aceita com `×claguerraaceitar <id>`.

## Compatibilidade

Os nomes antigos `clacriar`, `claentrar`, `clasair`, `clainfo`, `clarank`, `cladissolver`, `cladepositar`, `claguerra` e `war` foram reaproveitados no sistema Global. O antigo `claguerra` instantâneo foi substituído por guerra persistente; este é o principal ajuste comportamental da V4.
