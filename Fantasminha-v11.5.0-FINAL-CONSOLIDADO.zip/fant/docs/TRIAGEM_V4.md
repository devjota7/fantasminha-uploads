# 👻 Triagem v4 — Fila do Limbo

## Fluxo

1. Membro entra no grupo.
2. O bot cria um código individual `TRG-XXXXXX`.
3. O grupo recebe o link `wa.me/...?...` e o código.
4. O membro envia o código no PV.
5. O bot valida `userId + groupId + expiração` e inicia as perguntas.
6. Até 20 perguntas são respondidas uma por vez.
7. A ficha é persistida em `data/db/triage.json`.
8. Ao terminar, o grupo recebe um resumo e os administradores recebem a ficha completa no PV.
9. O administrador abre o Conselho do Limbo e aprova ou reprova pelo ID da triagem.
10. O Conselho usa decisão individual: não há votação nem contagem de votos.
11. Após a primeira decisão, a triagem é encerrada e não pode ser sobrescrita.
12. Reprovação exige justificativa, registra auditoria/histórico e pode remover o membro.
13. Reprovações `network` alimentam a regra de reincidência; `blacklist` bloqueia novas entradas nos grupos que usam a triagem.

## Coleções

- `triage.json` — triagens e estados ativos.
- `triage_history.json` — histórico de reprovações por usuário.
- `triage_blacklist.json` — bloqueios temporários/permanentes.
- `triage_audit.json` — trilha de auditoria.
- `groups.json` — configuração `triagem` por grupo.

## Comandos

`×triagem on|off`

`×setperguntas Pergunta 1?\nPergunta 2?`

`×setperguntas padrão`

`×verperguntas`

`×filatriagem`

`×ficha TRG-XXXXXX`

`×conselho TRG-XXXXXX`

`×aprovar TRG-XXXXXX`

`×reprovar TRG-XXXXXX <motivo>`

`×reprovar TRG-XXXXXX --blacklist <motivo>`

`×triagemconfig <chave> <valor>`

`×meustatus` (PV)

`×voltar` (PV durante triagem)

`×cancelatriagem @user`

`×bl add @user <motivo>`

`×bl add @user --temp 7 <motivo>`

`×bl check @user`

`×bl remove @user`

## Privacidade

O padrão é resumo no grupo e ficha completa somente para administradores. A ficha antiga não é redistribuída quando o membro entra em outro grupo; apenas o histórico de reprovação é apresentado aos administradores.

## Observação sobre banimento

O WhatsApp não fornece um banimento global nativo. O sistema remove o membro do grupo quando configurado e mantém um bloqueio persistente na própria base. Quando a pessoa tentar entrar em outro grupo com triagem ativa, o bloqueio é consultado antes da criação da nova ficha.
