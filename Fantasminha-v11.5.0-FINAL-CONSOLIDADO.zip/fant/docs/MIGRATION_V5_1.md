# Legacy → V5 — estratégia

1. Catalogar comando Legacy.
2. Criar comando/serviço V5.
3. Registrar `legacy -> target` no Migration Registry.
4. Rodar testes de contrato.
5. Ativar V5 por feature flag.
6. Monitorar erros e métricas.
7. Tornar o alias Legacy silencioso/notice.
8. Desligar o Legacy daquele domínio.
9. Remover código Legacy somente depois de snapshot + validação.

### Modos
- `silent`: usuário não percebe a troca.
- `notice`: informa que o comando antigo foi atualizado.
- `block`: comando antigo deixa de executar e aponta para o novo.

Nunca migre centenas de comandos de uma vez sem snapshot e validação.
