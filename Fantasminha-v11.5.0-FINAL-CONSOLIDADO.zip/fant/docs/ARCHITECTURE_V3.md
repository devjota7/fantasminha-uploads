# 👻 Fantasminha V3 — Arquitetura e plano de migração

## Objetivo

Transformar o Fantasminha em uma plataforma modular sem apagar o legado existente.

## Fluxo principal

1. `dados/src/connect.js` inicializa a fundação V2 antes de aceitar o fluxo normal.
2. `dados/src/v2bridge.js` expõe o pipeline ao legado.
3. `src/middleware/pipeline.js` normaliza mensagem, anti-flood e rate-limit.
4. `src/core/registry.js` resolve alias, contexto, permissão, cooldown, timeout e métricas.
5. O plugin executa o serviço necessário.
6. O resultado volta pelo `reply` adaptado do legado.
7. Comandos ainda não migrados continuam no `dados/src/index.js` como fallback.

## Regras de desenvolvimento

- Novos comandos: sempre em `src/plugins/<categoria>/`.
- Lógica de negócio: `src/services/`.
- Persistência: somente pela camada `src/database/`.
- Permissões: `src/core/permissions.js`.
- Limites: `src/middleware/`.
- Observabilidade: `src/core/metrics.js`, `health.js` e logs.
- Operações pesadas: filas em `src/core/queue.js`.
- Não adicionar novos `case` ao `index.js`, salvo manutenção de legado.

## Migração do legado

Migrar por domínio, não por arquivo inteiro:

1. Economia
2. Administração/moderação
3. RPG
4. Jogos
5. Downloads/mídia
6. VIP/premium
7. Ferramentas
8. IA
9. Menus
10. Remoção progressiva de duplicações

Cada domínio só é considerado migrado quando possuir testes e passar pelo Registry.

## Persistência

A V3 mantém JSON por compatibilidade com Termux. A API de `store.js` funciona como fronteira de persistência. A próxima etapa pode implementar SQLite nessa fronteira sem alterar os plugins.

## Confiabilidade

- Bootstrap idempotente.
- Supervisor com backoff.
- Limite de reinícios em janela de tempo.
- Crash reporter.
- Escrita atômica.
- Lock por coleção entre processos.
- Timeout de comando.
- Filas limitadas.
- Métricas por comando.

## Critério para V3.1

Antes de adicionar centenas de comandos, o projeto deve manter:

- `npm run test:syntax` verde.
- `npm test` verde.
- `npm run doctor:v3` verde no ambiente alvo.
- Registry sem aliases duplicados.
- Banco íntegro.
- Nenhum novo comando implementado diretamente no `index.js`.
