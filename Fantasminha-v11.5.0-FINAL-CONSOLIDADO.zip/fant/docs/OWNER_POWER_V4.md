# 👑 Owner Power V4

Camada administrativa complementar do Fantasminha 4.2.3.

## Princípios
- 100 comandos novos registrados no registry V2.
- Todos os comandos desta camada são exclusivos do dono.
- Não existe sistema de votação.
- Operações destrutivas não são automatizadas por esta camada.
- Auditoria persistente em `data/db/audit.json`.
- Snapshots usam o backup seguro já existente.
- Triagem mantém julgamento individual humano.
- A análise de carteirinha é tratada como sinal de apoio à moderação; não declara identidade real apenas por uma imagem.

## Comandos principais
`×ownerhelp`, `×integridade`, `×snapshot`, `×auditoria`, `×analytics`, `×busca`, `×flags`, `×flag`, `×jobs`, `×incidente`, `×relatorio`.

## Triagem
`×triagemcfg`, `×triagemimagem on|off`, `×triagempolicy`, `×triagemimagemcfg`.

A pergunta de imagem já existente continua compatível com `×triagempergunta foto Envie sua carteirinha do Among Us` e o template `×setperguntas among`.
