# Fantasminha 7.0.0

## Plataforma
- Member Engine, Identity Resolver e Reconciliation.
- Nick Engine com política, histórico e seções por dados.
- Birthday Engine com validação, próximo aniversário e consultas.
- Preference Engine para configurações individuais.
- Reward Engine para recompensas econômicas/RPG.
- Stat/RPG Engine para atributos, classes e treino.
- Search e Views.
- Transactions endurecidas com lock e rollback.
- Jobs com retry e prevenção de overlap.
- Migration Registry persistente.
- Snapshot restore com pré-snapshot.
- Eventos de plataforma ampliados.

## Economia
- `venderitem <item> [quantidade|all]`.
- Inventário mostra valor de revenda.
- Transferência crítica usa Transaction Engine.

## Compatibilidade
- Prefixo e moeda existentes preservados.
- Legacy preservado para migração gradual.
- Comandos existentes continuam registrados.
