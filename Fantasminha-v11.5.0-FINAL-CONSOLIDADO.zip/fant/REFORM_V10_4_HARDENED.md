# Fantasminha 10.4.0 — Hardened Reform

## Principais correções

- Economia crítica migrada para operações transacionais.
- Transferências de Ghostcoins protegidas contra race condition e overflow da carteira.
- Daily, Weekly e Work protegidos contra duplicação concorrente.
- Marketplace com quantidade estritamente positiva e limites de segurança.
- Criação de ofertas e compra de ofertas feitas atomicamente.
- Compra concorrente da mesma oferta não pode gerar dupla entrega/pagamento.
- Dungeon, Boss e descanso do World Engine ganharam cooldowns e mutações atômicas.
- Mistérios impedem múltiplos casos simultâneos e resolução duplicada.
- `cortarvideo` deixou de montar comando shell com entrada do usuário; usa `spawn` com argumentos separados e validação de tempo.
- Token GitHub hardcoded removido; autenticação usa `GITHUB_TOKEN`.
- `form-data` declarado nas dependências.
- Ponte V2 não mascara mais falha de inicialização e expõe estado real.
- `isBotAdmin` incluído no contexto V2.
- Comando duplicado `status` do Mega 7.0.1 renomeado para `statusmega`.
- Teste de segurança/anti-exploit adicionado.
- Teste de Championship corrigido e incluído no fluxo seguro.

## Validação executada

- Sintaxe: 212 arquivos JS/MJS — OK.
- Smoke/Registry: 480 comandos, 767 aliases, 24 categorias — OK.
- World — OK.
- Triage — OK.
- Triage Integration — OK.
- Triage Image — OK.
- Expansion — OK.
- Platform — OK.
- Reform — OK.
- V7 Core E2E — OK.
- Mega 7.0.1 E2E — OK.
- Fusion Core — OK.
- Clan Expansion — OK.
- Personal Clan — OK.
- Championship — OK.
- Security Hardening — OK.

## Observação

O pacote foi reformado sem instalar `node_modules` e sem incluir dados de execução gerados durante os testes. A conexão real com WhatsApp/Baileys ainda depende de executar o bot no ambiente Termux com as credenciais e serviços externos do proprietário.
