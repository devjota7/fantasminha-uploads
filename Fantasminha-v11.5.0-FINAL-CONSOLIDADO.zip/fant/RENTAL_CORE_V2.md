# 👻 Rental Core V2

- `×gerarcod <dias>` gera código universal de uso único.
- Formato: `FANT-XXXX-XXXX-XXXX-XXXX-XXXX-XXXX`.
- O cliente não precisa de comando: basta enviar o código no grupo.
- A ativação é serializada dentro do processo para impedir dupla utilização concorrente.
- Se o grupo já possui aluguel, os dias são somados ao vencimento atual.
- Permanente usa `duration: permanent` e `expiresAt: permanent`.
- Persistência do aluguel usa escrita temporária + rename.
- Não existe `×grupopermissao` neste modelo.
- `×modoaluguel on|off` continua sendo o interruptor global do sistema comercial.
