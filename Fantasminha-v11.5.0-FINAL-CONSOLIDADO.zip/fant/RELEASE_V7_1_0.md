# 👻 Fantasminha 7.1.0 — WORLD ENGINE

A 7.1.0 amplia a Mega Expansão 7.0.1 com uma camada persistente de mundo.

## Sistemas
- 🌌 Mundo do Além e regiões desbloqueáveis
- 🗺️ Viagem e exploração
- ⚡ Energia e descanso
- 👻 Perfil do mundo
- 🏆 Conquistas
- 🏠 Propriedades e upgrades
- 🎒 Inventário e loja do Véu
- 🏦 Banco, depósitos, saques e extrato
- 📈 Investimentos e mercado fictício
- ⚔️ Duelos, bosses e dungeons
- 🤖 NPCs com relações e memórias
- 🌳 Linhagem e legado
- 🌐 Eventos mundiais
- 🏆 Temporadas
- 📊 Estatísticas do World Engine

## Arquitetura
O sistema fica isolado em `src/plugins/worldEngine/` e é registrado pelo bootstrap V2. A persistência usa a camada de banco já existente, sem nova dependência nativa.
