# 👻 Fantasminha — Sistema de Atualização GitHub

A partir da 10.5.4, o Fantasminha usa um fluxo de release por ZIP.

## Comando no WhatsApp

O dono principal pode usar:

```text
×atualizar
```

Também existem os aliases `×update` e `×atualizarbot`.

## O que a atualização preserva

- `.env`
- `data/auth/` (sessão WhatsApp)
- `data/db/` (dados locais)
- `data/backups/`
- `logs/`
- diretórios legados de sessão/dados quando existirem

O `config.json` **não** é protegido: uma release pode atualizá-lo normalmente.

## O que a atualização faz

1. Consulta `latest.json` no GitHub.
2. Compara a versão instalada com a release.
3. Baixa o ZIP.
4. Confere o SHA-256, quando informado.
5. Rejeita ZIP com caminhos inseguros.
6. Confere `package.json` e a versão declarada.
7. Faz backup dos dados e do código atual.
8. Substitui o código.
9. Restaura `.env`, sessão e dados.
10. Instala dependências quando necessário.
11. Executa a validação de sintaxe.
12. Faz rollback do código se a aplicação/validação falhar.
13. Registra `.last-update.json`.
14. Encerra com código 0 para o supervisor reiniciar o bot.

## Release no GitHub

A raiz do repositório configurado deve conter:

```text
Fantasminha-v10.5.5.zip
latest.json
```

Exemplo de `latest.json`:

```json
{
  "version": "10.5.5",
  "name": "Fantasminha",
  "release": "stable",
  "zip": "Fantasminha-v10.5.5.zip",
  "sha256": "HASH_SHA256_DO_ZIP",
  "notes": "Fantasminha v10.5.5",
  "minNode": "20.0.0"
}
```

O updater transforma automaticamente `zip` em uma URL `raw.githubusercontent.com` usando o repositório configurado.

Também é possível informar `download_url`, desde que a URL aponte para o GitHub configurado.

## Gerar latest.json

Depois de criar o ZIP da nova versão:

```bash
npm run release:manifest -- caminho/Fantasminha-v10.5.5.zip 10.5.5
```

Isso calcula o SHA-256 e cria `latest.json`.

## Regra importante

Nunca coloque `.env`, tokens, sessão WhatsApp ou dados pessoais dentro do ZIP de release.
