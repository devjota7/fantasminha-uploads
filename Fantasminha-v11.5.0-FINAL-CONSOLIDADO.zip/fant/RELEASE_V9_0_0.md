# 👻 Fantasminha v9.0.0 — Eternal Dominion Mega Expansion

## Modelo de Clãs reformulado
- Todo usuário pode possuir um Clã pessoal independente do grupo do WhatsApp.
- Clã nasce privado.
- Tornar o Clã público custa 25.000 GC.
- Clã público aceita solicitações e convites, com limite de 100 membros.
- Clã privado aceita convites, com limite de 50 membros.
- Global não é um segundo tipo de Clã: é uma autorização administrativa sobre um Clã público.
- Somente Clãs Global autorizados entram no campeonato, ranking e eventos globais.
- Auditoria persistente de criação, convites, entradas, saídas e autorização.

## Sistemas preservados e ampliados
- Campeonato de 15 dias de preparação + 15 dias de guerra.
- Anti-pay-to-win por pontuação competitiva e limites.
- Pets 2.0, incluindo Aranha e renomeação.
- Família com vínculos biológicos/adotivos e árvore genealógica.
- Relacionamento separado Usuário × Usuário e Usuário × NPC.
- Empresas jogáveis com funcionários NPC.
- NPCs com memória e histórico.
- World Engine, territórios, sede, diplomacia e crônicas.
- Botstats, Status, Suporte e Brat com fundo branco.

## Novos comandos principais
- ×clacriar
- ×clapublico
- ×clainfo
- ×clabuscar
- ×claentrar
- ×claaprovar
- ×claconvidar
- ×claaceitar
- ×clapendencias
- ×clasair
- ×cladissolver
- ×clavice
- ×clanrank
- ×claglobal
- ×claautorizar (Bot Admin)
- ×clarevogar (Bot Admin)
- ×claaudit
