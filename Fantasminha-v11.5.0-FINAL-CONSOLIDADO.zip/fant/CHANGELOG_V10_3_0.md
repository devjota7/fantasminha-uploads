# Fantasminha 10.3.0 — Core Fusion

## Adicionado
- Message Envelope Registry volátil e conservador.
- Contexto de mensagem unificado (`ctx.send`, `ctx.media`, `ctx.retry`).
- Retry/backoff centralizado.
- Erros tipados para timeout, sessão, banco e serviços externos.
- Command Visibility persistente: ocultar/restaurar sem desativar.
- Command Catalog/analytics operacional.
- Incident Engine com deduplicação de incidentes.
- Anti-Scam Engine heurístico com configuração por grupo e integração a incidentes.
- AI Intent Router determinístico e Tool Registry seguro.
- Custom Commands persistentes sem execução de código.
- Comandos `analytics`, `incidentes`, `ocultarcmd`, `mostrarcmd`, `cmdvisiveis`, `scamcheck`, `antiscam`, `ferramentas`, `envelopes`, `catalogo`, `agente`, `criarcmd`, `rmcmd` e `listacmd`.
- Testes do novo núcleo.
- Inventário de referência das bases externas para futura seleção funcional.

## Melhorado
- Pipeline passa a enriquecer o contexto e registrar envelopes quando a mensagem bruta está disponível.
- Integração V2 recebe operação segura de exclusão de mensagem para automações autorizadas.
- Registry respeita visibilidade persistente dos comandos.
- Analytics/incident tooling passam a formar uma camada operacional única.

## Regra de integração
Nenhum código externo é copiado cegamente. Funcionalidades de Takeshi, Silva MD e Hiyuki são reimplementadas/adaptadas ao Core V2 do Fantasminha.
