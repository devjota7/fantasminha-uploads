# Fantasminha v3.0.0

## Fundação

- Boot V2 removido do processo supervisor; agora a fundação inicializa no mesmo processo do WhatsApp.
- Bootstrap idempotente.
- `connect.js` aguarda a fundação V2 antes de iniciar o restante da conexão.
- Supervisor com backoff e proteção contra crash loop.

## Command Engine

- Registry expandido com metadados.
- Validação de contexto: grupo/privado/dono.
- Timeout por comando.
- Detecção de alias duplicado.
- Métricas de latência/sucesso/erro.

## Persistência

- Escrita atômica mais segura.
- Lock em memória + lock entre processos.
- Proteção contra lock abandonado.
- Health check real do banco.
- API preparada para futura migração para SQLite.

## Performance

- Rate-limit com escopo por grupo.
- Anti-flood com escopo por grupo e limite de memória.
- Cache TTL/LRU limitado.
- Task queues com concorrência, limite, prioridade e timeout.

## Diagnóstico

- Crash reporter.
- Health check ampliado.
- `npm test`.
- `npm run test:syntax`.
- `npm run doctor:v3`.
- Métricas via comando `×metricas` para o dono.

## Instalação

- Corrigidas referências antigas a `config:install` para `install:termux`.
- `sharp` declarado como dependência direta.
- Versão centralizada no `package.json`.

## 4.0.0 — Fantasminha World

- Novo modelo de **Clã Global**: qualquer membro pode criar ou entrar em um clã persistente independente do grupo.
- Novo **Clã do Grupo**: criado automaticamente a partir do grupo; membros e nome acompanham a comunidade.
- Novo controle `×clagrupoguerra on/off`, exclusivo para administradores reais do grupo.
- Novo sistema de guerras persistentes de 1 a 5 dias, com desafio, aceitação, preparação, participantes, pontuação, ataques e histórico.
- Desafios de guerra entre grupos são enviados ao JID do grupo adversário quando a ponte WhatsApp disponibiliza `sendMessage`.
- `claguerra`/`war` do Clã Global deixou de ser uma resolução instantânea aleatória e passou a usar o mesmo motor persistente de guerras.
- Migração automática da coleção legada `clans.json` para `global_clans.json`.
- Bloqueio de grupos ocupados para evitar guerras simultâneas incompatíveis.
- Expiração de desafios pendentes e transição automática de preparação → ativa → finalizada.
- Limite de participantes e cooldown individual de ataques.
- Ranking/progresso de Clãs atualizado após guerras.
- Registro de testes direcionados em `tests/world.mjs`.
- Correção dos scripts `start`/`dev` que apontavam para caminhos incorretos.

## V4.2.4 — Triagem Universal
- Removido o template obrigatório/embutido de Among da triagem.
- Perguntas agora são totalmente personalizáveis.
- Construtor com texto, número, sim/não, escolha e imagem.
- Perguntas de imagem aceitam instrução própria de IA, OCR e comparação configurável.
- Limites, títulos, ajuda, obrigatoriedade, ordem, duplicação e remoção configuráveis.
- Exportação/importação de fluxo em JSON.
- Conselho do Limbo permanece sem votação.

## 4.2.5 — Triagem Help + fluxo raiz
- `×triagemhelp` passou a abrir o tutorial completo e navegável.
- `×triagem cria` cria/garante a triagem única oficial do grupo.
- `×triagem setperguntas` permite montar/substituir perguntas rapidamente.
- `×triagem perguntas`, `foto` e `teste` ganharam atalhos de ajuda.
- Catálogo do menu de triagem atualizado com os novos atalhos.
- Documentação `TRIAGEM_UNIVERSAL_V4.md` atualizada com passo a passo.
- Teste de triagem passou a verificar o alias `triagemhelp`.
