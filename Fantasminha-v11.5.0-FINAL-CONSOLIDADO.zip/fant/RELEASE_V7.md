# 👻 FANTASMINHA 7.0.0 — RELEASE

Build: Mega Core / Community / Economy / RPG

Base: Fantasminha V6.0 reformado

Included:
- Member/Identity/Nick/Birthday/Admission foundations
- Membership Reconciliation + Views
- Preferences + VIP-aware customizations
- Reward/Stat/RPG foundations
- Item resale and inventory resale visibility
- Global search without giant menus
- Event Bus, Jobs, Feature Flags, layered config
- Operations/idempotency, transactions, audit
- Migration Registry, Snapshot/Restore, Integrity, Incident Response
- Legacy → Core gradual migration support

Validation: `npm run validate:all` passed from a clean V6 database state before release packaging.
