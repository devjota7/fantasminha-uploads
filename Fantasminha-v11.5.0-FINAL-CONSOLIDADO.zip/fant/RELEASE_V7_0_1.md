# 👻 Fantasminha 7.0.1 — MEGA EXPANSÃO

Base: Fantasminha v7.0.0 MEGA CORE COMPLETA.

Esta versão adiciona uma camada de Mega Expansão sobre o Core V7, preservando a arquitetura modular e a persistência JSON existente.

## Novos sistemas
- Pets 2.0, incluindo 🕷️ Aranha e renomeação.
- Família 2.0 com filiação 🧬 biológica e 🍼 adotiva, adoção solo e árvore genealógica.
- Relacionamentos separados: usuário × usuário e usuário × NPC.
- Empresas persistentes e NPCs contratáveis.
- Rankings de pets, empresas e famílias.
- Botstats, status da licença e suporte.
- Brat local com fundo branco.

## Testes
- Syntax check: aprovado.
- V7 Core E2E: aprovado.
- Mega 7.0.1 E2E: aprovado.
