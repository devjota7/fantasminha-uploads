# 👻 Fantasminha 11.4.0 — Hardened Termux/Android ARM64

## Principais correções

- `extractIncomingText` exportada de `src/services/triage.js`.
- Registry: `ownerOnly` agora aceita a identidade de proprietário configurada, não apenas `ctx.isOwner`.
- Conflito `perfil` entre plugins removido: comando administrativo renomeado para `perfiladmin`.
- Conflito `misterio` removido: a implementação nova de investigação permanece como comando principal.
- Alias duplicado relacionado a `pistacaso` removido da implementação antiga do World Engine.
- Referência morta `Logos2` removida.
- Patch legado de `newsletterFollow` que modificava `node_modules/baileys` no boot removido.
- Menus passaram a ser derivados do registry ativo, reduzindo comandos mortos/fora de categoria.
- Catálogo antigo auditado; entradas mortas identificadas e removidas.
- `×menu`/menus com mídia agora possuem fallback para texto quando a mídia não existe.
- Instalador Termux passou a preservar `.env`, auth, banco, mídias e logs enquanto atualiza o código.
- Instalador cria `dados/midias` automaticamente.
- Runtime WASM do Sharp incluído para ambientes sem runtime nativo compatível.
- Pairing code usa número normalizado e browser canônico, com QR de terminal desativado no modo pairing.
- Reconexão utiliza backoff progressivo e trata 515 como reinício esperado.

## Auditoria de comandos

- Catálogo auditado contra registry + comandos legados.
- Nenhuma entrada do catálogo ficou sem implementação detectável.
- Conflitos conhecidos de registro foram eliminados.
- O relatório detalhado fica em `COMMAND_AUDIT.json`.

## Testes executados

- `node scripts/syntax-check.mjs`
- `node scripts/audit-commands.mjs`
- `node tests/release-hardening.mjs`
- `node tests/v11_3_innovation.mjs`
- `node tests/triage.mjs`
- `node tests/triage-integration.mjs`
- `node tests/world.mjs` (inicialização validada; testes longos dependem do scheduler/ambiente)

## Observação sobre Termux/Sharp

A documentação atual do Sharp recomenda `@img/sharp-wasm32` como fallback WebAssembly para runtimes sem binário nativo compatível. O Android/Termux ARM64 não possui o mesmo conjunto de binários nativos Linux suportados pelo Sharp, portanto a instalação Termux inclui o runtime WASM.

## Limitação de validação local

A máquina de build não é um Termux/Android ARM64 real e não contém uma sessão WhatsApp. Portanto, QR/pairing real e instalação física em Android não podem ser certificados aqui; o código, instalador e smoke checks foram preparados para esse ambiente e precisam do teste final no aparelho.
