# 👻 FANTASMINHA 7.2.0
## CLAN DOMINION

Expansão focada em transformar o Clã em uma organização persistente do World Engine.

### Principais comandos novos
- ×claworld
- ×clasede
- ×claterritorios
- ×claconquistar
- ×clacoletar
- ×clacofre
- ×cladepositar2
- ×clacargos
- ×cladiplomacia
- ×claespiao
- ×clamascote
- ×clamissao
- ×clarankworld
- ×clacronicas
- ×cladinastia
- ×clahall

### Validação
- Syntax: OK
- Smoke: OK
- World: OK
- Clan Expansion: OK
