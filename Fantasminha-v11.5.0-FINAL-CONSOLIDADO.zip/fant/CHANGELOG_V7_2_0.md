# Fantasminha 7.2.0 — Clan Dominion

Mega expansão do Clã Global sobre a base 7.1.0.

## Novos sistemas
- Sede e construções evolutivas
- Territórios do Além e renda territorial
- Cofre/tesouro do domínio
- Cargos personalizados de clã
- Diplomacia: aliança, trégua, embargo e guerra
- Espionagem
- Missões coletivas
- Mascote do clã (incluindo espécie aranha)
- Crônicas/histórico
- Legado e classificação de dinastia
- Ranking de domínios
- Integração com o World Engine

## Compatibilidade
Os sistemas antigos de Clã Global, Clã de Grupo e Guerra permanecem disponíveis.
A expansão usa uma coleção separada `clan_world` para evitar quebrar os dados existentes.
