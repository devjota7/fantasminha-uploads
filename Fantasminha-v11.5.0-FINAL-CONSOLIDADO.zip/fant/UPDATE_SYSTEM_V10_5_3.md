# 👻 Fantasminha — Atualização por ZIP

O comando único `×atualizar` consulta `latest.json` no repositório configurado e baixa o ZIP indicado.

## Arquivos protegidos

- `.env`
- `data/auth/`
- `data/db/`
- `data/backups/`
- `auth/`
- `session/`
- `sessions/`
- `dados/database/`
- `dados/midias/`
- `dados/src/config.json`
- `logs/`

Todo o restante do código pode ser substituído pelo ZIP novo.

## latest.json

Exemplo:

```json
{
  "version": "10.5.4",
  "download_url": "https://github.com/devjota7/fantasminha-uploads/releases/download/v10.5.4/Fantasminha-v10.5.4.zip",
  "changelog": ["Novo menu", "Correções"]
}
```

`download_url` pode ser qualquer URL HTTPS direta para o ZIP. Para GitHub Releases, prefira a URL do asset da release.

## Uso

No WhatsApp, o dono principal usa somente:

`×atualizar`

Não existe mais `×atualizar sim`.
