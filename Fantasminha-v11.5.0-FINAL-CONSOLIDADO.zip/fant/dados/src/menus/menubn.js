import { menuHeader } from './theme.js';

const tips = [
  '👻 Convide alguém para um duelo e descubra quem domina o Além.',
  '🎲 Use os jogos rápidos para movimentar o grupo sem complicação.',
  '🧠 Memória, Wordle, quiz e anagramas: desafie a mente dos espíritos.',
  '💞 Interações funcionam melhor com alguém marcado no comando.',
  '🏆 Os rankings transformam uma brincadeira em rivalidade saudável.',
  '🌑 Quer algo diferente? Explore os desafios com tema do Véu.'
];

const line = (middleBorder, icon, prefix, command) => `${middleBorder}${icon}${prefix}${command}`;

export default async function menubn(prefix, botName = 'Fantasminha', userName = 'Usuário', isLiteMode = false, {
  header = null,
  menuTopBorder = '╭┈',
  bottomBorder = '╰─┈┈┈┈┈◜👻◞┈┈┈┈┈─╯',
  menuTitleIcon = '◆',
  menuItemIcon = '•.̇𖥨֗👻⭟',
  separatorIcon = '❁',
  middleBorder = '┊',
  gamesMenuTitle = '🎮 JOGOS & DESAFIOS DO ALÉM 🎲',
  phrasesMenuTitle = '💬 FRASES, PIADAS & DESAFIOS 🧠',
  interactionsMenuTitle = '🤝 INTERAÇÕES & CAOS SOCIAL 👻',
  relationshipMenuTitle = '💞 RELACIONAMENTOS & DESTINO ❤️',
  hotInteractionsMenuTitle = '🔥 DESAFIOS MAIS OUSADOS 😏',
  maleFunMenuTitle = '🎯 BRINCADEIRAS & RANKINGS 👑',
  femaleFunMenuTitle = '✨ BRINCADEIRAS & RANKINGS 💎',
  maleRanksMenuTitle = '🏆 RANKING DO ALÉM 👻',
  femaleRanksMenuTitle = '💎 RANKING DAS ALMAS 👑'
} = {}) {
  const formattedHeader = header
    ? header.replace(/#user#/g, userName)
    : menuHeader(botName, userName, 'CENTRAL DE BRINCADEIRAS DO ALÉM');

  const section = (title, commands) => `\n${menuTopBorder}${separatorIcon} *${title}*\n${middleBorder}\n${commands.map(c => line(middleBorder, menuItemIcon, prefix, c)).join('\n')}\n${bottomBorder}`;

  const games = [
    'tictactoe @user', 'connect4 @user', 'uno criar', 'uno entrar', 'uno jogar <n°>',
    'uno cancelar', 'memoria', 'memoria ranking', 'memoriafantasma', 'wordle',
    'quiz <categoria>', 'dueloquiz @user [número]', 'quizalem', 'trivia', 'forca',
    'forcaalem', 'anagrama', 'anagramaalma', 'cacapalavras [dificuldade]', 'cacaalma',
    'caca', 'digitar @usuario', 'digitacao', 'batalhanaval @user', 'jogodavelha',
    'eununca', 'ppt', 'stop', 'torrelimbo', 'batalha', 'batalhaalmas', 'chance',
    'quando', 'sorte', 'vab'
  ];

  const phrases = [
    'conselho', 'conselhobiblico', 'conselhoalem', 'cantada', 'piada', 'charada',
    'motivacional', 'elogio', 'reflexao', 'fato', 'frasealem', 'destino', 'karma', 'julgamento'
  ];

  const interactions = [
    'chute @user', 'chutar @user', 'tapa @user', 'tapar @user', 'soco @user', 'socar @user',
    'explodir @user', 'tomate @user', 'abraco @user', 'abracar @user', 'morder @user',
    'mordida @user', 'beijo @user', 'beijar @user', 'cafune @user', 'mata @user', 'matar @user',
 'brincadeira @user', 'chance @user', 'quando @user', 'shipo @user'
  ];

  const relationships = [
    'brincadeira @user', 'namoro @user', 'casamento @user', 'relacionamento @user',
    'terminar @user', 'trair @user', 'historicotraicao', 'shipo @user', 'casal @user', 'sn @user'
  ];

  const playful = [
    'inteligente @user', 'otaku @user', 'fiel @user', 'infiel @user', 'gado @user',
    'gostoso @user', 'rico @user', 'pobre @user', 'safado @user', 'vesgo @user',
    'chato @user', 'sortudo @user', 'azarado @user', 'forte @user', 'fraco @user',
    'pegador @user', 'otario @user', 'nerd @user', 'preguicoso @user', 'trabalhador @user',
    'brabo @user', 'lindo @user', 'malandro @user', 'simpatico @user', 'engracado @user',
    'charmoso @user', 'misterioso @user', 'carinhoso @user', 'ciumento @user',
    'corajoso @user', 'covarde @user', 'esperto @user', 'chorao @user', 'brincalhao @user',
    'comedia @user', 'gamer @user', 'poderoso @user', 'vencedor @user', 'visionario @user', 'zueiro @user'
  ];

  const playfulFemale = playful.map(c => c
    .replace('gostoso', 'gostosa').replace('safado', 'safada').replace('sortudo', 'sortuda')
    .replace('azarado', 'azarada').replace('fraco', 'fraca').replace('pegador', 'pegadora')
    .replace('otario', 'otaria').replace('preguicoso', 'preguicosa').replace('trabalhador', 'trabalhadora')
    .replace('brabo', 'braba').replace('lindo', 'linda').replace('malandro', 'malandra')
    .replace('simpatico', 'simpatica').replace('engracado', 'engracada').replace('charmoso', 'charmosa')
    .replace('misterioso', 'misteriosa').replace('carinhoso', 'carinhosa').replace('ciumento', 'ciumenta')
    .replace('corajoso', 'corajosa').replace('covarde', 'covarde').replace('esperto', 'esperta')
    .replace('chorao', 'chorona').replace('brincalhao', 'brincalhona').replace('poderoso', 'poderosa')
    .replace('vencedor', 'vencedora').replace('visionario', 'visionaria').replace('zueiro', 'zueira'));

  const ranks = [
    'rankalem', 'rankinteligente', 'rankotaku', 'rankfiel', 'rankinfiel', 'rankgado',
    'rankgostoso', 'rankrico', 'rankpobre', 'rankforte', 'rankpegador', 'ranknerd',
    'ranktrabalhador', 'rankbrabo', 'ranklindo', 'rankmalandro', 'rankengracado',
    'rankcharmoso', 'rankvisionario', 'rankpoderoso', 'rankvencedor', 'placaralem'
  ];

  const femaleRanks = ranks.map(c => c
    .replace('rankgostoso', 'rankgostosa').replace('rankrico', 'rankrica').replace('rankpegador', 'rankpegadora')
    .replace('ranktrabalhador', 'ranktrabalhadora').replace('rankbrabo', 'rankbraba').replace('ranklindo', 'ranklinda')
    .replace('rankmalandro', 'rankmalandra').replace('rankengracado', 'rankengracada')
    .replace('rankcharmoso', 'rankcharmosa').replace('rankvisionario', 'rankvisionaria')
    .replace('rankpoderoso', 'rankpoderosa').replace('rankvencedor', 'rankvencedora'));

  let menuContent = formattedHeader;
  menuContent += section(gamesMenuTitle, games);
  menuContent += section(phrasesMenuTitle, phrases);
  menuContent += section(interactionsMenuTitle, interactions);
  menuContent += section(relationshipMenuTitle, relationships);

  if (!isLiteMode) {
    menuContent += section(hotInteractionsMenuTitle, [
      'beijob @user', 'beijarb @user', 'desafioalem @user', 'julgamento @user', 'karma @user'
    ]);
  }

  menuContent += section(maleFunMenuTitle, isLiteMode ? playful.slice(0, 22) : playful);
  menuContent += section(femaleFunMenuTitle, isLiteMode ? playfulFemale.slice(0, 22) : playfulFemale);
  menuContent += section(maleRanksMenuTitle, isLiteMode ? ranks.slice(0, 12) : ranks);
  menuContent += section(femaleRanksMenuTitle, isLiteMode ? femaleRanks.slice(0, 12) : femaleRanks);

  const tip = tips[Math.floor(Math.random() * tips.length)];
  menuContent += `\n${menuTopBorder}${menuTitleIcon} *👻 CENTRAL DO CAOS*\n${middleBorder}${tip}\n${middleBorder}🎯 *Dica:* marque alguém com @ para transformar a brincadeira em desafio.\n${middleBorder}🌀 *Comandos:* ${games.length + phrases.length + interactions.length + relationships.length + ranks.length * 2}+ opções no menu.\n${bottomBorder}`;

  return menuContent;
}
