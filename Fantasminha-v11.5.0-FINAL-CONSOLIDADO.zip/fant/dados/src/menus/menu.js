import { menuHeader, menuFooter, section } from './theme.js';
export default async function menu(prefix='×', botName='Fantasminha', userName='Usuário') {
  return [menuHeader(botName,userName,'CENTRAL DO ALÉM'),'','🌑 PORTAIS',
    `${prefix}menualem  ${prefix}menueconomia  ${prefix}menujogos  ${prefix}menurpg`,
    `${prefix}menuclans  ${prefix}menuguerras  ${prefix}menumundo`,
    '', '👥 COMUNIDADE',
    `${prefix}menumemb  ${prefix}menucomunidade  ${prefix}menutriagem`,
    '', '🛠️ FERRAMENTAS',
    `${prefix}menuia  ${prefix}menudown  ${prefix}menufig  ${prefix}ferramentas`,
    '', '⚙️ SISTEMA',
    `${prefix}menusistema  ${prefix}menupremium  ${prefix}menudono`,
    '', menuFooter(`Use ${prefix}ajuda ou ${prefix}catalogo para encontrar comandos ativos.`)].join('\n');
}
