import { buildCatalogMenu } from './catalogMenu.js';
export default async function menu_dono(prefix='×') { return buildCatalogMenu(prefix, 'dono'); }
