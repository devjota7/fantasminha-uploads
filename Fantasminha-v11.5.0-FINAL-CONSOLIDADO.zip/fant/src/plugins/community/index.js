import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { ensureMember } from '../../platform/member/index.js';
import { setNick, listNicks, removeNick } from '../../platform/nick/index.js';
import { setBirthday, listBirthdays, todayBirthdays, nextBirthdays, removeBirthday } from '../../platform/birthday/index.js';
import { reconcile } from '../../platform/reconciliation/index.js';
import { getPreferences, setPreference } from '../../platform/preferences/index.js';
import { searchGlobal } from '../../platform/search/index.js';

const tag = s => `× 👻 FANTASMINHA\n\n${s}`;
const mention = id => `@${String(id||'').split('@')[0]}`;
function currentIds(ctx){ return Array.isArray(ctx.groupParticipants) ? ctx.groupParticipants : []; }
function target(ctx){ return ctx.mentioned?.[0] || ctx.sender; }
function displayNickRows(groupId, rows){
  if(!rows.length)return 'Nenhum nick cadastrado.';
  const sections=new Map(); for(const r of rows){const k=r.sectionId||'membros';if(!sections.has(k))sections.set(k,[]);sections.get(k).push(r);}
  return [...sections.entries()].map(([s,list])=>`📂 *${s}*\n${list.map(x=>`• ${mention(x.platformId||x.memberId)} → 「${x.nick}」`).join('\n')}`).join('\n\n');
}
function birthdayText(rows){
  const months=['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  return months.map((m,i)=>{const r=rows.filter(x=>x.month===i+1);return `📅 *${m}*\n${r.length?r.map(x=>`• ${String(x.day).padStart(2,'0')}/${String(x.month).padStart(2,'0')} • ${mention(x.platformId||x.memberId)}`).join('\n'):'• Nenhum cadastrado.'}`}).join('\n\n');
}
export async function register(){
  registerCommand({name:'nick',aliases:['cnick'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,handler:async ctx=>{
    const targetId=target(ctx); const parts=[...ctx.args]; if(ctx.mentioned?.[0]) parts.shift();
    if(!parts.length) throw new ValidationError('Use ×nick <seu nick> ou ×nick @membro <nick>.');
    if(targetId!==ctx.sender && !(ctx.isOwner||ctx.isBotAdmin||ctx.isGroupAdmin)) throw new ValidationError('Você não pode alterar o nick de outra pessoa.');
    const nick=parts.join(' '); const r=await setNick(targetId,nick,{groupId:ctx.from,actor:ctx.sender}); await ctx.reply(tag(`🏷️ Nick registrado!\n\n👤 ${mention(targetId)}\n✨ *${r.nick}*`));
  }});
  registerCommand({name:'nicks',aliases:['listacnick'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,groupOnly:true,handler:async ctx=>{const rows=listNicks(ctx.from,{order:'alpha'});await ctx.reply(tag(`🏷️ *LISTA DE NICKS*\n\n${displayNickRows(ctx.from,rows)}\n\n📌 Total: *${rows.length}*`));}});
  registerCommand({name:'semaNick',aliases:['semcnick'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,groupOnly:true,handler:async ctx=>{const ids=currentIds(ctx);if(!ids.length)throw new ValidationError('A lista de participantes não está disponível neste contexto.');const rows=listNicks(ctx.from);const set=new Set(rows.map(x=>x.platformId||x.memberId));const missing=ids.filter(x=>!set.has(x));await ctx.reply(tag(`👻 *SEM NICK*\n\n${missing.length?missing.map(mention).join('\n'):'Todos os participantes possuem nick.'}\n\nTotal: *${missing.length}*`));}});
  registerCommand({name:'aniversario',aliases:['cdata'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,handler:async ctx=>{const t=target(ctx);const date=ctx.args.filter(a=>!String(a).startsWith('@')).join(' ');if(!date)throw new ValidationError('Use ×aniversario DD/MM ou DD/MM/AAAA.');if(t!==ctx.sender&&!(ctx.isOwner||ctx.isBotAdmin||ctx.isGroupAdmin))throw new ValidationError('Você não pode alterar o aniversário de outra pessoa.');const r=await setBirthday(t,date,{groupId:ctx.from,actor:ctx.sender});await ctx.reply(tag(`🎂 Aniversário registrado para ${mention(t)}: *${String(r.day).padStart(2,'0')}/${String(r.month).padStart(2,'0')}*${r.year?`/${r.year}`:''}.`));}});
  registerCommand({name:'aniversarios',aliases:['listaaniversarios'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,groupOnly:true,handler:async ctx=>{const sub=String(ctx.args?.[0]||'lista').toLowerCase();if(sub==='hoje'||sub==='today'){const r=todayBirthdays(ctx.from);return ctx.reply(tag(`🎉 *ANIVERSARIANTES DE HOJE*\n\n${r.length?r.map(x=>mention(x.platformId||x.memberId)).join('\n'):'Ninguém cadastrado hoje.'}`));}if(sub==='proximos'||sub==='next'){const r=nextBirthdays(ctx.from,7);return ctx.reply(tag(`🎂 *PRÓXIMOS ANIVERSÁRIOS*\n\n${r.length?r.map(x=>`• ${String(x.day).padStart(2,'0')}/${String(x.month).padStart(2,'0')} — ${mention(x.platformId||x.memberId)}`).join('\n'):'Nenhum cadastrado.'}`));}const rows=listBirthdays(ctx.from);const next=nextBirthdays(ctx.from,1)[0];await ctx.reply(tag(`🎂 *ANIVERSÁRIOS*\n\n👥 Total: *${rows.length}*\n${next?`🎉 Próximo: ${mention(next.platformId||next.memberId)} — ${String(next.day).padStart(2,'0')}/${String(next.month).padStart(2,'0')}`:''}\n\n${birthdayText(rows)}`));}});
  registerCommand({name:'semdata',aliases:['semdata2'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,groupOnly:true,handler:async ctx=>{const ids=currentIds(ctx);const rows=listBirthdays(ctx.from);const set=new Set(rows.map(x=>x.platformId||x.memberId));const missing=ids.length?ids.filter(x=>!set.has(x)):[];await ctx.reply(tag(`👻 *SEM ANIVERSÁRIO*\n\n${missing.length?missing.map(mention).join('\n'):'Todos os participantes possuem data.'}\n\nTotal: *${missing.length}*`));}});
  registerCommand({name:'reconciliar',aliases:['reconcile'],category:'comunidade',plugin:'community',permission:Role.GROUP_ADMIN,cooldown:5,groupOnly:true,handler:async ctx=>{const ids=currentIds(ctx);if(!ids.length)throw new ValidationError('Participantes indisponíveis.');const r1=reconcile({groupId:ctx.from,currentIds:ids,collection:'nicks'});const r2=reconcile({groupId:ctx.from,currentIds:ids,collection:'birthdays'});await ctx.reply(tag(`🔎 *RECONCILIAÇÃO*\n\n🏷️ Nicks: ${r1.matched.length} OK · ${r1.missing.length} sem · ${r1.stale.length} antigos\n🎂 Aniversários: ${r2.matched.length} OK · ${r2.missing.length} sem · ${r2.stale.length} antigos\n\n⚠️ Nenhum cadastro é apagado automaticamente.`));}});
  registerCommand({name:'buscar',aliases:['search'],category:'comunidade',plugin:'community',permission:Role.USER,cooldown:3,handler:async ctx=>{if(!ctx.q)throw new ValidationError('buscar <nome/nick/ID>');const r=searchGlobal(ctx.q,{limit:10});await ctx.reply(tag(`🔎 *BUSCA GLOBAL*\n\n${r.length?r.map(x=>`• ${x.name} — ${x.id}`).join('\n'):'Nenhum resultado.'}`));}});
  registerCommand({name:'preferencias',aliases:['minhasprefs'],category:'personal',plugin:'community',permission:Role.USER,cooldown:3,privateOnly:true,handler:async ctx=>{const sub=String(ctx.args?.[0]||'ver').toLowerCase();if(sub==='ver'){const p=getPreferences(ctx.sender);return ctx.reply(tag(`⚙️ *PREFERÊNCIAS*\n\nIdioma: ${p.language}\nTema: ${p.theme}\nEstilo: ${p.responseStyle}\nNotificações: ${p.notifications?'ON':'OFF'}\nAniversários: ${p.birthdayReminders?'ON':'OFF'}`));}const key=ctx.args?.[0];const value=ctx.args?.slice(1).join(' ');if(!value)throw new ValidationError('preferencias <chave> <valor>');const allowed={idioma:'language',tema:'theme',estilo:'responseStyle',notificacoes:'notifications',aniversarios:'birthdayReminders'};const k=allowed[String(key).toLowerCase()];if(!k)throw new ValidationError('Chaves: idioma, tema, estilo, notificacoes, aniversarios');const val=['notifications','birthdayReminders'].includes(k)?['on','true','sim','1'].includes(value.toLowerCase()):value;await setPreference(ctx.sender,k,val);await ctx.reply(tag(`⚙️ Preferência *${k}* atualizada.`));}});
}
export default {register};
