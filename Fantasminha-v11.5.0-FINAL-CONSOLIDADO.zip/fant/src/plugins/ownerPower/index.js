/**
 * 👑 OWNER POWER V4.2.3
 * Camada administrativa complementar: 100 comandos novos, sem sistema de votação.
 * Persistência usa a store JSON existente para continuar compatível com Termux.
 */
import fs from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection, backupDatabase, DB_ROOT } from '../../database/store.js';
import config from '../../core/config.js';
import { ValidationError } from '../../core/errors.js';
import { createSnapshot, listSnapshots } from '../../platform/snapshots/index.js';
import { listIncidents, createIncident, updateIncident } from '../../platform/incidents/index.js';
import { platformAnalytics, analyticsText } from '../../platform/analytics.js';

const tag = t => `× 👻 FANTASMINHA\n\n${t}`;
const now = () => Date.now();
const stamp = () => new Date().toISOString();
const bool = v => ['on','1','true','sim','yes','ativo','ativar'].includes(String(v||'').toLowerCase());
const safeKey = s => String(s||'').toLowerCase().replace(/[^a-z0-9_.:-]/g,'_').slice(0,80);
const q = ctx => String(ctx.q || '').trim();
const arg0 = ctx => String(ctx.args?.[0] || '').trim();
const owner = { permission: Role.OWNER, cooldown: 1, category: 'dono', plugin: 'ownerPower', ownerOnly: true };

async function audit(action, ctx, details = {}) {
  await updateCollection('audit', d => {
    d.events ||= [];
    d.events.push({ id: `AUD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`, at: now(), action, actor: ctx.sender, group: ctx.from || null, details });
    if (d.events.length > 5000) d.events.splice(0, d.events.length - 5000);
    return d;
  }, { events: [] });
}

async function setKV(collection, key, value) {
  return updateCollection(collection, d => {
    d.values ||= {};
    d.values[safeKey(key)] = { value, updatedAt: now() };
    return d;
  }, { values: {} });
}
function getKV(collection, key, fallback = null) {
  return readCollection(collection, { values: {} }).values?.[safeKey(key)]?.value ?? fallback;
}
async function addRecord(collection, record, max = 2000) {
  return updateCollection(collection, d => {
    d.items ||= [];
    d.items.push(record);
    if (d.items.length > max) d.items.splice(0, d.items.length - max);
    return d;
  }, { items: [] });
}
function records(collection) { return readCollection(collection, { items: [] }).items || []; }

const defs = [
['integridade','integrity','🩺 Executa diagnóstico básico de integridade do banco e configuração.'],
['saude','health','🩺 Mostra saúde do núcleo.'],
['contexto','context','🧩 Mostra o contexto unificado da execução.'],
['idempotencia','idempotency','🔁 Consulta o estado da camada de idempotência.'],
['permissoes','permissions','🔐 Mostra a hierarquia de permissões.'],
['auditoria','audit','📋 Mostra os últimos eventos de auditoria.'],
['auditar','auditadd','📋 Registra um evento administrativo.'],
['snapshot','snapshot','💾 Cria snapshot do banco.'],
['snapshots','snapshots','💾 Lista snapshots existentes.'],
['restoreinfo','restoreinfo','💾 Mostra como localizar um snapshot para restauração segura.'],
['dependencias','deps','🕸️ Lista dependências dos módulos V4.'],
['flags','flags','🚩 Lista feature flags.'],
['flag','flag','🚩 Consulta/altera uma feature flag: flag nome on/off.'],
['configcamadas','layers','⚙️ Mostra configuração em camadas.'],
['migracoes','migrations','🔄 Mostra versão de migração e metadados.'],
['eventos','events','🚌 Lista eventos administrativos recentes.'],
['emitir','emit','🚌 Registra um evento no barramento persistente.'],
['jobs','jobs','⏱️ Lista jobs registrados.'],
['job','job','⏱️ Cria/atualiza um job simples persistente.'],
['deljob','deljob','⏱️ Remove um job persistente.'],
['incidentes','incidents','🚨 Lista incidentes.'],
['incidente','incident','🚨 Abre incidente administrativo.'],
['resolverincidente','resolveincident','🚨 Resolve incidente por ID.'],
['analytics','analytics','📊 Resumo global de uso e dados.'],
['topcomandos','topcommands','📊 Top comandos pelo registro de métricas.'],
['busca','search','🔎 Busca texto nas coleções JSON.'],
['buscagrupo','groupsearch','🔎 Busca um grupo pelo ID/nome salvo.'],
['buscauser','usersearch','🔎 Busca usuário pelo ID/nome.'],
['perfiladmin','profileadmin','👻 Perfil administrativo persistente do usuário marcado/informado.'],
['prefadmin','preferenciasadmin','⚙️ Consulta preferências administrativas.'],
['setpreferencia','setpref','⚙️ Define preferência: setpreferencia chave valor.'],
['notificar','notify','🔔 Registra notificação pessoal para um usuário.'],
['notificacoes','notifications','🔔 Lista notificações.'],
['limparnotificacoes','clearnotifications','🔔 Limpa notificações de um usuário.'],
['reputacao','reputation','⭐ Consulta reputação.'],
['setreputacao','setreputation','⭐ Ajusta reputação administrativa.'],
['conquista','achievement','🎖️ Registra conquista.'],
['conquistas','achievements','🎖️ Lista conquistas.'],
['temporada','season','🏆 Consulta temporada.'],
['settemporada','setseason','🏆 Define temporada ativa.'],
['rankinghistorico','historicalrank','🏆 Guarda/consulta snapshot de ranking.'],
['recorde','record','📈 Registra recorde.'],
['recordes','records','📈 Lista recordes.'],
['progressao','progress','📈 Consulta progressão.'],
['setprogresso','setprogress','📈 Define progresso administrativo.'],
['vipinfo','vipinfo','💎 Consulta status premium.'],
['vipset','vipset','💎 Define premium de um usuário.'],
['claninfo','claninfo','🏰 Consulta clã.'],
['clanset','clanset','🏰 Define temporada/status de clã.'],
['triagemcfg','triagecfg','⚖️ Consulta configuração global de triagem.'],
['triagemimagem','triageimage','🖼️ Configura política de análise de imagem da triagem.'],
['triagemlog','triagelog','⚖️ Consulta histórico de triagem.'],
['triagemfila','triagequeue','⚖️ Consulta fila global de triagem.'],
['blackstats','blackstats','🚫 Estatísticas da blacklist global.'],
['blackhistorico','blackhistory','🚫 Histórico administrativo da blacklist.'],
['blackexport','blackexport','🚫 Exporta resumo seguro da blacklist.'],
['blackpolicy','blackpolicy','🚫 Consulta política global da blacklist.'],
['modoglobal','globalmode','🌐 Consulta modo global.'],
['setmodoglobal','setglobalmode','🌐 Define modo global.'],
['bloqueiocmd','commandblock','⛔ Consulta bloqueio global de comando.'],
['setbloqueiocmd','setcommandblock','⛔ Bloqueia/desbloqueia comando globalmente.'],
['limites','limits','⏱️ Consulta limites administrativos.'],
['setlimite','setlimit','⏱️ Define limite simples por chave.'],
['cacheinfo','cacheinfo','🧠 Mostra estado de caches.'],
['cacheclear','cacheclear','🧠 Limpa sinalizador de cache do núcleo.'],
['memoria','memory','🧠 Mostra uso de memória do processo.'],
['processos','process','🧠 Mostra informações do processo.'],
['versao','version','📦 Mostra versão e ambiente.'],
['arquivosdb','dbfiles','💾 Lista arquivos do banco.'],
['dbcheck','dbcheck','💾 Verifica JSONs do banco.'],
['dbstats','dbstats','💾 Estatísticas das coleções.'],
['dbbackup','dbbackup','💾 Backup completo do banco.'],
['loginfo','loginfo','📋 Mostra localização de logs.'],
['configenv','envinfo','⚙️ Mostra chaves de configuração sem expor segredos.'],
['featureaudit','featureaudit','🚩 Auditoria das feature flags.'],
['comandos','commands','🧩 Lista comandos registrados.'],
['comandoinfo','commandinfo','🧩 Inspeciona um comando.'],
['categoria','category','🧩 Lista comandos de uma categoria.'],
['aliasinfo','aliasinfo','🧩 Consulta aliases de um comando.'],
['testarnucleo','coretest','🧪 Executa testes rápidos do núcleo.'],
['dryrun','dryrun','🧪 Simula operação administrativa sem persistir.'],
['lockinfo','lockinfo','🔐 Consulta locks persistentes.'],
['limparlocks','clearlocks','🔐 Remove locks antigos do banco.'],
['integridadeaudit','auditcheck','🩺 Verifica consistência básica da auditoria.'],
['seguranca','security','🛡️ Mostra controles de segurança ativos.'],
['rateinfo','rateinfo','⏱️ Mostra política de rate limit.'],
['fila','queue','🚌 Mostra estado de fila do núcleo.'],
['metricasreset','metricsreset','📊 Reinicia métricas em memória do processo.'],
['reputacaotop','reputationtop','⭐ Top de reputação.'],
['conquistasstats','achievementstats','🎖️ Estatísticas de conquistas.'],
['temporadastats','seasonstats','🏆 Estatísticas da temporada.'],
['progressotop','progresstop','📈 Top de progressão.'],
['triagempolicy','triagepolicy','⚖️ Mostra política de triagem sem votação.'],
['triagemimagemcfg','triageimagecfg','🖼️ Mostra configuração de imagem da triagem.'],
['blackpolicyset','blackpolicyset','🚫 Define política administrativa da blacklist.'],
['relatorio','report','📊 Gera relatório executivo resumido.'],
['exportconfig','exportconfig','💾 Exporta configuração pública/segura.'],
['manutencao','maintenance','🛠️ Alterna modo de manutenção.'],
['confirmaroperacao','confirm','🛡️ Exibe política de confirmação de operações destrutivas.'],
['ownerhelp','ownerhelp','👑 Mostra índice dos 100 comandos novos.']
];

function target(ctx) { return ctx.mentioned?.[0] || ctx.args?.find(x => /(@|:|@lid)/.test(x)) || null; }
function collectionSummary() {
  const out = {};
  try { for (const f of fs.readdirSync(DB_ROOT).filter(x=>x.endsWith('.json'))) { const c=f.slice(0,-5); const d=readCollection(c, null); out[c]=Array.isArray(d?.items)?d.items.length:Object.keys(d?.byId||d?.values||d||{}).length; } } catch {}
  return out;
}
function safeEnv() {
  return Object.fromEntries(['NODE_ENV','BOT_NAME','BOT_VERSION','OWNER_NAME','PREFIX','DEFAULT_LANGUAGE','AI_PROVIDER'].map(k=>[k,process.env[k]||null]));
}

export async function register() {
  for (const [name, action, description] of defs) {
    registerCommand({
      ...owner, name, description,
      aliases: [],
      handler: async ctx => {
        const t = target(ctx) || ctx.sender;
        const args = ctx.args || [];
        if (action === 'integrity') {
          const files = collectionSummary(); return ctx.reply(tag(`🩺 *INTEGRIDADE*\n\nBanco: ${config.root}/data/db\nColeções: ${Object.keys(files).length}\nNode: ${process.version}\nMemória disponível: ${Math.round(os.freemem()/1024/1024)} MB`));
        }
        if (action === 'health') return ctx.reply(tag(`🩺 Saúde: *OK*\nNode: ${process.version}\nPID: ${process.pid}\nUptime: ${Math.round(process.uptime())}s`));
        if (action === 'context') return ctx.reply(tag(`🧩 *CONTEXTO UNIFICADO*\nUsuário: ${ctx.sender}\nGrupo: ${ctx.from||'PV'}\nOwner: ${!!ctx.isOwner}\nGrupo admin: ${!!ctx.isGroupAdmin}\nBot admin: ${!!ctx.isBotAdmin}`));
        if (action === 'idempotency') return ctx.reply(tag(`🔁 Camada persistente de operações: audit + IDs únicos.\nÚltimo evento: ${records('audit').at(-1)?.id||'nenhum'}`));
        if (action === 'permissions') return ctx.reply(tag('🔐 OWNER 100 > BOT_ADMIN 80 > GROUP_ADMIN 60 > VIP 40 > USER 10'));
        if (action === 'audit') {
          const n=Math.min(20,Math.max(1,Number(arg0(ctx))||10)); const a=records('audit').slice(-n).reverse();
          return ctx.reply(tag(a.length?a.map(e=>`${e.id} • ${new Date(e.at).toLocaleString('pt-BR')} • ${e.action}`).join('\n'):'Auditoria vazia.'));
        }
        if (action === 'auditadd') { const text=q(ctx)||'evento manual'; await audit(text,ctx); return ctx.reply(tag(`📋 Auditoria registrada: *${text}*`)); }
        if (action === 'snapshot') { const snap=createSnapshot('owner', {actor:ctx.sender}); await audit('snapshot',ctx,{id:snap.id}); return ctx.reply(tag(`💾 Snapshot criado:\n${snap.id}\nArquivos: ${snap.files.length}`)); }
        if (action === 'snapshots') { const dir=path.join(config.root,'data','backups'); const list=fs.existsSync(dir)?fs.readdirSync(dir).slice(-20):[]; return ctx.reply(tag(list.length?list.map(x=>`• ${x}`).join('\n'):'Nenhum snapshot.')); }
        if (action === 'restoreinfo') return ctx.reply(tag('💾 Restauração é deliberadamente manual: faça backup atual, pare o bot e substitua somente os JSONs desejados por um snapshot íntegro.'));
        if (action === 'deps') return ctx.reply(tag('🕸️ Núcleo → registry → permissions/cooldown/errors → plugins → database/store → scheduler. Triagem e imagem permanecem desacopladas.'));
        if (action === 'flags') { const f=config.features||{}; return ctx.reply(tag(Object.entries(f).map(([k,v])=>`🚩 ${k}: *${v?'ON':'OFF'}*`).join('\n'))); }
        if (action === 'flag') { const k=arg0(ctx); if(!k) return ctx.reply(tag(`Uso: ${config.prefix}flag nome on|off`)); if(args[1]) { await setKV('owner_flags',k,bool(args[1])); await audit('flag.set',ctx,{key:k,value:bool(args[1])}); } return ctx.reply(tag(`🚩 ${k}: *${getKV('owner_flags',k,'não definido')}*`)); }
        if (action === 'layers') return ctx.reply(tag(`⚙️ Camadas: .env → config.json → feature flags → grupo → usuário → comando.`));
        if (action === 'migrations') return ctx.reply(tag(`🔄 ${JSON.stringify(readCollection('_meta',{version:0}),null,2)}`));
        if (action === 'events') { const a=records('event_bus').slice(-15).reverse(); return ctx.reply(tag(a.length?a.map(e=>`${e.id} • ${e.type}`).join('\n'):'Sem eventos.')); }
        if (action === 'emit') { const type=arg0(ctx)||'manual'; await addRecord('event_bus',{id:`EV-${Date.now().toString(36)}`,type,payload:q(ctx),at:now()}); await audit('event.emit',ctx,{type}); return ctx.reply(tag(`🚌 Evento *${type}* registrado.`)); }
        if (action === 'jobs') { const j=records('jobs'); return ctx.reply(tag(j.length?j.map(x=>`${x.id} • ${x.name} • ${x.enabled?'ON':'OFF'}`).join('\n'):'Nenhum job.')); }
        if (action === 'job') { const name=arg0(ctx); if(!name) throw new ValidationError(`Use ${config.prefix}job nome [on|off]`); const enabled=args[1]===undefined?true:bool(args[1]); await updateCollection('jobs',d=>{d.items ||= []; const old=d.items.find(x=>x.name===name); if(old) old.enabled=enabled,old.updatedAt=now(); else d.items.push({id:`JOB-${Date.now().toString(36)}`,name,enabled,createdAt:now()}); return d;},{items:[]}); return ctx.reply(tag(`⏱️ Job *${name}*: ${enabled?'ON':'OFF'}`)); }
        if (action === 'deljob') { const name=arg0(ctx); await updateCollection('jobs',d=>{d.items=(d.items||[]).filter(x=>x.name!==name);return d;},{items:[]}); return ctx.reply(tag('⏱️ Job removido.')); }
        if (action === 'incidents') { const a=listIncidents('open').slice(0,15); return ctx.reply(tag(a.length?a.map(x=>`${x.id} • ${x.severity} • ${x.status} • ${x.title}`).join('\n'):'Sem incidentes abertos.')); }
        if (action === 'incident') { const title=q(ctx)||'Incidente sem título'; const id=`INC-${crypto.randomBytes(3).toString('hex').toUpperCase()}`; await addRecord('incidents',{id,title,status:'open',createdAt:now(),actor:ctx.sender}); return ctx.reply(tag(`🚨 Incidente *${id}* aberto.`)); }
        if (action === 'resolveincident') { const id=arg0(ctx); await updateCollection('incidents',d=>{const x=(d.items||[]).find(i=>i.id===id);if(x)x.status='resolved',x.resolvedAt=now();return d;},{items:[]}); return ctx.reply(tag(`🚨 Incidente ${id||'?'} marcado como resolvido.`)); }
        if (action === 'analytics') return ctx.reply(tag(analyticsText(platformAnalytics())));
        if (action === 'topcommands') { const m=readCollection('metrics',{commands:[]}); const top=(m.commands||[]).slice(0,15); return ctx.reply(tag(top.length?top.map((x,i)=>`${i+1}. ${x.name} — ${x.calls||0}`).join('\n'):'Sem métricas persistidas.')); }
        if (action === 'search') { const term=q(ctx).toLowerCase(); if(term.length<2) throw new ValidationError('Informe ao menos 2 caracteres.'); const hits=[]; for(const [c,n] of Object.entries(collectionSummary())) { const d=readCollection(c,null); const s=JSON.stringify(d||'').toLowerCase(); if(s.includes(term)) hits.push(`${c} (${n})`); } return ctx.reply(tag(hits.length?`🔎 ${hits.join('\n')}`:'Nada encontrado.')); }
        if (action === 'groupsearch') { const term=q(ctx).toLowerCase(); const d=readCollection('groups',{byId:{}}); const hits=Object.values(d.byId||{}).filter(x=>JSON.stringify(x).toLowerCase().includes(term)).slice(0,15); return ctx.reply(tag(hits.length?hits.map(x=>`• ${x.id||x.name||'grupo'}`).join('\n'):'Nenhum grupo encontrado.')); }
        if (action === 'usersearch') { const term=q(ctx).toLowerCase(); const d=readCollection('users',{byId:{}}); const hits=Object.values(d.byId||{}).filter(x=>JSON.stringify(x).toLowerCase().includes(term)).slice(0,15); return ctx.reply(tag(hits.length?hits.map(x=>`• ${x.id||x.name||'usuário'}`).join('\n'):'Nenhum usuário encontrado.')); }
        if (action === 'profile') { const u=readCollection('users',{byId:{}}).byId?.[t]; return ctx.reply(tag(u?JSON.stringify(u,null,2):`👻 Perfil ${t} não encontrado.`)); }
        if (action === 'prefs') { const p=getKV('preferences',t,{}); return ctx.reply(tag(`⚙️ Preferências de ${t}:\n${JSON.stringify(p,null,2)}`)); }
        if (action === 'setpref') { const k=args[0],v=args.slice(1).join(' '); if(!k||!v) throw new ValidationError('Use setpreferencia chave valor.'); const p=getKV('preferences',t,{}); p[k]=v; await setKV('preferences',t,p); return ctx.reply(tag('⚙️ Preferência salva.')); }
        if (action === 'notify') { const text=q(ctx); if(!text) throw new ValidationError('Informe a mensagem.'); await addRecord('notifications',{id:`NT-${Date.now().toString(36)}`,userId:t,text,read:false,at:now()}); return ctx.reply(tag(`🔔 Notificação registrada para ${t}.`)); }
        if (action === 'notifications') { const a=records('notifications').filter(x=>x.userId===t).slice(-20).reverse(); return ctx.reply(tag(a.length?a.map(x=>`${x.read?'✓':'•'} ${x.text}`).join('\n'):'Sem notificações.')); }
        if (action === 'clearnotifications') { await updateCollection('notifications',d=>{d.items=(d.items||[]).filter(x=>x.userId!==t);return d;},{items:[]}); return ctx.reply(tag('🔔 Notificações limpas.')); }
        if (action === 'reputation') { const u=readCollection('reputation',{byId:{}}).byId?.[t]; return ctx.reply(tag(`⭐ Reputação: *${u?.score??0}*`)); }
        if (action === 'setreputation') { const n=Number(args[0]); if(!Number.isFinite(n)) throw new ValidationError('Informe um número.'); await updateCollection('reputation',d=>{d.byId ||= {};d.byId[t]={...(d.byId[t]||{}),score:n,updatedAt:now()};return d;},{byId:{}}); return ctx.reply(tag(`⭐ Reputação de ${t}: *${n}*`)); }
        if (action === 'achievement') { const a=q(ctx)||'Conquista administrativa'; await addRecord('achievements',{userId:t,title:a,at:now(),source:'owner'}); return ctx.reply(tag(`🎖️ Conquista registrada para ${t}.`)); }
        if (action === 'achievements') { const a=records('achievements').filter(x=>x.userId===t).slice(-30); return ctx.reply(tag(a.length?a.map(x=>`🎖️ ${x.title}`).join('\n'):'Nenhuma conquista.')); }
        if (action === 'season') return ctx.reply(tag(`🏆 Temporada ativa: *${getKV('season','active','Nenhuma')}*`));
        if (action === 'setseason') { const v=q(ctx)||arg0(ctx); if(!v) throw new ValidationError('Informe o nome da temporada.'); await setKV('season','active',v); return ctx.reply(tag(`🏆 Temporada: *${v}*`)); }
        if (action === 'historicalrank') { const v=q(ctx)||'snapshot'; await addRecord('ranking_history',{at:now(),label:v}); return ctx.reply(tag('🏆 Snapshot de ranking registrado.')); }
        if (action === 'record') { const label=args[0], value=Number(args[1]); if(!label||!Number.isFinite(value)) throw new ValidationError('Use record nome valor.'); await addRecord('records',{userId:t,label,value,at:now()}); return ctx.reply(tag(`📈 Recorde ${label}: ${value}`)); }
        if (action === 'records') { const a=records('records').filter(x=>x.userId===t).slice(-20).reverse(); return ctx.reply(tag(a.length?a.map(x=>`${x.label}: ${x.value}`).join('\n'):'Sem recordes.')); }
        if (action === 'progress') { const p=getKV('progress',t,{}); return ctx.reply(tag(`📈 ${t}\n${JSON.stringify(p,null,2)}`)); }
        if (action === 'setprogress') { const k=args[0],v=Number(args[1]); if(!k||!Number.isFinite(v)) throw new ValidationError('Use setprogresso chave número.'); const p=getKV('progress',t,{}); p[k]=v; await setKV('progress',t,p); return ctx.reply(tag('📈 Progresso atualizado.')); }
        if (action === 'vipinfo') { const u=readCollection('users',{byId:{}}).byId?.[t]; return ctx.reply(tag(`💎 VIP: ${u?.premium?.active?'ATIVO':'INATIVO'}${u?.premium?.until?`\nAté: ${new Date(u.premium.until).toLocaleString('pt-BR')}`:''}`)); }
        if (action === 'vipset') { const days=Math.max(0,Number(args[0])||30); await updateCollection('users',d=>{d.byId ||= {};const u=d.byId[t]||{id:t};u.premium={...(u.premium||{}),active:days>0,until:days?now()+days*86400000:0,plan:'owner'};d.byId[t]=u;return d;},{byId:{}}); return ctx.reply(tag(`💎 VIP de ${t}: ${days?`${days} dias`:'OFF'}`)); }
        if (action === 'claninfo') { const c=readCollection('clans',{byId:{}}).byId?.[arg0(ctx)]; return ctx.reply(tag(c?JSON.stringify(c,null,2):'Clã não encontrado.')); }
        if (action === 'clanset') { const id=arg0(ctx)||'global'; await setKV('clan_settings',id,q(ctx)||'active'); return ctx.reply(tag(`🏰 Configuração do clã ${id} salva.`)); }
        if (action === 'triagecfg') { return ctx.reply(tag(`⚖️ Triagem global: decisão individual, sem votação.\nAnálise de imagem: ${getKV('triage_policy','imageAnalysis',true)?'ON':'OFF'}\nAuditoria: ON`)); }
        if (action === 'triageimage') { const v=args[0]; if(v) await setKV('triage_policy','imageAnalysis',bool(v)); return ctx.reply(tag(`🖼️ Análise de imagem: *${getKV('triage_policy','imageAnalysis',true)?'ON':'OFF'}*`)); }
        if (action === 'triagelog') { const d=readCollection('triage',{byId:{}}); const a=Object.values(d.byId||{}).slice(-15); return ctx.reply(tag(a.length?a.map(x=>`${x.id} • ${x.state} • ${x.userId}`).join('\n'):'Sem triagens.')); }
        if (action === 'triagequeue') { const d=readCollection('triage',{byId:{}}); const a=Object.values(d.byId||{}).filter(x=>['pending','running','judging'].includes(x.state)); return ctx.reply(tag(`⚖️ Fila global: *${a.length}*`)); }
        if (action === 'blackstats') { const d=readCollection('blacklist',{byId:{}}); return ctx.reply(tag(`🚫 Entradas: *${Object.keys(d.byId||{}).length}*`)); }
        if (action === 'blackhistory') { const a=records('blacklist_audit').slice(-20).reverse(); return ctx.reply(tag(a.length?a.map(x=>`${x.at} • ${x.action} • ${x.userId}`).join('\n'):'Sem histórico dedicado.')); }
        if (action === 'blackexport') { const d=readCollection('blacklist',{byId:{}}); return ctx.reply(tag(JSON.stringify({count:Object.keys(d.byId||{}).length,ids:Object.keys(d.byId||{})},null,2))); }
        if (action === 'blackpolicy') return ctx.reply(tag(`🚫 Política: bloqueios devem ter motivo; temporários expiram; decisões de triagem são individuais; nenhuma votação automática.`));
        if (action === 'globalmode') return ctx.reply(tag(`🌐 Modo global: *${getKV('global','mode','normal')}*`));
        if (action === 'setglobalmode') { const v=arg0(ctx)||'normal'; await setKV('global','mode',v); return ctx.reply(tag(`🌐 Modo global: *${v}*`)); }
        if (action === 'commandblock') { const v=getKV('blocked_commands','all',{}); return ctx.reply(tag(JSON.stringify(v,null,2))); }
        if (action === 'setcommandblock') { const c=arg0(ctx); if(!c) throw new ValidationError('Informe comando. Use on/off.'); const map=getKV('blocked_commands','all',{}); map[c]=args[1]===undefined?true:bool(args[1]); await setKV('blocked_commands','all',map); return ctx.reply(tag(`⛔ ${c}: ${map[c]?'BLOQUEADO':'LIBERADO'}`)); }
        if (action === 'limits') return ctx.reply(tag(JSON.stringify(readCollection('limits',{values:{}}),null,2)));
        if (action === 'setlimit') { const k=args[0],v=Number(args[1]); if(!k||!Number.isFinite(v)) throw new ValidationError('Use setlimite chave número.'); await setKV('limits',k,v); return ctx.reply(tag(`⏱️ Limite ${k}: ${v}`)); }
        if (action === 'cacheinfo') return ctx.reply(tag(`🧠 NODE_OPTIONS: ${process.env.NODE_OPTIONS||'padrão'}\nHeap usado: ${Math.round(process.memoryUsage().heapUsed/1024/1024)} MB`));
        if (action === 'cacheclear') { globalThis.__fantasmaV2Ready=false; return ctx.reply(tag('🧠 Sinalizador de cache reiniciado.')); }
        if (action === 'memory') { const m=process.memoryUsage(); return ctx.reply(tag(`🧠 RSS ${Math.round(m.rss/1024/1024)} MB\nHeap ${Math.round(m.heapUsed/1024/1024)}/${Math.round(m.heapTotal/1024/1024)} MB`)); }
        if (action === 'process') return ctx.reply(tag(`PID ${process.pid}\nUptime ${Math.round(process.uptime())}s\nPlatform ${process.platform}/${process.arch}`));
        if (action === 'version') return ctx.reply(tag(`📦 Fantasminha ${config.botVersion}\nNode ${process.version}\nOS ${process.platform}`));
        if (action === 'dbfiles') { const l=fs.readdirSync(DB_ROOT).filter(x=>x.endsWith('.json')); return ctx.reply(tag(l.join('\n')||'Banco vazio.')); }
        if (action === 'dbcheck') { const bad=[]; for(const f of fs.readdirSync(DB_ROOT).filter(x=>x.endsWith('.json'))){try{JSON.parse(fs.readFileSync(path.join(DB_ROOT,f),'utf8'))}catch{bad.push(f)}} return ctx.reply(tag(bad.length?`❌ Inválidos:\n${bad.join('\n')}`:'✅ Todos os JSONs estão válidos.')); }
        if (action === 'dbstats') return ctx.reply(tag(JSON.stringify(collectionSummary(),null,2)));
        if (action === 'dbbackup') return ctx.reply(tag(`💾 ${backupDatabase()}`));
        if (action === 'loginfo') return ctx.reply(tag(`📋 Logs: ${path.join(config.root,'logs')}`));
        if (action === 'envinfo') return ctx.reply(tag(JSON.stringify(safeEnv(),null,2)));
        if (action === 'featureaudit') return ctx.reply(tag(`🚩 ${JSON.stringify(config.features,null,2)}\n\nOverrides: ${JSON.stringify(readCollection('owner_flags',{values:{}}).values||{},null,2)}`));
        if (action === 'commands') { const {listCommands}=await import('../../core/registry.js'); const a=listCommands(); return ctx.reply(tag(`🧩 ${a.length} comandos registrados.\n\n${a.slice(0,80).map(x=>`${x.name} — ${x.category}`).join('\n')}`)); }
        if (action === 'commandinfo') { const {getCommand}=await import('../../core/registry.js'); const c=getCommand(arg0(ctx)); return ctx.reply(tag(c?JSON.stringify({name:c.name,aliases:c.aliases,category:c.category,permission:c.permission,description:c.description,usage:c.usage},null,2):'Comando não encontrado.')); }
        if (action === 'category') { const {listCommands}=await import('../../core/registry.js'); const a=listCommands({category:arg0(ctx)}); return ctx.reply(tag(a.length?a.map(x=>x.name).join(', '):'Categoria vazia.')); }
        if (action === 'aliasinfo') { const {getCommand}=await import('../../core/registry.js'); const c=getCommand(arg0(ctx)); return ctx.reply(tag(c?`${c.name}: ${c.aliases.join(', ')||'sem aliases'}`:'Comando não encontrado.')); }
        if (action === 'coretest') { const {validateRegistry,registryStats}=await import('../../core/registry.js'); const v=validateRegistry(); return ctx.reply(tag(`${v.ok?'✅':'❌'} Registry\n${JSON.stringify(registryStats())}`)); }
        if (action === 'dryrun') return ctx.reply(tag(`🧪 DRY-RUN OK\nOperação: ${q(ctx)||'não informada'}\nNenhum dado foi alterado.`));
        if (action === 'lockinfo') { const l=fs.existsSync(path.join(DB_ROOT,'.locks'))?fs.readdirSync(path.join(DB_ROOT,'.locks')):[]; return ctx.reply(tag(l.length?l.join('\n'):'Sem locks ativos.')); }
        if (action === 'clearlocks') { const dir=path.join(DB_ROOT,'.locks'); let n=0; if(fs.existsSync(dir)) for(const x of fs.readdirSync(dir)){const p=path.join(dir,x);try{const st=fs.statSync(p);if(now()-st.mtimeMs>120000){fs.rmSync(p,{recursive:true,force:true});n++}}catch{}} return ctx.reply(tag(`🔐 ${n} locks antigos removidos.`)); }
        if (action === 'auditcheck') { const a=records('audit'); const valid=a.filter(x=>x.id&&x.at&&x.action).length===a.length; return ctx.reply(tag(valid?'🩺 Auditoria íntegra.':`❌ ${a.length-valid} eventos inválidos.`)); }
        if (action === 'security') return ctx.reply(tag('🛡️ Segurança: permissões por cargo, ownerOnly, locks atômicos, auditoria, anti-crash e validação do registry.'));
        if (action === 'rateinfo') return ctx.reply(tag('⏱️ Rate limit: cooldown por comando no registry + antiflood do pipeline legado.'));
        if (action === 'queue') return ctx.reply(tag('🚌 Fila: persistência de eventos/jobs disponível; fila de execução permanece no núcleo do bot.'));
        if (action === 'metricsreset') { globalThis.__fantasminhaMetricsReset = now(); return ctx.reply(tag('📊 Métricas em memória marcadas para reset.')); }
        if (action === 'incidentclear') { const cutoff=now()-7*86400000; await updateCollection('incidents',d=>{d.items=(d.items||[]).filter(x=>x.status!=='resolved'||x.resolvedAt>cutoff);return d;},{items:[]}); return ctx.reply(tag('🚨 Incidentes resolvidos antigos limpos.')); }
        if (action === 'jobsstats') { const a=records('jobs'); return ctx.reply(tag(`⏱️ Jobs: ${a.length}\nAtivos: ${a.filter(x=>x.enabled).length}`)); }
        if (action === 'notifytest') { await addRecord('notifications',{id:`NT-${Date.now().toString(36)}`,userId:ctx.sender,text:'Notificação de teste do Fantasminha.',read:false,at:now()}); return ctx.reply(tag('🔔 Teste criado.')); }
        if (action === 'clearprefs') { await setKV('preferences',t,{}); return ctx.reply(tag('⚙️ Preferências limpas.')); }
        if (action === 'reputationtop') { const d=readCollection('reputation',{byId:{}}); const a=Object.entries(d.byId||{}).sort((a,b)=>(b[1].score||0)-(a[1].score||0)).slice(0,10); return ctx.reply(tag(a.length?a.map(([id,x],i)=>`${i+1}. ${id} — ${x.score||0}`).join('\n'):'Sem reputações.')); }
        if (action === 'achievementstats') { const a=records('achievements'); return ctx.reply(tag(`🎖️ ${a.length} conquistas registradas.`)); }
        if (action === 'seasonstats') { const a=records('ranking_history'); return ctx.reply(tag(`🏆 ${a.length} snapshots históricos.`)); }
        if (action === 'progresstop') { const d=readCollection('progress',{values:{}}); const a=Object.entries(d.values||{}).slice(0,10); return ctx.reply(tag(a.length?a.map(([id,x])=>`${id} — ${JSON.stringify(x)}`).join('\n'):'Sem progressão.')); }
        if (action === 'triagepolicy') return ctx.reply(tag('⚖️ Conselho do Limbo: julgamento individual humano; sem votação; histórico preservado; justificativa obrigatória na reprovação.'));
        if (action === 'triageimagecfg') return ctx.reply(tag(`🖼️ Carteirinha: pergunta tipada de imagem + OCR/análise + comparação com respostas. Resultado é sinal de apoio à moderação, não prova de identidade.`));
        if (action === 'blackpolicyset') { const v=q(ctx)||'motivo-obrigatorio|temporario-expira|sem-votacao'; await setKV('blacklist_policy','default',v); return ctx.reply(tag(`🚫 Política salva: ${v}`)); }
        if (action === 'report') return ctx.reply(tag(`📊 *RELATÓRIO*\nVersão: ${config.botVersion}\nComandos: ${(await import('../../core/registry.js')).listCommands().length}\nDB: ${Object.keys(collectionSummary()).length} coleções\nAuditoria: ${records('audit').length}\nIncidentes abertos: ${records('incidents').filter(x=>x.status==='open').length}`));
        if (action === 'exportconfig') return ctx.reply(tag(`💾 Configuração segura:\n${JSON.stringify({features:config.features,prefix:config.prefix,botVersion:config.botVersion,env:safeEnv()},null,2)}`));
        if (action === 'maintenance') { const v=bool(arg0(ctx)); await setKV('global','maintenance',v); return ctx.reply(tag(`🛠️ Manutenção: *${v?'ON':'OFF'}*`)); }
        if (action === 'confirm') return ctx.reply(tag('🛡️ Operações destrutivas exigem comando explícito e backup prévio. Nenhum comando novo desta camada apaga banco inteiro automaticamente.'));
        if (action === 'ownerhelp') {
          const text=defs.map(([n,,d],i)=>`${String(i+1).padStart(3,'0')}. ${config.prefix}${n} — ${d}`).join('\n');
          return ctx.reply(tag(`👑 *OWNER POWER — 100 COMANDOS*\n\n${text}`));
        }
        return ctx.reply(tag('Comando reconhecido, mas ação não implementada.'));
      }
    });
  }
  await audit('ownerPower.register', {sender:'system'}, {commands:defs.length});
  return defs.length;
}
export const OWNER_POWER_COMMANDS = defs.map(x=>x[0]);
export default { register };
