/**
 * Plugin: Jogos do Submundo (com placar)
 */
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../../core/config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../../..');

let extra = null;
async function getExtra() {
  if (extra) return extra;
  try {
    extra = await import(path.join(ROOT, 'dados/src/funcs/utils/fantasminhaExtra.js'));
  } catch {
    extra = {};
  }
  return extra;
}

function dbDir() {
  return path.join(ROOT, 'dados', 'src', 'database');
}

async function replyText(ctx, text) {
  if (text) await ctx.reply(`× 👻 FANTASMINHA\n\n${text}`);
}

export async function register() {
  if (!config.features.games) return;
  const fx = await getExtra();
  const base = () => dbDir();

  registerCommand({
    name: 'forcaalem',
    aliases: ['forca'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    description: 'Forca do além',
    handler: async (ctx) => {
      await replyText(ctx, fx.startForca?.(base(), ctx.from, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'letra',
    aliases: ['chuteletra'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    description: 'Chutar letra na forca',
    handler: async (ctx) => {
      await replyText(ctx, fx.playForca?.(base(), ctx.from, ctx.q || ctx.args?.[0], ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'quizalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    description: 'Quiz do além',
    handler: async (ctx) => {
      await replyText(ctx, fx.startQuiz?.(base(), ctx.from));
    }
  });

  registerCommand({
    name: 'respostaquiz',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      await replyText(ctx, fx.answerQuiz?.(base(), ctx.from, ctx.q, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'roletaalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 5,
    handler: async (ctx) => {
      await replyText(ctx, fx.roletaAlem?.(base(), ctx.from, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'placaralem',
    aliases: ['rankalem'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      await replyText(ctx, fx.placarAlem?.(base(), ctx.from));
    }
  });

  registerCommand({
    name: 'batalhaalmas',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 5,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (target) {
        await replyText(ctx, fx.batalhaDesafiar?.(base(), ctx.from, ctx.sender, ctx.pushname, target, ctx.mentionName));
      } else {
        await replyText(ctx, fx.batalhaAlmas?.(ctx.args?.[0], ctx.args?.[1] || ctx.pushname));
      }
    }
  });

  registerCommand({
    name: 'aceitarbatalha',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      await replyText(ctx, fx.batalhaAceitar?.(base(), ctx.from, ctx.sender));
    }
  });

  registerCommand({
    name: 'recusarbatalha',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      await replyText(ctx, fx.batalhaRecusar?.(base(), ctx.from));
    }
  });

  registerCommand({
    name: 'torrelimbo',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 4,
    handler: async (ctx) => {
      await replyText(ctx, fx.torreLimbo?.(base(), ctx.from, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'memoriafantasma',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      await replyText(ctx, fx.startMemoria?.(base(), ctx.from) || fx.memoriaFantasma?.());
    }
  });

  registerCommand({
    name: 'respostamemoria',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      await replyText(ctx, fx.answerMemoria?.(base(), ctx.from, ctx.q, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'juizfinal',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      const opt = (ctx.q || '').toLowerCase();
      if (['culpado', 'inocente', 'limbo'].includes(opt)) {
        await replyText(ctx, fx.juizVotar?.(base(), ctx.from, opt, ctx.sender, ctx.pushname));
      } else {
        await replyText(ctx, fx.juizStart?.(base(), ctx.from, ctx.mentionName || ctx.q || 'réu'));
      }
    }
  });

  registerCommand({
    name: 'encerrarjuiz',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      await replyText(ctx, fx.juizEncerrar?.(base(), ctx.from));
    }
  });

  const mg = await import('../../services/minigames.js');

  registerCommand({
    name: 'wordle',
    aliases: ['termo'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      if (!ctx.q) {
        const s = await mg.wordleStart(ctx.from);
        await replyText(ctx, `🟩 *Wordle do Além*\nPalavra com *${s.len}* letras. ${s.max} tentativas.\n×wordle <chute>`);
        return;
      }
      const r = await mg.wordleGuess(ctx.from, ctx.q, ctx.sender, ctx.pushname);
      let t = `${r.pattern}\nTentativa ${r.tries}/${r.max}`;
      if (r.win) t += `\n🏆 Acertou! +150 GC`;
      if (r.lose) t += `\n💀 Era *${r.word}*`;
      await replyText(ctx, t);
    }
  });

  registerCommand({
    name: 'stop',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 5,
    handler: async (ctx) => {
      const letter = await mg.stopStart(ctx.from, ctx.q);
      await replyText(ctx, `🛑 *STOP* letra *${letter}*\n90s para responder:\n×stopresp nome:X animal:Y alma:Z lugar:W objeto:V`);
    }
  });

  registerCommand({
    name: 'stopresp',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      const r = await mg.stopAnswer(ctx.from, ctx.sender, ctx.pushname, ctx.q || '');
      await replyText(ctx, `✅ Resposta na letra *${r.letter}* registrada.`);
    }
  });

  registerCommand({
    name: 'stopfim',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      const r = await mg.stopEnd(ctx.from);
      const lines = Object.values(r.scores || {}).sort((a,b)=>b.pts-a.pts).map((s,i)=>`${i+1}. ${s.name}: ${s.pts}`);
      await replyText(ctx, `🛑 STOP *${r.letter}* encerrado\n${lines.join('\n') || 'Ninguém'}`);
    }
  });

  registerCommand({
    name: 'bj',
    aliases: ['blackjack'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      const r = await mg.bjStart(ctx.sender, ctx.q, ctx.pushname);
      await replyText(ctx, `🃏 *Blackjack*\nVocê: ${r.player} (${r.pVal})\nDealer: ${r.dealerShow} ?\n×bjhit · ×bjstand`);
    }
  });

  registerCommand({
    name: 'bjhit',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      const r = await mg.bjHit(ctx.sender);
      let t = `🃏 ${r.player} (${r.val})`;
      if (r.bust) t += `\n💥 Bust! Perdeu ${r.bet} GC`;
      await replyText(ctx, t);
    }
  });

  registerCommand({
    name: 'bjstand',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      const r = await mg.bjStand(ctx.sender);
      await replyText(ctx, `🃏 Você ${r.player} (${r.pv}) vs Dealer ${r.dealer} (${r.dv})\n${r.win ? '🏆 +'+r.win+' GC' : '💀 Perdeu '+r.bet+' GC'}`);
    }
  });

}

export default { register };
