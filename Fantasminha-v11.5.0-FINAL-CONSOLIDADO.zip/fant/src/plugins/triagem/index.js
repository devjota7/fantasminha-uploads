import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import config from '../../core/config.js';
import { readCollection } from '../../database/store.js';
import {
  beginTriageBuilder, deleteTriageConfiguration, getSettings, saveSettings, getTriage,
  triageFullText, triageSummaryText, judgeTriage, cancelActiveTriage, triageStats,
  blacklistCheck, setBlacklist, removeBlacklist, blacklistList, blacklistInfo,
  blacklistStats, STATES, memberJoined, createTriage, rejectionHistory,
  beginTriageEdit, QUESTION_TYPES
} from '../../services/triage.js';

const prefix = () => config.prefix || '×';
const idOf = u => String(u || '').split('@')[0].split(':')[0];
const target = ctx => ctx.mentioned?.[0] || null;
const parseId = q => String(q || '').trim().split(/\s+/)[0].toUpperCase();
const isBot = (id, bot) => idOf(id) === idOf(bot);
const box = (title, body) => `╭─👻 *FANTASMINHA • ${title}* ─╮\n${body}\n╰────────────────────────────╯`;
const typeName = t => ({text:'Texto',date:'Data',number:'Número',yesno:'Sim/Não',choice:'Escolha',image:'Foto + IA'})[t] || t;

function questionsView(s) {
  if (!s.questions.length) return '│ Nenhuma pergunta configurada.';
  return s.questions.map((q, i) => `│ ${String(i + 1).padStart(2,'0')} • *${typeName(q.type)}* • ${q.question}`).join('\n');
}

export async function register() {
  registerCommand({
    name:'triagemcriar', aliases:['triagemcria'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    description:'Abre o assistente visual para criar a triagem',
    handler:async ctx => {
      await beginTriageBuilder(ctx.from, ctx.sender);
      return ctx.reply(box('CRIADOR', '│ 🧭 Vamos montar a triagem do grupo.\n│\n│ Você poderá criar até *20 perguntas*.\n│ Cada pergunta pode ser texto, data, número, sim/não, escolha ou foto.\n│\n│ ▶️ *1* Continuar\n│ ❌ *2* Cancelar\n│\n│ _Envie somente o número._'));
    }
  });

  registerCommand({
    name:'triagemexcluir', aliases:['triagemreset'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => {
      await deleteTriageConfiguration(ctx.from);
      return ctx.reply(box('CONFIGURAÇÃO REMOVIDA', '│ 🗑️ Perguntas, regras e rascunhos da triagem foram removidos.\n│\n│ 🔴 A triagem ficou desativada.\n│\n│ Para começar novamente:\n│ *'+prefix()+'triagemcriar*'));
    }
  });

  registerCommand({
    name:'setpergunta', aliases:['editarpergunta','editpergunta'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => {
      const s=await getSettings(ctx.from); const n=Number(ctx.args?.[0]);
      if(!s.questions.length) throw new ValidationError('Nenhuma pergunta configurada. Use '+prefix()+'triagemcriar.');
      if(!Number.isInteger(n)||n<1||n>s.questions.length)
        return ctx.reply(box('PERGUNTAS', questionsView(s)+`\n│\n│ ✏️ Para editar: *${prefix()}setpergunta número*`));
      const r=await beginTriageEdit(ctx.from,ctx.sender,n);
      if(!r.ok) throw new ValidationError('Pergunta não encontrada.');
      return ctx.reply(box('EDITAR PERGUNTA '+n, `│ Atual: *${r.question.question}*\n│ Tipo: *${typeName(r.question.type)}*\n│\n│ ✏️ Envie a nova pergunta.\n│ _Use ${prefix()}cancelar para sair._`));
    }
  });

  registerCommand({
    name:'triagemativar', aliases:['triagemon'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => {
      const s=await getSettings(ctx.from); if(!s.questions.length) throw new ValidationError('Nenhuma pergunta configurada. Use '+prefix()+'triagemcriar.');
      await saveSettings(ctx.from,{enabled:true});
      return ctx.reply(box('TRIAGEM ATIVA', `│ 🟢 Entrada automática ativada.\n│\n│ 📝 Perguntas: *${s.questions.length}/20*\n│ 🔐 Cada novo membro recebe um código exclusivo.\n│ 📩 As respostas são feitas no PV.\n│ ⚖️ A ficha segue para análise da equipe.`));
    }
  });

  registerCommand({
    name:'triagemdesativar', aliases:['triagemoff'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => { await saveSettings(ctx.from,{enabled:false}); return ctx.reply(box('TRIAGEM DESATIVADA','│ 🔴 Novos membros não receberão novas triagens.\n│\n│ ℹ️ Sessões já abertas continuam preservadas.')); }
  });

  registerCommand({
    name:'triagemcobrar', aliases:['cobrartodos'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:4,
    description:'Gera triagem individual para os membros atuais',
    handler:async ctx => {
      const s=await getSettings(ctx.from); if(!s.questions.length) throw new ValidationError('Nenhuma pergunta configurada.');
      const bot=ctx.botJid||''; const members=(ctx.groupParticipants||[]).filter(u=>!isBot(u,bot));
      if(!members.length) throw new ValidationError('Não consegui obter os membros deste grupo.');
      const rows=[]; for(const u of members){const c=await createTriage(ctx.from,u,{botJid:bot,force:true}); if(c.ok) rows.push(`│ 👤 @${idOf(u)}\n│ 🔗 ${c.link}\n│ 🪪 ${c.code}`);}
      return ctx.reply(box('COBRANÇA INDIVIDUAL', `│ 📋 ${rows.length} membro(s) receberam uma triagem.\n│\n${rows.join('\n│\n')}`), {mentions:members});
    }
  });

  registerCommand({
    name:'triagemficha', aliases:['fichatriagem','ficha'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => { const id=parseId(ctx.q),t=await getTriage(id); if(!id||!t||t.groupId!==ctx.from) throw new ValidationError('ID de triagem não encontrado neste grupo.'); return ctx.reply(triageFullText(t,(await rejectionHistory(t.userId)).length),{mentions:[t.userId]}); }
  });

  registerCommand({
    name:'triagemconectar', aliases:['triagemarquivo'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => { const gid=String(ctx.args?.[0]||'').trim(); if(!gid.endsWith('@g.us')) throw new ValidationError('Informe o ID do grupo destino terminando em @g.us.'); await saveSettings(ctx.from,{archiveGroupId:gid}); return ctx.reply(box('ARQUIVO CONECTADO',`│ 🔗 Destino: *${gid}*\n│\n│ 📚 Novas fichas concluídas também serão arquivadas nesse grupo.`)); }
  });

  registerCommand({name:'triagemdesconectar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{await saveSettings(ctx.from,{archiveGroupId:null});return ctx.reply(box('ARQUIVO DESCONECTADO','│ 🔌 O envio automático para o grupo de arquivo foi removido.'));}});

  registerCommand({
    name:'setperguntas', aliases:['triagemperguntas'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx => { const raw=String(ctx.q||'').trim(); if(!raw) throw new ValidationError('Informe as perguntas separadas por |.'); const questions=raw.split('|').map(x=>x.trim()).filter(Boolean).slice(0,20).map((q,i)=>({id:'q_'+(i+1),type:'text',required:true,question:q,order:i+1})); await saveSettings(ctx.from,{questions,maxQuestions:20,enabled:false}); return ctx.reply(box('PERGUNTAS SALVAS',`│ ✅ ${questions.length}/20 perguntas cadastradas.\n│\n│ 🔴 A triagem foi deixada desativada por segurança.\n│ ▶️ Ative com *${prefix()}triagemativar*.`)); }
  });

  registerCommand({
    name:'triagempergunta', aliases:['addpergunta'], category:'triagem', plugin:'triagem',
    permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    description:'Editor completo de perguntas da triagem',
    handler:async ctx=>{
      const args=ctx.args||[], sub=String(args[0]||'help').toLowerCase(), s=await getSettings(ctx.from);
      const list=()=>questionsView(s)+`\n│\n│ Total: *${s.questions.length}/20*`;
      if(sub==='help') return ctx.reply(box('EDITOR DE PERGUNTAS',`│ 📚 *COMANDOS*\n│ ${prefix()}triagempergunta lista\n│ ${prefix()}triagempergunta add text Pergunta\n│ ${prefix()}triagempergunta editar 1 Nova pergunta\n│ ${prefix()}triagempergunta remover 1\n│ ${prefix()}triagempergunta mover 3 1\n│ ${prefix()}triagempergunta duplicar 2\n│ ${prefix()}triagempergunta tipo 1 choice\n│ ${prefix()}triagempergunta opcoes 1 A|B|C\n│ ${prefix()}triagempergunta obrigatoria 1 on\n│ ${prefix()}triagempergunta ia 1 on\n│ ${prefix()}triagempergunta ocr 1 on\n│ ${prefix()}triagempergunta comparar 1 q1|q2\n│ ${prefix()}triagempergunta confianca 1 high\n│ ${prefix()}triagempergunta exportar\n│ ${prefix()}triagempergunta importar JSON`));
      if(sub==='lista') return ctx.reply(box('PERGUNTAS',list()));
      const idx=n=>Number(n)-1;
      const validIndex=i=>Number.isInteger(i)&&i>=0&&i<s.questions.length;
      if(sub==='add'){
        const type=String(args[1]||'text').toLowerCase(); if(!Object.values(QUESTION_TYPES).includes(type)) throw new ValidationError('Tipo inválido. Use text, date, number, yesno, choice ou image.');
        const question=String(args.slice(2).join(' ')||'').trim(); if(!question) throw new ValidationError('Informe o texto da pergunta.'); if(s.questions.length>=20) throw new ValidationError('Limite de 20 perguntas atingido.');
        const q={id:`q_${Date.now().toString(36)}`,type,required:true,question,order:s.questions.length+1}; if(type==='choice')q.choices=['Opção 1','Opção 2']; if(type==='image')q.analysis={enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low'};
        await saveSettings(ctx.from,{questions:[...s.questions,q],maxQuestions:20,enabled:false}); return ctx.reply(box('PERGUNTA ADICIONADA',`│ #${s.questions.length+1} • *${typeName(type)}*\n│ ${question}\n│\n│ 🔴 Triagem mantida desativada enquanto você configura.`));
      }
      if(['editar','edit'].includes(sub)){const i=idx(args[1]);const q=s.questions[i];if(!q)throw new ValidationError('Pergunta não encontrada.');const text=String(args.slice(2).join(' ')||'').trim();if(!text)throw new ValidationError('Informe o novo texto.');const questions=s.questions.map((x,n)=>n===i?{...x,question:text}:x);await saveSettings(ctx.from,{questions});return ctx.reply(box('PERGUNTA EDITADA',`│ #${i+1}\n│ ${text}`));}
      if(['remover','remove','del'].includes(sub)){const i=idx(args[1]);if(!validIndex(i))throw new ValidationError('Número de pergunta inválido.');const removed=s.questions[i];const questions=s.questions.filter((_,n)=>n!==i).map((x,n)=>({...x,order:n+1}));await saveSettings(ctx.from,{questions});return ctx.reply(box('PERGUNTA REMOVIDA',`│ 🗑️ #${i+1} • ${removed.question}\n│\n│ Restantes: *${questions.length}/20*`));}
      if(sub==='mover'){const from=idx(args[1]),to=idx(args[2]);if(!validIndex(from)||!Number.isInteger(to)||to<0||to>=s.questions.length)throw new ValidationError('Informe posições válidas.');const questions=[...s.questions];const [q]=questions.splice(from,1);questions.splice(to,0,q);await saveSettings(ctx.from,{questions:questions.map((x,n)=>({...x,order:n+1}))});return ctx.reply(box('ORDEM ATUALIZADA',questionsView(await getSettings(ctx.from))));}
      if(['duplicar','clone'].includes(sub)){const i=idx(args[1]);if(!validIndex(i))throw new ValidationError('Pergunta não encontrada.');if(s.questions.length>=20)throw new ValidationError('Limite de 20 perguntas atingido.');const copy={...s.questions[i],id:`q_${Date.now().toString(36)}`,choices:s.questions[i].choices?[...s.questions[i].choices]:undefined};const questions=[...s.questions,copy].map((x,n)=>({...x,order:n+1}));await saveSettings(ctx.from,{questions,enabled:false});return ctx.reply(box('PERGUNTA DUPLICADA',`│ Criada como #${questions.length}.\n│ ${copy.question}`));}
      if(sub==='tipo'){const i=idx(args[1]),type=String(args[2]||'').toLowerCase();if(!validIndex(i)||!Object.values(QUESTION_TYPES).includes(type))throw new ValidationError('Use: tipo número text|date|number|yesno|choice|image.');const q={...s.questions[i],type};if(type==='choice'&&!Array.isArray(q.choices))q.choices=['Opção 1','Opção 2'];if(type==='image'&&!q.analysis)q.analysis={enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low'};await saveSettings(ctx.from,{questions:s.questions.map((x,n)=>n===i?q:x),enabled:false});return ctx.reply(box('TIPO ALTERADO',`│ #${i+1} • *${typeName(type)}*`));}
      if(sub==='opcoes'){const i=idx(args[1]),choices=String(args.slice(2).join(' ')||'').split('|').map(x=>x.trim()).filter(Boolean).slice(0,20);if(!validIndex(i)||choices.length<2)throw new ValidationError('Informe ao menos 2 opções separadas por |.');const q={...s.questions[i],type:'choice',choices};await saveSettings(ctx.from,{questions:s.questions.map((x,n)=>n===i?q:x),enabled:false});return ctx.reply(box('OPÇÕES SALVAS',`│ #${i+1}\n│ ${choices.map((x,n)=>`${n+1}. ${x}`).join('\n│ ')}`));}
      if(sub==='obrigatoria'){const i=idx(args[1]),v=String(args[2]||'').toLowerCase();if(!validIndex(i)||!['on','off','sim','nao','não','1','0'].includes(v))throw new ValidationError('Use on/off.');const required=['on','sim','1'].includes(v);await saveSettings(ctx.from,{questions:s.questions.map((x,n)=>n===i?{...x,required}:x)});return ctx.reply(box('OBRIGATORIEDADE',`│ #${i+1}: *${required?'obrigatória':'opcional'}*`));}
      if(['ia','ocr','comparar','confianca'].includes(sub)){const i=idx(args[1]);if(!validIndex(i))throw new ValidationError('Pergunta não encontrada.');const q={...s.questions[i],analysis:{enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low',...(s.questions[i].analysis||{})}};if(sub==='ia'){const v=String(args[2]||'').toLowerCase();if(!['on','off','sim','não','nao','1','0'].includes(v))throw new ValidationError('Use on/off.');q.analysis.enabled=['on','sim','1'].includes(v);}if(sub==='ocr'){const v=String(args[2]||'').toLowerCase();if(!['on','off','sim','não','nao','1','0'].includes(v))throw new ValidationError('Use on/off.');q.analysis.ocr=['on','sim','1'].includes(v);}if(sub==='comparar'){q.analysis.compareQuestionIds=String(args.slice(2).join('')||'').split('|').map(x=>x.trim()).filter(Boolean);}if(sub==='confianca'){const v=String(args[2]||'').toLowerCase();if(!['low','medium','high'].includes(v))throw new ValidationError('Confiança: low, medium ou high.');q.analysis.confidenceFloor=v;}await saveSettings(ctx.from,{questions:s.questions.map((x,n)=>n===i?q:x)});return ctx.reply(box('ANÁLISE ATUALIZADA',`│ #${i+1}\n│ IA: *${q.analysis.enabled?'on':'off'}*\n│ OCR: *${q.analysis.ocr?'on':'off'}*\n│ Confiança mínima: *${q.analysis.confidenceFloor}*\n│ Comparação: *${q.analysis.compareQuestionIds.join(' | ')||'nenhuma'}*`));}
      if(sub==='exportar'){const payload=JSON.stringify({version:1,questions:s.questions,maxQuestions:s.maxQuestions},null,2);return ctx.reply(box('EXPORTAÇÃO','\n'+payload));}
      if(sub==='importar'){const raw=String(ctx.q||'').trim().replace(/^importar\s+/i,'');let parsed;try{parsed=JSON.parse(raw);}catch{throw new ValidationError('JSON inválido. Use o JSON exportado pelo próprio Fantasminha.');}const questions=Array.isArray(parsed)?parsed:parsed.questions;if(!Array.isArray(questions)||!questions.length)throw new ValidationError('O JSON não contém perguntas.');if(questions.length>20)throw new ValidationError('O máximo é 20 perguntas.');const cleanQuestions=questions.map((q,n)=>({id:q.id||`q_${Date.now().toString(36)}_${n}`,type:Object.values(QUESTION_TYPES).includes(q.type)?q.type:'text',required:q.required!==false,question:String(q.question||'').trim(),order:n+1,...(q.choices?{choices:q.choices.slice(0,20)}:{}),...(q.analysis?{analysis:q.analysis}: {})})).filter(q=>q.question);if(!cleanQuestions.length)throw new ValidationError('Nenhuma pergunta válida encontrada.');await saveSettings(ctx.from,{questions:cleanQuestions,maxQuestions:20,enabled:false});return ctx.reply(box('IMPORTAÇÃO CONCLUÍDA',`│ ✅ ${cleanQuestions.length}/20 perguntas importadas.\n│ 🔴 Triagem desativada para revisão.`));}
      return ctx.reply(box('EDITOR DE PERGUNTAS',`│ Comando desconhecido. Use *${prefix()}triagempergunta help* para ver todos os recursos.`));
    }
  });

  registerCommand({name:'verperguntas',aliases:['listarperguntas'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await getSettings(ctx.from);return ctx.reply(box('PERGUNTAS',questionsView(s)+`\n│\n│ Total: *${s.questions.length}/20*`));}});

  registerCommand({
    name:'triagemstatus', aliases:['triagem'], category:'triagem', plugin:'triagem', permission:Role.GROUP_ADMIN, groupOnly:true, cooldown:2,
    handler:async ctx=>{const s=await getSettings(ctx.from); const st=s.enabled?'🟢 ATIVA':'🔴 DESATIVADA'; return ctx.reply(box('PAINEL',`│ Status: *${st}*\n│ Perguntas: *${s.questions.length}/20*\n│ Arquivo: *${s.archiveGroupId?'🟢 conectado':'⚪ não conectado'}*\n│ Lembrete: *${s.reminderEnabled?'🟢 ativo':'🔴 desligado'}*\n│ Expiração: *${s.kickOnExpire?'🟠 remoção ativa':'⚪ sem remoção automática'}*\n│\n│ ⚙️ Criar: *${prefix()}triagemcriar*\n│ 📋 Perguntas: *${prefix()}verperguntas*\n│ 📊 Estatísticas: *${prefix()}triagemstats*\n│ 🧭 Ajuda: *${prefix()}triagemmenu*`));}
  });

  registerCommand({name:'filatriagem',aliases:['triagempedentes'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const d=readCollection('triage',{byId:{}});const a=Object.values(d.byId||{}).filter(t=>t.groupId===ctx.from&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(t.state)).sort((x,y)=>x.createdAt-y.createdAt);return ctx.reply(box('FILA',a.length?a.map((t,i)=>`│ ${i+1}. *${t.id}* • @${idOf(t.userId)}\n│    └ ${t.state}`).join('\n'):'│ 🟢 Fila vazia.'),{mentions:a.map(t=>t.userId)});}});

  registerCommand({name:'triagemstats',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const s=await triageStats(ctx.from);return ctx.reply(box('ESTATÍSTICAS',`│ 📦 Total: *${s.total}*\n│ 🟡 Pendentes: *${s.pending}*\n│ 🔵 Em andamento: *${s.running}*\n│ ⚖️ Julgamento: *${s.judging}*\n│ 🟢 Aprovadas: *${s.approved}*\n│ 🔴 Reprovadas: *${s.rejected}*\n│ ⚫ Expiradas: *${s.expired}*`));}});

  registerCommand({name:'conselho',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');return ctx.reply(box('CONSELHO',`${triageSummaryText(t,(await rejectionHistory(t.userId)).length)}\n\n⚖️ *${prefix()}aprovar ${id}*\n❌ *${prefix()}reprovar ${id} motivo`),{mentions:[t.userId]});}});

  registerCommand({name:'aprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'approve');if(!r.ok)throw new ValidationError(r.reason);return ctx.reply(box('APROVADA',`│ 🟢 Triagem *${id}* aprovada.\n│\n│ 👤 @${idOf(t.userId)}\n│ ⚖️ Analisada por: *${ctx.pushname||idOf(ctx.sender)}*`),{mentions:[t.userId]});}});

  registerCommand({name:'reprovar',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const id=parseId(ctx.q),reason=String(ctx.q).slice(id.length).trim(),t=await getTriage(id);if(!t||t.groupId!==ctx.from)throw new ValidationError('Triagem não encontrada.');const r=await judgeTriage(id,{id:ctx.sender,name:ctx.pushname||''},'reject',reason);if(!r.ok)throw new ValidationError(r.reason==='reason-required'?'Informe o motivo.':r.reason);return ctx.reply(box('REPROVADA',`│ 🔴 Triagem *${id}* reprovada.\n│\n│ 👤 @${idOf(t.userId)}\n│ 📝 Motivo: *${reason}*`),{mentions:[t.userId]});}});

  registerCommand({name:'cancelatriagem',category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>{const u=target(ctx);if(!u)throw new ValidationError('Mencione o usuário.');const t=await cancelActiveTriage(ctx.from,u,'cancelada pelo administrador');return ctx.reply(box('CANCELAMENTO',t?`│ 🟡 Triagem de @${idOf(u)} cancelada.`:'│ ⚪ Nenhuma triagem ativa encontrada.'),{mentions:[u]});}});

  registerCommand({
    name:'bl', aliases:['blacklist'], category:'triagem', plugin:'triagem', permission:Role.GROUP_ADMIN, cooldown:2,
    handler:async ctx=>{
      const sub=String(ctx.args?.[0]||'check').toLowerCase(); const u=target(ctx)||ctx.args?.[1]||ctx.sender;
      if(['list','stats'].includes(sub)){if(!ctx.isOwner)throw new ValidationError('Apenas o dono.');const r=sub==='list'?await blacklistList():await blacklistStats();return ctx.reply(box('BLACKLIST',JSON.stringify(r,null,2)));}
      if(['check','info'].includes(sub)){const e=await blacklistInfo(u);return ctx.reply(box('CONSULTA',e?`│ 🚫 @${idOf(u)} está bloqueado.\n│ 📝 ${e.reason}`:`│ 🟢 @${idOf(u)} não possui bloqueio ativo.`),{mentions:[u]});}
      if(!ctx.isOwner&&!ctx.isGroupAdmin)throw new ValidationError('Sem permissão.');
      if(['remove','del'].includes(sub))return ctx.reply(box('BLACKLIST',await removeBlacklist(u,ctx.sender)?'│ 🟢 Bloqueio removido.':'│ ⚪ Nenhum bloqueio ativo.'),{mentions:[u]});
      if(['add','perm','temp'].includes(sub)){const days=sub==='temp'?Number(ctx.args?.[2]):0;if(sub==='temp'&&(!Number.isFinite(days)||days<=0))throw new ValidationError('Informe a duração em dias.');const start=sub==='temp'?3:1;const reason=String(ctx.args?.slice(start).join(' ')||'').trim();if(reason.length<3)throw new ValidationError('Informe o motivo.');await setBlacklist(u,ctx.sender,reason,days*86400000,{source:'manual',level:'blacklist'});return ctx.reply(box('BLACKLIST',`│ 🚫 @${idOf(u)} bloqueado.\n│ 📝 ${reason}\n│ ⏱️ ${sub==='temp'?days+' dia(s)':'permanente'}`),{mentions:[u]});}
      throw new ValidationError('Use bl check/add/temp/remove/list/stats.');
    }
  });

  registerCommand({name:'triagemmenu',aliases:['triagemhelp'],category:'triagem',plugin:'triagem',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:2,handler:async ctx=>ctx.reply(box('CENTRAL DE CONTROLE',`│ 🧭 *CONFIGURAÇÃO*\n│ ${prefix()}triagemcriar\n│ ${prefix()}setperguntas\n│ ${prefix()}setpergunta 2\n│ ${prefix()}verperguntas\n│ ${prefix()}triagemativar / ${prefix()}triagemdesativar\n│\n│ 👥 *OPERAÇÃO*\n│ ${prefix()}triagemcobrar\n│ ${prefix()}filatriagem\n│ ${prefix()}triagemficha ID\n│ ${prefix()}conselho ID\n│ ${prefix()}aprovar ID\n│ ${prefix()}reprovar ID motivo\n│ ${prefix()}cancelatriagem @membro\n│\n│ 🗃️ *ARQUIVO*\n│ ${prefix()}triagemconectar ID_GRUPO\n│ ${prefix()}triagemdesconectar\n│\n│ 🛡️ *SEGURANÇA*\n│ ${prefix()}bl check @membro\n│ ${prefix()}bl add @membro motivo\n│ ${prefix()}bl temp @membro dias motivo\n│\n│ 📊 *VISÃO GERAL*\n│ ${prefix()}triagemstatus\n│ ${prefix()}triagemstats\n│ ${prefix()}triagemexcluir`))});
}

export { memberJoined };
export default { register };
