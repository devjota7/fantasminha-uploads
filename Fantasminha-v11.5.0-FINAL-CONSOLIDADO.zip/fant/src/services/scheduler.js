import { backupDatabase } from '../database/store.js';
import logger from '../core/logger.js';
import config from '../core/config.js';
import { syncWarStates } from './wars.js';

let timer = null;

export function startSchedulers() {
  if (timer) return;
  const hours = Number(process.env.BACKUP_EVERY_HOURS || 6);
  const ms = Math.max(1, hours) * 3600 * 1000;
  timer = setInterval(() => {
    try {
      const dest = backupDatabase();
      logger.info('scheduler', 'backup automático', { dest });
    } catch (e) {
      logger.error('scheduler', e.message);
    }
  }, ms);
  timer.unref?.();
  logger.info('scheduler', `backup a cada ${hours}h`);

  // Triagem: expiração e lembretes. O scheduler não depende do socket.
  const triageTimer = setInterval(async () => {
    try {
      const { expireSweep, reminderSweep } = await import('./triage.js');
      await expireSweep();
      await reminderSweep();
    } catch (e) { logger.error('triage', e.message); }
  }, 60_000);
  triageTimer.unref?.();

  // Estado das guerras: transições preparação → ativa → encerrada.
  const warTimer = setInterval(async () => {
    try {
      const changes = await syncWarStates();
      for (const change of changes) logger.info('wars', `guerra ${change.type}`, { warId: change.war?.id, type: change.war?.type });
    } catch (e) { logger.error('wars', e.message); }
  }, 30_000);
  warTimer.unref?.();

  // Campeonato Global do Além: mantém a fase persistente sem depender do WhatsApp/socket.
  const championshipTimer = setInterval(async () => {
    try { const { tick } = await import('./clanChampionship.js'); await tick(); } catch (e) { logger.error('championship', e.message); }
  }, 60_000);
  championshipTimer.unref?.();

  // premium expiry soft check hourly
  setInterval(async () => {
    try {
      const { readCollection, writeCollection } = await import('../database/store.js');
      const users = readCollection('users', { byId: {} });
      let changed = false;
      const now = Date.now();
      for (const u of Object.values(users.byId || {})) {
        if (u.premium?.active && u.premium.until && u.premium.until < now) {
          u.premium.active = false;
          changed = true;
        }
      }
      if (changed) writeCollection('users', users);
    } catch (e) {
      logger.error('scheduler', 'premium expiry: ' + e.message);
    }
  }, 3600 * 1000).unref?.();
}

export default { startSchedulers };
