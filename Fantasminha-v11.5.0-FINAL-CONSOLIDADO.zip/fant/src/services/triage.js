import crypto from 'node:crypto';
import fs from 'node:fs';
import { readCollection, updateCollection } from '../database/store.js';
import config from '../core/config.js';
import { analyzeTriageImage, downloadImage, persistTriageMedia, saveTriageImageFile, getImageMessage } from './triageImage.js';

export const MAX_QUESTIONS = 20;
export const DEFAULT_QUESTIONS = [];
export const DEFAULT_SETTINGS = Object.freeze({
  enabled:false, maxQuestions:20, questions:[], archiveGroupId:null,
  startTimeoutMs:3600000, completionTimeoutMs:86400000, judgeTimeoutMs:172800000,
  reminderAfterMs:1200000, reminderEnabled:true, kickOnExpire:false, restrictPending:false,
  publicMode:'summary', defaultRejectionLevel:'network', autoBlacklistCount:3,
  autoBlacklistWindowMs:30*86400000, kickOnReject:false, photoMaxMb:12, imageAnalysis:true
});
export const STATES = Object.freeze({PENDING:'pendente',RUNNING:'em_andamento',JUDGING:'aguardando_julgamento',APPROVED:'aprovado',REJECTED:'reprovado',EXPIRED:'expirado',CANCELLED:'cancelado'});
const clone=v=>v==null?v:structuredClone(v); const now=()=>Date.now();
const clean=v=>String(v??'').trim(); const mention=j=>`@${String(j).split('@')[0]}`;
const idBase=v=>String(v||'').split('@')[0].split(':')[0].replace(/[^0-9a-zA-Z]/g,'');
const makeId=()=>`TRG-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
const normalizeUser=(a,b)=>idBase(a)===idBase(b);

/** Extrai texto de diferentes formatos de mensagem Baileys sem lançar exceção. */
export function extractIncomingText(info) {
  const m = info?.message || info?.msg || {};
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    m.documentMessage?.caption ||
    m.buttonsResponseMessage?.selectedDisplayText ||
    m.listResponseMessage?.title ||
    m.templateButtonReplyMessage?.selectedDisplayText ||
    ''
  );
}

export const QUESTION_TYPES=Object.freeze({text:'text',date:'date',number:'number',yesno:'yesno',choice:'choice',image:'image'});
export function settingsOf(groups,groupId){const raw=groups.byId?.[groupId]?.triagem||{};return {...clone(DEFAULT_SETTINGS),...raw,questions:Array.isArray(raw.questions)?clone(raw.questions).slice(0,MAX_QUESTIONS):[]};}
export async function getSettings(groupId){return settingsOf(readCollection('groups',{byId:{}}),groupId);}
export async function saveSettings(groupId,patch){let out;await updateCollection('groups',g=>{g.byId??={};g.byId[groupId]??={};g.byId[groupId].triagem={...settingsOf(g,groupId),...clone(patch)};out=clone(g.byId[groupId].triagem);return g;},{byId:{}});return out;}
export async function deleteTriageConfiguration(groupId){let out;await updateCollection('groups',g=>{g.byId??={};if(g.byId[groupId]){const old=clone(g.byId[groupId].triagem||DEFAULT_SETTINGS);delete g.byId[groupId].triagem;out=old;}return g;},{byId:{}});await updateCollection('triage_builder',d=>{if(d.byKey)for(const k of Object.keys(d.byKey))if(k.startsWith(`${groupId}:`))delete d.byKey[k];return d;},{byKey:{}});return out||clone(DEFAULT_SETTINGS);}

function template(code,groupId,userId,s,botJid=''){const ts=now();return{id:code,groupId,userId,botJid:clean(botJid),state:STATES.PENDING,questionIndex:0,questions:clone(s.questions).slice(0,Math.min(MAX_QUESTIONS,Number(s.maxQuestions)||20)),answers:[],alerts:[],media:[],createdAt:ts,updatedAt:ts,startedAt:0,completedAt:0,judgedAt:0,expiresStartAt:ts+s.startTimeoutMs,expiresCompleteAt:0,expiresJudgeAt:0,reminderSentAt:0,judgeId:'',judgeName:'',reason:'',rejectionLevel:'',version:3};}
export async function getTriage(code){return readCollection('triage',{byId:{},active:{}}).byId?.[String(code||'').toUpperCase()]||null;}
export async function getActiveTriage(groupId,userId){const d=readCollection('triage',{byId:{},active:{}});const c=d.active?.[`${groupId}:${userId}`];return c?d.byId?.[c]||null:null;}
export async function isPendingMember(groupId,userId){const t=await getActiveTriage(groupId,userId);return !!(t&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(t.state));}
async function audit(action,t,extra={}){await updateCollection('triage_audit',d=>{d.entries??=[];d.entries.push({id:crypto.randomUUID(),action,at:now(),triageId:t?.id||'',groupId:t?.groupId||'',userId:t?.userId||'',state:t?.state||'',...clone(extra)});if(d.entries.length>15000)d.entries=d.entries.slice(-15000);return d;},{entries:[]});}
async function transition(code,patch){let out;await updateCollection('triage',d=>{const c=d.byId?.[code];if(!c)return d;out={...c,...clone(patch),updatedAt:now()};d.byId[code]=out;if([STATES.APPROVED,STATES.REJECTED,STATES.EXPIRED,STATES.CANCELLED].includes(out.state)&&d.active?.[`${out.groupId}:${out.userId}`]===code)delete d.active[`${out.groupId}:${out.userId}`];return d;},{byId:{},active:{}});if(out)await audit('state-change',out,patch);return out||null;}
export function triageLink(code,botJid=config.ownerNumber){const n=idBase(botJid);return n?`https://wa.me/${n}?text=${encodeURIComponent(code)}`:'';}
export async function createTriage(groupId,userId,{botJid=null,force=false}={}){const s=await getSettings(groupId);if(!s.questions.length)return{ok:false,reason:'no-questions'};if(!s.enabled&&!force)return{ok:false,reason:'disabled'};const old=await getActiveTriage(groupId,userId);if(old&&[STATES.PENDING,STATES.RUNNING,STATES.JUDGING].includes(old.state))return{ok:true,created:false,code:old.id,triage:old,link:triageLink(old.id,botJid)};const code=makeId(),t=template(code,groupId,userId,s,botJid||config.ownerNumber);await updateCollection('triage',d=>{d.byId??={};d.active??={};d.byId[code]=t;d.active[`${groupId}:${userId}`]=code;return d;},{byId:{},active:{}});await audit('created',t);return{ok:true,created:true,code,triage:t,link:triageLink(code,botJid)};}
export async function cancelActiveTriage(groupId,userId,reason='cancelado'){const t=await getActiveTriage(groupId,userId);return t?transition(t.id,{state:STATES.CANCELLED,reason}):null;}
function validateDate(raw){const m=String(raw).match(/^(\d{2})\/(\d{2})\/(\d{4})$/);if(!m)return false;const d=new Date(Number(m[3]),Number(m[2])-1,Number(m[1]));return d.getFullYear()===Number(m[3])&&d.getMonth()===Number(m[2])-1&&d.getDate()===Number(m[1]);}
function validateTextAnswer(q,raw){
  if(!raw) return q.required?'required':null;
  if(q.type==='date'&&!validateDate(raw)) return 'invalid-date';
  if(q.minLength&&raw.length<q.minLength) return 'too-short';
  if(q.maxLength&&raw.length>q.maxLength) return 'too-long';
  if(q.type==='number'){
    const n=Number(raw); if(!Number.isFinite(n)) return 'invalid-number';
    if(q.min!=null&&n<Number(q.min)) return 'number-too-small';
    if(q.max!=null&&n>Number(q.max)) return 'number-too-large';
  }
  if(q.type==='yesno'&&!['sim','s','yes','y','1','aceito','aceita','nao','não','n','no','0'].includes(raw.toLowerCase())) return 'invalid-yesno';
  if(q.type==='choice'&&q.choices?.length){
    const lower=raw.toLowerCase(); const exact=q.choices.map(x=>String(x).toLowerCase());
    const numeric=/^\d+$/.test(raw)?Number(raw):0;
    if(!exact.includes(lower) && !(numeric>=1&&numeric<=q.choices.length)) return 'invalid-choice';
  }
  return null;
}
export async function validateAndSaveAnswer(code,answer){const t=await getTriage(code);
if(!t||t.state!==STATES.RUNNING)return{ok:false,reason:t?'not-running':'not-found',triage:t};const s=await getSettings(t.groupId);const q=t.questions?.[t.questionIndex];if(!q||q.type==='image')return{ok:false,reason:q?'image-required':'finished',question:q,triage:t};const raw=clean(answer).replace(/\s+/g,' '),err=validateTextAnswer(q,raw);if(err)return{ok:false,reason:err,question:q,triage:t};let out;await updateCollection('triage',d=>{const c=d.byId?.[code];if(!c||c.state!==STATES.RUNNING)return d;c.answers??=[];c.answers.push({questionId:q.id,question:q.question,type:q.type,value:raw,at:now()});c.questionIndex++;c.updatedAt=now();if(c.questionIndex>=c.questions.length){c.state=STATES.JUDGING;c.completedAt=now();c.expiresJudgeAt=now()+s.judgeTimeoutMs;}out=clone(c);return d;},{byId:{},active:{}});if(!out)return{ok:false,reason:'race'};await audit('answer',out,{questionId:q.id});return{ok:true,triage:out,finished:out.state===STATES.JUDGING};}
export async function saveImageAnswer(code,info){const t=await getTriage(code);if(!t||t.state!==STATES.RUNNING)return{ok:false,reason:t?'not-running':'not-found',triage:t};const s=await getSettings(t.groupId);const q=t.questions?.[t.questionIndex];if(!q||q.type!=='image')return{ok:false,reason:'not-image-question',triage:t};let image;try{image=await downloadImage(info);}catch(e){return{ok:false,reason:'image-download',error:e.message,triage:t};}if(!image)return{ok:false,reason:'image-required',triage:t};const answers=Object.fromEntries((t.answers||[]).map(a=>[a.questionId,a.value]));const analysis=await analyzeTriageImage(image,{answers,question:q.question,analysis:q.analysis||{enabled:true,ocr:true}});const mediaId=crypto.randomUUID();const imagePath=await saveTriageImageFile(code,mediaId,image);const media={id:mediaId,questionId:q.id,sha256:image.sha256,mime:image.mime,size:image.size,width:image.width,height:image.height,path:imagePath,analysis,at:now()};let out;await updateCollection('triage',d=>{const c=d.byId?.[code];if(!c||c.state!==STATES.RUNNING)return d;c.media??=[];c.media.push(media);c.answers??=[];c.answers.push({questionId:q.id,question:q.question,type:'image',value:'[imagem enviada]',mediaId:media.id,analysisSummary:{id:analysis.id,nickname:analysis.nickname,quality:analysis.quality,confidence:analysis.confidence,alerts:analysis.alerts},at:now()});c.alerts.push(...(analysis.alerts||[]).filter(Boolean));c.questionIndex++;c.updatedAt=now();if(c.questionIndex>=c.questions.length){c.state=STATES.JUDGING;c.completedAt=now();c.expiresJudgeAt=now()+s.judgeTimeoutMs;}out=clone(c);return d;},{byId:{},active:{}});if(!out)return{ok:false,reason:'race'};await persistTriageMedia(code,media);await audit('image-answer',out,{questionId:q.id,mediaId:media.id});return{ok:true,triage:out,finished:out.state===STATES.JUDGING,analysis};}
export async function startTriage(code){const t=await getTriage(code);if(!t)return{ok:false,reason:'not-found'};if(t.state!==STATES.PENDING)return{ok:false,reason:'not-pending',triage:t};if(now()>t.expiresStartAt)return{ok:false,reason:'expired',triage:await transition(code,{state:STATES.EXPIRED,reason:'não iniciou no prazo'})};const s=await getSettings(t.groupId);return{ok:true,triage:await transition(code,{state:STATES.RUNNING,startedAt:now(),expiresCompleteAt:now()+s.completionTimeoutMs})};}
export function isImageQuestion(t){
  const q = t?.questions?.[t?.questionIndex];
  return q?.type === 'image';
}
export function questionText(t){
  const q=t?.questions?.[t.questionIndex]; if(!q) return '';
  const total=t.questions.length, n=t.questionIndex+1;
  const bar='▰'.repeat(Math.max(0,Math.min(10,Math.ceil((n/total)*10))))+'▱'.repeat(Math.max(0,10-Math.ceil((n/total)*10)));
  let extra=q.required===false?'\n\n_(Opcional)_':'';
  if(q.type==='image') extra+='\n\n📸 *Envie a imagem diretamente neste PV.*\n🤖 A análise automática é apenas auxiliar e pode ser inconclusiva.';
  if(q.type==='choice') extra+=`\n\n╭─「 🔘 OPÇÕES 」\n${q.choices.map((x,i)=>`│ ${i+1}. ${x}`).join('\n')}\n╰──────────────────`;
  if(q.type==='date') extra+='\n\n📅 Formato: *DD/MM/AAAA*';
  if(q.type==='number') extra+='\n\n🔢 Responda somente com um número válido.';
  if(q.type==='yesno') extra+='\n\n✅ *Sim*  •  ❌ *Não*';
  return `╭─👻────────────────────╮\n│       *FANTASMINHA*       │\n│        *TRIAGEM*          │\n╰──────────────────────────╯\n\n📋 *FICHA DA ALMA*  •  *${t.id}*\n📊 ${bar}  *${n}/${total}*\n\n╭─「 📝 PERGUNTA 」\n│ ${q.question}\n╰──────────────────────────${extra}\n\n💡 Responda com calma. O próximo passo aparece automaticamente.`;
}
async function historyFor(userId,windowMs=null){const d=readCollection('triage_history',{byUser:{}});const l=Array.isArray(d.byUser?.[userId])?d.byUser[userId]:[];return windowMs?l.filter(x=>x.at>=now()-windowMs):l;}
export async function rejectionHistory(userId,windowMs=null){return historyFor(userId,windowMs);}
async function addHistory(t,actor,reason,level){const e={id:crypto.randomUUID(),triageId:t.id,groupId:t.groupId,userId:t.userId,judgeId:actor.id,judgeName:actor.name||'',reason,level,at:now()};await updateCollection('triage_history',d=>{d.byUser??={};d.byUser[t.userId]??=[];d.byUser[t.userId].push(e);return d;},{byUser:{}});return e;}
export async function blacklistCheck(userId){const d=readCollection('triage_blacklist',{byUser:{}}),e=d.byUser?.[userId];if(!e)return null;if(e.until&&e.until<=now()){await updateCollection('triage_blacklist',x=>{delete x.byUser?.[userId];return x;},{byUser:{}});return null;}return e;}
export async function setBlacklist(userId,actorId,reason,durationMs=0,meta={}){const e={id:crypto.randomUUID(),userId,actorId,reason:clean(reason)||'sem motivo informado',createdAt:now(),until:durationMs?now()+durationMs:0,permanent:!durationMs,source:meta.source||'manual',level:meta.level||'blacklist'};await updateCollection('triage_blacklist',d=>{d.byUser??={};d.byUser[userId]=e;return d;},{byUser:{}});await audit('blacklist-add',{userId},{actorId,reason:e.reason});return e;}
export async function removeBlacklist(userId,actorId){let existed=false;await updateCollection('triage_blacklist',d=>{d.byUser??={};existed=!!d.byUser[userId];delete d.byUser[userId];return d;},{byUser:{}});if(existed)await audit('blacklist-remove',{userId},{actorId});return existed;}
export async function blacklistList(){const d=readCollection('triage_blacklist',{byUser:{}});return Object.values(d.byUser||{}).filter(e=>!e.until||e.until>now());}
export async function blacklistInfo(userId){return blacklistCheck(userId);} export async function blacklistHistory(userId){return rejectionHistory(userId);}
export async function triageStats(groupId=null){const a=Object.values(readCollection('triage',{byId:{}}).byId||{}).filter(t=>!groupId||t.groupId===groupId);return{total:a.length,pending:a.filter(t=>t.state===STATES.PENDING).length,running:a.filter(t=>t.state===STATES.RUNNING).length,judging:a.filter(t=>t.state===STATES.JUDGING).length,approved:a.filter(t=>t.state===STATES.APPROVED).length,rejected:a.filter(t=>t.state===STATES.REJECTED).length,expired:a.filter(t=>t.state===STATES.EXPIRED).length};}
export async function blacklistStats(){const list=await blacklistList();return{active:list.length,permanent:list.filter(x=>x.permanent).length,temporary:list.filter(x=>!x.permanent).length};}
export async function networkSummary(userId){return{count:(await historyFor(userId)).length,latest:(await historyFor(userId)).at(-1)||null,blacklist:await blacklistCheck(userId)};}
export function triageSummaryText(t,h=0){return`👻 *TRIAGEM ${t.id}*\n\n👤 Membro: ${mention(t.userId)}\n📋 Status: *${t.state}*\n📝 Respostas: *${t.answers?.length||0}/${t.questions?.length||0}*\n🛡️ Histórico na rede: *${h} reprovação(ões)*${t.alerts?.length?`\n\n⚠️ Alertas:\n${t.alerts.map(x=>`• ${x}`).join('\n')}`:'\n\n✅ Sem alertas objetivos'}`;}
export function triageFullText(t,h=0){const answers=(t.answers||[]).map((x,i)=>`${i+1}. *${x.question}*\n↳ ${x.type==='image'?'📸 Imagem enviada':x.value}`).join('\n\n')||'Nenhuma resposta.';const analyses=(t.media||[]).map((m,i)=>`📸 *Imagem ${i+1}*\n• Qualidade: ${m.analysis?.quality||'n/d'}\n• Confiança: ${m.analysis?.confidence||'n/d'}\n• ID detectado: ${m.analysis?.id||'não identificado'}\n• Nick detectado: ${m.analysis?.nickname||'não identificado'}\n• Alertas IA: ${(m.analysis?.alerts||[]).join('; ')||'nenhum'}`).join('\n\n');return`👻 *FICHA DA ALMA*\nCódigo: *${t.id}*\n👤 ${mention(t.userId)}\n📋 Estado: *${t.state}*\n\n╭─「 📝 RESPOSTAS  」\n${answers}\n╰────────────────────\n${analyses?`\n╭─「 🤖 ANÁLISE IA  」\n${analyses}\n╰────────────────────\n`:''}\n🛡️ Reprovações na rede: *${h}*\n⚠️ Alertas: ${t.alerts?.length?`\n${t.alerts.map(x=>`• ${x}`).join('\n')}`:'nenhum'}`;}
export async function judgeTriage(code,actor,decision,reason='',level=null){const t=await getTriage(code);if(!t)return{ok:false,reason:'not-found'};if(t.state!==STATES.JUDGING)return{ok:false,reason:'not-judging',triage:t};const s=await getSettings(t.groupId);if(decision==='approve'){return{ok:true,triage:await transition(code,{state:STATES.APPROVED,judgedAt:now(),judgeId:actor.id,judgeName:actor.name||'',reason:''})};}const r=clean(reason);if(r.length<3)return{ok:false,reason:'reason-required',triage:t};const l=['local','network','blacklist'].includes(String(level||'').toLowerCase())?String(level).toLowerCase():s.defaultRejectionLevel;const u=await transition(code,{state:STATES.REJECTED,judgedAt:now(),judgeId:actor.id,judgeName:actor.name||'',reason:r,rejectionLevel:l});const hist=await addHistory(u,actor,r,l);if(l==='blacklist')await setBlacklist(t.userId,actor.id,r,0,{source:'triage-blacklist',level:l});return{ok:true,triage:u,history:hist};}
export async function publishForAdmins(sock,t){const h=await rejectionHistory(t.userId);const full=triageFullText(t,h.length);const s=await getSettings(t.groupId);const destinations=[t.groupId,...(s.archiveGroupId&&s.archiveGroupId!==t.groupId?[s.archiveGroupId]:[])];for(const gid of destinations)await sock.sendMessage(gid,{text:full,mentions:[t.userId]}).catch(()=>{});const meta=await sock.groupMetadata(t.groupId).catch(()=>null);const admins=(meta?.participants||[]).filter(p=>p.admin).map(p=>p.id||p.jid).filter(Boolean);for(const admin of admins)await sock.sendMessage(admin,{text:full,mentions:[t.userId]}).catch(()=>{});return{history:h};}
export async function notifyAdmins(sock,groupId,text,mentions=[]){const meta=await sock.groupMetadata(groupId).catch(()=>null);const admins=(meta?.participants||[]).filter(p=>p.admin).map(p=>p.id||p.jid).filter(Boolean);for(const a of admins)await sock.sendMessage(a,{text,mentions}).catch(()=>{});return admins.length;}
export async function expireSweep(sendMessage=null,kick=null){const d=readCollection('triage',{byId:{}});let n=0;for(const t of Object.values(d.byId||{})){const expired=(t.state===STATES.PENDING&&t.expiresStartAt<now())||(t.state===STATES.RUNNING&&t.expiresCompleteAt<now())||(t.state===STATES.JUDGING&&t.expiresJudgeAt<now());if(!expired)continue;n++;await transition(t.id,{state:STATES.EXPIRED,reason:'tempo esgotado'});if(sendMessage)await sendMessage(t.userId,{text:`👻 Sua triagem *${t.id}* expirou.`}).catch(()=>{});if(kick){const s=await getSettings(t.groupId);if(s.kickOnExpire)await kick(t.groupId,t.userId).catch(()=>{});}}return n;}
export async function reminderSweep(sendMessage=null,sendGroup=null){const d=readCollection('triage',{byId:{}});let n=0;for(const t of Object.values(d.byId||{})){if(t.state!==STATES.PENDING||t.reminderSentAt)continue;const s=await getSettings(t.groupId);if(!s.reminderEnabled||now()<t.createdAt+s.reminderAfterMs)continue;await updateCollection('triage',x=>{if(x.byId?.[t.id])x.byId[t.id].reminderSentAt=now();return x;},{byId:{},active:{}});n++;if(sendMessage)await sendMessage(t.userId,{text:`👻 Sua triagem está aguardando você.\nCódigo: *${t.id}*\n${triageLink(t.id,t.botJid||config.ownerNumber)}`}).catch(()=>{});if(sendGroup)await sendGroup(t.groupId,{text:`👻 ${mention(t.userId)} ainda não concluiu a triagem.`,mentions:[t.userId]}).catch(()=>{});}return n;}

export async function handlePrivateMessage({sock,info,sender,text,send}){if(!sender||info?.key?.fromMe)return{handled:false};const normalized=clean(text),upper=normalized.toUpperCase();if(/^TRG-[A-F0-9]{8}$/.test(upper)){const t=await getTriage(upper);if(!t){await send('👻 Código de triagem não encontrado.');return{handled:true};}if(!normalizeUser(t.userId,sender)){await send('🚫 Este link/código pertence a outro usuário.');return{handled:true};}if(t.state===STATES.PENDING){const s=await startTriage(upper);if(!s.ok){await send('👻 Esta triagem não pode mais ser iniciada.');return{handled:true};}await send(questionText(s.triage));return{handled:true};}if(t.state===STATES.RUNNING){await send(questionText(t));return{handled:true};}await send(`👻 *TRIAGEM ${t.id}*\nStatus: *${t.state}*`);return{handled:true};}
const d=readCollection('triage',{byId:{},active:{}});const key=Object.keys(d.active||{}).find(k=>k.endsWith(`:${sender}`)||k.endsWith(`:${String(sender).split('@')[0]}@s.whatsapp.net`));const code=d.active?.[key||''];const t=code?d.byId?.[code]:null;if(!t)return{handled:false};if(t.state===STATES.RUNNING){if(t.questions?.[t.questionIndex]?.type==='image'){const image=getImageMessage(info);if(!image){await send('📸 Esta pergunta exige uma imagem.');return{handled:true};}const r=await saveImageAnswer(t.id,info);if(!r.ok){await send('⚠️ Não consegui processar a imagem. Envie uma imagem nítida.');return{handled:true};}if(r.finished){await send(`╭─👻────────────────────╮\n│    *TRIAGEM CONCLUÍDA*  │\n╰──────────────────────────╯\n\n✅ Todas as respostas foram registradas.\n🪪 Código: *${r.triage.id}*\n⚖️ *Agora sua ficha será analisada pela equipe.*\n\n⏳ Aguarde o resultado no próprio WhatsApp.`);await publishForAdmins(sock,r.triage);return{handled:true,finished:true,triage:r.triage};}await send(questionText(r.triage));return{handled:true};}const r=await validateAndSaveAnswer(t.id,normalized);if(!r.ok){const msg={required:'⚠️ Resposta obrigatória.','invalid-date':'⚠️ Use exatamente DD/MM/AAAA.','invalid-number':'⚠️ Envie um número válido.','invalid-yesno':'⚠️ Responda sim ou não.','invalid-choice':'⚠️ Escolha uma opção válida.','too-short':'⚠️ Resposta curta demais.','too-long':'⚠️ Resposta longa demais.','number-too-small':'⚠️ Número abaixo do mínimo permitido.','number-too-large':'⚠️ Número acima do máximo permitido.'};await send(msg[r.reason]||'⚠️ Resposta inválida.');return{handled:true};}if(r.finished){await send(`╭─👻────────────────────╮\n│    *TRIAGEM CONCLUÍDA*  │\n╰──────────────────────────╯\n\n✅ Todas as respostas foram registradas.\n🪪 Código: *${r.triage.id}*\n⚖️ *Agora sua ficha será analisada pela equipe.*\n\n⏳ Aguarde o resultado no próprio WhatsApp.`);await publishForAdmins(sock,r.triage);return{handled:true};}await send(questionText(r.triage));return{handled:true};}return{handled:true};}
export async function memberJoined(sock,groupId,userId){const s=await getSettings(groupId);if(!s.enabled)return{ok:false,reason:'disabled'};const bl=await blacklistCheck(userId);if(bl){await sock.groupParticipantsUpdate(groupId,[userId],'remove').catch(()=>{});return{ok:false,reason:'blacklisted',blacklist:bl};}const botJid=sock?.user?.id||config.ownerNumber;const c=await createTriage(groupId,userId,{botJid});if(!c.ok)return c;await sock.sendMessage(groupId,{text:`╭─👻────────────────────╮\n│     *FILA DO LIMBO*      │\n╰──────────────────────────╯\n\n👋 Bem-vindo(a), ${mention(userId)}!\n\n🔐 Sua entrada está aguardando uma triagem individual.\n\n📩 *Abra o link abaixo e responda no PV do Fantasminha:*\n👉 ${c.link}\n\n🪪 Código exclusivo: *${c.code}*\n⏳ Prazo para iniciar: *1 hora*\n\n╰─🌑 Após concluir, sua ficha será enviada à equipe para análise.`,mentions:[userId]}).catch(()=>{});return{ok:true,...c};}

// ---------- CONSTRUTOR SIMPLES / SEM PREFIXO ----------
export function builderState(groupId,actor){return readCollection('triage_builder',{byKey:{}}).byKey?.[`${groupId}:${actor}`]||null;}
async function setBuilder(groupId,actor,state){return updateCollection('triage_builder',d=>{d.byKey??={};if(state)d.byKey[`${groupId}:${actor}`]=state;else delete d.byKey[`${groupId}:${actor}`];return d;},{byKey:{}});}
export async function beginTriageBuilder(groupId,actor){await setBuilder(groupId,actor,{step:'confirm',questions:[],current:null,createdAt:now()});return true;}
export async function cancelTriageBuilder(groupId,actor){await setBuilder(groupId,actor,null);return true;}
const catMap={'1':'text','2':'date','3':'image','4':'number','5':'yesno','6':'choice',texto:'text',data:'date',foto:'image',imagem:'image',numero:'number',simnao:'yesno',escolha:'choice'};
function categoryText(){return`🧩 *ESCOLHA A CATEGORIA*\n\n1️⃣ Texto — aceita texto livre\n2️⃣ Data — somente DD/MM/AAAA\n3️⃣ Foto — somente imagem + análise IA\n4️⃣ Número — somente número\n5️⃣ Sim/Não — somente resposta sim/não\n6️⃣ Escolha — opções definidas pelo administrador`}
export async function beginTriageEdit(groupId,actor,index){
  const s=await getSettings(groupId);
  const i=Number(index)-1;
  if(!Number.isInteger(i)||i<0||i>=s.questions.length)return{ok:false,reason:'not-found'};
  const q=clone(s.questions[i]);
  await setBuilder(groupId,actor,{step:'edit-question',questions:clone(s.questions),editIndex:i,current:q,createdAt:now()});
  return{ok:true,question:q,number:i+1,total:s.questions.length};
}

export async function handleTriageBuilderMessage(ctx){if(!ctx.isGroup||!ctx.isGroupAdmin||!ctx.sender)return{handled:false};const st=builderState(ctx.from,ctx.sender);if(!st)return{handled:false};const raw=clean(ctx.body||ctx.text||ctx.q||'');const lower=raw.toLowerCase();if(lower===`${ctx.prefix||config.prefix}cancelar`||lower==='cancelar'){await cancelTriageBuilder(ctx.from,ctx.sender);await ctx.reply('👻 Criação da triagem cancelada.');return{handled:true};}if(st.step==='confirm'){if(raw==='1'){await setBuilder(ctx.from,ctx.sender,{...st,step:'question'});await ctx.reply('👻 Para criar uma triagem, você poderá cadastrar até *20 perguntas*.\n\n1️⃣ para continuar\n2️⃣ para cancelar');}else if(raw==='2'){await cancelTriageBuilder(ctx.from,ctx.sender);await ctx.reply('👻 Criação cancelada.');}else await ctx.reply('Envie apenas *1* para continuar ou *2* para cancelar.');return{handled:true};}if(st.step==='question'){if(lower==='concluir'){const s=await getSettings(ctx.from);if(!st.questions.length){await ctx.reply('⚠️ Cadastre pelo menos uma pergunta.');return{handled:true};}await saveSettings(ctx.from,{questions:st.questions.map((q,i)=>({...q,order:i+1})),maxQuestions:20,enabled:false});await cancelTriageBuilder(ctx.from,ctx.sender);await ctx.reply(`👻 *TRIAGEM SALVA!*\n\nPerguntas: *${st.questions.length}/20*\nStatus: *DESATIVADA*\n\nPara testar: *${config.prefix}triagemcobrar*\nPara ativar automaticamente novos membros: *${config.prefix}triagemativar*`);return{handled:true};}if(st.questions.length>=20){await ctx.reply('⚠️ Limite de 20 perguntas atingido. Envie *concluir*.');return{handled:true};}if(!raw){await ctx.reply('⚠️ Escreva a pergunta.');return{handled:true};}await setBuilder(ctx.from,ctx.sender,{...st,step:'category',current:{question:raw}});await ctx.reply(categoryText());return{handled:true};}if(st.step==='edit-question'){
if(!raw){await ctx.reply('⚠️ Escreva a nova pergunta.');return{handled:true};}
await setBuilder(ctx.from,ctx.sender,{...st,step:'edit-category',current:{...st.current,question:raw}});
await ctx.reply(categoryText()+`\n\n✏️ Editando a pergunta *${st.editIndex+1}*. Escolha a categoria novamente.`);return{handled:true};}
if(st.step==='edit-category'){
const type=catMap[lower];if(!type){await ctx.reply(categoryText());return{handled:true};}
if(type==='choice'){await setBuilder(ctx.from,ctx.sender,{...st,step:'edit-choice-options',current:{...st.current,type}});await ctx.reply(`╭─👻 *OPÇÕES DA PERGUNTA* ─╮\n│ Envie as opções separadas por *|*.\n│ Ex.: Iniciante | Membro | Staff\n╰────────────────────────╯`);return{handled:true};}
const q={...st.current,type,id:st.current.id,order:st.editIndex+1,required:true};
if(type==='image')q.analysis={enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low'};else delete q.analysis;
delete q.choices;
const questions=st.questions.map((x,i)=>i===st.editIndex?q:x);
await saveSettings(ctx.from,{questions,maxQuestions:20});await cancelTriageBuilder(ctx.from,ctx.sender);
await ctx.reply(`╭─👻 *PERGUNTA ATUALIZADA* ─╮\n│ *${st.editIndex+1}.* ${q.question}\n│ Tipo: *${type}*\n╰──────────────────────────╯\n\n${config.prefix}triagemativar`);return{handled:true};}
if(st.step==='edit-choice-options'){
const choices=raw.split('|').map(x=>x.trim()).filter(Boolean).slice(0,50);if(choices.length<2){await ctx.reply('⚠️ Envie pelo menos 2 opções usando | para separar.');return{handled:true};}
const q={...st.current,type:'choice',id:st.current.id,order:st.editIndex+1,required:true,choices};
const questions=st.questions.map((x,i)=>i===st.editIndex?q:x);await saveSettings(ctx.from,{questions,maxQuestions:20});await cancelTriageBuilder(ctx.from,ctx.sender);
await ctx.reply(`╭─👻 *PERGUNTA ATUALIZADA* ─╮\n│ *${st.editIndex+1}.* ${q.question}\n│ Tipo: *escolha*\n│ Opções: ${choices.join(' • ')}\n╰──────────────────────────╯`);return{handled:true};}
if(st.step==='category'){const type=catMap[lower];if(!type){await ctx.reply(categoryText());return{handled:true};}const q={id:`q_${crypto.randomBytes(4).toString('hex')}`,type,required:true,question:st.current.question,order:st.questions.length+1};if(type==='image')q.analysis={enabled:true,ocr:true,compareQuestionIds:[],requireReadable:false,confidenceFloor:'low'};if(type==='choice'){await setBuilder(ctx.from,ctx.sender,{...st,step:'choice-options',current:q});await ctx.reply(`╭─👻 *OPÇÕES* ───────────╮\n│ Envie as opções separadas por *|*.\n│ Ex.: Recrutamento | Suporte | Parceria\n╰────────────────────────╯`);return{handled:true};}const questions=[...st.questions,q];await setBuilder(ctx.from,ctx.sender,{questions,step:'question',current:null});await ctx.reply(`╭─👻 *PERGUNTA ${questions.length}/20* ─╮\n│ ✅ ${q.question}\n│ Tipo: *${type}*\n╰────────────────────────────╯\n\nEnvie a próxima pergunta ou *concluir*.`);return{handled:true};}
if(st.step==='choice-options'){const choices=raw.split('|').map(x=>x.trim()).filter(Boolean).slice(0,50);if(choices.length<2){await ctx.reply('⚠️ Envie pelo menos 2 opções usando | para separar.');return{handled:true};}const q={...st.current,choices};const questions=[...st.questions,q];await setBuilder(ctx.from,ctx.sender,{questions,step:'question',current:null});await ctx.reply(`╭─👻 *PERGUNTA ${questions.length}/20* ─╮\n│ ✅ ${q.question}\n│ Tipo: *escolha*\n│ Opções: ${choices.join(' • ')}\n╰────────────────────────────╯\n\nEnvie a próxima pergunta ou *concluir*.`);return{handled:true};}
return{handled:false};}
