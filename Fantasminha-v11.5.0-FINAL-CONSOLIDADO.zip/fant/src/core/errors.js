/**
 * Fantasminha — erros centralizados
 */
import logger from './logger.js';

export class FantasmaError extends Error {
  constructor(message, { code = 'FANTASMA_ERROR', userMessage = null, status = 400 } = {}) {
    super(message);
    this.name = 'FantasmaError';
    this.code = code;
    this.userMessage = userMessage || message;
    this.status = status;
  }
}

export class PermissionError extends FantasmaError {
  constructor(msg = 'Sem permissão no submundo.') {
    super(msg, { code: 'PERMISSION', userMessage: msg, status: 403 });
  }
}

export class CooldownError extends FantasmaError {
  constructor(seconds) {
    super(`Cooldown ${seconds}s`, {
      code: 'COOLDOWN',
      userMessage: `🕯️ Aguarde *${seconds}s* antes de usar de novo.`,
      status: 429
    });
  }
}

export class TimeoutError extends FantasmaError {
  constructor(msg = 'A operação excedeu o tempo limite.') { super(msg, { code: 'TIMEOUT', userMessage: `⏱️ ${msg}`, status: 504 }); }
}

export class ExternalServiceError extends FantasmaError {
  constructor(msg = 'Serviço externo indisponível.') { super(msg, { code: 'EXTERNAL_SERVICE', userMessage: `🌐 ${msg}`, status: 502 }); }
}

export class DatabaseError extends FantasmaError {
  constructor(msg = 'Falha ao acessar os dados.') { super(msg, { code: 'DATABASE', userMessage: `💾 ${msg}`, status: 500 }); }
}

export class SessionError extends FantasmaError {
  constructor(msg = 'A sessão do WhatsApp precisa ser recuperada.') { super(msg, { code: 'SESSION', userMessage: `🔐 ${msg}`, status: 503 }); }
}

export class ValidationError extends FantasmaError {
  constructor(msg) {
    super(msg, { code: 'VALIDATION', userMessage: `🌑 ${msg}`, status: 400 });
  }
}

/** middleware de erro: comando → handler → log → resposta */
export async function withErrorHandler(ctx, fn) {
  try {
    return await fn(ctx);
  } catch (err) {
    logger.error('handler', err.message, {
      code: err.code,
      command: ctx?.command,
      stack: err.stack?.split('\n').slice(0, 3).join(' | ')
    });
    const userMsg =
      err.userMessage ||
      err.message ||
      '🕯️ O véu engasgou. Tente de novo.';
    if (typeof ctx?.reply === 'function') {
      try {
        await ctx.reply(`× 👻 FANTASMINHA\n\n${userMsg}`);
      } catch (e) {
        logger.error('handler', 'falha ao responder erro', { message: e.message });
      }
    }
    throw err;
  }
}

export default { FantasmaError, PermissionError, CooldownError, ValidationError, TimeoutError, ExternalServiceError, DatabaseError, SessionError, withErrorHandler };
