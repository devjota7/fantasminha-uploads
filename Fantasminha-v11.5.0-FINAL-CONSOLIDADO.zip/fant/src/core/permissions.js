/**
 * Hierarquia: OWNER > BOT_ADMIN > GROUP_ADMIN > VIP > USER
 */
export const Role = {
  OWNER: 100,
  BOT_ADMIN: 80,
  GROUP_ADMIN: 60,
  VIP: 40,
  USER: 10
};

import config, { normalizeOwnerId } from './config.js';
export function configuredOwner(value) {
  const x = normalizeOwnerId(value);
  if (!x) return false;
  const cfg = new Set([
    ...(globalThis.__fantasminhaOwnerIds || []),
    ...(config.ownerIds || []),
    config.ownerNumber,
    config.ownerLid
  ].map(normalizeOwnerId).filter(Boolean));
  return cfg.has(x);
}

export function resolveRole(ctx = {}) {
  if (ctx.isOwner || configuredOwner(ctx.sender)) return Role.OWNER;
  if (ctx.isBotAdmin) return Role.BOT_ADMIN;
  if (ctx.isGroupAdmin) return Role.GROUP_ADMIN;
  if (ctx.isVip || ctx.isPremium) return Role.VIP;
  return Role.USER;
}

export function canRun(ctx, minRole = Role.USER) {
  return resolveRole(ctx) >= minRole;
}

export function roleName(role) {
  const map = {
    [Role.OWNER]: 'Dono',
    [Role.BOT_ADMIN]: 'Bot Admin',
    [Role.GROUP_ADMIN]: 'Admin',
    [Role.VIP]: 'VIP',
    [Role.USER]: 'Membro'
  };
  return map[role] || 'Membro';
}

export default { Role, resolveRole, canRun, roleName };
