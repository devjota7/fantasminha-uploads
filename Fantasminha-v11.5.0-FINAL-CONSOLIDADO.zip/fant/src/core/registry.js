/** Registry central: única fonte de verdade para comandos V6. */
import { Role, canRun, configuredOwner } from './permissions.js';
import { checkCooldown, setCooldown } from './cooldown.js';
import { CooldownError, PermissionError, withErrorHandler } from './errors.js';
import logger from './logger.js';
import { commandStarted, commandFinished } from './metrics.js';
import { isCommandHidden } from '../platform/commandVisibility.js';

const commands = new Map();
const aliasMap = new Map();
const executionLocks = new Map();

async function runExclusive(key, fn) {
  const previous = executionLocks.get(key) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  executionLocks.set(key, previous.then(() => current));
  await previous;
  try { return await fn(); }
  finally {
    release();
    if (executionLocks.get(key) === current) executionLocks.delete(key);
  }
}
const normalize = value => String(value ?? '').trim().toLowerCase();

function detachCommand(name) {
  const old = commands.get(name);
  if (!old) return;
  commands.delete(name);
  for (const [alias, target] of aliasMap) if (target === name) aliasMap.delete(alias);
}

export function registerCommand(def) {
  if (!def?.name || typeof def.handler !== 'function') throw new Error('registerCommand: name e handler são obrigatórios');
  const name = normalize(def.name);
  if (!name) throw new Error('registerCommand: nome vazio');

  const aliases = [...new Set((def.aliases || []).map(normalize).filter(Boolean))];
  const reserved = new Set([name, ...aliases]);
  for (const key of reserved) {
    const existing = aliasMap.get(key);
    if (existing && existing !== name) throw new Error(`Nome/alias duplicado: ${key} (${existing} -> ${name})`);
  }

  // Registro idempotente: o mesmo comando pode ser carregado novamente sem deixar aliases órfãos.
  if (commands.has(name)) {
    logger.warn('registry', `comando substituído: ${name}`, { plugin: def.plugin });
    detachCommand(name);
  }

  const entry = Object.freeze({
    name, aliases,
    category: def.category || 'geral', subcategory: def.subcategory || null,
    permission: def.permission ?? Role.USER, cooldown: Number(def.cooldown || 0),
    description: def.description || '', usage: def.usage || '', examples: def.examples || [],
    groupOnly: !!def.groupOnly, privateOnly: !!def.privateOnly, ownerOnly: !!def.ownerOnly,
    enabled: def.enabled !== false, plugin: def.plugin || null, version: def.version || null,
    timeoutMs: Number(def.timeoutMs || 30_000), hidden: !!def.hidden, handler: def.handler
  });
  commands.set(name, entry);
  aliasMap.set(name, name);
  for (const alias of aliases) aliasMap.set(alias, name);
  return entry;
}

export function unregisterCommand(name) {
  const key = normalize(name);
  const target = aliasMap.get(key) || key;
  if (!commands.has(target)) return false;
  detachCommand(target);
  return true;
}

export function getCommand(name) {
  const key = aliasMap.get(normalize(name));
  const cmd = key ? commands.get(key) : null;
  return cmd?.enabled ? cmd : null;
}

export function listCommands(filter = {}) {
  let list = [...commands.values()].filter(c => c.enabled && (filter.includeHidden || (!c.hidden && !isCommandHidden(c.name))));
  if (filter.category) list = list.filter(c => c.category === filter.category);
  if (filter.plugin) list = list.filter(c => c.plugin === filter.plugin);
  return list.sort((a, b) => a.name.localeCompare(b.name));
}

export function categories() { return [...new Set(listCommands().map(c => c.category))].sort(); }

function validateContext(cmd, ctx = {}) {
  if (cmd.groupOnly && !ctx.isGroup) throw new PermissionError('Este comando só pode ser usado em grupos.');
  if (cmd.privateOnly && ctx.isGroup) throw new PermissionError('Este comando só pode ser usado no privado.');
  if (cmd.ownerOnly && !(ctx.isOwner || configuredOwner(ctx.sender))) throw new PermissionError('Somente o dono pode usar este comando.');
}

async function withTimeout(promise, ms, name) {
  if (!ms || ms <= 0) return promise;
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`Timeout no comando ${name}`)), ms); });
  try { return await Promise.race([promise, timeout]); } finally { clearTimeout(timer); }
}

export async function runCommand(name, ctx = {}) {
  const cmd = getCommand(name);
  if (!cmd) return { found: false };
  validateContext(cmd, ctx);
  if (!canRun(ctx, cmd.permission)) throw new PermissionError('Só quem tem cargo suficiente no véu pode usar isto.');

  const lockKey = `${ctx.sender || 'unknown'}:${cmd.name}`;
  return runExclusive(lockKey, async () => {
    const cdSec = Math.ceil(cmd.cooldown * (ctx.cooldownMult || 1));
    const cd = checkCooldown(ctx.sender, cmd.name, cdSec);
    if (!cd.ok) throw new CooldownError(cd.remaining);

    commandStarted(cmd.name);
    const started = Date.now();
    logger.command('registry', cmd.name, { user: ctx.sender, group: ctx.from, category: cmd.category });
    try {
      await withErrorHandler(ctx, async () => {
        await withTimeout(Promise.resolve().then(() => cmd.handler(ctx)), cmd.timeoutMs, cmd.name);
        setCooldown(ctx.sender, cmd.name, cdSec);
      });
      commandFinished(cmd.name, { ok: true, durationMs: Date.now() - started });
      return { found: true, name: cmd.name };
    } catch (err) {
      commandFinished(cmd.name, { ok: false, durationMs: Date.now() - started });
      throw err;
    }
  });
}

export function validateRegistry() {
  const errors = [];
  const names = new Set();
  const aliases = new Map();
  for (const c of commands.values()) {
    if (names.has(c.name)) errors.push(`comando duplicado: ${c.name}`);
    names.add(c.name);
    if (typeof c.handler !== 'function') errors.push(`${c.name}: handler inválido`);
    for (const a of c.aliases) {
      if (a === c.name) errors.push(`${c.name}: alias igual ao nome`);
      if (names.has(a)) errors.push(`alias colide com comando: ${a}`);
      if (aliases.has(a) && aliases.get(a) !== c.name) errors.push(`alias duplicado: ${a}`);
      aliases.set(a, c.name);
    }
  }
  return { ok: errors.length === 0, errors };
}

export function registryStats() {
  const list = listCommands();
  return { total: commands.size, enabled: list.length, disabled: commands.size - list.length, categories: categories().length, aliases: aliasMap.size, valid: validateRegistry().ok };
}

export function clearRegistry() { for (const name of [...commands.keys()]) detachCommand(name); }

export function commandExists(name) { return commands.has(normalize(name)); }

export default { registerCommand, unregisterCommand, getCommand, listCommands, categories, runCommand, registryStats, validateRegistry, clearRegistry, commandExists };
