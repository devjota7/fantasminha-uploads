import { registerCommand } from '../core/registry.js';
import { Role } from '../core/permissions.js';
import { healthSnapshot, healthText } from '../core/health.js';
import config from '../core/config.js';
import logger from '../core/logger.js';
import fs from 'fs';
import { snapshot as metricsSnapshot } from '../core/metrics.js';
import path from 'path';

export function registerSystemCommands() {
  registerCommand({
    name: 'status',
    aliases: ['statusbot', 'health', 'pingalem'],
    category: 'sistema',
    permission: Role.USER,
    cooldown: 5,
    handler: async (ctx) => {
      const snap = healthSnapshot({ waConnected: ctx.waConnected === true });
      await ctx.reply(healthText(snap));
    }
  });

  registerCommand({
    name: 'backupconfig',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 10,
    handler: async (ctx) => {
      const src = path.join(config.root, 'dados', 'src', 'config.json');
      const dir = path.join(config.root, 'data', 'backups');
      fs.mkdirSync(dir, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const dest = path.join(dir, `config_${stamp}.json`);
      fs.copyFileSync(src, dest);
      await ctx.reply(`× 👻 FANTASMINHA\n\n🕯️ Backup:\n\`${dest}\``);
    }
  });

  registerCommand({
    name: 'backupdb',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 15,
    handler: async (ctx) => {
      const { backupDatabase } = await import('../database/store.js');
      const dest = backupDatabase();
      await ctx.reply(`× 👻 FANTASMINHA\n\n🗄️ DB:\n\`${dest}\``);
    }
  });

  registerCommand({
    name: 'forcaridentidade',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 5,
    handler: async (ctx) => {
      const p = path.join(config.root, 'dados', 'src', 'config.json');
      const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
      cfg.nomebot = 'Fantasminha';
      if (!cfg.nomedono) cfg.nomedono = config.ownerName;
      fs.writeFileSync(p, JSON.stringify(cfg, null, 2));
      await ctx.reply('× 👻 FANTASMINHA\n\nIdentidade: *Fantasminha*.');
    }
  });

  registerCommand({
    name: 'limparcache',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 10,
    handler: async (ctx) => {
      globalThis.__fantasmaV2Ready = false;
      await ctx.reply('× 👻 FANTASMINHA\n\nCache v2 resetado.');
    }
  });

  registerCommand({
    name: 'aicusto',
    aliases: ['ailimit'],
    category: 'sistema',
    permission: Role.USER,
    cooldown: 5,
    handler: async (ctx) => {
      const { aiStats } = await import('../services/aiLimit.js');
      const st = aiStats();
      const u = st.byUser?.[ctx.sender] || { total: 0, calls: 0 };
      await ctx.reply(
        `× 👻 FANTASMINHA\n\n🤖 *IA / limites*\nSeus créditos: *${u.total}* (${u.calls} calls)\nGlobal: *${st.global || 0}*\nVIP aumenta teto diário de IA e download.`
      );
    }
  });
  registerCommand({
    name: 'metricas', aliases: ['metrics', 'statscmd'], category: 'sistema', permission: Role.OWNER, cooldown: 10,
    handler: async (ctx) => {
      const m = metricsSnapshot();
      const top = m.commands.slice(0, 10).map((c, i) => `${i + 1}. *${c.name}* — ${c.calls} usos | ${c.avgMs}ms | ${c.errors} erros`).join('\n') || 'Sem dados.';
      await ctx.reply(`× 👻 *MÉTRICAS*\n\n⏱ Uptime: ${Math.round(m.uptimeMs / 1000)}s\n\n🏆 *Top comandos*\n${top}`);
    }
  });

}

export default { registerSystemCommands };
