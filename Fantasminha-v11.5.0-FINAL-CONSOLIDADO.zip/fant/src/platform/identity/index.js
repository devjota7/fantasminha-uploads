import crypto from 'node:crypto';
import { getUser, upsertUser } from '../../database/store.js';

export function normalizeId(value) {
  return String(value || '').trim().toLowerCase();
}

export function fantasminhaId(value) {
  const normalized = normalizeId(value);
  if (!normalized) return null;
  return `FNT-${crypto.createHash('sha256').update(normalized).digest('hex').slice(0, 12).toUpperCase()}`;
}

export async function ensureIdentity(userId, patch = {}) {
  if (!userId) throw new Error('userId obrigatório');
  const id = fantasminhaId(userId);
  const current = getUser(userId);
  if (!current || current.fantasminhaId !== id) {
    await upsertUser(userId, { ...patch, fantasminhaId: id, identityVersion: 1 });
  }
  return { userId, fantasminhaId: id, user: getUser(userId) };
}

export function createContext(base = {}) {
  const sender = base.sender || base.userId || base.participant || null;
  return {
    ...base,
    actor: sender ? { userId: sender, fantasminhaId: fantasminhaId(sender) } : null,
    requestId: base.requestId || crypto.randomUUID(),
    operationId: base.operationId || crypto.randomUUID(),
    startedAt: base.startedAt || Date.now(),
    platformVersion: '10.4.0'
  };
}

export * from './lid.js';
export default { normalizeId, fantasminhaId, ensureIdentity, createContext };
