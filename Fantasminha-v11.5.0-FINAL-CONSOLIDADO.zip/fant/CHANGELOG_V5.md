# Fantasminha 5.0.0

## Reforma geral
- +100 comandos de expansão, registrados pelo núcleo central.
- Nova camada de diagnóstico, backup/snapshot, auditoria, incidentes, busca e métricas.
- Perfil e preferências persistentes.
- Notas e lembretes locais.
- 20 ferramentas/jogos leves sem apostas.
- Atalhos de triagem universal para diagnóstico, validação, prévia, exportação e relatórios.
- Menudono ampliado com a seção EXPANSÃO 5.0.
- `validate:full` inclui teste da expansão.
- `node-addon-api` e `node-gyp` declarados no devDependencies para facilitar instalação do Sharp no Termux.

## Triagem
- Mantida a regra: uma configuração de triagem por grupo e fichas individuais por participante.
- Perguntas e análise de imagem continuam configuráveis; IA é auxiliar e pode exigir revisão humana.
- Conselho continua sem votação.
