import config from '../core/config.js';
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
export async function play(edit, frames=[], stepMs=Number(process.env.ANIMATION_STEP_MS||250)){if(process.env.ANIMATION_ENABLED==='false'||config?.features?.animations===false)return null;let last=null;for(const frame of frames){try{last=await edit(frame);}catch{}await sleep(Math.max(80,stepMs));}return last;}
export const gameFrames=(title)=>[`👻 *FANTASMINHA 11.7.03*\n\n🎮 ${title}\n\n⚙️ Preparando...`,`👻 *FANTASMINHA 11.7.03*\n\n🎮 ${title}\n\n⚡ Carregando...`,`👻 *FANTASMINHA 11.7.03*\n\n🎮 ${title}\n\n🏁 Valendo!`];
export default {play,gameFrames};
