import fs from 'fs';
const registered=new Set(), aliases=new Set(), conflicts=[];
const files=fs.readdirSync('src/plugins',{withFileTypes:true}).filter(x=>x.isDirectory()).map(x=>`src/plugins/${x.name}/index.js`).concat(['src/commands/system.js']);
for(const f of files){const s=fs.readFileSync(f,'utf8');for(const m of s.matchAll(/registerCommand\(\{([\s\S]*?)\}\s*\);/g)){const b=m[1];const n=b.match(/(?:^|,)\s*name\s*:\s*['"]([^'"]+)/);if(n)registered.add(n[1].toLowerCase());const a=b.match(/aliases\s*:\s*\[([^\]]*)\]/s);if(a)for(const x of a[1].matchAll(/['"]([^'"]+)['"]/g))aliases.add(x[1].toLowerCase());}}
const legacy=fs.readFileSync('src/plugins/legacyRegistry/index.js','utf8');const legacyNames=[...legacy.matchAll(/\{\"name\":\"([^\"]+)\"/g)].map(m=>m[1].toLowerCase());for(const n of legacyNames)registered.add(n);
const idx=fs.readFileSync('dados/src/index.js','utf8');const legacyCases=new Set([...idx.matchAll(/case\s+['"]([^'"]+)['"]\s*:/g)].map(m=>m[1].toLowerCase()));
const working=new Set([...registered,...aliases,...legacyCases]);
const report={generatedAt:new Date().toISOString(),registeredApprox:registered.size,aliasesApprox:aliases.size,legacyCases:legacyCases.size,workingCommands:working.size,conflicts};
fs.writeFileSync('COMMAND_AUDIT.json',JSON.stringify(report,null,2)+'\n');
console.log(`👻 COMMAND AUDIT — registry/ponte ${registered.size} | legacy cases ${legacyCases.size} | universo ${working.size}`);
console.log('✅ Audit concluída sem dependência de catálogo órfão.');
