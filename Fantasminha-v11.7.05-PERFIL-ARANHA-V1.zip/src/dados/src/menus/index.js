import menu from './menu.js';
import menuPremium from './menupremium.js';
export async function getMenus(){ return { menu, menuPremium }; }
export default { menu, menuPremium };
