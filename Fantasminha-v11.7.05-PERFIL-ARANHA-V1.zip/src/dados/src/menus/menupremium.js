import { buildCatalogMenu } from './catalogMenu.js';
export default async function menuPremium(prefix='×', botName='Fantasminha', userName='Usuário', design=null, options={}) { return buildCatalogMenu(prefix,'premium',{...options,botName,userName,customDesign:design}); }
