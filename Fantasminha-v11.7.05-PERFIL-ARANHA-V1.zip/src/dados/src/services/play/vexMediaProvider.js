import * as youtube from '../../funcs/downloads/youtube.js';

/**
 * Provider de mídia VEX para o PlayService.
 * O comando não conhece endpoints, autenticação ou formato bruto da VEX.
 */
export class VexMediaProvider {
  constructor({ provider = youtube } = {}) {
    this.provider = provider;
  }

  async search(query) {
    if (!this.provider || typeof this.provider.search !== 'function') {
      return { ok: false, code: 'PROVIDER_UNAVAILABLE', msg: 'Provedor de mídia indisponível.' };
    }
    return this.provider.search(query);
  }

  async getAudio(result) {
    if (!result?.url) {
      return { ok: false, code: 'MISSING_URL', msg: 'O resultado não possui URL de mídia.' };
    }
    if (!this.provider || typeof this.provider.mp3 !== 'function') {
      return { ok: false, code: 'PROVIDER_UNAVAILABLE', msg: 'Processador de áudio indisponível.' };
    }
    return this.provider.mp3(result.url);
  }
}
