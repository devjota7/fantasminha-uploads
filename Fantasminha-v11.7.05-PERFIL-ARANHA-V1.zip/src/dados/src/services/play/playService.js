import { VexMediaProvider } from './vexMediaProvider.js';

const MAX_QUERY_LENGTH = 300;
const MAX_AUDIO_BYTES = 40 * 1024 * 1024;
const DEFAULT_DURATION = '—';

function clean(value, fallback = '') {
  const text = String(value ?? '').replace(/[\u0000-\u001F\u007F]/g, ' ').trim();
  return text || fallback;
}

function safeDuration(value, seconds) {
  if (value != null && String(value).trim()) return clean(value, DEFAULT_DURATION);
  if (Number.isFinite(Number(seconds))) {
    const total = Math.max(0, Math.floor(Number(seconds)));
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    return h > 0
      ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
      : `${m}:${String(s).padStart(2, '0')}`;
  }
  return DEFAULT_DURATION;
}

function safeFileName(title) {
  const base = clean(title, 'audio')
    .replace(/[\\/:*?"<>|]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 120);
  return `${base || 'audio'}.mp3`;
}

function normalizeSearchResult(raw, requester) {
  const data = raw?.data || raw?.result || raw?.resposta || raw;
  if (!data) return null;

  const author = typeof data.author === 'string'
    ? data.author
    : data.author?.name;

  const title = clean(data.title, 'Mídia sem título');
  const url = clean(data.url || data.videoUrl || data.link);
  if (!url) return null;

  return {
    id: clean(data.videoId || data.id || data.video_id, ''),
    title,
    artist: clean(author || data.artist || data.channel, 'Canal desconhecido'),
    duration: safeDuration(data.timestamp || data.duration, data.seconds),
    seconds: Number.isFinite(Number(data.seconds)) ? Number(data.seconds) : null,
    url,
    thumbnail: clean(data.thumbnail || data.thumbnailUrl, ''),
    requester
  };
}

function normalizeAudio(raw, result) {
  if (!raw?.ok) return raw || { ok: false, msg: 'Falha ao obter áudio.' };
  const buffer = raw.buffer;
  if (!Buffer.isBuffer(buffer) || buffer.length === 0) {
    return { ok: false, code: 'INVALID_AUDIO', msg: 'O áudio retornado é inválido.' };
  }
  if (buffer.length > MAX_AUDIO_BYTES) {
    return { ok: false, code: 'AUDIO_TOO_LARGE', msg: 'O áudio excede o limite seguro para envio.' };
  }
  return {
    ok: true,
    buffer,
    mimeType: raw.mimetype || raw.mimeType || 'audio/mpeg',
    filename: raw.filename || safeFileName(result.title),
    title: clean(raw.title, result.title),
    thumbnail: clean(raw.thumbnail, result.thumbnail)
  };
}

function buildSearchMessage(query) {
  return `🔮 FANTASMINHA • PLAY\n\n⌕ Consultando os registros sonoros...\n\n🎵 ${query}\n\n✦ Aguarde a invocação...`;
}

function buildCard(result, mention) {
  return `☽━━━━━━━━━━ ✦ ━━━━━━━━━━☾\n          🔮 FANTASMINHA\n☽━━━━━━━━━━ ✦ ━━━━━━━━━━☾\n\n🎵  ${result.title}\n✦   ${result.artist}\n◈   ${result.duration}\n\n♢   Invocado por ${mention} 🤍\n\n🪄 ◌ Canalizando a essência sonora...`;
}

function buildAudioCaption(result) {
  return `🎧 ${result.title}\n✦ ${result.artist} • ${result.duration}\n\n🔮 FANTASMINHA`;
}

function buildError(kind, result, query) {
  if (kind === 'not_found') {
    return `🔮 FANTASMINHA • PLAY\n\n⌕ Nenhuma essência sonora foi encontrada.\n\n🎵 ${query}\n\n✦ Tente utilizar outro termo.`;
  }
  if (kind === 'search') {
    return `🔮 FANTASMINHA • PLAY\n\n⚠️ Não foi possível consultar os registros sonoros.\n\n✦ Tente novamente em alguns instantes.`;
  }
  return `🔮 FANTASMINHA • PLAY\n\n🎵 ${result?.title || 'Mídia'}\n✦ ${result?.artist || 'Canal desconhecido'}\n\n⚠️ Não foi possível manifestar o áudio.\n\n✦ Tente outro resultado.`;
}

function normalizeRequester(requester = {}) {
  const participantId = clean(requester.participantId || requester.senderAlternate || requester.senderOriginal || requester.senderId);
  const displayName = clean(requester.displayName, participantId ? participantId.split('@')[0] : 'Usuário');
  return { participantId, displayName };
}

export function createPlayService({ bot, chatId, quoted, reply, provider = new VexMediaProvider(), requester }) {
  const normalizedRequester = normalizeRequester(requester);
  const mention = `@${normalizedRequester.displayName.replace(/^@+/, '').slice(0, 80)}`;
  const mentions = normalizedRequester.participantId ? [normalizedRequester.participantId] : [];

  return {
    async execute(rawQuery) {
      const query = clean(rawQuery);
      if (!query) {
        return {
          ok: false,
          handled: true,
          message: '🔮 FANTASMINHA • PLAY\n\n✦ Informe o nome da música ou um link do YouTube.'
        };
      }
      if (query.length > MAX_QUERY_LENGTH) {
        return {
          ok: false,
          handled: true,
          message: '🔮 FANTASMINHA • PLAY\n\n⚠️ A pesquisa é muito longa.\n\n✦ Reduza o texto e tente novamente.'
        };
      }

      // ETAPA 1: sempre rápida e antes da pesquisa pesada.
      await reply(buildSearchMessage(query));

      let rawResult;
      try {
        rawResult = await provider.search(query);
      } catch (error) {
        console.error('[PLAY][SEARCH]', error?.message || error);
        await reply(buildError('search'));
        return { ok: false, handled: true, code: 'SEARCH_ERROR' };
      }

      if (!rawResult?.ok) {
        const msg = String(rawResult?.msg || '').toLowerCase();
        if (msg.includes('nenhum') || msg.includes('não encontrado') || msg.includes('nao encontrado')) {
          await reply(buildError('not_found', null, query));
          return { ok: false, handled: true, code: 'NOT_FOUND' };
        }
        await reply(buildError('search'));
        return { ok: false, handled: true, code: 'SEARCH_ERROR' };
      }

      const result = normalizeSearchResult(rawResult, normalizedRequester);
      if (!result) {
        await reply(buildError('search'));
        return { ok: false, handled: true, code: 'INVALID_RESULT' };
      }

      // Impede conteúdo excessivamente longo de chegar ao processamento.
      if (result.seconds != null && result.seconds > 1800) {
        await reply(`🔮 FANTASMINHA • PLAY\n\n🎵 ${result.title}\n✦ ${result.artist}\n\n⚠️ Este resultado excede o limite seguro de 30 minutos.\n\n✦ Tente outro resultado.`);
        return { ok: false, handled: true, code: 'DURATION_LIMIT' };
      }

      // ETAPA 2: thumbnail + card. A thumbnail vem do MESMO resultado.
      const card = buildCard(result, mention);
      try {
        if (result.thumbnail) {
          await bot.sendMessage(chatId, {
            image: { url: result.thumbnail },
            caption: card,
            mentions
          }, { quoted });
        } else {
          await bot.sendMessage(chatId, { text: card, mentions }, { quoted });
        }
      } catch (error) {
        console.error('[PLAY][CARD]', error?.message || error);
        // Fallback seguro da segunda etapa sem imagem.
        await bot.sendMessage(chatId, { text: card, mentions }, { quoted });
      }

      // ETAPA 3: somente agora inicia a obtenção/processamento do áudio.
      let audio;
      try {
        audio = normalizeAudio(await provider.getAudio(result), result);
      } catch (error) {
        console.error('[PLAY][AUDIO]', error?.message || error);
        await reply(buildError('audio', result));
        return { ok: false, handled: true, code: 'AUDIO_ERROR' };
      }

      if (!audio?.ok) {
        await reply(buildError('audio', result));
        return { ok: false, handled: true, code: audio?.code || 'AUDIO_ERROR' };
      }

      try {
        await bot.sendMessage(chatId, {
          audio: audio.buffer,
          mimetype: audio.mimeType,
          fileName: audio.filename,
          caption: buildAudioCaption(result)
        }, { quoted });
      } catch (error) {
        console.error('[PLAY][SEND_AUDIO]', error?.message || error);
        await reply(buildError('audio', result));
        return { ok: false, handled: true, code: 'AUDIO_SEND_ERROR' };
      }

      return { ok: true, handled: true, code: 'COMPLETED', result };
    }
  };
}

export const playInternals = {
  normalizeSearchResult,
  normalizeAudio,
  buildSearchMessage,
  buildCard,
  buildAudioCaption,
  buildError
};
