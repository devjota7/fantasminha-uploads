import fs from 'node:fs';

const idx = fs.readFileSync('dados/src/index.js', 'utf8');

for (const token of ['menuVIP(', 'menuDono(', 'menuSticker(', 'menuIa(', 'menuRPG(', 'menuFerramentas(', 'menuAlterador(', 'menuMembros(', 'menuBuscas(']) {
  if (idx.includes(token)) throw new Error(`referência executável antiga encontrada: ${token}`);
}

const vipInfo = idx.slice(idx.indexOf("case 'infovip':"), idx.indexOf("case 'addcmdvip':"));
if (!vipInfo.includes("buildCatalogMenu(prefix, 'premium'")) throw new Error('infovip/vipinfo não usa buildCatalogMenu(premium)');

const vipListStart = idx.indexOf("case 'listcmdvip':");
const vipList = idx.slice(vipListStart, idx.indexOf("case 'togglecmdvip':", vipListStart));
if (!vipList.includes("buildCatalogMenu(prefix, 'premium'")) throw new Error('listcmdvip não usa buildCatalogMenu(premium)');

const allStart = idx.indexOf('const MENU_ALL_CATEGORY_MAP');
const allEnd = idx.indexOf('const commandsArray', allStart);
const allBlock = idx.slice(allStart, allEnd);
if (!allBlock.includes('listCommands')) throw new Error('addcmdvip all não consulta o Registry diretamente');
for (const expected of ["menudono: 'dono'", "menuvip: 'premium'", "menuadm: 'adm'", "menudown: 'ferramentas'"]) {
  if (!allBlock.includes(expected)) throw new Error(`MENU_ALL_CATEGORY_MAP não cobre ${expected}`);
}

console.log('MENU VIP REGRESSION OK — infovip/listcmdvip usam catálogo central; addcmdvip all usa Registry; renderizadores antigos não são chamados.');
