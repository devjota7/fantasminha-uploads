import assert from 'node:assert/strict';
import { profileText } from '../src/services/profile.js';
const p={displayUserId:'5521991471186@s.whatsapp.net',userId:'5521991471186@s.whatsapp.net',name:'Jota 🤍',nick:'Não cadastrado',birthday:'Não cadastrado',number:'5521991471186',role:'Super Administrador',premium:false,messages:3840,botUses:563,interactionPercent:15.0,position:1,vacilos:0,peakHour:'21h',bestFriend:'5521990000000@s.whatsapp.net',relationship:'Solteiro(a)',lastSeen:Date.now()};
const out=profileText(p);
for(const token of ['𝙁𝘼𝙉𝙏𝘼𝙎𝙈𝙄𝙉𝙃𝘼','𝙍𝙀𝙂𝙄𝙎𝙏𝙍𝙊 𝘿𝘼 𝘼𝙇𝙈𝘼','𝙌𝙐𝙀𝙈 𝙑𝙀𝙄𝙊 𝘼𝙌𝙐𝙄','𝙈𝘼𝙍𝘾𝘼𝙎 𝘿𝘼 𝘼𝙇𝙈𝘼','𝘽𝙚𝙨𝙩 𝙁𝙧𝙞𝙚𝙣𝙙','𝙇𝘼𝘾̧𝙊𝙎','𝙎𝙄𝙉𝘼𝙇 𝘿𝘼 𝘼𝙇𝙈𝘼','𝙙𝙤 𝙖𝙡𝙚́𝙢']) assert.match(out,new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')));
assert.match(out,/3\.840/); assert.match(out,/563 • 15\.0%/); assert.match(out,/#1/); assert.match(out,/21h/); assert.match(out,/Solteiro\(a\)/); assert.match(out,/@5521990000000/);
assert.doesNotMatch(out,/FICHA DA ALMA/); assert.doesNotMatch(out,/PERFIL DA ALMA/);
console.log('PROFILE DESIGN OK');
