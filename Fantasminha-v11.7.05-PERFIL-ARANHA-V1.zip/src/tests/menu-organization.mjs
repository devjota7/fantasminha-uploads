import assert from 'node:assert/strict';
import { organizeCommands, MENU_STRUCTURE, getCategoryMeta } from '../dados/src/menus/catalogMenu.js';

const commands = [
  { name: 'perfil', category: 'perfil', permission: 10, enabled: true },
  { name: 'quiz', category: 'jogos', plugin: 'quizEngine', permission: 10, enabled: true, hidden: true },
  { name: 'rankquiz', category: 'rankings', plugin: 'ranking', permission: 10, enabled: true },
  { name: 'saldo', category: 'economia', permission: 10, enabled: true },
  { name: 'triagemstatus', category: 'triagem', permission: 60, enabled: true },
  { name: 'doctor', category: 'dono', permission: 100, enabled: true },
  { name: 'ping', category: 'comunidade', permission: 10, enabled: true },
  { name: 'comandoestranho', category: 'categoria_nova', permission: 10, enabled: true },
  { name: 'aliasnaoentra', category: 'jogos', permission: 10, enabled: true }
];

const member = organizeCommands(commands, { permission: 10 });
assert.equal(member.orphanCount, 0);
assert.equal(member.duplicates.length, 0);
assert.equal(member.visible.length, 7, 'membro só deve ver os comandos permitidos');
assert.ok(member.groups.has('social'));
assert.ok(member.groups.has('jogos'));
assert.ok(member.groups.has('rpg'));
assert.ok(member.groups.has('grupo'));
assert.ok(member.groups.has('ferramentas'));
assert.ok(!member.groups.has('adm'), 'adm não deve aparecer para membro comum');
assert.ok(!member.groups.has('dono'), 'dono não deve aparecer para membro comum');

const owner = organizeCommands(commands, { permission: 100 });
assert.equal(owner.visible.length, commands.length);
assert.equal(owner.orphanCount, 0);
assert.ok(owner.groups.has('adm'));
assert.ok(owner.groups.has('dono'));

for (const key of ['social','jogos','rpg','bn','ferramentas','grupo','adm','dono','sistema','premium']) {
  assert.ok(MENU_STRUCTURE[key], `estrutura ausente: ${key}`);
  assert.ok(getCategoryMeta(key));
}

const flattened = [...owner.groups.values()].flatMap(s => [...s.values()].flat()).map(c => c.name);
assert.equal(new Set(flattened).size, owner.visible.length, 'um comando não pode aparecer duplicado');
console.log(`MENU ORGANIZATION OK — ${owner.visible.length} comandos canônicos organizados; aliases fora do catálogo; fallback sem órfãos; permissões respeitadas.`);
