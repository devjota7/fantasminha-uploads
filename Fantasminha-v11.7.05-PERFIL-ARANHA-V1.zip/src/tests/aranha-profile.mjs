import assert from 'node:assert/strict';
import { clearRegistry, getCommand, listCommands, registerCommand } from '../src/core/registry.js';
import { Role } from '../src/core/permissions.js';
import { buildCatalogMenu } from '../dados/src/menus/catalogMenu.js';
import { register } from '../src/plugins/aranha/index.js';

clearRegistry();
await register();

for (const name of ['perfilaranha','menuaranha','aranhaadd','aranharemove','aranhastatus','aranhaadmin']) {
  assert.ok(getCommand(name), `comando ausente: ${name}`);
}
for (const name of ['aranhaadd','aranharemove','aranhastatus','aranhaadmin']) {
  const c=getCommand(name);
  assert.equal(c.category,'dono',`${name} precisa estar no menu dono`);
  assert.equal(c.permission,Role.OWNER);
  assert.equal(c.ownerOnly,true);
}
assert.equal(getCommand('perfilaranha').hidden,true);
assert.equal(getCommand('menuaranha').hidden,true);
const ownerMenu = await buildCatalogMenu('×', 'dono', { permission: 100 });
for (const name of ['aranhaadd','aranharemove','aranhastatus','aranhaadmin']) assert.match(ownerMenu, new RegExp(`×${name}\\b`), `${name} ausente do menudono`);
assert.doesNotMatch(ownerMenu, /×perfilaranha\b/);
console.log('aranha-profile: ok');
