import assert from 'node:assert/strict';
import tower from '../src/games/torre-limbo/index.js';

const sent=[]; let n=0;
const base={from:'test-group',sender:'test-user',pushname:'Tester',prefix:'×',isGroup:true,
  sendMessage:async(j,c)=>{sent.push(c);return {key:{remoteJid:j,id:`TL${++n}`}}},
  reply:async text=>{sent.push({text});return {key:{remoteJid:'test-group',id:`TL${++n}`}}}};
await tower.start(base);
let s=tower.getActive(base);
assert(s && s.floor===1);
assert(s.challenge);
if(!['rest','reward'].includes(s.challenge.kind)) await tower.handleInput({...base,body:`${s.challenge.answer} qualquer coisa`});
else await tower.handleInput({...base,body:'continuar'});
assert(tower.getActive(base)?.floor===2 || !tower.getActive(base));
await tower.handleInput({...base,body:'sair agora'});
assert.equal(tower.hasActive(base),false);
console.log('torre-limbo-engine: ok');
