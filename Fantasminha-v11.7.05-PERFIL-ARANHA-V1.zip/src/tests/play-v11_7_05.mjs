import assert from 'node:assert/strict';
import { createPlayService, playInternals } from '../dados/src/services/play/playService.js';

const sent = [];
const bot = {
  async sendMessage(chatId, content, options) {
    sent.push({ chatId, content, options });
    return { key: { id: `m${sent.length}` } };
  }
};

const provider = {
  async search(query) {
    assert.equal(query, 'm4');
    return {
      ok: true,
      data: {
        videoId: 'same-result-1',
        url: 'https://youtube.test/watch?v=same-result-1',
        title: 'Música Real',
        author: { name: 'Artista Real' },
        timestamp: '09:08',
        seconds: 548,
        thumbnail: 'https://img.test/same-result-1.jpg'
      }
    };
  },
  async getAudio(result) {
    assert.equal(result.id, 'same-result-1');
    return { ok: true, buffer: Buffer.from('fake-audio'), mimetype: 'audio/mpeg', filename: 'musica-real.mp3' };
  }
};

const replies = [];
const reply = async (text) => { replies.push(text); return { ok: true }; };
const service = createPlayService({
  bot,
  chatId: 'group@g.us',
  quoted: { key: { id: 'source' } },
  reply,
  provider,
  requester: {
    displayName: 'Jota',
    participantId: '5511999999999@s.whatsapp.net'
  }
});

const result = await service.execute('m4');
assert.equal(result.ok, true);
assert.equal(sent.length, 2);
assert.equal(replies.length, 1);
assert.match(replies[0], /🔮 FANTASMINHA • PLAY/);
assert.equal(sent[0].content.image.url, 'https://img.test/same-result-1.jpg');
assert.match(sent[0].content.caption, /🎵  Música Real/);
assert.match(sent[0].content.caption, /♢   Invocado por @Jota 🤍/);
assert.deepEqual(sent[0].content.mentions, ['5511999999999@s.whatsapp.net']);
assert.ok(sent[1].content.audio instanceof Buffer);
assert.equal(sent[1].content.mimetype, 'audio/mpeg');
assert.match(sent[1].content.caption, /🎧 Música Real/);

assert.equal(playInternals.buildAudioCaption({ title: 'X', artist: 'Y', duration: '01:02' }), '🎧 X\n✦ Y • 01:02\n\n🔮 FANTASMINHA');

// Thumbnail ausente: a segunda etapa continua sem imagem e o áudio permanece funcional.
sent.length = 0;
replies.length = 0;
const noThumbProvider = {
  async search() { return { ok: true, data: { id: 'x', url: 'https://youtube.test/x', title: 'Sem Capa', author: { name: 'Canal' }, seconds: 62 } }; },
  async getAudio() { return { ok: true, buffer: Buffer.from('audio') }; }
};
const s2 = createPlayService({ bot, chatId: 'g@g.us', quoted: {}, reply, provider: noThumbProvider, requester: { displayName: 'Ana', participantId: '5511888888888@s.whatsapp.net' } });
assert.equal((await s2.execute('x')).ok, true);
assert.equal(sent.length, 2);
assert.ok(sent[0].content.text);
assert.ok(sent[1].content.audio);

console.log('PLAY 11.7.05 OK — 3 etapas, VEX provider, thumbnail consistente e menção real');
