import assert from 'node:assert/strict';
import { buildCatalogMenu } from '../dados/src/menus/catalogMenu.js';
import { registerCommand, clearRegistry } from '../src/core/registry.js';

for (const name of ['brat', 'renomearpet', 'contratarnpc', 'migracoes']) {
  registerCommand({ name, category: 'dono', permission: 100, description: `teste ${name}`, handler: async () => {} });
}

const m = await buildCatalogMenu('×', 'dono', { permission: 100 });
assert.match(m, /👑 DONO/);
for (const command of ['brat', 'renomearpet', 'contratarnpc', 'migracoes']) assert.match(m, new RegExp(`×${command}\\b`), `×${command} não apareceu no menu`);
assert.doesNotMatch(m, /PODER DO DONO|PLATAFORMA & ARQUITETURA/);
clearRegistry();
console.log('MENU DONO ATUAL OK — catálogo dinâmico v11');
