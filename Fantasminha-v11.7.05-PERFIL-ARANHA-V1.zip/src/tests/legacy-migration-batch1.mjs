import fs from 'fs';
const index = fs.readFileSync(new URL('../dados/src/index.js', import.meta.url), 'utf8');
const plugin = fs.readFileSync(new URL('../src/plugins/legacyMigrationBatch1/index.js', import.meta.url), 'utf8');
const bridge = fs.readFileSync(new URL('../src/plugins/legacyRegistry/index.js', import.meta.url), 'utf8');
const bootstrap = fs.readFileSync(new URL('../src/core/bootstrap.js', import.meta.url), 'utf8');
const names = ['zipbot','gitbot','meustatus','statusbot','sticker','mention','voltei'];
for (const name of names) {
  if (!new RegExp(String.raw`name:\s*['\"]${name}['\"]`).test(plugin)) throw new Error(`handler ausente: ${name}`);
  if (new RegExp(String.raw`^\s{6}case ['\"]${name}['\"]\s*:`, 'm').test(index)) throw new Error(`case legado ainda existe: ${name}`);
  if (new RegExp(String.raw`\"name\":\"${name}\"`).test(bridge)) throw new Error(`ponte ainda contém: ${name}`);
}
for (const a of ['st','stk','s']) if (!new RegExp(String.raw`['\"]${a}['\"]`).test(plugin)) throw new Error(`alias sticker ausente: ${a}`);
for (const a of ['zip-bot','botzip','git-bot','github','infobot','botinfo']) if (!new RegExp(String.raw`['\"]${a}['\"]`).test(plugin)) throw new Error(`alias ausente: ${a}`);
if (!bootstrap.includes("legacyMigrationBatch1Plugin.register()")) throw new Error('plugin não carregado no bootstrap');
if (bridge.includes('const DEFINITIONS = const DEFINITIONS')) throw new Error('ponte corrompida');
console.log('LEGACY MIGRATION BATCH1 STATIC OK — handlers reais, cases removidos, bridge limpa para 7 canônicos e aliases cobertos.');
