import assert from 'node:assert/strict';
import fs from 'node:fs';
import { MENU_STRUCTURE, organizeCommands, buildCatalogMenu } from '../dados/src/menus/catalogMenu.js';
import { registerCommand, clearRegistry } from '../src/core/registry.js';
import { legacyDefinitions, register as registerLegacy } from '../src/plugins/legacyRegistry/index.js';

const idx=fs.readFileSync('dados/src/index.js','utf8');
assert.equal((idx.match(/sendMenuWithMedia/g)||[]).length,0,'sendMenuWithMedia ainda existe');
assert.equal((idx.match(/^      case ['"]menu['"]:/gm)||[]).length,1,'deve existir um case menu');
assert.equal(fs.existsSync('dados/src/menus/commandCatalog.json'),false,'commandCatalog.json deveria ter sido removido');
assert.equal(Object.keys(MENU_STRUCTURE).length,10,'MENU_STRUCTURE deve ter 10 submenus');
for(const k of ['social','jogos','rpg','bn','ferramentas','grupo','adm','dono','sistema','premium']) assert.ok(MENU_STRUCTURE[k]);
assert.ok(MENU_STRUCTURE.jogos.categories.includes('pets'));
assert.ok(MENU_STRUCTURE.adm.categories.includes('licenca'));
assert.ok(MENU_STRUCTURE.premium.categories.includes('premium'));

const sample=[
  {name:'socialx',category:'perfil',permission:10},
  {name:'jogosx',category:'jogos',permission:10},
  {name:'rpgx',category:'rpg',permission:10},
  {name:'iax',category:'ia',permission:10},
  {name:'sticker',category:'figurinhas',permission:10},
  {name:'pet',category:'pets',permission:10},
  {name:'grupoX',category:'clans',permission:10},
  {name:'licenca',category:'licenca',permission:60},
  {name:'ownerx',category:'dono',permission:100},
  {name:'systemx',category:'sistema',permission:10},
  {name:'vip',category:'premium',permission:40}
];
const o=organizeCommands(sample,{permission:100});
assert.equal(o.duplicates.length,0);
assert.equal(o.orphanCount,0);
assert.equal(new Set(o.visible.map(x=>x.name)).size,o.visible.length);
const root=buildCatalogMenu('×',null,{permission:100,commands:sample});
for(const k of Object.keys(MENU_STRUCTURE)) assert.match(root,new RegExp(`menu ${k.replace('-', '\\-')}`));

clearRegistry();
const stats=await registerLegacy();
assert.equal(stats.total,legacyDefinitions.length);
assert.ok(stats.added>500,'ponte legada deve registrar a maior parte dos comandos do switch');
const legacyMenu=buildCatalogMenu('×','ferramentas',{permission:100});
assert.match(legacyMenu,/×sticker/,'sticker precisa aparecer em ferramentas');
const pets=buildCatalogMenu('×','jogos',{permission:100});
assert.match(pets,/×pet/,'pets precisa aparecer em jogos');

// Alias canônico: um grupo de aliases deve gerar uma única entrada no catálogo.
registerCommand({name:'aliascanonico',aliases:['alias-a','alias-b'],category:'ferramentas',permission:10,description:'Teste',handler:()=>{}});
const aliasMenu=buildCatalogMenu('×','ferramentas',{permission:100});
assert.equal((aliasMenu.match(/×aliascanonico/g)||[]).length,1);
assert.equal((aliasMenu.match(/×alias-a/g)||[]).length,0);
assert.equal((aliasMenu.match(/×alias-b/g)||[]).length,0);

clearRegistry();
console.log(`MENU CONSOLIDATION OK — 10 submenus; ponte legada ${stats.added} comandos; aliases não renderizados; sticker/pets/licenca/premium cobertos.`);
