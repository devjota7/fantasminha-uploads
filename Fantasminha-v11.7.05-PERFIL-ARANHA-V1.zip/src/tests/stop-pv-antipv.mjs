import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { beginConfig, handleAnswer, isStopPrivateInputAllowed } from '../src/games/stop/StopCore.js';

const dbDir=path.join(process.cwd(),'data','db');
fs.mkdirSync(dbDir,{recursive:true});
const names=['stop_user_configs.json','stop_private_state.json'];
const backup={};
for(const n of names){const f=path.join(dbDir,n);backup[n]=fs.existsSync(f)?fs.readFileSync(f):null;}

const sent=[];
const groupCtx={
  sender:'5511999999999@s.whatsapp.net', from:'120000000000@g.us', isGroup:true, isPrivate:false,
  prefix:'×', sendMessage:async(j,c)=>sent.push({j,c}), reply:async()=>{}
};
const pv=(body)=>({
  sender:'5511999999999@s.whatsapp.net', from:'5511999999999@s.whatsapp.net', isGroup:false, isPrivate:true,
  body, text:body, sendMessage:async(j,c)=>sent.push({j,c}), reply:async(t)=>sent.push({j,c:{text:t}})
});

try {
  for(const n of names) fs.rmSync(path.join(dbDir,n),{force:true});
  await beginConfig(groupCtx);
  assert.equal(isStopPrivateInputAllowed(groupCtx.sender,'Animal, Comida'),true);
  const categories=await handleAnswer(pv('Animal, Comida'));
  assert.equal(categories.handled,true);
  assert.equal(categories.updated ?? true,true);
  assert.equal(isStopPrivateInputAllowed(groupCtx.sender,'3'),true);
  const rounds=await handleAnswer(pv('3'));
  assert.equal(rounds.handled,true);
  assert.equal(rounds.completed,true);
  assert.equal(isStopPrivateInputAllowed(groupCtx.sender,'qualquer texto fora do fluxo'),false);
  console.log('STOP PV ANTIPV OK — configuração privada não é bloqueada e o PV comum continua protegido.');
} finally {
  for(const n of names){const f=path.join(dbDir,n);if(backup[n]===null)fs.rmSync(f,{force:true});else fs.writeFileSync(f,backup[n]);}
}
