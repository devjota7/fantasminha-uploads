# CHANGELOG — Fantasminha

## [11.7.05] — MENU CONSOLIDADO

### Menu e catálogo
- Auditoria dos comandos do switch legado e criação de ponte de catálogo para o Registry.
- `menu`, `help`, `comandos` e `commands` permanecem como portal oficial; atalhos antigos convergem para `menu <categoria>`.
- `MENU_STRUCTURE` passa a ter 10 submenus, incluindo `💎 PREMIUM`.
- `pets` foi incorporado a JOGOS e `configuracao` foi normalizado para `licenca` dentro de ADM.
- Figurinhas passam a ser descobertas pelo Registry e aparecem em FERRAMENTAS.
- Aliases continuam fora da renderização: cada comando canônico ocupa uma única linha.
- Menus hardcoded foram removidos; `dados/src/menus/` ficou reduzido aos módulos dinâmicos.
- `commandCatalog.json` órfão foi removido e o Response Media Manager passou a usar exclusivamente o Registry.
- A implementação duplicada de `menualem` no plugin de expansão foi removida.
- Novo padrão visual de caixas com identidade Fantasminha, paginação e suporte ao `getMenuLerMaisText()`.

## [11.7.05] — PLAY + VEX

### Sistema PLAY
- Novo fluxo oficial em 3 etapas: pesquisa → thumbnail + card → áudio.
- `.play` passou a ser orquestrado pelo `PlayService`, sem concentrar toda a lógica no handler.
- Integração do PLAY com o provider de mídia VEX já existente no projeto.
- Thumbnail e metadados são obtidos do mesmo resultado selecionado para evitar inconsistência de mídia.
- Segunda etapa envia thumbnail e card na mesma mensagem; fallback textual é utilizado quando a imagem não estiver disponível.
- Terceira etapa envia o áudio somente depois da segunda etapa.
- Menção dinâmica do executor usando o identificador real do contexto WhatsApp.
- Tratamento de pesquisa vazia, resultado inexistente, falhas de provider, limite de duração, áudio inválido e falha de envio.
- Validação de tamanho do áudio e filename seguro.
- Separação em `PlayService` + `VexMediaProvider`, permitindo reutilização pelo Mega Assistente sem chamada direta da IA à VEX.


Este arquivo é cumulativo. A regra do projeto é manter aqui o estado documental
atual do Fantasminha e registrar cada release publicada sem apagar o histórico.

## [11.7.04] — FINAL

### Arquitetura e Registry
- Consolidação do Command Registry como fonte de verdade dos comandos.
- Organização dinâmica dos menus a partir do Registry.
- Aliases mantidos como referências de comandos canônicos, sem duplicação no
  menu.
- Permissões, cooldowns, auditoria, métricas e controle de concorrência
  centralizados.

### Prefixo
- Implementação do resolvedor central de prefixo.
- Prioridade `GRUPO → GLOBAL`.
- Isolamento do prefixo entre grupos.
- Validação e fallback para valores inválidos.
- Cache com invalidação.
- Auditoria de alterações.
- Parser, menus e respostas preparados para utilizar o prefixo efetivo.

### Triagem
- Triagem persistente com estados de execução, julgamento, aprovação,
  rejeição, expiração e cancelamento.
- Fluxo PV com código de triagem.
- Configuração de grupos de entrada, triagem, gestão e aprovação.
- Snapshot de configuração no início da triagem.
- Auditoria e proteção contra duplicação.
- Aprovação humana e rejeição com motivo obrigatório.

### Jogos e Ranking
- Game Engine integrado aos fluxos compatíveis.
- Ranking Central integrado aos jogos.
- Quiz, Forca, Stop, Gartic e Memory Cups preservados.
- Forca continua após erro e finaliza corretamente ao completar a palavra.
- Stop possui fluxo completo de lobby, rodada, respostas, validação,
  pontuação e finalização.
- Gartic possui validação tolerante a acentos, plural, aliases e pequenas
  variações de escrita.

### Assistant V2
- Bridge funcional para o Assistant V2.
- Core canônico preservado.
- Guards de entrada e validação reforçados.
- Métricas protegidas contra estruturas inválidas.

### Mensagens privadas
- PV Gateway com códigos e IDs válidos para triagem e partidas.
- Comandos privados de jogos controlados por allowlist.
- Mensagens privadas arbitrárias não entram no fluxo de comandos de jogo.

### Persistência, auditoria e recuperação
- Persistência JSON com escrita atômica e proteção de concorrência.
- Idempotência em operações que exigem proteção contra retry.
- Auditoria de operações críticas.
- Backup e rollback no atualizador.
- Proteção de dados locais e arquivos não pertencentes à release.

### Release e documentação
- `latest.json` passa a ser tratado como manifesto operacional obrigatório da
  release publicada.
- `release-manifest.json` registra a integridade física do ZIP.
- Toda release deve gerar SHA-256 e tamanho a partir do ZIP real.
- A documentação e as regras permanentes devem acompanhar a evolução do código.

### Correções de estabilidade desta revisão
- Gerador de códigos do STOP corrigido para produzir sempre exatamente 8 caracteres alfanuméricos após `STP-`, sem encurtamento causado por Base64URL.
- Catálogo da expansão corrigido para não anunciar o comando inexistente `×forcax`.
- Registros canônicos duplicados da expansão removidos, preservando as implementações V2 consolidadas.
- Testes de menu atualizados para o contrato do catálogo dinâmico atual.
- Scanner de prelaunch passou a reconhecer o uso fixo e revisado de `execFileSync` em `scripts/update-safety.mjs`.
- Adicionados testes de regressão para códigos STOP e duplicação de registros.

## Regra de manutenção

Nenhuma nova release deve ser publicada sem atualizar este changelog,
as release notes aplicáveis e o manifesto `latest.json` correspondente à
release. O histórico não deve ser apagado para substituir uma versão anterior.
