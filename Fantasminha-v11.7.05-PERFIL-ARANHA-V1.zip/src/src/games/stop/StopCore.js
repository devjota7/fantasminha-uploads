import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import game from '../../services/gameEngine.js';
import stats from '../../services/statsEngine.js';
import { emit } from '../../events/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import { configuredOwner } from '../../core/permissions.js';
import config from '../../core/config.js';
import { parseStopAnswers } from './StopAnswerParser.js';
import { validateDeterministic } from './StopAnswerValidator.js';
import { validateWithAI } from './StopAIValidator.js';
import { scoreRound } from './StopScoreEngine.js';

export const STOP_STATES = Object.freeze({ CONFIGURING:'CONFIGURING', LOBBY_OPEN:'LOBBY_OPEN', LOBBY_CLOSED:'LOBBY_CLOSED', WAITING_CREATOR_START:'WAITING_CREATOR_START', ROUND_STARTING:'ROUND_STARTING', ROUND_ACTIVE:'ROUND_ACTIVE', ROUND_LOCKED:'ROUND_LOCKED', VALIDATING:'VALIDATING', ROUND_RESULT:'ROUND_RESULT', FINISHED:'FINISHED', CANCELLED:'CANCELLED', EXPIRED:'EXPIRED', ERROR_RECOVERY:'ERROR_RECOVERY' });
export const ROUND_MS = 120_000;
export const LOBBY_MS = 60_000;
const letters='ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const locks=new Map();
const pendingTimers=new Map();
const n=s=>String(s??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
const lock=(key,fn)=>{const prev=locks.get(key)||Promise.resolve();let release;const cur=new Promise(r=>release=r);locks.set(key,prev.then(()=>cur));return prev.then(async()=>{try{return await fn();}finally{release();if(locks.get(key)===cur)locks.delete(key);}})};
const uid=ctx=>ctx?.sender||'unknown'; const gid=ctx=>ctx?.from||'private';
const mid=ctx=>ctx.message?.key?.id||ctx.key?.id||null;
const mention=id=>`@${String(id).split('@')[0]}`;
function now(){return Date.now()}
async function audit(action,session,extra={}){try{await recordAudit({actor:extra.userId||session?.createdBy||null,target:session?.groupId||null,action,scope:session?.groupId||null,details:extra.details||{sessionId:session?.sessionId||null}});}catch{}}
const STOP_CODE_ALPHABET='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
export function generateStopCode(){
  const db=readCollection('stop_sessions',{byId:{},byCode:{}});
  let codeValue='';
  do {
    const bytes=crypto.randomBytes(8);
    let body='';
    for(const byte of bytes) body+=STOP_CODE_ALPHABET[byte % STOP_CODE_ALPHABET.length];
    codeValue=`STP-${body}`;
  } while(db.byCode?.[codeValue]);
  return codeValue;
}
function code(){return generateStopCode();}
function normalizeCategories(raw){const arr=Array.isArray(raw)?raw:String(raw||'').split(/[\n,;|]+/);const out=[];const seen=new Set();for(const item of arr){const v=String(item||'').replace(/\s+/g,' ').trim();const k=n(v);if(!k||seen.has(k))continue;seen.add(k);out.push(v.slice(0,60));if(out.length===10)break;}return out;}
function validRounds(v){const x=Number(String(v||'').trim());return Number.isInteger(x)&&x>=1&&x<=5?x:null;}
function configKey(userId){return String(userId)}
function emptyConfig(){return {status:'ACTIVE',categories:[],roundsTotal:0,createdAt:now(),updatedAt:now(),deletedAt:null};}
function sessionFromGame(g){return g?.state?.stopSession||null;}
function gameActive(g){return g && g.gameType==='STOP' && ['WAITING','ACTIVE'].includes(g.status) && ![STOP_STATES.FINISHED,STOP_STATES.CANCELLED].includes(g.state?.stopSession?.status);}
export function getSessionByGroup(groupId){return game.listActiveGames(groupId).find(gameActive)||null;}
export function getSessionByCode(stopCode){
 const normalized=String(stopCode||'').trim().toUpperCase();
 if(!normalized)return null;
 const db=readCollection('stop_sessions',{byId:{},byCode:{}});
 const id=db.byCode?.[normalized];
 if(id&&db.byId?.[id])return db.byId[id];
 // Fallback de recuperação: se o índice byCode estiver ausente/desatualizado,
 // procura somente sessões STOP ativas no Game Engine e repara o índice.
 const active=game.listActiveGames().find(g=>gameActive(g)&&g.state?.stopSession?.stopCode===normalized);
 const recovered=active?.state?.stopSession||null;
 if(recovered){
   void persistSession(recovered).catch(()=>{});
   return recovered;
 }
 return null;
}
export function getConfig(userId){return readCollection('stop_user_configs',{byId:{}}).byId?.[configKey(userId)]||null;}

// O STOP possui fluxos privados próprios. Esta função permite que o gateway legado
// do antipv deixe passar somente quem realmente possui uma etapa privada do STOP
// ou participa de uma sessão ativa. Assim a configuração no PV continua funcionando
// mesmo quando antipv/antipv4 estiverem ativos, sem liberar o PV inteiro.
export function isStopPrivateInputAllowed(userId, text=''){
  const id=String(userId||'').trim();
  if(!id)return false;
  const raw=String(text||'').trim();
  const privateState=readCollection('stop_private_state',{byUser:{}}).byUser?.[id];
  if(privateState?.step)return true;
  if(/^STP-[A-Z0-9]{8}$/i.test(raw)){
    return !!getSessionByCode(raw);
  }
  const active=game.listActiveGames().filter(gameActive);
  return active.some(g=>{
    const session=sessionFromGame(g);
    return session?.participants?.some(p=>String(p?.userId||'')===id);
  });
}
async function saveConfig(userId,patch){return updateCollection('stop_user_configs',db=>{db.byId??={};const prev=db.byId[configKey(userId)]||emptyConfig();db.byId[configKey(userId)]={...prev,...patch,updatedAt:now()};return db;},{byId:{}}).then(db=>db.byId[configKey(userId)]);}
export async function beginConfig(ctx){const userId=uid(ctx);await saveConfig(userId,{status:'CONFIGURING',categories:[],roundsTotal:0,createdAt:now(),updatedAt:now(),deletedAt:null});await updateCollection('stop_private_state',db=>{db.byUser??={};db.byUser[userId]={step:'CATEGORIES',startedAt:now(),updatedAt:now()};return db;},{byUser:{}});await ctx.sendMessage?.(userId,{text:renderConfigCategories()});return {handled:true};}
function renderConfigCategories(){return `╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   ⚙️ CONFIGURAÇÃO\n╰━━━━━━━━━━━━━━━━━━╯\n\n📋 Envie de 1 a 10 categorias.\n\nExemplo:\nAnimal, Comida, Nome, Marca, Filme\n\n• Pode separar por vírgula ou linha.\n• Categorias vazias e repetidas serão removidas.\n• Digite *cancelar* para sair.\n\n╰━━━━━━━━━━━━━━━━━━╯`;}
function renderConfigRounds(categories){return `╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   🔄 NÚMERO DE RODADAS\n╰━━━━━━━━━━━━━━━━━━╯\n\n📋 Categorias: ${categories.length}\n${categories.map((x,i)=>`${i+1}️⃣ ${x}`).join('\n')}\n\nEscolha de 1 a 5 rodadas.\n⏱️ Cada rodada terá 2 minutos.\n\nEnvie apenas: 1, 2, 3, 4 ou 5.\n\n╰━━━━━━━━━━━━━━━━━━╯`;}
export async function handleConfigPrivate(ctx){if(!ctx.isPrivate||!uid(ctx))return {handled:false};const userId=uid(ctx);const db=readCollection('stop_private_state',{byUser:{}});const p=db.byUser?.[userId];if(!p)return {handled:false};const text=String(ctx.body||ctx.text||'').trim();if(!text)return {handled:true};if(n(text)==='cancelar'){await updateCollection('stop_private_state',d=>{delete d.byUser?.[userId];return d;},{byUser:{}});await ctx.sendMessage?.(userId,{text:'🛑 Configuração do STOP cancelada.'});return {handled:true,cancelled:true};}
if(p.step==='CATEGORIES'){
 const cats=normalizeCategories(text); if(cats.length<1){await ctx.sendMessage?.(userId,{text:'⚠️ Envie pelo menos 1 categoria válida.'});return {handled:true,invalid:true};}
 await saveConfig(userId,{status:'CONFIGURING',categories:cats}); await updateCollection('stop_private_state',d=>{d.byUser[userId]={step:'ROUNDS',startedAt:p.startedAt,updatedAt:now()};return d;},{byUser:{}});await ctx.sendMessage?.(userId,{text:renderConfigRounds(cats)});return {handled:true};
}
if(p.step==='ROUNDS'){
 if(['editar','categorias','editar categorias'].includes(n(text))){await updateCollection('stop_private_state',d=>{d.byUser[userId]={step:'CATEGORIES',startedAt:p.startedAt,updatedAt:now()};return d;},{byUser:{}});await ctx.sendMessage?.(userId,{text:renderConfigCategories()});return {handled:true,editing:true};}
 const rounds=validRounds(text); if(!rounds){await ctx.sendMessage?.(userId,{text:'⚠️ O número de rodadas deve ser de 1 a 5.'});return {handled:true,invalid:true};}
 const saved=await saveConfig(userId,{status:'ACTIVE',roundsTotal:rounds});await updateCollection('stop_private_state',d=>{delete d.byUser?.[userId];return d;},{byUser:{}});await audit('STOP_CONFIG_CREATED',null,{userId,details:{categories:saved.categories.length,rounds:rounds}});await emit('STOP_CONFIG_CREATED',{userId,categories:saved.categories,roundsTotal:rounds});await ctx.sendMessage?.(userId,{text:`╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   ✅ CONFIGURAÇÃO\n╰━━━━━━━━━━━━━━━━━━╯\n\n📋 Categorias: ${saved.categories.length}\n🔄 Rodadas: ${rounds}\n⏱️ Cada rodada: 2 minutos\n\nSua configuração está pronta.\n\nUse ×stop no grupo para\nabrir uma partida.\n\n╰━━━━━━━━━━━━━━━━━━╯`});return {handled:true,completed:true};}
return {handled:false};}

export async function beginDelete(ctx){if(!ctx.isGroup)return {handled:false};const userId=uid(ctx);const c=getConfig(userId);if(!c||c.status==='DELETED'){return ctx.reply?.('⚠️ Você não possui uma configuração ativa do STOP.')?.then?.(()=>({handled:true}))||{handled:true};}await updateCollection('stop_private_state',d=>{d.byUser??={};d.byUser[userId]={step:'DELETE_CONFIRM',startedAt:now(),updatedAt:now()};return d;},{byUser:{}});await ctx.sendMessage?.(userId,{text:`╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   🗑️ EXCLUIR CONFIGURAÇÃO\n╰━━━━━━━━━━━━━━━━━━╯\n\n⚠️ Você está prestes a excluir\nsua configuração atual.\n\nIsso permitirá criar uma\nnova configuração.\n\n📋 Partidas antigas, resultados,\nranking e histórico permanecerão\nintactos.\n\n1️⃣ SIM, EXCLUIR\n2️⃣ NÃO, CANCELAR\n\n✏️ Responda com 1 ou 2.\n\n╰━━━━━━━━━━━━━━━━━━╯`});return {handled:true};}
async function handleDeleteConfirm(ctx){const userId=uid(ctx);const p=readCollection('stop_private_state',{byUser:{}}).byUser?.[userId];if(!p||p.step!=='DELETE_CONFIRM')return {handled:false};const text=String(ctx.body||ctx.text||'').trim();if(text==='1'){await saveConfig(userId,{status:'DELETED',deletedAt:now()});await updateCollection('stop_private_state',d=>{delete d.byUser?.[userId];return d;},{byUser:{}});await audit('STOP_CONFIG_DELETED',null,{userId});await emit('STOP_CONFIG_DELETED',{userId});await ctx.sendMessage?.(userId,{text:'🗑️ Sua configuração do STOP foi excluída.\n\nO histórico das partidas permanece intacto. 👻'});return {handled:true,deleted:true};}if(text==='2'||n(text)==='cancelar'){await updateCollection('stop_private_state',d=>{delete d.byUser?.[userId];return d;},{byUser:{}});await ctx.sendMessage?.(userId,{text:'✅ Exclusão cancelada. Sua configuração continua ativa.'});return {handled:true,cancelled:true};}await ctx.sendMessage?.(userId,{text:'⚠️ Responda somente com 1 ou 2.'});return {handled:true};}

function linkFor(ctx,stopCode){const raw=String(ctx.botJid||'').split(':')[0];const digits=raw.replace(/[^0-9]/g,'');return digits?`https://wa.me/${digits}?text=${encodeURIComponent(stopCode)}`:`https://wa.me/?text=${encodeURIComponent(stopCode)}`;}
function initialSession(ctx,cfg,stopCode,gameId){const t=now();return {sessionId:gameId,gameId,stopCode,groupId:gid(ctx),groupName:ctx.groupName||'Grupo',createdBy:uid(ctx),categoriesSnapshot:cfg.categories.map(x=>({name:x,key:n(x)})),roundsTotal:cfg.roundsTotal,currentRound:0,status:STOP_STATES.LOBBY_OPEN,lobbyStartedAt:t,lobbyExpiresAt:t+LOBBY_MS,createdAt:t,updatedAt:t,finishedAt:null,cancelledAt:null,participants:[],rounds:[],processedMessageIds:[],usedLetters:[],scores:{}};}
async function persistSession(session){return updateCollection('stop_sessions',db=>{db.byId??={};db.byCode??={};db.byId[session.sessionId]=session;db.byCode[session.stopCode]=session.sessionId;return db;},{byId:{},byCode:{}});}
async function persistParticipant(session, participant){await updateCollection('stop_participants',db=>{db.byId??={};const k=`${session.sessionId}::${participant.userId}`;db.byId[k]={...participant,id:k,sessionId:session.sessionId};return db;},{byId:{}});}
async function persistAnswer(session, round, userId, answer){return persistAnswers(session,round,userId,[answer]);}
async function persistAnswers(session, round, userId, answers){
  const list=Array.isArray(answers)?answers:[];
  if(!list.length)return;
  await updateCollection('stop_answers',db=>{
    db.byId??={};
    for(const answer of list){
      const id=`${round.roundId}::${userId}::${answer.categoryKey}`;
      db.byId[id]={id,roundId:round.roundId,sessionId:session.sessionId,userId,...answer};
    }
    return db;
  },{byId:{}});
}
async function persistRoundResults(session){await updateCollection('stop_round_results',db=>{db.byId??={};for(const p of session.participants){const r=session.round.results?.[p.userId]||{};const vals=Object.values(r);const id=`${session.round.roundId}::${p.userId}`;db.byId[id]={id,roundId:session.round.roundId,sessionId:session.sessionId,userId:p.userId,validCount:vals.filter(v=>String(v.status).startsWith('VALID')).length,uniqueCount:vals.filter(v=>v.status==='VALID_UNIQUE').length,duplicateCount:vals.filter(v=>v.status==='VALID_DUPLICATE').length,invalidCount:vals.filter(v=>v.status==='INVALID').length,emptyCount:vals.filter(v=>v.status==='EMPTY').length,points:vals.reduce((a,v)=>a+Number(v.points||0),0),createdAt:now()};}return db;},{byId:{}});}
async function persistValidationResults(session){await updateCollection('stop_answers',db=>{db.byId??={};for(const [user,cats] of Object.entries(session.round.results||{}))for(const [categoryKey,v] of Object.entries(cats||{})){const id=`${session.round.roundId}::${user}::${categoryKey}`;if(db.byId[id])db.byId[id]={...db.byId[id],validationStatus:v.status,validationReason:v.reason||'',validationConfidence:Number(v.confidence)||0,aiResult:v,points:Number(v.points)||0,updatedAt:now()};}return db;},{byId:{}});}
function lobbyText(s,ctx){return `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n    🎮 NOVA PARTIDA\n╰━━━━━━━━━━━━━━━━━━╯\n\n👤 Criador: ${mention(s.createdBy)}\n\n🚀 Uma partida de STOP foi criada!\n\nQuer participar?\n\n🔗 🛑 PARTICIPAR DO STOP\n${linkFor(ctx,s.stopCode)}\n\n⏱️ Inscrições abertas por 60 segundos.\n\n╰━━━━━━━━━━━━━━━━━━╯`;}
export async function createSession(ctx){if(!ctx.isGroup)return ctx.reply?.('⚠️ ×stop funciona apenas em grupos.');const cfg=getConfig(uid(ctx));if(!cfg||cfg.status!=='ACTIVE'||!Array.isArray(cfg.categories)||!cfg.categories.length||!validRounds(cfg.roundsTotal))return ctx.reply?.(`⚠️ Você ainda não possui uma configuração válida do STOP.\n\nUse ${ctx.prefix||'×'}stopcriar para configurar no PV.`);if(getSessionByGroup(gid(ctx)))return ctx.reply?.('⚠️ Já existe um STOP ativo neste grupo.');return lock(`group:${gid(ctx)}`,async()=>{if(getSessionByGroup(gid(ctx)))return ctx.reply?.('⚠️ Já existe um STOP ativo neste grupo.');const stopCode=code();const g=await game.createGame({groupId:gid(ctx),gameType:'STOP',creatorId:uid(ctx),maxPlayers:999,state:{stopSession:initialSession(ctx,cfg,stopCode,'PENDING')},timeoutMs:0,metadata:{gameType:'STOP'},onePerGroup:true});const session=initialSession(ctx,cfg,stopCode,g.gameId);session.sessionId=g.gameId;await game.updateGame(g.gameId,gid(ctx),x=>{x.state.stopSession=session;return x;});await persistSession(session);await emit('GAME_CREATED',{gameType:'STOP',sessionId:g.gameId,groupId:gid(ctx)});await emit('GAME_LOBBY_OPENED',{gameType:'STOP',sessionId:g.gameId,groupId:gid(ctx)});await emit('STOP_SESSION_CREATED',{sessionId:g.gameId,groupId:gid(ctx),stopCode});await emit('STOP_LOBBY_OPENED',{sessionId:g.gameId,groupId:gid(ctx)});await audit('STOP_SESSION_CREATED',session,{userId:uid(ctx),details:{categories:session.categoriesSnapshot.length,rounds:session.roundsTotal}});schedule(g.gameId,session.lobbyExpiresAt);return ctx.reply?.(lobbyText(session,ctx),{mentions:[session.createdBy]});});}
function schedule(gameId,at){clearTimer(gameId);const delay=Math.max(50,at-now());const t=setTimeout(()=>tick(gameId).catch(()=>{}),delay);t.unref?.();pendingTimers.set(gameId,t);}
function clearTimer(gameId){const t=pendingTimers.get(gameId);if(t){clearTimeout(t);pendingTimers.delete(gameId);}}
function getGameSession(gameId){const g=game.getGame(gameId);return g?.gameType==='STOP'?g:null;}
async function updateBoth(gameId,groupId,fn){const updated=await game.updateGame(gameId,groupId,g=>{g.state.stopSession=fn(structuredClone(g.state.stopSession));return g;});await persistSession(updated.state.stopSession);return updated.state.stopSession;}
async function tick(gameId){const g=getGameSession(gameId);if(!g)return;const s=sessionFromGame(g);if(!s)return;if(s.status===STOP_STATES.LOBBY_OPEN&&now()>=s.lobbyExpiresAt){await closeLobby(g);return;}if(s.status===STOP_STATES.ROUND_ACTIVE&&now()>=s.round?.expiresAt){await lockRound(g);return;}if([STOP_STATES.ROUND_ACTIVE,STOP_STATES.LOBBY_OPEN].includes(s.status))schedule(gameId,s.status===STOP_STATES.LOBBY_OPEN?s.lobbyExpiresAt:s.round.expiresAt);}

export async function joinByCode(ctx){if(!ctx.isPrivate)return {handled:false};const text=String(ctx.body||ctx.text||'').trim().toUpperCase();if(!/^STP-[A-Z0-9]{8}$/.test(text))return {handled:false};const sess=getSessionByCode(text);if(!sess)return ctx.sendMessage?.(uid(ctx),{text:'❌ O ID do STOP não foi encontrado.'}).then(()=>({handled:true}));return lock(`session:${sess.sessionId}`,async()=>{const g=getGameSession(sess.gameId);const s=sessionFromGame(g);if(!g||!s||s.groupId!==sess.groupId)return ctx.sendMessage?.(uid(ctx),{text:'❌ Esta partida não está disponível.'}).then(()=>({handled:true}));if(s.status!==STOP_STATES.LOBBY_OPEN||now()>s.lobbyExpiresAt)return ctx.sendMessage?.(uid(ctx),{text:'⏰ O lobby desta partida já foi encerrado.'}).then(()=>({handled:true}));const existing=s.participants.find(p=>p.userId===uid(ctx));if(existing)return ctx.sendMessage?.(uid(ctx),{text:`✅ Sua presença já está registrada!\n\n📋 Categorias:\n${s.categoriesSnapshot.map((x,i)=>`${i+1}️⃣ ${x.name}`).join('\n')}\n\n🔄 Rodadas: ${s.roundsTotal}\n⏱️ Cada rodada: 2 minutos`}).then(()=>({handled:true,duplicate:true}));const updated=await updateBoth(g.gameId,s.groupId,ss=>{ss.participants.push({userId:uid(ctx),joinedAt:now(),status:'JOINED',lastActivityAt:now(),totalScore:0});return ss;});await persistParticipant(updated,updated.participants.find(p=>p.userId===uid(ctx)));await audit('STOP_PARTICIPANT_JOINED',updated,{userId:uid(ctx)});await emit('GAME_PLAYER_JOINED',{gameType:'STOP',sessionId:updated.sessionId,groupId:updated.groupId,userId:uid(ctx)});await emit('STOP_PARTICIPANT_JOINED',{sessionId:updated.sessionId,groupId:updated.groupId,userId:uid(ctx)});await ctx.sendMessage?.(uid(ctx),{text:`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   ✅ PRESENÇA REGISTRADA\n╰━━━━━━━━━━━━━━━━━━╯\n\nVocê entrou na partida!\n\n📋 Categorias:\n${updated.categoriesSnapshot.map((x,i)=>`${i+1}️⃣ ${x.name}`).join('\n')}\n\n🔄 Rodadas: ${updated.roundsTotal}\n⏱️ Cada rodada: 2 minutos\n\n⚠️ Aguarde o encerramento\ndo lobby.\n\n╰━━━━━━━━━━━━━━━━━━╯`});return {handled:true,joined:true};});}

async function closeLobby(g){const s=sessionFromGame(g);if(!s||s.status!==STOP_STATES.LOBBY_OPEN)return;clearTimer(g.gameId);const updated=await updateBoth(g.gameId,s.groupId,ss=>{ss.status=STOP_STATES.LOBBY_CLOSED;ss.updatedAt=now();return ss;});await emit('GAME_LOBBY_CLOSED',{gameType:'STOP',sessionId:g.gameId,groupId:s.groupId});await emit('STOP_LOBBY_CLOSED',{sessionId:g.gameId,groupId:s.groupId});await audit('STOP_LOBBY_CLOSED',updated,{userId:updated.createdBy});await ctxSendGroup(updated.groupId,renderLobbyClosed(updated));await updateBoth(g.gameId,s.groupId,ss=>{ss.status=STOP_STATES.WAITING_CREATOR_START;return ss;});}
function renderLobbyClosed(s){const list=s.participants.length?s.participants.map((p,i)=>`${i+1}. ${mention(p.userId)}`).join('\n'):'Nenhum participante.';return `╭━━━ 🛑 STOP ━━━╮\n⏰ LOBBY FECHADO!\n\n👤 Criador: ${mention(s.createdBy)}\n\n👥 PARTICIPANTES:\n${list}\n\n━━━━━━━━━━━━━━━━\n\n🏁 A partida está pronta.\n\nSomente o criador deve responder:\n1️⃣ Sim\n2️⃣ Não\n\n╰━━━━━━━━━━━━━━━━╯`;}
async function ctxSendGroup(groupId,text,options={}){const transport=globalThis.__fantasminhaStopTransport;try{return await transport?.sendMessage?.(groupId,{text,...options})}catch{return null}}
export function attachTransport(ctx){if(ctx?.sendMessage)globalThis.__fantasminhaStopTransport={sendMessage:ctx.sendMessage};}

async function startFromCreator(ctx,s){if(uid(ctx)!==s.createdBy)return {handled:false};return lock(`session:${s.sessionId}`,async()=>{const g=getGameSession(s.gameId);const ss=sessionFromGame(g);if(!g||!ss||ss.status!==STOP_STATES.WAITING_CREATOR_START)return {handled:false};if(!ss.participants.length){await ctx.reply?.('⚠️ Não há participantes registrados. A partida não pode iniciar.');return {handled:true,started:false};}const updated=await updateBoth(s.gameId,s.groupId,x=>{x.status=STOP_STATES.ROUND_STARTING;return x;});await emit('STOP_START_CONFIRMED',{sessionId:s.sessionId,groupId:s.groupId,userId:uid(ctx)});await emit('GAME_STARTED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId});await startRound(updated,ctx);return {handled:true,started:true};});}
async function cancelCreatorStart(ctx,s){if(uid(ctx)!==s.createdBy)return {handled:false};await cancelSession(s,ctx,'START_CANCELLED');return {handled:true,cancelled:true};}

function selectLetter(s){const available=letters.filter(x=>!s.usedLetters.includes(x));if(!available.length)return letters[Math.floor(Math.random()*letters.length)];const idx=crypto.randomInt(0,available.length);return available[idx];}
function renderCategories(s){return s.categoriesSnapshot.map((x,i)=>`${['🐾','🍔','👤','🏷️','🎬','🌍','🎨','💼','🎵','📦'][i]||'📋'} ${x.name}`).join('\n');}
async function startRound(s,ctx){const letter=selectLetter(s);const roundNumber=s.currentRound+1;const t=now();const round={roundId:`${s.sessionId}-${roundNumber}`,roundNumber,letter,startedAt:t,expiresAt:t+ROUND_MS,lockedAt:null,status:STOP_STATES.ROUND_ACTIVE,answers:{},results:{},createdAt:t,updatedAt:t};const updated=await updateBoth(s.gameId,s.groupId,x=>{x.currentRound=roundNumber;x.status=STOP_STATES.ROUND_ACTIVE;x.usedLetters.push(letter);x.round=round;x.rounds.push({roundId:round.roundId,roundNumber,letter,startedAt:t,expiresAt:t+ROUND_MS,status:STOP_STATES.ROUND_ACTIVE});return x;});await emit('GAME_ROUND_STARTED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId,roundNumber,userId:uid(ctx)});await emit('STOP_ROUND_STARTED',{sessionId:s.sessionId,groupId:s.groupId,roundNumber,letter});await audit('STOP_ROUND_STARTED',updated,{userId:uid(ctx),details:{roundNumber,letter}});await ctxSendGroup(s.groupId,`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n    🚨 RODADA ${roundNumber}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 LETRA SORTEADA: ${letter}\n\n📋 Categorias:\n${renderCategories(updated)}\n\n⏱️ TEMPO: 02:00\n\n📩 As respostas devem ser\nenviadas no PV do bot.\n\n🚀 VALENDO!\n\n╰━━━━━━━━━━━━━━━━━━╯`);await sendSheets(updated);schedule(s.gameId,t+ROUND_MS);}
async function sendSheets(s){for(const p of s.participants){const text=`╭━━━ 👻 STOP ━━━╮\n🔄 RODADA ${s.currentRound}/${s.roundsTotal}\n🔤 LETRA: ${s.round.letter}\n\n${s.categoriesSnapshot.map(x=>`${x.name}:\n⬜`).join('\n\n')}\n\n⏱️ RESTAM: 02:00\n\nEnvie suas respostas no formato:\nCategoria: Resposta\nCategoria: Resposta\n\n╰━━━━━━━━━━━━━━╯`;try{await globalThis.__fantasminhaStopTransport?.sendMessage?.(p.userId,{text})}catch(e){await audit('STOP_ERROR',s,{userId:p.userId,details:{kind:'private_send',error:e.message}});}}}

export async function handleAnswer(ctx){if(!ctx.isPrivate)return {handled:false};attachTransport(ctx);const text=String(ctx.body||ctx.text||'').trim();if(!text)return {handled:false};const configFlow=await handleConfigPrivate(ctx);if(configFlow.handled)return configFlow;const del=await handleDeleteConfirm(ctx);if(del.handled)return del;const codeResult=await joinByCode(ctx);if(codeResult.handled)return codeResult;const activeSessions=game.listActiveGames().filter(gameActive);const s=activeSessions.map(sessionFromGame).find(x=>x?.participants?.some(p=>p.userId===uid(ctx))&&x.status===STOP_STATES.ROUND_ACTIVE);if(!s)return {handled:false};const answerResult=await lock(`session:${s.sessionId}`,async()=>{const g=getGameSession(s.gameId);const ss=sessionFromGame(g);if(!ss||ss.status!==STOP_STATES.ROUND_ACTIVE)return {handled:false};if(now()>ss.round.expiresAt)return {handled:true,expired:true,late:true,game:g};const parsed=parseStopAnswers(text,ss.categoriesSnapshot);if(!parsed.length)return {handled:false};const m=mid(ctx);let duplicateMessage=false;const updated=await updateBoth(ss.gameId,ss.groupId,x=>{x.processedMessageIds??=[];if(m&&x.processedMessageIds.includes(m)){duplicateMessage=true;return x;}if(m)x.processedMessageIds.push(m);const p=x.participants.find(p=>p.userId===uid(ctx));if(!p)return x;p.lastActivityAt=now();x.round.answers[uid(ctx)]??={};for(const a of parsed)x.round.answers[uid(ctx)][a.categoryKey]={...a,submittedAt:now(),updatedAt:now(),messageId:m};return x;});if(duplicateMessage)return {handled:true,duplicate:true};await persistAnswers(updated,updated.round,uid(ctx),parsed);await audit('STOP_ANSWER_SUBMITTED',updated,{userId:uid(ctx),details:{count:parsed.length}});await emit('STOP_ANSWER_SUBMITTED',{sessionId:s.sessionId,groupId:s.groupId,userId:uid(ctx),count:parsed.length});await ctx.sendMessage?.(uid(ctx),{text:`✅ Resposta(s) registrada(s)!\n\nVocê pode alterar qualquer categoria enquanto o tempo estiver aberto.`});return {handled:true,updated:true};});if(answerResult?.late){await lockRound(answerResult.game);await ctx.sendMessage?.(uid(ctx),{text:'⏰ O tempo da rodada terminou. Sua resposta não pode mais ser alterada.'});return {handled:true,expired:true};}return answerResult;}

async function lockRound(g){let locked=null;await lock(`session:${g.gameId}`,async()=>{const current=getGameSession(g.gameId);const s=sessionFromGame(current);if(!s||s.status!==STOP_STATES.ROUND_ACTIVE)return;clearTimer(g.gameId);locked=await updateBoth(g.gameId,s.groupId,x=>{x.status=STOP_STATES.ROUND_LOCKED;x.round.status=STOP_STATES.ROUND_LOCKED;x.round.lockedAt=now();return x;});await emit('GAME_ROUND_LOCKED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId,roundNumber:s.currentRound});await emit('STOP_ROUND_LOCKED',{sessionId:s.sessionId,groupId:s.groupId,roundNumber:s.currentRound});await audit('STOP_ROUND_LOCKED',locked,{details:{roundNumber:s.currentRound}});});if(locked)await validateRound(locked);return locked;}
async function validateRound(s){
  const g=getGameSession(s.gameId);
  if(!g)return;
  const updated=await updateBoth(s.gameId,s.groupId,x=>{x.status=STOP_STATES.VALIDATING;return x;});
  await emit('GAME_VALIDATION_STARTED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId,roundNumber:s.currentRound});
  const validations={};
  const answers=updated.round.answers||{};
  const aiCache=new Map();
  const jobs=[];
  const concurrency=Math.max(1,Math.min(8,Number(process.env.STOP_AI_CONCURRENCY||4)));
  const validateOne=async(job)=>{
    const {p,cat,a}=job;
    validations[p.userId]??={};
    if(!a){
      validations[p.userId][cat.key]={status:'EMPTY',valid:false,reason:'Sem resposta.',confidence:1,points:0};
      return;
    }
    const det=validateDeterministic(cat,a.answerRaw,updated.round.letter);
    if(det.valid===false){
      validations[p.userId][cat.key]={...det,points:0};
      return;
    }
    const cacheKey=`${cat.key}::${a.answerNormalized}::${updated.round.letter}`;
    let aiPromise=aiCache.get(cacheKey);
    if(!aiPromise){
      aiPromise=validateWithAI(cat,a.answerRaw,updated.round.letter);
      aiCache.set(cacheKey,aiPromise);
    }
    const ai=await aiPromise;
    const final=(ai.valid===true&&ai.letter_match!==false&&ai.category_match!==false&&Number(ai.confidence)>=Number(process.env.STOP_AI_MIN_CONFIDENCE||0.6));
    const result={...ai,status:final?'VALID':'INVALID',points:0,answerRaw:a.answerRaw,answerNormalized:a.answerNormalized};
    validations[p.userId][cat.key]=result;
    await emit('STOP_AI_VALIDATION',{sessionId:s.sessionId,groupId:s.groupId,userId:p.userId,category:cat.key,status:result.status,confidence:ai.confidence});
  };
  for(const p of updated.participants){
    const userAnswers=answers[p.userId]||{};
    validations[p.userId]={};
    for(const cat of updated.categoriesSnapshot)jobs.push({p,cat,a:userAnswers[cat.key]});
  }
  let cursor=0;
  const workers=Array.from({length:Math.min(concurrency,jobs.length)},async()=>{
    while(true){
      const i=cursor++;
      if(i>=jobs.length)return;
      await validateOne(jobs[i]);
    }
  });
  await Promise.all(workers);
scoreRound(updated.participants,validations);
const scored=await updateBoth(s.gameId,s.groupId,x=>{x.round.results=validations;for(const p of x.participants){const total=Object.values(validations[p.userId]||{}).reduce((a,v)=>a+Number(v.points||0),0);p.totalScore=(Number(p.totalScore)||0)+total;x.scores[p.userId]=(x.scores[p.userId]||0)+total;}x.status=STOP_STATES.ROUND_RESULT;x.round.status=STOP_STATES.ROUND_RESULT;return x;});await persistRoundResults(scored);await persistValidationResults(scored);await emit('GAME_SCORE_CALCULATED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId,roundNumber:s.currentRound});await emit('STOP_SCORE_CALCULATED',{sessionId:s.sessionId,groupId:s.groupId,roundNumber:s.currentRound});await audit('STOP_SCORE_CALCULATED',s,{details:{roundNumber:s.currentRound}});await sendRoundResults(getGameSession(s.gameId)?.state?.stopSession||s);}
async function sendRoundResults(s){const rows=s.participants.map(p=>{const r=s.round.results?.[p.userId]||{};const vals=Object.values(r);return {userId:p.userId,points:vals.reduce((a,v)=>a+Number(v.points||0),0),valid:vals.filter(v=>String(v.status).startsWith('VALID')).length,unique:vals.filter(v=>v.status==='VALID_UNIQUE').length,dup:vals.filter(v=>v.status==='VALID_DUPLICATE').length,invalid:vals.filter(v=>v.status==='INVALID'||v.status==='EMPTY').length};}).sort((a,b)=>b.points-a.points||b.unique-a.unique);const lines=rows.length?rows.map((x,i)=>`${['🥇','🥈','🥉'][i]||`${i+1}️⃣`} ${mention(x.userId)} — ${x.points} pontos\n   ✅ ${x.valid} válidas · ⭐ ${x.unique} únicas${x.dup?` · 🔁 ${x.dup} repetidas`:''}${x.invalid?` · ❌ ${x.invalid} inválidas/vazias`:''}`).join('\n'):'Ninguém respondeu.';await ctxSendGroup(s.groupId,`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   🏆 RODADA ${s.currentRound}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 Letra: ${s.round.letter}\n⏰ Rodada encerrada!\n\n🏆 RESULTADO\n\n${lines}\n\n━━━━━━━━━━━━━━━━━━\n\n🤖 Respostas verificadas pelo\nsistema de validação do STOP.\n\n╰━━━━━━━━━━━━━━━━━━╯`,{mentions:rows.map(x=>x.userId)});for(const p of s.participants){const r=s.round.results?.[p.userId]||{};const linesP=s.categoriesSnapshot.map(cat=>{const v=r[cat.key];if(!v||v.status==='EMPTY')return `📋 ${cat.name}\n⚪ Sem resposta\n+0 pontos`;return `${v.status==='VALID_UNIQUE'||v.status==='VALID_DUPLICATE'?'📋':'📋'} ${cat.name}\n${v.status==='VALID_UNIQUE'?'✅':v.status==='VALID_DUPLICATE'?'🟡':'❌'} ${v.answerRaw||'Sem resposta'}\n+${v.points||0} pontos${v.status==='VALID_DUPLICATE'?'\n🔁 Resposta repetida.':v.status==='INVALID'?`\n💡 ${v.reason||'Não foi considerada válida.'}`:''}`;}).join('\n\n');const total=Object.values(r).reduce((a,v)=>a+Number(v.points||0),0);try{await globalThis.__fantasminhaStopTransport?.sendMessage?.(p.userId,{text:`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   📊 RODADA ${s.currentRound}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 Letra: ${s.round.letter}\n\n${linesP}\n\n━━━━━━━━━━━━━━━━━━\n\n🏆 TOTAL DA RODADA: ${total} PONTOS\n\n╰━━━━━━━━━━━━━━━━━━╯`});}catch{}}
if(s.currentRound<s.roundsTotal){await new Promise(r=>setTimeout(r,300));const g=getGameSession(s.gameId);if(g)await startRound(sessionFromGame(g),null);}else await finishSession(s);}

function finalLines(s){return s.participants.map(p=>({userId:p.userId,score:Number(p.totalScore)||0})).sort((a,b)=>b.score-a.score).map((x,i)=>`${['🥇','🥈','🥉'][i]||`${i+1}️⃣`} ${mention(x.userId)} — ${x.score} pontos`).join('\n')||'Ninguém participou.';}
async function finishSession(s){return lock(`session:${s.gameId}`,async()=>{const g=getGameSession(s.gameId);const current=sessionFromGame(g);if(!current||[STOP_STATES.FINISHED,STOP_STATES.CANCELLED].includes(current.status))return;const fin=await updateBoth(s.gameId,s.groupId,x=>{x.status=STOP_STATES.FINISHED;x.finishedAt=now();return x;});for(const p of fin.participants){const score=Number(p.totalScore)||0;try{await stats.recordResult({groupId:fin.groupId,userId:p.userId,gameType:'STOP',result:'play',score,win:score===Math.max(...fin.participants.map(x=>Number(x.totalScore)||0)),operationId:`STOP:${fin.gameId}:${p.userId}`});}catch{}}
try { const { recordSession } = await import('./StopStatisticsService.js'); await recordSession(fin); } catch {}
await emit('STOP_SESSION_FINISHED',{sessionId:fin.sessionId,groupId:fin.groupId});await emit('GAME_FINISHED',{gameType:'STOP',sessionId:fin.sessionId,groupId:fin.groupId});await audit('STOP_SESSION_FINISHED',fin,{details:{participants:fin.participants.length}});const finishedGame=await game.finishGame(fin.gameId,fin.groupId,{status:'FINISHED',winnerId:fin.participants.sort((a,b)=>b.totalScore-a.totalScore)[0]?.userId||null,reason:'all_rounds_finished',result:{rounds:fin.roundsTotal,scores:fin.scores}});if(finishedGame){const max=Math.max(...fin.participants.map(x=>Number(x.totalScore)||0));for(const p of fin.participants){const all=fin.rounds||[];const vals=all.flatMap(r=>Object.values(r.results?.[p.userId]||{}));await emit('GAME_SCORE_FINALIZED',{eventId:`STOP:${fin.sessionId}:${p.userId}`,gameId:'stop',gameSessionId:fin.sessionId,groupId:fin.groupId,userId:p.userId,points:Number(p.totalScore)||0,won:(Number(p.totalScore)||0)===max,stats:{rounds:fin.roundsTotal,validAnswers:vals.filter(v=>String(v.status).startsWith('VALID')).length,uniqueAnswers:vals.filter(v=>v.status==='VALID_UNIQUE').length,duplicateAnswers:vals.filter(v=>v.status==='VALID_DUPLICATE').length,invalidAnswers:vals.filter(v=>v.status==='INVALID'||v.status==='EMPTY').length,totalAnswers:vals.length},groupName:fin.groupName||'Grupo',occurredAt:Date.now()});}}clearTimer(fin.gameId);await ctxSendGroup(fin.groupId,`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   🏆 RESULTADO FINAL\n╰━━━━━━━━━━━━━━━━━━╯\n\n🎉 PARTIDA FINALIZADA!\n\n${finalLines(fin)}\n\n━━━━━━━━━━━━━━━━━━\n\n🔄 Rodadas: ${fin.roundsTotal}\n📋 Categorias: ${fin.categoriesSnapshot.length}\n\nParabéns a todos! 👻\n\n╰━━━━━━━━━━━━━━━━━━╯`);});}

async function cancelSession(s,ctx,reason='CANCELLED'){return lock(`session:${s.sessionId}`,async()=>{const g=getGameSession(s.gameId);const current=sessionFromGame(g);if(!current||[STOP_STATES.FINISHED,STOP_STATES.CANCELLED].includes(current.status))return;clearTimer(s.gameId);const cancelled=await updateBoth(s.gameId,s.groupId,x=>{x.status=STOP_STATES.CANCELLED;x.cancelledAt=now();return x;});await emit('STOP_SESSION_CANCELLED',{sessionId:s.sessionId,groupId:s.groupId,userId:uid(ctx)});await emit('GAME_CANCELLED',{gameType:'STOP',sessionId:s.sessionId,groupId:s.groupId});await audit('STOP_SESSION_CANCELLED',cancelled,{userId:uid(ctx),details:{reason}});await game.finishGame(s.gameId,s.groupId,{status:'CANCELLED',reason,result:{reason}});await ctx.reply?.('🛑 STOP encerrado. A partida foi cancelada.');});}
export async function cancelForContext(ctx){if(!ctx.isGroup)return {handled:false};const g=getSessionByGroup(gid(ctx));if(!g)return {handled:false};const s=sessionFromGame(g);const allowed=s.createdBy===uid(ctx)||ctx.isGroupAdmin||ctx.isOwner||configuredOwner(uid(ctx));if(!allowed){await audit('STOP_SESSION_CANCELLED',s,{userId:uid(ctx),details:{denied:true}});await emit('STOP_ERROR',{sessionId:s.sessionId,groupId:s.groupId,userId:uid(ctx),reason:'cancel_denied'});await ctx.reply?.('🚫 Você não possui permissão para cancelar este STOP.');return {handled:true,denied:true};}await cancelSession(s,ctx);return {handled:true,cancelled:true};}
export async function handleGroupInput(ctx){if(!ctx.isGroup)return {handled:false};attachTransport(ctx);const text=n(ctx.body||ctx.text||'');if(!text)return {handled:false};const g=getSessionByGroup(gid(ctx));if(!g)return {handled:false};const s=sessionFromGame(g);if((s.status===STOP_STATES.WAITING_CREATOR_START)&&(text==='1'||text==='2')){if(uid(ctx)!==s.createdBy)return {handled:false};return text==='1'?startFromCreator(ctx,s):cancelCreatorStart(ctx,s);}if(text==='cancelar stop'||text==='cancelarstop')return cancelForContext(ctx);return {handled:false};}
export async function recover(){const games=game.listActiveGames().filter(gameActive);for(const g of games){const s=sessionFromGame(g);if(!s)continue;await persistSession(s);if(s.status===STOP_STATES.LOBBY_OPEN){if(now()>=s.lobbyExpiresAt)await closeLobby(g);else schedule(g.gameId,s.lobbyExpiresAt);}else if(s.status===STOP_STATES.ROUND_ACTIVE){if(now()>=s.round?.expiresAt)await lockRound(g);else schedule(g.gameId,s.round.expiresAt);}else if(s.status===STOP_STATES.ROUND_LOCKED||s.status===STOP_STATES.VALIDATING)await validateRound(s);else if(s.status===STOP_STATES.ROUND_RESULT&&s.currentRound>=s.roundsTotal)await finishSession(s);await emit('STOP_RECOVERY',{sessionId:s.sessionId,groupId:s.groupId,status:s.status});}return games.length;}
export function stopOrphanCleanup(){return 0;}
export const normalize=n; export const helpers={normalizeCategories,validRounds};
export default {beginConfig,beginDelete,createSession,handleConfigPrivate,handleAnswer,handleGroupInput,cancelForContext,recover,attachTransport,getConfig,isStopPrivateInputAllowed,getSessionByGroup,getSessionByCode};
