import logger from './logger.js';
import config from './config.js';
import { installAntiCrash } from './antiCrash.js';
import { runMigrations } from '../database/migrate.js';
import { registerSystemCommands } from '../commands/system.js';
import { registryStats } from './registry.js';
import { validateRegistry } from './registry.js';
import { startSchedulers } from '../services/scheduler.js';
import { bootstrapPlatform } from '../platform/index.js';
import { installLifecycleHandlers } from './lifecycle.js';
import { emit, Events } from '../events/index.js';
import * as alemPlugin from '../plugins/alem/index.js';
import * as jogosPlugin from '../plugins/jogos/index.js';
import * as economiaPlugin from '../plugins/economia/index.js';
import * as adminPlugin from '../plugins/admin/index.js';
import * as premiumPlugin from '../plugins/premium/index.js';
import * as rpgPlugin from '../plugins/rpg/index.js';
import * as clansPlugin from '../plugins/clans/index.js';
import * as downloadsPlugin from '../plugins/downloads/index.js';
import * as triagemPlugin from '../plugins/triagem/index.js';
import * as ownerPowerPlugin from '../plugins/ownerPower/index.js';
import * as aranhaPlugin from '../plugins/aranha/index.js';
import * as expansionPlugin from '../plugins/expansion/index.js';
import * as platformPlugin from '../plugins/platform/index.js';
import * as communityPlugin from '../plugins/community/index.js';
import * as socialPlugin from '../plugins/social/index.js';
import * as mega701Plugin from '../plugins/mega701/index.js';
import * as worldEnginePlugin from '../plugins/worldEngine/index.js';
import * as championshipPlugin from '../plugins/championship/index.js';
import * as fusionCorePlugin from '../plugins/fusionCore/index.js';
import * as innovationPlugin from '../plugins/innovation/index.js';
import * as takeshiCompatPlugin from '../plugins/takeshiCompat/index.js';
import * as megaFusionPlugin from '../plugins/megaFusion/index.js';
import * as completeExpansionPlugin from '../plugins/completeExpansion/index.js';
import * as reactionManagerPlugin from '../plugins/reactionManager/index.js';
import * as responseMediaPlugin from '../plugins/responseMedia/index.js';
import * as reactionEnginePlugin from '../plugins/reactionEngine/index.js';
import * as quizPlugin from '../plugins/quiz/index.js';
import * as forcaPlugin from '../plugins/forca/index.js';
import * as stopPlugin from '../plugins/stop/index.js';
import * as garticPlugin from '../plugins/gartic/index.js';
import * as rankingPlugin from '../plugins/ranking/index.js';
import * as legacyMigrationBatch1Plugin from '../plugins/legacyMigrationBatch1/index.js';
import * as legacyRegistryPlugin from '../plugins/legacyRegistry/index.js';

let bootstrapped = false;
let bootPromise = null;

export async function bootstrapV2() {
  if (bootstrapped) return registryStats();
  if (bootPromise) return bootPromise;
  bootPromise = (async () => {
    installAntiCrash();
    installLifecycleHandlers();
    logger.info('bootstrap', `Fantasminha ${config.botVersion}`);
    const validation = config.validate();
    if (!validation.ok) logger.warn('bootstrap', 'configuração incompleta', { missing: validation.missing });
    const ver = runMigrations();
    logger.db('bootstrap', `migrations v${ver}`);

    await bootstrapPlatform();
    registerSystemCommands();
    await fusionCorePlugin.register();
    if (config.features.alem) await alemPlugin.register();
    if (config.features.games) await jogosPlugin.register();
    if (config.features.economy) await economiaPlugin.register();
    await adminPlugin.register();
    await premiumPlugin.register();
    if (config.features.rpg) await rpgPlugin.register();
    if (config.features.clans) await clansPlugin.register();
    if (config.features.downloads) await downloadsPlugin.register();
    await triagemPlugin.register();
    await communityPlugin.register();
    await socialPlugin.register();
    await ownerPowerPlugin.register();
    await aranhaPlugin.register();
    await expansionPlugin.register();
    await platformPlugin.register();
    await mega701Plugin.register();
    await worldEnginePlugin.register();
    await championshipPlugin.register();
    await innovationPlugin.register();
    await takeshiCompatPlugin.register();
    await megaFusionPlugin.register();
    await completeExpansionPlugin.register();
    await reactionManagerPlugin.register();
    await responseMediaPlugin.register();
    await reactionEnginePlugin.register();
    await quizPlugin.register();
    await forcaPlugin.register();
    await stopPlugin.register();
    await garticPlugin.register();
    await rankingPlugin.register();
    await legacyMigrationBatch1Plugin.register();
    await legacyRegistryPlugin.register();
    try { await (await import('../games/quiz/QuizService.js')).recover(); } catch (e) { logger.warn('quiz', `recovery: ${e.message}`); }
    try { await (await import('../games/forca/ForcaService.js')).recover(); } catch (e) { logger.warn('forca', `recovery: ${e.message}`); }
    try { await (await import('../games/stop/StopCore.js')).recover(); } catch (e) { logger.warn('stop', `recovery: ${e.message}`); }
    try { await (await import('../games/gartic/GarticService.js')).recover(); } catch (e) { logger.warn('gartic', `recovery: ${e.message}`); }

    const registryValidation = validateRegistry();
    if (!registryValidation.ok) throw new Error(`Registry inválido: ${registryValidation.errors.join('; ')}`);
    startSchedulers();
    bootstrapped = true;
    const stats = registryStats();
    logger.info('bootstrap', 'registry pronto', stats);
    await emit(Events.READY, { version: config.botVersion, stats });
    return stats;
  })();
  try { return await bootPromise; } finally { bootPromise = null; }
}

export function isBootstrapped() { return bootstrapped; }
export default bootstrapV2;
