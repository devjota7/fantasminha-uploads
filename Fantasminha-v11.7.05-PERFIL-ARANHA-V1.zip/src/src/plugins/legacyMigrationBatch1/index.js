import fs from 'fs';
import path from 'path';
import os from 'os';
import axios from 'axios';
import { downloadContentFromMessage } from 'baileys';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import config from '../../core/config.js';
import { sendSticker } from '../../../dados/src/funcs/utils/sticker.js';

const GROUPS_DIR = path.join(config.root, 'dados', 'database', 'grupos');
const PREMIUM_FILE = path.join(config.root, 'dados', 'database', 'dono', 'premium.json');
const GLOBAL_BLOCKS_FILE = path.join(config.root, 'dados', 'database', 'globalBlocks.json');
const BOT_STATE_FILE = path.join(config.root, 'dados', 'database', 'botState.json');

function tag(text) { return `× 👻 FANTASMINHA\n\n${text}`; }
function readJson(file, fallback) {
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; }
  catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2));
}
function groupFile(jid) { return path.join(GROUPS_DIR, `${jid}.json`); }
function readGroup(jid) { return readJson(groupFile(jid), {}); }
function userLabel(jid) { return String(jid || '').split('@')[0]; }
function isUserId(id) { return String(id || '').includes('@s.whatsapp.net') || String(id || '').includes('@lid'); }

async function downloadMedia(message, type) {
  const stream = await downloadContentFromMessage(message, type);
  const chunks = [];
  let total = 0;
  for await (const chunk of stream) {
    total += chunk.length;
    if (total > 50 * 1024 * 1024) throw new Error('Mídia excede o limite de 50 MB.');
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function quotedOrCurrentMedia(ctx) {
  const root = ctx.message?.message || {};
  const quoted = root.extendedTextMessage?.contextInfo?.quotedMessage ||
    root.viewOnceMessage?.message?.extendedTextMessage?.contextInfo?.quotedMessage || {};
  const image = quoted.imageMessage || root.imageMessage || quoted.viewOnceMessageV2?.message?.imageMessage || root.viewOnceMessageV2?.message?.imageMessage || quoted.viewOnceMessage?.message?.imageMessage || root.viewOnceMessage?.message?.imageMessage;
  const video = quoted.videoMessage || root.videoMessage || quoted.viewOnceMessageV2?.message?.videoMessage || root.viewOnceMessageV2?.message?.videoMessage || quoted.viewOnceMessage?.message?.videoMessage || root.viewOnceMessage?.message?.videoMessage;
  return { image, video };
}

async function register() {
  registerCommand({
    name: 'zipbot',
    aliases: ['zip-bot', 'botzip', 'bot-zip', 'downloadbot', 'download-bot'],
    category: 'downloads', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 10,
    description: 'Baixa o código-fonte atual do Fantasminha em ZIP.',
    handler: async (ctx) => {
      try {
        await ctx.reply('📦 Baixando o código-fonte do bot... Aguarde!');
        let githubUrl = config.github_ofc;
        if (!githubUrl) throw new Error('Repositório oficial não configurado.');
        if (githubUrl.endsWith('.git')) githubUrl = githubUrl.replace(/\.git$/, '');
        if (!githubUrl.includes('/archive/refs/heads/')) githubUrl += '/archive/refs/heads/main.zip';
        const response = await axios.get(githubUrl, { responseType: 'arraybuffer', timeout: 60000, headers: { 'User-Agent': 'Fantasminha-Bot' } });
        const zipBuffer = Buffer.from(response.data);
        if (zipBuffer.length < 1000) throw new Error('Arquivo ZIP inválido ou vazio.');
        await ctx.sendMessage(ctx.from, {
          document: zipBuffer, fileName: 'fantasminha-bot.zip', mimetype: 'application/zip',
          caption: `📦 *Código-fonte do ${config.botName || 'Fantasminha'}*\n\n📖 Repositório: ${config.github_ofc}\n\n⚠️ Siga o README.md para instalação.`
        });
      } catch (e) {
        const status = e.response?.status;
        const msg = status === 404 ? '❌ Repositório não encontrado.' : (e.code === 'ECONNABORTED' || e.code === 'ETIMEDOUT') ? '❌ Tempo de conexão esgotado. Tente novamente.' : '❌ Erro ao baixar o arquivo.';
        await ctx.reply(`${msg}\n\nAcesse: ${config.github_ofc || 'repositório não configurado'}`);
      }
    }
  });

  registerCommand({
    name: 'gitbot',
    aliases: ['git-bot', 'github', 'git-hub', 'repo', 'repositorio', 'source', 'sourcecode', 'source-code'],
    category: 'ferramentas', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 10,
    description: 'Mostra informações e estatísticas do repositório oficial.',
    handler: async (ctx) => {
      try {
        await ctx.reply('🔍 Buscando informações do repositório...');
        const owner = config.autor;
        const repoName = config.repositorio;
        if (!owner || !repoName) throw new Error('Repositório não configurado.');
        const headers = { Accept: 'application/vnd.github+json' };
        const [repoResponse, commitsResponse] = await Promise.all([
          axios.get(`https://api.github.com/repos/${owner}/${repoName}`, { headers, timeout: 20000 }),
          axios.get(`https://api.github.com/repos/${owner}/${repoName}/commits?per_page=1`, { headers, timeout: 20000 })
        ]);
        const repo = repoResponse.data;
        let totalCommits = commitsResponse.data.length;
        const link = commitsResponse.headers.link || '';
        const last = link.match(/page=(\d+)>;\s*rel="last"/);
        if (last) totalCommits = Number(last[1]);
        const createdDate = new Date(repo.created_at);
        const diff = Math.max(0, Date.now() - createdDate.getTime());
        const dias = Math.floor(diff / 86400000);
        const horas = Math.floor((diff % 86400000) / 3600000);
        const minutos = Math.floor((diff % 3600000) / 60000);
        const segundos = Math.floor((diff % 60000) / 1000);
        const text = `╭━━━⊱ 🐙 *GITHUB INFO* ⊱━━━╮\n│\n│ 📦 *Repositório:* ${repo.name}\n│ 📝 *Descrição:* ${repo.description || 'Sem descrição'}\n│\n│ 👨‍💻 *Atualizado Por:* ${repo.owner?.login || owner}\n│ 🔗 *Perfil:* https://github.com/${repo.owner?.login || owner}\n│\n│ ⭐ *Stars:* ${repo.stargazers_count}\n│ 🍴 *Forks:* ${repo.forks_count}\n│ 👀 *Watchers:* ${repo.subscribers_count}\n│ 🐛 *Issues:* ${repo.open_issues_count}\n│ 📊 *Commits:* ${totalCommits}\n│\n│ 💻 *Linguagem:* ${repo.language || 'N/A'}\n│ 📜 *Licença:* ${repo.license?.name || 'Sem licença'}\n│\n│ 📅 *Criado em:* ${createdDate.toLocaleDateString('pt-BR')}\n│ 🔄 *Atualizado:* ${new Date(repo.updated_at).toLocaleDateString('pt-BR')}\n│ 📤 *Último push:* ${repo.pushed_at ? new Date(repo.pushed_at).toLocaleDateString('pt-BR') : 'N/A'}\n│\n│ ⏱️ *Fantasminha vem sendo ativamente mantida há:* ${dias} dias, ${horas} horas, ${minutos} minutos e ${segundos} segundos\n│\n│ 🔗 *Repo:* ${repo.html_url}\n│ • Clone: ${repo.clone_url}\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯`;
        await ctx.reply(text);
      } catch (e) {
        await ctx.reply(`❌ Erro ao buscar informações. Acesse diretamente:\n🔗 ${config.github_ofc || 'repositório não configurado'}`);
      }
    }
  });

  registerCommand({
    name: 'meustatus', category: 'social', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 5,
    description: 'Mostra suas estatísticas no grupo e no conjunto de grupos.',
    handler: async (ctx) => {
      try {
        let groupMessages = 0, groupCommands = 0, groupStickers = 0;
        if (ctx.isGroup) {
          const gd = readGroup(ctx.from);
          const u = (gd.contador || []).find(x => x?.id === ctx.sender);
          groupMessages = u?.msg || 0; groupCommands = u?.cmd || 0; groupStickers = u?.figu || 0;
        }
        let totalMessages = 0, totalCommands = 0, totalStickers = 0;
        if (fs.existsSync(GROUPS_DIR)) {
          for (const file of fs.readdirSync(GROUPS_DIR).filter(x => x.endsWith('.json'))) {
            const gd = readJson(path.join(GROUPS_DIR, file), {});
            const u = (gd.contador || []).find(x => x?.id === ctx.sender);
            if (u) { totalMessages += u.msg || 0; totalCommands += u.cmd || 0; totalStickers += u.figu || 0; }
          }
        }
        const name = ctx.pushname || userLabel(ctx.sender);
        const status = ctx.isOwner ? 'Dono' : ctx.isPremium ? 'Premium' : ctx.isGroupAdmin ? 'Admin' : 'Membro';
        const text = `📊 *Meu Status - ${name}* 📊\n\n👤 *Nome*: ${name}\n📱 *Número*: @${userLabel(ctx.sender)}\n⭐ *Status*: ${status}\n${ctx.isGroup ? `\n📌 *No Grupo: ${ctx.groupName || ctx.from}*\n💬 Mensagens: ${groupMessages}\n⚒️ Comandos: ${groupCommands}\n🎨 Figurinhas: ${groupStickers}\n` : ''}\n🌐 *Geral (Todos os Grupos)*\n💬 Mensagens: ${totalMessages}\n⚒️ Comandos: ${totalCommands}\n🎨 Figurinhas: ${totalStickers}\n\n✨ *Bot*: ${config.botName || 'Fantasminha'} by ${config.ownerName || ''} ✨`;
        const pic = await ctx.profilePictureUrl?.(ctx.sender);
        if (pic) await ctx.sendMessage(ctx.from, { image: { url: pic }, caption: text, mentions: [ctx.sender] });
        else await ctx.sendMessage(ctx.from, { text, mentions: [ctx.sender] });
      } catch { await ctx.reply('❌ Ocorreu um erro interno ao mostrar seu status.'); }
    }
  });

  registerCommand({
    name: 'statusbot', aliases: ['infobot', 'botinfo'], category: 'sistema', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 10,
    description: 'Mostra o estado, recursos e estatísticas atuais do bot.',
    handler: async (ctx) => {
      try {
        const uptime = `${Math.floor(process.uptime() / 86400)}d ${Math.floor(process.uptime() / 3600) % 24}h ${Math.floor(process.uptime() / 60) % 60}m`;
        const mem = process.memoryUsage();
        const allGroupsRaw = ctx.sock?.groupFetchAllParticipating ? await ctx.sock.groupFetchAllParticipating() : {};
        const allGroups = Object.values(allGroupsRaw || {});
        const totalUsers = allGroups.reduce((n, g) => n + (g?.participants?.length || 0), 0);
        const premium = readJson(PREMIUM_FILE, {});
        const blocks = readJson(GLOBAL_BLOCKS_FILE, { users: {}, commands: {} });
        const state = readJson(BOT_STATE_FILE, { status: 'on' });
        const premiumUsers = Object.keys(premium).filter(isUserId).length;
        const premiumGroups = Object.keys(premium).filter(x => x.endsWith('@g.us')).length;
        const text = `╭───🤖 STATUS DO BOT ───╮\n┊ 🏷️ Nome: ${config.botName || 'Fantasminha'}\n┊ 👨‍💻 Dono: ${config.nomedono || '—'}\n┊ 🆚 Versão: ${config.botVersion || '11.7.05'}\n┊ 🟢 Status: ${state.status === 'on' ? '✅ Online' : '❌ Offline'}\n┊ ⏰ Online há: ${uptime}\n┊ 🖥️ Plataforma: ${os.platform()}\n┊ 🟢 Node.js: ${process.version}\n┊\n┊ 📊 *Estatísticas:*\n┊ • 👥 Grupos: ${allGroups.length}\n┊ • 👤 Usuários: ${totalUsers}\n┊ • 💎 Users Premium: ${premiumUsers}\n┊ • 💎 Grupos Premium: ${premiumGroups}\n┊\n┊ 🛡️ *Segurança:*\n┊ • 🚫 Users Bloqueados: ${Object.keys(blocks.users || {}).length}\n┊ • 🚫 Cmds Bloqueados: ${Object.keys(blocks.commands || {}).length}\n┊\n┊ 💾 *Sistema:*\n┊ • 🧠 RAM Usada: ${(mem.heapUsed / 1048576).toFixed(2)}MB\n┊ • 📦 RAM Total: ${(mem.heapTotal / 1048576).toFixed(2)}MB\n┊ • 🕐 Hora Atual: ${new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' })}\n╰───────────────╯`;
        await ctx.reply(text);
      } catch { await ctx.reply('❌ Ocorreu um erro ao consultar o status do bot.'); }
    }
  });

  registerCommand({
    name: 'sticker', aliases: ['s', 'st', 'stk'], category: 'figurinhas', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 3,
    description: 'Converte uma imagem ou vídeo curto em figurinha.',
    handler: async (ctx) => {
      try {
        const { image, video } = quotedOrCurrentMedia(ctx);
        if (!image && !video) throw new Error(`Marque uma imagem ou um vídeo de até 9.9 segundos para fazer figurinha.`);
        if (video?.seconds > 9.9) throw new Error('O vídeo precisa ter no máximo 9.9 segundos para ser convertido em figurinha.');
        const type = video ? 'video' : 'image';
        const buffer = await downloadMedia(video || image, type);
        await sendSticker(ctx.sock || ctx.socket, ctx.from, { sticker: buffer, author: ctx.pushname || '', packname: config.botName || 'Fantasminha', type, forceSquare: true }, { quoted: ctx.message });
      } catch (e) { await ctx.reply(e.message || '❌ Ocorreu um erro ao criar a figurinha.'); }
    }
  });

  registerCommand({
    name: 'mention', category: 'ferramentas', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 3, groupOnly: true,
    description: 'Define quando o bot deve incluir você em marcações.',
    handler: async (ctx) => {
      const option = String(ctx.q || '').trim().toLowerCase();
      if (!option) return ctx.reply(`📢 *Configuração de Marcações*\n\nUse: ${ctx.prefix}mention all | marca | games | 0`);
      const options = {
        all: '✨ Você agora será mencionado em todas as interações do bot, incluindo marcações de administradores e os jogos!',
        marca: '📢 A partir de agora, você será mencionado apenas quando um administrador marcar.',
        games: '🎮 Você optou por ser mencionado somente em jogos do bot.',
        '0': '🔕 Silêncio ativado! Você não será mais mencionado pelo bot, nem em marcações nem em jogos.'
      };
      if (!(option in options)) return ctx.reply(`❌ Opção inválida! Use ${ctx.prefix}mention para ver as opções.`);
      const gd = readGroup(ctx.from);
      gd.mark = gd.mark || {};
      gd.mark[ctx.sender] = option;
      writeJson(groupFile(ctx.from), gd);
      await ctx.reply(`*${options[option]}*`);
    }
  });

  registerCommand({
    name: 'voltei', category: 'social', plugin: 'legacy-migration-batch1', permission: Role.USER, cooldown: 3, groupOnly: true,
    description: 'Remove seu status AFK do grupo atual.',
    handler: async (ctx) => {
      const file = groupFile(ctx.from);
      const gd = readJson(file, {});
      if (gd.afkUsers?.[ctx.sender]) {
        delete gd.afkUsers[ctx.sender];
        writeJson(file, gd);
        return ctx.reply('👋 Bem-vindo(a) de volta! Seu status AFK foi removido.');
      }
      await ctx.reply('Você não estava AFK.');
    }
  });

  return true;
}

export { register };
export default { register };
