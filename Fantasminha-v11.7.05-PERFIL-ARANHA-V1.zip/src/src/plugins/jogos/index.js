/**
 * Plugin: Jogos do Submundo (com placar)
 */
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import path from 'path';
import { fileURLToPath } from 'url';
import config from '../../core/config.js';
import gameSessions from '../../services/gameSessionManager.js';
import { cancelForContext as cancelMemoryCups } from '../../games/memory-cups/MemoryCupsService.js';
import torreLimbo from '../../games/torre-limbo/index.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../../..');

let extra = null;
async function getExtra() {
  if (extra) return extra;
  try {
    extra = await import(path.join(ROOT, 'dados/src/funcs/utils/fantasminhaExtra.js'));
  } catch {
    extra = {};
  }
  return extra;
}

function dbDir() {
  return path.join(ROOT, 'dados', 'src', 'database');
}

async function replyText(ctx, text) {
  if (text) await ctx.reply(`× 👻 FANTASMINHA\n\n${text}`);
}

export async function register() {
  if (!config.features.games) return;
  const fx = await getExtra();
  const base = () => dbDir();

  registerCommand({
    name: 'forcaalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    description: 'Forca do além legada',
    handler: async (ctx) => {
      await replyText(ctx, fx.startForca?.(base(), ctx.from, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'letraalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    description: 'Chutar letra na Forca do Além legada',
    handler: async (ctx) => {
      await replyText(ctx, fx.playForca?.(base(), ctx.from, ctx.q || ctx.args?.[0], ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'quizalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    description: 'Quiz do além',
    handler: async (ctx) => {
      await replyText(ctx, fx.startQuiz?.(base(), ctx.from));
    }
  });

  registerCommand({
    name: 'respostaquiz',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      await replyText(ctx, fx.answerQuiz?.(base(), ctx.from, ctx.q, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'roletaalem',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 5,
    handler: async (ctx) => {
      await replyText(ctx, fx.roletaAlem?.(base(), ctx.from, ctx.sender, ctx.pushname));
    }
  });



  registerCommand({
    name: 'batalhaalmas',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 5,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (target) {
        await replyText(ctx, fx.batalhaDesafiar?.(base(), ctx.from, ctx.sender, ctx.pushname, target, ctx.mentionName));
      } else {
        await replyText(ctx, fx.batalhaAlmas?.(ctx.args?.[0], ctx.args?.[1] || ctx.pushname));
      }
    }
  });





  registerCommand({
    name: 'torrelimbo',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 4,
    priority: 50,
    groupOnly: true,
    description: 'Torre do Limbo procedural com desafios, riscos, recompensas, eventos Fantasma e tensão dinâmica.',
    handler: async (ctx) => {
      await torreLimbo.start(ctx);
    }
  });

  registerCommand({
    name: 'memoriafantasma',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      await replyText(ctx, fx.startMemoria?.(base(), ctx.from) || fx.memoriaFantasma?.());
    }
  });

  registerCommand({
    name: 'respostamemoria',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      await replyText(ctx, fx.answerMemoria?.(base(), ctx.from, ctx.q, ctx.sender, ctx.pushname));
    }
  });

  registerCommand({
    name: 'juizfinal',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 2,
    handler: async (ctx) => {
      const opt = (ctx.q || '').toLowerCase();
      if (['culpado', 'inocente', 'limbo'].includes(opt)) {
        await replyText(ctx, fx.juizVotar?.(base(), ctx.from, opt, ctx.sender, ctx.pushname));
      } else {
        await replyText(ctx, fx.juizStart?.(base(), ctx.from, ctx.mentionName || ctx.q || 'réu'));
      }
    }
  });



  const mg = await import('../../services/minigames.js');

  registerCommand({
    name: 'wordle',
    aliases: ['termo'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      if (!ctx.q) {
        const s = await mg.wordleStart(ctx.from);
        await replyText(ctx, `🟩 *Wordle do Além*\nPalavra com *${s.len}* letras. ${s.max} tentativas.\n×wordle <chute>`);
        return;
      }
      const r = await mg.wordleGuess(ctx.from, ctx.q, ctx.sender, ctx.pushname);
      let t = `${r.pattern}\nTentativa ${r.tries}/${r.max}`;
      if (r.win) t += `\n🏆 Acertou! +150 GC`;
      if (r.lose) t += `\n💀 Era *${r.word}*`;
      await replyText(ctx, t);
    }
  });

  registerCommand({
    name: 'quiz',
    aliases: ['quizjogo'], category: 'jogos', plugin: 'jogos', cooldown: 2,
    description: 'Quiz rápido com respostas numeradas.',
    handler: async (ctx) => {
      const q=await mg.quizStart(ctx.from);
      const scope=ctx.from||'private';
      gameSessions.startTimer(scope,'quiz',30000,async()=>{
        try {
          const r=await mg.quizAnswer(scope,'__TIMEOUT__',ctx.sender,ctx.pushname);
          await replyText(ctx, `🪦 *TEMPO ESGOTADO!*\n\n🔮 A resposta era: *${r.display}*\n\n🏆 Nenhum ponto nesta rodada.\n👻 O Véu fechou. Use *×quiz* para outra rodada.`);
        } catch {}
        gameSessions.end(scope,'quiz');
      });
      await replyText(ctx, `🧠✨ *QUIZ DO ALÉM*\n\n❓ ${q.question}\n\n${q.options.map((x,i)=>`${i+1}️⃣ ${x}`).join('\n')}\n\n⏱️ *30 segundos*\n💬 Responda apenas com *1, 2, 3 ou 4*.\n🚪 *×sairjogo* para sair.`);
    }
  });

  registerCommand({
    name: 'sairjogo',
    aliases: ['sairjogos','cancelarjogo','quitgame','jogosair'],
    category: 'jogos', plugin: 'jogos', cooldown: 1,
    description: 'Sai do jogo ativo sem encerrar os jogos dos demais.',
    handler: async (ctx) => {
      const memoryCancelled = await cancelMemoryCups(ctx);
      if (memoryCancelled.cancelled) {
        await replyText(ctx, '🚪✨ *JOGO ENCERRADO!*\n\nVocê saiu da partida de *Memória dos Copos*.\nNenhuma animação continuará. 👻');
        return;
      }
      const r = await mg.quitGame(ctx.from, ctx.sender);
      // Estados legados em memória também são limpos para evitar respostas presas.
      for (const k of ['quizGames','wordleGames','anagramaGames']) {
        try { if (global[k]?.[ctx.isGroup ? ctx.from : ctx.sender]) delete global[k][ctx.isGroup ? ctx.from : ctx.sender]; } catch {}
      }
      await replyText(ctx, r.length ? `🚪✨ *SAÍDA CONCLUÍDA!*\n\nVocê saiu de: *${r.join(', ')}*.\nPode voltar quando quiser. 👻` : '🚪 Você não possui um jogo ativo para sair.');
    }
  });

  registerCommand({
    name: 'bj',
    aliases: ['blackjack'],
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 3,
    handler: async (ctx) => {
      const r = await mg.bjStart(ctx.sender, ctx.q, ctx.pushname);
      await replyText(ctx, `🃏 *Blackjack*\nVocê: ${r.player} (${r.pVal})\nDealer: ${r.dealerShow} ?\n×bjhit · ×bjstand`);
    }
  });

  registerCommand({
    name: 'bjhit',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      const r = await mg.bjHit(ctx.sender);
      let t = `🃏 ${r.player} (${r.val})`;
      if (r.bust) t += `\n💥 Bust! Perdeu ${r.bet} GC`;
      await replyText(ctx, t);
    }
  });

  registerCommand({
    name: 'bjstand',
    category: 'jogos',
    plugin: 'jogos',
    cooldown: 1,
    handler: async (ctx) => {
      const r = await mg.bjStand(ctx.sender);
      await replyText(ctx, `🃏 Você ${r.player} (${r.pv}) vs Dealer ${r.dealer} (${r.dv})\n${r.win ? '🏆 +'+r.win+' GC' : '💀 Perdeu '+r.bet+' GC'}`);
    }
  });

}

export default { register };
