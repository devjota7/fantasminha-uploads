/**
 * 🕷️ PERFIL ARANHA
 * Camada visual exclusiva sobre o perfil oficial do Fantasminha.
 * Não duplica identidade: dados básicos vêm de buildPublicProfile().
 */
import crypto from 'node:crypto';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection } from '../../database/store.js';
import { buildPublicProfile } from '../../services/profile.js';
import config from '../../core/config.js';

const PLUGIN = 'aranha';
const TAG = '× 👻 FANTASMINHA';
const DEFAULT = { byUser: {} };
const norm = v => String(v || '').trim().toLowerCase();
const baseId = v => norm(v).split('@')[0].split(':')[0];
const sameId = (a, b) => norm(a) === norm(b) || baseId(a) === baseId(b);
const esc = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const num = v => Number.isFinite(Number(v)) ? Number(v) : 0;
const fmt = v => num(v).toLocaleString('pt-BR');
const clamp = (v,a,b) => Math.max(a, Math.min(b, num(v)));

function target(ctx) {
  return ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || ctx.sender;
}

function isOwner(ctx) { return !!ctx.isOwner; }

function readSpider(userId) {
  const d = readCollection('spider_profile', DEFAULT);
  return d.byUser?.[userId] || null;
}

async function upsertSpider(userId, patch = {}) {
  let out;
  await updateCollection('spider_profile', d => {
    d.byUser ||= {};
    const prev = d.byUser[userId] || {
      userId,
      enabled: false,
      spiderLevel: 1,
      spiderXp: 0,
      title: 'Aranha',
      badges: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    out = d.byUser[userId] = { ...prev, ...patch, userId, updatedAt: Date.now() };
    return d;
  }, DEFAULT);
  return out;
}

async function audit(ctx, action, details = {}) {
  await updateCollection('audit', d => {
    d.events ||= [];
    d.events.push({ id:`AUD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`, at:Date.now(), action, actor:ctx.sender, group:ctx.from || null, details });
    if (d.events.length > 10000) d.events.splice(0, d.events.length - 10000);
    return d;
  }, { events:[] });
}

function allowed(ctx, userId) {
  if (isOwner(ctx)) return true;
  const s = readSpider(userId);
  return !!s?.enabled && sameId(s.userId, ctx.sender) && sameId(userId, ctx.sender);
}

function gameStats(groupId, userId) {
  const d = readCollection('stats_engine', { players:{} });
  const direct = d.players?.[`${groupId || 'global'}::${userId}`];
  if (direct) return direct;
  const found = Object.values(d.players || {}).find(x => x.groupId === (groupId || 'global') && sameId(x.userId, userId));
  return found || { plays:0, wins:0, losses:0, draws:0, xp:0, score:0, streak:0, bestStreak:0 };
}

function webSvg(p, spider, stats) {
  const W = 1080, H = 1350;
  const name = esc(p.name || 'Não informado');
  const nick = esc(p.nick || 'Não cadastrado');
  const birthday = esc(p.birthday || 'Não cadastrado');
  const role = esc(p.role || 'Membro');
  const trail = esc(p.number || 'Não informado');
  const messages = fmt(p.messages);
  const botUses = fmt(p.botUses);
  const plays = fmt(stats.plays);
  const wins = fmt(stats.wins);
  const score = fmt(stats.score);
  const level = Math.max(1, Math.floor(num(spider.spiderLevel) || 1));
  const xp = Math.max(0, num(spider.spiderXp));
  const xpNext = level * 1000;
  const xpPct = clamp((xp / Math.max(1, xpNext)) * 100, 0, 100);
  const title = esc(spider.title || 'Aranha');
  const badge = esc((spider.badges || []).length ? `${spider.badges.length} distintivo(s)` : 'Sem distintivos');
  const rings = Math.min(10, 4 + Math.floor(level / 5));
  const spokes = 12;
  const cx = 540, cy = 555;
  const web = [];
  for (let r=1; r<=rings; r++) {
    const rr = 105 + r*48;
    const pts = [];
    for (let i=0;i<spokes;i++) {
      const a = (Math.PI*2*i/spokes) - Math.PI/2;
      pts.push(`${(cx+Math.cos(a)*rr).toFixed(1)},${(cy+Math.sin(a)*rr).toFixed(1)}`);
    }
    web.push(`<polygon points="${pts.join(' ')}" fill="none" stroke="#aeb6c1" stroke-opacity="${0.18 + r*0.025}" stroke-width="2"/>`);
  }
  for (let i=0;i<spokes;i++) {
    const a = (Math.PI*2*i/spokes) - Math.PI/2;
    web.push(`<line x1="${cx}" y1="${cy}" x2="${cx+Math.cos(a)*600}" y2="${cy+Math.sin(a)*600}" stroke="#e6e9ed" stroke-opacity="0.25" stroke-width="2"/>`);
  }
  const nodeDots = Array.from({length:spokes},(_,i)=>{
    const a=(Math.PI*2*i/spokes)-Math.PI/2, x=cx+Math.cos(a)*585, y=cy+Math.sin(a)*585;
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" fill="#e32632"/>`;
  }).join('');
  const spiderGraphic = `
    <g transform="translate(${cx} ${cy})">
      <ellipse cx="0" cy="18" rx="92" ry="116" fill="#12151a" stroke="#e32632" stroke-width="6"/>
      <circle cx="0" cy="-82" r="62" fill="#12151a" stroke="#e32632" stroke-width="6"/>
      <path d="M-32 -88 L-8 -104 L-20 -54 Z M32 -88 L8 -104 L20 -54 Z" fill="#f2f4f6" stroke="#e32632" stroke-width="3"/>
      <path d="M-80 -35 L-180 -110 M-92 -5 L-205 -25 M-86 35 L-185 85 M80 -35 L180 -110 M92 -5 L205 -25 M86 35 L185 85" stroke="#e32632" stroke-width="9" stroke-linecap="round"/>
      <path d="M-40 28 Q0 70 40 28 M-52 50 Q0 92 52 50" fill="none" stroke="#e32632" stroke-width="4" opacity=".8"/>
    </g>`;
  const panel = (x,y,w,h,title,rows) => `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="24" fill="#090b0f" fill-opacity="0.92" stroke="#d8dde3" stroke-opacity="0.22" stroke-width="2"/><text x="${x+26}" y="${y+38}" fill="#e32632" font-family="Arial" font-size="23" font-weight="700">${esc(title)}</text>${rows.map((r,i)=>`<text x="${x+26}" y="${y+78+i*42}" fill="#f2f4f6" font-family="Arial" font-size="22"><tspan fill="#aeb6c1">${esc(r[0])}</tspan><tspan dx="10" font-weight="700">${esc(r[1])}</tspan></text>`).join('')}</g>`;
  return `<?xml version="1.0" encoding="UTF-8"?>
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <radialGradient id="bg"><stop offset="0" stop-color="#161b22"/><stop offset="1" stop-color="#050608"/></radialGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    <rect width="100%" height="100%" fill="url(#bg)"/>
    <path d="M0 80 Q270 0 540 80 T1080 80" fill="none" stroke="#e32632" stroke-opacity=".35" stroke-width="4"/>
    <text x="540" y="70" text-anchor="middle" fill="#f5f7fa" font-family="Arial" font-size="38" font-weight="800" letter-spacing="4">PERFIL DA ARANHA</text>
    <text x="540" y="105" text-anchor="middle" fill="#aeb6c1" font-family="Arial" font-size="17" letter-spacing="3">A MESMA IDENTIDADE • UMA NOVA TEIA</text>
    <g filter="url(#glow)">${web.join('')}${nodeDots}</g>
    ${panel(55,185,355,270,'IDENTIDADE CIVIL',[['Nome',name],['Codinome',nick],['Dia da Picada',birthday],['Posição na Teia',role]])}
    ${panel(670,185,355,270,'RASTRO-ARANHA',[['Rastro',trail],['Vozes na Teia',messages],['Uso do Fantasminha',botUses],['Título',title]])}
    ${spiderGraphic}
    <text x="540" y="725" text-anchor="middle" fill="#f2f4f6" font-family="Arial" font-size="34" font-weight="800">${name}</text>
    <text x="540" y="757" text-anchor="middle" fill="#e32632" font-family="Arial" font-size="21" font-weight="700" letter-spacing="3">${title}</text>
    <rect x="290" y="790" width="500" height="3" fill="#e32632" opacity=".7"/>
    ${panel(55,830,470,270,'TEIA PESSOAL',[['Nível da Teia',String(level)],['Experiência-Aranha',fmt(xp)],['Próximo nível',fmt(xpNext)],['Distintivos',badge]])}
    ${panel(555,830,470,270,'REGISTROS DA TEIA',[['Missões',plays],['Vitórias',wins],['Pontuação',score],['Melhor sequência',fmt(stats.bestStreak || 0)]])}
    <text x="540" y="1145" text-anchor="middle" fill="#aeb6c1" font-family="Arial" font-size="18">PROGRESSO DA TEIA</text>
    <rect x="210" y="1165" width="660" height="22" rx="11" fill="#171b21" stroke="#68717d" stroke-opacity=".35"/>
    <rect x="210" y="1165" width="${6.6*xpPct}" height="22" rx="11" fill="#e32632"/>
    <text x="540" y="1218" text-anchor="middle" fill="#f2f4f6" font-family="Arial" font-size="19" font-weight="700">${fmt(xp)} / ${fmt(xpNext)} XP • ${xpPct.toFixed(0)}%</text>
    <text x="540" y="1275" text-anchor="middle" fill="#e32632" font-family="Arial" font-size="18" font-weight="700" letter-spacing="3">FANTASMINHA • ARQUIVO ARANHA</text>
    <text x="540" y="1305" text-anchor="middle" fill="#7f8995" font-family="Arial" font-size="14">PERFIL DINÂMICO • DADOS REAIS • ACESSO RESTRITO</text>
  </svg>`;
}

async function renderProfile(ctx, userId) {
  const p = await buildPublicProfile({
    userId: ctx.sender,
    displayUserId: userId,
    groupId: ctx.from || 'private',
    pushname: ctx.pushname || '',
    groupParticipants: ctx.groupParticipants || [],
    groupParticipantObjects: ctx.groupParticipantObjects || [],
    groupAdmins: ctx.groupAdmins || [],
    groupOwner: ctx.groupOwner || null
  });
  const spider = readSpider(p.displayUserId) || { spiderLevel:1, spiderXp:0, title:'Aranha', badges:[] };
  const stats = gameStats(ctx.from || 'global', p.displayUserId);
  const { default: sharp } = await import('sharp');
  const png = await sharp(Buffer.from(webSvg(p, spider, stats))).png().toBuffer();
  const mentions = [p.mention].filter(x => String(x).endsWith('@s.whatsapp.net'));
  const caption = `${TAG}\n\n🕷️ *PERFIL DA ARANHA*\n🕸️ A identidade é a mesma do seu perfil oficial. Esta é apenas a versão exclusiva da Teia.`;
  if (ctx.sendMessage) return ctx.sendMessage(ctx.from || ctx.sender, { image: png, caption, mentions });
  return ctx.reply(caption, { mentions });
}

export async function register() {
  registerCommand({
    name:'perfilaranha', aliases:['aranhaperfil'], category:'perfil', plugin:PLUGIN, permission:Role.USER,
    hidden:true, cooldown:4, description:'Mostra o perfil exclusivo em uma interface dinâmica de teia.',
    usage:'×perfilaranha',
    handler:async ctx=>{
      const requested = target(ctx);
      if (!sameId(requested, ctx.sender) && !isOwner(ctx)) throw new Error('🕷️ O Perfil Aranha é privado.');
      const uid = sameId(requested, ctx.sender) ? ctx.sender : requested;
      if (!allowed(ctx, uid)) throw new Error('🕸️ Sua conta não possui uma Sessão Aranha ativa.');
      return renderProfile(ctx, uid);
    }
  });

  registerCommand({
    name:'menuaranha', aliases:['aranhamenu'], category:'perfil', plugin:PLUGIN, permission:Role.USER,
    hidden:true, cooldown:3, description:'Central exclusiva da Sessão Aranha.', usage:'×menuaranha',
    handler:async ctx=>{
      if (!isOwner(ctx) && !readSpider(ctx.sender)?.enabled) throw new Error('🕸️ A Central Aranha é exclusiva.');
      return ctx.reply(`${TAG}\n\n╭──────────── 🕷️ ────────────╮\n        *CENTRAL ARANHA*\n╰─────────────────────────────╯\n\n🕸️ *Perfil*\n• ${config.prefix}perfilaranha — abrir seu Perfil Aranha\n\n🕷️ *Teia*\n• Nível e XP da Teia ficam integrados ao perfil especial.\n• Estatísticas de jogos são lidas dos registros reais.\n\n🔐 *Acesso*\nSessão privada vinculada à identidade oficial do Fantasminha.`);
    }
  });

  registerCommand({
    name:'aranhaadd', aliases:['ativaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Ativa a Sessão Aranha para uma pessoa.', usage:'×aranhaadd @pessoa',
    handler:async ctx=>{
      const u = target(ctx); if (!u || sameId(u, ctx.sender)) throw new Error('Mencione a pessoa que receberá a Sessão Aranha.');
      const existing = readSpider(u);
      const s = await upsertSpider(u, { enabled:true });
      await audit(ctx,'SPIDER_SESSION_ENABLED',{target:u, alreadyEnabled:!!existing?.enabled});
      return ctx.reply(`${TAG}\n\n🕷️ *SESSÃO ARANHA ATIVADA*\n\n👤 @${baseId(u)}\n🪪 Perfil vinculado: *OFICIAL*\n🕸️ Perfil Aranha: *ATIVO*\n🔐 Acesso privado: *ATIVO*\n\nAgora a conta pode usar *${config.prefix}perfilaranha* e *${config.prefix}menuaranha*.`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'aranharemove', aliases:['desativaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Desativa a Sessão Aranha sem apagar o perfil oficial.', usage:'×aranharemove @pessoa',
    handler:async ctx=>{
      const u = target(ctx); if (!u || sameId(u, ctx.sender)) throw new Error('Mencione a pessoa.');
      const current = readSpider(u); if (!current?.enabled) return ctx.reply(`${TAG}\n\n🕸️ Nenhuma Sessão Aranha ativa para @${baseId(u)}.`,{mentions:[u]});
      await upsertSpider(u,{enabled:false});
      await audit(ctx,'SPIDER_SESSION_DISABLED',{target:u});
      return ctx.reply(`${TAG}\n\n🔒 *SESSÃO ARANHA DESATIVADA*\n\n👤 @${baseId(u)}\n🪪 O perfil oficial continua intacto.`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'aranhastatus', aliases:['statusaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Consulta a Sessão Aranha de uma pessoa.', usage:'×aranhastatus @pessoa',
    handler:async ctx=>{
      const u=target(ctx); if(!u) throw new Error('Mencione a pessoa.');
      const s=readSpider(u);
      return ctx.reply(`${TAG}\n\n🕷️ *STATUS DA SESSÃO ARANHA*\n\n👤 @${baseId(u)}\n🕸️ Sessão: *${s?.enabled?'ATIVA':'INATIVA'}*\n⭐ Nível: *${s?.spiderLevel||1}*\n✨ XP: *${fmt(s?.spiderXp||0)}*\n💎 Distintivos: *${s?.badges?.length||0}*\n📅 Criada: *${s?.createdAt?new Date(s.createdAt).toLocaleString('pt-BR'):'não criada'}*`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'aranhaadmin', aliases:['adminaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Painel administrativo da Sessão Aranha.', usage:'×aranhaadmin',
    handler:async ctx=>ctx.reply(`${TAG}\n\n╭──────── 👑 🕷️ ────────╮\n        *ARANHA ADMIN*\n╰────────────────────────╯\n\n🕷️ ${config.prefix}aranhaadd @pessoa\n   Ativa a Sessão Aranha.\n\n🔒 ${config.prefix}aranharemove @pessoa\n   Desativa sem apagar o perfil oficial.\n\n📊 ${config.prefix}aranhastatus @pessoa\n   Consulta estado, nível e XP.\n\n🖼️ ${config.prefix}perfilaranha @pessoa\n   Visualiza o perfil autorizado.\n\n🧬 Regra: dados de identidade vêm do ${config.prefix}perfil.\n🕸️ Regra: comandos administrativos ficam na categoria *dono* e, portanto, no *menudono*.`)
  });
}

export default { register };
