import { readCollection, updateCollection } from '../database/store.js';
import gameSessions from './gameSessionManager.js';
import torreLimbo from '../games/torre-limbo/index.js';
const norm=s=>String(s||'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
const exitWords=new Set(['sair','sairjogo','sairjogos','cancelar','cancelarjogo','pararjogo','desistir']);

export async function handleRawGameInput(ctx){
  const text=String(ctx.body||ctx.text||'').trim();
  if(!text || text.startsWith(ctx.prefix||'×')) return {handled:false};
  const key=ctx.isGroup?ctx.from:ctx.sender;
  if(norm(text)==='cancelar forca'){
    try {
      const { cancelForContext } = await import('../games/forca/ForcaService.js');
      const result = await cancelForContext(ctx);
      if (result?.handled) return result;
    } catch {}
  }

  try {
    const tower = await torreLimbo.handleInput(ctx);
    if (tower?.handled) return tower;
  } catch (e) {
    try { console.debug('[torre-limbo] input:', e?.message || e); } catch {}
  }

  if(exitWords.has(norm(text))){
    try {
      const quiz = await import('../games/quiz/QuizService.js');
      const qc = await quiz.cancelForContext(ctx);
      if (qc?.cancelled) {
        await ctx.reply?.('🚪✨ *QUIZ ENCERRADO!*\n\nA rodada atual foi cancelada. 👻');
        return { handled: true, cancelled: true, game: 'quiz' };
      }
    } catch {}
    try {
      const { cancelForContext } = await import('../games/memory-cups/MemoryCupsService.js');
      const cancelled = await cancelForContext(ctx);
      if (cancelled?.cancelled) {
        await ctx.reply?.('🚪✨ *JOGO ENCERRADO!*\n\nVocê saiu da partida de *Memória dos Copos*.\nNenhuma animação continuará. 👻');
        return { handled: true, cancelled: true, game: 'memory-cups' };
      }
    } catch {}
    let removed=false;
    try{
      await updateCollection('minigames',M=>{if(M.wordle?.[key]){delete M.wordle[key];removed=true;}if(M.stop?.[key]){delete M.stop[key];removed=true;}if(M.quiz?.[key]){delete M.quiz[key];removed=true;}if(M.bj?.[ctx.sender]){delete M.bj[ctx.sender];removed=true;}return M;},{});
    }catch{}
    for(const k of ['quizGames','wordleGames','anagramaGames']) try{if(global[k]?.[key]){delete global[k][key];removed=true;}}catch{}
    gameSessions.end(key,'quiz'); gameSessions.end(key,'wordle'); gameSessions.end(key,'stop');
    if(!removed) return {handled:false};
    await ctx.reply?.(`🚪✨ *Jogo encerrado!*\n\nVocê saiu da partida. Quando quiser, é só começar outra. 👻`);
    return {handled:true};
  }

  try{
    const M=readCollection('minigames',{}); const g=M.quiz?.[key];
    if(g){
      if(g.endsAt && Date.now()>g.endsAt){
        await updateCollection('minigames',X=>{if(X.quiz) delete X.quiz[key];return X;},{});
        gameSessions.end(key,'quiz');
        await ctx.reply?.(`🪦 *TEMPO ESGOTADO!*\n\n🔮 A resposta era: *${g.display||'a resposta correta'}*`);
        return {handled:true,expired:true};
      }
      let answer=text;
      if(/^\d+$/.test(text) && Array.isArray(g.options)){
        const index=Number(text)-1;
        if(index<0 || index>=g.options.length){await ctx.reply?.(`⚠️ Escolha uma opção de *1 a ${g.options.length}*. O quiz continua.`);return {handled:true,invalid:true};}
        answer=g.options[index];
      }
      const ok=(g.answers||[]).some(a=>norm(answer)===norm(a));
      await updateCollection('minigames',X=>{delete X.quiz[key];return X;},{});
      gameSessions.end(key,'quiz');
      await ctx.reply?.(ok?`🎉✨ *ACERTOU!*\n\n👻 O Véu confirmou sua resposta.`:`🌑 *NÃO FOI DESSA!*\n\n🔮 A resposta correta era: *${g.display||'a resposta do quiz'}*`);
      return {handled:true,correct:ok};
    }
  }catch(e){throw e;}

  if(global.quizGames?.[key]){
    const game=global.quizGames[key];
    let answer=text;
    if(/^\d+$/.test(text) && Array.isArray(game.opcoes)) answer=game.opcoes[Number(text)-1]||text;
    const ok=(game.respostas||[]).some(r=>norm(answer)===norm(r)||norm(answer).includes(norm(r)));
    delete global.quizGames[key];
    await ctx.reply?.(ok?'🎉✨ *ACERTOU!*':'❌ *NÃO FOI DESSA!*');
    return {handled:true,correct:ok};
  }
  return {handled:false};
}
export default {handleRawGameInput};
