import fs from 'node:fs';
import path from 'node:path';
import { readCollection, upsertUser, updateCollection } from '../database/store.js';
import { listNicks } from '../platform/nick/index.js';
import { listBirthdays } from '../platform/birthday/index.js';
import { resolveUserIdentity } from '../platform/identity/resolver.js';
import { configuredOwner } from '../core/permissions.js';
import { listBestFriends } from './social.js';
import relationshipManager from '../../dados/src/funcs/utils/relationships.js';
import config from '../core/config.js';

const TZ = 'America/Sao_Paulo';
const normalizeId = value => String(value || '').trim().toLowerCase();
const baseId = value => normalizeId(value).split('@')[0].split(':')[0];
const phoneFrom = value => {
  const s = normalizeId(value);
  if (s.endsWith('@s.whatsapp.net') && /^\d+$/.test(baseId(s))) return baseId(s);
  return /^\d+$/.test(baseId(s)) ? baseId(s) : null;
};
const sameId = (a, b) => normalizeId(a) === normalizeId(b) || baseId(a) === baseId(b);
const clamp = (n, a = 0, b = 100) => Math.max(a, Math.min(b, Number(n) || 0));

function ensurePending() {
  globalThis.__profileActivity ||= { pending: new Map(), timer: null };
  const state = globalThis.__profileActivity;
  if (!state.timer) {
    state.timer = setInterval(() => { flushActivity().catch(() => {}); }, 30000);
    state.timer.unref?.();
  }
  return state;
}

function dateParts(date = new Date()) {
  const hour = new Intl.DateTimeFormat('pt-BR', { timeZone: TZ, hour: '2-digit', hour12: false }).format(date);
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
  return { hour, day };
}

export function recordMessage(userId, groupId) {
  if (!userId || !groupId) return;
  const state = ensurePending();
  const k = `${groupId}:${normalizeId(userId)}`;
  const { hour, day } = dateParts();
  const p = state.pending.get(k) || { userId, groupId, messages: 0, botUses: 0, days: {}, hours: {} };
  p.messages += 1;
  p.days[day] = (p.days[day] || 0) + 1;
  p.hours[hour] = (p.hours[hour] || 0) + 1;
  state.pending.set(k, p);
}

export function recordCommandUsage(userId, groupId) {
  if (!userId || !groupId) return;
  const state = ensurePending();
  const k = `${groupId}:${normalizeId(userId)}`;
  const p = state.pending.get(k) || { userId, groupId, messages: 0, botUses: 0, days: {}, hours: {} };
  p.botUses += 1;
  state.pending.set(k, p);
}

export async function flushActivity() {
  const state = globalThis.__profileActivity;
  if (!state?.pending?.size) return;
  const rows = [...state.pending.values()];
  state.pending.clear();
  await updateCollection('profile_activity', d => {
    d.byGroupUser ||= {};
    for (const p of rows) {
      const k = `${p.groupId}:${normalizeId(p.userId)}`;
      const cur = d.byGroupUser[k] || { userId: p.userId, groupId: p.groupId, messages: 0, botUses: 0, days: {}, hours: {} };
      cur.messages += Number(p.messages || 0);
      cur.botUses += Number(p.botUses || 0);
      for (const [day, count] of Object.entries(p.days || {})) cur.days[day] = (cur.days[day] || 0) + Number(count || 0);
      for (const [hour, count] of Object.entries(p.hours || {})) cur.hours[hour] = (cur.hours[hour] || 0) + Number(count || 0);
      cur.updatedAt = Date.now();
      d.byGroupUser[k] = cur;
    }
    return d;
  }, { byGroupUser: {} });
}

function activityRows(groupId) {
  const d = readCollection('profile_activity', { byGroupUser: {} });
  return Object.values(d.byGroupUser || {}).filter(x => x.groupId === groupId);
}

function activity(groupId, userId) {
  const d = readCollection('profile_activity', { byGroupUser: {} });
  const direct = d.byGroupUser?.[`${groupId}:${normalizeId(userId)}`];
  if (direct) return direct;
  const found = Object.values(d.byGroupUser || {}).find(x => x.groupId === groupId && sameId(x.userId, userId));
  return found || { messages: 0, botUses: 0, days: {}, hours: {} };
}

function readLegacyGroup(groupId) {
  const file = path.join(config.root, 'dados', 'database', 'grupos', `${groupId}.json`);
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}; } catch { return {}; }
}

function legacyCounter(groupId, userId) {
  const group = readLegacyGroup(groupId);
  const row = (group.contador || []).find(x => sameId(x?.id, userId));
  if (!row) return { messages: 0, botUses: 0, score: 0 };
  const messages = Number(row.msg || 0);
  const botUses = Number(row.cmd || 0);
  const stickers = Number(row.figu || 0);
  return { messages, botUses, score: messages + botUses + stickers };
}

function mergedActivity(groupId, userId) {
  const modern = activity(groupId, userId);
  const legacy = legacyCounter(groupId, userId);
  return {
    ...modern,
    messages: Math.max(Number(modern.messages || 0), legacy.messages),
    botUses: Math.max(Number(modern.botUses || 0), legacy.botUses),
    legacyScore: legacy.score
  };
}

function peakHour(row) {
  const entries = Object.entries(row?.hours || {})
    .filter(([, v]) => Number(v) > 0)
    .sort((a, b) => Number(b[1]) - Number(a[1]) || a[0].localeCompare(b[0]));
  return entries.length ? `${String(entries[0][0]).padStart(2, '0')}h` : 'Não informado';
}

function inactivityPercent(groupId, userId, participants = []) {
  const ids = [...new Set(participants.map(x => baseId(x)).filter(Boolean))];
  const rows = ids.map(id => ({ id, activity: mergedActivity(groupId, id) }));
  if (!rows.length) return null;
  const mine = rows.find(x => sameId(x.id, userId))?.activity?.messages ?? mergedActivity(groupId, userId).messages;
  const active = rows.filter(x => Number(x.activity.messages) > 0);
  if (active.length < 2 || Number(mine) <= 0) return active.length < 2 ? null : 100;

  // Percentil de inatividade: 0% para o topo da atividade e 100% para o fundo.
  // Empates recebem a mesma posição média, evitando que a ordem dos participantes distorça o resultado.
  const greater = active.filter(x => Number(x.activity.messages) > Number(mine)).length;
  const equal = active.filter(x => Number(x.activity.messages) === Number(mine)).length;
  const percentileFromTop = (greater + ((equal - 1) / 2)) / Math.max(1, active.length - 1);
  return Math.round(clamp(percentileFromTop * 100));
}

function rankativo(groupId, userId, participants = []) {
  const group = readLegacyGroup(groupId);
  const counter = Array.isArray(group.contador) ? group.contador : [];
  if (!counter.length) return null;
  const allowed = new Set(participants.map(x => baseId(x)).filter(Boolean));
  const rows = counter
    .filter(x => x?.id && (!allowed.size || allowed.has(baseId(x.id))))
    .map(x => ({ id: x.id, score: Number(x.msg || 0) + Number(x.cmd || 0) + Number(x.figu || 0), messages: Number(x.msg || 0), commands: Number(x.cmd || 0), stickers: Number(x.figu || 0) }));
  if (!rows.length) return null;
  rows.sort((a, b) => b.score - a.score || b.messages - a.messages || b.commands - a.commands || baseId(a.id).localeCompare(baseId(b.id)));
  const index = rows.findIndex(x => sameId(x.id, userId));
  return index < 0 ? null : index + 1;
}

function groupWarns(groupId, userId) {
  const d = readCollection('groups', { byId: {} });
  const direct = d.byId?.[groupId]?.warns?.[userId];
  if (direct != null) return Number(direct) || 0;
  const found = Object.entries(d.byId?.[groupId]?.warns || {}).find(([id]) => sameId(id, userId));
  return Number(found?.[1] || 0) || 0;
}

function birthdayFor(groupId, userId) {
  const row = listBirthdays(groupId).find(x => sameId(x.platformId, userId) || sameId(x.memberId, userId));
  if (!row) return null;
  return `${String(row.day).padStart(2, '0')}/${String(row.month).padStart(2, '0')}${row.year ? `/${row.year}` : ''}`;
}

function relationshipFor(userId, groupId) {
  try {
    const pair = relationshipManager.getActivePairForUser(userId);
    if (!pair) return { status: 'Solteiro(a)', partnerId: null };
    const status = pair.pair?.status;
    const stage = pair.pair?.stages?.[status];
    if (stage?.groupId && stage.groupId !== groupId) return { status: 'Solteiro(a)', partnerId: null };
    if (status === 'casamento') return { status: 'Casado(a)', partnerId: pair.partnerId };
    if (status === 'namoro') return { status: 'Namorando', partnerId: pair.partnerId };
    return { status: 'Em uma brincadeira', partnerId: pair.partnerId };
  } catch {
    return { status: 'Solteiro(a)', partnerId: null };
  }
}

function roleFor(target, participants = [], groupAdmins = [], groupOwner = null) {
  const t = baseId(target);
  if (groupOwner && sameId(groupOwner, target)) return 'Super Administrador';
  const participant = participants.find(p => sameId(p?.id || p?.jid || p?.participant, target));
  if (participant?.admin === 'superadmin') return 'Super Administrador';
  if (participant?.admin === 'admin') return 'Administrador';
  if (groupAdmins.some(x => sameId(x, target))) return 'Administrador';
  return t ? 'Membro' : 'Não informado';
}

function formatDateTime(value) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return { date: 'Não informado', time: 'Não informado' };
  return {
    date: d.toLocaleDateString('pt-BR', { timeZone: TZ }),
    time: d.toLocaleTimeString('pt-BR', { timeZone: TZ, hour12: false })
  };
}

function formatNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString('pt-BR') : '0';
}

export async function buildPublicProfile({
  userId,
  displayUserId = null,
  groupId,
  pushname = '',
  groupParticipants = [],
  groupParticipantObjects = [],
  groupAdmins = [],
  groupOwner = null,
  now = Date.now()
}) {
  const requested = displayUserId || userId;
  const identity = await resolveUserIdentity({
    sender: userId,
    pushname,
    groupParticipantObjects
  }, requested);
  const target = identity.realJid || requested;
  const u = await upsertUser(target, { name: identity.name || pushname || '' });
  const participants = groupParticipants.length ? groupParticipants : groupParticipantObjects.map(p => p?.id || p?.jid || p?.participant).filter(Boolean);
  const participantsObjects = groupParticipantObjects.length ? groupParticipantObjects : participants.map(id => ({ id }));
  const act = mergedActivity(groupId, target);
  const nick = listNicks(groupId).find(x => sameId(x.platformId, target) || sameId(x.memberId, target));
  const rel = relationshipFor(target, groupId);
  const friends = listBestFriends(target);
  const bestFriend = friends[0] || null;
  const last = formatDateTime(now);
  const phone = identity.number || phoneFrom(target);
  const groupRank = rankativo(groupId, target, participants);
  const inactivity = inactivityPercent(groupId, target, participants);
  const relationshipPartner = rel.partnerId ? (await resolveUserIdentity({ groupParticipantObjects: participantsObjects }, rel.partnerId)).realJid || rel.partnerId : null;

  return {
    userId: target,
    displayUserId: target,
    number: phone,
    mention: identity.mentionJid || target,
    name: identity.name || pushname || 'Não informado',
    nick: nick?.nick || 'Não cadastrado',
    birthday: birthdayFor(groupId, target) || 'Não cadastrado',
    role: roleFor(target, participantsObjects, groupAdmins, groupOwner),
    messages: Number(act.messages || 0),
    botUses: Number(act.botUses || 0),
    inactivityPercent: inactivity,
    position: groupRank,
    vacilos: groupWarns(groupId, target),
    relationship: rel.status,
    relationshipPartner,
    bestFriend,
    peakHour: peakHour(act),
    lastProfileAt: now,
    lastDate: last.date,
    lastTime: last.time,
    premium: !!u.premium?.active
  };
}

function mentionToken(jid) {
  const phone = phoneFrom(jid);
  return `@${phone || baseId(jid)}`;
}

export function profileText(p) {
  const bestFriend = p.bestFriend ? mentionToken(p.bestFriend) : 'Não cadastrado';
  const inactivity = p.inactivityPercent == null ? 'Não calculável' : `${p.inactivityPercent}%`;
  const rank = p.position ? `#${p.position}` : 'Sem colocação';
  const phone = p.number || 'Não informado';
  return `╭─👻 𝙁𝘼𝙉𝙏𝘼𝙎𝙈𝙄𝙉𝙃𝘼 ─╮
│     𝙍𝙀𝙂𝙄𝙎𝙏𝙍𝙊 𝘿𝘼 𝘼𝙇𝙈𝘼
│
│ 👻 𝙌𝙐𝙀𝙈 𝙑𝙀𝙄𝙊 𝘼𝙌𝙐𝙄
│
│ 🪪 𝙉𝙤𝙢𝙚 ─ ${mentionToken(p.mention)}
│ 🎭 𝘼𝙥𝙚𝙡𝙞𝙙𝙤 ─ ${p.nick}
│ 🎂 𝘿𝙞𝙖 𝙙𝙖 𝙖𝙡𝙢𝙖 ─ ${p.birthday}
│ 📱 𝙍𝙖𝙨𝙩𝙧𝙤 ─ ${phone}
│ 👑 𝙋𝙖𝙩𝙚𝙣𝙩𝙚 ─ ${p.role}
│
│ ─────────── ✦ ───────────
│
│ 🔮 𝙈𝘼𝙍𝘾𝘼𝙎 𝘿𝘼 𝘼𝙇𝙈𝘼
│
│ 💬 𝙑𝙤𝙯𝙚𝙨 𝙙𝙚𝙞𝙭𝙖𝙙𝙖𝙨 ─ ${formatNumber(p.messages)}
│ ⚡ 𝙀𝙣𝙘𝙤𝙣𝙩𝙧𝙤𝙨 𝙘𝙤𝙢 𝙤 𝙁𝙖𝙣𝙩𝙖𝙨𝙢𝙞𝙣𝙝𝙖 ─ ${formatNumber(p.botUses)} • ${inactivity}
│ 🏆 𝙇𝙪𝙜𝙖𝙧 𝙣𝙤 𝙧𝙖𝙣𝙠 ─ ${rank}
│ ⚠️ 𝙑𝙖𝙘𝙞𝙡𝙤𝙨 𝙖𝙘𝙪𝙢𝙪𝙡𝙖𝙙𝙤𝙨 ─ ${formatNumber(p.vacilos)}
│ 🕒 𝙃𝙤𝙧𝙖 𝙙𝙚 𝙖𝙥𝙖𝙧𝙚𝙘𝙚𝙧 ─ ${p.peakHour}
│ 🫂 𝘽𝙚𝙨𝙩 𝙁𝙧𝙞𝙚𝙣𝙙 ─ ${bestFriend}
│
│ ─────────── ✦ ───────────
│
│ 💕 𝙇𝘼𝘾̧𝙊𝙎
│
│ ❌ 𝙎𝙞𝙩𝙪𝙖𝙘̧𝙖̃𝙤 𝙖𝙛𝙚𝙩𝙞𝙫𝙖 ─ ${p.relationship}
│
│ ─────────── ✦ ───────────
│
│ 🌙 𝙎𝙄𝙉𝘼𝙇 𝘿𝘼 𝘼𝙇𝙈𝘼
│
│ 📅 𝙐́𝙡𝙩𝙞𝙢𝙖 𝙥𝙖𝙨𝙨𝙖𝙜𝙚𝙢 ─ ${p.lastDate}
│ 🕰️ 𝙈𝙖𝙧𝙘𝙖𝙙𝙖 𝙖̀𝙨 ─ ${p.lastTime}
│
╰─「 𝙙𝙤 𝙖𝙡𝙚́𝙢 」─╯`;
}

export default { buildPublicProfile, profileText, recordMessage, recordCommandUsage, flushActivity };
