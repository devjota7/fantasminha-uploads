from pathlib import Path
import re,json
ROOT=Path('/mnt/data/menu_audit')
idxp=ROOT/'dados/src/index.js'; text=idxp.read_text(); lines=text.splitlines()
# Existing registry names/aliases from source.
existing_names=set(); existing_aliases=set()
for p in (ROOT/'src/plugins').rglob('*.js'):
 s=p.read_text(errors='ignore')
 for m in re.finditer(r"registerCommand\s*\(\s*\{([\s\S]*?)\}\s*\)\s*;?",s):
  b=m.group(1); n=re.search(r"\bname\s*:\s*['\"]([^'\"]+)['\"]",b)
  if n: existing_names.add(n.group(1).lower())
  a=re.search(r"\baliases\s*:\s*\[([^\]]*)\]",b,re.S)
  if a: existing_aliases.update(x.group(1).lower() for x in re.finditer(r"['\"]([^'\"]+)['\"]",a.group(1)))
# Main switch case groups.
entries=[]
for i,l in enumerate(lines):
 m=re.match(r'^      case\s+[\'\"]([^\'\"]+)[\'\"]\s*:',l)
 if m: entries.append((i,m.group(1)))
groups=[]; cur=[]; prev=None
for e in entries:
 if prev is not None and e[0]==prev+1: cur.append(e)
 else:
  if cur: groups.append(cur)
  cur=[e]
 prev=e[0]
if cur: groups.append(cur)
menu_names=set('menu help comandos commands menualterador menualteradores changersmenu changers menulogo menulogos menubn menubrincadeira menubrincadeiras gamemenu menudown menudownload menudownloads downmenu downloadmenu ferramentas menuferramentas menuferramenta toolsmenu tools menuadm menuadmin menuadmins admmenu menumembros menumemb menugeral membmenu membermenu menudono ownermenu stickermenu menusticker menufig menualem menuveu menujogos jogosalem menurpg rpgmenu menuvip vipmenu menupremium menuia menutriagem menueconomia menuclans menuguerras menucomunidade economia premium rpg'.split())
unsafe_exact=set('sexo goza gozar mamar mamada surubao bucetuda pirocudo pirokudo nazista suicidio pornhub apostar bet slots roleta roulette blackjack 21 loteria mega cacaniquel corrida cavalos apostarpet petbet'.split())
unsafe_prefixes=('gay','lesbica','homofob','racist','machist')

def classify(n,body):
 n=n.lower()
 if n in menu_names or n.startswith('menu'): return None
 if n in unsafe_exact or any(n.startswith(p) for p in unsafe_prefixes): return 'restricted'
 if n.startswith('triagem') or n in {'filatriagem','aprovar','reprovar','cancelatriagem','setpergunta','setperguntas','verperguntas'}: return 'triagem'
 if n in {'st','stk','sticker','s','st2','stk2','sticker2','s2','figualeatoria','randomsticker','rename','mudarpack','figurinhas','packfig'}: return 'figurinhas'
 if n.startswith(('tiktok','facebook','instagram','gdrive','twitter','youtube','yt','spotify','soundcloud','pinterest','mediafire','mcplugins','bratvid','play','dl','probeurl','letra','lyrics','to-mp3')): return 'downloads'
 if n.startswith(('setname','setdesc','setfoto','ban','kick','promover','rebaixar','mute','desmute','ant','auto','modobrincadeira','bemvindo','fotobv','removerfoto','removerfotos','configsaida','saida','parcerias','addparceria','delparceria','blacklist','adv','removeradv','listadv','suporte','ticket','solicitacoes','captchasolic','linkgp','grupo','opengp','closegp','totag','marcar','wl.','addregra','delregra','listmods','grantmodcmd','revokemodcmd','soadm','modolite','regras','admins','admin','setregra','maxwarns','resetwarn','grupoinfo')): return 'admin'
 if n.startswith(('rental','listaralug','removeralug','estenderalug','infoalug','gerarcod','addsub','remsub','listasub','conectarsub','removesubbot','listarsubbots','cmdlimitar','cmddeslimitar','cmdlimites','atualizar','reiniciar','backupconfig','cachedebug','debugcache','numerodono','nomebot','forcar','bloqueartudo','desbloqueartudo','statusalemdono','iaclear','cmdinfo','totalcmd','topcmd','statusbot','statusgp','diagnosticrpg')): return 'dono' if any(k in n for k in ('numerodono','nomebot','forcar','bloqueartudo','desbloqueartudo','statusalemdono','backupconfig')) else 'sistema'
 if n.startswith(('addpremium','delpremium','listapremium','removecmdvip','addcmdvip','listcmdvip','togglecmdvip','statsvip','infovip','vip','planosvip')): return 'premium'
 if n.startswith(('clan','cla','guerra','guerr','war','clagrupo','claworld','campeonato')): return 'grupo'
 if n.startswith(('rpg','classe','profissao','dungeon','masmorra','boss','equipar','meustreinos','missoes','familia','adotaruser','arvore','reputacao','votar','investir','prestigio')): return 'rpg'
 if n in {'economia','carteira','banco','depositar','dep','sacar','saque','transferir','pix','loja','lojarps','comprar','buy','inventario','inv','minerar','mine','trabalhar','work','emprego','vagas','demitir','pescar','fish','explorar','explore','cacar','caçar','hunt','mercado','listar','comprarmercado','cmerc','meusanuncios','meusan','cancelar','propriedades','comprarpropriedade','cprop','coletarpropriedades','cprops','habilidades','desafiosemanal','desafiomensal','materiais','precos','preços','vender','reparar','desafio','forjar','forge','crime','assaltar','roubar','cozinhar','cook','receitas','plantar','cultivar','plant','farm','colher','coletar','harvest','plantacao','plantação','horta','comer','eat','vendercomida','ingredientes','sementes','daily','diario','rankgc','ranksemana'}: return 'economia'
 if n.startswith(('rank','top','meurank')): return 'rankings'
 if n.startswith('pet') or n in {'pets','adotapet','adotar','alimentar','feed','treinar','evoluirpet','renomearpet','batalhapet','petbattle','equipet','equippet','unequippet','desequiparpet'}: return 'pets'
 if n in {'forca','stop','gartic','quiz','memoria','memoriacopos','memoriafantasma','jogodavelha','ttt','tictactoe','connect4','ligue4','uno','wordle','digitar','batalhanaval','dueloquiz','cacapalavras','forcaalem','quizalem','placaralem','juizfinal','torrelimbo','batalhaalmas','aceitarbatalha','recusarbatalha','sairjogo','encerrarjuiz','jogada','jogodesistir','anagrama','matematica','campominado','quemsoueu'} or n.startswith(('torneio','entorneio','iniciartorneio','listatorneios')): return 'jogos'
 if n in {'personalidade','perfil','meustatus','afk','voltei','addbestfriend','rmvbestfriend','conquistas','conquistasalma','titulos','meubest'} or n.startswith(('perfil','meubest')): return 'perfil'
 if n.startswith(('addreact','delreact','listreact','react')): return 'ferramentas'
 if n in {'aniversario','aniversarios','birthday','buscarusuario','nicks','nick','semdata','semanick','reconciliar','todos','addsala','sala','rmsala','preferencias'}: return 'comunidade'
 if n.startswith(('statusalem','frasealem','veu','purgatorio','submundo','cemiterio','eco','alma','julgamento','sombra','destino','pecado','virtude','karma','horarioveu','contagemalmas','sorteioalem','ajudaalem','pingalem','museulimbo','jornaldolimbo','mundovivo','historia','misterio','expedicao','eventomundial','atacarboss','bossmundial','bossinvocar','pistacaso','temporadainnovation','historiainterativa','caminhoveu')): return 'alem'
 if n in {'dado','dados','coinflip','moeda','chance','8ball','piada','fato','conselho','escolher','ship','compatibilidade','quem','voceprefere','brincadeira','casal','namoro','casamento','divorciar','divorcio','termino','terminarelacionamento','trair','historicotraicao'}: return 'brincadeiras'
 if n in {'calc','hora','fuso','horario','clima','clima2','horamundial','qrcode','lerqr','nota','notas','tradutor','translator','encurtalink','tinyurl','verificar','verificarurl','checkurl','urlsafe','linkseguro','url','wikipedia','github','json','base64','hash','morse','uuid','timestamp','texto','contar','senha','upload','gerarlink','printsite','ssweb'}: return 'ferramentas'
 if n.startswith(('speed','voz','cortar','reverse','bass','normalizar','equal','reverb','overdrive','flanger','phaser','tremolo','vibrato','pitch','volum','espelhar','rotacionar','sepia','preto','upscale','vide','audio')): return 'ferramentas'
 if n.startswith(('addcmd','edcmd','delcmd','testcmd','autoresponse','addauto','delauto','listauto','addnoprefix','delnoprefix','listnoprefix','configcmdnotfound','tutorial','designmenu','resetdesign','setborda','setheader','setitemicon','setseparador','settitleicon','fotomenu','videomenu','audiomenu','lermais','personalizargrupo','fotomenugrupo','removerfotomenu','nomegrupo','removernome','infoperso')): return 'ferramentas'
 return 'ferramentas'

def desc(cat):
 return {'jogos':'Jogo ou recurso de entretenimento.','rpg':'Recurso de RPG e progressão.','economia':'Economia e recursos.','ferramentas':'Ferramenta e utilidade.','downloads':'Download e mídia.','figurinhas':'Criação e gerenciamento de figurinhas.','admin':'Administração e moderação.','dono':'Controle e manutenção do bot.','sistema':'Sistema e diagnóstico.','grupo':'Comunidade, clãs e guerras.','comunidade':'Recursos sociais da comunidade.','perfil':'Perfil e interação social.','rankings':'Rankings e estatísticas.','brincadeiras':'Brincadeira e interação recreativa.','alem':'Recursos do Além.','triagem':'Triagem e gestão de entrada.','pets':'Pets virtuais e progressão.','premium':'Recursos Premium.'}[cat]
# Build manifest. For groups whose body depends on command, each case is a distinct canonical command; otherwise aliases.
defs=[]
for g in groups:
 start=g[-1][0]+1; nxt=next((i for i,_ in entries if i>g[-1][0]),len(lines)); body='\n'.join(lines[start:nxt]); labels=[x[1] for x in g]
 dynamic=bool(re.search(r'\bcommand\b',body)) and len(labels)>1
 if dynamic:
  for label in labels:
   cat=classify(label,body)
   if cat and cat!='restricted': defs.append({'name':label,'aliases':[],'category':cat,'permission':None,'groupOnly':None,'description':desc(cat)})
 else:
  cat=classify(labels[0],body)
  if cat and cat!='restricted': defs.append({'name':labels[0],'aliases':[x for x in labels[1:] if x.lower() not in menu_names], 'category':cat,'permission':None,'groupOnly':None,'description':desc(cat)})
# merge duplicate canonical names
merged={}
for d in defs:
 n=d['name'].lower()
 if n in merged: merged[n]['aliases']=sorted(set(merged[n]['aliases']+d['aliases']))
 else: merged[n]=d
for d in merged.values():
 # infer permission and group-only from source body by finding corresponding group containing canonical
 # approximate from name plus body not retained; default user; critical admin/dono prefixes handled below.
 n=d['name'].lower()
 if d['category']=='dono': d['permission']=100
 elif d['category']=='admin' or d['category']=='triagem': d['permission']=60
 elif d['category']=='premium': d['permission']=40
 else: d['permission']=10
 if d['category'] in {'admin','triagem','grupo','jogos','rpg','economia','rankings'} and n in {'banir','deletar','setname','setdesc','setfoto','promover','rebaixar','mute','desmute','grupo','solicitacoes','aprovar','reprovar'}: d['groupOnly']=True
 d['aliases']=[a for a in d['aliases'] if a.lower() not in existing_names and a.lower() not in menu_names and a.lower() not in unsafe_exact and not any(a.lower().startswith(p) for p in unsafe_prefixes)]
# write plugin
plugin=ROOT/'src/plugins/legacyRegistry/index.js'; plugin.parent.mkdir(parents=True,exist_ok=True)
plugin.write_text("""import { registerCommand, getCommand, registerAlias } from '../../core/registry.js';\nimport { Role } from '../../core/permissions.js';\n\n// Ponte de catálogo para comandos ainda executados pelo switch legado.\n// Ela centraliza descoberta, categoria e aliases sem duplicar a execução.\nconst DEFINITIONS = %s;\n\nexport async function register() {\n  let added = 0, aliasCount = 0;\n  for (const def of DEFINITIONS) {\n    const current = getCommand(def.name);\n    if (current) {\n      for (const alias of def.aliases || []) {\n        if (getCommand(alias)) continue;\n        const r = registerAlias(alias, current.name);\n        if (r.ok) aliasCount++;\n      }\n      continue;\n    }\n    const entry = registerCommand({\n      ...def, permission: def.permission ?? Role.USER, plugin: 'legacy-switch',\n      priority: -100, cooldown: 0, audit: false, legacyBridge: true,\n      handler: async () => ({ legacy: true })\n    });\n    if (entry?.plugin === 'legacy-switch') added++;\n  }\n  return { added, aliases: aliasCount, total: DEFINITIONS.length };\n}\nexport const legacyDefinitions = DEFINITIONS;\nexport default { register, legacyDefinitions };\n""" % json.dumps(list(merged.values()),ensure_ascii=False,separators=(',',':')))
# registry + bridge + bootstrap
rp=ROOT/'src/core/registry.js'; rs=rp.read_text(); old="enabled: def.enabled !== false, plugin: def.plugin || null, version: def.version || null, responseCapabilities: def.responseCapabilities || null,"; new="enabled: def.enabled !== false, plugin: def.plugin || null, version: def.version || null, legacyBridge: !!def.legacyBridge, responseCapabilities: def.responseCapabilities || null,"; assert old in rs; rp.write_text(rs.replace(old,new,1))
vp=ROOT/'dados/src/v2bridge.js'; vs=vp.read_text(); old="""  if (!ready) return { handled: false };\n  if (ctx.command && !getCommand(ctx.command)) return { handled: false, legacy: true };\n  return handleMessage(ctx);"""; new="""  if (!ready) return { handled: false };\n  const command = ctx.command ? getCommand(ctx.command) : null;\n  if (ctx.command && !command) return { handled: false, legacy: true };\n  if (command?.legacyBridge) return { handled: false, legacy: true };\n  return handleMessage(ctx);"""; assert old in vs; vp.write_text(vs.replace(old,new,1))
bp=ROOT/'src/core/bootstrap.js'; bs=bp.read_text();
if "legacyRegistryPlugin" not in bs:
 bs=bs.replace("import * as rankingPlugin from '../plugins/ranking/index.js';","import * as rankingPlugin from '../plugins/ranking/index.js';\nimport * as legacyRegistryPlugin from '../plugins/legacyRegistry/index.js';")
 bs=bs.replace("    await rankingPlugin.register();\n    try { await (await import('../games/quiz/QuizService.js')).recover(); }","    await rankingPlugin.register();\n    await legacyRegistryPlugin.register();\n    try { await (await import('../games/quiz/QuizService.js')).recover(); }")
bp.write_text(bs)
# license category
cp=ROOT/'src/plugins/completeExpansion/index.js'; cs=cp.read_text().replace("category:'configuracao'","category:'licenca'"); cs=re.sub(r"\n\s*safe\(\{name:'menualem',[^\n]*\}\);",'',cs,count=1); cp.write_text(cs)
# remove all menu case groups in one pass by target labels.
targets=set('economia menueconomia clans clãs menuclans guerras menuguerras menuia menutriagem triagem menupremium premium menusistema sistema menucomunidade comunidade menurpg rpg alteradores menualterador menualteradores changersmenu changers menulogo menulogos edits menuedits menubn menubrincadeira menubrincadeiras gamemenu menudown menudownload menudownloads downmenu downloadmenu ferramentas menuferramentas menuferramenta toolsmenu tools menuadm menuadmin menuadmins admmenu menumembros menumemb menugeral membmenu membermenu menudono ownermenu stickermenu menusticker menufig menuvip vipmenu menujogos jogosalem menualem menuveu'.split())
# recompute main case line indices on current text
ls=text.splitlines(); ranges=[]
for i,l in enumerate(ls):
 m=re.match(r'^      case\s+[\'\"]([^\'\"]+)[\'\"]\s*:',l)
 if m and m.group(1).lower() in targets:
  st=i
  while st>0 and re.match(r'^      case\s+[\'\"]([^\'\"]+)[\'\"]\s*:',ls[st-1]): st-=1
  en=i+1
  while en<len(ls) and not re.match(r'^      case\s+[\'\"]([^\'\"]+)[\'\"]\s*:',ls[en]): en+=1
  ranges.append((st,en))
# merge overlapping
merged_ranges=[]
for r in sorted(ranges):
 if merged_ranges and r[0]<=merged_ranges[-1][1]: merged_ranges[-1]=(merged_ranges[-1][0],max(merged_ranges[-1][1],r[1]))
 else: merged_ranges.append(r)
for st,en in reversed(merged_ranges): del ls[st:en]
text='\n'.join(ls)+'\n'
# Remove helper function from main switch if still present. Find exact nested declaration and matching brace using a simple brace scanner.
start=text.find('        async function sendMenuWithMedia(menuType, menuFunction) {')
if start>=0:
 # find matching brace, lexical-ish counter ignoring strings is unnecessary for this helper body; use brace count.
 i=text.find('{',start); depth=0; end=None
 in_str=None; esc=False; in_line=False; in_block=False
 j=i
 while j<len(text):
  c=text[j]; n=text[j+1] if j+1<len(text) else ''
  if in_line:
   if c=='\n': in_line=False
  elif in_block:
   if c=='*' and n=='/': in_block=False; j+=1
  elif in_str:
   if esc: esc=False
   elif c=='\\': esc=True
   elif c==in_str: in_str=None
  else:
   if c in "'\"`": in_str=c
   elif c=='/' and n=='/': in_line=True; j+=1
   elif c=='/' and n=='*': in_block=True; j+=1
   elif c=='{': depth+=1
   elif c=='}':
    depth-=1
    if depth==0: end=j+1; break
  j+=1
 if end: text=text[:start]+text[end:]
# Add import buildCatalogMenu if missing
if "./menus/catalogMenu.js" not in text:
 text=text.replace("import { decorateResponse } from './menus/theme.js';","import { decorateResponse } from './menus/theme.js';\nimport { buildCatalogMenu } from './menus/catalogMenu.js';")
# Simplify menu import destructuring.
m=re.search(r"  const \{ default: menus \} = await import\('./menus/index\.js'\);\n  const \{[\s\S]*?\n  \} = menus;",text)
if m: text=text[:m.start()]+"  const { default: menus } = await import('./menus/index.js');\n  const { menu, menuPremium } = menus;"+text[m.end():]
# Add redirect before main switch.
marker="    switch (command) {"
redirect="""    const LEGACY_MENU_REDIRECTS = {\n      economia:'rpg', clans:'grupo', clãs:'grupo', menuclans:'grupo', guerras:'grupo', menuguerras:'grupo',\n      menuia:'bn', menutriagem:'adm', triagem:'adm', menupremium:'premium', premium:'premium', menusistema:'sistema',\n      sistema:'sistema', menucomunidade:'grupo', comunidade:'grupo', menurpg:'rpg',\n      menudown:'ferramentas', menudownload:'ferramentas', menudownloads:'ferramentas', downmenu:'ferramentas', downloadmenu:'ferramentas',\n      ferramentas:'ferramentas', menuferramentas:'ferramentas', menuferramenta:'ferramentas', toolsmenu:'ferramentas', tools:'ferramentas',\n      menuadm:'adm', menuadmin:'adm', menuadmins:'adm', admmenu:'adm', menumembros:'social', menumemb:'social', menugeral:'social', membmenu:'social', membermenu:'social',\n      menudono:'dono', ownermenu:'dono', menuvip:'premium', vipmenu:'premium', menufig:'ferramentas', menusticker:'ferramentas', stickermenu:'ferramentas',\n      menujogos:'jogos', jogosalem:'jogos', menualem:'ferramentas', menuveu:'ferramentas', menubn:'jogos', menubrincadeira:'jogos', menubrincadeiras:'jogos', gamemenu:'jogos',\n      menulogo:'ferramentas', menulogos:'ferramentas', menuedits:'ferramentas', edits:'ferramentas', alteradores:'ferramentas', menualterador:'ferramentas', menualteradores:'ferramentas', changersmenu:'ferramentas', changers:'ferramentas'\n    };\n    if (isCmd && LEGACY_MENU_REDIRECTS[command]) {\n      command = 'menu';\n      args[0] = LEGACY_MENU_REDIRECTS[command];\n    }\n\n    switch (command) {"""
# Bug above uses changed command; fix expression after insertion.
redirect=redirect.replace("args[0] = LEGACY_MENU_REDIRECTS[command];","args[0] = LEGACY_MENU_REDIRECTS[originalMenuCommand];")
redirect=redirect.replace("    if (isCmd && LEGACY_MENU_REDIRECTS[command]) {\n      command = 'menu';", "    const originalMenuCommand = command;\n    if (isCmd && LEGACY_MENU_REDIRECTS[originalMenuCommand]) {\n      command = 'menu';")
assert marker in text
text=text.replace(marker,redirect,1)
# Fix menu call options if present.
text=text.replace("{ category: args?.[0], page: args?.[1], permission: isOwner ? 100 : isBotAdmin ? 80 : isGroupAdmin ? 60 : isPremium ? 40 : 10 }", "{ category: args?.[0], page: args?.[1], permission: isOwner ? 100 : isBotAdmin ? 80 : isGroupAdmin ? 60 : isPremium ? 40 : 10, lerMaisText: getMenuLerMaisText() }")
idxp.write_text(text)
# Rewrite menus folder: retain only dynamic catalog, main menu, theme, premium wrapper.
menus=ROOT/'dados/src/menus'; keep={'catalogMenu.js','menu.js','theme.js','menupremium.js'}
for p in menus.glob('*.js'):
 if p.name not in keep: p.unlink()
(menus/'index.js').write_text("import menu from './menu.js';\nimport menuPremium from './menupremium.js';\nexport async function getMenus(){ return { menu, menuPremium }; }\nexport default { menu, menuPremium };\n")
(menus/'menupremium.js').write_text("import { buildCatalogMenu } from './catalogMenu.js';\nexport default async function menuPremium(prefix='×', botName='Fantasminha', userName='Usuário', design=null, options={}) { return buildCatalogMenu(prefix,'premium',{...options,botName,userName,customDesign:design}); }\n")
# New catalog
(ROOT/'dados/src/menus/catalogMenu.js').write_text('''import { MENU_THEME, menuHeader, menuFooter } from './theme.js';\nimport { listCommands } from '../../../src/core/registry.js';\n\nexport const MENU_STRUCTURE = Object.freeze({\n  social:{title:'👤 SOCIAL',categories:['perfil','personal','conquistas'],close:'🩶'},\n  jogos:{title:'🎮 JOGOS',categories:['jogos','quiz','rankings','brincadeiras','competitivo','torneios','pets'],close:'⛧'},\n  rpg:{title:'⚔️ RPG',categories:['rpg','economia','mundo','world-engine'],close:'⛧'},\n  bn:{title:'🤖 BN / IA',categories:['ia'],close:'🔮'},\n  ferramentas:{title:'🛠️ FERRAMENTAS',categories:['ferramentas','utilidades','produtividade','downloads','figurinhas','media','geral','alem','mega-expansao','expansion','platform'],close:'🕯️'},\n  grupo:{title:'👥 GRUPO',categories:['comunidade','clans','group-clan','wars','campeonato'],close:'👻'},\n  adm:{title:'🛡️ ADM',categories:['admin','triagem','licenca'],close:'⛧'},\n  dono:{title:'👑 DONO',categories:['dono','owner'],close:'🩶'},\n  sistema:{title:'⚙️ SISTEMA',categories:['sistema','seguranca'],close:'⛧'},\n  premium:{title:'💎 PREMIUM',categories:['premium'],close:'💎'}\n});\n\nexport const CATEGORY_ALIASES = Object.freeze({social:'social',jogos:'jogos',jogo:'jogos',games:'jogos',rpg:'rpg',bn:'bn',ia:'bn',inteligencia:'bn',ferramentas:'ferramentas',ferramenta:'ferramentas',tools:'ferramentas',grupo:'grupo',comunidade:'grupo',clans:'grupo',clãs:'grupo',adm:'adm',admin:'adm',administracao:'adm',triagem:'adm',licenca:'adm',licença:'adm',dono:'dono',owner:'dono',sistema:'sistema',seguranca:'sistema',premium:'premium',vip:'premium',downloads:'ferramentas',download:'ferramentas',figurinhas:'ferramentas',media:'ferramentas',utilidades:'ferramentas',produtividade:'ferramentas',alem:'ferramentas',expansion:'ferramentas','mega-expansao':'ferramentas',platform:'ferramentas'});\nconst ROLE_LABEL=new Map([[100,'Dono'],[80,'Bot Admin'],[60,'Admin'],[50,'Moderador'],[40,'VIP'],[10,'Membro']]);\nconst normalize=v=>String(v??'').trim().toLowerCase();\nfunction allowed(c,o={}){return c.enabled!==false&&Number(o.permission??10)>=Number(c.permission??10);}\nfunction top(c){const cat=normalize(c.category||'geral');for(const [k,d] of Object.entries(MENU_STRUCTURE))if(d.categories.includes(cat))return k;return 'ferramentas';}\nconst SUB={social:{perfil:'👤 Perfil',personal:'🤝 Interações',conquistas:'🏅 Conquistas'},jogos:{jogos:'🎮 Jogos',quiz:'🎯 Quiz',rankings:'🏆 Rankings',brincadeiras:'🎲 Brincadeiras',competitivo:'⚔️ Competitivo',torneios:'🏟️ Torneios',pets:'🐾 Pets'},rpg:{rpg:'⚔️ RPG',economia:'💰 Economia',mundo:'🌎 Mundo Vivo','world-engine':'🌎 Mundo Vivo'},bn:{ia:'🧠 Inteligência / IA'},ferramentas:{ferramentas:'🛠️ Ferramentas',utilidades:'⏱️ Utilidades',produtividade:'📝 Produtividade',downloads:'📥 Downloads',figurinhas:'🖼️ Figurinhas',media:'🎞️ Mídia',geral:'🧰 Geral',alem:'🌑 Além','mega-expansao':'🚀 Expansões',expansion:'🚀 Expansões',platform:'🚀 Plataforma'},grupo:{comunidade:'👥 Comunidade',clans:'🏰 Clãs','group-clan':'🏰 Clãs',wars:'⚔️ Guerras',campeonato:'🏟️ Campeonatos'},adm:{admin:'🛡️ Administração',triagem:'⚖️ Triagem',licenca:'🔐 Licença'},dono:{dono:'👑 Proprietário',owner:'👑 Proprietário'},sistema:{sistema:'⚙️ Sistema',seguranca:'🔐 Segurança'},premium:{premium:'💎 Premium'}};\nexport function organizeCommands(commands,options={}){const groups=new Map(),seen=new Set(),duplicates=[],visible=[];for(const c of commands||[]){if(!c?.name||!allowed(c,options))continue;const n=normalize(c.name);if(seen.has(n)){duplicates.push(n);continue;}seen.add(n);const k=top(c),cat=normalize(c.category||'geral'),sub=c.subcategory||SUB[k]?.[cat]||`📂 ${String(c.category||'Geral').toUpperCase()}`;if(!groups.has(k))groups.set(k,new Map());if(!groups.get(k).has(sub))groups.get(k).set(sub,[]);groups.get(k).get(sub).push(c);visible.push(c);}for(const m of groups.values())for(const l of m.values())l.sort((a,b)=>normalize(a.name).localeCompare(normalize(b.name)));return{groups,visible,duplicates,orphanCount:0,totalInput:(commands||[]).length};}\nfunction chunk(a,n=35){const o=[];for(let i=0;i<a.length;i+=n)o.push(a.slice(i,i+n));return o;}\nfunction item(c,p){const scope=c.groupOnly?' [GRUPO]':c.privateOnly?' [PV]':'';return `👻 • ${p}${c.name}${scope}${c.description?` — ${c.description}`:''}`;}\nfunction section(def,p,cmds,page,total,ler=''){return [`╭─${def.close} ${def.title} ${def.close}─${ler}`,...(total>1?[`👻 • Página ${page}/${total}`]:[]),'👻',...cmds.map(c=>item(c,p)),'👻',`╰─「 do além ${def.close} 」─`].join('\\n');}\nexport function buildCatalogMenu(prefix='×',category=null,options={}){const org=organizeCommands(listCommands({includeHidden:true}),options),requested=normalize(category),ler=String(options.lerMaisText||'');if(requested){const key=CATEGORY_ALIASES[requested]||requested,def=MENU_STRUCTURE[key];if(!def)return `╭─⛧ CATEGORIA NÃO ENCONTRADA ⛧─\\n👻 • Use ${prefix}menu para voltar.\\n╰─「 do além ⛧ 」─`;const cmds=[...(org.groups.get(key)?.values()||[])].flat(),pages=chunk(cmds);if(!pages.length)return `╭─${def.close} ${def.title} ${def.close}─${ler}\\n👻\\n👻 • Nenhum comando disponível para seu nível de acesso.\\n👻\\n╰─「 do além ${def.close} 」─`;return pages.map((pg,i)=>section(def,p,pg,i+1,pages.length,ler)).join('\\n\\n');}\nconst role=Number(options.permission??10),sections=Object.entries(MENU_STRUCTURE).filter(([k])=>k==='dono'?role>=80:[...(org.groups.get(k)?.values()||[])].some(l=>l.length));const out=[menuHeader('Fantasminha','Usuário','MENU PRINCIPAL'),'','🔮 *FANTASMINHA — MENU PRINCIPAL*',`🔐 Acesso: *${ROLE_LABEL.get(role)||'Membro'}*`,'','Escolha uma área:',''];for(const [k,d] of sections){const count=[...(org.groups.get(k)?.values()||[])].reduce((n,l)=>n+l.length,0);out.push(`╭─${d.close} ${d.title} ${d.close}─`,`👻 • ${prefix}menu ${k}`,`👻 • ${count} comandos`,`╰─「 ${k==='premium'?'premium':'do além'} ${d.close} 」─`,'');}out.push(`${MENU_THEME.itemIcon}${prefix}buscar <termo>`,`${MENU_THEME.itemIcon}${prefix}ajuda <comando>`,'',menuFooter(`Catálogo único • aliases não são exibidos • ${org.visible.length} comandos canônicos acessíveis`));return out.join('\\n');}\nexport function getCategoryMeta(category){const key=CATEGORY_ALIASES[normalize(category)]||normalize(category);return MENU_STRUCTURE[key]||null;}\n''')
# remove orphan catalog JSON
cc=ROOT/'dados/src/menus/commandCatalog.json'; cc.unlink(missing_ok=True)
# remove old menu imports that are now unused from menus/index dynamic; index destructuring only menu/menuPremium, fine.
# Add tests.
test=ROOT/'tests/menu-consolidation-v11_7_05.mjs'
test.write_text("""import assert from 'node:assert/strict';\nimport fs from 'node:fs';\nimport { MENU_STRUCTURE, organizeCommands, buildCatalogMenu } from '../dados/src/menus/catalogMenu.js';\nconst idx=fs.readFileSync('dados/src/index.js','utf8');\nassert.equal((idx.match(/sendMenuWithMedia/g)||[]).length,0,'sendMenuWithMedia ainda existe');\nassert.equal((idx.match(/^      case ['\"]menu['\"]:/gm)||[]).length,1,'deve existir um case menu');\nassert.equal(fs.existsSync('dados/src/menus/commandCatalog.json'),false,'commandCatalog.json deveria ter sido removido');\nassert.equal(Object.keys(MENU_STRUCTURE).length,10,'MENU_STRUCTURE deve ter 10 submenus');\nfor(const k of ['social','jogos','rpg','bn','ferramentas','grupo','adm','dono','sistema','premium']) assert.ok(MENU_STRUCTURE[k]);\nconst sample=[{name:'sticker',category:'figurinhas',permission:10},{name:'sticker2',category:'figurinhas',permission:10},{name:'pet',category:'pets',permission:10},{name:'licenca',category:'licenca',permission:60},{name:'vip',category:'premium',permission:40},{name:'ownerx',category:'dono',permission:100}];\nconst o=organizeCommands(sample,{permission:100});\nassert.equal(o.duplicates.length,0); assert.equal(o.orphanCount,0);\nassert.equal(new Set(o.visible.map(x=>x.name)).size,o.visible.length);\nconst root=buildCatalogMenu('×',null,{permission:100});\nfor(const k of Object.keys(MENU_STRUCTURE)) assert.match(root,new RegExp(`menu ${k.replace('-', '\\-')}`));\nconsole.log(`MENU CONSOLIDATION OK — ${Object.keys(MENU_STRUCTURE).length} submenus; único portal; sem sendMenuWithMedia; sem commandCatalog.json.`);\n""")
print('legacy definitions',len(merged),'represented labels',sum(1+len(x['aliases']) for x in merged.values()))
