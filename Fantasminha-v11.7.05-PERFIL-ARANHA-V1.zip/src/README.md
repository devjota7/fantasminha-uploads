# 👻 Fantasminha Bot

**Versão atual:** 11.7.05  
**Release:** `v11.7.05-final`  
**Node mínimo:** `>=20.9.0`

O Fantasminha é um bot modular para automação de grupos, jogos, triagem,
assistência, ranking e sistemas de plataforma. A arquitetura prioriza
persistência, isolamento por grupo, auditoria, idempotência, recuperação e
compatibilidade com recursos existentes.

## 📌 Fonte oficial da versão

A versão publicada deve possuir um `latest.json` junto dos artefatos da release.
Esse arquivo é o manifesto operacional usado pelo atualizador para descobrir a
versão, ZIP, SHA-256, tamanho, compatibilidade e regras de atualização.

**Importante:** o `latest.json` da release é publicado ao lado do ZIP em
`release-out/` e no repositório GitHub. Ele não é colocado dentro do próprio ZIP,
porque o SHA-256 do ZIP não pode ser simultaneamente calculado sobre um arquivo
que contém o próprio SHA exato.

## 📚 Documentação de atualidade

- `CHANGELOG.md` — histórico acumulado das versões e mudanças.
- `RELEASE-NOTES-V11.7.05.txt` — notas específicas da release atual.
- `REGRAS-OBRIGATORIAS-FANTASMINHA.txt` — regras permanentes de arquitetura,
  segurança, atualização e compatibilidade.
- `release-out/latest.json` — manifesto da release construída.
- `release-out/release-manifest.json` — manifesto técnico com integridade e
  arquivos obrigatórios.

## 🔄 Regra permanente de documentação e release

Toda atualização do Fantasminha deve, obrigatoriamente:

1. atualizar a documentação correspondente ao comportamento real;
2. atualizar o `CHANGELOG.md` com a versão atual;
3. atualizar as release notes quando houver mudança relevante;
4. manter as regras permanentes em `REGRAS-OBRIGATORIAS-FANTASMINHA.txt`;
5. gerar um novo `latest.json` compatível com a versão publicada;
6. recalcular o SHA-256 e o tamanho do ZIP real;
7. não reutilizar SHA, nome de ZIP ou manifesto de outra versão;
8. validar o ZIP e os arquivos obrigatórios antes da publicação;
9. preservar `.env`, autenticação, sessão, banco, mídias, logs e demais dados
   locais protegidos;
10. somente considerar a release pronta depois das validações aplicáveis.

## 🛡️ Segurança de atualização

O atualizador valida a versão, o SHA-256, o tamanho quando informado, os
arquivos obrigatórios e a estrutura do ZIP antes de aplicar uma atualização.
O fluxo de atualização possui backup validado, rollback em falha e proteção
contra substituição destrutiva de dados locais.

Nenhuma release deve conter credenciais reais, tokens, senhas, sessão do
WhatsApp ou `.env` real.

## 🧩 Princípios de arquitetura

- Registry como fonte de verdade dos comandos.
- Aliases apontam para comandos canônicos e não são tratados como comandos
  independentes.
- Prefixo efetivo: grupo → global.
- Dados contextualizados devem respeitar `groupId`/organização.
- Operações críticas devem ser idempotentes quando houver possibilidade de
  retry.
- Estado persistente deve sobreviver a reinício quando necessário.
- Auditoria deve registrar operações relevantes.
- Não criar sistemas paralelos quando já existir um engine central.
- Não usar mock ou placeholder permanente como funcionalidade de produção.
- Não declarar recurso concluído sem implementação real e teste compatível.
