# Fantasminha 11.7.05 — Catálogo Oficial de Jogos

A limpeza reduz duplicações e separa jogo real de engine, ação auxiliar e ferramenta interna.

## Jogos principais

1. STOP / Adedonha — `×stop`
2. Forca — `×forca`
3. Quiz — `×quiz`
4. Memória — `×memoria`
5. Wordle — `×wordle`
6. Anagrama — `×anagrama`
7. Caça-Palavras — `×cacapalavras`
8. Batalha Naval — `×batalhanaval`
9. Digitação — `×digitar`
10. Jogo da Velha / TTT — `×ttt`
11. Connect 4 — `×connect4`
12. UNO — `×uno`
13. Batalha — `×batalha`
14. Torneio — `×torneio`
15. Forca do Além — `×forcaalem`
16. Quiz do Além — `×quizalem`
17. Batalha das Almas — `×batalhaalmas`
18. Memória Fantasma — `×memoriafantasma`
19. Juiz Final — `×juizfinal`
20. Torre do Limbo — `×torrelimbo`
21. Memória dos Copos — `×memoriacopos`
22. Gartic — `×gartic`

## Mini-games

23. Cara ou Coroa — `×caraoucoroa`
24. Pedra, Papel e Tesoura — `×jokenpo`
25. Maior ou Menor — `×maioroumenor`
26. Batalha de Emojis — `×dueloemoji`
27. Sequência — `×sequencia`
28. Verdadeiro ou Falso — `×verdadeirofalso`
29. Roleta de Emojis — `×roletaemoji`

## Não são jogos independentes

- Engines internas
- Ranking/placar
- Aceitar/recusar batalha
- Encerrar Juiz
- Anagrama da Alma
- Caça-Alma
- Memória Flash
- Anagrama rápido/embaralhamento
- Palavra/Número aleatório
- Desafio aleatório
- Jogo dos Números
- Campo Minado, Enigma, Matemática e Quem Sou Eu, retirados do catálogo oficial desta versão

## Regra de catálogo

Um modo especial deve viver dentro do jogo correspondente quando for apenas uma variação temática ou mecânica, em vez de criar outro jogo duplicado.
