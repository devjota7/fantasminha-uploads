# Torre do Limbo V2

Reforma integrada ao Fantasminha 11.7.05.

- 500 andares possíveis.
- Geração procedural por tentativa/jogador.
- Tipos: normal, desafio, perigoso, recompensa e Fantasma.
- 50+ eventos narrativos e 50+ perguntas; palavras, sequências, memória e reações são geradas/variadas proceduralmente.
- Histórico e persistência de sessão.
- Antirrepetição por histórico da tentativa.
- Primeiro token da mensagem do jogador é a resposta.
- Mensagens de outros jogadores não interferem.
- `sair` encerra a tentativa.
- Cronômetro opcional, nunca abaixo de 5 segundos.
- Edição progressiva de mensagens quando o transporte do WhatsApp suporta `edit`.
- Timeout e respostas atrasadas são protegidos por `challengeId`/estado.
- Pontuação consolidada no `statsEngine` ao final da tentativa.
- O comando público continua sendo apenas `×torrelimbo`.
