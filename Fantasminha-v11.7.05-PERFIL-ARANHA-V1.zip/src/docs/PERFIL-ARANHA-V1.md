# 🕷️ Perfil Aranha — Fantasminha 11.7.05

O Perfil Aranha é uma camada exclusiva sobre o perfil oficial do Fantasminha.

## Comandos

### Usuário autorizado
- `×perfilaranha` — renderiza o perfil dinâmico em uma teia visual.
- `×menuaranha` — central privada da Sessão Aranha.

### Dono
- `×aranhaadd @pessoa` — ativa a Sessão Aranha.
- `×aranharemove @pessoa` — desativa a sessão sem apagar o perfil oficial.
- `×aranhastatus @pessoa` — consulta o estado da sessão.
- `×aranhaadmin` — painel administrativo.

Os comandos administrativos são registrados na categoria `dono`, portanto aparecem no `menudono` dinâmico.

## Fonte dos dados

Nome, nick, nascimento, patente, rastro e vozes vêm do mesmo serviço usado pelo `×perfil`. O módulo não cria uma segunda identidade.

As estatísticas de jogos são lidas do `stats_engine` existente. Dados exclusivos da sessão ficam em `spider_profile`.

## Renderização

O perfil é construído em SVG e convertido para PNG pelo Sharp. A teia é desenhada estruturalmente, e os textos, números, barras e níveis são preenchidos em cada renderização.

Não existe imagem PNG estática com números gravados.

## Segurança

A sessão é vinculada ao identificador real da conta. Usuários comuns só podem abrir a própria sessão autorizada. O dono pode administrar e visualizar perfis autorizados.

A desativação da sessão não remove o `×perfil` oficial nem seus dados.
