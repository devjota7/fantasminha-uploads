import { menuHeader, menuFooter } from './theme.js';
export default async function menu(prefix='×', botName='Fantasminha', userName='Usuário') {
  return [menuHeader(botName,userName,'CENTRAL DO ALÉM'),'','🌑 PORTAIS',
    `${prefix}alem  ${prefix}jogos  ${prefix}economia  ${prefix}rpg`,
    `${prefix}perfil  ${prefix}personalidade  ${prefix}afk`,
    `${prefix}comunidade  ${prefix}triagem`,
    '', '🎮 DIVERSÃO',
    `${prefix}quiz  ${prefix}stop  ${prefix}wordle  ${prefix}jokenpo`,
    '', '👥 SOCIAL',
    `${prefix}addbestfriend  ${prefix}rmvbestfriend  ${prefix}todos`,
    '', '🛠️ UTILIDADES',
    `${prefix}ajuda  ${prefix}buscar  ${prefix}status`,
    '', '👑 ADMIN',
    `${prefix}menuadm  ${prefix}menudono`,
    '', menuFooter(`Use ${prefix}ajuda <comando> para detalhes.`)].join('\n');
}
