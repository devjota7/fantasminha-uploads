import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { addBestFriend, removeBestFriend, setAfk, clearAfk, findAfk, personality } from '../../services/social.js';
import { mentionAll } from '../../services/mentionManager.js';
import { resolveUserIdentity } from '../../platform/identity/resolver.js';
import { on, Events } from '../../events/index.js';

const tag = s => `👻 *FANTASMINHA — ALÉM SOCIAL*\n\n${s}`;
const targetArg = ctx => ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || null;
let listenerInstalled = false;

export async function register() {
  registerCommand({name:'addbestfriend',aliases:['addbf','melhoramigo'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:3,description:'Adiciona uma pessoa como Best Friend no seu perfil.',usage:'×addbestfriend @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); if(!t) throw new ValidationError('Mencione a pessoa ou responda à mensagem dela.');
    const r=await addBestFriend(ctx,t); const j=r.person.realJid;
    return ctx.reply(tag(r.changed?`🫂 *BEST FRIEND ADICIONADO*\n\n👤 @${j.split('@')[0]}\n✨ Seu perfil foi atualizado.`:`🫂 Essa pessoa já é seu Best Friend.`),{mentions:[j]});
  }});
  registerCommand({name:'rmvbestfriend',aliases:['rmbf','removerbestfriend'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:3,description:'Remove um Best Friend do seu perfil.',usage:'×rmvbestfriend @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); if(!t) throw new ValidationError('Mencione a pessoa ou responda à mensagem dela.');
    const r=await removeBestFriend(ctx,t); const j=r.person.realJid;
    return ctx.reply(tag(r.changed?`🕯️ *BEST FRIEND REMOVIDO*\n\n👤 @${j.split('@')[0]}\nO vínculo saiu da sua ficha.`:`🕯️ Essa pessoa não está como seu Best Friend.`),{mentions:[j]});
  }});
  registerCommand({name:'todos',aliases:['t'],category:'comunidade',plugin:'social',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:8,description:'Envia seu texto mencionando todos os participantes do grupo.',usage:'×todos <texto>',handler:async ctx=>{
    const text=String(ctx.q||'').trim(); if(!text) throw new ValidationError('Use ×todos <mensagem>.');
    const payload=await mentionAll(ctx,text,{excludeBot:true});
    return ctx.reply(payload.text,{mentions:payload.mentions});
  }});
  registerCommand({name:'personalidade',aliases:['pers','analisepessoa'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:5,description:'Gera uma análise espiritual aleatória, apenas recreativa.',usage:'×personalidade @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); const person=await resolveUserIdentity(ctx,t||ctx.sender); const j=person.realJid || ctx.sender; const p=personality(person.name||ctx.pushname||'Pessoa',j);
    const body=`✨ *ANÁLISE ESPIRITUAL DE @${j.split('@')[0]}* ✨\n\n↳ 🏛️ Aparência espiritual: ${p.aparencia}\n↳ 🏋️ Hobby provável: ${p.hobby}\n↳ 🎭 Profissão ideal: ${p.profissao}\n↳ ⏰ Horário favorito: ${p.horario}\n↳ 🎵 Trilha sonora: ${p.musica}\n↳ 🌡️ Clima ideal: ${p.clima}\n↳ ♑ Signo espiritual: ${p.signo}\n↳ 🦈 Animal interior: ${p.animal}\n↳ 👻 Qualidade marcante: ${p.qualidade}\n↳ 🌀 Defeito provável: ${p.defeito}\n↳ ⚡ Energia: ${p.energia}\n↳ 🪦 Profissão no Além: ${p.profissaoAlem}\n↳ 🪄 Superpoder inútil: ${p.poder}\n↳ 🚔 Motivo pelo qual seria preso no Além: ${p.preso}\n↳ 🎁 Talento secreto: ${p.talento}\n↳ 💬 Frase que representa: ${p.frase}\n\n🔮 _Brincadeira recreativa. A precisão foi espiritualmente questionável._`;
    return ctx.reply(tag(body),{mentions:[j]});
  }});
  registerCommand({name:'afk',aliases:['ausente'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:3,description:'Ativa ou remove seu modo AFK.',usage:'×afk [motivo] | ×afk off',handler:async ctx=>{
    if(['off','sair','voltar','disable','desativar'].includes(String(ctx.args?.[0]||'').toLowerCase())) { const r=await clearAfk(ctx); return ctx.reply(tag(r?`🕯️ *DE VOLTA AO MUNDO DOS VIVOS*\n\n👻 ${r.name}, o Véu foi reaberto.`:`👻 Você não estava em AFK.`)); }
    const r=await setAfk(ctx,ctx.q); return ctx.reply(tag(`🌑 *MODO ALÉM ATIVADO*\n\n👤 ${r.name}\n🕯️ Motivo: *${r.reason}*\n⏳ Desde: *${new Date(r.since).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}*\n\nQuem te marcar pode receber uma mensagem do Além. 💀`));
  }});

  if (listenerInstalled) return;
  listenerInstalled = true;
  on(Events.MESSAGE, async ctx=>{
    if(!ctx?.isGroup || !ctx.mentioned?.length || !ctx.body || String(ctx.body).trim().startsWith(ctx.prefix||'×')) return;
    for(const target of ctx.mentioned.slice(0,3)) {
      try { const hit=await findAfk(ctx,target); if(!hit) continue; const j=hit.person.realJid; await ctx.reply(tag(`💀 *O espírito de @${j.split('@')[0]} não está aqui.*\n🕯️ ${hit.record.reason}\n⏳ Desde ${new Date(hit.record.since).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit'})}.`),{mentions:[j]}); } catch {}
    }
  });
}
export default {register};
