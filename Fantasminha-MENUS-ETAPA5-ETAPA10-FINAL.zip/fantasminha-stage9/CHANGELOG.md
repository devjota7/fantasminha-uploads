## Triagem 2.0 — Fases 2 e 3 (próxima versão)

- Fase 2: conectar grupos (julgamento compartilhado com aviso, destinos de aprovados, mapa e saúde da conexão); aprovar adiciona a pessoa nos destinos, com link de convite no PV quando o WhatsApp recusa e `×triagemaprovar #n repetir`; `×triagemcobrar` (volta ao Registry; ID novo, confirmação, lotes e teto por hora); restrição do pendente com liberação automática; aprovado que volta (ficha anterior preservada); sinais entre grupos só para o dono.
- Fase 3: estatísticas por período e exportação CSV; manutenção diária com alertas (fila parada, falhas de PV, grupo desconectado, retenção); histórico de configuração com restauração; modelos de perguntas da rede; retenção opcional (só avisa); aviso automático de reprovação ao dono (desligado por padrão).
- Privacidade: aviso no PV, membro e admin NÃO apagam fichas (nem a própria), só o dono, com confirmação e registro; política de fotos configurável (padrão: guardar).
- Um gancho novo no `connect.js` (`startTriagemMaintenance`, ao abrir a conexão), isolado em try/catch.
- Testes: `tests/triagem-fase2-3.test.mjs` (incluído em `npm run test:triagem`).

## Triagem 2.0 — Fase 1 (próxima versão)

- A Triagem 2.0 é um **redesenho** (nada da Triagem 1.0 / 11.7.11 foi reaproveitado) e vive somente em `src/modules/triagem/`.
- Política: a regra 2 foi reescrita; `triagem` e `triagemficha` saíram de `REMOVED_COMMANDS`. Os demais nomes da 1.0 continuam removidos (inclusive `triagemcobrar`, reservado à Fase 2).
- Comandos novos: `×triagem` (painel), `×triagemficha`, `×triagemaprovar`, `×triagemreprovar`, `×triagemobs` (admin) e `×triagemdono` (dono, somente leitura). Estão em ADM > Triagem de entrada e em DONO > Triagem.
- Desligada por padrão: nada acontece até um admin ativar no painel. Interruptor de emergência global do dono.
- O bot só coleta e sinaliza; o admin decide; o dono só analisa.
- Interruptor global: `TRIAGEM_ENABLED` (padrão `false`). Sem `true`, o gancho de entrada, o PV e os 6 comandos ficam inertes; `TRIAGEM_DISABLED=true` e o desligar-tudo do dono continuam valendo.
- Release: `data/triagem-media` (fotos) excluída do ZIP (`build-release`, `validate-release`, `.gitignore`).
- Blacklist: a Triagem apenas CONSULTA a blacklist existente (adapter somente-leitura em `src/legacy/adapters/blacklistReader.js`); nunca escreve nela.
- Sinais de apoio por grupo; cruzamento entre grupos visível só ao dono.
- Ganchos: entrada de membro (`connect.js`, inclusive pós-captcha), pipeline (`handleTriagemInput`) e gate de PV antipv (`isTriagemPrivateFlow`).
- Testes: `npm run test:triagem` (também em `npm test`).

## 2.0.1 (correções)

- FIX-01: papel do ator do Chat Bridge passou a vir da configuração.
- FIX-02: comandos hard-blocked e owner-only destrutivos foram bloqueados no Bridge.
- FIX-03: denylist passou a classificar nomes/aliases, não argumentos.
- FIX-04: modo real passou pela mesma policy de segurança.
- FIX-05: texto livre não aceita `$`/`>>` como meta-comandos.
- FIX-06: simulação exige banco sandbox ou override explícito para efeitos persistentes.
- FIX-07: rate limit passou a ser por identidade do token.
- FIX-08: Bridge respeita prefixo efetivo do grupo.
- FIX-09: campos controlados pelo cliente passaram por validação/sanitização.
- FIX-10: prefixo global fixado em `×`.
- FIX-11: fallbacks de prefixo inconsistentes foram corrigidos.
- FIX-12: downloads por URL receberam validação anti-SSRF e redirects revalidados.
- FIX-13: auditorias de colisões de aliases e `case` foram adicionadas.
- FIX-14: comandos críticos dos 125 pendentes foram revisados, corrigindo apenas defeitos demonstráveis.
- FIX-15: unit systemd passou a usar usuário dedicado e hardening.
- FIX-16: documentação de clãs foi corrigida para refletir bloqueio por política.
- FIX-17: `perfilnome` permanece removido.
- FIX-18: `dbbackup` permanece desativado e aponta para o backup do deploy.

## Chat Bridge v2 + instalação na VPS (finalização)

- Chat Bridge: texto livre (sem prefixo) passa a ser aceito sem confirmação e sem a denylist; comandos continuam protegidos (denylist, fail-closed e confirmação).
- `deploy/vps/install-vps.sh`: não chama mais o script inexistente `audit:legacy-reachability`; backup inclui `dados/database` (sessão do WhatsApp) e `dados/src/config.json`; acrescenta `WEB_AUTH_COOKIE_SECURE=true` quando falta em produção; `FANTASMINHA_SKIP_TESTS=1` pula a certificação; o `ReadWritePaths` do systemd é reescrito por completo.
- Novo `deploy/vps/restaurar-dados.sh`: restaura somente `.env`, `data/`, `dados/database/`, `dados/src/config.json` e `dados/midias/` de um `.tgz` (valida caminhos, ignora links, `--dry-run`, `--force` com cópia prévia).
- Novo `deploy/vps/chat-bridge.sh` (on/off/status/token) e guia `docs/DEPLOY-VPS-RECUPERACAO.md`.
- Chat Bridge: porta ocupada (`EADDRINUSE`) não derruba mais o bot — o erro é registrado e o bot segue sem o bridge (teste `chat-bridge-port-busy`).
- `restaurar-dados.sh`: `tar --no-recursion` com a lista de arquivos (com um backup feito pelo `tar` de verdade o script abortava com "Not found in archive"); novo teste `vps-restore-script` (`npm run test:vps-restore`).
- `.env.example` ganhou `WEB_AUTH_COOKIE_SECURE=true`; novos scripts npm `restore:vps`, `bridge:vps` e `test:chat-bridge-freetext`.

## Menus — etapas 4–5 concluídas

- Usage agora respeita o prefixo efetivo e limita variantes; os 141 comandos técnicos reais foram catalogados no `menudono` sem vazar para membros/adms.
- Entradas legadas verificadas (`gerarnick`, `roleta`, `slots`, `apostar`, `loteria`, `corrida`, `petbet`) tornaram-se virtuais e não registram handlers duplicados; conteúdo adulto/suicídio foi deliberadamente excluído.
- Portados como plugins nativos: `blackjack` (ledger de economia existente) e `voltei` (serviço AFK existente); `likeff`/`infoff` ficaram documentados como dependências externas ausentes.
- Novos testes cobrem usage, visibilidade técnica, entradas legadas, ports e duplicidade física no mapa.

## Menus — reorganização por assunto (etapas 1–3)

- `dados/src/menus/menuMap.js` (novo): mapa de menus e seções; cada comando aparece em um menu e uma seção.
- `catalogMenu.js` lê o mapa primeiro; comando fora do mapa cai em "Outros" do menu temático. Chave `bn` = Brincadeiras, `ia` = IA.
- Ferramentas dividida em Downloads, Figurinhas, Logos, Edits, Alteradores, Ferramentas (utilidades) e o novo Além; Brincadeiras só no `menubn`.
- Menu principal: card + botão nativo (19 menus) + lista escrita de todos os menus; `menudono`/`menuadm` só aparecem para quem tem acesso.
- Removido o comando quebrado `viaja nte` (`viajante` continua).
- Testes: `tests/menus-map.test.mjs` e `tests/menus-registry-coverage.test.mjs` (falham se um comando estiver em 2 menus ou em nenhum); testes antigos de menu ajustados à nova estrutura.

# Changelog — Fantasminha 2.0.0

- Consolidação da fundação 2.0 e Registry.
- Loader declarativo de comandos e catálogo runtime.
- Menus derivados do Registry, com navegação compacta.
- Triagem removida do produto e do catálogo público.
- Clãs/guerras legados removidos fisicamente e do bootstrap.
- Memória dos Copos preservada como jogo ativo.
- Hardening de dependências opcionais com lazy-load onde apropriado.
- Deploy VPS com backup, preflight, certificação e systemd.
