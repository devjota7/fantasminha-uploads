# RELATÓRIO — CHAT BRIDGE v2

## Resultado
A implementação do lado do bot foi adicionada atrás de `CHAT_BRIDGE_ENABLED`, desligado por padrão. O caminho normal do WhatsApp não foi substituído; o bridge recebe uma instância virtual separada quando usado em simulação.

## Arquivos principais
- `src/platform/chatbridge/server.js`
- `src/platform/chatbridge/auth.js`
- `src/platform/chatbridge/config.js`
- `src/platform/chatbridge/health.js`
- `src/platform/chatbridge/virtualSocket.js`
- `src/platform/chatbridge/messageFactory.js`
- `src/platform/chatbridge/capture.js`
- `src/platform/chatbridge/denylist.js`
- `src/platform/chatbridge/catalog.js`
- `tests/chat-bridge-*.test.mjs`
- `docs/CHAT-BRIDGE.md`

## Evidência de execução
`npm run test:syntax` — PASS: 705 arquivos JS/MJS.

`npm test` — PASS:
- sintaxe;
- `FANTASMINHA 2.0 CERTIFICATION OK`;
- `DB ROOT SEAM: PASS`.

Testes específicos do bridge — PASS:
- core/captura;
- servidor/contrato;
- segurança;
- interação/eventos.

## Segurança
A simulação não encaminha `sendMessage`, `react`, `relayMessage` ou mutadores de grupo ao socket real. A denylist é fixa e não depende de `ALLOW_OWNER_SHELL`/`ALLOW_OWNER_EVAL`.

## Banco
O projeto permite `FANTASMINHA_DB_ROOT` **antes da importação** e o seam foi aprovado. Não foi implementada uma falsa troca de raiz em runtime. A simulação sem raiz externa pode escrever no banco do processo e avisa isso na resposta.

## Catálogo
O código usa o Registry e `LEGACY_UNREGISTERED` do `menuMap`. Em um processo sem bootstrap do Registry, a evidência local retornou `registry=0`, `legacy=7` e 1468 nomes do menuMap sem handler catalogável; esses nomes não foram inventados. Após bootstrap produtivo, o catálogo deverá ser medido novamente.

## Divergência encontrada
O arquivo `bot-side/chatEndpoint.js` citado pelo escopo não existe no ZIP recebido. A compatibilidade v1 foi implementada diretamente no servidor v2. A reutilização literal desse módulo ficou **NÃO EXECUTADA**.

## Dependências / integração real
Foi tentado `npm ci --ignore-scripts --no-audit --no-fund`, mas a instalação excedeu o limite do ambiente e foi interrompida. Por isso, qualquer teste que dependa de Baileys autenticado ou de toda a árvore de dependências está **NÃO EXECUTADO**.

## Próximos passos
1. instalar dependências integralmente no ambiente de execução;
2. iniciar o bot com `CHAT_BRIDGE_ENABLED=true` e token seguro;
3. executar `×menu` e `×perfil` via `/v2/chat/send` e comparar com o WhatsApp real;
4. validar comandos destrutivos e interações reais;
5. se isolamento de banco for obrigatório, iniciar um processo sandbox com `FANTASMINHA_DB_ROOT` definido antes dos imports.
