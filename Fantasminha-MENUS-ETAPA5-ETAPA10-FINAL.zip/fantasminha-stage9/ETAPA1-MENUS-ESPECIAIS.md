# Etapa 1 — Menus Especiais

## Objetivo
Criar somente a estrutura dos cinco menus especiais, inicialmente vazios, sem criar comandos de benefício e sem atualizar o menu principal nesta etapa.

## Menus criados
- `×menudono` — abertura: Dono Principal + Co-Dono
- `×menuaranha` — abertura: Dono Principal + Co-Dono + Aranha
- `×menuvip` — abertura: Dono Principal + Co-Dono + VIP
- `×menusubdono` — abertura: Dono Principal + Co-Dono + Subdono
- `×menusuporte` — abertura: Dono Principal + Co-Dono + Suporte

## Regras
- Os menus são navegação, não concessão de autoridade.
- `permission: USER` é intencional; a abertura é protegida por `specialRoles` no Registry.
- Nenhum comando de benefício foi criado nesta etapa.
- `×menuadm` não foi alterado.
- `×menu` e seus botões/lista não foram alterados nesta etapa.
- O menu antigo da Aranha foi removido do plugin da Aranha e substituído pelo menu vazio centralizado.
- `×perfilaranha` continua existente; nenhum novo `×aranhaperfil` foi criado.

## Validação
- `tests/menus-especiais-etapa1.test.mjs`: PASS
- Sintaxe dos 3 arquivos alterados: PASS
- Cada um dos 5 menus possui um único registro central: PASS
- Registro antigo de `menuaranha` no plugin da Aranha: removido

## Próxima etapa
Etapa 2: criação dos quatro comandos de estatísticas e definição de suas autorizações, sem ainda implementar benefícios novos.
