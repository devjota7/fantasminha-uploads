# MIGRATION.md

**Fase atual:** Wallet parcial, aditiva e desativada publicamente. O legado não foi removido.

## Checklist por módulo

| Item | Regressão | Módulo novo | Adapter | Legado removido | Commit |
|------|-----------|-------------|---------|-----------------|--------|
| Wallet | PASS — defaults e taxas legacy comparados por `test:wallet-legacy-regression`; runtime usa DB temporário | PASS parcial — saque/transferência Fees integrados; comandos públicos desativados | PASS — reader read-only transacional, idempotência e ledger em `fee.saque`/`fee.transferencia` | BLOCKED — pendente de validação humana; bancos legado/moderno separados | — |
| Clan | pré-existente fora desta execução | pré-existente fora desta execução | — | BLOCKED — não remover | — |
| Dungeon | — | — | — | BLOCKED — fora do escopo | — |
| Masmorra Solo | — | — | — | BLOCKED — fora do escopo | — |
| Perfil | — | — | — | BLOCKED — fora do escopo | — |
| Economia | PASS parcial — tabela legacy × Fees e três getters síncronos comparados | PASS parcial — política em `src/modules/economy/fees/`; `fee.mercado` não é espelhada no ledger moderno | PASS parcial — saque/transferência Wallet usam Fees; mercado permanece no armazenamento legado | BLOCKED — duas fontes de persistência e validação humana | — |

## Inventário de estado

**Comandos Wallet migrados:** nenhum comando público. `walletsaldo` existe somente como definição declarativa `enabled: false` para validar carregamento e boundaries.

**Comandos ainda legados:** economia continua em `dados/src/index.js`, `dados/src/connect.js`, `dados/src/funcs/` e nos plugins/bridges existentes. O Registry e seus plugins foram preservados.

**Testes criados nesta etapa:**

- `tests/architecture-boundaries.test.mjs`: fixtures e baseline monotônico.
- `tests/command-contract-run.test.mjs`: `run`, `handler`, `execute`, definição inválida e módulo temporário.
- `tests/extract-legacy-case.test.mjs`: fixture agrupada e fumaça real de `dados/src/index.js`.
- `tests/wallet-service.test.mjs`, `tests/wallet-concurrency.test.mjs`, `tests/wallet-fees-runtime.test.mjs`: fees, idempotência e concorrência em repos/DB temporários.
- `tests/wallet-legacy-regression.test.mjs`: tabela de defaults e inspeção dos cases pelo extrator, sem executar dispatcher.
- `tests/fees-service.test.mjs`, `tests/fees-command.test.mjs`: policy 0–100%, fallback, autorização do dono (`taxa`, `edittaxa`, `taxareset`) e visibilidade no menu do dono.
- `tests/economy-regression.test.mjs`: inventário estático; reporta BLOCKED sem escrever dados reais.

**Ferramentas criadas:** `scripts/extract-legacy-case.mjs` (somente leitura), `scripts/architecture-boundaries.baseline.json` e enforcement em `scripts/architecture-boundaries.mjs`.

**Comportamento conhecido:** o runtime aceita `handler` e agora adapta `run` sem impor uma API paralela. O loader descobre `.js` em `src/comandos/` e `.commands.js` em `src/modules/`, ignorando definições com `enabled: false`. Wallet usa o adapter moderno; o comando `taxa` é owner-only/oculto; os três cases legados leem a mesma política via getter síncrono com fallback default.

## Bugs achados no legado

1. **Corrida de saldo:** muitos cases fazem `loadEconomy() → mutação em memória → saveEconomy()` diretamente. Esse read-modify-write perde ganhos quando duas chamadas se entrelaçam. `mutateEconomy()` corrige somente os fluxos que o usam; os demais continuam vulneráveis.
2. **Lock limitado:** `withFileLock` do legado serializa chamadas dentro de um único processo Node; não protege múltiplas instâncias/processos apontando para `dados/database/economy.json`.
3. **Durabilidade menor:** `saveJsonFileSafe` faz temporário + rename, mas não faz `fsync` e `createBackup()` está desativado.
4. **Duas fontes de verdade:** `data/db/` e `dados/database/` têm schemas e caminhos distintos; unificá-los sem migração pode duplicar ou perder saldo.

## Bloqueios

- Execução funcional dos cases legados segue BLOCKED: o dispatcher grava na base `dados/database` fixa e não foi executado. A equivalência de fórmulas foi provada por extração estática e testes isolados; o getter não migra nem unifica persistência.
- A venda de mercado legada ainda não grava `fee.mercado` em `data/db/economy_ledger`; registrar essa taxa de forma atômica entre bancos exige uma etapa de persistência própria, fora da troca de fonte de percentual.
- `test:architecture-etapa26` já falhava na baseline por esperar Clãs removido enquanto o workspace traz uma implementação aditiva pré-existente; não foi apagada nesta execução.
- Imports de Baileys fora de `src/platform/` permanecem baseline conhecida (6 arquivos); não foram movidos.
- Não houve validação humana em produção; portanto nenhum comando público foi ativado e nada foi marcado como “Legado removido”.

## Ordem obrigatória da próxima migração

Após validação humana da Wallet em produção: **Perfil → Clã → Dungeon → Masmorra Solo**. Cada módulo deve repetir LEGADO → teste → módulo → comparação → adapter roteador → validação → remoção controlada.

- Mercado legado: exibição de taxa agora usa a taxa configurável vigente (`getFeeRateSync`) em vez de `econ.playerMarket.fee`.
- Percentuais exibidos por saque, transferência e mercado agora usam `formatFeePercent`, eliminando ruído de ponto flutuante sem alterar a cobrança.

- **Assets padrão** — `assets/defaults/` agora contém a foto padrão de perfil e a mídia padrão dos menus; `dados/midias/` continua sendo mídia local do dono e tem prioridade quando presente.
- **Brincadeiras/ppp** — criado o comando novo `×ppp` no módulo `src/modules/games/ppp/`, sem legado a remover.

## Correções pós-análise (pacote final)

- `.env.example` restaurado (tinha sumido); `test:update-safety` volta a passar as etapas 1–9.
- `validate-release` ignora `tests/` na checagem de imports; `release:build` volta a concluir.
- Novo `test:release-assets`: prova que `assets/defaults` entra na release e que `dados/midias`, `data/db` e `dados/database` ficam fora. Ver `docs/audit/correcoes-pos-analise.md`.
- `×ppp`: menção real também para usuários LID (`buildMention`); sem telefone resolvido menciona o JID `@lid` em vez de falhar ou escrever `@número` sem menção.
- Menu principal em carrossel (1 cartão por menu, Aranha incluída), com plano B em lista e texto e `MENU_PRINCIPAL_ESTILO=lista` para reverter. Ver `docs/audit/correcoes-pos-analise.md`.
