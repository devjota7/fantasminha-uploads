# CHECKPOINT — CHAT BRIDGE CORREÇÃO DOS 5 BUGS

Data da execução: 2026-10-04
Projeto: `Fantasminha-ChatBridge-v2-bot.zip`
Escopo: somente os 5 itens do mini prompt; caminho real do WhatsApp não foi refatorado. O Bridge continua protegido por `CHAT_BRIDGE_ENABLED=false` por padrão.

## 1) P0 — DM usa remetente errado

**Causa:** `chatJid()` usava o `chat.id` virtual no DM, e `createVirtualMessage()` deixava `participant` ausente.

**Correção:** em DM, `remoteJid` agora é `actorJid(actor)`; em grupo, o `remoteJid` continua sendo o JID do grupo e `participant` continua sendo o ator. `createInteractionMessage()` usa a mesma regra porque reaproveita `createVirtualMessage()`.

**Evidência executada:** `tests/chat-bridge-corrections.test.mjs` verificou:
- owner DM → `key.remoteJid === ownerJid`;
- member DM → JID fictício do member;
- grupo → `remoteJid` do grupo + `participant` do ator;
- interação DM → JID do ator.

**Resultado:** PASS — executado.

## 2) P0 — comando desconhecido/não classificado executava sem confirmação

**Causa:** `commandPolicy()` tratava `getCommand(name) === null` como `simulationSafe:false`, mas não retornava `requiresConfirmation`.

**Correção:** criada `SAFE_READONLY_ALLOWLIST` explícita. O Registry resolve aliases para o nome canônico antes da decisão. Qualquer comando desconhecido, legado ou não classificado fora da allowlist retorna `409 requiresConfirmation`; com `confirmSideEffects=true`, segue para o dispatcher existente.

Allowlist explícita atual:
- navegação: `menu`, `menus`, `menubn`, `menujogos`, `menuia`, `menugrupo`, `menurpg`, `menualem`, `menudown`, `ferramentas`, `menusistema`, `menuadm`, `menudono`, `menuvip`, `menuaranha`;
- leitura/perfil/ranking: `perfil`, `meustatus`, `perfilrpg`, `rank`, `ranking`, `rankjogos`, `ranklevel`, `ranklvl`, `rankgc`, `rankglobal`, `rankgads`, `rankpeques`;
- informação/ajuda/status: `ping`, `info`, `ajuda`, `regras`, `statusbot`, `statusgp`, `botstats`, `tempoativo`, `recursos`, `sobrebot`, `criador`, `dono`, `catalogo`, `comandos`, `cmdinfo`, `comandobusca`, `aliasinfo`, `aliasbusca`, `mapabot`, `guia`, `guiafantasminha`, `listaferramentas`, `conhecimento`.

**Evidência executada:**
- `×daily` → 409;
- `×comprar item` → 409;
- `×transferir 100` → 409;
- `×apostar 50` → 409;
- `×resetar` → 409;
- `×menu` → 200;
- `×perfil` → 200;
- alias `×p` → 200;
- `×daily` com `confirmSideEffects:true` → 200.

**Resultado:** PASS — executado.

## 3) P1 — denylist não cobria português

**Causa:** regex anterior cobria parcialmente `ban`, `kick`, `expuls`, etc., sem as formas portuguesas completas.

**Correção:** denylist ampliada para nomes canônicos e aliases, incluindo banir, expulsar, remover, silenciar/mutar, apagar, limpar, resetar, bloquear/desbloquear, promover/rebaixar, addadm/deladm/seradm, setdono, backup/restaurar, parar/desligar/reiniciar, atualizar/deploy/release/upgrade, nuke e operações de arquivo/DB.

Sem confirmação: `409 requiresConfirmation`.
Com `confirmSideEffects:true`: `403 blocked`.
Assim nenhum denylisted executa silenciosamente.

**Evidência executada:** o teste de correção enviou via HTTP cada nome da lista e aceitou somente `403` ou `409`. Todos retornaram `409` sem confirmação. Também foi mantido o teste `shell` com confirmação retornando `403`.

**Resultado:** PASS — executado.

## 4) P1 — Proxy thenable (`await virtualSocket` travava)

**Causa:** o `Proxy.get()` criava uma função para qualquer propriedade desconhecida, incluindo `then`.

**Correção:** `get` agora retorna `undefined` para `then`, `toJSON` e símbolos.

**Evidência executada:** `tests/chat-bridge-corrections.test.mjs` verificou `socket.then === undefined` e `await createVirtualSocket(...)` resolveu abaixo de 100 ms.

**Resultado:** PASS — executado.

## 5) P0 — capture perdia interactive/native-flow, botões/listas e poll

**Causa:** texto simples era testado antes de botões/listas/interactive; wrappers não eram desembrulhados; `nativeFlowMessage.buttonParamsJson` não era normalizado; poll lia `options` mas o bot usa `values`.

**Correção:**
- botões/listas/interactive são processados antes do texto simples;
- `viewOnceMessage`, `viewOnceMessageV2`, `viewOnceMessageV2Extension`, `ephemeralMessage` e `documentWithCaptionMessage` são desembrulhados;
- `quick_reply` → botão;
- `single_select` → lista;
- `cta_url`, `cta_copy`, `cta_call` → botão informativo com label + valor;
- carrossel preserva o corpo e, quando não há adaptação segura, retorna `unsupported` com `rawType:"carousel"`;
- header de imagem de `interactiveMessage` é emitido antes quando a mídia é capturável; quando não é, gera warning;
- poll aceita `values` e `options`, incluindo `optionName`.

**Payloads usados nos testes:**
- menu Native Flow `single_select` copiado da estrutura de `dados/src/menus/mainMenuNativeFlow.js`;
- `quick_reply` copiado de `dados/src/menus/mainMenuCatalog.js`;
- `cta_copy` copiado de `dados/src/index.js`;
- poll `values/selectableCount` copiado de `dados/src/index.js`;
- carrossel copiado da estrutura de `dados/src/menus/mainMenuCatalog.js`;
- wrapper `viewOnceMessageV2`;
- lista e botões foram validados pelos mesmos formatos de payload que o capture aceita; o código atual do bot não possui um `sendMessage({buttons/listMessage})` legado ativo separado do Native Flow.

**Resultado:** PASS — executado.

## Validação obrigatória

### `npm run test:syntax`

**PASS — executado.**

Saída:
```text
SYNTAX OK — 709 arquivos JS/MJS verificados com 8 workers.
```

### `npm test`

**PASS — executado.** Código de saída: `0`.

Saída relevante:
```text
FANTASMINHA 2.0 CERTIFICATION OK
DB ROOT SEAM: PASS — override anterior à importação; diretório temporário criado; fallback mantém config.root/data/db.
```

### 4 testes oficiais

**PASS — todos executados com código 0.**

```text
tests/chat-bridge-core.test.mjs
CHAT-BRIDGE CORE: PASS

tests/chat-bridge-interaction.test.mjs
CHAT-BRIDGE INTERACTION: PASS

tests/chat-bridge-security.test.mjs
CHAT-BRIDGE SECURITY: PASS

tests/chat-bridge-server.test.mjs
CHAT-BRIDGE SERVER: PASS
```

### Teste adicional dos 5 bugs

**PASS — executado.**

```text
CHAT-BRIDGE CORRECTIONS: PASS
```

Arquivo: `tests/chat-bridge-corrections.test.mjs`.

### `npm ci`

**NÃO EXECUTADO ATÉ O FIM / INCONCLUSIVO.**

Comando executado:
```bash
npm ci
```

A primeira execução terminou por `Container TransportTimeoutError`. Foi feita uma segunda tentativa em background para separar timeout do transporte de erro do npm; o processo `npm ci` ficou mais de 1 minuto sem produzir saída nem arquivo de término e foi encerrado manualmente para não deixar processo pendurado.

Não foi registrado PASS para `npm ci`.

### `tools/chatbridge-smoke.mjs`

**NÃO EXECUTADO.**

Motivo: a instalação completa das dependências por `npm ci` não concluiu neste ambiente. O script foi criado e está pronto para VPS/ambiente com dependências instaladas.

Comando destinado à execução:
```bash
FANTASMINHA_DB_ROOT=/caminho/para/banco-de-teste npm ci
FANTASMINHA_DB_ROOT=/caminho/para/banco-de-teste CHAT_BRIDGE_ENABLED=true CHAT_BRIDGE_TOKEN='TOKEN_DE_TESTE_COM_32+_CARACTERES' npm run test:chat-bridge-smoke
```

O script sobe `dados/src/connect.js`, espera `/health` e envia `×menu` e `×perfil` em DM e grupo como owner, imprimindo o JSON retornado.

### Cobertura Registry após bootstrap real

**NÃO EXECUTADO.**

Tentativa executada:
```bash
node scripts/generate-active-command-catalog.mjs
```

Saída:
```text
Error [ERR_MODULE_NOT_FOUND]: Cannot find package 'axios' imported from /tmp/cbwork/src/platform/http/client.js
```

Portanto não foi possível afirmar a cobertura após o bootstrap real do Registry.

Referência estática disponível no ZIP, sem substituir a validação exigida:
```text
menuMapUnique: 1475
legacyUnregistered: 7
navigation: 14
```

Também existe `docs/audit/command-inventory.json` com inventário anterior de 1523 comandos únicos, mas ele não é usado como evidência do bootstrap desta correção.

## Escopo do WhatsApp real

O caminho real de WhatsApp não foi refatorado. As alterações ficaram em identidade da mensagem virtual, policy/denylist, virtual socket e capture. O Bridge continua condicionado a `CHAT_BRIDGE_ENABLED=true`; por padrão permanece desligado.
