#!/usr/bin/env node
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';

const root = path.resolve(process.cwd());
const dbRoot = process.env.FANTASMINHA_DB_ROOT || fs.mkdtempSync(path.join(os.tmpdir(), 'fantasminha-chatbridge-db-'));
const port = Number(process.env.CHAT_BRIDGE_PORT || 30100);
const token = process.env.CHAT_BRIDGE_TOKEN || 'S'.repeat(40);
const env = {
  ...process.env,
  FANTASMINHA_DB_ROOT: dbRoot,
  CHAT_BRIDGE_ENABLED: 'true',
  CHAT_BRIDGE_TOKEN: token,
  CHAT_BRIDGE_PORT: String(port),
  CHAT_BRIDGE_ALLOW_REAL: 'false',
  NODE_ENV: 'test',
};

function request(pathname, body) {
  return new Promise((resolve, reject) => {
    const data = Buffer.from(JSON.stringify(body));
    const req = requireHttp.request({ host: '127.0.0.1', port, path: pathname, method: 'POST', headers: {
      authorization: `Bearer ${token}`, 'content-type': 'application/json', 'content-length': data.length
    }}, res => {
      const chunks = []; res.on('data', c => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(Buffer.concat(chunks).toString('utf8')) }));
    });
    req.on('error', reject); req.end(data);
  });
}

const requireHttp = await import('node:http');
const child = spawn(process.execPath, ['dados/src/connect.js'], { cwd: root, env, stdio: ['ignore', 'pipe', 'pipe'] });
let log = '';
child.stdout.on('data', c => { log += c.toString(); process.stdout.write(c); });
child.stderr.on('data', c => { log += c.toString(); process.stderr.write(c); });

async function waitHealth(timeoutMs = 120000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const result = await new Promise((resolve, reject) => {
        const req = requireHttp.request({ host: '127.0.0.1', port, path: '/health', method: 'GET' }, res => {
          const chunks = []; res.on('data', c => chunks.push(c)); res.on('end', () => resolve({ status: res.statusCode, body: JSON.parse(Buffer.concat(chunks).toString()) }));
        }); req.on('error', reject); req.end();
      });
      if (result.status === 200) return result;
    } catch {}
    await new Promise(r => setTimeout(r, 1000));
  }
  throw new Error(`Bridge não ficou disponível em ${timeoutMs}ms.`);
}

try {
  await waitHealth();
  for (const [label, chat] of [
    ['DM owner', { type: 'dm', id: 'virtual' }],
    ['group owner', { type: 'group', id: '120363000000000000@g.us' }]
  ]) {
    for (const text of ['×menu', '×perfil']) {
      const result = await request('/v2/chat/send', { text, mode: 'simulation', chat, actor: { role: 'owner', pushName: 'Smoke' } });
      console.log(`SMOKE ${label} ${text}: HTTP ${result.status}`);
      console.log(JSON.stringify(result.body, null, 2));
    }
  }
  console.log('SMOKE: EXECUTADO');
} finally {
  child.kill('SIGTERM');
  await new Promise(resolve => child.once('close', resolve));
}
