# MEGA701 — Etapa 4/10: integração de pets

## Resultado

Os comandos de pets do MEGA701 foram consolidados no plugin oficial `src/plugins/completeExpansion/index.js`, usando `petController` e `petEngine` já existentes. O plugin `src/plugins/mega701/index.js` deixou de registrar handlers e aliases de pets; continua responsável apenas pelas áreas ainda não migradas nesta etapa.

## Rotas oficiais

- `×pet` / `×meuspets` / `×meuspets701` / `×petlist`: lista os pets do usuário.
- `×adotapet` / `×adotarpet` / `×adotar`: adoção gratuita, preservando o comportamento oficial anterior.
- `×catalogopets` / `×lojapets` / `×petcatalogo`: catálogo comercial com preços.
- `×comprarpet` / `×adquirirpet`: compra pelo sistema oficial de economia, com validação de espécie e preço via `petController.acquire`.
- `×petespecies` / `×listapets`: lista de espécies; `listapets` não é mais o catálogo comercial.
- `×renomearpet` / `×petrenomear` / `×renamepet701`: renomeação.
- `×petalimentar` / `×alimentarpet`, `×petbrincar` / `×brincarpet`, `×pettreinar` / `×treinarpet`: ações pelo controller oficial.
- `×rankpets` / `×rankingpets` / `×petleaderboard`: ranking oficial por grupo, sem leitura direta duplicada da coleção.

## Integridade e permissões

- Não houve alteração de esquema nem remoção de dados.
- O armazenamento canônico continua sendo `pet_engine`, gerido por `petEngine`.
- A migração legada permanece não destrutiva: `users.pets`, `users.megaPets` e dados de pets em `economy.json` não são limpos nesta etapa.
- Os comandos são registrados com as permissões de usuário que já são o padrão da expansão oficial; o ranking permanece restrito a grupo como já estava.
- A compra passa pelo método oficial de economia e mantém a validação de saldo e limite de pets do serviço.

## Verificações executadas

- `node scripts/syntax-check.mjs` — OK, 805 arquivos JS/MJS verificados.
- `node tests/mega701-pets-stage4.test.mjs` — OK.
- `node tests/pet-storage-contract-stage2.test.mjs` — OK.
- `node tests/pet-compat-stage5.test.mjs` — OK.

Não foi alegado teste de integração do bootstrap completo: a verificação anterior dessa base foi bloqueada por dependência `baileys` ausente no ambiente de teste. A etapa não publica nem aplica mudanças na VPS.
