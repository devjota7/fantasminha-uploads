// Renderizador central de respostas do Fantasminha.
// Caixa compacta, título estilizado e uma frase final sem etiqueta de domínio.
import { pickFrase } from './frases.js';
import { getCommand } from '../core/registry.js';

// ---------- texto estilizado ----------
const SERIF_ITALIC_UP = 0x1D468; // 𝑨
const SERIF_ITALIC_LO = 0x1D482; // 𝒂
const LEGACY_BOLD_UP = 0x1D400;
const LEGACY_BOLD_LO = 0x1D41A;
const LEGACY_BOLD_NUM = 0x1D7CE;

// Itálico serifado, preservando acentos como marcas combinantes (𝑰́).
export function stylize(text) {
  return [...String(text ?? '').normalize('NFD')].map(ch => {
    const c = ch.codePointAt(0);
    if (c >= 65 && c <= 90) return String.fromCodePoint(SERIF_ITALIC_UP + c - 65);
    if (c >= 97 && c <= 122) return String.fromCodePoint(SERIF_ITALIC_LO + c - 97);
    return ch;
  }).join('').normalize('NFC');
}

// Inverso de stylize(): também reconhece saídas em negrito da versão anterior.
export function unstylize(text) {
  return [...String(text ?? '').normalize('NFD')].map(ch => {
    const c = ch.codePointAt(0);
    if (c >= SERIF_ITALIC_UP && c < SERIF_ITALIC_UP + 26) return String.fromCharCode(65 + c - SERIF_ITALIC_UP);
    if (c >= SERIF_ITALIC_LO && c < SERIF_ITALIC_LO + 26) return String.fromCharCode(97 + c - SERIF_ITALIC_LO);
    if (c >= LEGACY_BOLD_UP && c < LEGACY_BOLD_UP + 26) return String.fromCharCode(65 + c - LEGACY_BOLD_UP);
    if (c >= LEGACY_BOLD_LO && c < LEGACY_BOLD_LO + 26) return String.fromCharCode(97 + c - LEGACY_BOLD_LO);
    if (c >= LEGACY_BOLD_NUM && c < LEGACY_BOLD_NUM + 10) return String.fromCharCode(48 + c - LEGACY_BOLD_NUM);
    return ch;
  }).join('').normalize('NFC');
}

const SMALL_CAPS = { a:'ᴀ',b:'ʙ',c:'ᴄ',d:'ᴅ',e:'ᴇ',f:'ꜰ',g:'ɢ',h:'ʜ',i:'ɪ',j:'ᴊ',k:'ᴋ',l:'ʟ',m:'ᴍ',n:'ɴ',o:'ᴏ',p:'ᴘ',q:'ǫ',r:'ʀ',s:'s',t:'ᴛ',u:'ᴜ',v:'ᴠ',w:'ᴡ',x:'x',y:'ʏ',z:'ᴢ' };
export function smallCaps(text) {
  return [...String(text ?? '').toLowerCase()].map(ch => SMALL_CAPS[ch] || ch).join('');
}

// ---------- barras ----------
export function bar(value = 0, max = 10, size = 8) {
  const m = Math.max(1, Number(max) || 1);
  const filled = Math.max(0, Math.min(size, Math.round((Number(value) || 0) / m * size)));
  return '▰'.repeat(filled) + '▱'.repeat(size - filled);
}

// "Vida: 80/100" -> "Vida: 80/100 ▰▰▰▰▰▰▰▱"
const BAR_KEYWORDS = /(vida|hp|xp|exp|energia|fome|sede|stamina|mana|felicidade|sa[úu]de|carisma|for[çc]a|nivel|n[íi]vel|progresso)/i;
export function addBars(text) {
  return String(text).split('\n').map(line => {
    if (line.includes('▰') || line.includes('▱')) return line;
    if (!BAR_KEYWORDS.test(line)) return line;
    const m = line.match(/(\d[\d.,]*)\s*\/\s*(\d[\d.,]*)/);
    if (!m) return line;
    const num = s => Number(String(s).replace(/\./g, '').replace(',', '.'));
    const a = num(m[1]), b = num(m[2]);
    if (!Number.isFinite(a) || !Number.isFinite(b) || b <= 0 || a < 0 || a > b * 1.0001) return line;
    return `${line} ${bar(a, b)}`;
  }).join('\n');
}

// ---------- layout compacto compartilhado ----------
export function caixa({ titulo = '', icone = '', linhas = [], rodape = '', category = 'geral', tipo = null, command = '' } = {}) {
  const safeLines = linhas.map(line => String(line ?? ''));
  const responseType = tipo || classificar(`${titulo}\n${safeLines.join('\n')}`);
  const footer = rodape || pickFrase(responseType, Math.random, `${category}:${command || titulo || 'caixa'}`);
  return renderDomainResponse({ titulo, icone, linhas: safeLines, rodape: footer, tipo: responseType, category });
}

// ---------- classificação ----------
const ICONES = {
  erro: ['🩸', '🥀', '💀'],
  permissao: ['🔒', '†', '⛧'],
  sucesso: ['💜', '👻', '✨'],
  uso: ['🕯️', '📜', '🖤'],
  aviso: ['🖤', '🌑', '⚠️'],
  espera: ['🌑', '⏳', '🕸️'],
  menu: ['🧭', '👻', '🕯️'],
  info: ['👻', '🖤', '💜', '🔮']
};
const pick = (arr, rng) => arr[Math.floor(rng() * arr.length) % arr.length];

const STATUS_START = /^(?:❌|🚫|⛔|✖️?|🩸)\s*/u;
const OK_START = /^(?:✅|✔️?|☑️?)\s*/u;
const WARN_START = /^(?:⚠️?|❗|‼️?|🔒)\s*/u;
const WAIT_START = /^(?:⏳|⌛|🔄|⏱️?)\s*/u;
const USO_START = /^(?:💡|📋|📝|ℹ️?)\s*/u;

// Emoji decorativo no início de linhas "Rótulo:" vira ▸ (visual discreto).
const KEEP_EMOJI = /^(?:🥇|🥈|🥉|🟥|🟧|🟨|🟩|🟦|🟪|🟫|⬛|⬜|🔴|🟠|🟡|🟢|🔵|🟣|⚫|⚪|✅|❌|⚠️|[0-9]\uFE0F?\u20E3)/u;
const LABEL_LINE = /^(\p{Extended_Pictographic}\uFE0F?)\s+(\*[^*\n]{1,40}:\*|[A-ZÀ-Ú][^\n:*]{0,28}:)/u;

function calmarEmojis(linhas) {
  return linhas.map(l => {
    if (KEEP_EMOJI.test(l)) return l;
    const m = l.match(LABEL_LINE);
    if (!m) return l;
    return l.replace(m[1], '▸');
  });
}

export function classificar(text) {
  const first = String(text).trimStart();
  if (/(?:acesso\s+negado|permiss(?:ão|ões)|não\s+autorizad[oa]|somente\s+(?:o\s+)?(?:dono|administrador)|exclusivo\s+do\s+dono)/i.test(first)) return 'permissao';
  if (STATUS_START.test(first) || /^(erro|falha)\b/i.test(first)) return 'erro';
  if (OK_START.test(first)) return 'sucesso';
  if (WARN_START.test(first)) return 'aviso';
  if (WAIT_START.test(first)) return 'espera';
  if (USO_START.test(first) && /\b(uso|use|exemplo|formato)\b/i.test(first)) return 'uso';
  if (/^\s*[^\n]{0,6}\s*(uso|use)\s*:/i.test(first) || /\b(uso|exemplo)s?:/i.test(first.slice(0, 160))) return 'uso';
  return 'info';
}

const TITULOS_PADRAO = { erro: 'Erro', permissao: 'Permissão', sucesso: 'Feito', uso: 'Como usar', aviso: 'Atenção', espera: 'Aguarde', info: 'Fantasminha' };

export const RESPONSE_VISUAL_PROFILES = Object.freeze({
  glitch: Object.freeze({
    header: badge => `// FANTASMINHA · ${badge}`,
    title: (icon, title) => `${icon} ${title}`,
    line: value => value,
    footer: value => value
  }),
  dossier: Object.freeze({
    header: badge => `† LAUDO · ${badge}`,
    title: (icon, title) => `${icon} ${title}`,
    line: value => value,
    footer: value => value
  }),
  gothic: Object.freeze({
    header: badge => `† FANTASMINHA · ${badge}`,
    title: (icon, title) => `${icon} ${title}`,
    line: value => value,
    footer: value => value
  }),
  graffiti: Object.freeze({
    header: badge => `# FANTASMINHA · ${badge}`,
    title: (icon, title) => `${icon} ${title}`,
    line: value => value,
    footer: value => value
  })
});

const RESPONSE_DOMAIN_STYLE = Object.freeze({
  sistema: 'glitch', geral: 'glitch', ferramentas: 'glitch', downloads: 'glitch',
  ia: 'glitch', utilidades: 'glitch', produtividade: 'glitch', media: 'glitch',
  figurinhas: 'glitch', alem: 'glitch', 'mega-expansao': 'glitch',
  perfil: 'dossier', rankings: 'dossier', economia: 'dossier', premium: 'dossier',
  licenca: 'dossier', personal: 'dossier', conquistas: 'dossier',
  dono: 'gothic', owner: 'gothic', admin: 'gothic', seguranca: 'gothic',
  jogos: 'graffiti', quiz: 'graffiti', brincadeiras: 'graffiti', competitivo: 'graffiti',
  torneios: 'graffiti', rpg: 'graffiti', world: 'graffiti', mundo: 'graffiti',
  pets: 'graffiti', social: 'graffiti', comunidade: 'graffiti'
});

const RESPONSE_STATUS_BADGE = Object.freeze({
  erro: '0xERRO', permissao: '0xBLOQUEIO', sucesso: '0xOK', uso: '0xUSO', aviso: '0xALERTA',
  espera: '0xBUSCA', menu: '0xMENU', info: '0xREGISTRO'
});

export function resolveResponseDomain(category) {
  const key = String(category || '').trim().toLowerCase();
  return RESPONSE_DOMAIN_STYLE[key] || 'glitch';
}

const COMMAND_MENTION = /†\s+([^\p{L}\p{N}\s]+[\p{L}\p{N}][\p{L}\p{N}_.-]*)/gu;

function stylizeHeading(value) {
  const source = String(value ?? '');
  let result = '';
  let cursor = 0;
  for (const match of source.matchAll(COMMAND_MENTION)) {
    result += stylize(source.slice(cursor, match.index).toUpperCase());
    result += `† ${match[1]}`;
    cursor = match.index + match[0].length;
  }
  return result + stylize(source.slice(cursor).toUpperCase());
}

export function renderDomainResponse({ titulo = 'Fantasminha', icone = '👻', linhas = [], rodape = '', tipo = 'info', category = 'geral', includeHeader = true } = {}) {
  const profile = RESPONSE_VISUAL_PROFILES[resolveResponseDomain(category)];
  const badge = RESPONSE_STATUS_BADGE[tipo] || RESPONSE_STATUS_BADGE.info;
  const title = stylizeHeading(titulo || 'Fantasminha');
  return [
    ...(includeHeader ? [profile.header(badge)] : []),
    profile.title(icone, title),
    ...linhas.map(line => profile.line(String(line ?? ''))),
    profile.footer(String(rodape || 'ARQUIVO ENCERRADO'))
  ].join('\n');
}

// ---------- decoração automática ----------
export const LIMITE_DECORAR = 3500;
const JA_TEM_MOLDURA = /(?:^|\n)(?:\/\/[^\n]*|† (?:DOSSIÊ|LAUDO|FANTASMINHA)[^\n]*|# (?:.+ · FANTASMINHA|FANTASMINHA · 0x[A-Z]+)|👻 𝑴[^\n]*)/u;
const MOLDURA_ANTIGA = /[◤◥◣◢╭╮╰╯┏┓┗┛╔╗╚╝┌┐└┘═║⟦⟧]|┃|┊|╎|〔/u;
const LINHA_APENAS_DECORATIVA = /^[\s╭╮╰╯┏┓┗┛╔╗╚╝┌┐└┘═║┃│╎┊━─=+*]+$/u;
const CABECALHO_RESPOSTA = /^(?:\/\/ FANTASMINHA · 0x[A-Z]+|† (?:LAUDO|FANTASMINHA) · 0x[A-Z]+|# FANTASMINHA · 0x[A-Z]+)\r?\n/u;

function removerCabecalhoResposta(text) {
  return String(text ?? '').replace(CABECALHO_RESPOSTA, '');
}

function normalizarMolduraAntiga(text) {
  const lines = String(text ?? '').replace(/\r/g, '').split('\n');
  const start = lines.findIndex(line => line.trim() !== '');
  const end = lines.findLastIndex(line => line.trim() !== '');
  if (start < 0 || end <= start) return null;
  const top = lines[start].trim();
  const bottom = lines[end].trim();
  if (!/^[╭╔┏┌]/u.test(top) || !/[╮╗┓┐]$/u.test(top)) return null;
  if (!/^[╰╚┗└]/u.test(bottom) || !/[╯╝┛┘]$/u.test(bottom)) return null;

  const match = top.match(/(?:〔|【|\[)\s*(.*?)(?:〕|】|\])/u);
  if (!match) return null;
  const rawTitle = match[1].trim();
  const iconMatch = rawTitle.match(/^(\p{Extended_Pictographic}\uFE0F?)\s*/u);
  const icon = iconMatch?.[1] || '';
  const plainTitle = unstylize(rawTitle
    .replace(/^\p{Extended_Pictographic}\uFE0F?\s*/u, '')
    .replace(/^(?:†|⛧|◈|✦|✧)\s*/u, '')
    .replace(/[*_]/g, '')).trim() || 'Registro';
  const heading = icon ? `${icon} *${plainTitle}*` : `*${plainTitle}*`;
  const body = lines.slice(start + 1, end).flatMap(line => {
    if (LINHA_APENAS_DECORATIVA.test(line)) return [];
    return [unstylize(line.replace(/^\s*[┃│║╎┊]\s?/u, ''))];
  });
  return [heading, ...body].join('\n').replace(/\n{3,}/g, '\n\n').trim();
}

export function deveDecorar(text, ctx = {}) {
  const s = String(text ?? '');
  const t = s.trim();
  if (!t || t.length < 3) return false;
  if (ctx.options?.noDecorate === true || ctx.options?.raw === true) return false;
  if (t.length > LIMITE_DECORAR) return false;
  if (JA_TEM_MOLDURA.test(t)) return false;
  if (MOLDURA_ANTIGA.test(t) && !normalizarMolduraAntiga(t)) return false;
  if (t.includes('```')) return false;
  if (/^https?:\/\/\S+$/i.test(t)) return false;
  if (/^[{\[]/.test(t) && /[}\]]$/.test(t)) return false;
  if (ctx.category && SKIP_CATEGORIES.has(String(ctx.category).toLowerCase())) return false;
  return true;
}

const SKIP_CATEGORIES = new Set(['ia', 'assistente', 'assistant', 'chat']);

function extrairTitulo(linhas) {
  // Só é título quando o negrito é a linha inteira: "🎰 *CAÇA-NÍQUEIS*", "*Título*:" ou "*Título* - subtítulo".
  const first = linhas[0] ?? '';
  const m = first.match(/^\s*(?:\p{Extended_Pictographic}\uFE0F?\s*)*\*([^*\n]{2,48})\*\s*(?:[:!.]+\s*)?(?:[-–—]\s*(.+))?$/u);
  if (!m) return null;
  return { titulo: m[1].replace(/[!:]+$/, '').trim(), resto: (m[2] || '').trim() };
}

export function decorarResposta(text, ctx = {}) {
  const raw = String(text ?? '');
  if (!ctx.category && ctx.command) {
    try { ctx = { ...ctx, category: getCommand(String(ctx.command))?.category }; } catch { /* sem registry */ }
  }
  const normalized = normalizarMolduraAntiga(raw);
  const source = normalized ?? raw;
  if (!deveDecorar(source, ctx)) {
    return ctx.omitirCabecalho === true ? removerCabecalhoResposta(raw) : raw;
  }
  const rng = ctx.rng || Math.random;
  const tipo = ctx.tipo || classificar(raw);

  let linhas = source.replace(/\r/g, '').trim().split('\n');
  let titulo = null;
  const ext = extrairTitulo(linhas);
  if (ext) {
    titulo = ext.titulo;
    linhas = ext.resto ? [ext.resto, ...linhas.slice(1)] : linhas.slice(1);
    while (linhas.length && linhas[0].trim() === '') linhas.shift();
  } else {
    // remove só o emoji de status da 1ª linha; o resto do texto fica como veio
    linhas[0] = linhas[0].replace(STATUS_START, '').replace(OK_START, '').replace(WARN_START, '').replace(WAIT_START, '').replace(USO_START, '');
    // Sucessos e registros podem identificar a ação; erros e permissões mantêm título neutro.
    titulo = ctx.command && ['info', 'sucesso'].includes(tipo)
      ? String(ctx.command)
      : TITULOS_PADRAO[tipo];
  }
  linhas = calmarEmojis(addBars(linhas.join('\n')).split('\n'));
  // colapsa linhas vazias repetidas
  linhas = linhas.filter((l, i, a) => !(l.trim() === '' && (a[i - 1] ?? '').trim() === ''));
  while (linhas.length && linhas[linhas.length - 1].trim() === '') linhas.pop();

  return renderDomainResponse({
    titulo,
    icone: pick(ICONES[tipo] || ICONES.info, rng),
    linhas: linhas.map(l => (l.trim() === '' ? '' : l)),
    rodape: pickFrase(tipo, rng, `${ctx.category || 'geral'}:${ctx.command || 'global'}`),
    tipo,
    category: ctx.category,
    includeHeader: ctx.omitirCabecalho !== true
  });
}

export default { stylize, unstylize, smallCaps, bar, addBars, caixa, classificar, deveDecorar, decorarResposta };
