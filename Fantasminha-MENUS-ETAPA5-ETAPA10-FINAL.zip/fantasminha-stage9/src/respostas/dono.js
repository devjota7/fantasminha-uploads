/** Respostas voltadas ao usuário para o domínio dono. */

export function doctorText(d) {
  return `× 👻 *FANTASMINHA — DOCTOR*\n\n${d.ok ? '✅ Sistema saudável.' : '⚠️ Problemas encontrados:'}\n${d.issues.map(x => `• ${x}`).join('\\n') || '• Nenhum problema crítico.'}\n\n📦 Registry: ${d.snapshot.registry.enabled} comandos / ${d.snapshot.registry.aliases} aliases\n💾 Banco: ${d.snapshot.checks.database ? 'OK' : 'ERRO'}\n🧠 Heap: ${Math.round(d.snapshot.memory.heapUsed / Math.max(d.snapshot.memory.heapTotal, 1) * 100)}%\n⚙️ Jobs: ${d.snapshot.jobs.length}`;
}

export function auditText(a) {
  return `× 👻 *AUDITORIA*\n\n📚 Eventos: *${a.total}*\n🕒 Último: *${a.last ? new Date(a.last.at).toLocaleString('pt-BR') : 'nenhum'}*\n🎯 Última ação: *${a.last?.action || '—'}*\n📌 Resultado: *${a.last?.result || '—'}*`;
}

export function featureFlagsText(flags) {
  return `× 👻 *FEATURE FLAGS*\n\n${Object.entries(flags).map(([k, v]) => `${v ? '🟢' : '🔴'} ${k}: *${v ? 'ON' : 'OFF'}*`).join('\\n')}`;
}

export default Object.freeze({ doctorText, auditText, featureFlagsText });
