import { decorarResposta } from './estilo.js';
import { renderCommandText } from '../core/prefix.js';

const INTERACTIVE_KEYS = Object.freeze([
  'buttons', 'buttonsMessage', 'sections', 'listMessage', 'interactiveMessage',
  'templateButtons', 'nativeFlowMessage', 'viewOnceMessage', 'pollCreationMessage',
  'groupInviteMessage', 'productMessage', 'contacts', 'location', 'liveLocation'
]);
const MEDIA_KEYS = Object.freeze(['image', 'video', 'audio', 'sticker', 'document', 'ptv']);
const MUTATION_KEYS = Object.freeze(['edit', 'react', 'delete', 'pin', 'star', 'forward']);

function hasAnyKey(value, keys) {
  return keys.some(key => Object.prototype.hasOwnProperty.call(value, key));
}

/**
 * Decora somente texto/legenda de saída. Edits, ações de protocolo e payloads
 * interativos permanecem intactos; o marcador interno é removido antes do envio.
 */
export function decorateOutgoingContent(content, context = {}) {
  if (!content || typeof content !== 'object' || Array.isArray(content)) return content;

  const skipVisual = content.__skipVisualDecorate === true;
  const { __skipVisualDecorate: _internal, ...payload } = content;
  if (skipVisual || hasAnyKey(payload, MUTATION_KEYS) || hasAnyKey(payload, INTERACTIVE_KEYS)) return payload;

  const options = (typeof context === 'function' ? context() : context) || {};
  if (typeof payload.caption === 'string') {
    const caption = decorarResposta(renderCommandText(payload.caption, options.prefix), { ...options, omitirCabecalho: true });
    return caption === payload.caption ? payload : { ...payload, caption };
  }

  if (typeof payload.text !== 'string' || hasAnyKey(payload, MEDIA_KEYS)) return payload;
  const text = decorarResposta(renderCommandText(payload.text, options.prefix), options);
  return text === payload.text ? payload : { ...payload, text };
}

/** Wraps a per-message transport while preserving the original receiver. */
export function createStyledSendMessage(sendMessage, contextProvider = () => ({}), receiver = null) {
  if (typeof sendMessage !== 'function') return sendMessage;
  return function styledSendMessage(jid, content, ...rest) {
    const styledContent = decorateOutgoingContent(content, contextProvider);
    return Reflect.apply(sendMessage, receiver || this, [jid, styledContent, ...rest]);
  };
}

/** Creates a scoped proxy; the shared transport object is never monkey-patched. */
export function createStyledSocketProxy(socket, contextProvider = () => ({})) {
  if (!socket || typeof socket.sendMessage !== 'function') return socket;
  const styledSendMessage = createStyledSendMessage(socket.sendMessage, contextProvider, socket);
  const boundMethods = new Map();
  return new Proxy(socket, {
    get(target, property) {
      if (property === 'sendMessage') return styledSendMessage;
      const value = Reflect.get(target, property, target);
      if (typeof value !== 'function') return value;
      if (!boundMethods.has(property)) boundMethods.set(property, value.bind(target));
      return boundMethods.get(property);
    },
    set(target, property, value) {
      return Reflect.set(target, property, value, target);
    }
  });
}

export default { decorateOutgoingContent, createStyledSendMessage, createStyledSocketProxy };
