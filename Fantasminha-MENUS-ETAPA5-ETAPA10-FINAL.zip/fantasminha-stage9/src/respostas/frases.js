// Frases originais do Fantasminha: humor sombrio por contexto, sem atacar quem usa o bot.
// Cada comando mantém uma rotação própria e evita repetição nas três últimas saídas.
export const FRASES = Object.freeze({
  erro: [
    'A entidade tropeçou no próprio véu. O log vai fingir que não viu.',
    'Falha no ritual; até o além tem dias de expediente ruim.',
    'O resultado sumiu numa falha dimensional. Tente novamente em instantes.',
    'Não concluiu. Nem todo susto vira sucesso.',
    'O Fantasminha errou; já registrei minha própria ocorrência.',
    'O sistema engasgou com o ectoplasma. Sem pânico.',
    'A operação saiu do trilho. A culpa, claro, foi do fantasma.',
    'Erro confirmado. A entidade está revendo o feitiço.',
    'O pedido voltou sem resposta. O além também tem dias de folga.',
    'Falha registrada; desta vez, o susto foi para o sistema.'
  ],
  sucesso: [
    'Resolvido — antes que a entidade mudasse de ideia.',
    'Pronto. O silêncio sobrenatural agradece.',
    'Feito. Nenhuma alma precisou ser invocada.'
  ],
  uso: [
    'Ritual incompleto. O formato está logo acima; sim, eu também li.',
    'Falta um dado. Nem toda entidade trabalha com telepatia.',
    'Sintaxe indicada. O além aceita instruções mais precisas.',
    'Quase certo; o fantasma não adivinha parâmetros por esporte.',
    'Confira o exemplo e complete a invocação sem improvisar no escuro.',
    'Parâmetros incompletos. A bola de cristal está em manutenção.',
    'A chamada precisa de mais detalhes antes de abrir o portal.',
    'Use o formato indicado; improviso funciona melhor em histórias de terror.'
  ],
  permissao: [
    'Esta ação exige um nível de acesso diferente.',
    'Solicitação bloqueada pelas permissões deste comando.',
    'A regra de acesso foi aplicada; nenhuma alteração foi feita.',
    'Este comando não está liberado para o seu nível de acesso.',
    'Não tenho autorização para concluir esta ação nesta conta.',
    'A permissão necessária não foi atendida; nenhum dado foi alterado.'
  ],
  aviso: [
    'Sinal instável. Confirme as condições antes de prosseguir.',
    'Aviso registrado. Esta operação pode produzir efeitos inesperados.',
    'Atenção: há uma condição que precisa ser verificada primeiro.',
    'Contenção recomendada. Revise os dados antes de continuar.',
    'A entidade sinalizou um risco concreto; leia a mensagem acima.',
    'O estado atual não é seguro para concluir a ação.',
    'Há uma restrição ativa. Resolva-a antes de repetir o comando.',
    'Verificação necessária. A operação ainda não foi concluída.'
  ],
  espera: [
    'Consulta atravessando o véu. O além não tem fibra óptica.',
    'Processando em frequências que os vivos não captam.',
    'A entidade foi buscar a resposta no arquivo empoeirado.',
    'Aguarde enquanto o sistema invoca um pouco de paciência.',
    'Sinal em trânsito. Até assombração pega fila.',
    'O pedido está sendo processado; o resultado ainda não cruzou o portal.',
    'A consulta segue em andamento. Não precisa repetir a invocação.',
    'Processando. O véu está a caminho de se abrir.'
  ],
  info: [
    'Arquivo aberto; não toque nas páginas que sussurram.',
    'Informação recuperada do lado inconveniente da realidade.',
    'Relatório emitido. O mistério perdeu uma batalha.',
    'Dados confirmados pelo departamento de ocorrências estranhas.',
    'Consulta encerrada. A entidade continua sabendo demais.',
    'Registro localizado no arquivo do além.',
    'Informação reunida. O silêncio perdeu mais um segredo.',
    'Leitura concluída; nada aqui foi escrito por um poltergeist. Talvez.'
  ],
  menu: [
    'Escolha uma rota. O labirinto não vai se organizar sozinho.',
    'Navegação aberta; o fantasma não responde por escolhas questionáveis.',
    'Arquivo consultado. Há mais comandos do que juízo disponível.',
    'Use sem medo. Se der errado, culpamos a interferência.',
    'Sinal de navegação ativo. As paredes ainda sussurram, por cortesia.',
    'Áreas disponíveis. O mapa não morde; em geral.',
    'Selecione uma seção para consultar os comandos daquele domínio.',
    'A passagem está aberta. Não há necessidade de bater três vezes.'
  ]
});

const recentIndicesByScope = new Map();

export function pickFrase(tipo = 'info', rng = Math.random, scope = 'global') {
  const keyType = Object.hasOwn(FRASES, tipo) ? tipo : 'info';
  const lista = FRASES[keyType];
  const sample = Number(rng());
  let index = Number.isFinite(sample)
    ? ((Math.floor(sample * lista.length) % lista.length) + lista.length) % lista.length
    : 0;
  const key = `${keyType}\u0000${String(scope || 'global')}`;
  const recent = recentIndicesByScope.get(key) || [];
  if (recent.includes(index)) {
    for (let step = 1; step < lista.length; step++) {
      const candidate = (index + step) % lista.length;
      if (!recent.includes(candidate)) { index = candidate; break; }
    }
  }
  recent.push(index);
  if (recent.length > 3) recent.shift();
  recentIndicesByScope.set(key, recent);
  return lista[index];
}

export function resetFraseRotation() {
  recentIndicesByScope.clear();
}
