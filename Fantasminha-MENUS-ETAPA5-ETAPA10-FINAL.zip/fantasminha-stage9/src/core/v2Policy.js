// Fantasminha 2.0 — política de produto.
// Comandos aqui listados não são registrados no Registry e, portanto,
// deixam de existir na interface pública da versão 2.0.
// Triagem 2.0 (redesenho, src/modules/triagem) usa: triagem, triagemficha,
// triagemaprovar, triagemreprovar, triagemobs e triagemdono. Os demais nomes da
// Triagem 1.0 continua removida; triagemcobrar volta na Fase 2 da Triagem 2.0 (redesenho).
export const REMOVED_COMMANDS = new Set([
  'warn','warns','resetwarn','maxwarns','autoban',
  'rpgcriar','rpgxp','rankxp','rpgcurar','baterrpg','aceitarrpg','aceitarbatalha',
  'bj','bjhit','bjstand','forcaalem','letraalem','quizalem','respostaquiz',
  'memoriafantasminha','memoriafantasma','respostamemoria','roletaaelm','roletaalem',
  'batalhaalmas','torrelimbo','juizalem','juizfinal','sairjogo','metricas','forcaidentidade',
  'preferencias','acheiumerro','mundovivo','temporadainnovation',
  'bossmundial','bossinvocar','boasinvocar','atacarboss','eventomundial','expedicao',
  'museulimbo','conquistasalem','titulos','historia','historiaregistrar','misterio',
  'misteriocriar','misteriopista','misterioparticipar','prestigio','quizresposta',
  'alive','online','pingalem','hora','moeda','uuid','senha','ausente','ausentes','removerausencia',
  'triagemcriar','triagemexcluir','triagemativar','triagemdesativar',
  'triagemconectar','triagemdesconectar','triagemgrupos','triagemgruposadicionar',
  'triagemgrupostirar','triagemgruposlimpar','triagemgruposreset','triagemgruposstatus',
  'triagempergunta','triagemperguntas','setpergunta','setperguntas','verperguntas','triagemstatus',
  'triagemstats','filatriagem','conselho','menutriagem','triagemmenu',
  'guerras','guerra','war','guerracla','guerragrupoataque','guerragrupoataques',
  'guerragrupodefesa','guerragrupoentrar','guerragrupohistorico','guerragrupomembros',
  'guerragrupomvp','guerragrupoplacar','guerragruposair','clagrupomenu',
  'clan','clans','clãs','cla','clã','clancriar','clanentrar','clansair','clancontribuir','clanmembros','clanrank','criarclan','criarcla','criarclã','claninfo','entrarclan','entrarcla','sairclan','saircla',
  'doarclan','doarcla','membrosclan','membroscla','rankclan','rankcla',
  'convidar','invite','convite','rmconvite','removerconvite','aceitarconvite','recusarconvite','recusar','kickcla',
]);

export const REMOVED_PLUGINS = new Set();
export const isRemovedCommand = name => REMOVED_COMMANDS.has(String(name ?? '').trim().toLowerCase());
