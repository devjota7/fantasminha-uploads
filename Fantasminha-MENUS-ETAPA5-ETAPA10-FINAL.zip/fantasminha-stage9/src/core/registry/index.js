/** Registry arquitetural: a fonte de verdade continua em ../registry.js. */
export * from '../registry.js';
import registry from '../registry.js';
export default registry;
