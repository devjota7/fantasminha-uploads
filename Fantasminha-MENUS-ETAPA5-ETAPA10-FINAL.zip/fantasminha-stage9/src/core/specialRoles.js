/**
 * Arquitetura oficial dos cargos/status especiais do Fantasminha.
 *
 * IMPORTANTE:
 * - Este módulo define o modelo novo; ele não substitui ainda as verificações
 *   legadas espalhadas pelo bot. A migração acontece nas etapas seguintes.
 * - Aranha e VIP NÃO são cargos administrativos. São sistemas/status do usuário.
 * - ADM do WhatsApp, Bot Admin e Moderador de grupo NÃO pertencem a esta lista.
 */

export const SPECIAL_ROLE = Object.freeze({
  OWNER: 'owner',
  CO_OWNER: 'co_owner',
  SUB_OWNER: 'sub_owner',
  SUPPORT: 'support',
  ARANHA: 'aranha',
  VIP: 'vip'
});

export const SPECIAL_ROLE_META = Object.freeze({
  [SPECIAL_ROLE.OWNER]: Object.freeze({
    id: SPECIAL_ROLE.OWNER,
    name: 'Dono Principal',
    label: '👑 Dono Principal',
    kind: 'administrative',
    rank: 500,
    manageable: false,
    global: true
  }),
  [SPECIAL_ROLE.CO_OWNER]: Object.freeze({
    id: SPECIAL_ROLE.CO_OWNER,
    name: 'Co-Dono',
    label: '🏆 Co-Dono',
    kind: 'administrative',
    rank: 400,
    manageable: true,
    global: true
  }),
  [SPECIAL_ROLE.SUB_OWNER]: Object.freeze({
    id: SPECIAL_ROLE.SUB_OWNER,
    name: 'Subdono',
    label: '🛡️ Subdono',
    kind: 'administrative',
    rank: 300,
    manageable: true,
    global: true
  }),
  [SPECIAL_ROLE.SUPPORT]: Object.freeze({
    id: SPECIAL_ROLE.SUPPORT,
    name: 'Suporte',
    label: '🆘 Suporte',
    kind: 'administrative',
    rank: 200,
    manageable: true,
    global: true
  }),
  [SPECIAL_ROLE.ARANHA]: Object.freeze({
    id: SPECIAL_ROLE.ARANHA,
    name: 'Aranha',
    label: '🕷️ Aranha',
    kind: 'feature',
    rank: 0,
    manageable: true,
    global: false,
    note: 'Sistema/benefício de usuário; não concede autoridade administrativa.'
  }),
  [SPECIAL_ROLE.VIP]: Object.freeze({
    id: SPECIAL_ROLE.VIP,
    name: 'VIP',
    label: '💎 VIP',
    kind: 'entitlement',
    rank: 0,
    manageable: true,
    global: true,
    note: 'Plano/benefício de usuário; não concede autoridade administrativa.'
  })
});

export const ADMINISTRATIVE_ROLES = Object.freeze([
  SPECIAL_ROLE.OWNER,
  SPECIAL_ROLE.CO_OWNER,
  SPECIAL_ROLE.SUB_OWNER,
  SPECIAL_ROLE.SUPPORT
]);

export const USER_SYSTEM_ROLES = Object.freeze([
  SPECIAL_ROLE.ARANHA,
  SPECIAL_ROLE.VIP
]);

export const SPECIAL_ROLES_FOR_MANAGEMENT = Object.freeze([
  SPECIAL_ROLE.CO_OWNER,
  SPECIAL_ROLE.SUB_OWNER,
  SPECIAL_ROLE.SUPPORT,
  SPECIAL_ROLE.ARANHA,
  SPECIAL_ROLE.VIP
]);

export function isSpecialRole(roleId) {
  return Boolean(SPECIAL_ROLE_META[String(roleId || '').trim()]);
}

export function getSpecialRoleMeta(roleId) {
  return SPECIAL_ROLE_META[String(roleId || '').trim()] || null;
}

export function isAdministrativeRole(roleId) {
  return ADMINISTRATIVE_ROLES.includes(String(roleId || '').trim());
}

export function isUserSystemRole(roleId) {
  return USER_SYSTEM_ROLES.includes(String(roleId || '').trim());
}

export function specialRoleName(roleId) {
  return getSpecialRoleMeta(roleId)?.label || 'Usuário';
}

/**
 * Regra arquitetural de gerenciamento.
 * Nesta etapa, apenas o Dono Principal administra os cargos especiais.
 * A matriz detalhada de permissões será definida na Etapa 3.
 */
export function canManageSpecialRoles(actorRoleId) {
  return String(actorRoleId || '').trim() === SPECIAL_ROLE.OWNER;
}

/**
 * Evita que um cargo administrativo seja tratado como equivalente a
 * Aranha/VIP apenas por comparação numérica.
 */
export function isAdministrativeHierarchyRole(roleId) {
  return isAdministrativeRole(roleId);
}

export default {
  SPECIAL_ROLE,
  SPECIAL_ROLE_META,
  ADMINISTRATIVE_ROLES,
  USER_SYSTEM_ROLES,
  SPECIAL_ROLES_FOR_MANAGEMENT,
  isSpecialRole,
  getSpecialRoleMeta,
  isAdministrativeRole,
  isUserSystemRole,
  specialRoleName,
  canManageSpecialRoles,
  isAdministrativeHierarchyRole
};
