/** Contexto de mensagem unificado. Mantém compatibilidade com o ctx legado. */
import { renderCommandText } from './prefix.js';
import { fantasminhaApi } from '../services/api/index.js';
import { createStyledSendMessage } from '../respostas/outgoing.js';
export function enrichMessageContext(ctx = {}) {
  if (!ctx || typeof ctx !== 'object') return ctx;
  if (!ctx.__prefixOutputWrapped && typeof ctx.reply === 'function') {
    const originalReply = ctx.reply.bind(ctx);
    ctx.reply = async (text, options = {}) => originalReply(renderCommandText(text, ctx.prefix), options);
    ctx.__prefixOutputWrapped = true;
  }
  if (!ctx.__outgoingResponseWrapped && typeof ctx.sendMessage === 'function') {
    const originalSendMessage = ctx.sendMessage;
    ctx.sendMessage = createStyledSendMessage(originalSendMessage, () => ({ command: ctx.command, category: ctx.category, prefix: ctx.prefix }), ctx);
    ctx.__outgoingResponseWrapped = true;
  }
  if (!ctx.send) {
    ctx.send = {
      text: async (text, options = {}) => {
        const rendered = renderCommandText(text, ctx.prefix);
        if (typeof ctx.sendMessage === 'function' && ctx.from) {
          return ctx.sendMessage(ctx.from, { text: String(rendered), ...options });
        }
        return ctx.reply?.(rendered);
      },
      to: async (jid, content, options = {}) => ctx.sendMessage?.(jid, content, options),
      reaction: async () => null // reações automáticas desativadas
    };
  }
  if (!ctx.media) {
    ctx.media = {
      isImage: !!ctx.message?.message?.imageMessage,
      isVideo: !!ctx.message?.message?.videoMessage,
      isAudio: !!ctx.message?.message?.audioMessage,
      isSticker: !!ctx.message?.message?.stickerMessage,
      quoted: ctx.message?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null
    };
  }
  ctx.retry ??= async (fn, options) => (await import('./retry.js')).withRetry(fn, options);
  if (!ctx.api) ctx.api = fantasminhaApi;
  const identityValues = [ctx.sender, ctx.senderAlternate, ctx.senderLid].filter(Boolean).map(String);
  const whatsappJid = identityValues.find(value => value.endsWith('@s.whatsapp.net'));
  const whatsappLid = identityValues.find(value => value.endsWith('@lid'));
  ctx.apiContext = { userId: ctx.apiUserId || ctx.sender || undefined, groupId: ctx.isGroup ? (ctx.from || undefined) : undefined, whatsappJid, whatsappLid, command: ctx.command || undefined, source: 'whatsapp-bot', requestId: ctx.requestId || undefined, isGroup: !!ctx.isGroup, isPrivate: !!ctx.isPrivate };
  return ctx;
}
export default { enrichMessageContext };
