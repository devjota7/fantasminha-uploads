/** Observabilidade unificada sobre implementações existentes. */
import logger from '../logger.js';
import metrics from '../metrics.js';

export { logger, metrics };
export async function audit(event, payload = {}) {
  const { recordAudit } = await import('../../platform/audit/index.js');
  return recordAudit({ action: event, ...payload });
}
export function health() {
  return { uptimeMs: process.uptime() * 1000, metrics: metrics.snapshot() };
}
export default { logger, metrics, audit, health };
