/** Ciclo de vida central do Fantasminha. */
import { stopAllJobs } from '../platform/jobs/index.js';
import { emit, Events } from '../events/index.js';
import logger from './logger.js';
import { cleanupResources } from './resourceManager.js';
import { stopControlCenter } from '../platform/controlCenter/index.js';

let shuttingDown = false;
const shutdownHooks = new Set();
const SHUTDOWN_TIMEOUT_MS = Math.max(1000, Number(process.env.SHUTDOWN_TIMEOUT_MS || 15000));

export function registerShutdownHook(name, hook) {
  if (typeof hook !== 'function') throw new TypeError('shutdown hook deve ser uma função');
  const entry = { name: String(name || `hook-${shutdownHooks.size + 1}`), hook };
  shutdownHooks.add(entry);
  return () => shutdownHooks.delete(entry);
}

async function runWithTimeout(task, timeoutMs, label) {
  let timer;
  try {
    return await Promise.race([
      Promise.resolve().then(task),
      new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`${label} excedeu ${timeoutMs}ms`)), timeoutMs); })
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

export function isShuttingDown() { return shuttingDown; }

export async function shutdown(reason = 'manual') {
  if (shuttingDown) return false;
  shuttingDown = true;
  logger.info('lifecycle', `encerrando (${reason})`);
  const startedAt = Date.now();
  try { stopAllJobs(); } catch (e) { logger.warn('lifecycle', 'falha ao parar jobs', { error: e.message }); }
  try { await emit(Events.SHUTDOWN, { reason, at: Date.now() }); } catch (e) { logger.warn('lifecycle', 'falha no evento shutdown', { error: e.message }); }

  for (const { name, hook } of [...shutdownHooks]) {
    const remaining = SHUTDOWN_TIMEOUT_MS - (Date.now() - startedAt);
    if (remaining <= 0) {
      logger.warn('lifecycle', 'prazo global de shutdown esgotado', { hook: name });
      break;
    }
    try { await runWithTimeout(hook, remaining, `hook ${name}`); }
    catch (e) { logger.warn('lifecycle', `falha no hook ${name}`, { error: e.message }); }
  }

  try { await runWithTimeout(cleanupResources, Math.max(1000, SHUTDOWN_TIMEOUT_MS - (Date.now() - startedAt)), 'cleanupResources'); }
  catch (e) { logger.warn('lifecycle', 'falha ao limpar recursos', { error: e.message }); }
  try { await runWithTimeout(stopControlCenter, Math.max(1000, SHUTDOWN_TIMEOUT_MS - (Date.now() - startedAt)), 'stopControlCenter'); }
  catch (e) { logger.warn('lifecycle', 'falha ao parar control center', { error: e.message }); }

  try {
    const { drain } = await import('../database/store.js');
    await runWithTimeout(() => drain(Math.max(1000, SHUTDOWN_TIMEOUT_MS - (Date.now() - startedAt))), Math.max(1000, SHUTDOWN_TIMEOUT_MS - (Date.now() - startedAt)), 'database drain');
  } catch (e) { logger.warn('lifecycle', 'falha ao drenar persistência', { error: e.message }); }
  return true;
}

export function installLifecycleHandlers() {
  if (globalThis.__fantasmaLifecycleInstalled) return;
  globalThis.__fantasmaLifecycleInstalled = true;
  for (const signal of ['SIGINT', 'SIGTERM']) {
    process.once(signal, () => { shutdown(signal).finally(() => process.exit(0)); });
  }
}

export default { shutdown, isShuttingDown, installLifecycleHandlers, registerShutdownHook };
