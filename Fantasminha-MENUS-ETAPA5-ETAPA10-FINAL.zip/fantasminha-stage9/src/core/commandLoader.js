/**
 * Carrega definições declarativas de src/comandos e src/modules/<dominio>/*.commands.js.
 * O Registry continua sendo a única fonte de verdade em runtime.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { registerCommand } from './registry.js';

const SRC_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const COMMAND_ROOT = path.join(SRC_ROOT, 'comandos');
const MODULE_ROOT = path.join(SRC_ROOT, 'modules');

async function walk(dir, predicate) {
  const files = [];
  let entries;
  try { entries = await fs.readdir(dir, { withFileTypes: true }); }
  catch (error) { if (error.code === 'ENOENT') return files; throw error; }
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...await walk(full, predicate));
    else if (entry.isFile() && predicate(entry.name)) files.push(full);
  }
  return files;
}

function isLegacyCommandFile(name) { return name.endsWith('.js') && !name.startsWith('_'); }
function isModuleCommandFile(name) { return name.endsWith('.commands.js') && !name.startsWith('_'); }

function assertDefinition(def, file) {
  if (!def || typeof def !== 'object' || !def.name || (typeof def.handler !== 'function' && typeof def.run !== 'function')) {
    throw new TypeError(`Comando inválido em ${file}: export default precisa conter name e handler|run.`);
  }
}

export async function loadCommandFiles({ root = COMMAND_ROOT, moduleRoot = MODULE_ROOT } = {}) {
  const legacyFiles = await walk(root, isLegacyCommandFile);
  const moduleFiles = await walk(moduleRoot, isModuleCommandFile);
  const files = [...legacyFiles, ...moduleFiles];
  const commands = [];
  for (const file of files) {
    const mod = await import(`${pathToFileURL(file).href}?command-loader=${encodeURIComponent(file)}`);
    const def = mod.default;
    assertDefinition(def, path.relative(SRC_ROOT, file));
    if (def.enabled === false) continue;
    const entry = registerCommand(def);
    commands.push({ file: path.relative(SRC_ROOT, file), name: def.name, registered: !!entry });
  }
  return { files: commands.length, discoveredFiles: files.length, registered: commands.filter(item => item.registered).length, commands };
}

export function commandRoot() { return COMMAND_ROOT; }
export function moduleCommandRoot() { return MODULE_ROOT; }
