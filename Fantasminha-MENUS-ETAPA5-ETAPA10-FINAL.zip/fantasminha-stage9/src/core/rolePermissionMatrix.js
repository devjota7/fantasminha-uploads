/**
 * Matriz oficial de permissões dos cargos especiais — Etapa 3.
 *
 * Esta matriz é a fonte declarativa da arquitetura nova.
 * A migração dos handlers legados para esta matriz acontece nas etapas seguintes.
 *
 * Hierarquia administrativa:
 *   OWNER > CO_OWNER > SUB_OWNER > SUPPORT > USER
 *
 * ARANHA e VIP são atributos/sistemas de usuário e nunca elevam autoridade.
 */
import {
  SPECIAL_ROLE,
  ADMINISTRATIVE_ROLES,
  USER_SYSTEM_ROLES,
  isAdministrativeRole,
  isUserSystemRole
} from './specialRoles.js';

export const ROLE_PERMISSION = Object.freeze({
  MANAGE_SPECIAL_ROLES: 'manage_special_roles',
  VIEW_SPECIAL_ROLES: 'view_special_roles',
  MANAGE_CO_OWNER: 'manage_co_owner',
  MANAGE_SUB_OWNER: 'manage_sub_owner',
  MANAGE_SUPPORT: 'manage_support',
  MANAGE_ARANHA: 'manage_aranha',
  MANAGE_VIP: 'manage_vip',
  RENTAL_CREATE: 'rental_create',
  RENTAL_CREATE_UP_TO_30: 'rental_create_up_to_30',
  RENTAL_CODE_CREATE: 'rental_code_create',
  RENTAL_CODE_CREATE_UP_TO_30: 'rental_code_create_up_to_30',
  RENTAL_VIEW: 'rental_view',
  RENTAL_EXTEND_UP_TO_30: 'rental_extend_up_to_30',
  RENTAL_REMOVE: 'rental_remove',
  RENTAL_MANAGE_UNLIMITED: 'rental_manage_unlimited',
  OWNER_SYSTEM_ADMIN: 'owner_system_admin',
  USE_VIP_BENEFITS: 'use_vip_benefits',
  RPG_ADMIN: 'rpg_admin',
  RPG_RESET_GLOBAL: 'rpg_reset_global'
});

const P = ROLE_PERMISSION;
const R = SPECIAL_ROLE;

export const ROLE_PERMISSION_MATRIX = Object.freeze({
  [R.OWNER]: Object.freeze([
    P.MANAGE_SPECIAL_ROLES,
    P.VIEW_SPECIAL_ROLES,
    P.MANAGE_CO_OWNER,
    P.MANAGE_SUB_OWNER,
    P.MANAGE_SUPPORT,
    P.MANAGE_ARANHA,
    P.MANAGE_VIP,
    P.RENTAL_CREATE,
    P.RENTAL_CREATE_UP_TO_30,
    P.RENTAL_CODE_CREATE,
    P.RENTAL_CODE_CREATE_UP_TO_30,
    P.RENTAL_VIEW,
    P.RENTAL_EXTEND_UP_TO_30,
    P.RENTAL_REMOVE,
    P.RENTAL_MANAGE_UNLIMITED,
    P.OWNER_SYSTEM_ADMIN
  ]),

  // Co-Dono mantém poderes administrativos delegados, mas não altera a
  // autoridade máxima nem a lista de Co-Donos.
  [R.CO_OWNER]: Object.freeze([
    P.VIEW_SPECIAL_ROLES,
    P.MANAGE_SUB_OWNER,
    P.MANAGE_SUPPORT,
    P.MANAGE_ARANHA,
    P.MANAGE_VIP,
    P.RENTAL_CREATE,
    P.RENTAL_CREATE_UP_TO_30,
    P.RENTAL_CODE_CREATE,
    P.RENTAL_CODE_CREATE_UP_TO_30,
    P.RENTAL_VIEW,
    P.RENTAL_EXTEND_UP_TO_30,
    P.RENTAL_REMOVE,
    P.RENTAL_MANAGE_UNLIMITED
  ]),

  // Subdono pode operar aluguel, mas nesta fase sua capacidade de aluguel
  // fica limitada a 30 dias. Não administra Co-Donos/Subdonos.
  [R.SUB_OWNER]: Object.freeze([
    P.VIEW_SPECIAL_ROLES,
    P.MANAGE_SUPPORT,
    P.RENTAL_CREATE_UP_TO_30,
    P.RENTAL_CODE_CREATE_UP_TO_30,
    P.RENTAL_VIEW,
    P.RENTAL_EXTEND_UP_TO_30
  ]),

  // Suporte: inicialmente somente operação de aluguel até 30 dias.
  [R.SUPPORT]: Object.freeze([
    P.RENTAL_CREATE_UP_TO_30,
    P.RENTAL_CODE_CREATE_UP_TO_30,
    P.RENTAL_VIEW,
    P.RENTAL_EXTEND_UP_TO_30
  ]),

  // Sistemas/status não concedem permissões administrativas.
  [R.ARANHA]: Object.freeze([]),
  [R.VIP]: Object.freeze([P.USE_VIP_BENEFITS])
});

export const COMMAND_PERMISSION_MATRIX = Object.freeze({
  // Administração do RPG: somente Dono Principal e Co-Dono.
  rpgadd: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgaddmoney: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  adicionardinheiro: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgremove: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgremovemoney: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  removerdinheiro: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgsetlevel: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  setlevel: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  definirnivelrpg: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgadditem: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  adicionaritem: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgremoveitem: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  removeritem: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgresetplayer: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  resetarjogador: Object.freeze({ permission: P.RPG_ADMIN, roles: [R.OWNER, R.CO_OWNER] }),
  rpgresetglobal: Object.freeze({ permission: P.RPG_RESET_GLOBAL, roles: [R.OWNER] }),
  resetrpgglobal: Object.freeze({ permission: P.RPG_RESET_GLOBAL, roles: [R.OWNER] }),

  gerenciarcargo: Object.freeze({ permission: P.MANAGE_SPECIAL_ROLES, roles: [R.OWNER] }),
  donos: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER] }),
  listadonos: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER] }),

  adddono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  adddonos: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  adicionardono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  rmvdono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  rmdono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  deldono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  removerdono: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),
  rmdonos: Object.freeze({ permission: P.MANAGE_CO_OWNER, roles: [R.OWNER] }),

  addsubdono: Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  rmvsubdono: Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  remsubdono: Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  rmsubdono: Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  delsubdono: Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  listasubdonos: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  listsubdonos: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  'addcmd-subdono': Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  'removecmd-subdono': Object.freeze({ permission: P.MANAGE_SUB_OWNER, roles: [R.OWNER] }),
  'listcmd-subdono': Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  cmdlimitar: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  cmdlimit: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  cmdlimites: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  cmdlimits: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  cmddeslimitar: Object.freeze({ permission: P.VIEW_SPECIAL_ROLES, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),

  addsuporte: Object.freeze({ permission: P.MANAGE_SUPPORT, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  rmvsuporte: Object.freeze({ permission: P.MANAGE_SUPPORT, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),
  rmosuporte: Object.freeze({ permission: P.MANAGE_SUPPORT, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER] }),

  addaranha: Object.freeze({ permission: P.MANAGE_ARANHA, roles: [R.OWNER] }),
  rmvaranha: Object.freeze({ permission: P.MANAGE_ARANHA, roles: [R.OWNER] }),
  rmaranha: Object.freeze({ permission: P.MANAGE_ARANHA, roles: [R.OWNER] }),

  addvip: Object.freeze({ permission: P.MANAGE_VIP, roles: [R.OWNER] }),
  rmvvip: Object.freeze({ permission: P.MANAGE_VIP, roles: [R.OWNER] }),
  delvip: Object.freeze({ permission: P.MANAGE_VIP, roles: [R.OWNER] }),
  rmvvip: Object.freeze({ permission: P.MANAGE_VIP, roles: [R.OWNER] }),

  addaluguel: Object.freeze({ permission: P.RENTAL_CREATE_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  gerarcod: Object.freeze({ permission: P.RENTAL_CODE_CREATE_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  gerarcodigobr: Object.freeze({ permission: P.RENTAL_CODE_CREATE_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  listaraluguel: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  veralugueis: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  listrentals: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  infoaluguel: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  statusaluguel: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  detalhesaluguel: Object.freeze({ permission: P.RENTAL_VIEW, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT] }),
  estenderaluguel: Object.freeze({ permission: P.RENTAL_EXTEND_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  adddiasaluguel: Object.freeze({ permission: P.RENTAL_EXTEND_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  extenderrental: Object.freeze({ permission: P.RENTAL_EXTEND_UP_TO_30, roles: [R.OWNER, R.CO_OWNER, R.SUB_OWNER, R.SUPPORT], maxDays: 30 }),
  removeraluguel: Object.freeze({ permission: P.RENTAL_REMOVE, roles: [R.OWNER, R.CO_OWNER] }),
  deletaraluguel: Object.freeze({ permission: P.RENTAL_REMOVE, roles: [R.OWNER, R.CO_OWNER] }),
  cancelaraluguel: Object.freeze({ permission: P.RENTAL_REMOVE, roles: [R.OWNER, R.CO_OWNER] }),
  limparaluguel: Object.freeze({ permission: P.RENTAL_MANAGE_UNLIMITED, roles: [R.OWNER, R.CO_OWNER] })
});

export function getRolePermissions(roleId) {
  return ROLE_PERMISSION_MATRIX[String(roleId || '').trim()] || [];
}

export function hasRolePermission(roleId, permission) {
  return getRolePermissions(roleId).includes(permission);
}

export function getCommandPermission(commandName) {
  return COMMAND_PERMISSION_MATRIX[String(commandName || '').trim().toLowerCase()] || null;
}

export function canRoleRunCommand(roleId, commandName) {
  const rule = getCommandPermission(commandName);
  if (!rule) return null;
  return rule.roles.includes(String(roleId || '').trim());
}

export function maxDaysForCommand(commandName) {
  const rule = getCommandPermission(commandName);
  return Number.isInteger(rule?.maxDays) ? rule.maxDays : null;
}

export function isKnownAdministrativeRole(roleId) {
  return isAdministrativeRole(roleId);
}

export function isNonAdministrativeSpecialRole(roleId) {
  return isUserSystemRole(roleId);
}

export function assertMatrixIntegrity() {
  for (const role of ADMINISTRATIVE_ROLES) {
    if (!Array.isArray(ROLE_PERMISSION_MATRIX[role])) throw new Error(`Matriz ausente para ${role}`);
  }
  const SYSTEM_ROLE_ALLOWED_PERMISSIONS = Object.freeze({
    [R.ARANHA]: Object.freeze([]),
    [R.VIP]: Object.freeze([P.USE_VIP_BENEFITS])
  });
  for (const role of USER_SYSTEM_ROLES) {
    const allowed = new Set(SYSTEM_ROLE_ALLOWED_PERMISSIONS[role] || []);
    for (const permission of ROLE_PERMISSION_MATRIX[role] || []) {
      if (!allowed.has(permission)) throw new Error(`${role} possui permissão não permitida: ${permission}`);
    }
  }
  for (const [command, rule] of Object.entries(COMMAND_PERMISSION_MATRIX)) {
    if (!rule.roles.length) throw new Error(`Comando sem cargo: ${command}`);
    if (rule.roles.includes(R.ARANHA) || rule.roles.includes(R.VIP)) throw new Error(`Aranha/VIP não podem autorizar comando administrativo: ${command}`);
    if (rule.maxDays != null && rule.maxDays !== 30) throw new Error(`Limite inesperado no comando: ${command}`);
  }
  return true;
}

export default {
  ROLE_PERMISSION,
  ROLE_PERMISSION_MATRIX,
  COMMAND_PERMISSION_MATRIX,
  getRolePermissions,
  hasRolePermission,
  getCommandPermission,
  canRoleRunCommand,
  maxDaysForCommand,
  assertMatrixIntegrity
};
