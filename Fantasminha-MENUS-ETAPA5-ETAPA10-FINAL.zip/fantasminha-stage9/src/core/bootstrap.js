import logger from './logger.js';
import config from './config.js';
import { installAntiCrash } from './antiCrash.js';
import { runMigrations } from '../database/migrate.js';
import { registerSystemCommands } from '../commands/system.js';
import { registryStats } from './registry.js';
import { validateRegistry } from './registry.js';
import { startSchedulers } from '../services/scheduler.js';
import { bootstrapPlatform } from '../platform/index.js';
import { installLifecycleHandlers } from './lifecycle.js';
import { loadCommandFiles } from './commandLoader.js';
import { emit, Events } from '../events/index.js';
import * as alemPlugin from '../plugins/alem/index.js';
import * as jogosPlugin from '../plugins/jogos/index.js';
import * as economiaPlugin from '../plugins/economia/index.js';
import * as adminPlugin from '../plugins/admin/index.js';
import * as premiumPlugin from '../plugins/premium/index.js';
import * as rpgPlugin from '../plugins/rpg/index.js';
import * as clanPlugin from '../plugins/clan/index.js';
import * as downloadsPlugin from '../plugins/downloads/index.js';
import * as ownerPowerPlugin from '../plugins/ownerPower/index.js';
import * as aranhaPlugin from '../plugins/aranha/index.js';
import * as expansionPlugin from '../plugins/expansion/index.js';
import * as platformPlugin from '../plugins/platform/index.js';
import * as supportPlugin from '../plugins/support/index.js';
import * as mediaGenerationPlugin from '../plugins/mediaGeneration/index.js';
import * as communityPlugin from '../plugins/community/index.js';
import * as socialPlugin from '../plugins/social/index.js';
import * as familyPlugin from '../plugins/family/index.js';
import * as relationshipsPlugin from '../plugins/relationships/index.js';
import * as worldEnginePlugin from '../plugins/worldEngine/index.js';
import * as fusionCorePlugin from '../plugins/fusionCore/index.js';
import * as innovationPlugin from '../plugins/innovation/index.js';
import * as takeshiCompatPlugin from '../plugins/takeshiCompat/index.js';
import * as megaFusionPlugin from '../plugins/megaFusion/index.js';
import * as completeExpansionPlugin from '../plugins/completeExpansion/index.js';
import * as responseMediaPlugin from '../plugins/responseMedia/index.js';
import * as quizPlugin from '../plugins/quiz/index.js';
import * as forcaPlugin from '../plugins/forca/index.js';
import * as stopPlugin from '../plugins/stop/index.js';
import * as garticPlugin from '../plugins/gartic/index.js';
import * as rankingPlugin from '../plugins/ranking/index.js';
import * as legacyMigrationBatch1Plugin from '../plugins/legacyMigrationBatch1/index.js';
import * as legacyRegistryPlugin from '../plugins/legacyRegistry/index.js';
import * as reactionManagerPlugin from '../plugins/reactionManager/index.js';
import * as communityFeedbackPlugin from '../plugins/communityFeedback/index.js';
import * as nazunaCompatPlugin from '../plugins/nazunaCompat/index.js';
import * as blackjackPlugin from '../plugins/blackjack/index.js';
import * as volteiPlugin from '../plugins/voltei/index.js';
import * as tagsPlugin from '../plugins/tags/index.js';
import * as menuStylePlugin from '../plugins/menuStyle/index.js';
import * as specialRolesPlugin from '../plugins/specialRoles/index.js';
import * as specialMenusPlugin from '../plugins/specialMenus/index.js';

let bootstrapped = false;
let bootPromise = null;

export async function bootstrapV2() {
  if (bootstrapped) return registryStats();
  if (bootPromise) return bootPromise;
  bootPromise = (async () => {
    installAntiCrash();
    installLifecycleHandlers();
    logger.info('bootstrap', `Fantasminha ${config.botVersion}`);
    const validation = config.validate();
    if (!validation.ok) logger.warn('bootstrap', 'configuração incompleta', { missing: validation.missing });
    const ver = await runMigrations();
    logger.db('bootstrap', `migrations v${ver}`);

    await bootstrapPlatform();
    registerSystemCommands();
    await fusionCorePlugin.register();
    if (config.features.alem) await alemPlugin.register();
    if (config.features.games) await jogosPlugin.register();
    if (config.features.economy) await economiaPlugin.register();
    await adminPlugin.register();
    await premiumPlugin.register();
    if (config.features.rpg) await rpgPlugin.register();
    await clanPlugin.register();
    if (config.features.downloads) await downloadsPlugin.register();
    await communityPlugin.register();
    await socialPlugin.register();
    await blackjackPlugin.register();
    await volteiPlugin.register();
    await tagsPlugin.register();
    await ownerPowerPlugin.register();
    await menuStylePlugin.register();
  await specialRolesPlugin.register();
    await specialMenusPlugin.register();
    await aranhaPlugin.register();
    await expansionPlugin.register();
    await platformPlugin.register();
    await supportPlugin.register();
    await mediaGenerationPlugin.register();
    await familyPlugin.register();
    await relationshipsPlugin.register();
    await worldEnginePlugin.register();
    await innovationPlugin.register();
    await takeshiCompatPlugin.register();
    await megaFusionPlugin.register();
    await completeExpansionPlugin.register();
    await responseMediaPlugin.register();
    await quizPlugin.register();
    await forcaPlugin.register();
    await stopPlugin.register();
    await garticPlugin.register();
    await rankingPlugin.register();
    await legacyMigrationBatch1Plugin.register();
    await legacyRegistryPlugin.register();
    await reactionManagerPlugin.register();
    await communityFeedbackPlugin.register();
    await nazunaCompatPlugin.register();
    await loadCommandFiles();
    try { await (await import('../games/quiz/QuizService.js')).recover(); } catch (e) { logger.warn('quiz', `recovery: ${e.message}`); }
    try { await (await import('../games/forca/ForcaService.js')).recover(); } catch (e) { logger.warn('forca', `recovery: ${e.message}`); }
    try { await (await import('../games/stop/StopCore.js')).recover(); } catch (e) { logger.warn('stop', `recovery: ${e.message}`); }
    try { await (await import('../games/gartic/GarticService.js')).recover(); } catch (e) { logger.warn('gartic', `recovery: ${e.message}`); }

    const registryValidation = validateRegistry();
    if (!registryValidation.ok) throw new Error(`Registry inválido: ${registryValidation.errors.join('; ')}`);
    startSchedulers();
    bootstrapped = true;
    const stats = registryStats();
    logger.info('bootstrap', 'registry pronto', stats);
    await emit(Events.READY, { version: config.botVersion, stats });
    return stats;
  })();
  try { return await bootPromise; } finally { bootPromise = null; }
}

export function isBootstrapped() { return bootstrapped; }
export default bootstrapV2;
