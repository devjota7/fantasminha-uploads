/**
 * Contrato declarativo de comando.
 * Mantém metadados exclusivos junto da definição, sem duplicar o Registry.
 */

const asArray = value => Array.isArray(value) ? [...value] : [];
const asObject = value => value && typeof value === 'object' ? { ...value } : {};

export function commandResponses(responses = {}) {
  const copy = value => value && typeof value === 'object'
    ? Object.fromEntries(Object.entries(value).map(([key, item]) => [key, copy(item)]))
    : value;
  return Object.freeze(copy(responses));
}

export function interpolateResponse(template, values = {}) {
  if (typeof template !== 'string') throw new TypeError('Resposta deve ser texto');
  return template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_, key) => {
    const value = values[key];
    if (value === undefined || value === null) throw new Error(`Variável de resposta ausente: ${key}`);
    return String(value).replace(/[\u0000-\u001f]/g, '');
  });
}

export function defineCommandContract(definition = {}) {
  if (!definition || typeof definition !== 'object') throw new TypeError('Definição de comando inválida');
  const execute = definition.execute || definition.handler;
  if (typeof execute !== 'function') throw new TypeError('Comando precisa de execute/handler');
  const identity = {
    publicName: definition.publicName || definition.name,
    aliases: asArray(definition.aliases),
    category: definition.category || 'geral',
    description: definition.description || '',
    purpose: definition.purpose || definition.description || '',
    syntax: definition.syntax || definition.usage || '',
    examples: asArray(definition.examples),
    enabled: definition.enabled !== false,
    visibleInMenu: definition.visibleInMenu !== false && !definition.hidden,
    visibleInHelp: definition.visibleInHelp !== false && !definition.hidden,
    configurablePrefix: definition.configurablePrefix !== false
  };
  const authorization = asObject(definition.authorization);
  const validation = asObject(definition.validation);
  const context = asObject(definition.context || definition.contextRequirements);
  return {
    ...definition,
    ...identity,
    authorization,
    validation,
    contextRequirements: context,
    responses: commandResponses(definition.responses),
    tests: asArray(definition.tests),
    handler: execute
  };
}

export default { defineCommandContract, commandResponses, interpolateResponse };
