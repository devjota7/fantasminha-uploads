/** Contrato de comando sobre o Registry único. Não mantém estado próprio. */
import { registerCommand, getCommand, listCommands, runCommand, commandExists } from '../registry.js';

export function defineCommand(definition = {}) {
  if (!definition || typeof definition !== 'object') throw new TypeError('Definição de comando inválida');
  const execute = definition.execute || definition.handler || definition.run;
  if (typeof execute !== 'function') throw new TypeError('Command.execute|run|handler deve ser uma função');
  return registerCommand({
    ...definition,
    handler: execute,
    usage: definition.usage || '',
    aliases: Array.isArray(definition.aliases) ? definition.aliases : []
  });
}

export { getCommand, listCommands, runCommand, commandExists };
export default { defineCommand, getCommand, listCommands, runCommand, commandExists };
