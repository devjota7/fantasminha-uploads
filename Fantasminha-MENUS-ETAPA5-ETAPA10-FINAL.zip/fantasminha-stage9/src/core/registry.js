/** Registry central: única fonte de verdade para comandos V6. */
import { Role, canRun, configuredOwner } from './permissions.js';
import { checkCooldown, setCooldown } from './cooldown.js';
import { CooldownError, PermissionError, withErrorHandler } from './errors.js';
import logger from './logger.js';
import { commandStarted, commandFinished } from './metrics.js';
import { isCommandHidden } from '../platform/commandVisibility.js';
import { isRemovedCommand } from './v2Policy.js';
import { assertSpecialCommandAuthorization } from './specialCommandAuthorization.js';

const commands = new Map();
const aliasMap = new Map();
const executionLocks = new Map();

async function runExclusive(key, fn) {
  const previous = executionLocks.get(key) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  const chain = previous.then(() => current);
  executionLocks.set(key, chain);
  await previous;
  try { return await fn(); }
  finally {
    release();
    if (executionLocks.get(key) === chain) executionLocks.delete(key);
  }
}
const normalize = value => String(value ?? '').trim().toLowerCase();

function cloneContractObject(value) {
  if (!value || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(cloneContractObject);
  return Object.freeze(Object.fromEntries(Object.entries(value).map(([key, item]) => [key, cloneContractObject(item)])));
}

function detachCommand(name) {
  const old = commands.get(name);
  if (!old) return;
  commands.delete(name);
  for (const [alias, target] of aliasMap) if (target === name) aliasMap.delete(alias);
}

export function registerCommand(def) {
  const handler = def?.handler || def?.run;
  if (!def?.name || typeof handler !== 'function') throw new Error('registerCommand: name e handler|run são obrigatórios');
  const name = normalize(def.name);
  if (!name) throw new Error('registerCommand: nome vazio');
  if (isRemovedCommand(name)) return null;

  let aliases = [...new Set((def.aliases || []).map(normalize).filter(Boolean).filter(alias => !isRemovedCommand(alias)))];
  const priority = Number(def.priority || 0);

  // Prioridade determinística: a primeira implementação vence quando as
  // prioridades são iguais; uma camada explicitamente superior pode substituir.
  // Isso elimina o comportamento de 'último plugin carregado vence' que gerava
  // warnings e, principalmente, crashes por aliases concorrentes.
  const existingCanonical = commands.get(name);
  if (existingCanonical) {
    const oldPriority = Number(existingCanonical.priority || 0);
    if (priority <= oldPriority) return existingCanonical;
    detachCommand(name);
  } else {
    // O nome canônico solicitado pode já estar ocupado como ALIAS de outro
    // comando (registrado em outra ordem de carregamento). Para manter a
    // invariante CANONICAL_NAMES ∩ ALIASES = ∅ de forma determinística e
    // independente da ordem de carregamento, aplicamos a mesma regra de
    // prioridade usada acima para colisões canônico-vs-canônico.
    const aliasOwnerName = aliasMap.get(name);
    if (aliasOwnerName && aliasOwnerName !== name) {
      const aliasOwner = commands.get(aliasOwnerName);
      const ownerPriority = Number(aliasOwner?.priority || 0);
      if (priority <= ownerPriority) {
        // Prioridade insuficiente para tomar o nome do dono atual do alias:
        // este registro é descartado e o alias existente permanece intacto.
        return aliasOwner || null;
      }
      // Prioridade suficiente: libera o nome removendo o alias do dono antigo,
      // inclusive da lista de aliases congelada da entrada antiga (senão a
      // validação global voltaria a acusar uma falsa colisão).
      aliasMap.delete(name);
      if (aliasOwner) {
        const prunedEntry = Object.freeze({ ...aliasOwner, aliases: aliasOwner.aliases.filter(a => a !== name) });
        commands.set(aliasOwnerName, prunedEntry);
      }
    }
  }

  // Alias ocupado por outro comando é resolvido por prioridade, assim como
  // canonical-vs-canonical. Uma camada superior toma somente o alias, sem
  // remover o comando inteiro que o possuía.
  aliases = aliases.filter(alias => {
    // Um nome canônico nunca pode virar alias de outro comando. A prioridade
    // pode resolver alias-vs-alias, mas não deve apagar a identidade pública
    // de um comando já registrado (ex.: work vs trabalhar).
    if (commands.has(alias) && alias !== name) return false;
    const existing = aliasMap.get(alias);
    if (!existing || existing === name) return true;
    const owner = commands.get(existing);
    const ownerPriority = Number(owner?.priority || 0);
    if (priority > ownerPriority) {
      if (owner) {
        commands.set(existing, Object.freeze({
          ...owner,
          aliases: owner.aliases.filter(a => a !== alias)
        }));
      }
      aliasMap.delete(alias);
      return true;
    }
    return false;
  });

  const entry = Object.freeze({
    name, aliases, priority,
    publicName: def.publicName || def.name, category: def.category || 'geral', subcategory: def.subcategory || null,
    permission: def.permission ?? Role.USER, cooldown: Number(def.cooldown || 0),
    description: def.description || '', usage: def.usage || '', examples: def.examples || [],
    purpose: def.purpose || def.description || '', syntax: def.syntax || def.usage || '',
    contextRequirements: cloneContractObject(def.contextRequirements || def.context || {}),
    authorization: cloneContractObject(def.authorization || {}),
    validation: cloneContractObject(def.validation || {}),
    responses: cloneContractObject(def.responses || {}),
    tests: Array.isArray(def.tests) ? [...def.tests] : [],
    visibleInMenu: def.visibleInMenu !== false && !def.hidden,
    visibleInHelp: def.visibleInHelp !== false && !def.hidden,
    configurablePrefix: def.configurablePrefix !== false,
    groupOnly: !!def.groupOnly, privateOnly: !!def.privateOnly, ownerOnly: !!def.ownerOnly,
    enabled: def.enabled !== false, plugin: def.plugin || null, version: def.version || null,
    classification: def.classification || def.lifecycle || (def.legacyBridge ? 'LEGACY' : def.hidden ? 'HIDDEN' : 'ACTIVE'),
    specialPermission: def.specialPermission || null,
    specialRoles: Array.isArray(def.specialRoles) ? [...new Set(def.specialRoles.map(normalize).filter(Boolean))] : [],
    legacyBridge: !!def.legacyBridge, responseCapabilities: def.responseCapabilities || null,
    timeoutMs: Number(def.timeoutMs || 30_000), hidden: !!def.hidden,
    audit: def.audit === true || def.permission >= Role.GROUP_ADMIN || def.ownerOnly === true,
    requiresTriage: !!def.requiresTriage, handler, run: handler
  });
  commands.set(name, entry);
  aliasMap.set(name, name);
  for (const alias of aliases) aliasMap.set(alias, name);
  return entry;
}

export function unregisterCommand(name) {
  const key = normalize(name);
  const target = aliasMap.get(key) || key;
  if (!commands.has(target)) return false;
  detachCommand(target);
  return true;
}

export function getCommand(name) {
  const key = aliasMap.get(normalize(name));
  const cmd = key ? commands.get(key) : null;
  return cmd?.enabled ? cmd : null;
}

export function listCommands(filter = {}) {
  let list = [...commands.values()].filter(c => c.enabled && (filter.includeHidden || (!c.hidden && c.visibleInMenu && !isCommandHidden(c.name))));
  if (filter.category) list = list.filter(c => c.category === filter.category);
  if (filter.classification) list = list.filter(c => c.classification === filter.classification);
  if (filter.plugin) list = list.filter(c => c.plugin === filter.plugin);
  return list.sort((a, b) => a.name.localeCompare(b.name));
}

export function categories() { return [...new Set(listCommands().map(c => c.category))].sort(); }

function permissionCategory(cmd) {
  if (cmd.ownerOnly || cmd.permission >= Role.OWNER) return 'PERMISSION_OWNER';
  if (cmd.permission >= Role.BOT_ADMIN) return 'PERMISSION_BOT_ADMIN';
  if (cmd.permission >= Role.GROUP_ADMIN) return 'PERMISSION_GROUP_ADMIN';
  if (cmd.permission >= Role.MODERATOR) return 'PERMISSION_MODERATOR';
  return 'PERMISSION_MEMBER';
}

function validateContext(cmd, ctx = {}) {
  if (cmd.groupOnly && !ctx.isGroup) throw new PermissionError('Este comando só pode ser usado em grupos.', { category: 'GROUP_ONLY' });
  if (cmd.privateOnly && ctx.isGroup) throw new PermissionError('Este comando só pode ser usado no privado.', { category: 'PV_NOT_ALLOWED' });
  if (cmd.ownerOnly && !(ctx.isOwner || configuredOwner(ctx.sender))) throw new PermissionError('Somente o dono pode usar este comando.', { category: 'PERMISSION_OWNER' });
}

async function withTimeout(promise, ms, name) {
  if (!ms || ms <= 0) return promise;
  let timer;
  const timeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error(`Timeout no comando ${name}`)), ms); });
  try { return await Promise.race([promise, timeout]); } finally { clearTimeout(timer); }
}

export async function runCommand(name, ctx = {}) {
  const cmd = getCommand(name);
  if (!cmd) return { found: false };
  validateContext(cmd, ctx);
  await assertSpecialCommandAuthorization(ctx, cmd.name, cmd);
  if (!canRun(ctx, cmd.permission)) throw new PermissionError('Só quem tem cargo suficiente no véu pode usar isto.', { category: permissionCategory(cmd) });

  const lockKey = `${ctx.sender || 'unknown'}:${cmd.name}`;
  return runExclusive(lockKey, async () => {
    const cdSec = Math.ceil(cmd.cooldown * (ctx.cooldownMult || 1));
    const cd = checkCooldown(ctx.sender, cmd.name, cdSec);
    if (!cd.ok) throw new CooldownError(cd.remaining);

    commandStarted(cmd.name);
    const started = Date.now();
    logger.command('registry', cmd.name, { user: ctx.sender, group: ctx.from, category: cmd.category });
    try {
      await withErrorHandler(ctx, async () => {
        await withTimeout(Promise.resolve().then(() => cmd.handler(ctx)), cmd.timeoutMs, cmd.name);
        setCooldown(ctx.sender, cmd.name, cdSec);
      });
      commandFinished(cmd.name, { ok: true, durationMs: Date.now() - started });
      if (cmd.audit) { try { const { recordAudit } = await import('../platform/audit/index.js'); await recordAudit({ actor: ctx.sender || null, target: ctx.from || null, action: `COMMAND:${cmd.name}`, scope: ctx.from || null, requestId: ctx.requestId || null, result: 'success', details: { category: cmd.category, durationMs: Date.now() - started } }); } catch (e) { logger.debug?.('audit', `falha ao registrar comando: ${e.message}`); } }
      return { found: true, name: cmd.name };
    } catch (err) {
      commandFinished(cmd.name, { ok: false, durationMs: Date.now() - started });
      if (cmd.audit) { try { const { recordAudit } = await import('../platform/audit/index.js'); await recordAudit({ actor: ctx.sender || null, target: ctx.from || null, action: `COMMAND:${cmd.name}`, scope: ctx.from || null, requestId: ctx.requestId || null, result: 'error', details: { category: cmd.category, error: err?.message || 'unknown' } }); } catch (e) { logger.debug?.('audit', `falha ao registrar erro: ${e.message}`); } }
      throw err;
    }
  });
}

export function validateRegistry() {
  const errors = [];
  // Duas passagens para tornar a validação independente da ordem de
  // iteração do Map: primeiro coletamos TODOS os nomes canônicos, depois
  // validamos aliases contra o conjunto completo. Antes, um alias só era
  // detectado como colidindo com um comando canônico se esse comando já
  // tivesse sido visitado nesta mesma iteração — um falso-negativo que
  // dependia da ordem de carregamento dos plugins.
  const names = new Set();
  for (const c of commands.values()) {
    if (names.has(c.name)) errors.push(`comando duplicado: ${c.name}`);
    names.add(c.name);
  }
  const aliasOwners = new Map();
  for (const c of commands.values()) {
    if (typeof c.handler !== 'function') errors.push(`${c.name}: handler inválido`);
    for (const a of c.aliases) {
      if (a === c.name) errors.push(`${c.name}: alias igual ao nome`);
      if (names.has(a)) errors.push(`alias colide com comando: ${a}`);
      if (aliasOwners.has(a) && aliasOwners.get(a) !== c.name) errors.push(`alias duplicado: ${a}`);
      aliasOwners.set(a, c.name);
    }
  }
  return { ok: errors.length === 0, errors };
}

export function registryStats() {
  const list = listCommands();
  const canonicalCount = commands.size; const aliasCount = Math.max(0, [...aliasMap.keys()].filter(key => aliasMap.get(key) !== key).length); return { total: canonicalCount, enabled: list.length, disabled: canonicalCount - list.length, categories: categories().length, aliases: aliasCount, valid: validateRegistry().ok };
}

export function clearRegistry() { for (const name of [...commands.keys()]) detachCommand(name); }

export function registerAlias(alias, target) {
  const a = normalize(alias), t = normalize(target);
  if (!a || !t || a === t) return { ok: false, reason: 'invalid' };
  const command = commands.get(t);
  if (!command) return { ok: false, reason: 'target_missing', target: t };
  const existing = aliasMap.get(a);
  if (existing && existing !== t) return { ok: false, reason: 'conflict', existing, target: t };
  if (commands.has(a) && a !== t) return { ok: false, reason: 'command_conflict', existing: a, target: t };
  aliasMap.set(a, t);
  return { ok: true, alias: a, target: t };
}

export function listAliases() {
  return [...aliasMap.entries()].map(([alias, target]) => ({ alias, target })).sort((a,b)=>a.alias.localeCompare(b.alias));
}

export function commandExists(name) { return commands.has(normalize(name)); }

export default { registerCommand, registerAlias, listAliases, unregisterCommand, getCommand, listCommands, categories, runCommand, registryStats, validateRegistry, clearRegistry, commandExists };
