/**
 * Fantasminha — erros centralizados
 */
import logger from './logger.js';
import { response } from './responses.js';

export class FantasmaError extends Error {
  constructor(message, { code = 'FANTASMA_ERROR', userMessage = null, status = 400 } = {}) {
    super(message);
    this.name = 'FantasmaError';
    this.code = code;
    this.userMessage = userMessage || message;
    this.status = status;
  }
}

export class PermissionError extends FantasmaError {
  constructor(msg = 'Sem permissão no submundo.', { category = 'PERMISSION_MEMBER', userMessage = null } = {}) {
    super(msg, { code: 'PERMISSION', userMessage: userMessage || response(category), status: 403 });
  }
}

export class CooldownError extends FantasmaError {
  constructor(seconds) {
    super(`Cooldown ${seconds}s`, {
      code: 'COOLDOWN',
      userMessage: response('COOLDOWN', { time: seconds }),
      status: 429
    });
  }
}

export class TimeoutError extends FantasmaError {
  constructor(msg = 'A operação excedeu o tempo limite.') { super(msg, { code: 'TIMEOUT', userMessage: response('API_TIMEOUT'), status: 504 }); }
}

export class ExternalServiceError extends FantasmaError {
  constructor(msg = 'Serviço externo indisponível.') { super(msg, { code: 'EXTERNAL_SERVICE', userMessage: response('API_ERROR'), status: 502 }); }
}

export class DatabaseError extends FantasmaError {
  constructor(msg = 'Falha ao acessar os dados.') { super(msg, { code: 'DATABASE', userMessage: response('DATABASE_ERROR'), status: 500 }); }
}

export class SessionError extends FantasmaError {
  constructor(msg = 'A sessão do WhatsApp precisa ser recuperada.') { super(msg, { code: 'SESSION', userMessage: response('COMMAND_UNAVAILABLE'), status: 503 }); }
}

export class ValidationError extends FantasmaError {
  constructor(msg, { category = 'INVALID_ARGUMENT', userMessage = null } = {}) {
    super(msg, { code: 'VALIDATION', userMessage: userMessage || response(category), status: 400 });
  }
}

/** middleware de erro: comando → handler → log → resposta */
export async function withErrorHandler(ctx, fn) {
  try {
    return await fn(ctx);
  } catch (err) {
    logger.error('handler', err.message, {
      code: err.code,
      command: ctx?.command,
      stack: err.stack?.split('\n').slice(0, 3).join(' | ')
    });
    const userMsg = err.userMessage || response('INTERNAL_ERROR', { command: ctx?.command });
    if (typeof ctx?.reply === 'function') {
      try {
        await ctx.reply(userMsg);
      } catch (e) {
        logger.error('handler', 'falha ao responder erro', { message: e.message });
      }
      err.__fantasminhaUserErrorHandled = true;
    }
    throw err;
  }
}

export default { FantasmaError, PermissionError, CooldownError, ValidationError, TimeoutError, ExternalServiceError, DatabaseError, SessionError, withErrorHandler };
