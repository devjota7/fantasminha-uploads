import { env } from '../config/env.js';
/**
 * 👻 Fantasminha — resolvedor centralizado de prefixo.
 *
 * ÚNICA fonte de verdade para prefixos efetivos.
 * Prioridade obrigatória: GRUPO -> GLOBAL.
 *
 * Observação: env.PREFIX em Termux pode ser o diretório de instalação;
 * nunca tratamos esse valor como prefixo quando ele parece ser um caminho.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '../..');
const ENV_FILE = path.join(ROOT, '.env');
const CONFIG_FILE = path.join(ROOT, 'dados', 'src', 'config.json');
function groupsDir() {
  return process.env.FANTASMINHA_DB_ROOT
    ? path.join(path.resolve(process.env.FANTASMINHA_DB_ROOT), 'grupos')
    : path.join(ROOT, 'dados', 'database', 'grupos');
}
function dbGroupsFile() {
  return process.env.FANTASMINHA_DB_ROOT
    ? path.join(path.resolve(process.env.FANTASMINHA_DB_ROOT), 'groups.json')
    : path.join(ROOT, 'data', 'db', 'groups.json');
}
const CACHE_TTL_MS = 5000;
const cache = new Map();

function clean(value) { return String(value ?? '').trim(); }

function readEnvValue(name) {
  try {
    if (!fs.existsSync(ENV_FILE)) return '';
    const line = fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/).find(raw => raw.trim().startsWith(`${name}=`));
    if (!line) return '';
    return line.slice(line.indexOf('=') + 1).trim().replace(/^(['"])(.*)\1$/, '$2');
  } catch { return ''; }
}

function readJson(file, fallback = {}) {
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; } catch { return fallback; }
}

function graphemeCount(value) {
  try { return Array.from(new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(value)).length; }
  catch { return Array.from(value).length; }
}

export function isValidBotPrefix(value) {
  const v = clean(value);
  if (!v) return false;
  // Limite por caracteres visíveis (emoji composto conta como 1), não por unidades UTF-16.
  if (graphemeCount(v) > 8 || v.length > 64) return false;
  if (/\s/.test(v)) return false;
  // '/' e '\' sozinhos são prefixos legítimos; só rejeitamos CAMINHOS (ex.: PREFIX do Termux).
  if (v.length > 1 && (v.includes('/') || v.includes('\\'))) return false;
  if (v.startsWith('/data/data/') || v.includes('termux/files')) return false;
  if (v === '$') return false; // reservado: '$' abre o shell do dono.
  return true;
}

export function normalizeBotPrefix(value, fallback = '×') {
  const candidate = clean(value);
  const safeFallback = isValidBotPrefix(fallback) ? clean(fallback) : '×';
  return isValidBotPrefix(candidate) ? candidate : safeFallback;
}

let globalPrefixWarningShown = false;
export function getBotPrefix() {
  const publicCfg = readJson(CONFIG_FILE, {});
  const candidates = [
    readEnvValue('BOT_PREFIX'),
    readEnvValue('PREFIX'),
    env.BOT_PREFIX,
    env.PREFIX,
    publicCfg.prefixo
  ].map(clean).filter(Boolean);
  if (!globalPrefixWarningShown && candidates.some(value => value !== '×')) {
    globalPrefixWarningShown = true;
    console.warn('[PREFIX] prefixo global é fixo em ×; valor configurado ignorado');
  }
  return '×';
}

function groupFile(groupId) {
  const id = clean(groupId);
  if (!id || !id.endsWith('@g.us')) return '';
  return path.join(groupsDir(), `${id}.json`);
}

function loadGroupPrefix(groupId) {
  const file = groupFile(groupId);
  if (file) {
    const data = readJson(file, {});
    if (isValidBotPrefix(data?.customPrefix)) return clean(data.customPrefix);
    if (isValidBotPrefix(data?.prefix)) return clean(data.prefix);
  }
  const db = readJson(dbGroupsFile(), { byId: {} });
  const entry = db?.byId?.[clean(groupId)] || {};
  if (isValidBotPrefix(entry?.customPrefix)) return clean(entry.customPrefix);
  if (isValidBotPrefix(entry?.prefix)) return clean(entry.prefix);
  return '';
}

/**
 * Retorna sempre um prefixo válido.
 * @param {string} groupId
 * @param {{groupConfig?: object, globalPrefix?: string}} options
 */
export function getEffectivePrefix(groupId, options = {}) {
  const id = clean(groupId);
  if (id && id.endsWith('@g.us')) {
    const injected = options?.groupConfig;
    const injectedPrefix = injected && (injected.customPrefix ?? injected.prefix);
    if (isValidBotPrefix(injectedPrefix)) return clean(injectedPrefix);

    const cached = cache.get(id);
    if (cached && cached.expiresAt > Date.now()) return cached.prefix;

    const groupPrefix = loadGroupPrefix(id);
    const globalPrefix = normalizeBotPrefix(options?.globalPrefix, getBotPrefix());
    const effective = isValidBotPrefix(groupPrefix) ? groupPrefix : globalPrefix;
    cache.set(id, { prefix: effective, expiresAt: Date.now() + CACHE_TTL_MS });
    return effective;
  }
  return normalizeBotPrefix(options?.globalPrefix, getBotPrefix());
}

export function invalidatePrefixCache(groupId) {
  const id = clean(groupId);
  if (id) cache.delete(id); else cache.clear();
}

export function clearPrefixCache() { cache.clear(); }

/** Substitui prefixos literais comuns em textos de saída por um prefixo efetivo. */
export function renderCommandText(text, prefix) {
  const value = String(text ?? '');
  const effective = normalizeBotPrefix(prefix, getBotPrefix());
  // Compatibilidade com comandos documentados historicamente com ×.
  const normalized = value.replace(/(^|[\s`*_(>•])×(?=[a-zA-Z][a-zA-Z0-9_.-]*)/g, (_match, boundary) => `${boundary}${effective}`);
  const escaped = effective.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const commandPrefix = new RegExp(`(?<!† )(?<![\\p{L}\\p{N}])${escaped}(?=[\\p{L}\\p{N}][\\p{L}\\p{N}_.-]*)`, 'gu');
  return normalized.replace(commandPrefix, match => `† ${match}`);
}

/** Registra alteração sem criar dependência circular no módulo de configuração. */
export async function auditPrefixChange({ groupId, actor = '', before = null, after = null } = {}) {
  try {
    const { recordAudit } = await import('../platform/audit/index.js');
    return await recordAudit({
      actor: actor || null,
      target: groupId || null,
      action: 'GROUP_PREFIX_CHANGED',
      scope: 'group',
      before: { prefix: before },
      after: { prefix: after },
      details: { groupId, previousPrefix: before, newPrefix: after }
    });
  } catch {
    return null;
  }
}

export default getBotPrefix;
