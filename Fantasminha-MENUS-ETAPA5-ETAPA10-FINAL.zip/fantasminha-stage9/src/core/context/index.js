/** Context arquitetural compatível com o contexto legado do WhatsApp. */
import { enrichMessageContext } from '../messageContext.js';

export function createContext(input = {}) {
  const ctx = enrichMessageContext(input);
  if (!ctx || typeof ctx !== 'object') return ctx;
  ctx.context = ctx.context || {};
  ctx.context.user = ctx.user || null;
  ctx.context.group = ctx.isGroup ? (ctx.from || null) : null;
  ctx.context.membership = ctx.membership || null;
  ctx.context.identity = ctx.identity || null;
  ctx.context.message = ctx.message || null;
  ctx.context.command = ctx.command || null;
  ctx.context.permissions = ctx.permissions || {
    isOwner: !!ctx.isOwner,
    isBotAdmin: !!ctx.isBotAdmin,
    isGroupAdmin: !!ctx.isGroupAdmin,
    isModerator: !!ctx.isModerator,
    isVip: !!(ctx.isVip || ctx.isPremium)
  };
  ctx.context.prefix = ctx.prefix || null;
  ctx.context.isGroup = !!ctx.isGroup;
  ctx.context.isPV = !!(ctx.isPrivate || !ctx.isGroup);
  ctx.context.reply = ctx.reply;
  ctx.context.respond = ctx.respond || ctx.reply;
  ctx.context.logger = ctx.logger || null;
  ctx.context.services = ctx.services || null;
  return ctx;
}

export function contextView(ctx = {}) {
  createContext(ctx);
  return ctx.context;
}

export default { createContext, contextView };
