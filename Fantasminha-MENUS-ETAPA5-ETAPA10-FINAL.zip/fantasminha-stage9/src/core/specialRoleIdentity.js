/**
 * Fachada única para identidade + cargos especiais.
 *
 * Nesta etapa ela usa adaptadores para os armazenamentos existentes:
 * - Dono principal: identidade configurada
 * - Co-Dono: banco legado de donos
 * - Subdono: banco legado de subdonos
 * - Suporte: registro central novo
 * - Aranha: bot_roles por grupo
 * - VIP: entitlement premium do usuário
 *
 * A migração física dos dados legados fica para as etapas posteriores.
 */
import config from './config.js';
import { isDono, isSubdono } from '../../dados/src/utils/database.js';
import { resolveUserIdentity } from '../platform/identity/resolver.js';
import { isMainOwnerIdentityMatch } from '../platform/identity/mainOwnerMatcher.js';
import { getBotRole, BOT_ROLE } from '../services/botRoles.js';
import { getVipPlan } from '../services/vipBenefits.js';
import { hasGlobalRole } from '../services/specialRoleRegistry.js';
import { SPECIAL_ROLE, ADMINISTRATIVE_ROLES, USER_SYSTEM_ROLES } from './specialRoles.js';

function idsFor(identity) {
  return [...new Set([identity?.requested, identity?.realJid, identity?.lid].filter(Boolean))];
}

function isMainOwner(identity, ctx = {}) {
  return isMainOwnerIdentityMatch({
    ownerBase: config.ownerNumber,
    senderOriginal: identity?.requested || ctx.senderOriginal,
    sender: identity?.realJid || ctx.sender,
    senderResolvedPN: identity?.realJid,
    nmrdn: config.ownerNumber,
    ownerJid: config.ownerNumber,
    lidownerAtual: config.ownerLid,
    fromMe: Boolean(ctx.fromMe),
    isBotSender: Boolean(ctx.isBotSender)
  });
}

function matchesLegacy(predicate, identity) {
  return idsFor(identity).some(id => {
    try { return Boolean(predicate(id)); } catch { return false; }
  });
}

export async function resolveSpecialRoleIdentity(ctx = {}, target = null) {
  const identity = await resolveUserIdentity(ctx, target);
  const roles = [];
  const primaryOwner = isMainOwner(identity, ctx);

  if (primaryOwner) roles.push(SPECIAL_ROLE.OWNER);
  else if (matchesLegacy(isDono, identity)) roles.push(SPECIAL_ROLE.CO_OWNER);

  if (matchesLegacy(isSubdono, identity)) roles.push(SPECIAL_ROLE.SUB_OWNER);
  if (idsFor(identity).some(id => hasGlobalRole(id, SPECIAL_ROLE.SUPPORT))) roles.push(SPECIAL_ROLE.SUPPORT);

  const groupId = ctx.from?.endsWith?.('@g.us') ? ctx.from : null;
  if (groupId && identity.realJid && getBotRole(groupId, identity.realJid)?.id === BOT_ROLE.ARANHA) {
    roles.push(SPECIAL_ROLE.ARANHA);
  }
  if (getVipPlan(identity.realJid || identity.requested)) roles.push(SPECIAL_ROLE.VIP);

  const uniqueRoles = [...new Set(roles)];
  const administrativeRoles = uniqueRoles.filter(role => ADMINISTRATIVE_ROLES.includes(role));
  const systemRoles = uniqueRoles.filter(role => USER_SYSTEM_ROLES.includes(role));
  const highestAdministrativeRole = administrativeRoles
    .sort((a, b) => ({ owner: 500, co_owner: 400, sub_owner: 300, support: 200 }[b] || 0) - ({ owner: 500, co_owner: 400, sub_owner: 300, support: 200 }[a] || 0))[0] || null;

  return {
    identity,
    roles: uniqueRoles,
    administrativeRoles,
    systemRoles,
    highestAdministrativeRole,
    isAdministrative: administrativeRoles.length > 0,
    isSystemUser: systemRoles.length > 0
  };
}

export async function getPrimarySpecialRole(ctx = {}, target = null) {
  return (await resolveSpecialRoleIdentity(ctx, target)).highestAdministrativeRole;
}

export async function hasSpecialRole(ctx = {}, target = null, roleId) {
  const resolved = await resolveSpecialRoleIdentity(ctx, target);
  return resolved.roles.includes(String(roleId || '').trim());
}

export async function getSpecialRoleIds(ctx = {}, target = null) {
  return (await resolveSpecialRoleIdentity(ctx, target)).roles;
}

export default { resolveSpecialRoleIdentity, getPrimarySpecialRole, hasSpecialRole, getSpecialRoleIds };
