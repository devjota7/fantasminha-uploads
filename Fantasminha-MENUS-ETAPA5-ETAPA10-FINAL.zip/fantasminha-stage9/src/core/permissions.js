/**
 * COMPATIBILIDADE LEGADA — não confundir com a hierarquia oficial de cargos.
 *
 * A arquitetura nova está em ./specialRoles.js:
 * Dono Principal > Co-Dono > Subdono > Suporte > Usuário.
 * Aranha e VIP são sistemas/status e não autoridade administrativa.
 *
 * Os níveis abaixo permanecem temporariamente para não quebrar comandos
 * legados; a migração desses consumidores ocorrerá nas etapas seguintes.
 */
export const Role = {
  OWNER: 100,
  BOT_ADMIN: 80,
  GROUP_ADMIN: 60,
  MODERATOR: 50,
  VIP: 40,
  ARANHA: 45,
  USER: 10
};

import config, { normalizeOwnerId } from './config.js';
export function configuredOwner(value) {
  const x = normalizeOwnerId(value);
  if (!x) return false;
  const cfg = new Set([
    ...(globalThis.__fantasminhaOwnerIds || []),
    ...(config.ownerIds || []),
    config.ownerNumber,
    config.ownerLid
  ].map(normalizeOwnerId).filter(Boolean));
  return cfg.has(x);
}

export function resolveRole(ctx = {}) {
  if (ctx.isOwner || configuredOwner(ctx.sender)) return Role.OWNER;
  // isBotAdmin descreve a capacidade do bot no grupo; não autentica o remetente.
  // O nível BOT_ADMIN só pode ser alcançado quando o remetente também é admin.
  if (ctx.isGroup && ctx.isBotAdmin && ctx.isGroupAdmin) return Role.BOT_ADMIN;
  if (ctx.isGroupAdmin) return Role.GROUP_ADMIN;
  if (ctx.isModerator) return Role.MODERATOR;
  // Aranha e VIP são status de sistema. Eles nunca elevam o nível
  // administrativo do remetente; benefícios específicos devem usar
  // autorização especial ou checagem de status no próprio recurso.
  return Role.USER;
}

export function canRun(ctx, minRole = Role.USER) {
  return resolveRole(ctx) >= minRole;
}

export function roleName(role) {
  const map = {
    [Role.OWNER]: 'Dono',
    [Role.BOT_ADMIN]: 'Bot Admin',
    [Role.GROUP_ADMIN]: 'Admin',
    [Role.MODERATOR]: 'Moderador',
    [Role.ARANHA]: '🕷️ Aranha',
    [Role.VIP]: 'VIP',
    [Role.USER]: 'Membro'
  };
  return map[role] || 'Membro';
}

export default { Role, resolveRole, canRun, roleName };
