/**
 * Metadados visuais de categorias. Os comandos nunca são mantidos aqui:
 * a lista é derivada do Registry em runtime.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { commandRoot } from './commandLoader.js';
import { listCommands } from './registry.js';

async function walk(dir) {
  const entries = await fs.readdir(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...await walk(full));
    else if (entry.isFile() && entry.name === '_menu.js') files.push(full);
  }
  return files;
}

export async function loadMenuMetadata({ root = commandRoot() } = {}) {
  let files;
  try {
    files = await walk(root);
  } catch (error) {
    if (error.code === 'ENOENT') return new Map();
    throw error;
  }

  const metadata = new Map();
  for (const file of files) {
    const mod = await import(`${pathToFileURL(file).href}?menu-loader=${encodeURIComponent(file)}`);
    const meta = mod.default;
    if (!meta?.category) throw new TypeError(`_menu.js inválido em ${path.relative(root, file)}: category é obrigatório.`);
    const category = String(meta.category).toLowerCase();
    if (metadata.has(category)) throw new Error(`Categoria duplicada em _menu.js: ${category}`);
    metadata.set(category, Object.freeze({
      category,
      title: meta.title || category,
      emoji: meta.emoji || '👻',
      order: Number.isFinite(Number(meta.order)) ? Number(meta.order) : 999
    }));
  }
  return metadata;
}

export async function buildCommandMenus({ includeHidden = false, root = commandRoot() } = {}) {
  const metadata = await loadMenuMetadata({ root });
  const commands = listCommands({ includeHidden });
  const categories = [...new Set(commands.map(command => command.category))];
  return categories
    .map(category => ({
      ...(metadata.get(category) || { category, title: category, emoji: '👻', order: 999 }),
      commands: commands.filter(command => command.category === category)
    }))
    .sort((a, b) => a.order - b.order || a.category.localeCompare(b.category));
}
