/** EventBus arquitetural único: reexporta o barramento existente. */
export { on, emit, Events } from '../../events/index.js';
import bus from '../../events/index.js';
export default bus;
