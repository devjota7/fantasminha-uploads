/**
 * Ponte de migração entre o Registry e a arquitetura oficial de cargos.
 *
 * Etapa 5: a autorização especial é OPT-IN. Comandos legados continuam
 * funcionando pela política antiga até serem migrados individualmente.
 */
import { resolveSpecialRoleIdentity } from './specialRoleIdentity.js';
import { getCommandPermission, canRoleRunCommand, hasRolePermission } from './rolePermissionMatrix.js';

export async function resolveSpecialCommandAuthorization(ctx = {}, commandName, definition = {}) {
  const command = String(commandName || '').trim().toLowerCase();
  const matrixRule = getCommandPermission(command);
  const roles = Array.isArray(definition.specialRoles)
    ? definition.specialRoles.map(String)
    : (matrixRule?.roles || []);
  const permission = definition.specialPermission || matrixRule?.permission || null;

  // Sem regra especial, não interfere no legado.
  if (!permission && roles.length === 0) {
    return { applicable: false, allowed: true, command, permission: null, roles: [] };
  }

  const resolved = await resolveSpecialRoleIdentity(ctx);

  // Defesa contra configuração privilegiada indevida: declarar um cargo em
  // `specialRoles` não pode, sozinho, conceder uma permissão que a matriz
  // oficial não atribui a esse cargo. Isso fecha o caminho de bypass por
  // definição de comando, mantendo VIP/Aranha fora da hierarquia administrativa.
  const explicitlyAllowed = (resolved.roles || []).some(role => {
    if (!roles.includes(role)) return false;
    return !permission || hasRolePermission(role, permission);
  });
  const matrixAllowed = (resolved.roles || []).some(role => canRoleRunCommand(role, command) === true);
  const allowed = explicitlyAllowed || matrixAllowed;

  return {
    applicable: true,
    allowed,
    command,
    permission,
    roles,
    resolved
  };
}

export async function assertSpecialCommandAuthorization(ctx = {}, commandName, definition = {}) {
  const result = await resolveSpecialCommandAuthorization(ctx, commandName, definition);
  if (result.applicable && !result.allowed) {
    const error = new Error('Permissão de cargo especial insuficiente.');
    error.code = 'SPECIAL_ROLE_PERMISSION_DENIED';
    error.authorization = result;
    throw error;
  }
  return result;
}

export default { resolveSpecialCommandAuthorization, assertSpecialCommandAuthorization };
