import { env as defaultEnv } from '../config/env.js';
/**
 * Política central para recursos de execução arbitrária do proprietário.
 *
 * Segurança: ambos os gates permanecem DESLIGADOS por padrão. A ativação
 * exige explicitamente o valor textual "true" e uma identidade de owner já
 * validada pelo pipeline.
 */
function envFlag(env, key) {
  return String(env?.[key] ?? '').trim().toLowerCase() === 'true';
}

export function ownerShellAllowed({ isOwner = false, env = defaultEnv } = {}) {
  return Boolean(isOwner) && envFlag(env, 'ALLOW_OWNER_SHELL');
}

export function ownerEvalAllowed({ isOwner = false, env = defaultEnv } = {}) {
  return Boolean(isOwner) && envFlag(env, 'ALLOW_OWNER_EVAL');
}

export function ownerExecutionPolicy(env = defaultEnv) {
  return Object.freeze({
    shellEnabled: envFlag(env, 'ALLOW_OWNER_SHELL'),
    evalEnabled: envFlag(env, 'ALLOW_OWNER_EVAL'),
    defaultShellEnabled: false,
    defaultEvalEnabled: false
  });
}
