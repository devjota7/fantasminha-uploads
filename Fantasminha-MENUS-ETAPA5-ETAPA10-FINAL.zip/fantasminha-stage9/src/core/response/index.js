/** Response Engine oficial. O catálogo único permanece em ../responses.js. */
export { response, responseCatalog, responseCategories, resetResponseRotation } from '../responses.js';
import engine from '../responses.js';
export default engine;
