/** Contrato de erros arquitetural sobre o sistema central existente. */
export * from '../errors.js';
import errors from '../errors.js';
export default errors;
