/**
 * Catálogo central de respostas do Fantasminha.
 *
 * Este módulo só formata texto: não conhece permissões, banco, APIs ou jogos.
 * A seleção é round-robin por categoria/contexto para evitar repetição imediata
 * sem introduzir aleatoriedade não determinística nos testes.
 */

const catalogSource = {
  COMMAND_NOT_FOUND: [
    '👻 Procurei esse comando no além. Nem os mortos conhecem.',
    '👻 O véu se abriu, mas esse comando não estava do outro lado.',
    '👻 Esse comando não consta nos meus registros espectrais.',
    '👻 A invocação chegou sem nome reconhecível. Tente outro comando.',
    '👻 O além recebeu seu pedido, mas não encontrou esse comando.',
    '👻 Comando ausente. Até os fantasmas precisam de um nome válido.'
  ],
  COMMAND_INVALID: [
    '👻 A invocação não pôde ser reconhecida.',
    '👻 O comando atravessou o véu de forma inválida.',
    '👻 Ritual inválido. Confira o comando e tente novamente.',
    '👻 Essa forma de invocação não pertence aos registros ativos.'
  ],
  COMMAND_USAGE: [
    '👻 O ritual está quase certo. Só faltou o argumento correto.',
    '👻 Invocação incompleta. Use: {usage}',
    '👻 O comando ouviu você, mas precisa de mais detalhes. Use: {usage}',
    '👻 Falta uma peça nesse ritual. Forma correta: {usage}'
  ],
  COMMAND_DISABLED: [
    '👻 Esse comando está adormecido no além no momento.',
    '👻 O ritual foi temporariamente selado.',
    '👻 Comando indisponível: o véu ainda não autorizou esta passagem.'
  ],
  COMMAND_UNAVAILABLE: [
    '👻 Esse recurso está indisponível agora. Tente novamente em instantes.',
    '👻 A passagem está fechada no momento. Tente mais tarde.',
    '👻 O além não conseguiu liberar esse recurso agora.'
  ],
  PERMISSION_OWNER: [
    '👻 Este comando é exclusivo do dono.',
    '👻 Somente o dono pode executar esta ação.',
    '👻 A hierarquia reserva este comando ao dono.'
  ],
  PERMISSION_BOT_ADMIN: [
    '👻 O bot precisa ser administrador do grupo para concluir esta ação.',
    '👻 Este comando exige autoridade administrativa do bot.',
    '👻 Defina o bot como administrador e tente novamente.'
  ],
  PERMISSION_GROUP_OWNER: [
    '👻 Este comando é exclusivo do dono do grupo.',
    '👻 Somente o proprietário do grupo pode concluir esta ação.',
    '👻 A hierarquia do grupo reserva esta operação ao dono.'
  ],
  PERMISSION_GROUP_ADMIN: [
    '👻 Este comando exige que você seja administrador do grupo.',
    '👻 A permissão de administrador do grupo é necessária.',
    '👻 A hierarquia do grupo não autorizou esta ação para seu cargo.'
  ],
  PERMISSION_MODERATOR: [
    '👻 Este comando exige patente de moderador.',
    '👻 Somente moderadores podem concluir esta ação.',
    '👻 A permissão de moderador é necessária para prosseguir.'
  ],
  PERMISSION_MEMBER: [
    '👻 Seu cargo atual não tem permissão para executar este comando.',
    '👻 Esta ação exige um nível de acesso superior.',
    '👻 A hierarquia do grupo bloqueou este comando para seu cargo atual.'
  ],
  GROUP_ONLY: [
    '👻 Este comando só pode ser usado em grupos.',
    '👻 A ação requer uma conversa em grupo.',
    '👻 Uso restrito a grupos; esta conversa privada não é compatível.'
  ],
  PV_BLOCKED: [
    '👻 O uso deste comando por mensagem privada não está liberado.',
    '👻 Esta conversa privada não possui autorização para executar o comando.',
    '👻 O acesso privado está bloqueado para esta ação.'
  ],
  PV_NOT_ALLOWED: [
    '👻 Este comando não está autorizado para uso no privado.',
    '👻 Esta ação precisa ser executada no grupo correto.',
    '👻 O contexto privado não tem permissão para este comando.'
  ],
  OWNER_COMMAND_ATTEMPT: [
    '👻 Esta ação exige autorização do dono.',
    '👻 O comando é reservado ao dono da instância.',
    '👻 A hierarquia bloqueou esta ação; somente o dono pode prosseguir.'
  ],
  ADMIN_COMMAND_ATTEMPT: [
    '👻 Esta ação exige permissões administrativas no grupo.',
    '👻 A hierarquia do grupo não autorizou a operação para seu cargo.',
    '👻 Somente um administrador do grupo pode concluir esta ação.'
  ],
  USER_NOT_FOUND: [
    '👻 Não encontrei essa alma nos registros.',
    '👻 O usuário desapareceu do mapa espectral.',
    '👻 Nenhuma identidade correspondente foi localizada.'
  ],
  MEMBER_NOT_FOUND: [
    '👻 Esse membro não foi encontrado neste grupo.',
    '👻 A alma procurada não pertence aos registros deste grupo.',
    '👻 Não localizei esse membro entre os presentes.'
  ],
  GROUP_NOT_FOUND: [
    '👻 Não encontrei esse grupo nos registros.',
    '👻 A sala indicada não atravessou o véu.',
    '👻 Grupo não localizado. Confira o contexto e tente novamente.'
  ],
  ALREADY_ACTIVE: ['👻 Isso já está ativo.', '👻 O ritual já está em funcionamento.', '👻 Ativação desnecessária: a entidade já despertou.'],
  ALREADY_RUNNING: ['👻 Já existe uma sessão em andamento.', '👻 O ritual já está rodando. Não invoque uma segunda cópia.', '👻 Aguarde: essa atividade já começou.'],
  ALREADY_EXISTS: ['👻 Esse registro já existe.', '👻 Nada novo foi criado: essa presença já está nos arquivos.', '👻 O além já conhece esse registro.'],
  ALREADY_JOINED: ['👻 Você já entrou nessa sessão.', '👻 Sua alma já está registrada aqui.', '👻 Entrada duplicada detectada — você já participa.'],
  NOT_ACTIVE: ['👻 Isso ainda não está ativo.', '👻 A entidade permanece adormecida.', '👻 Não há ativação para encerrar neste momento.'],
  NOT_RUNNING: ['👻 Não existe uma sessão em andamento.', '👻 O ritual não está rodando agora.', '👻 O além está quieto: nada está em execução.'],
  NOT_FOUND: ['👻 Não encontrei o registro solicitado.', '👻 Essa presença não consta nos arquivos.', '👻 Procurei além do véu, mas não localizei.'],
  COOLDOWN: [
    '👻 Calma, mortal. Até fantasma precisa de intervalo. Aguarde {time}s.',
    '👻 O comando ainda está se recuperando da última aparição. Aguarde {time}s.',
    '👻 Você está invocando rápido demais. Próxima aparição em {time}s.',
    '👻 Intervalo espectral: tente novamente em {time}s.',
    '👻 O ectoplasma pediu uma pausa. Restam {time}s.'
  ],
  RATE_LIMIT: [
    '👻 Muitas invocações em pouco tempo. Aguarde {time}s.',
    '👻 O véu detectou uma rajada. Tente novamente em {time}s.',
    '👻 Ritmo reduzido, mortal: o limite retorna em {time}s.',
    '👻 Até fantasmas precisam controlar o fluxo. Aguarde {time}s.'
  ],
  USER_LIMIT: ['👻 Seu limite foi alcançado: {used}/{limit}.', '👻 Chega por agora, mortal: {used}/{limit}.', '👻 O estoque de invocações acabou: {used}/{limit}.'],
  PLAY_LIMIT: ['👻 O limite de partidas foi atingido: {used}/{limit}.', '👻 O tabuleiro entrou em contenção: {used}/{limit}.', '👻 Partidas usadas: {used}/{limit}. Tente novamente depois.'],
  MISSING_ARGUMENT: ['👻 Falta um argumento para completar o ritual.', '👻 A invocação está incompleta. Informe o argumento necessário.', '👻 Quase lá: falta um detalhe no comando.'],
  INVALID_ARGUMENT: ['👻 Argumento inválido. Confira o formato e tente novamente.', '👻 Esse argumento não atravessou a validação do véu.', '👻 Ritual inválido: use os valores aceitos pelo comando.'],
  INVALID_NUMBER: ['👻 Preciso de um número válido para continuar.', '👻 Esse valor não parece um número do nosso plano astral.', '👻 Número inválido. Informe um valor numérico.'],
  INVALID_OPTION: ['👻 Essa opção não existe neste ritual.', '👻 Opção inválida. Escolha uma das alternativas disponíveis.', '👻 O véu não reconhece essa escolha.'],
  API_ERROR: ['👻 A entidade externa respondeu com erro. Tente novamente.', '👻 A API falhou durante a invocação. Tente mais tarde.', '👻 O serviço externo não concluiu o pedido.'],
  API_TIMEOUT: ['👻 O além está demorando para responder. Tente novamente.', '👻 A entidade externa ficou em silêncio além do limite.', '👻 A invocação expirou antes da resposta chegar.'],
  API_OFFLINE: ['👻 A entidade externa desapareceu. Tente novamente em instantes.', '👻 O serviço externo está indisponível agora.', '👻 A passagem para a API está fechada neste momento.'],
  API_LIMIT: ['👻 O limite da entidade externa foi alcançado. Tente mais tarde.', '👻 A API entrou em contenção de invocações.', '👻 O serviço externo pediu um intervalo antes da próxima chamada.'],
  DATABASE_ERROR: ['👻 Algo se rompeu no além dos dados. Tente novamente.', '👻 Não consegui consultar os registros agora.', '👻 O arquivo espectral recusou a operação. Tente novamente.'],
  DATABASE_BUSY: ['👻 Os registros estão ocupados. Aguarde um instante.', '👻 O arquivo espectral está recebendo outra invocação.', '👻 Banco ocupado: tente novamente em breve.'],
  DATABASE_RECOVERY: ['👻 Os registros estão se recuperando. Tente novamente em instantes.', '👻 O banco entrou em recuperação segura.', '👻 O arquivo foi protegido e está voltando do além.'],
  GAME_ERROR: ['👻 O jogo encontrou uma assombração inesperada.', '👻 Algo saiu do tabuleiro. Tente iniciar novamente.', '👻 A partida sofreu uma interferência espectral.'],
  GAME_ALREADY_RUNNING: ['👻 Já existe uma partida em andamento neste grupo.', '👻 O tabuleiro já está ocupado por outra partida.', '👻 Não invoque outra partida enquanto esta ainda estiver viva.'],
  GAME_NOT_RUNNING: ['👻 Não há partida ativa neste grupo.', '👻 O tabuleiro está vazio no momento.', '👻 Nenhum jogo está em andamento para receber essa jogada.'],
  GAME_FULL: ['👻 A partida atingiu a capacidade máxima.', '👻 Não há mais lugares no tabuleiro.', '👻 O jogo está cheio — nem uma alma extra cabe aqui.'],
  GAME_EXPIRED: ['👻 Essa partida expirou e foi encerrada.', '👻 O tempo do jogo atravessou o véu e acabou.', '👻 Sessão expirada. Inicie uma nova partida.'],
  PREMIUM_REQUIRED: ['👻 Este recurso exige Premium.', '👻 Seu plano atual não libera este recurso.', '👻 Ative Premium para usar este recurso.'],
  PREMIUM_EXPIRED: ['👻 A autorização Premium expirou.', '👻 Seu período Premium terminou.', '👻 Renove Premium para voltar a usar este recurso.'],
  OWNER_ONLY: ['👻 Este comando é exclusivo do dono.', '👻 Somente o dono pode executar esta ação.', '👻 A hierarquia reserva este comando ao dono.'],
  BOT_ADMIN_ONLY: ['👻 O bot precisa ser administrador do grupo para concluir esta ação.', '👻 Este comando exige autoridade administrativa do bot.', '👻 Defina o bot como administrador e tente novamente.'],
  ADMIN_ONLY: ['👻 Este comando exige administração do grupo.', '👻 Somente administradores podem concluir esta ação.', '👻 A hierarquia do grupo não autorizou esta ação para seu cargo.'],
  MODERATOR_ONLY: ['👻 Este comando exige patente de moderador.', '👻 Somente moderadores podem concluir esta ação.', '👻 A permissão de moderador é necessária para prosseguir.'],
  SUCCESS: ['👻 Invocação concluída.', '👻 O ritual funcionou.', '👻 Feito. O além aprovou.', '👻 Registrado nas sombras.', '👻 Pronto. Nem precisei assustar ninguém.'],
  DONE: ['👻 Concluído.', '👻 Feito. O véu está em ordem.', '👻 Ritual encerrado com sucesso.'],
  SAVED: ['👻 Salvo nos registros espectrais.', '👻 Informação guardada nas sombras.', '👻 Registro atualizado e preservado.'],
  REMOVED: ['👻 Removido do além.', '👻 Registro apagado com segurança.', '👻 A presença foi retirada dos arquivos.'],
  UPDATED: ['👻 Atualização concluída.', '👻 Os registros foram renovados.', '👻 Mudança aplicada nas sombras.'],
  GENERIC_ERROR: ['👻 Algo se rompeu no além. Tente novamente em instantes.', '👻 O véu engasgou. Tente novamente.', '👻 Uma interferência espectral impediu a operação.', '👻 Não saiu como planejado. Tente novamente.'],
  UNKNOWN_ERROR: ['👻 O além encontrou algo inesperado. Tente novamente.', '👻 Falha desconhecida detectada nas sombras.', '👻 Nem o Fantasminha reconheceu essa assombração.'],
  INTERNAL_ERROR: ['👻 Ocorreu um erro interno. Tente novamente em instantes.', '👻 Algo se rompeu nos bastidores do além.', '👻 A operação falhou internamente; tente novamente mais tarde.']
};

const catalog = Object.freeze(Object.fromEntries(
  Object.entries(catalogSource).map(([key, variants]) => [
    key,
    Object.freeze(variants.map(template => String(template).replace(/^👻\s*/u, '')))
  ])
));

const marked = (marker, keys) => Object.fromEntries(keys.map(key => [key, marker]));
const RESPONSE_MARKERS = Object.freeze({
  ...marked('❌', ['COMMAND_NOT_FOUND', 'COMMAND_INVALID', 'API_ERROR', 'API_TIMEOUT', 'API_OFFLINE', 'API_LIMIT', 'DATABASE_ERROR', 'DATABASE_RECOVERY', 'GAME_ERROR', 'GENERIC_ERROR', 'UNKNOWN_ERROR', 'INTERNAL_ERROR']),
  ...marked('⚠️', ['COMMAND_DISABLED', 'COMMAND_UNAVAILABLE', 'RATE_LIMIT', 'USER_LIMIT', 'PLAY_LIMIT', 'GAME_ALREADY_RUNNING', 'GAME_NOT_RUNNING', 'GAME_FULL', 'GAME_EXPIRED']),
  ...marked('🔒 Permissão negada:', ['PERMISSION_OWNER', 'PERMISSION_BOT_ADMIN', 'PERMISSION_GROUP_OWNER', 'PERMISSION_GROUP_ADMIN', 'PERMISSION_MODERATOR', 'PERMISSION_MEMBER', 'GROUP_ONLY', 'PV_BLOCKED', 'PV_NOT_ALLOWED', 'OWNER_COMMAND_ATTEMPT', 'ADMIN_COMMAND_ATTEMPT', 'PREMIUM_REQUIRED', 'PREMIUM_EXPIRED', 'OWNER_ONLY', 'BOT_ADMIN_ONLY', 'ADMIN_ONLY', 'MODERATOR_ONLY']),
  ...marked('💡 Uso:', ['COMMAND_USAGE', 'MISSING_ARGUMENT', 'INVALID_ARGUMENT', 'INVALID_NUMBER', 'INVALID_OPTION']),
  ...marked('⏳', ['COOLDOWN']),
  ...marked('ℹ️', ['USER_NOT_FOUND', 'MEMBER_NOT_FOUND', 'GROUP_NOT_FOUND', 'ALREADY_ACTIVE', 'ALREADY_RUNNING', 'ALREADY_EXISTS', 'ALREADY_JOINED', 'NOT_ACTIVE', 'NOT_RUNNING', 'NOT_FOUND', 'DATABASE_BUSY']),
  ...marked('✅', ['SUCCESS', 'DONE', 'SAVED', 'REMOVED', 'UPDATED'])
});

const cursors = new Map();
const fallback = '👻 O véu está instável. Tente novamente em instantes.';

function safeValue(value) {
  if (value === null || value === undefined) return '';
  return String(value);
}

function render(template, context = {}) {
  const values = { ...context, time: context.time ?? context.remaining ?? '' };
  return template.replace(/\{([a-zA-Z0-9_]+)\}/g, (_, key) => safeValue(values[key]));
}

export function response(category, context = {}) {
  const key = String(category || 'GENERIC_ERROR').toUpperCase();
  const variants = catalog[key] || catalog.GENERIC_ERROR;
  const rotationKey = `${key}:${context.rotationKey || context.command || context.user || 'global'}`;
  const cursor = cursors.get(rotationKey) || 0;
  const template = variants[cursor % variants.length];
  cursors.set(rotationKey, (cursor + 1) % variants.length);
  const message = render(template, context);
  const marker = RESPONSE_MARKERS[key];
  return marker ? `${marker} ${message}` : message;
}

export function responseCatalog() {
  return Object.fromEntries(Object.entries(catalog).map(([key, variants]) => [key, [...variants]]));
}

export function responseCategories() { return Object.keys(catalog); }
export function resetResponseRotation() { cursors.clear(); }

export default Object.freeze({ response, responseCatalog, responseCategories, resetResponseRotation });
