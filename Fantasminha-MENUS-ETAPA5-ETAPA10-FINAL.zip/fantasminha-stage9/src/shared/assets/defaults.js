import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const MODULE_DIR = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(MODULE_DIR, '../../..');
const DEFAULTS_ROOT = path.join(PROJECT_ROOT, 'assets', 'defaults');
const PROFILE_PATH = path.join(DEFAULTS_ROOT, 'perfil-padrao.jpg');
const MENU_PATH = path.join(DEFAULTS_ROOT, 'menu-padrao.jpg');

let profileCache;
let menuCache;
let warnedProfile = false;
let warnedMenu = false;

function warnOnce(kind, error) {
  const state = kind === 'profile' ? 'warnedProfile' : 'warnedMenu';
  if (kind === 'profile' ? warnedProfile : warnedMenu) return;
  if (kind === 'profile') warnedProfile = true;
  else warnedMenu = true;
  console.warn(`[DEFAULT-ASSETS] Falha ao carregar ${kind}: ${error?.message || error}`);
}

function readAsset(filePath, kind, cacheState) {
  if (cacheState.value !== undefined) return cacheState.value;
  try {
    if (!fs.existsSync(filePath)) {
      cacheState.value = null;
      warnOnce(kind, new Error(`arquivo ausente: ${filePath}`));
      return null;
    }
    const buffer = fs.readFileSync(filePath);
    if (!buffer.length) {
      cacheState.value = null;
      warnOnce(kind, new Error(`arquivo vazio: ${filePath}`));
      return null;
    }
    cacheState.value = buffer;
    return buffer;
  } catch (error) {
    cacheState.value = null;
    warnOnce(kind, error);
    return null;
  }
}

export function getDefaultProfilePhotoPath() {
  return PROFILE_PATH;
}

export function getDefaultMenuMediaPath() {
  return MENU_PATH;
}

export function readDefaultProfilePhoto() {
  const state = { value: profileCache };
  const result = readAsset(PROFILE_PATH, 'profile', state);
  profileCache = state.value;
  return result;
}

export function readDefaultMenuMedia() {
  const state = { value: menuCache };
  const result = readAsset(MENU_PATH, 'menu', state);
  menuCache = state.value;
  return result;
}

export async function profilePhotoOrDefault(ctx = {}, jid) {
  try {
    const profile = await ctx?.profilePictureUrl?.(jid);
    if (profile) return profile;
  } catch (error) {
    warnOnce('profile', error);
  }
  return readDefaultProfilePhoto();
}

export function createDefaultAssetResolver(root = DEFAULTS_ROOT) {
  const base = path.resolve(root);
  const profilePath = path.join(base, 'perfil-padrao.jpg');
  const menuPath = path.join(base, 'menu-padrao.jpg');
  let profile;
  let menu;
  const read = (filePath, current) => {
    if (current.value !== undefined) return current.value;
    try {
      if (!fs.existsSync(filePath)) return (current.value = null);
      const buffer = fs.readFileSync(filePath);
      return (current.value = buffer.length ? buffer : null);
    } catch {
      return (current.value = null);
    }
  };
  return {
    getDefaultProfilePhotoPath: () => profilePath,
    getDefaultMenuMediaPath: () => menuPath,
    readDefaultProfilePhoto: () => read(profilePath, { get value() { return profile; }, set value(v) { profile = v; } }),
    readDefaultMenuMedia: () => read(menuPath, { get value() { return menu; }, set value(v) { menu = v; } })
  };
}

export default {
  getDefaultProfilePhotoPath,
  getDefaultMenuMediaPath,
  readDefaultProfilePhoto,
  readDefaultMenuMedia,
  profilePhotoOrDefault,
  createDefaultAssetResolver
};
