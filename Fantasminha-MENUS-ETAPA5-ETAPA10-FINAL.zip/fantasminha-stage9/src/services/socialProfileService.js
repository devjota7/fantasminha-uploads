import { readCollection, updateCollection } from '../database/store.js';
const D={users:{},total:0,day:null,today:0};
export function ranking(limit=5){const d=readCollection('mega_stats',D);return Object.entries(d.users||{}).sort((a,b)=>b[1]-a[1]).slice(0,limit);}
export async function record(userId,amount=1){return updateCollection('mega_stats',d=>{d.users??={};d.total=Number(d.total||0)+amount;const day=new Date().toISOString().slice(0,10);if(d.day!==day){d.day=day;d.today=0}d.today=Number(d.today||0)+amount;d.users[userId]=Number(d.users[userId]||0)+amount;return d;},D);}
export function snapshot(){const d=readCollection('mega_stats',D);return {...d,ranking:ranking(5)};}
export default {ranking,record,snapshot};
