import logger from '../core/logger.js';
import config from '../core/config.js';

let timer = null;

export function startSchedulers() {
  if (timer) return;
  // Não há backup automático de banco: evita crescimento de armazenamento no Android/Termux.
  // O mecanismo de rollback de código do updater permanece independente deste scheduler.

  // Partidas com timeout: encerramento automático e persistente.
  const gameTimer = setInterval(async () => {
    try { const { expireGames } = await import('./gameEngine.js'); const n = await expireGames(); if (n) logger.info('games', `partidas expiradas: ${n}`); }
    catch (e) { logger.error('games', 'game expiry: ' + e.message); }
  }, 30_000);
  gameTimer.unref?.();

  // Quiz: remove mídia temporária órfã sem manter arquivos indefinidamente.
  const quizCleanupTimer = setInterval(async () => {
    try { const { cleanupOrphans } = await import('../games/quiz/QuizCleanupService.js'); const n = await cleanupOrphans(); if (n) logger.info('quiz', `mídias órfãs removidas: ${n}`); }
    catch (e) { logger.error('quiz', 'cleanup: ' + e.message); }
  }, 10 * 60_000);
  quizCleanupTimer.unref?.();

  const stopRecoveryTimer = setInterval(async () => {
    try { const { recover } = await import('../games/stop/StopCore.js'); await recover(); }
    catch (e) { logger.error('stop', 'recovery tick: ' + e.message); }
  }, 15_000);
  stopRecoveryTimer.unref?.();

  const garticCleanupTimer = setInterval(async () => {
    try {
      const { cleanupOrphans } = await import('../games/gartic/GarticCleanupService.js');
      const removed = await cleanupOrphans();
      // cleanupOrphans() retorna um array; [] é truthy em JavaScript.
      // Só registra quando alguma mídia realmente foi removida.
      if (Array.isArray(removed) && removed.length > 0) {
        logger.info('gartic', `mídias órfãs removidas: ${removed.length}`);
      }
    } catch (e) {
      logger.error('gartic', 'cleanup: ' + e.message);
    }
  }, 10 * 60_000);
  garticCleanupTimer.unref?.();

  // premium expiry soft check hourly
  setInterval(async () => {
    try {
      const { readCollection, writeCollection } = await import('../database/store.js');
      const users = readCollection('users', { byId: {} });
      let changed = false;
      const now = Date.now();
      for (const u of Object.values(users.byId || {})) {
        if (u.premium?.active && u.premium.until && u.premium.until < now) {
          u.premium.active = false;
          changed = true;
        }
      }
      if (changed) writeCollection('users', users);
    } catch (e) {
      logger.error('scheduler', 'premium expiry: ' + e.message);
    }
  }, 3600 * 1000).unref?.();

  // Marca a inicialização depois de instalar a cadeia de intervalos.
  timer = gameTimer;
}

export default { startSchedulers };
