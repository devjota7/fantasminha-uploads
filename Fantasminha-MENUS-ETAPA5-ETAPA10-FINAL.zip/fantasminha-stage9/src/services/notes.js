import { randomUUID, createHash } from 'node:crypto';
import { readCollection, updateCollection } from '../database/store.js';

const COLLECTION = 'user_notes';
const DEFAULTS = { byUser: {} };
const MAX_NAME = 40;
const MAX_TEXT = 2000;
const MAX_NOTES = 50;

const normalizeName = (name) => String(name || '').trim().toLocaleLowerCase('pt-BR').slice(0, MAX_NAME);
const displayName = (name) => String(name || '').trim().replace(/\s+/g, ' ').slice(0, MAX_NAME);

function keyOf(name) {
  return normalizeName(name);
}

function stableLegacyId(userId, name) {
  return `note-${createHash('sha256').update(`${userId}\0${keyOf(name)}`).digest('hex').slice(0, 24)}`;
}

function ensureInternalId(note, userId, name) {
  return note?.id || stableLegacyId(userId, name);
}

function readUser(userId) {
  const db = readCollection(COLLECTION, DEFAULTS);
  return db.byUser?.[userId] || {};
}

export function listNotes(userId) {
  return Object.entries(readUser(userId))
    .map(([key, note]) => ({ ...note, id: ensureInternalId(note, userId, key) }))
    .sort((a, b) => (b.updatedAt || b.createdAt || 0) - (a.updatedAt || a.createdAt || 0));
}

export function getNote(userId, name) {
  const key = keyOf(name);
  if (!key) return null;
  const note = readUser(userId)[key];
  return note ? { ...note, id: ensureInternalId(note, userId, key) } : null;
}

export function getNoteByPosition(userId, position) {
  const index = Number(position);
  if (!Number.isInteger(index) || index < 1) return null;
  return listNotes(userId)[index - 1] || null;
}

export function resolveNote(userId, reference) {
  const raw = String(reference || '').trim();
  if (!raw) return null;
  if (/^\d+$/.test(raw)) return getNoteByPosition(userId, raw);
  return getNote(userId, raw);
}

export function parseNoteDirectInput(raw) {
  const value = String(raw || '').trim();
  const separator = value.indexOf('|');
  if (separator < 0) return { name: value, text: '', hasSeparator: false };
  return {
    name: value.slice(0, separator).trim(),
    text: value.slice(separator + 1).trim(),
    hasSeparator: true,
  };
}

export async function addNote({ userId, name, text }) {
  if (!userId || !displayName(name) || !String(text || '').trim()) throw new Error('Informe o nome e o conteúdo da nota.');
  const cleanName = displayName(name);
  const key = keyOf(cleanName);
  const cleanText = String(text).trim().slice(0, MAX_TEXT);
  let result = null;
  await updateCollection(COLLECTION, db => {
    db.byUser ||= {};
    db.byUser[userId] ||= {};
    if (db.byUser[userId][key]) return db;
    if (Object.keys(db.byUser[userId]).length >= MAX_NOTES) throw new Error(`Você já atingiu o limite de ${MAX_NOTES} notas.`);
    const now = Date.now();
    result = { id: randomUUID(), name: cleanName, text: cleanText, createdAt: now, updatedAt: now };
    db.byUser[userId][key] = result;
    return db;
  }, DEFAULTS);
  return result;
}

export async function editNote({ userId, name, text, noteId = null }) {
  if (!userId || !keyOf(name) || !String(text || '').trim()) throw new Error('Informe o nome e o novo conteúdo da nota.');
  const key = keyOf(name);
  let result = null;
  await updateCollection(COLLECTION, db => {
    db.byUser ||= {};
    db.byUser[userId] ||= {};
    const currentKey = noteId
      ? Object.keys(db.byUser[userId]).find(k => db.byUser[userId][k]?.id === noteId)
      : key;
    const current = currentKey ? db.byUser[userId][currentKey] : null;
    if (!current) return db;
    result = { ...current, text: String(text).trim().slice(0, MAX_TEXT), updatedAt: Date.now() };
    db.byUser[userId][currentKey] = result;
    return db;
  }, DEFAULTS);
  return result;
}

export async function removeNote(userId, name, noteId = null) {
  const key = keyOf(name);
  if (!userId || !key) return false;
  let removed = false;
  await updateCollection(COLLECTION, db => {
    db.byUser ||= {};
    db.byUser[userId] ||= {};
    const currentKey = noteId
      ? Object.keys(db.byUser[userId]).find(k => db.byUser[userId][k]?.id === noteId)
      : key;
    if (currentKey && db.byUser[userId][currentKey]) {
      delete db.byUser[userId][currentKey];
      removed = true;
    }
    return db;
  }, DEFAULTS);
  return removed;
}

export async function migrateLegacyNotes() {
  const legacyNotes = readCollection('notes', { items: {} }).items || {};
  const legacyPersonal = readCollection('personal_notes', { byUser: {} }).byUser || {};
  let migrated = 0;
  await updateCollection(COLLECTION, db => {
    db.byUser ||= {};
    for (const note of Object.values(legacyNotes)) {
      const scope = String(note?.scope || '');
      const userId = scope.startsWith('user:') ? scope.slice(5) : (note?.actor || '');
      if (!userId || !note?.name || !note?.text) continue;
      const key = keyOf(note.name);
      db.byUser[userId] ||= {};
      if (!db.byUser[userId][key]) {
        const at = Number(note.updatedAt || Date.now());
        db.byUser[userId][key] = { id: ensureInternalId(note, userId, note.name), name: displayName(note.name), text: String(note.text).slice(0, MAX_TEXT), createdAt: at, updatedAt: at, migratedFrom: 'notes' };
        migrated++;
      }
    }
    for (const [userId, rows] of Object.entries(legacyPersonal)) {
      db.byUser[userId] ||= {};
      for (const row of Array.isArray(rows) ? rows : []) {
        if (!row?.text) continue;
        const legacyName = String(row.id || `legado-${migrated + 1}`).slice(0, MAX_NAME);
        const key = keyOf(legacyName);
        if (db.byUser[userId][key]) continue;
        const at = Number(row.at || Date.now());
        db.byUser[userId][key] = { id: row.id ? `legacy-${createHash('sha256').update(`${userId}\0${row.id}`).digest('hex').slice(0, 24)}` : stableLegacyId(userId, legacyName), name: legacyName, text: String(row.text).slice(0, MAX_TEXT), createdAt: at, updatedAt: at, migratedFrom: 'personal_notes', legacyId: row.id || null };
        migrated++;
      }
    }
    return db;
  }, DEFAULTS);
  return migrated;
}

export const NOTES_LIMITS = Object.freeze({ maxName: MAX_NAME, maxText: MAX_TEXT, maxPerUser: MAX_NOTES });
export default { listNotes, getNote, getNoteByPosition, resolveNote, parseNoteDirectInput, addNote, editNote, removeNote, migrateLegacyNotes, NOTES_LIMITS };
