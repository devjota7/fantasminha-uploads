import crypto from 'node:crypto';
import { readCollection, getUser } from '../database/store.js';
import { transact } from '../platform/transactions/index.js';
import { ValidationError } from '../core/errors.js';
import * as economy from './economy.js';

export const CLAN_CREATE_COST = 50_000;
export const CLAN_MAX_MEMBERS = 50;
const MAX_NAME = 32;

const id = () => `CLAN-${crypto.randomBytes(5).toString('hex').toUpperCase()}`;
const cleanName = value => String(value || '').trim().replace(/\s+/g, ' ').slice(0, MAX_NAME);
const base = () => ({ byId: {}, byMember: {}, history: [] });

function clans() {
  return readCollection('clans', base());
}
function requireClanFor(userId, data = clans()) {
  const clanId = data.byMember?.[userId];
  const clan = clanId ? data.byId?.[clanId] : null;
  if (!clan) throw new ValidationError('Você não está em nenhum clã.');
  return clan;
}
function assertName(name) {
  const value = cleanName(name);
  if (value.length < 3) throw new ValidationError('Nome do clã deve ter ao menos 3 caracteres.');
  return value;
}
function assertAmount(amount) {
  const n = Number(amount);
  if (!Number.isSafeInteger(n) || n <= 0) throw new ValidationError('Valor inválido.');
  return n;
}

export function getClanFor(userId) {
  const data = clans();
  const c = data.byId?.[data.byMember?.[userId]];
  return c ? structuredClone(c) : null;
}

export async function createClan(userId, name, userName = '', operationId = null) {
  const clanName = assertName(name);
  const op = operationId || `clan:create:${userId}:${clanName.toLowerCase()}`;
  const created = { id: id(), name: clanName, owner: userId, members: [userId], roles: { [userId]: 'owner' }, treasury: CLAN_CREATE_COST, level: 1, xp: 0, createdAt: Date.now(), updatedAt: Date.now(), operationId: op };
  const existingUser = getUser(userId);
  if (existingUser?.economy?.operations?.[op] && existingUser.clanId) return getClanFor(userId);
  await economy.mutateAccount(userId, ({ user, account }) => {
    account.debit(CLAN_CREATE_COST);
    return { amount: -CLAN_CREATE_COST };
  }, {
    reason: 'clan.create', name: userName, operationId: op,
    userMutator: ({ user }) => { user.clanId = created.id; },
    extraSteps: [{ collection: 'clans', update: data => {
      data.byId ??= {}; data.byMember ??= {}; data.history ??= [];
      if (data.byMember[userId]) throw new ValidationError('Você já está em um clã.');
      data.byId[created.id] = created;
      data.byMember[userId] = created.id;
      data.history.push({ type: 'create', clanId: created.id, userId, at: Date.now(), operationId: op });
      return data;
    }}]
  });
  return structuredClone(created);
}

export async function joinClan(userId, clanId, userName = '') {
  const key = String(clanId || '').trim().toUpperCase();
  if (!key) throw new ValidationError('Informe o ID do clã.');
  let joined;
  await transact([{ collection: 'clans', update: data => {
    data.byId ??= {}; data.byMember ??= {}; data.history ??= [];
    if (data.byMember[userId]) throw new ValidationError('Você já está em um clã.');
    const clan = data.byId[key];
    if (!clan) throw new ValidationError('Clã não encontrado.');
    if (clan.members.length >= CLAN_MAX_MEMBERS) throw new ValidationError('Clã lotado.');
    if (!clan.members.includes(userId)) clan.members.push(userId);
    clan.roles ??= {}; clan.roles[userId] = 'member'; clan.updatedAt = Date.now();
    data.byMember[userId] = key; data.history.push({ type: 'join', clanId: key, userId, name: userName, at: Date.now() }); joined = structuredClone(clan); return data;
  }}], { actor: userId, type: 'clan.join', clanId: key });
  return joined;
}

export async function leaveClan(userId) {
  let left;
  await transact([{ collection: 'clans', update: data => {
    data.byId ??= {}; data.byMember ??= {}; data.history ??= [];
    const clan = requireClanFor(userId, data);
    if (clan.owner === userId) throw new ValidationError('O líder deve transferir a liderança ou dissolver o clã.');
    clan.members = clan.members.filter(x => x !== userId); delete clan.roles?.[userId]; delete data.byMember[userId]; clan.updatedAt = Date.now();
    data.history.push({ type: 'leave', clanId: clan.id, userId, at: Date.now() }); left = structuredClone(clan); return data;
  }}, { collection: 'users', update: users => { users.byId ??= {}; const u = users.byId?.[userId]; if (u) { delete u.clanId; u.updatedAt = Date.now(); } return users; } }], { actor: userId, type: 'clan.leave' });
  return left;
}

export async function contribute(userId, amount, userName = '', operationId = null) {
  const value = assertAmount(amount); const data = clans(); const clan = requireClanFor(userId, data); const op = operationId || `clan:contribute:${userId}:${clan.id}:${Date.now()}`;
  const existingUser = getUser(userId);
  if (existingUser?.economy?.operations?.[op]) return getClanFor(userId);
  await economy.mutateAccount(userId, ({ account }) => { account.debit(value); return { amount: -value }; }, {
    reason: 'clan.contribute', name: userName, operationId: op,
    extraSteps: [{ collection: 'clans', update: d => { const c = d.byId?.[clan.id]; if (!c) throw new ValidationError('Clã não encontrado.'); c.treasury = Number(c.treasury || 0) + value; c.xp = Number(c.xp || 0) + Math.floor(value / 100); c.level = Math.max(1, Math.floor(Math.sqrt(c.xp / 100)) + 1); c.updatedAt = Date.now(); d.history ??= []; d.history.push({ type: 'contribute', clanId: c.id, userId, amount: value, at: Date.now(), operationId: op }); return d; } }]
  });
  return getClanFor(userId);
}

export function ranking(limit = 10) {
  return Object.values(clans().byId || {}).sort((a, b) => (b.level - a.level) || (b.treasury - a.treasury) || a.name.localeCompare(b.name)).slice(0, limit).map(c => ({ id: c.id, name: c.name, level: c.level, members: c.members.length, treasury: c.treasury }));
}

export function members(userId) {
  const clan = requireClanFor(userId);
  return clan.members.map(memberId => { const u = getUser(memberId); return { id: memberId, name: u?.name || memberId, role: clan.roles?.[memberId] || 'member' }; });
}

export default { createClan, joinClan, leaveClan, contribute, getClanFor, ranking, members, CLAN_CREATE_COST, CLAN_MAX_MEMBERS };
