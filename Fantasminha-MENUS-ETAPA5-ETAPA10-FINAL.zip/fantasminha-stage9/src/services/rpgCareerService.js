import { getUser, upsertUser } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import * as economy from './economy.js';
import { ensureRpg, applyXp, xpForLevel, xpForNextLevel, levelForXp } from './rpgService.js';

// Mercado de trabalho RPG: 34 profissões (4 antigas + 30 novas).
// O nível é o nível RPG global; a profissão não possui um segundo nível.
export const JOBS = Object.freeze({
  estagiario:   { name:'Estagiário',       icon:'🧑‍💼', category:'iniciais',   minLevel:1,  min:80,   max:140,  xp:12,  cooldown:3600 },
  designer:     { name:'Designer',         icon:'🎨', category:'criativa',   minLevel:2,  min:155,  max:235,  xp:15,  cooldown:3600 },
  programador:  { name:'Programador',      icon:'💻', category:'tecnologia', minLevel:3,  min:230,  max:330,  xp:18,  cooldown:3600 },
  gerente:      { name:'Gerente',          icon:'📊', category:'gestao',     minLevel:5,  min:310,  max:430,  xp:22,  cooldown:3600 },
  jornalista:   { name:'Jornalista',       icon:'📰', category:'comunicacao',minLevel:4,  min:270,  max:390,  xp:20,  cooldown:3600 },
  fotografo:    { name:'Fotógrafo',        icon:'📷', category:'criativa',   minLevel:4,  min:285,  max:405,  xp:21,  cooldown:3600 },
  cozinheiro:   { name:'Cozinheiro',       icon:'👨‍🍳', category:'servicos',   minLevel:5,  min:325,  max:465,  xp:23,  cooldown:3600 },
  enfermeiro:   { name:'Enfermeiro',       icon:'🩺', category:'saude',      minLevel:6,  min:380,  max:540,  xp:26,  cooldown:3600 },
  mecanico:     { name:'Mecânico',         icon:'🔧', category:'tecnico',    minLevel:6,  min:400,  max:560,  xp:27,  cooldown:3600 },
  eletricista:  { name:'Eletricista',      icon:'⚡', category:'tecnico',    minLevel:7,  min:420,  max:590,  xp:29,  cooldown:3600 },
  arquiteto:    { name:'Arquiteto',        icon:'📐', category:'projeto',    minLevel:8,  min:455,  max:635,  xp:31,  cooldown:3600 },
  advogado:     { name:'Advogado',         icon:'⚖️', category:'juridico',   minLevel:8,  min:480,  max:670,  xp:33,  cooldown:3600 },
  professor:    { name:'Professor',        icon:'📚', category:'educacao',   minLevel:9,  min:500,  max:700,  xp:35,  cooldown:3600 },
  pesquisador:  { name:'Pesquisador',      icon:'🔬', category:'ciencia',    minLevel:10, min:535,  max:745,  xp:38,  cooldown:3600 },
  analista:     { name:'Analista',         icon:'📈', category:'tecnologia', minLevel:10, min:560,  max:780,  xp:40,  cooldown:3600 },
  desenvolvedor:{ name:'Desenvolvedor',   icon:'🧑‍💻', category:'tecnologia', minLevel:11, min:590,  max:825,  xp:42,  cooldown:3600 },
  contador:     { name:'Contador',         icon:'🧮', category:'financas',   minLevel:11, min:615,  max:855,  xp:44,  cooldown:3600 },
  medico:       { name:'Médico',           icon:'🧑‍⚕️', category:'saude',      minLevel:12, min:635,  max:885,  xp:46,  cooldown:3600 },
  engenheiro:   { name:'Engenheiro',       icon:'🏗️', category:'engenharia', minLevel:12, min:650,  max:900,  xp:47,  cooldown:3600 },
  piloto:       { name:'Piloto',           icon:'✈️', category:'aviacao',    minLevel:13, min:690,  max:950,  xp:50,  cooldown:3600 },
  diplomata:    { name:'Diplomata',        icon:'🌐', category:'governo',    minLevel:14, min:735,  max:1010, xp:54,  cooldown:3600 },
  investigador: { name:'Investigador',     icon:'🔎', category:'investigacao',minLevel:15,min:780,  max:1070, xp:58,  cooldown:3600 },
  produtor:     { name:'Produtor',         icon:'🎬', category:'entretenimento',minLevel:16,min:825,max:1130,xp:62,cooldown:3600 },
  diretor:      { name:'Diretor',          icon:'🎥', category:'gestao',     minLevel:17, min:875,  max:1190, xp:66,  cooldown:3600 },
  cientista:    { name:'Cientista',        icon:'🧪', category:'ciencia',    minLevel:18, min:930,  max:1260, xp:70,  cooldown:3600 },
  empresario:   { name:'Empresário',       icon:'💼', category:'negocios',   minLevel:19, min:990,  max:1340, xp:74,  cooldown:3600 },
  executivo:    { name:'Executivo',        icon:'👔', category:'gestao',     minLevel:20, min:1050, max:1420, xp:78,  cooldown:3600 },
  especialista: { name:'Especialista',     icon:'🏅', category:'elite',      minLevel:21, min:1120, max:1510, xp:82,  cooldown:3600 },
  estrategista: { name:'Estrategista',     icon:'♟️', category:'elite',      minLevel:22, min:1195, max:1605, xp:86,  cooldown:3600 },
  conselheiro:  { name:'Conselheiro',      icon:'🧭', category:'elite',      minLevel:24, min:1280, max:1710, xp:91,  cooldown:3600 },
  magnata:      { name:'Magnata',          icon:'👑', category:'lendaria',   minLevel:26, min:1380, max:1840, xp:96,  cooldown:3600 },
  visionario:   { name:'Visionário',       icon:'🔮', category:'lendaria',   minLevel:28, min:1490, max:1980, xp:101, cooldown:3600 },
  mestre:       { name:'Mestre de Ofício', icon:'🏆', category:'lendaria',   minLevel:30, min:1610, max:2140, xp:108, cooldown:3600 },
  lenda:        { name:'Lenda do Mercado', icon:'🌟', category:'lendaria',   minLevel:35, min:1750, max:2320, xp:115, cooldown:3600 }
});

const JOB_ALIASES = Object.freeze({
  estagiario:'estagiario', estagiária:'estagiario', estagiaria:'estagiario',
  dev:'desenvolvedor', developer:'desenvolvedor', programador:'programador',
  foto:'fotografo', fotografa:'fotografo', jornalista:'jornalista',
  investigador:'investigador', cientista:'cientista', empresario:'empresario',
  executivo:'executivo', magnata:'magnata', mestre:'mestre', lenda:'lenda'
});

const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim().replace(/\s+/g,'_');

export function ensureCareer(user = {}) {
  user.career ??= {};
  if (user.career.job == null && user.job) {
    const legacy = resolveJob(user.job);
    if (legacy) user.career.job = legacy;
    else user.career.legacyJob = String(user.job).slice(0,60);
  }
  user.career.job ??= null;
  user.career.lastWork ??= 0;
  user.career.workCount = Number.isSafeInteger(Number(user.career.workCount)) ? Number(user.career.workCount) : 0;
  user.career.totalEarned = Number.isFinite(Number(user.career.totalEarned)) ? Number(user.career.totalEarned) : 0;
  user.career.totalXp = Number.isFinite(Number(user.career.totalXp)) ? Number(user.career.totalXp) : 0;
  user.career.history ??= [];
  if (!Array.isArray(user.career.history)) user.career.history = [];
  return user.career;
}

export function ensureCurriculum(user = {}) {
  user.curriculum ??= {};
  if (user.curriculum.name != null) user.curriculum.name = String(user.curriculum.name).trim().slice(0,60);
  if (user.curriculum.age != null) user.curriculum.age = Number(user.curriculum.age);
  return user.curriculum;
}

export function resolveJob(value) {
  const key = normalize(value).replace(/_/g,'');
  const direct = Object.keys(JOBS).find(id => id.replace(/_/g,'') === key);
  if (direct) return direct;
  return JOB_ALIASES[key] || null;
}

export { xpForLevel, xpForNextLevel, levelForXp };

export function levelProgress(rpg = {}) {
  const xp = Math.max(0, Number(rpg.xp) || 0);
  const level = Math.max(1, Number(rpg.level) || 1);
  const current = xpForLevel(level);
  const next = xpForNextLevel(level);
  const span = Math.max(1, next - current);
  const inside = Math.max(0, xp - current);
  return { level, xp, currentLevelXp: current, nextLevelXp: next, remaining: Math.max(0,next-xp), progressXp: inside, progressPercent: Math.min(100, Math.floor((inside/span)*100)) };
}

export function unlockedJobs(level) {
  const n = Math.max(1, Number(level) || 1);
  return Object.entries(JOBS).filter(([,job]) => job.minLevel <= n).map(([id,job]) => ({id,...job}));
}

export function lockedJobs(level) {
  const n = Math.max(1, Number(level) || 1);
  return Object.entries(JOBS).filter(([,job]) => job.minLevel > n).map(([id,job]) => ({id,...job}));
}

export function curriculumValid(curriculum) {
  const name = String(curriculum?.name || '').trim();
  const age = Number(curriculum?.age);
  return name.length >= 2 && name.length <= 60 && Number.isInteger(age) && age >= 1 && age <= 120;
}

export async function saveCurriculum(userId, name, age) {
  const cleanName = String(name ?? '').trim().replace(/\s+/g,' ');
  const nAge = Number(age);
  if (cleanName.length < 2 || cleanName.length > 60) throw new ValidationError('O nome deve ter entre 2 e 60 caracteres.');
  if (!Number.isInteger(nAge) || nAge < 1 || nAge > 120) throw new ValidationError('A idade deve ser um número inteiro entre 1 e 120.');
  const user = getUser(userId) || { id:userId, name:'' };
  const curriculum = ensureCurriculum(user);
  curriculum.name = cleanName;
  curriculum.age = nAge;
  curriculum.createdAt ??= Date.now();
  curriculum.updatedAt = Date.now();
  await upsertUser(userId, { curriculum });
  return curriculum;
}

export async function setJob(userId, jobId) {
  const id = resolveJob(jobId);
  if (!id) throw new ValidationError('Vaga inexistente. Use ×vagas para consultar o catálogo.');
  const user = getUser(userId) || { id:userId };
  const rpg = ensureRpg(user);
  if (!rpg.class) throw new ValidationError('Crie seu personagem RPG primeiro com ×rpgcriar.');
  const job = JOBS[id];
  if (rpg.level < job.minLevel) throw new ValidationError(`🔒 ${job.name} exige nível ${job.minLevel}. Seu nível atual é ${rpg.level}.`);
  const curriculum = ensureCurriculum(user);
  if (!curriculumValid(curriculum)) throw new ValidationError('Complete seu currículo primeiro: ×curriculo Nome | Idade');
  const career = ensureCareer(user);
  const previousJob = career.job;
  career.job = id;
  career.jobSince = Date.now();
  career.history.push({ type:'HIRED', job:id, previousJob:previousJob || null, at:Date.now() });
  career.history = career.history.slice(-50);
  career.updatedAt = Date.now();
  await upsertUser(userId, { career });
  return { id, job, rpg, curriculum, career };
}

export async function resign(userId) {
  const user = getUser(userId);
  if (!user) throw new ValidationError('Usuário não encontrado.');
  const career = ensureCareer(user);
  const old = career.job;
  if (!old) throw new ValidationError('Você não possui uma profissão ativa.');
  career.job = null;
  career.jobSince = null;
  career.history.push({ type:'RESIGNED', job:old, at:Date.now() });
  career.history = career.history.slice(-50);
  career.updatedAt = Date.now();
  await upsertUser(userId, { career });
  return { old, job:JOBS[old] || null };
}

export async function work(userId, name = '', operationId = null) {
  const op = operationId || `career-work:${userId}:${Date.now()}`;
  let result;
  await economy.mutateAccount(userId, ({ user, account }) => {
    const career = ensureCareer(user);
    const curriculum = ensureCurriculum(user);
    if (!curriculumValid(curriculum)) throw new ValidationError('Complete seu currículo primeiro: ×curriculo Nome | Idade');
    const rpg = ensureRpg(user);
    if (!rpg.class) throw new ValidationError('Crie seu personagem RPG primeiro com ×rpgcriar.');
    if (!career.job || !JOBS[career.job]) throw new ValidationError('Você não possui emprego. Use ×vagas e depois ×emprego <vaga>.');
    const job = JOBS[career.job];
    if (rpg.level < job.minLevel) throw new ValidationError(`Seu nível caiu abaixo do requisito de ${job.name}.`);
    const now = Date.now();
    if (career.lastWork && now - career.lastWork < job.cooldown * 1000) {
      throw new ValidationError(`⏳ Você ainda está trabalhando. Aguarde ${Math.ceil((job.cooldown*1000-(now-career.lastWork))/60000)} min.`);
    }
    const gained = job.min + Math.floor(Math.random() * (job.max - job.min + 1));
    const oldLevel = rpg.level;
    const oldXp = rpg.xp;
    career.lastWork = now;
    career.workCount += 1;
    career.totalEarned += gained;
    career.totalXp += job.xp;
    career.history.push({ type:'WORKED', job:career.job, amount:gained, xp:job.xp, at:now });
    career.history = career.history.slice(-50);
    applyXp(rpg, job.xp);
    if (name) user.name = curriculum.name || name;
    account.credit(gained);
    user.rpg = rpg;
    user.career = career;
    result = { gained, xp:gained ? job.xp : 0, wallet:account.wallet, level:rpg.level, oldLevel, oldXp, levelUp:rpg.level > oldLevel, jobId:career.job, job };
    return { amount:gained, ...result };
  }, { reason:'rpg.career.work', name, operationId:op });
  return result;
}

export function getCareer(userId) {
  const user = getUser(userId);
  if (!user) return null;
  const career = ensureCareer(user);
  const curriculum = ensureCurriculum(user);
  const rpg = ensureRpg(user);
  return { user, career, curriculum, rpg, job: career.job ? JOBS[career.job] || null : null, progress:levelProgress(rpg) };
}

export function renderBar(percent, width = 12) {
  const filled = Math.round((Math.max(0,Math.min(100,percent))/100)*width);
  return '█'.repeat(filled) + '░'.repeat(Math.max(0,width-filled));
}
