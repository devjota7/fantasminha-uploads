import { env as defaultEnv } from '../../config/env.js';
/**
 * Fantasminha — OpenAI-only AI gateway.
 *
 * One credential, one text model and explicit optional image model.
 * Text/vision use Responses API. Image generation uses the OpenAI Images API.
 * No Groq/Cerebras/Gemini/NVIDIA compatibility is retained here.
 */

const RESPONSES_URL = 'https://api.openai.com/v1/responses';
const IMAGES_URL = 'https://api.openai.com/v1/images/generations';
// Se OPENAI_MODEL não for definido no .env, cai nesse modelo em vez de
// exigir configuração extra — só a OPENAI_API_KEY já é suficiente pra IA
// funcionar. OPENAI_IMAGE_MODEL continua opcional.
const DEFAULT_TEXT_MODEL = 'gpt-4o-mini';
const DEFAULT_TIMEOUT_MS = 30000;
const DEFAULT_VISION_TIMEOUT_MS = 45000;
const DEFAULT_IMAGE_TIMEOUT_MS = 90000;
const DEFAULT_MAX_OUTPUT_TOKENS = 1200;
const DEFAULT_MAX_RETRIES = 2;
const RETRY_BASE_DELAY_MS = 700;
const MAX_INPUT_CHARS = 30000;
const MAX_IMAGE_BASE64_CHARS = 18 * 1024 * 1024;

function numberEnv(name, fallback, env = defaultEnv) {
  const value = Number(env[name]);
  return Number.isFinite(value) && value > 0 ? value : fallback;
}

function sanitizeText(value, max = MAX_INPUT_CHARS) {
  return String(value ?? '').replace(/\u0000/g, '').trim().slice(0, max);
}

function sanitizeHistory(history = []) {
  if (!Array.isArray(history)) return [];
  return history.map(item => ({
    role: item?.role === 'assistant' ? 'assistant' : 'user',
    content: sanitizeText(item?.content, 12000)
  })).filter(item => item.content).slice(-16);
}

export function getOpenAIConfig(env = defaultEnv) {
  const apiKey = String(env.OPENAI_API_KEY || '').trim();
  const model = String(env.OPENAI_MODEL || '').trim() || DEFAULT_TEXT_MODEL;
  const imageModel = String(env.OPENAI_IMAGE_MODEL || '').trim();
  return {
    configured: Boolean(apiKey && model),
    hasKey: Boolean(apiKey),
    hasModel: Boolean(model),
    model,
    imageModel,
    timeoutMs: Math.max(5000, numberEnv('OPENAI_TIMEOUT_MS', DEFAULT_TIMEOUT_MS, env)),
    visionTimeoutMs: Math.max(5000, numberEnv('OPENAI_VISION_TIMEOUT_MS', DEFAULT_VISION_TIMEOUT_MS, env)),
    imageTimeoutMs: Math.max(10000, numberEnv('OPENAI_IMAGE_TIMEOUT_MS', DEFAULT_IMAGE_TIMEOUT_MS, env)),
    maxOutputTokens: Math.max(64, numberEnv('OPENAI_MAX_OUTPUT_TOKENS', DEFAULT_MAX_OUTPUT_TOKENS, env)),
    maxRetries: Math.min(4, Math.max(0, numberEnv('OPENAI_MAX_RETRIES', DEFAULT_MAX_RETRIES, env))),
    reasoningEffort: String(env.OPENAI_REASONING_EFFORT || 'low').trim().toLowerCase(),
    endpoint: RESPONSES_URL,
    imageEndpoint: IMAGES_URL
  };
}

function extractOutputText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const chunks = [];
  for (const item of Array.isArray(data?.output) ? data.output : []) {
    for (const part of Array.isArray(item?.content) ? item.content : []) {
      if (typeof part?.text === 'string') chunks.push(part.text);
    }
  }
  return chunks.join('\n').trim();
}

function providerError(status, data) {
  const message = data?.error?.message || data?.message || `OpenAI HTTP ${status}`;
  const error = new Error(message);
  error.provider = 'openai';
  error.status = status;
  error.code = data?.error?.code || `HTTP_${status}`;
  error.data = data;
  return error;
}

function shouldRetry(error) {
  const status = Number(error?.status || error?.response?.status);
  return error?.name === 'AbortError' || status === 408 || status === 409 || status === 425 || status === 429 || status >= 500;
}

async function fetchJson({ url, body, env, timeoutMs, requestFn, method = 'POST' }) {
  const request = {
    url,
    method,
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
      Authorization: `Bearer ${env.OPENAI_API_KEY}`
    },
    body
  };
  const fn = requestFn || (async ({ url: target, options }) => fetch(target, options));
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fn({
      ...request,
      options: {
        method,
        headers: request.headers,
        body: JSON.stringify(body),
        signal: controller.signal
      }
    });
    let data = null;
    try { data = await response.json(); } catch { data = null; }
    if (!response.ok) throw providerError(response.status, data);
    return data;
  } finally {
    clearTimeout(timer);
  }
}

function validateCommon(cfg, input) {
  if (!cfg.hasKey) {
    const error = new Error('OPENAI_API_KEY não configurada.');
    error.code = 'OPENAI_NOT_CONFIGURED';
    throw error;
  }
  if (!cfg.hasModel) {
    const error = new Error('OPENAI_MODEL não configurado.');
    error.code = 'OPENAI_MODEL_NOT_CONFIGURED';
    throw error;
  }
  if (!input) {
    const error = new Error('Texto da solicitação vazio.');
    error.code = 'OPENAI_EMPTY_INPUT';
    throw error;
  }
}

async function withRetries(task, cfg, onEvent, meta) {
  const attempts = cfg.maxRetries + 1;
  let lastError = null;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    if (attempt > 1) await new Promise(resolve => setTimeout(resolve, RETRY_BASE_DELAY_MS * (2 ** (attempt - 2))));
    const started = Date.now();
    onEvent?.({ type: 'attempt', provider: 'openai', ...meta, attempt });
    try {
      const result = await task();
      onEvent?.({ type: 'success', provider: 'openai', ...meta, attempt, latencyMs: Date.now() - started });
      return result;
    } catch (error) {
      lastError = error;
      if (error?.name === 'AbortError') {
        lastError = new Error('Tempo limite da OpenAI excedido.');
        lastError.code = 'OPENAI_TIMEOUT';
        lastError.provider = 'openai';
      }
      const status = Number(lastError?.status || lastError?.response?.status);
      onEvent?.({ type: 'error', provider: 'openai', ...meta, attempt, code: lastError?.code || status || 'UNKNOWN' });
      if (!shouldRetry(error) || attempt >= attempts) throw lastError;
    }
  }
  throw lastError || new Error('Falha desconhecida na OpenAI.');
}

function buildInput({ text, history }) {
  const items = [];
  for (const item of sanitizeHistory(history)) {
    items.push({ role: item.role, content: [{ type: 'input_text', text: item.content }] });
  }
  items.push({ role: 'user', content: [{ type: 'input_text', text: sanitizeText(text) }] });
  return items;
}

export async function requestOpenAI({
  text,
  systemPrompt = '',
  history = [],
  model = null,
  env = defaultEnv,
  requestFn = null,
  timeoutMs = null,
  maxOutputTokens = null,
  reasoningEffort = null,
  onEvent = null
} = {}) {
  const cfg = getOpenAIConfig(env);
  const selectedModel = String(model || cfg.model || '').trim();
  const input = sanitizeText(text);
  validateCommon(cfg, input);

  const body = {
    model: selectedModel,
    input: buildInput({ text: input, history }),
    max_output_tokens: Number(maxOutputTokens || cfg.maxOutputTokens)
  };
  const instructions = sanitizeText(systemPrompt, 30000);
  if (instructions) body.instructions = instructions;
  if (cfg.reasoningEffort && cfg.reasoningEffort !== 'none') body.reasoning = { effort: reasoningEffort || cfg.reasoningEffort };

  const data = await withRetries(
    () => fetchJson({ url: RESPONSES_URL, body, env, timeoutMs: Math.max(5000, timeoutMs || cfg.timeoutMs), requestFn }),
    cfg,
    onEvent,
    { model: selectedModel, mode: 'text' }
  );
  const content = extractOutputText(data);
  if (!content) {
    const error = new Error('OpenAI retornou uma resposta sem texto.');
    error.code = 'OPENAI_EMPTY_RESPONSE';
    throw error;
  }
  return {
    success: true,
    provider: 'openai',
    model: selectedModel,
    text: content,
    data,
    response: { choices: [{ message: { role: 'assistant', content } }] }
  };
}

export async function requestOpenAIVision({
  prompt,
  imageBase64,
  mimeType = 'image/jpeg',
  model = null,
  env = defaultEnv,
  requestFn = null,
  timeoutMs = null,
  onEvent = null
} = {}) {
  const cfg = getOpenAIConfig(env);
  const selectedModel = String(model || cfg.model || '').trim();
  const text = sanitizeText(prompt, 30000);
  validateCommon(cfg, text);
  const raw = String(imageBase64 || '').replace(/^data:[^;]+;base64,/, '').trim();
  if (!raw) throw new Error('Imagem não informada.');
  if (raw.length > MAX_IMAGE_BASE64_CHARS) throw new Error('Imagem acima do limite permitido.');
  if (!/^image\/(jpeg|png|webp|gif)$/i.test(String(mimeType))) throw new Error('Formato de imagem não suportado.');

  const body = {
    model: selectedModel,
    input: [{
      role: 'user',
      content: [
        { type: 'input_text', text },
        { type: 'input_image', image_url: `data:${mimeType};base64,${raw}` }
      ]
    }],
    max_output_tokens: 1200
  };
  const instructions = 'Analise somente o conteúdo visual realmente presente. Não invente informações, identidade, autenticidade ou dados externos.';
  body.instructions = instructions;

  const data = await withRetries(
    () => fetchJson({ url: RESPONSES_URL, body, env, timeoutMs: Math.max(5000, timeoutMs || cfg.visionTimeoutMs), requestFn }),
    cfg,
    onEvent,
    { model: selectedModel, mode: 'vision' }
  );
  const content = extractOutputText(data);
  if (!content) throw new Error('OpenAI retornou uma resposta visual sem texto.');
  return { success: true, text: content, provider: 'openai', model: selectedModel, data };
}

export async function requestOpenAIImage({
  prompt,
  model = null,
  env = defaultEnv,
  requestFn = null,
  timeoutMs = null,
  size = '1024x1024',
  quality = 'low',
  onEvent = null
} = {}) {
  const cfg = getOpenAIConfig(env);
  if (!cfg.hasKey) throw new Error('OPENAI_API_KEY não configurada.');
  const selectedModel = String(model || cfg.imageModel || '').trim();
  if (!selectedModel) {
    const error = new Error('OPENAI_IMAGE_MODEL não configurado.');
    error.code = 'OPENAI_IMAGE_MODEL_NOT_CONFIGURED';
    throw error;
  }
  const cleanPrompt = sanitizeText(prompt, 30000);
  if (!cleanPrompt) throw new Error('Prompt de imagem vazio.');

  const body = {
    model: selectedModel,
    prompt: cleanPrompt,
    n: 1,
    size,
    quality,
    output_format: 'png'
  };
  const data = await withRetries(
    () => fetchJson({ url: IMAGES_URL, body, env, timeoutMs: Math.max(10000, timeoutMs || cfg.imageTimeoutMs), requestFn }),
    cfg,
    onEvent,
    { model: selectedModel, mode: 'image' }
  );
  const item = data?.data?.[0] || {};
  if (!item?.b64_json) throw new Error('OpenAI não retornou a imagem em base64.');
  return { buffer: Buffer.from(item.b64_json, 'base64'), mimeType: 'image/png', provider: 'openai', model: selectedModel, data };
}

export function assertOpenAIConfig(env = defaultEnv) {
  const cfg = getOpenAIConfig(env);
  if (!cfg.hasKey) throw new Error('OPENAI_API_KEY não configurada.');
  if (!cfg.hasModel) throw new Error('OPENAI_MODEL não configurado.');
  return cfg;
}

export default { getOpenAIConfig, requestOpenAI, requestOpenAIVision, requestOpenAIImage, assertOpenAIConfig };
