import { getUser, upsertUser } from '../database/store.js';
import { purchaseItem, sellItem } from './economy.js';
import { ValidationError } from '../core/errors.js';
import { ensureRpg, applyXp } from './rpgService.js';
const CATALOG={vela:{name:'Vela do Véu',price:500,desc:'Cosmético do além',sellRate:.5},ticket_fila:{name:'Ticket de Fila',price:1500,desc:'Pula 1 daily wait simbólico',sellRate:.5},amuleto:{name:'Amuleto Sombrio',price:3000,desc:'+sorte no crime (flavor)',sellRate:.5},capa_espectro:{name:'Capa de Espectro',price:8000,desc:'Item RPG cosmético',sellRate:.5},elixir:{name:'Elixir de XP',price:2500,desc:'Usar: usaritem elixir (+50 xp se RPG)',sellRate:.5}};
const qty=n=>{const x=Number(n);if(!Number.isInteger(x)||x<=0)throw new ValidationError('Quantidade inválida.');return x;};
export function listShop(){return Object.entries(CATALOG).map(([id,i])=>({id,...i,sellPrice:Math.floor(i.price*i.sellRate)}));}
export async function buy(userId,itemId,name='') {
  const item=CATALOG[itemId];
  if(!item)throw new ValidationError('Item inexistente. Use: loja');
  const r=await purchaseItem(userId,itemId,item.price,1,name,`shop-buy:${userId}:${itemId}:${Date.now()}`);
  return{item,inv:r.inventory};
}

export async function inventory(userId){return getUser(userId)?.economy?.inventory||{};}
export async function sell(userId,itemId,quantity='1',name='') {
  const item=CATALOG[itemId];
  if(!item)throw new ValidationError('Item inexistente. Use: loja');
  const q=String(quantity).toLowerCase()==='all'?Number(getUser(userId)?.economy?.inventory?.[itemId]||0):qty(quantity);
  if(q<=0)throw new ValidationError('Quantidade inválida.');
  const value=Math.floor(item.price*item.sellRate);
  const r=await sellItem(userId,itemId,value,q,name,`shop-sell:${userId}:${itemId}:${Date.now()}`);
  return{item,qty:q,value:r.value,wallet:r.wallet,remaining:r.remaining};
}

export async function useItem(userId,itemId,name=''){const u=getUser(userId);if(!u)throw new ValidationError('Usuário não encontrado.');const inv={...(u.economy?.inventory||{})};if(!inv[itemId])throw new ValidationError('Você não tem esse item.');inv[itemId]--;if(inv[itemId]<=0)delete inv[itemId];const eco={...(u.economy||{}),inventory:inv};let extra='';if(itemId==='elixir'){const r=ensureRpg(u);r.class ||= 'alma_errante';applyXp(r,50);await upsertUser(userId,{name,economy:eco,rpg:r});extra='\n+50 XP de RPG.';}else await upsertUser(userId,{name,economy:eco});return{itemId,extra};}
export {CATALOG}; export default{listShop,buy,inventory,sell,useItem,CATALOG};
