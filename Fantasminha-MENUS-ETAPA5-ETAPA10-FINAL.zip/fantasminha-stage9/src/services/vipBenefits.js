import { getUser, upsertUser, readCollection } from '../database/store.js';
import { updateCollection } from '../database/store.js';

const USAGE = 'vip_usage';

function isActivePremium(u) {
  if (!u?.premium?.active) return false;
  if (u.premium.until && u.premium.until < Date.now()) return false;
  return true;
}

export function getVipPlan(userId) {
  const u = getUser(userId);
  if (!isActivePremium(u)) return null;
  return (u.premium.plan || 'prata').toLowerCase();
}


export async function grantVip(userId, { days = 30, plan = 'prata' } = {}) {
  const uid = String(userId || '').trim().toLowerCase();
  if (!uid) throw new Error('Usuário inválido para VIP.');
  const safeDays = Math.max(1, Math.min(3650, Number(days) || 30));
  const safePlan = ['bronze', 'prata', 'ouro'].includes(String(plan || '').toLowerCase())
    ? String(plan).toLowerCase()
    : 'prata';
  const before = getUser(uid)?.premium;
  const active = !!before?.active && (!before.until || before.until > Date.now());
  const until = Math.max(Number(before?.until || 0), Date.now() + safeDays * 86400000);
  await upsertUser(uid, { premium: { active: true, until, plan: safePlan } });
  return { changed: !active, userId: uid, days: safeDays, plan: safePlan, until };
}

export async function revokeVip(userId) {
  const uid = String(userId || '').trim().toLowerCase();
  if (!uid) throw new Error('Usuário inválido para VIP.');
  const before = getUser(uid)?.premium;
  const changed = !!before?.active || Number(before?.until || 0) > 0 || !!before?.plan;
  await upsertUser(uid, { premium: { active: false, until: 0, plan: null } });
  return { changed, userId: uid };
}

export function listActiveVipUsers() {
  const users = readCollection('users', { byId: {} }).byId || {};
  return Object.values(users)
    .filter(u => isActivePremium(u))
    .map(u => u.id)
    .filter(Boolean);
}

/** Multiplicador de cooldown: VIP gasta menos tempo */
export function cooldownMultiplier(userId) {
  const plan = getVipPlan(userId);
  if (!plan) return 1;
  if (plan === 'ouro') return 0.3;
  if (plan === 'prata') return 0.5;
  if (plan === 'bronze') return 0.8;
  return 0.6;
}

export function dailyBonus(userId) {
  const plan = getVipPlan(userId);
  if (plan === 'ouro') return 1500;
  if (plan === 'prata') return 500;
  if (plan === 'bronze') return 200;
  return 0;
}

/** Limites diários de download / IA */
export async function canUseVipBenefit(userId, kind = 'download') {
  const plan = getVipPlan(userId);
  const limits = {
    free: { download: 15, ai: 20 },
    bronze: { download: 40, ai: 50 },
    prata: { download: 80, ai: 100 },
    ouro: { download: 200, ai: 300 }
  };
  const key = plan || 'free';
  const max = limits[key]?.[kind] ?? limits.free[kind];
  const day = new Date().toISOString().slice(0, 10);

  const data = await updateCollection(USAGE, (U) => {
    if (!U.byDay) U.byDay = {};
    if (!U.byDay[day]) U.byDay[day] = {};
    if (!U.byDay[day][userId]) U.byDay[day][userId] = { download: 0, ai: 0 };
    return U;
  }, { byDay: {} });

  const used = data.byDay?.[day]?.[userId]?.[kind] || 0;
  if (used >= max) {
    return {
      ok: false,
      msg: `🕯️ Limite diário de *${kind}* (${used}/${max}). VIP aumenta o teto.`
    };
  }

  await updateCollection(USAGE, (U) => {
    U.byDay[day][userId][kind] = used + 1;
    return U;
  }, { byDay: {} });

  return { ok: true, used: used + 1, max, plan: key };
}

export function vipSummary(userId) {
  const plan = getVipPlan(userId);
  return {
    active: !!plan,
    plan: plan || 'free',
    cooldownMult: cooldownMultiplier(userId),
    dailyBonus: dailyBonus(userId)
  };
}

export default { getVipPlan, cooldownMultiplier, dailyBonus, canUseVipBenefit, vipSummary, isActivePremium, grantVip, revokeVip, listActiveVipUsers };
