const W = 1080;
const H = 1500;

function esc(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&apos;');
}

function safeText(value, fallback = 'Não disponível') {
  const s = String(value ?? '').replace(/\s+/g, ' ').trim();
  return s || fallback;
}

function crop(value, max = 180) {
  const s = safeText(value, '');
  return s.length > max ? `${s.slice(0, max - 1).trim()}…` : s;
}

function fmt(value) {
  return Number.isFinite(Number(value)) ? Number(value).toLocaleString('pt-BR') : 'Não disponível';
}

function date(value) {
  if (value == null) return 'Não disponível';
  let n = Number(value);
  if (Number.isFinite(n) && n > 1e12) n /= 1000;
  const d = Number.isFinite(n) && n > 1e9 ? new Date(n * 1000) : new Date(String(value));
  return Number.isNaN(d.getTime()) ? 'Não disponível' : d.toLocaleDateString('pt-BR');
}

function dataUri(buffer, mime = 'image/jpeg') {
  return buffer ? `data:${mime};base64,${Buffer.from(buffer).toString('base64')}` : '';
}

function wrap(text, maxChars = 42, maxLines = 3) {
  const words = safeText(text, '').split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (const word of words) {
    const next = line ? `${line} ${word}` : word;
    if (next.length > maxChars && line) { lines.push(line); line = word; }
    else line = next;
  }
  if (line) lines.push(line);
  return lines.slice(0, maxLines);
}

function ghostWatermark() {
  return `
    <g opacity="0.18" transform="translate(785 185)">
      <path d="M0 170 C-18 35 80 -65 210 -55 C340 -45 430 55 412 180 L392 350 L350 325 L315 370 L272 325 L228 370 L184 325 L140 370 L96 325 L55 365 L25 315 Z" fill="#5d39ff" stroke="#a47bff" stroke-width="7"/>
      <ellipse cx="145" cy="155" rx="28" ry="44" fill="#050509"/>
      <ellipse cx="275" cy="155" rx="28" ry="44" fill="#050509"/>
      <path d="M185 245 Q210 270 235 245" fill="none" stroke="#050509" stroke-width="12" stroke-linecap="round"/>
      <circle cx="40" cy="70" r="12" fill="#8f6bff"/><circle cx="395" cy="75" r="10" fill="#8f6bff"/>
    </g>`;
}

function postCard(post, x, y, index) {
  const img = dataUri(post?.imageBuffer);
  const clip = `postClip${index}`;
  const image = img
    ? `<image href="${img}" x="${x + 18}" y="${y + 18}" width="${286}" height="286" preserveAspectRatio="xMidYMid slice" clip-path="url(#${clip})"/>`
    : `<rect x="${x + 18}" y="${y + 18}" width="286" height="286" rx="18" fill="#11101d"/><text x="${x + 161}" y="${y + 165}" text-anchor="middle" fill="#8d8aa0" font-family="Arial" font-size="24">Não disponível</text>`;
  const label = post?.type === 'video' ? 'VÍDEO' : 'POST';
  return `
    <defs><clipPath id="${clip}"><rect x="${x + 18}" y="${y + 18}" width="286" height="286" rx="18"/></clipPath></defs>
    <g>
      <rect x="${x}" y="${y}" width="322" height="410" rx="28" fill="#080812" fill-opacity="0.94" stroke="#6f45ff" stroke-width="2"/>
      ${image}
      <rect x="${x + 18}" y="${y + 318}" width="286" height="64" rx="14" fill="#0e0d1a"/>
      <text x="${x + 34}" y="${y + 344}" fill="#a982ff" font-family="Arial" font-size="17" font-weight="700">${label} ${index}</text>
      <text x="${x + 34}" y="${y + 370}" fill="#d9d5e8" font-family="Arial" font-size="16">${esc(date(post?.date))}</text>
    </g>`;
}

function buildSvg(data, avatarBuffer, posts) {
  const insta = data.platform === 'instagram';
  const platform = insta ? 'INSTAGRAM' : 'TIKTOK';
  const accent = insta ? '#a45bff' : '#2ee8ff';
  const accent2 = '#5631ff';
  const icon = insta ? '◎' : '♪';
  const username = safeText(data.username, 'usuario');
  const name = safeText(data.name, username);
  const bioLines = wrap(crop(data.bio, 190), 48, 3);
  const avatar = dataUri(avatarBuffer);
  const stats = insta
    ? [['PUBLICAÇÕES', fmt(data.posts)], ['SEGUIDORES', fmt(data.followers)], ['SEGUINDO', fmt(data.following)]]
    : [['VÍDEOS', fmt(data.videos)], ['SEGUIDORES', fmt(data.followers)], ['SEGUINDO', fmt(data.following)]];
  const verified = data.verified ? '✓ PERFIL VERIFICADO' : (data.private ? '🔒 PERFIL PRIVADO' : '● PERFIL PÚBLICO');
  const postCards = [0, 1, 2].map((i) => postCard(posts[i], 72 + i * 336, 965, i + 1)).join('');
  const links = posts.filter(p => p?.url).slice(0, 3);

  return `<?xml version="1.0" encoding="UTF-8"?>
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#03020a"/><stop offset="0.48" stop-color="#08051a"/><stop offset="1" stop-color="#02030b"/></linearGradient>
      <radialGradient id="halo"><stop offset="0" stop-color="${accent}" stop-opacity=".34"/><stop offset="1" stop-color="${accent2}" stop-opacity="0"/></radialGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="10" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
      <clipPath id="avatarClip"><circle cx="185" cy="285" r="112"/></clipPath>
    </defs>
    <rect width="1080" height="1500" fill="url(#bg)"/>
    <circle cx="850" cy="170" r="430" fill="url(#halo)"/>
    <circle cx="130" cy="1270" r="420" fill="url(#halo)" opacity=".45"/>
    ${ghostWatermark()}
    <path d="M0 0H1080V10H0Z" fill="${accent}" opacity=".75"/>
    <text x="72" y="75" fill="#f5f2ff" font-family="Arial" font-size="30" font-weight="800" letter-spacing="5">👻 FANTASMINHA</text>
    <text x="72" y="112" fill="${accent}" font-family="Arial" font-size="17" font-weight="700" letter-spacing="4">PERFIL ${platform}</text>
    <text x="1008" y="84" text-anchor="end" fill="#8d87a4" font-family="Arial" font-size="16">CONSULTA PÚBLICA</text>

    <rect x="48" y="145" width="984" height="535" rx="38" fill="#070711" fill-opacity=".88" stroke="${accent2}" stroke-width="2"/>
    <rect x="70" y="167" width="230" height="230" rx="115" fill="#0b0916" stroke="${accent}" stroke-width="7" filter="url(#glow)"/>
    ${avatar ? `<image href="${avatar}" x="73" y="173" width="224" height="224" preserveAspectRatio="xMidYMid slice" clip-path="url(#avatarClip)"/>` : `<text x="185" y="292" text-anchor="middle" fill="#77708d" font-family="Arial" font-size="22">SEM FOTO</text>`}
    <circle cx="274" cy="372" r="31" fill="#0b0916" stroke="${accent}" stroke-width="4"/>
    <text x="274" y="382" text-anchor="middle" fill="${accent}" font-family="Arial" font-size="30" font-weight="800">${esc(icon)}</text>

    <text x="350" y="225" fill="#ffffff" font-family="Arial" font-size="38" font-weight="800">${esc(crop(name, 28))}</text>
    <text x="350" y="270" fill="${accent}" font-family="Arial" font-size="25" font-weight="700">@${esc(username)}</text>
    <rect x="350" y="292" width="270" height="42" rx="21" fill="${accent2}" fill-opacity=".18" stroke="${accent}" stroke-opacity=".6"/>
    <text x="485" y="320" text-anchor="middle" fill="#e7e1ff" font-family="Arial" font-size="17" font-weight="700">${esc(verified)}</text>
    <text x="350" y="385" fill="#9c96ad" font-family="Arial" font-size="16" font-weight="700" letter-spacing="2">BIO</text>
    ${bioLines.map((line, i) => `<text x="350" y="417" dy="${i * 30}" fill="#eeeaf8" font-family="Arial" font-size="20">${esc(line)}</text>`).join('')}

    ${stats.map((s, i) => {
      const x = 350 + i * 210;
      return `<g><text x="${x}" y="525" fill="#ffffff" font-family="Arial" font-size="27" font-weight="800">${esc(s[1])}</text><text x="${x}" y="552" fill="#8e879f" font-family="Arial" font-size="14" font-weight="700" letter-spacing="1">${esc(s[0])}</text></g>`;
    }).join('')}
    ${!insta && Number.isFinite(Number(data.likes)) ? `<text x="350" y="602" fill="#ff6fbd" font-family="Arial" font-size="17" font-weight="700">♥ ${fmt(data.likes)} curtidas</text>` : ''}

    <rect x="72" y="710" width="936" height="100" rx="26" fill="#0b0916" stroke="#2b2450"/>
    <text x="102" y="752" fill="${accent}" font-family="Arial" font-size="18" font-weight="800">LINK DO PERFIL</text>
    <text x="102" y="785" fill="#dcd6ee" font-family="Arial" font-size="19">${esc(data.profileUrl || 'Não disponível')}</text>

    <text x="72" y="880" fill="#ffffff" font-family="Arial" font-size="31" font-weight="800">${insta ? 'POSTS RECENTES' : 'VÍDEOS RECENTES'}</text>
    <rect x="72" y="898" width="936" height="3" rx="2" fill="${accent}" opacity=".55"/>
    ${postCards}

    <rect x="72" y="1405" width="936" height="58" rx="20" fill="#090813" stroke="#2b2450"/>
    <text x="540" y="1441" text-anchor="middle" fill="#9b94ad" font-family="Arial" font-size="15" font-weight="700" letter-spacing="3">FANTASMINHA • PERFIL SOCIAL DINÂMICO</text>
    <text x="540" y="1482" text-anchor="middle" fill="${accent}" font-family="Arial" font-size="13" font-weight="700">DADOS PÚBLICOS • IMAGENS REAIS • SEM LINKS DENTRO DA IMAGEM</text>
  </svg>`;
}

export async function renderSocialProfile(data, { avatarBuffer = null, posts = [] } = {}) {
  const safePosts = Array.from({ length: 3 }, (_, i) => posts[i] || null);
  const { default: sharp } = await import('sharp');
  return sharp(Buffer.from(buildSvg(data, avatarBuffer, safePosts))).png().toBuffer();
}

export default { renderSocialProfile };
