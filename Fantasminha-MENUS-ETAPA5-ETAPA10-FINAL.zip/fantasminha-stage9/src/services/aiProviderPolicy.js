import { env as defaultEnv } from '../config/env.js';
/**
 * Fantasminha — política canônica de provedores de IA.
 *
 * O projeto usa OpenAI como único gateway de IA. Este módulo é deliberadamente
 * pequeno: ele define o contrato e evita que um provider legado reapareça por
 * fallback silencioso.
 */
export const AI_PROVIDER = 'openai';

export function getAIProviderPolicy(env = defaultEnv) {
  const apiKey = String(env.OPENAI_API_KEY || '').trim();
  const model = String(env.OPENAI_MODEL || '').trim();
  return Object.freeze({
    provider: AI_PROVIDER,
    configured: Boolean(apiKey && model),
    hasKey: Boolean(apiKey),
    hasModel: Boolean(model),
    model,
    failClosed: true,
    allowLegacyProviders: false,
    allowFallbackToDifferentProvider: false
  });
}

export function assertOpenAIConfigured(env = defaultEnv) {
  const policy = getAIProviderPolicy(env);
  if (!policy.hasKey) {
    const error = new Error('OPENAI_API_KEY não configurada.');
    error.code = 'OPENAI_NOT_CONFIGURED';
    throw error;
  }
  if (!policy.hasModel) {
    const error = new Error('OPENAI_MODEL não configurado.');
    error.code = 'OPENAI_MODEL_NOT_CONFIGURED';
    throw error;
  }
  return policy;
}

export default { AI_PROVIDER, getAIProviderPolicy, assertOpenAIConfigured };
