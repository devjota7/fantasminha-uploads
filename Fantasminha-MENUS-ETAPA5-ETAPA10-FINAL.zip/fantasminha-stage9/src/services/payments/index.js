import { env } from '../../config/env.js';
import crypto from 'node:crypto';
import { readCollection, writeCollection, updateCollection } from '../../database/store.js';
import { recordAudit } from '../../platform/audit/index.js';
import { getRental, listPlans, renewRental } from '../platformCommercial.js';

const COLLECTION = 'payment_platform';
const MAX_BODY = 256 * 1024;
const API_BASE = 'https://api.mercadopago.com';
const STATUS_MAP = new Set(['pending', 'approved', 'authorized', 'in_process', 'rejected', 'cancelled', 'refunded', 'charged_back', 'in_mediation']);

function now() { return Date.now(); }
function id(prefix) { return `${prefix}-${crypto.randomUUID().replaceAll('-', '').slice(0, 20).toUpperCase()}`; }
function clone(value) { return value == null ? value : structuredClone(value); }
function db() {
  const d = readCollection(COLLECTION, { version: 1, payments: {}, operations: {} });
  return { version: 1, payments: d.payments || {}, operations: d.operations || {} };
}
function save(d) { writeCollection(COLLECTION, d); return d; }
function configured() { return Boolean(String(env.MERCADOPAGO_ACCESS_TOKEN || '').trim()); }
function webhookConfigured() { return Boolean(String(env.MERCADOPAGO_WEBHOOK_SECRET || '').trim()); }
function publicPayment(p) {
  if (!p) return null;
  const { secret, ...safe } = p;
  delete safe.rawWebhook;
  return clone(safe);
}
function money(value) {
  const n = Number(value);
  if (!Number.isFinite(n) || n <= 0 || n > 100000000) throw Object.assign(new Error('Valor do plano inválido.'), { statusCode: 400 });
  return Math.round(n * 100) / 100;
}
function safeStatus(value) {
  const s = String(value || 'pending').toLowerCase();
  return STATUS_MAP.has(s) ? s : 'pending';
}
function requestError(message, statusCode = 502, code = 'payment_provider_error') {
  return Object.assign(new Error(message), { statusCode, code });
}
async function mpRequest(path, { method = 'GET', body, timeoutMs = 15000, headers = {} } = {}) {
  if (!configured()) throw requestError('Mercado Pago não configurado.', 503, 'payment_provider_unavailable');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Math.max(1000, Number(timeoutMs) || 15000));
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      method,
      headers: { Authorization: `Bearer ${env.MERCADOPAGO_ACCESS_TOKEN}`, Accept: 'application/json', ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers },
      body: body ? JSON.stringify(body) : undefined,
      signal: controller.signal,
    });
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = null; }
    if (!response.ok) throw requestError('Mercado Pago recusou a operação.', response.status >= 500 ? 502 : 400, 'payment_provider_rejected');
    return data || {};
  } catch (error) {
    if (error?.code?.startsWith('payment_provider_')) throw error;
    if (error?.name === 'AbortError') throw requestError('Tempo limite ao consultar o Mercado Pago.', 504, 'payment_provider_timeout');
    throw requestError('Falha ao consultar o Mercado Pago.', 502, 'payment_provider_error');
  } finally { clearTimeout(timer); }
}

export function paymentConfig() {
  return {
    provider: 'mercadopago',
    configured: configured(),
    webhookConfigured: webhookConfigured(),
    checkoutReady: configured(),
    webhookReady: configured() && webhookConfigured(),
    returnUrlConfigured: Boolean(String(env.MERCADOPAGO_RETURN_URL || '').trim()),
    webhookUrlConfigured: Boolean(String(env.MERCADOPAGO_WEBHOOK_URL || '').trim()),
  };
}

export function listPayments({ clientId = null, rentalId = null } = {}) {
  return Object.values(db().payments)
    .filter(p => !clientId || p.clientId === clientId)
    .filter(p => !rentalId || p.rentalId === rentalId)
    .sort((a, b) => Number(b.createdAt) - Number(a.createdAt))
    .map(publicPayment);
}
export function getPayment(paymentId) { return publicPayment(db().payments[String(paymentId || '').trim()] || null); }

export async function createCheckout({ rentalId, planId, actor = 'owner', operationId = null } = {}) {
  const rid = String(rentalId || '').trim();
  const pid = String(planId || '').trim();
  if (!rid || !pid) throw Object.assign(new Error('rentalId e planId são obrigatórios.'), { statusCode: 400 });
  const rental = getRental(rid);
  if (!rental) throw Object.assign(new Error('Rental não encontrado.'), { statusCode: 404 });
  if (rental.state === 'REVOKED') throw Object.assign(new Error('Rental revogado não pode receber cobrança.'), { statusCode: 409 });
  const plan = listPlans().find(p => p.planId === pid);
  if (!plan || !plan.active) throw Object.assign(new Error('Plano inexistente ou inativo.'), { statusCode: 404 });
  const amount = money(plan.price);
  const d = db();
  if (operationId && d.operations[operationId]) return clone(d.operations[operationId].result);
  const duplicate = Object.values(d.payments).find(p => p.rentalId === rid && p.planId === pid && ['pending','in_process','authorized'].includes(p.status) && now() - Number(p.createdAt) < 15 * 60 * 1000 && p.checkoutUrl);
  if (duplicate) return { payment: publicPayment(duplicate), checkoutUrl: duplicate.checkoutUrl, reused: true };
  const paymentId = id('PAY');
  const externalReference = `FANT-PAY-${paymentId}`;
  const row = {
    paymentId, provider: 'mercadopago', clientId: rental.clientId || null, rentalId: rid, groupId: rental.groupId,
    planId: pid, planName: plan.name, durationDays: plan.days, amount, currency: 'BRL',
    status: 'pending', providerPreferenceId: null, providerPaymentId: null, externalReference,
    checkoutUrl: null, createdAt: now(), updatedAt: now(), paidAt: null, processedAt: null,
    failureCode: null, failureMessage: null,
  };
  d.payments[paymentId] = row;
  if (operationId) d.operations[operationId] = { type: 'CREATE_PAYMENT', at: now(), paymentId };
  save(d);
  try {
    const preference = await mpRequest('/checkout/preferences', {
      method: 'POST',
      body: {
        external_reference: externalReference,
        items: [{ id: pid, title: `Fantasminha — ${plan.name}`, quantity: 1, currency_id: 'BRL', unit_price: amount }],
        ...(env.MERCADOPAGO_WEBHOOK_URL ? { notification_url: env.MERCADOPAGO_WEBHOOK_URL } : {}),
        ...(env.MERCADOPAGO_RETURN_URL ? { back_urls: { success: env.MERCADOPAGO_RETURN_URL, pending: env.MERCADOPAGO_RETURN_URL, failure: env.MERCADOPAGO_RETURN_URL } } : {}),
      },
      headers: { 'X-Idempotency-Key': paymentId },
    });
    row.providerPreferenceId = String(preference.id || '');
    row.checkoutUrl = String(preference.init_point || preference.sandbox_init_point || '');
    if (!row.providerPreferenceId || !row.checkoutUrl) throw requestError('Mercado Pago não retornou um checkout utilizável.', 502, 'payment_checkout_invalid');
    row.updatedAt = now(); save(d);
    void recordAudit({ actor, target: paymentId, action: 'PAYMENT_CHECKOUT_CREATED', scope: 'payment', result: 'success', details: { provider: 'mercadopago', rentalId: rid, planId: pid } });
    const result = { payment: publicPayment(row), checkoutUrl: row.checkoutUrl };
    if (operationId) { const next = db(); next.operations[operationId] = { type: 'CREATE_PAYMENT', at: now(), paymentId, result: clone(result) }; save(next); }
    return result;
  } catch (error) {
    const failedDb = db();
    const current = failedDb.payments[paymentId];
    if (current) { current.status = 'rejected'; current.failureCode = error.code || 'payment_provider_error'; current.failureMessage = error.message; current.updatedAt = now(); save(failedDb); }
    throw error;
  }
}

export async function refreshPayment(paymentId, actor = 'system') {
  const idValue = String(paymentId || '').trim();
  const d = db(); const row = d.payments[idValue];
  if (!row) throw Object.assign(new Error('Pagamento não encontrado.'), { statusCode: 404 });
  if (!row.providerPaymentId) throw Object.assign(new Error('Pagamento ainda não possui referência de pagamento do provedor.'), { statusCode: 409 });
  const remote = await mpRequest(`/v1/payments/${encodeURIComponent(row.providerPaymentId)}`);
  return await reconcilePayment(remote, actor);
}

function paymentMatchesOrder(row, remote) {
  const ext = String(remote?.external_reference || '').trim();
  const amount = Number(remote?.transaction_amount);
  const currency = String(remote?.currency_id || '').toUpperCase();
  return ext === row.externalReference && Math.abs(amount - row.amount) < 0.005 && currency === row.currency;
}

export async function reconcilePayment(remote, actor = 'system') {
  const providerPaymentId = String(remote?.id || '').trim();
  if (!providerPaymentId) throw requestError('Pagamento remoto sem identificador.', 400, 'payment_invalid');
  const status = safeStatus(remote.status);
  let before = null;
  let claimed = false;
  let claimedPaymentId = null;
  const claimNow = now();
  const CLAIM_LEASE_MS = 2 * 60 * 1000;

  // Atualização + claim ocorrem dentro do lock da coleção. Isso impede dois
  // webhooks simultâneos de processarem a mesma renovação ao mesmo tempo.
  let d = await updateCollection(COLLECTION, current => {
    const next = { version: 1, payments: current.payments || {}, operations: current.operations || {} };
    let row = Object.values(next.payments).find(p => p.providerPaymentId === providerPaymentId);
    if (!row && remote?.external_reference) row = Object.values(next.payments).find(p => p.externalReference === String(remote.external_reference));
    if (!row) throw Object.assign(new Error('Pagamento não pertence a um pedido Fantasminha.'), { statusCode: 404, code: 'payment_not_found' });
    if (!paymentMatchesOrder(row, remote)) throw Object.assign(new Error('Pagamento remoto não corresponde ao pedido registrado.'), { statusCode: 409, code: 'payment_mismatch' });
    before = clone(row);
    row.providerPaymentId = providerPaymentId;
    row.status = status;
    row.updatedAt = claimNow;
    if (status === 'approved' && !row.paidAt) row.paidAt = claimNow;
    if (['rejected','cancelled','refunded','charged_back'].includes(status)) row.failureCode = String(remote.status_detail || status).slice(0, 120);

    if (status === 'approved' && !row.processedAt) {
      const processingAt = Number(row.processingAt || 0);
      if (!processingAt || claimNow - processingAt > CLAIM_LEASE_MS) {
        row.processingAt = claimNow;
        row.processingBy = `${process.pid}:${crypto.randomUUID()}`;
        claimed = true;
        claimedPaymentId = row.paymentId;
      }
    }
    return next;
  });

  const rowAfterClaim = d.payments[claimedPaymentId || before.paymentId];
  if (claimed && rowAfterClaim && !rowAfterClaim.processedAt) {
    const op = `MP-PAYMENT-${providerPaymentId}`;
    try {
      // renewRental deve ser idempotente por operationId; assim, se o processo
      // cair após renovar e antes de marcar processedAt, o retry não duplica a cobrança.
      const result = renewRental(rowAfterClaim.groupId, rowAfterClaim.durationDays, 'mercadopago', op);
      d = await updateCollection(COLLECTION, current => {
        const next = { version: 1, payments: current.payments || {}, operations: current.operations || {} };
        const row = next.payments[claimedPaymentId];
        if (row && !row.processedAt) {
          row.processedAt = now();
          row.updatedAt = now();
          row.processingAt = null;
          row.processingBy = null;
          next.operations[op] = { type: 'PAYMENT_RENTAL_RENEWAL', at: now(), result: clone(result) };
        }
        return next;
      });
    } catch (error) {
      await updateCollection(COLLECTION, current => {
        const next = { version: 1, payments: current.payments || {}, operations: current.operations || {} };
        const row = next.payments[claimedPaymentId];
        if (row && !row.processedAt) { row.processingAt = null; row.processingBy = null; row.updatedAt = now(); }
        return next;
      });
      throw error;
    }
  }

  const finalRow = d.payments[before.paymentId] || before;
  if (before.status !== finalRow.status || finalRow.processedAt) {
    void recordAudit({ actor, target: finalRow.paymentId, action: `PAYMENT_${status.toUpperCase()}`, scope: 'payment', result: 'success', before: publicPayment(before), after: publicPayment(finalRow), details: { provider: 'mercadopago', providerPaymentId } });
  }
  return publicPayment(finalRow);
}

function parseSignature(value) {
  const parts = {};
  for (const piece of String(value || '').split(',')) {
    const [k, ...rest] = piece.trim().split('=');
    if (k && rest.length) parts[k.trim()] = rest.join('=').trim();
  }
  return parts;
}
export function verifyWebhookSignature({ xSignature, xRequestId, dataId } = {}) {
  const secret = String(env.MERCADOPAGO_WEBHOOK_SECRET || '').trim();
  if (!secret) return false;
  const parsed = parseSignature(xSignature);
  if (!parsed.ts || !parsed.v1 || !xRequestId || !dataId) return false;
  const ts = Number(parsed.ts);
  const maxSkewMs = Math.max(1000, Number(env.WEBHOOK_MAX_SKEW_MS || 5 * 60 * 1000));
  if (!Number.isFinite(ts) || ts <= 0 || Math.abs(Date.now() - (ts * 1000)) > maxSkewMs) return false;
  const manifest = `id:${String(dataId)};request-id:${String(xRequestId)};ts:${String(parsed.ts)};`;
  const expected = crypto.createHmac('sha256', secret).update(manifest).digest('hex');
  try { return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(parsed.v1)); } catch { return false; }
}

export async function handleWebhook({ body, query = {}, headers = {} } = {}) {
  if (!webhookConfigured()) throw Object.assign(new Error('Webhook do Mercado Pago não configurado.'), { statusCode: 503, code: 'payment_webhook_unavailable' });
  const dataId = String(query['data.id'] || body?.data?.id || '').trim();
  const type = String(query.type || body?.type || '').trim();
  if (type && type !== 'payment') return { ignored: true };
  if (!dataId) throw Object.assign(new Error('Webhook sem data.id.'), { statusCode: 400, code: 'invalid_webhook' });
  if (!verifyWebhookSignature({ xSignature: headers['x-signature'], xRequestId: headers['x-request-id'], dataId })) {
    void recordAudit({ actor: 'mercadopago', target: dataId, action: 'PAYMENT_WEBHOOK_REJECTED', scope: 'payment', result: 'rejected', details: { reason: 'invalid_signature' } });
    throw Object.assign(new Error('Assinatura de webhook inválida.'), { statusCode: 401, code: 'invalid_webhook_signature' });
  }
  const remote = await mpRequest(`/v1/payments/${encodeURIComponent(dataId)}`);
  return { ignored: false, payment: await reconcilePayment(remote, 'mercadopago-webhook') };
}

export function paymentSnapshot() {
  const payments = Object.values(db().payments);
  return {
    provider: paymentConfig(),
    total: payments.length,
    pending: payments.filter(p => ['pending','in_process','authorized'].includes(p.status)).length,
    approved: payments.filter(p => p.status === 'approved').length,
    rejected: payments.filter(p => ['rejected','cancelled'].includes(p.status)).length,
    refunded: payments.filter(p => ['refunded','charged_back'].includes(p.status)).length,
    confirmedRevenue: payments.filter(p => p.status === 'approved').reduce((sum, p) => sum + Number(p.amount || 0), 0),
  };
}
