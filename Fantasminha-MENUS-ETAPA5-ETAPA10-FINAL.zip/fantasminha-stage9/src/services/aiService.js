import { env as defaultEnv } from '../config/env.js';
/**
 * Compatibility facade for the historical AI service name.
 * Implementation is OpenAI-only; there are no legacy provider adapters.
 */
import { getAIProviderPolicy } from './aiProviderPolicy.js';
import {
  getOpenAIConfig,
  requestOpenAI,
  requestOpenAIVision,
  requestOpenAIImage
} from './assistant/openaiProvider.js';

export function getAiConfig(env = defaultEnv) {
  const cfg = getOpenAIConfig(env);
  return {
    provider: 'openai',
    model: cfg.model,
    imageModel: cfg.imageModel,
    timeoutMs: cfg.timeoutMs,
    maxRetries: cfg.maxRetries,
    reasoningEffort: cfg.reasoningEffort
  };
}

export function getConfiguredProviders(env = defaultEnv) {
  const policy = getAIProviderPolicy(env);
  return policy.configured ? [{ name: policy.provider, model: policy.model }] : [];
}

export function sanitizeHistory(history = []) {
  if (!Array.isArray(history)) return [];
  return history.map(msg => ({
    role: msg?.role === 'assistant' ? 'assistant' : 'user',
    content: String(msg?.content ?? '').replace(/\u0000/g, '').slice(0, 12000)
  })).filter(msg => msg.content).slice(-16);
}

export function buildMessages(text, systemPrompt = null, history = []) {
  if (!text) throw new Error('Parâmetro obrigatório ausente: texto');
  const messages = [];
  if (systemPrompt) messages.push({ role: 'system', content: String(systemPrompt).slice(0, 30000) });
  messages.push(...sanitizeHistory(history));
  messages.push({ role: 'user', content: String(text).slice(0, 30000) });
  return messages;
}

export function classifyProviderError(error) {
  const status = Number(error?.status || error?.response?.status);
  if (status === 401 || status === 403) return { retryable: false, code: 'AUTH' };
  if (status === 400 || status === 404) return { retryable: false, code: 'REQUEST' };
  if (status === 408 || status === 409 || status === 425 || status === 429 || status >= 500) return { retryable: true, code: `HTTP_${status}` };
  if (error?.code === 'OPENAI_TIMEOUT') return { retryable: true, code: 'TIMEOUT' };
  return { retryable: false, code: 'UNKNOWN' };
}

export async function requestAI(options = {}) {
  return requestOpenAI(options);
}

export async function requestAIVision(options = {}) {
  return requestOpenAIVision(options);
}

export async function requestAIImage(options = {}) {
  return requestOpenAIImage(options);
}

export async function makeCognimaRequest(modelOrOptions = null, text = '', systemPrompt = null, history = []) {
  if (modelOrOptions && typeof modelOrOptions === 'object' && !Array.isArray(modelOrOptions)) return requestAI(modelOrOptions);
  return requestAI({ model: String(modelOrOptions || '').trim() || null, text, systemPrompt, history });
}

export default {
  requestAI,
  makeCognimaRequest,
  requestAIVision,
  requestAIImage,
  getAiConfig,
  getConfiguredProviders,
  classifyProviderError,
  buildMessages,
  sanitizeHistory
};
