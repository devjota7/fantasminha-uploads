import fs from 'node:fs';
import path from 'node:path';
import { readCollection, upsertUser, updateCollection } from '../database/store.js';
import { listNicks } from '../platform/nick/index.js';
import { listBirthdays } from '../platform/birthday/index.js';
import { resolveUserIdentity } from '../platform/identity/resolver.js';
import { configuredOwner } from '../core/permissions.js';
import { listBestFriends } from './social.js';
import relationshipManager from '../../dados/src/funcs/utils/relationships.js';
import config from '../core/config.js';
import { isDono, isSubdono, getDonos } from '../../dados/src/utils/database.js';
import { getBotRole } from './botRoles.js';
import { stylize } from '../respostas/estilo.js';
import { pickFrase } from '../respostas/frases.js';

const TZ = 'America/Sao_Paulo';
const normalizeId = value => String(value || '').trim().toLowerCase();
const baseId = value => normalizeId(value).split('@')[0].split(':')[0];
const phoneFrom = value => {
  const s = normalizeId(value);
  if (s.endsWith('@s.whatsapp.net') && /^\d+$/.test(baseId(s))) return baseId(s);
  return /^\d+$/.test(baseId(s)) ? baseId(s) : null;
};
const sameId = (a, b) => normalizeId(a) === normalizeId(b) || baseId(a) === baseId(b);
const clamp = (n, a = 0, b = 100) => Math.max(a, Math.min(b, Number(n) || 0));

function ensurePending() {
  globalThis.__profileActivity ||= { pending: new Map(), timer: null };
  const state = globalThis.__profileActivity;
  if (!state.timer) {
    state.timer = setInterval(() => { flushActivity().catch(() => {}); }, 30000);
    state.timer.unref?.();
  }
  return state;
}

function dateParts(date = new Date()) {
  const hour = new Intl.DateTimeFormat('pt-BR', { timeZone: TZ, hour: '2-digit', hour12: false }).format(date);
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date);
  return { hour, day };
}

export function recordMessage(userId, groupId, eventId = null) {
  if (!userId || !groupId) return;

  const state = ensurePending();
  const k = `${groupId}:${normalizeId(userId)}`;
  const { hour, day } = dateParts();

  const p = state.pending.get(k) || {
    userId,
    groupId,
    messages: 0,
    botUses: 0,
    days: {},
    hours: {},
    messageEvents: {},
    commandEvents: {}
  };

  p.messageEvents ||= {};
  p.commandEvents ||= {};

  // Com ID de evento, a mensagem só será contabilizada uma vez.
  if (eventId) {
    const eid = String(eventId);

    if (p.messageEvents[eid]) {
      return;
    }

    p.messageEvents[eid] = {
      timestamp: Date.now(),
      day,
      hour
    };
  } else {
    // Compatibilidade com chamadas antigas que não possuem ID.
    p.messages += 1;
    p.days[day] = (p.days[day] || 0) + 1;
    p.hours[hour] = (p.hours[hour] || 0) + 1;
  }

  state.pending.set(k, p);
}

export function recordCommandUsage(userId, groupId, eventId = null) {
  if (!userId || !groupId) return;

  const state = ensurePending();
  const k = `${groupId}:${normalizeId(userId)}`;

  const p = state.pending.get(k) || {
    userId,
    groupId,
    messages: 0,
    botUses: 0,
    days: {},
    hours: {},
    commandEvents: {}
  };

  p.commandEvents ||= {};
  p.messageEvents ||= {};

  // Com ID de evento, a execução só será contabilizada uma vez.
  if (eventId) {
    const eid = String(eventId);

    if (p.commandEvents[eid]) {
      return;
    }

    p.commandEvents[eid] = Date.now();
  } else {
    // Compatibilidade com chamadas antigas que não possuem ID.
    p.botUses += 1;
  }

  state.pending.set(k, p);
}

export async function flushActivity() {
  const state = globalThis.__profileActivity;
  if (!state?.pending?.size) return;
  const rows = [...state.pending.values()];
  state.pending.clear();
  await updateCollection('profile_activity', d => {
    d.byGroupUser ||= {};
    for (const p of rows) {
      const k = `${p.groupId}:${normalizeId(p.userId)}`;
      const cur = d.byGroupUser[k] || {
        userId: p.userId,
        groupId: p.groupId,
        messages: 0,
        botUses: 0,
        days: {},
        hours: {},
        messageEvents: {},
        commandEvents: {}
      };

      cur.messageEvents ||= {};
      cur.commandEvents ||= {};
      cur.days ||= {};
      cur.hours ||= {};

      // --------------------------------------------------------
      // MENSAGENS COM ID
      // --------------------------------------------------------
      for (const [eventId, meta] of Object.entries(p.messageEvents || {})) {
        if (cur.messageEvents[eventId]) continue;

        const data = meta && typeof meta === 'object'
          ? meta
          : { timestamp: Number(meta) || Date.now() };

        cur.messageEvents[eventId] = data;

        cur.messages += 1;

        if (data.day) {
          cur.days[data.day] = (cur.days[data.day] || 0) + 1;
        }

        if (data.hour != null) {
          const hour = String(data.hour).padStart(2, '0');
          cur.hours[hour] = (cur.hours[hour] || 0) + 1;
        }
      }

      // --------------------------------------------------------
      // COMPATIBILIDADE COM MENSAGENS SEM ID
      // --------------------------------------------------------
      cur.messages += Number(p.messages || 0);

      for (const [day, count] of Object.entries(p.days || {})) {
        cur.days[day] = (cur.days[day] || 0) + Number(count || 0);
      }

      for (const [hour, count] of Object.entries(p.hours || {})) {
        cur.hours[hour] = (cur.hours[hour] || 0) + Number(count || 0);
      }

      // --------------------------------------------------------
      // COMANDOS COM ID
      // --------------------------------------------------------
      for (const [eventId, timestamp] of Object.entries(p.commandEvents || {})) {
        if (cur.commandEvents[eventId]) continue;

        cur.commandEvents[eventId] = timestamp;
        cur.botUses += 1;
      }

      // --------------------------------------------------------
      // COMPATIBILIDADE COM COMANDOS SEM ID
      // --------------------------------------------------------
      cur.botUses += Number(p.botUses || 0);

      cur.updatedAt = Date.now();
      d.byGroupUser[k] = cur;
    }
    return d;
  }, { byGroupUser: {} });
}

function activityRows(groupId) {
  const d = readCollection('profile_activity', { byGroupUser: {} });
  return Object.values(d.byGroupUser || {}).filter(x => x.groupId === groupId);
}

function identityAliases(...values) {
  const base = new Set(values.flat(Infinity).filter(Boolean).map(normalizeId));
  const expanded = new Set(base);

  for (const val of base) {
    const unadorned = val.replace(/:\d+@/, '@');
    expanded.add(unadorned);
    const digits = unadorned.replace(/@.*$/, '').replace(/\D/g, '');
    if (!digits) continue;
    expanded.add(digits);

    if (unadorned.includes('@lid') || (digits.length >= 12 && !digits.startsWith('55'))) {
      try {
        const revPath = path.join(config.root, 'dados', 'database', 'qr-code', `lid-mapping-${digits}_reverse.json`);
        if (fs.existsSync(revPath)) {
          const raw = JSON.parse(fs.readFileSync(revPath, 'utf8'));
          if (raw) {
            const p = String(raw).replace(/\D/g, '');
            if (p) {
              expanded.add(p);
              expanded.add(`${p}@s.whatsapp.net`);
            }
          }
        }
      } catch (_) {}
    }

    if (digits.length >= 10 && (digits.length <= 11 || digits.startsWith('55'))) {
      const fullPhone = digits.length <= 11 ? `55${digits}` : digits;
      expanded.add(fullPhone);
      expanded.add(`${fullPhone}@s.whatsapp.net`);
      try {
        const fwdPath = path.join(config.root, 'dados', 'database', 'qr-code', `lid-mapping-${fullPhone}.json`);
        if (fs.existsSync(fwdPath)) {
          const raw = JSON.parse(fs.readFileSync(fwdPath, 'utf8'));
          if (raw) {
            const l = String(raw).replace(/\D/g, '');
            if (l) {
              expanded.add(l);
              expanded.add(`${l}@lid`);
            }
          }
        }
      } catch (_) {}
    }
  }

  return [...expanded];
}

function activity(groupId, userId, aliases = []) {
  const d = readCollection('profile_activity', { byGroupUser: {} });
  const candidates = identityAliases(userId, aliases);

  for (const id of candidates) {
    const direct = d.byGroupUser?.[`${groupId}:${id}`];
    if (direct) return direct;
  }

  const found = Object.values(d.byGroupUser || {}).find(x =>
    x.groupId === groupId && candidates.some(id => sameId(x.userId, id))
  );
  return found || { messages: 0, botUses: 0, days: {}, hours: {} };
}

function readLegacyGroup(groupId) {
  const file = path.join(config.root, 'dados', 'database', 'grupos', `${groupId}.json`);
  try { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {}; } catch { return {}; }
}

function legacyCounter(groupId, userId, aliases = []) {
  const group = readLegacyGroup(groupId);
  const candidates = identityAliases(userId, aliases);
  const row = (group.contador || []).find(x => {
    const id = normalizeId(x?.id);
    return candidates.includes(id) || candidates.some(candidate => sameId(id, candidate));
  });
  if (!row) return { messages: 0, botUses: 0, score: 0 };
  const messages = Number(row.msg || 0);
  const botUses = Number(row.cmd || 0);
  const stickers = Number(row.figu || 0);
  return { messages, botUses, score: messages + botUses + stickers };
}

function mergedActivity(groupId, userId, aliases = []) {
  const modern = activity(groupId, userId, aliases);
  const legacy = legacyCounter(groupId, userId, aliases);

  // O sistema "moderno" deduplica por ID único de mensagem/comando; o
  // "legado" (grupos/*.json) não tem essa proteção e pode inflar em
  // cenários de reconexão/reenvio. Uma vez que o usuário tenha qualquer
  // dado real no sistema moderno, ele é a fonte de verdade (precisa).
  // O legado só serve como base histórica para quem nunca foi rastreado
  // pelo sistema moderno (ex.: atividade anterior à migração).
  const hasModernData = Boolean(modern.updatedAt) || Object.keys(modern.messageEvents || {}).length > 0 || Object.keys(modern.commandEvents || {}).length > 0;

  return {
    ...modern,
    messages: hasModernData ? Number(modern.messages || 0) : legacy.messages,
    botUses: hasModernData ? Number(modern.botUses || 0) : legacy.botUses,
    legacyScore: legacy.score,
    lastActivityAt: Object.values(modern.messageEvents || {}).concat(Object.values(modern.commandEvents || {})).map(x => Number(typeof x === 'object' ? x.timestamp : x)).filter(Number.isFinite).reduce((a, x) => Math.max(a, x), Number(modern.updatedAt || 0))
  };
}

function peakHour(row) {
  const entries = Object.entries(row?.hours || {})
    .filter(([, v]) => Number(v) > 0)
    .sort((a, b) => Number(b[1]) - Number(a[1]) || a[0].localeCompare(b[0]));
  return entries.length ? `${String(entries[0][0]).padStart(2, '0')}h` : 'Não informado';
}

function inactivityPercent(groupId, userId, participants = []) {
  const ids = [...new Set(participants.map(x => baseId(x)).filter(Boolean))];
  const rows = ids.map(id => ({ id, activity: mergedActivity(groupId, id) }));
  if (!rows.length) return null;
  const mine = rows.find(x => sameId(x.id, userId))?.activity?.messages ?? mergedActivity(groupId, userId).messages;
  const active = rows.filter(x => Number(x.activity.messages) > 0);
  if (active.length < 2 || Number(mine) <= 0) return active.length < 2 ? null : 100;

  // Percentil de inatividade: 0% para o topo da atividade e 100% para o fundo.
  // Empates recebem a mesma posição média, evitando que a ordem dos participantes distorça o resultado.
  const greater = active.filter(x => Number(x.activity.messages) > Number(mine)).length;
  const equal = active.filter(x => Number(x.activity.messages) === Number(mine)).length;
  const percentileFromTop = (greater + ((equal - 1) / 2)) / Math.max(1, active.length - 1);
  return Math.round(clamp(percentileFromTop * 100));
}

function rankativo(groupId, userId, participants = [], aliases = []) {
  const group = readLegacyGroup(groupId);
  const counter = Array.isArray(group.contador) ? group.contador : [];
  if (!counter.length) return null;
  const allowed = new Set(participants.map(x => baseId(x)).filter(Boolean));
  const rows = counter
    .filter(x => x?.id && (!allowed.size || allowed.has(baseId(x.id))))
    .map(x => ({ id: x.id, score: Number(x.msg || 0) + Number(x.cmd || 0) + Number(x.figu || 0), messages: Number(x.msg || 0), commands: Number(x.cmd || 0), stickers: Number(x.figu || 0) }));
  if (!rows.length) return null;
  rows.sort((a, b) => b.score - a.score || b.messages - a.messages || b.commands - a.commands || baseId(a.id).localeCompare(baseId(b.id)));
  const candidates = identityAliases(userId, aliases);
  const index = rows.findIndex(x => candidates.includes(normalizeId(x.id)) || candidates.some(candidate => sameId(x.id, candidate)));
  return index < 0 ? null : index + 1;
}

function groupWarns(groupId, userId) {
  const d = readCollection('groups', { byId: {} });
  const warns = d.byId?.[groupId]?.warns || d.byId?.[groupId]?.warnings || {};
  const direct = warns?.[userId];
  if (direct != null) return Array.isArray(direct) ? direct.length : Number(direct) || 0;
  const found = Object.entries(warns).find(([id]) => sameId(id, userId));
  return Array.isArray(found?.[1]) ? found[1].length : Number(found?.[1] || 0) || 0;
}

function birthdayFor(groupId, userId, aliases = []) {
  const allIds = [userId, ...aliases].filter(Boolean);
  const row = listBirthdays(groupId).find(x => allIds.some(id => sameId(x.platformId, id) || sameId(x.memberId, id)));
  if (!row) return null;
  return `${String(row.day).padStart(2, '0')}/${String(row.month).padStart(2, '0')}${row.year ? `/${row.year}` : ''}`;
}

function calculateAge(birthday, now = new Date()) {
  if (!birthday?.year) return null;
  const birthYear = Number(birthday.year);
  const month = Number(birthday.month);
  const day = Number(birthday.day);
  if (!Number.isInteger(birthYear) || !Number.isInteger(month) || !Number.isInteger(day)) return null;
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(now);
  const currentYear = Number(parts.find(x => x.type === 'year')?.value);
  const currentMonth = Number(parts.find(x => x.type === 'month')?.value);
  const currentDay = Number(parts.find(x => x.type === 'day')?.value);
  let age = currentYear - birthYear;
  if (currentMonth < month || (currentMonth === month && currentDay < day)) age -= 1;
  return age >= 0 ? age : null;
}

function formatPhone(phone) {
  const digits = String(phone || '').replace(/\D/g, '');
  if (!digits) return 'Não informado';
  const br = digits.startsWith('55') ? digits.slice(2) : digits;
  if (br.length === 11) return `+55 (${br.slice(0,2)}) ${br.slice(2,7)}-${br.slice(7)}`;
  if (br.length === 10) return `+55 (${br.slice(0,2)}) ${br.slice(2,6)}-${br.slice(6)}`;
  return `+${digits}`;
}

function activityBar(percent) {
  if (percent == null) return '—';
  const filled = Math.max(0, Math.min(10, Math.round(percent / 10)));
  return '▰'.repeat(filled) + '▱'.repeat(10 - filled);
}

const PROFILE_BIO_MAX = 80;
function profileBio(value) {
  const bio = String(value || '').trim();
  if (!bio) return 'Não cadastrada';
  if (bio.length <= PROFILE_BIO_MAX) return bio;
  return `${bio.slice(0, PROFILE_BIO_MAX - 1).trimEnd()}…`;
}

function relationshipFor(userId) {
  try {
    const pair = relationshipManager.getActivePairForUser(userId);
    if (!pair) return { status: 'Solteiro(a)', partnerId: null };
    const status = pair.pair?.status;
    // Relacionamento é entre as duas pessoas, não é escopado por grupo:
    // deve aparecer no ×perfil independente de em qual grupo for checado.
    if (status === 'casamento') return { status: 'Casado(a)', partnerId: pair.partnerId };
    if (status === 'namoro') return { status: 'Namorando', partnerId: pair.partnerId };
    return { status: 'Em uma brincadeira', partnerId: pair.partnerId };
  } catch {
    return { status: 'Solteiro(a)', partnerId: null };
  }
}

function roleFor(target, participants = [], groupAdmins = [], groupOwner = null, aliases = [], premium = false, isCallerOwner = false, groupId = null) {
  const allIds = [target, ...aliases].filter(Boolean);
  const ownerNum = String(config.ownerNumber || config.public?.numerodono || '').replace(/\D/g, '');
  const ownerLid = String(config.ownerLid || config.public?.lidowner || '').replace(/\D/g, '');
  const isMain = allIds.some(id => {
    const d = String(id).replace(/:\d+@.*$/, '').replace(/\D/g, '');
    return (ownerNum && d === ownerNum) || (ownerLid && d === ownerLid) || configuredOwner(id);
  });
  if (isMain) return 'Dono Principal';

  const donosList = typeof getDonos === 'function' ? getDonos() : [];
  for (let i = 0; i < donosList.length; i++) {
    const item = donosList[i];
    const itemPhone = item?.phone ? String(item.phone).replace(/\D/g, '') : '';
    const itemLid = item?.lid ? String(item.lid).replace(/:\d+@/, '@').trim() : '';
    const itemJid = item?.jid ? String(item.jid).replace(/:\d+@/, '@').trim() : '';
    const match = allIds.some(id => {
      const unadorned = String(id).replace(/:\d+@/, '@').trim();
      const digits = unadorned.replace(/\D/g, '');
      return (itemPhone && digits.length >= 10 && itemPhone === digits) ||
             (itemLid && itemLid === unadorned) ||
             (itemJid && itemJid === unadorned);
    });
    if (match) return `Dono ${i + 1}`;
  }

  if (isCallerOwner || allIds.some(id => isDono(id))) return 'Dono 1';
  if (allIds.some(id => isSubdono(id))) return 'Subdono';
  if (groupOwner && allIds.some(id => sameId(groupOwner, id))) return 'Criador do Grupo';
  const participant = participants.find(p => allIds.some(id => sameId(p?.id || p?.jid || p?.participant, id)));
  if (participant?.admin === 'superadmin') return 'Criador do Grupo';
  if (participant?.admin === 'admin') return 'Administrador';
  if (groupAdmins.some(x => allIds.some(id => sameId(x, id)))) return 'Administrador';
  if (premium) return 'VIP';
  return baseId(target) ? 'Membro' : 'Não informado';
}

function groupRoleFor(target, participants = [], groupAdmins = [], groupOwner = null, aliases = []) {
  const allIds = [target, ...aliases].filter(Boolean);
  const participant = participants.find(p => allIds.some(id => sameId(p?.id || p?.jid || p?.participant, id)));
  if (groupOwner && allIds.some(id => sameId(groupOwner, id))) return '👑 Dono do Grupo';
  if (participant?.admin === 'superadmin') return '👑 Dono do Grupo';
  if (participant?.admin === 'admin') return '🛡️ Administrador';
  if (groupAdmins.some(x => allIds.some(id => sameId(x, id)))) return '🛡️ Administrador';
  return '👤 Membro';
}

function botRoleFor(groupId, target, aliases = [], isCallerOwner = false, premium = false) {
  const ids = [target, ...aliases].filter(Boolean);
  if (isCallerOwner || ids.some(id => configuredOwner(id))) {
    return { id: 'owner', label: '👑 Dono Supremo', permission: 100 };
  }
  for (const id of ids) {
    const role = getBotRole(groupId, id);
    if (role) return role;
  }
  if (premium) return { id: 'vip', label: '💎 VIP', permission: 40 };
  return { id: 'user', label: '👤 Membro', permission: 10 };
}

function formatDateTime(value) {
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return { date: 'Não informado', time: 'Não informado' };
  return {
    date: d.toLocaleDateString('pt-BR', { timeZone: TZ }),
    time: d.toLocaleTimeString('pt-BR', { timeZone: TZ, hour12: false })
  };
}

function formatNumber(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString('pt-BR') : '0';
}

export async function buildPublicProfile({
  userId,
  displayUserId = null,
  groupId,
  pushname = '',
  groupParticipants = [],
  groupParticipantObjects = [],
  groupAdmins = [],
  groupOwner = null,
  resolvePNForLID = null,
  now = Date.now(),
  isCallerOwner = false,
  isGroup = Boolean(String(groupId || '').endsWith('@g.us'))
}) {
  const requested = displayUserId || userId;
  const identity = await resolveUserIdentity({
    sender: userId,
    pushname,
    groupParticipantObjects,
    resolvePNForLID
  }, requested);
  const target =
    identity.realJid ||
    (identity.number ? `${identity.number}@s.whatsapp.net` : null) ||
    requested;
  const u = await upsertUser(target, { name: identity.name || pushname || '' });
  const participants = groupParticipants.length ? groupParticipants : groupParticipantObjects.map(p => p?.id || p?.jid || p?.participant).filter(Boolean);
  const participantsObjects = groupParticipantObjects.length ? groupParticipantObjects : participants.map(id => ({ id }));
  // O WhatsApp pode entregar o mesmo membro em LID e PN.
  // O histórico pode estar gravado no LID enquanto a identidade atual usa PN.
  const profileAliases = identityAliases(
    requested, userId, target, identity.lid, identity.realJid,
    identity.raw?.id, identity.raw?.jid, identity.raw?.participant,
    identity.raw?.phoneNumber, identity.raw?.pn, identity.raw?.phone, identity.raw?.number
  );
  const act = mergedActivity(groupId, target, profileAliases);
  const nick = listNicks(groupId).find(x =>
    profileAliases.some(a => sameId(x.platformId, a) || sameId(x.memberId, a))
  );
  const rel = relationshipFor(target);
  const friends = listBestFriends(target, profileAliases);
  const bestFriend = friends[0] ? (phoneFrom(friends[0]) ? `${phoneFrom(friends[0])}@s.whatsapp.net` : friends[0]) : null;
  const last = formatDateTime(act.lastActivityAt || 0);
  let phone = identity.number || phoneFrom(target);
  if (phone && phone.length >= 12 && !phone.startsWith('55')) {
    try {
      const revPath = path.join(config.root, 'dados', 'database', 'qr-code', `lid-mapping-${phone}_reverse.json`);
      if (fs.existsSync(revPath)) {
        const val = JSON.parse(fs.readFileSync(revPath, 'utf8'));
        if (val) phone = String(val).replace(/\D/g, '');
      }
    } catch (_) {}
  }
  const realMentionJid = (phone && phone.length >= 10) ? `${phone.length <= 11 ? '55' + phone : phone}@s.whatsapp.net` : (identity.mentionJid || target);
  const groupRank = rankativo(groupId, target, participants, profileAliases);
  const inactivity = inactivityPercent(groupId, target, participants);
  const relationshipPartner = rel.partnerId ? (await resolveUserIdentity({ groupParticipantObjects: participantsObjects }, rel.partnerId)).realJid || rel.partnerId : null;
  const economy = u.economy || {};
  const rpg = u.rpg || {};
  // premiumActive precisa existir ANTES de botRoleFor, que a recebe como argumento -
  // estava declarada mais abaixo (TDZ), o que derrubava ×perfil com
  // "Cannot access 'premiumActive' before initialization" em toda chamada.
  const premiumUntil = Number(u.premium?.until || 0);
  const premiumActive = !!u.premium?.active && (!premiumUntil || premiumUntil > now);
  const botRole = botRoleFor(groupId, target, profileAliases, isCallerOwner, premiumActive);
  const groupRole = groupRoleFor(target, participantsObjects, groupAdmins, groupOwner, profileAliases);
  const inventory = economy.inventory && typeof economy.inventory === 'object' ? economy.inventory : {};

  return {
    userId: target,
    displayUserId: target,
    isGroup: !!isGroup,
    number: phone,
    mention: realMentionJid,
    name: identity.name || pushname || 'Não informado',
    bio: u.profile?.bio || '',
    nick: nick?.nick || 'Não cadastrado',
    birthday: birthdayFor(groupId, target, profileAliases) || 'Não cadastrado',
    birthdayData: (() => {
      const all = listBirthdays(groupId);
      return all.find(x => profileAliases.some(a => sameId(x.platformId, a) || sameId(x.memberId, a))) || null;
    })(),
    age: calculateAge((() => {
      const all = listBirthdays(groupId);
      return all.find(x => profileAliases.some(a => sameId(x.platformId, a) || sameId(x.memberId, a))) || null;
    })(), new Date(now)),
    role: roleFor(target, participantsObjects, groupAdmins, groupOwner, profileAliases, premiumActive, isCallerOwner, groupId),
    groupRole,
    botRole: botRole.label,
    botRoleId: botRole.id,
    messages: Number(act.messages || 0),
    botUses: Number(act.botUses || 0),
    inactivityPercent: inactivity,
    position: groupRank,
    totalParticipants: participants.length || null,
    warnings: isGroup ? groupWarns(groupId, target) : 0,
    relationship: rel.status,
    relationshipPartner,
    bestFriend,
    peakHour: peakHour(act),
    lastProfileAt: act.lastActivityAt || null,
    lastDate: last.date,
    lastTime: last.time,
    premium: premiumActive,
    premiumPlan: u.premium?.plan || null,
    premiumUntil: premiumUntil || null,
    economy: { wallet: Number(economy.wallet || 0), bank: Number(economy.bank || 0), total: Number(economy.wallet || 0) + Number(economy.bank || 0) },
    rpg: { class: rpg.class || null, level: Number(rpg.level || 1), xp: Number(rpg.xp || 0), hp: Number(rpg.hp || 0), maxHp: Number(rpg.maxHp || 0), attack: Number(rpg.attack || 0), armor: Number(rpg.armor || 0), attributes: rpg.attributes || {} },
    inventoryCount: Object.keys(inventory).length
  };
}

function mentionToken(jid) {
  const phone = phoneFrom(jid);
  return `@${phone || baseId(jid)}`;
}

export function profileText(p) {
  const isGroup = p.isGroup === true;
  const bestFriend = p.bestFriend ? mentionToken(p.bestFriend) : 'Não cadastrado';
  const activity = isGroup && p.inactivityPercent != null
    ? Math.max(0, Math.min(100, 100 - Number(p.inactivityPercent)))
    : null;
  const rank = isGroup && p.position ? `#${p.position} de ${p.totalParticipants || '—'}` : (isGroup ? 'Sem colocação' : null);
  const name = p.name || 'Não informado';
  const mention = p.mention ? mentionToken(p.mention) : 'Usuário';
  const partner = p.relationshipPartner ? mentionToken(p.relationshipPartner) : '';
  const relationship = p.relationship || 'Solteiro(a)';
  const premium = p.premium
    ? `💎 Ativo`
    : '⚪ Inativo';
  const premiumDate = p.premium && p.premiumUntil ? formatDateTime(p.premiumUntil).date : null;
  const birthday = p.birthday || 'Não cadastrado';
  const age = p.age != null ? ` (${p.age} ${p.age === 1 ? 'ano' : 'anos'})` : '';
  const warningCount = Number(p.warnings || 0);
  const warningsLimit = 3;
  const warningStatus = warningCount === 0 ? '🟢 Limpo' : warningCount >= warningsLimit ? '🔴 Limite' : '🟡 Atenção';
  const peak = isGroup ? (p.peakHour || '—') : null;
  const bio = profileBio(p.bio);
  const lastDate = isGroup ? (p.lastDate || '—') : null;
  const lastTime = isGroup ? (p.lastTime || null) : null;
  const relationshipLine = relationship === 'Namorando' && partner
    ? `Namorando:\n↳ ${partner}`
    : relationship === 'Casado(a)' && partner
      ? `Casado(a):\n↳ ${partner}`
      : `Relação: ${relationship}`;

  const lines = [
    `† DOSSIÊ · ${stylize('PERFIL DA ALMA')}`,
    `† ${stylize('IDENTIDADE')}`,
    `• Tag: ${mention}`,
    `• Nome: ${name}`,
    `• Apelido: ${p.nick || 'Não cadastrado'}`,
    `• Niver: ${birthday}${age}`,
    '• Bio:',
    `  “${bio}”`,
    `† ${stylize('STATUS & CARGOS')}`
  ];

  if (isGroup) lines.push(`• Grupo: ${p.groupRole || '👤 Membro'}`);
  lines.push(`• Bot: ${p.botRole || '👤 Usuário'}`);
  lines.push(`• VIP: ${premium}`);
  if (premiumDate) lines.push(`↳ Até: ${premiumDate}`);

  lines.push(`† ${stylize('MARCAS DA ALMA')}`);
  if (isGroup) {
    lines.push(`◈ Mensagens: ${formatNumber(p.messages)} no grupo`);
    lines.push(`⚡ Comandos: ${formatNumber(p.botUses)}`);
    lines.push(`♛ Ranking: ${rank}`);
    lines.push(`⚠️ Advs: ${formatNumber(warningCount)}/${warningsLimit} [${warningStatus}]`);
    lines.push(`◔ Atividade: ${activity == null ? '—' : `${activity}%`}`);
    if (activity != null) lines.push(`↳ ${activityBar(activity)}`);
    lines.push(`◷ Horário Pico: ${peak}`);
  } else {
    lines.push(`⚡ Comandos: ${formatNumber(p.botUses)}`);
  }

  lines.push(`† ${stylize('LAÇOS & RELAÇÕES')}`);
  lines.push(`• Best: ${bestFriend}`);
  lines.push(...relationshipLine.split('\n'));

  if (isGroup) {
    lines.push(`† ${stylize('ÚLTIMA ATIVIDADE')}`);
    lines.push(`• Última msg: ${lastDate}${lastTime ? ` às ${lastTime}` : ''}`);
  }

  lines.push(`† ${pickFrase('info', Math.random, `profile:${normalizeId(p.mention || p.name || 'perfil')}`)}`);
  return lines.join('\n');
}

export default { buildPublicProfile, profileText, recordMessage, recordCommandUsage, flushActivity };
