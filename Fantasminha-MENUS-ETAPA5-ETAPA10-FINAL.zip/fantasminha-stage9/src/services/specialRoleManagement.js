/** Serviço central de gerenciamento dos cargos/status especiais.
 * Etapa 9: painel e futuros comandos rápidos passam pela mesma API.
 */
import config from '../core/config.js';
import { SPECIAL_ROLE, SPECIAL_ROLE_META, SPECIAL_ROLES_FOR_MANAGEMENT } from '../core/specialRoles.js';
import { resolveUserIdentity } from '../platform/identity/resolver.js';
import { grantGlobalRole, revokeGlobalRole, listGlobalRoleUsers } from './specialRoleRegistry.js';
import { grantBotRole, revokeBotRole, listBotRoles, BOT_ROLE } from './botRoles.js';
import { getUser, readCollection } from '../database/store.js';
import { addDono, removeDono, getDonos, addSubdono, removeSubdono, getSubdonos } from '../../dados/src/utils/database.js';
import { grantVip, revokeVip, listActiveVipUsers } from './vipBenefits.js';
import { ROLE_PERMISSION, hasRolePermission } from '../core/rolePermissionMatrix.js';
import { resolveSpecialRoleIdentity } from '../core/specialRoleIdentity.js';

const norm = v => String(v ?? '').trim().toLowerCase();
const same = (a, b) => {
  const x = norm(a).replace(/:\d+(?=@)/, '');
  const y = norm(b).replace(/:\d+(?=@)/, '');
  return x === y || (x && y && x.split('@')[0] === y.split('@')[0]);
};
const idsOf = identity => [...new Set([identity?.realJid, identity?.lid, identity?.requested].filter(Boolean))];
const roleMeta = roleId => SPECIAL_ROLE_META[roleId] || null;

const ROLE_MANAGEMENT_PERMISSION = Object.freeze({
  [SPECIAL_ROLE.CO_OWNER]: ROLE_PERMISSION.MANAGE_CO_OWNER,
  [SPECIAL_ROLE.SUB_OWNER]: ROLE_PERMISSION.MANAGE_SUB_OWNER,
  [SPECIAL_ROLE.SUPPORT]: ROLE_PERMISSION.MANAGE_SUPPORT,
  [SPECIAL_ROLE.ARANHA]: ROLE_PERMISSION.MANAGE_ARANHA,
  [SPECIAL_ROLE.VIP]: ROLE_PERMISSION.MANAGE_VIP
});

export function canManageSpecialRole(resolvedActor, targetRoleId) {
  const permission = ROLE_MANAGEMENT_PERMISSION[String(targetRoleId || '').trim()];
  if (!permission) return false;
  return (resolvedActor?.administrativeRoles || []).some(role => hasRolePermission(role, permission));
}

async function assertCanManageSpecialRole(ctx, targetRoleId) {
  const actor = await resolveSpecialRoleIdentity({ ...ctx, fromMe: false, isBotSender: false });
  if (!canManageSpecialRole(actor, targetRoleId)) {
    const error = new Error('Você não possui permissão para gerenciar este cargo.');
    error.code = 'SPECIAL_ROLE_MANAGEMENT_DENIED';
    error.targetRole = targetRoleId;
    error.actorRoles = actor.roles;
    throw error;
  }
  return actor;
}

export function manageableRoles() {
  return SPECIAL_ROLES_FOR_MANAGEMENT.map(roleId => ({ ...roleMeta(roleId) }));
}

export async function resolveTarget(ctx, target) {
  const identity = await resolveUserIdentity(ctx, target);
  if (!identity?.requested && !identity?.realJid && !identity?.lid) throw new Error('Usuário inválido. Mencione, responda ou informe o identificador.');
  return identity;
}

function ownerTarget(identity) {
  const id = identity.realJid || identity.lid || identity.requested;
  return { phone: identity.number || '', jid: identity.realJid || (id?.endsWith?.('@s.whatsapp.net') ? id : ''), lid: identity.lid || (id?.endsWith?.('@lid') ? id : null) };
}

function legacyMatch(list, identity) {
  const ids = idsOf(identity);
  return list.some(item => {
    const vals = typeof item === 'string' ? [item] : [item?.phone, item?.jid, item?.lid];
    return vals.some(v => v && ids.some(id => same(v, id)));
  });
}

async function ensureNotProtected(ctx, identity, roleId) {
  const special = (await import('../core/specialRoleIdentity.js')).resolveSpecialRoleIdentity(ctx, identity.realJid || identity.lid || identity.requested);
  if (special.roles.includes(SPECIAL_ROLE.OWNER)) throw new Error('O Dono Principal é fixo e não pode receber ou perder um cargo subordinado por este painel.');
  if (roleId === SPECIAL_ROLE.CO_OWNER && special.roles.some(r => [SPECIAL_ROLE.SUB_OWNER, SPECIAL_ROLE.SUPPORT].includes(r))) throw new Error('Um usuário com cargo administrativo inferior deve ser removido desse cargo antes de virar Co-Dono.');
  if (roleId === SPECIAL_ROLE.SUPPORT && special.roles.some(r => [SPECIAL_ROLE.CO_OWNER, SPECIAL_ROLE.SUB_OWNER].includes(r))) throw new Error('Dono, Co-Dono e Subdono não podem receber Suporte.');
  if (roleId === SPECIAL_ROLE.SUB_OWNER && special.roles.some(r => [SPECIAL_ROLE.CO_OWNER].includes(r))) throw new Error('Co-Dono não pode receber Subdono.');
}

export async function grant(ctx, roleId, target, options = {}) {
  await assertCanManageSpecialRole(ctx, roleId);
  const identity = await resolveTarget(ctx, target);
  await ensureNotProtected(ctx, identity, roleId);
  const id = identity.realJid || identity.lid || identity.requested;
  switch (roleId) {
    case SPECIAL_ROLE.CO_OWNER: {
      const result = await addDono(ownerTarget(identity), config.ownerNumber, ctx.sock || ctx.socket || null);
      return { changed: !!result.success, roleId, identity, message: result.message };
    }
    case SPECIAL_ROLE.SUB_OWNER: {
      const result = await addSubdono(id, config.ownerNumber, ctx.sock || ctx.socket || null);
      return { changed: !!result.success, roleId, identity, message: result.message };
    }
    case SPECIAL_ROLE.SUPPORT:
      return { ...(await grantGlobalRole(id, roleId, ctx.sender)), identity };
    case SPECIAL_ROLE.ARANHA: {
      if (!ctx.from?.endsWith?.('@g.us')) throw new Error('O cargo Aranha é vinculado a um grupo. Use o painel dentro do grupo.');
      const result = await grantBotRole(ctx.from, id, BOT_ROLE.ARANHA, ctx.sender);
      return { changed: result.changed, roleId, identity, message: result.changed ? 'Aranha ativada neste grupo.' : 'Aranha já estava ativa neste grupo.' };
    }
    case SPECIAL_ROLE.VIP: {
      const result = await grantVip(id, { days: options.days, plan: options.plan });
      return { changed: result.changed, roleId, identity, message: result.changed ? `VIP ${result.plan} ativado por ${result.days} dias.` : `VIP já estava ativo; validade preservada.` };
    }
    default: throw new Error('Cargo não gerenciável.');
  }
}

export async function revoke(ctx, roleId, target) {
  await assertCanManageSpecialRole(ctx, roleId);
  const identity = await resolveTarget(ctx, target);
  const id = identity.realJid || identity.lid || identity.requested;
  if (roleId === SPECIAL_ROLE.OWNER) throw new Error('Dono Principal é fixo e não pode ser removido pelo painel.');
  switch (roleId) {
    case SPECIAL_ROLE.CO_OWNER: {
      const result = await removeDono(ownerTarget(identity), ctx.sock || ctx.socket || null);
      return { changed: !!result.success, roleId, identity, message: result.message };
    }
    case SPECIAL_ROLE.SUB_OWNER: {
      const result = await removeSubdono(id, ctx.sock || ctx.socket || null);
      return { changed: !!result.success, roleId, identity, message: result.message };
    }
    case SPECIAL_ROLE.SUPPORT:
      return { ...(await revokeGlobalRole(id, roleId)), identity, message: 'Suporte removido.' };
    case SPECIAL_ROLE.ARANHA: {
      if (!ctx.from?.endsWith?.('@g.us')) throw new Error('O cargo Aranha é vinculado a um grupo. Use o painel dentro do grupo.');
      const result = await revokeBotRole(ctx.from, id, BOT_ROLE.ARANHA);
      return { changed: result.changed, roleId, identity, message: result.changed ? 'Aranha removida deste grupo.' : 'Aranha já estava inativa neste grupo.' };
    }
    case SPECIAL_ROLE.VIP: {
      const result = await revokeVip(id);
      return { changed: result.changed, roleId, identity, message: 'VIP removido.' };
    }
    default: throw new Error('Cargo não gerenciável.');
  }
}

function rowsFromIds(roleId, ids) {
  return [...new Set((ids || []).map(x => norm(x)).filter(Boolean))].map(id => ({ id, roleId }));
}

export function listRoleAssignments(ctx, roleId) {
  switch (roleId) {
    case SPECIAL_ROLE.CO_OWNER: return rowsFromIds(roleId, getDonos().map(x => typeof x === 'string' ? x : (x?.jid || x?.lid || x?.phone)));
    case SPECIAL_ROLE.SUB_OWNER: return rowsFromIds(roleId, getSubdonos());
    case SPECIAL_ROLE.SUPPORT: return rowsFromIds(roleId, listGlobalRoleUsers(roleId));
    case SPECIAL_ROLE.ARANHA: return ctx.from?.endsWith?.('@g.us') ? listBotRoles(ctx.from).filter(x => x.role?.id === BOT_ROLE.ARANHA).map(x => ({ id: x.userId, roleId })) : [];
    case SPECIAL_ROLE.VIP: {
      return listActiveVipUsers().map(id => ({ id, roleId }));
    }
    default: return [];
  }
}

export async function inspect(ctx, target) {
  const identity = await resolveTarget(ctx, target);
  const { resolveSpecialRoleIdentity } = await import('../core/specialRoleIdentity.js');
  const resolved = await resolveSpecialRoleIdentity(ctx, identity.realJid || identity.lid || identity.requested);
  return { identity, roles: resolved.roles, administrativeRoles: resolved.administrativeRoles, systemRoles: resolved.systemRoles };
}

export default { manageableRoles, resolveTarget, grant, revoke, listRoleAssignments, inspect, canManageSpecialRole };
