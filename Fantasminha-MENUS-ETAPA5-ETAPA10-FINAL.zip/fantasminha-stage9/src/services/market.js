import { readCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import * as economy from './economy.js';

export async function listOffers() {
  const M = readCollection('market', { offers: [] });
  return (M.offers || []).filter(o => o.active !== false);
}

export async function createOffer(sellerId, itemId, price, qty = 1, sellerName = '') {
  const p = economy.assertAmount(price);
  const q = economy.assertAmount(qty);
  if (!itemId || q > 100000 || !Number.isSafeInteger(p * q)) throw new ValidationError('anunciar <item> <preço> [qtd] — quantidade deve ser positiva.');
  const operationId = `market-create:${sellerId}:${itemId}:${p}:${q}:${Date.now()}`;
  let id = '';
  await economy.mutateAccount(sellerId, ({ user, economy: e }) => {
    const owned = Number(e.inventory?.[itemId] || 0);
    if (owned < q) throw new ValidationError('Sem item no inventário.');
    e.inventory[itemId] = owned - q;
    if (e.inventory[itemId] <= 0) delete e.inventory[itemId];
    return { amount: 0 };
  }, {
    reason: 'market.create', operationId, name: sellerName,
    extraSteps: [{ collection: 'market', update: M => {
      M.offers ??= [];
      id = `o${Date.now().toString(36)}-${crypto.randomUUID().slice(0,8)}`;
      M.offers.push({ id, sellerId, sellerName, itemId, price: p, qty: q, active: true, at: Date.now(), operationId });
      return M;
    }}]
  });
  return id;
}

export async function buyOffer(buyerId, offerId, buyerName = '') {
  const operationId = `market-buy:${buyerId}:${offerId}`;
  return economy.tradeMarketOffer(buyerId, offerId, buyerName, operationId);
}

export default { listOffers, createOffer, buyOffer };
