import crypto from 'node:crypto';
import { readCollection, writeCollection } from '../database/store.js';
import { recordAudit } from '../platform/audit/index.js';

const COLLECTION = 'commercial_platform';
const DAY = 86400000;
const MAX_DAYS = 3650;
const LIMITED_RENTAL_ROLES = new Set(['sub_owner', 'support']);
function normalizeActorRole(role) {
  const r = String(role || '').trim().toLowerCase();
  if (r === 'owner' || r === 'dono' || r === 'main_owner') return 'owner';
  if (r === 'co_owner' || r === 'co-owner' || r === 'codono') return 'co_owner';
  if (r === 'sub_owner' || r === 'subdono' || r === 'sub-owner') return 'sub_owner';
  if (r === 'support' || r === 'suporte') return 'support';
  return r;
}
function enforceRentalDuration(days, actorRole, { allowPermanent = false } = {}) {
  const role = normalizeActorRole(actorRole);
  if (LIMITED_RENTAL_ROLES.has(role)) {
    if (days === 'permanent' || (!Number.isInteger(Number(days)) || Number(days) < 1 || Number(days) > 30)) {
      throw Object.assign(new Error('Suporte/Subdono podem operar aluguel por no máximo 30 dias.'), { code: 'RENTAL_MAX_30_DAYS', maxDays: 30, actorRole: role });
    }
  }
  if (days === 'permanent' && !allowPermanent && LIMITED_RENTAL_ROLES.has(role)) {
    throw Object.assign(new Error('Aluguel permanente não é permitido para este cargo.'), { code: 'RENTAL_PERMANENT_DENIED', actorRole: role });
  }
  return days;
}
const DEFAULT_FEATURES = ['games', 'pets', 'tournaments', 'rankings'];

function now() { return Date.now(); }
function clone(v) { return v == null ? v : structuredClone(v); }
function emptyDb() { return { version: 1, globalMode: false, clients: {}, keys: {}, rentals: {}, plans: {}, operations: {} }; }
function db() {
  const d = readCollection(COLLECTION, emptyDb());
  return { ...emptyDb(), ...d, clients: d.clients || {}, keys: d.keys || {}, rentals: d.rentals || {}, plans: d.plans || {}, operations: d.operations || {} };
}
function save(d) { writeCollection(COLLECTION, d); return d; }
function id(prefix) { return `${prefix}-${crypto.randomUUID().replaceAll('-', '').slice(0, 16).toUpperCase()}`; }
function normalizeId(v) { return String(v || '').trim(); }
function groupId(v) { const x = normalizeId(v); return x.endsWith('@g.us') ? x : ''; }
function safeDays(days) { const n = Number(days); if (!Number.isInteger(n) || n < 1 || n > MAX_DAYS) throw new Error(`Duração deve estar entre 1 e ${MAX_DAYS} dias.`); return n; }
function stateOf(r, at = now()) {
  if (!r) return { state: 'INACTIVE', active: false, premium: false, expiresAt: null };
  if (r.state === 'REVOKED' || r.state === 'CANCELLED' || r.state === 'SUSPENDED' || r.state === 'EXPIRED') return { ...r, active: false, premium: false };
  if (r.permanent || r.expiresAt === 'permanent') return { ...r, state: 'ACTIVE', active: true, premium: r.plan !== 'BASIC' };
  const expires = Number(r.expiresAt);
  const expired = !Number.isFinite(expires) || expires <= at;
  return { ...r, state: expired ? 'EXPIRED' : (r.state || 'ACTIVE'), active: !expired && (r.state || 'ACTIVE') === 'ACTIVE', premium: !expired && r.plan !== 'BASIC' && (r.state || 'ACTIVE') === 'ACTIVE' };
}
function keyDigest(raw) { return crypto.createHash('sha256').update(String(raw)).digest('hex'); }
function generateKey() {
  const body = crypto.randomBytes(18).toString('base64url').replace(/[^A-Za-z0-9]/g, '').slice(0, 24).toUpperCase();
  return `FANT-${body.match(/.{1,4}/g).join('-')}`;
}
function publicKey(k) { return { keyId: k.keyId, prefix: k.prefix, type: k.type, status: k.status, clientId: k.clientId, groupId: k.groupId, durationDays: k.durationDays, createdAt: k.createdAt, usedAt: k.usedAt, revokedAt: k.revokedAt }; }

export function migrateLegacyRental(legacyRental = null, legacyCodes = null, actor = 'migration-stage11') {
  const d = db(); let changed = false;
  if (legacyRental?.groups && typeof legacyRental.groups === 'object') {
    for (const [gid, r] of Object.entries(legacyRental.groups)) {
      if (!groupId(gid) || d.rentals[gid]) continue;
      const permanent = r?.duration === 'permanent' || r?.expiresAt === 'permanent';
      const expiresAt = permanent ? 'permanent' : Date.parse(r?.expiresAt || '') || null;
      d.rentals[gid] = { rentalId: id('RNT'), groupId: gid, clientId: r?.clientId || null, plan: r?.plan || 'PREMIUM', state: 'ACTIVE', permanent, expiresAt, createdAt: Date.parse(r?.createdAt || '') || now(), updatedAt: now(), source: 'legacy-rental' };
      changed = true;
    }
    if (d.globalMode !== true && legacyRental.globalMode === true) { d.globalMode = true; changed = true; }
  }
  if (legacyCodes?.codes && typeof legacyCodes.codes === 'object') {
    for (const [raw, c] of Object.entries(legacyCodes.codes)) {
      if (!c || c.targetGroup || d.keys[`legacy:${raw}`]) continue;
      const keyId = id('KEY');
      d.keys[`legacy:${raw}`] = { keyId, hash: keyDigest(raw), prefix: String(raw).slice(0, 9), type: 'RENTAL', status: c.used ? 'USED' : 'ACTIVE', clientId: c.clientId || null, groupId: c.activatedGroup || null, durationDays: c.duration === 'permanent' ? 'permanent' : Number(c.duration) || 30, createdAt: Date.parse(c.createdAt || '') || now(), usedAt: Date.parse(c.usedAt || '') || null, source: 'legacy-code' };
      changed = true;
    }
  }
  if (changed) save(d);
  if (changed) void recordAudit({ actor, action: 'PLATFORM_LEGACY_MIGRATION', result: 'success', details: { rentals: Object.keys(d.rentals).length, keys: Object.keys(d.keys).length } });
  return { changed, rentals: Object.keys(d.rentals).length, keys: Object.keys(d.keys).length };
}

export function listPlans() { return Object.values(db().plans); }
export function upsertPlan({ planId = id('PLN'), name, days = 30, price = null, features = DEFAULT_FEATURES, active = true } = {}) {
  if (!name) throw new Error('Nome do plano obrigatório');
  const d = db(); d.plans[planId] = { planId, name: String(name).slice(0, 100), days: safeDays(days), price: price == null ? null : Number(price), features: [...new Set(features.map(String))].slice(0, 100), active: Boolean(active), updatedAt: now() }; save(d); return clone(d.plans[planId]);
}

export function ensureClient({ clientId = id('CLI'), name = '', externalId = null, actor = 'system' } = {}) {
  const key = String(clientId).trim(); if (!key) throw new Error('clientId obrigatório');
  const d = db(); const prev = d.clients[key];
  d.clients[key] = { clientId: key, name: String(name || prev?.name || '').slice(0, 160), externalId: externalId ?? prev?.externalId ?? null, createdAt: prev?.createdAt || now(), updatedAt: now(), status: prev?.status || 'ACTIVE' };
  save(d);
  if (!prev) void recordAudit({ actor, target: key, action: 'CLIENT_CREATED', scope: 'client', after: d.clients[key] });
  return clone(d.clients[key]);
}
export function listClients() { return Object.values(db().clients).map(clone); }
export function getClient(clientId) { const key = normalizeId(clientId); return key ? clone(db().clients[key] || null) : null; }
export function updateClient({ clientId, name, status, actor = 'system' } = {}) { const key = normalizeId(clientId); const d = db(); const current = d.clients[key]; if (!current) throw Object.assign(new Error('Cliente não encontrado.'), { statusCode: 404 }); const allowed = new Set(['ACTIVE','SUSPENDED','DISABLED']); const nextStatus = String(status ?? current.status).trim().toUpperCase(); if (!allowed.has(nextStatus)) throw Object.assign(new Error('Estado do cliente inválido.'), { statusCode: 400 }); const nextName = name === undefined ? current.name : String(name).trim().replace(/\s+/g, ' '); if (!nextName || nextName.length > 160) throw Object.assign(new Error('Nome do cliente inválido.'), { statusCode: 400 }); const before = clone(current); current.name = nextName; current.status = nextStatus; current.updatedAt = now(); save(d); void recordAudit({ actor, target:key, action:'CLIENT_UPDATED', scope:'client', before, after:current }); return clone(current); }
export function deleteClient(clientId, actor = 'system') { const key = normalizeId(clientId); const d = db(); const current = d.clients[key]; if (!current) throw Object.assign(new Error('Cliente não encontrado.'), { statusCode: 404 }); const hasKeys = Object.values(d.keys).some(k => k.clientId === key); const hasRentals = Object.values(d.rentals).some(r => r.clientId === key); if (hasKeys || hasRentals) throw Object.assign(new Error('Cliente possui chaves ou aluguéis vinculados; desative-o em vez de excluir.'), { statusCode: 409 }); delete d.clients[key]; save(d); void recordAudit({ actor, target:key, action:'CLIENT_DELETED', scope:'client', before:current }); return { deleted:true, id:key }; }

export function createKey({ clientId = null, groupId: targetGroup = null, durationDays = 30, type = 'RENTAL', actor = 'system', actorRole = null } = {}) {
  enforceRentalDuration(durationDays, actorRole);
  const days = durationDays === 'permanent' ? 'permanent' : safeDays(durationDays); const d = db();
  if (clientId && !d.clients[clientId]) throw Object.assign(new Error('Cliente não encontrado.'), { statusCode: 404 });
  if (clientId && String(d.clients[clientId].status || 'ACTIVE').toUpperCase() !== 'ACTIVE') throw Object.assign(new Error('Cliente não está ativo.'), { statusCode: 409 });
  const raw = generateKey(); const keyId = id('KEY'); const createdAt = now();
  const row = { keyId, hash: keyDigest(raw), prefix: raw.slice(0, 9), type, status: 'ACTIVE', clientId, groupId: groupId(targetGroup) || null, durationDays: days, createdAt, usedAt: null, revokedAt: null };
  d.keys[keyId] = row; save(d);
  void recordAudit({ actor, target: keyId, action: 'KEY_CREATED', scope: clientId ? `client:${clientId}` : 'platform', after: publicKey(row) });
  return { ...publicKey(row), secret: raw };
}
export function listKeys({ clientId = null } = {}) { return Object.values(db().keys).filter(k => !clientId || k.clientId === clientId).map(publicKey); }

export function createRental({ groupId: targetGroup, clientId = null, planId = null, actor = 'system', actorRole = null } = {}) {
  const gid = groupId(targetGroup); if (!gid) throw Object.assign(new Error('Grupo inválido.'), { statusCode: 400 });
  const d = db(); if (d.rentals[gid]) throw Object.assign(new Error('Grupo já possui aluguel cadastrado.'), { statusCode: 409 });
  let client = null;
  if (clientId) { client = d.clients[normalizeId(clientId)]; if (!client) throw Object.assign(new Error('Cliente não encontrado.'), { statusCode: 404 }); if (String(client.status || 'ACTIVE').toUpperCase() !== 'ACTIVE') throw Object.assign(new Error('Cliente não está ativo.'), { statusCode: 409 }); }
  let plan = null;
  if (planId) { plan = d.plans[normalizeId(planId)]; if (!plan || !plan.active) throw Object.assign(new Error('Plano inexistente ou inativo.'), { statusCode: 404 }); }
  if (plan && LIMITED_RENTAL_ROLES.has(normalizeActorRole(actorRole)) && safeDays(plan.days) > 30) {
    throw Object.assign(new Error('Suporte/Subdono podem criar aluguel por no máximo 30 dias.'), { code: 'RENTAL_MAX_30_DAYS', maxDays: 30, actorRole: normalizeActorRole(actorRole) });
  }
  const createdAt = now();
  const rental = { rentalId: id('RNT'), groupId: gid, clientId: client?.clientId || null, plan: plan?.planId || 'PREMIUM', state: 'ACTIVE', permanent: false, expiresAt: plan ? createdAt + safeDays(plan.days) * DAY : null, createdAt, updatedAt: createdAt, features: plan?.features || DEFAULT_FEATURES, source: 'control-center' };
  d.rentals[gid] = rental; save(d);
  void recordAudit({ actor, target: gid, action: 'RENTAL_CREATED', scope: `group:${gid}`, result: 'success', after: stateOf(rental), details: { clientId: rental.clientId, planId: rental.plan } });
  return stateOf(rental);
}

export function getRental(group) { const gid = groupId(group); if (!gid) return null; const rental = db().rentals[gid]; return rental ? stateOf(rental) : null; }
export function listRentals() { return Object.values(db().rentals).map(r => stateOf(r)); }
export function replaceRentalData(data, actor = 'legacy-compat') { const d=db(); const next={}; for(const [gid,r] of Object.entries(data?.groups||{})){ if(!groupId(gid)) continue; const prev=d.rentals[gid]; const permanent=r?.permanent===true || r?.expiresAt==='permanent' || r?.duration==='permanent'; const parsed=permanent?'permanent':(Number.isFinite(Number(r?.expiresAt))?Number(r.expiresAt):(Date.parse(r?.expiresAt||'')||null)); next[gid]={...(prev||{}),rentalId:prev?.rentalId||id('RNT'),groupId:gid,clientId:r?.clientId??prev?.clientId??null,plan:r?.plan||prev?.plan||'PREMIUM',state:r?.state||prev?.state||'ACTIVE',permanent,expiresAt:parsed,createdAt:prev?.createdAt||Date.parse(r?.createdAt||'')||now(),updatedAt:now()}; } const before=d.rentals; d.rentals=next; d.globalMode=data?.globalMode===true; save(d); void recordAudit({actor,action:'RENTAL_DATA_REPLACED',scope:'platform',before:{count:Object.keys(before).length},after:{count:Object.keys(next).length}}); return commercialSnapshot(); }

export function setGlobalMode(active, actor = 'system') { const d = db(); d.globalMode = Boolean(active); save(d); void recordAudit({ actor, action: 'RENTAL_GLOBAL_MODE_CHANGED', after: { active: d.globalMode } }); return d.globalMode; }
export function globalMode() { return db().globalMode === true; }

export function validateKey(rawKey) { const raw=String(rawKey||'').trim().toUpperCase(); if(raw.length<8||raw.length>64) return { valid:false, message:'Chave inválida.' }; const k=Object.values(db().keys).find(x=>x.hash===keyDigest(raw)); if(!k) return { valid:false, message:'Chave inválida ou não encontrada.' }; if(k.status!=='ACTIVE') return { valid:false, message:k.status==='USED'?'Chave já utilizada.':'Chave indisponível.' }; return { valid:true, ...publicKey(k) }; }

export function activateKey(rawKey, targetGroup, actor = null, operationId = null) {
  const gid = groupId(targetGroup); if (!gid) throw new Error('Grupo inválido.');
  const raw = String(rawKey || '').trim().toUpperCase(); if (raw.length < 8 || raw.length > 64) throw new Error('Chave inválida.');
  const d = db(); const key = Object.values(d.keys).find(k => k.hash === keyDigest(raw));
  if (!key) throw new Error('Chave inválida ou não encontrada.');
  if (operationId && d.operations[operationId]) return clone(d.operations[operationId].result);
  if (key.status !== 'ACTIVE') throw new Error(key.status === 'USED' ? 'Chave já utilizada.' : 'Chave indisponível.');
  if (key.groupId && key.groupId !== gid) throw new Error('Chave vinculada a outro grupo.');
  const previous = d.rentals[gid] ? clone(d.rentals[gid]) : null; const t = now();
  let expiresAt = key.durationDays === 'permanent' ? 'permanent' : t + Number(key.durationDays) * DAY;
  if (previous && !previous.permanent && previous.expiresAt > t && key.durationDays !== 'permanent') expiresAt = previous.expiresAt + Number(key.durationDays) * DAY;
  const rental = { ...(previous || {}), rentalId: previous?.rentalId || id('RNT'), groupId: gid, clientId: key.clientId, plan: 'PREMIUM', state: 'ACTIVE', permanent: key.durationDays === 'permanent' || previous?.permanent === true, expiresAt: key.durationDays === 'permanent' || previous?.permanent ? 'permanent' : expiresAt, createdAt: previous?.createdAt || t, updatedAt: t };
  key.status = 'USED'; key.groupId = gid; key.usedAt = t;
  d.rentals[gid] = rental; if (operationId) d.operations[operationId] = { type: 'ACTIVATE_KEY', at: t, result: clone({ success: true, rental: stateOf(rental) }) };
  save(d); void recordAudit({ actor, target: gid, action: 'RENTAL_ACTIVATED', scope: `group:${gid}`, operationId, before: previous, after: stateOf(rental), details: { keyId: key.keyId } });
  return { success: true, rental: stateOf(rental), key: publicKey(key) };
}

export function renewRental(targetGroup, days = 30, actor = 'system', operationId = null, actorRole = null) {
  enforceRentalDuration(days, actorRole);
  const gid = groupId(targetGroup); if (!gid) throw new Error('Grupo inválido.'); const d = db();
  if (operationId && d.operations[operationId]) return clone(d.operations[operationId].result);
  const rental = d.rentals[gid]; if (!rental) throw new Error('Grupo sem aluguel cadastrado.'); if (rental.permanent) throw new Error('Aluguel permanente.');
  const extra = safeDays(days); const base = Math.max(now(), Number(rental.expiresAt) || 0); const before = clone(rental); rental.expiresAt = base + extra * DAY; rental.state = 'ACTIVE'; rental.updatedAt = now();
  const result = { success: true, rental: stateOf(rental), addedDays: extra }; if (operationId) d.operations[operationId] = { type: 'RENEW_RENTAL', at: now(), result: clone(result) }; save(d);
  void recordAudit({ actor, target: gid, action: 'RENTAL_RENEWED', scope: `group:${gid}`, operationId, before, after: stateOf(rental), details: { days: extra } }); return result;
}
export function setRentalState(targetGroup, state, actor = 'system') { const gid = groupId(targetGroup); const d = db(); const r = d.rentals[gid]; if (!r) throw new Error('Aluguel não encontrado.'); const allowed = new Set(['ACTIVE','SUSPENDED','REVOKED','CANCELLED','EXPIRED']); if (!allowed.has(state)) throw new Error('Estado inválido.'); const current = stateOf(r).state; if ((current === 'REVOKED' || current === 'CANCELLED') && state !== current) throw new Error('Aluguel cancelado/revogado é terminal.'); if (current === 'EXPIRED' && state === 'ACTIVE') throw new Error('Aluguel expirado deve ser renovado antes de ser reativado.'); if (current === 'ACTIVE' && state === 'ACTIVE') return stateOf(r); const before = clone(r); r.state = state; r.updatedAt = now(); save(d); void recordAudit({ actor, target: gid, action: `RENTAL_${state}`, scope: `group:${gid}`, before, after: stateOf(r) }); return stateOf(r); }
export function canUse(group, feature = null) { const r = getRental(group); if (!r?.active) return false; return !feature || !r.features?.length || r.features.includes(feature); }
export function expireDueRentals(actor = 'system') { const d = db(); const changed = []; for (const r of Object.values(d.rentals)) { if (r.permanent || r.state !== 'ACTIVE') continue; if (Number(r.expiresAt) <= now()) { const before = clone(r); r.state = 'EXPIRED'; r.updatedAt = now(); changed.push(r.groupId); void recordAudit({ actor, target: r.groupId, action: 'RENTAL_EXPIRED', scope: `group:${r.groupId}`, before, after: stateOf(r) }); } } if (changed.length) save(d); return changed; }
export function evaluateCommercialLifecycle(actor = 'system') { return expireDueRentals(actor); }

export function commercialLifecycleIntegrity() {
  const d = db(); const issues = [];
  for (const r of Object.values(d.rentals)) {
    if (!r.groupId || !groupId(r.groupId)) issues.push({ type: 'RENTAL_INVALID_GROUP', rentalId: r.rentalId });
    if (r.clientId && !d.clients[r.clientId]) issues.push({ type: 'RENTAL_MISSING_CLIENT', rentalId: r.rentalId, clientId: r.clientId });
    if (r.plan && r.plan !== 'PREMIUM' && r.plan !== 'BASIC' && !d.plans[r.plan]) issues.push({ type: 'RENTAL_MISSING_PLAN', rentalId: r.rentalId, planId: r.plan });
    const l = stateOf(r); if (l.active && l.state !== 'ACTIVE') issues.push({ type: 'RENTAL_ACTIVE_STATE_MISMATCH', rentalId: r.rentalId });
  }
  return { ok: issues.length === 0, issues, checkedAt: now() };
}

export function commercialIntegrity() { return commercialLifecycleIntegrity(); }

export function commercialSnapshot() { const d = db(); const rentals = Object.values(d.rentals).map(r => stateOf(r)); return { clients: Object.keys(d.clients).length, keys: Object.keys(d.keys).length, keysActive: Object.values(d.keys).filter(k => k.status === 'ACTIVE').length, rentals: rentals.length, rentalsActive: rentals.filter(r => r.active).length, rentalsExpired: rentals.filter(r => r.state === 'EXPIRED').length, rentalsSuspended: rentals.filter(r => r.state === 'SUSPENDED').length, globalMode: d.globalMode === true, plans: Object.keys(d.plans).length }; }

export default { createRental, migrateLegacyRental, listPlans, upsertPlan, ensureClient, getClient, updateClient, deleteClient, listClients, createKey, listKeys, getRental, listRentals, setGlobalMode, replaceRentalData, globalMode, activateKey, validateKey, renewRental, setRentalState, canUse, expireDueRentals, commercialSnapshot, evaluateCommercialLifecycle, commercialLifecycleIntegrity, commercialIntegrity };
