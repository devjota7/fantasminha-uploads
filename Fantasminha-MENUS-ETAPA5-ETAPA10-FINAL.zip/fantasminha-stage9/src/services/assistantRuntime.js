/**
 * Fantasminha Assistant Runtime — camada única de ciclo de conversa.
 * Não executa comandos nem concede permissões. O router continua sendo a autoridade.
 */
import crypto from 'crypto';
import { guardInput, fingerprintEvent, incrementMetric } from './assistantV2Core.js';

const MAX_SESSIONS = 1000;
const SESSION_TTL_MS = 15 * 60 * 1000;
const DEDUP_TTL_MS = 5 * 60 * 1000;
const sessions = new Map();
const seenEvents = new Map();

function now() { return Date.now(); }
function prune(map, ttl, max) {
  const cutoff = now() - ttl;
  for (const [key, value] of map) {
    const stamp = Number(value?.lastSeen || value?.createdAt || value || 0);
    if (stamp < cutoff) map.delete(key);
  }
  while (map.size > max) map.delete(map.keys().next().value);
}

export function assistantScopeKey({ groupId = '', userId = '', personality = 'fantasminha' } = {}) {
  const g = String(groupId || 'private').trim() || 'private';
  const u = String(userId || 'unknown').trim() || 'unknown';
  const p = String(personality || 'fantasminha').trim().toLowerCase() || 'fantasminha';
  return `${g}:${u}:${p}`;
}

export function createAssistantContext(input = {}) {
  const text = String(input.text || '').replace(/\u0000/g, '').trim();
  const groupId = String(input.groupId || '').trim();
  const userId = String(input.userId || '').trim();
  const personality = String(input.personality || 'fantasminha').trim().toLowerCase();
  const messageId = String(input.messageId || crypto.randomUUID());
  const guard = guardInput(text);
  if (!guard.allowed) {
    incrementMetric('safety_blocks');
    return { allowed: false, reason: guard.reason, messageId };
  }
  const scope = assistantScopeKey({ groupId, userId, personality });
  return {
    allowed: true,
    scope,
    chatId: groupId || 'private',
    groupId: groupId || null,
    userId: userId || null,
    personality,
    messageId,
    text,
    fingerprint: fingerprintEvent({ chatId: groupId, senderId: userId, messageId, text }),
    createdAt: now()
  };
}

export function markEventSeen(context) {
  if (!context?.fingerprint) return { duplicate: false };
  prune(seenEvents, DEDUP_TTL_MS, 5000);
  if (seenEvents.has(context.fingerprint)) {
    incrementMetric('duplicate_count');
    return { duplicate: true };
  }
  seenEvents.set(context.fingerprint, now());
  return { duplicate: false };
}

export function touchSession(context, { activated = false } = {}) {
  if (!context?.scope) return null;
  prune(sessions, SESSION_TTL_MS, MAX_SESSIONS);
  let session = sessions.get(context.scope);
  if (!session) {
    session = { scope: context.scope, createdAt: now(), lastSeen: now(), turns: 0, active: false };
  }
  session.lastSeen = now();
  session.turns += 1;
  if (activated) session.active = true;
  sessions.set(context.scope, session);
  return { ...session };
}

export function getSession(contextOrScope) {
  const scope = typeof contextOrScope === 'string' ? contextOrScope : contextOrScope?.scope;
  if (!scope) return null;
  prune(sessions, SESSION_TTL_MS, MAX_SESSIONS);
  const session = sessions.get(scope);
  return session ? { ...session } : null;
}

export function closeSession(contextOrScope) {
  const scope = typeof contextOrScope === 'string' ? contextOrScope : contextOrScope?.scope;
  if (scope) sessions.delete(scope);
}

export function getRuntimeStats() {
  prune(sessions, SESSION_TTL_MS, MAX_SESSIONS);
  prune(seenEvents, DEDUP_TTL_MS, 5000);
  return { sessions: sessions.size, seenEvents: seenEvents.size };
}

export function resetAssistantRuntime() {
  sessions.clear();
  seenEvents.clear();
}
