/**
 * Cargos internos do Fantasminha, independentes dos cargos reais do WhatsApp.
 * Escopo: por grupo. O cargo do bot nunca promove/demove ninguém no WhatsApp.
 */
import { readCollection, updateCollection } from '../database/store.js';

export const BOT_ROLE = Object.freeze({
  ARANHA: 'aranha'
});

export const BOT_ROLE_META = Object.freeze({
  [BOT_ROLE.ARANHA]: Object.freeze({
    id: BOT_ROLE.ARANHA,
    name: 'Aranha',
    label: '🕷️ Aranha',
    permission: 0
  })
});

const DEFAULT = Object.freeze({ version: 1, byGroup: {} });
let cache = null;
const norm = value => String(value ?? '').trim().toLowerCase();
const baseId = value => norm(value).split('@')[0].split(':')[0];

export function normalizeBotRoleUserId(value) {
  return norm(value);
}

export function sameBotRoleUser(a, b) {
  return norm(a) === norm(b) || baseId(a) === baseId(b);
}

export function getBotRole(groupId, userId) {
  const gid = norm(groupId);
  const uid = norm(userId);
  if (!gid || !uid) return null;
  const db = cache || (cache = readCollection('bot_roles', DEFAULT));
  const users = db.byGroup?.[gid]?.users || {};
  const direct = users[uid];
  const fallbackKey = direct ? uid : Object.keys(users).find(key => baseId(key) === baseId(uid));
  const roleId = direct || (fallbackKey ? users[fallbackKey] : null);
  return roleId && BOT_ROLE_META[roleId] ? BOT_ROLE_META[roleId] : null;
}

export function hasBotRole(groupId, userId, roleId) {
  return getBotRole(groupId, userId)?.id === roleId;
}

export async function grantBotRole(groupId, userId, roleId = BOT_ROLE.ARANHA, actor = null) {
  const gid = norm(groupId);
  const uid = norm(userId);
  const meta = BOT_ROLE_META[roleId];
  if (!gid || !uid) throw new Error('Grupo e usuário são obrigatórios.');
  if (!meta) throw new Error(`Cargo interno inválido: ${roleId}`);

  let result;
  const next = await updateCollection('bot_roles', db => {
    db.version ||= 1;
    db.byGroup ||= {};
    db.byGroup[gid] ||= { users: {}, updatedAt: 0 };
    db.byGroup[gid].users ||= {};
    const previous = db.byGroup[gid].users[uid] || null;
    db.byGroup[gid].users[uid] = meta.id;
    db.byGroup[gid].updatedAt = Date.now();
    result = { changed: previous !== meta.id, previous, role: meta, groupId: gid, userId: uid, actor: actor ? norm(actor) : null };
    return db;
  }, DEFAULT);
  cache = next;
  return result;
}

export async function revokeBotRole(groupId, userId, roleId = BOT_ROLE.ARANHA) {
  const gid = norm(groupId);
  const uid = norm(userId);
  if (!gid || !uid) throw new Error('Grupo e usuário são obrigatórios.');

  let result;
  const next = await updateCollection('bot_roles', db => {
    db.version ||= 1;
    db.byGroup ||= {};
    const group = db.byGroup[gid];
    const users = group?.users || {};
    const key = users[uid] ? uid : Object.keys(users).find(k => baseId(k) === baseId(uid));
    const current = key ? users[key] : null;
    const changed = current === roleId;
    if (changed) {
      delete group.users[key];
      group.updatedAt = Date.now();
    }
    result = { changed, previous: current, groupId: gid, userId: uid };
    return db;
  }, DEFAULT);
  cache = next;
  return result;
}

export function listBotRoles(groupId) {
  const gid = norm(groupId);
  if (!gid) return [];
  const db = cache || (cache = readCollection('bot_roles', DEFAULT));
  const users = db.byGroup?.[gid]?.users || {};
  return Object.entries(users)
    .map(([userId, roleId]) => ({ userId, role: BOT_ROLE_META[roleId] || null }))
    .filter(item => item.role)
    .sort((a, b) => a.userId.localeCompare(b.userId));
}

export function getBotRolePermission(groupId, userId) {
  return getBotRole(groupId, userId)?.permission || 0;
}

export function botRoleName(groupId, userId) {
  return getBotRole(groupId, userId)?.label || null;
}

export default {
  BOT_ROLE,
  BOT_ROLE_META,
  getBotRole,
  hasBotRole,
  grantBotRole,
  revokeBotRole,
  listBotRoles,
  getBotRolePermission,
  botRoleName
};
