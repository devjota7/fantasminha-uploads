import pets from './petEngine.js';
import { getUser, upsertUser } from '../database/store.js';
import * as economy from './economy.js';
import { ValidationError } from '../core/errors.js';

export const ACTIONS = Object.freeze({
  alimentar: 'feed', comer: 'feed', feed: 'feed',
  brincar: 'play', play: 'play',
  carinho: 'care', care: 'care',
  banho: 'bath', bath: 'bath',
  passear: 'walk', walk: 'walk',
  treinar: 'train', train: 'train',
  descansar: 'rest', rest: 'rest',
  dormir: 'sleep', sleep: 'sleep',
  aventura: 'adventure', adventure: 'adventure'
});

export function scope(ctx) {
  return ctx?.isGroup ? String(ctx.from || 'global') : 'global';
}

export function user(ctx) { return String(ctx?.sender || ctx?.userId || 'unknown'); }

export async function list(ctx) {
  return pets.listAsync(scope(ctx), user(ctx));
}

export function listByScope(groupId) { return pets.listGroup(groupId); }

export function catalog() { return pets.catalog(); }
export function speciesList() { return pets.speciesList(); }

export async function adopt(ctx, name, speciesId = null) {
  return pets.adopt(scope(ctx), user(ctx), name, speciesId);
}

export async function acquire(ctx, speciesId, name = '', operationId = null) {
  return pets.acquire(scope(ctx), user(ctx), speciesId, name, operationId);
}

export async function action(ctx, actionName, indexOrId = null) {
  const actionId = ACTIONS[String(actionName || '').toLowerCase()] || String(actionName || '').toLowerCase();
  const listNow = await list(ctx);
  if (!listNow.length) throw new Error('Você não possui pets.');
  let pet = indexOrId == null || indexOrId === '' ? listNow[0] : null;
  if (pet == null) {
    const raw = String(indexOrId);
    pet = /^\d+$/.test(raw) ? listNow[Number(raw) - 1] : listNow.find(p => p.id === raw);
  }
  if (!pet) throw new Error('Pet não encontrado.');
  return pets.act(scope(ctx), user(ctx), pet.id, actionId);
}

export async function rename(ctx, index, name) {
  const listNow = await list(ctx);
  const n = Number(index);
  const pet = Number.isInteger(n) && n > 0 ? listNow[n - 1] : listNow.find(p => p.id === String(index));
  if (!pet) throw new Error('Pet não encontrado.');
  return pets.rename(scope(ctx), user(ctx), pet.id, name);
}

export async function release(ctx, index = 1) {
  const listNow = await list(ctx);
  const n = Number(index);
  const pet = Number.isInteger(n) && n > 0 ? listNow[n - 1] : listNow.find(p => p.id === String(index));
  if (!pet) throw new Error('Pet não encontrado.');
  return pets.release(scope(ctx), user(ctx), pet.id);
}

export async function duel(ctx, targetUserId) {
  const gid = scope(ctx);
  if (gid === 'global') throw new Error('Duelo de pets funciona em grupos.');
  const mine = pets.list(gid, user(ctx))[0];
  const other = pets.list(gid, targetUserId)[0];
  if (!mine || !other) throw new Error('Os dois participantes precisam possuir um pet.');
  const power = p => p.level * 10 + p.training + Math.floor(Math.random() * 50);
  const minePower = power(mine), otherPower = power(other);
  const won = minePower >= otherPower;
  return { mine, other, minePower, otherPower, won };
}

export async function ranking(ctx, limit = 10) {
  const gid = scope(ctx);
  const all = gid === 'global' ? [] : pets.listGroup(gid);
  all.sort((a, b) => b.pet.level - a.pet.level || b.pet.training - a.pet.training || b.pet.wins - a.pet.wins);
  return all.slice(0, limit);
}


const EVOLUTIONS = {
  lobo:[['Lobo Alpha','🐺⭐',10,15,8,50,10],['Lobo Lunar','🌙🐺',25,30,18,120,25],['Fenrir Despertado','🐺💫',50,60,40,250,50]],
  dragao:[['Dragão de Fogo','🐲🔥',15,25,15,80,5],['Dragão Ancião','🐉⚡',30,50,35,180,15],['Dragão Despertado','🐉💥',60,100,70,400,30]],
  fenix:[['Fênix Flamejante','🔥⭐',12,20,10,60,15],['Fênix Imortal','🔥💫',28,40,25,150,35],['Fênix Celestial','🔥👑',55,80,50,320,70]],
  tigre:[['Tigre Real','🐯👑',10,18,10,55,12],['Tigre de Jade','🐯💚',25,35,22,130,28],['Tigre Divino','🐯⚡',50,70,45,280,55]],
  aguia:[['Águia Majestosa','🦅⭐',10,22,7,45,20],['Águia Dourada','🦅👑',25,45,15,110,45],['Grifo Lendário','🦅💫',50,90,35,240,90]]
};

export async function evolve(ctx, indexOrId) {
  const listNow = await list(ctx); const raw=String(indexOrId||'1');
  const pet=/^\d+$/.test(raw)?listNow[Number(raw)-1]:listNow.find(p=>p.id===raw);
  if(!pet) throw new ValidationError('Pet não encontrado.');
  const stages=EVOLUTIONS[pet.speciesId]; if(!stages || pet.evolutions>=stages.length) throw new ValidationError(`${pet.emoji} ${pet.name} já atingiu sua forma máxima.`);
  const next=stages[pet.evolutions];
  if(pet.level<next[2]) throw new ValidationError(`${pet.emoji} ${pet.name} precisa estar no nível ${next[2]}.`);
  const uid=user(ctx); const u=getUser(uid)||{}; const inv=u.economy?.inventory||{};
  const has=Number(inv.evolution_stone||0)>0 || Number(u.items?.evolution_stone||0)>0;
  if(!has) throw new ValidationError('Você precisa de uma Pedra da Evolução.');
  let consumed='inventory';
  await economy.mutateAccount(uid, ({user})=>{
    user.economy ||= {}; user.economy.inventory ||= {};
    if(Number(user.economy.inventory.evolution_stone||0)>0) user.economy.inventory.evolution_stone--; else { user.items ||= {}; if(Number(user.items.evolution_stone||0)<=0) throw new ValidationError('Você precisa de uma Pedra da Evolução.'); user.items.evolution_stone--; consumed='items'; }
    return {amount:0};
  }, {reason:'pet.evolve', operationId:`pet:evolve:${scope(ctx)}:${uid}:${pet.id}:${pet.evolutions}`,
      extraSteps:[{collection:pets.PET_STORAGE_COLLECTION, update:d=>{const k=`${scope(ctx)}::${uid}`, cur=d.pets?.[k]?.[pet.id]; if(!cur) throw new ValidationError('Pet não encontrado.'); cur.name=next[0];cur.emoji=next[1];cur.attack=(cur.attack||0)+next[3];cur.defense=(cur.defense||0)+next[4];cur.maxHp=(cur.maxHp||100)+next[5];cur.health=cur.maxHp;cur.speed=(cur.speed||0)+next[6];cur.evolutions=(cur.evolutions||0)+1;d.pets[k][pet.id]=pets.normalizePet(cur);return d;}}]});
  return pets.list(scope(ctx),uid).find(p=>p.id===pet.id);
}

export async function equip(ctx,index,itemId) {
  const uid=user(ctx), gid=scope(ctx), listNow=await list(ctx); const pet=Number(index)>0?listNow[Number(index)-1]:listNow.find(p=>p.id===String(index));
  if(!pet) throw new ValidationError('Pet não encontrado.'); if(!itemId) throw new ValidationError('Informe o item.');
  const iid=String(itemId).toLowerCase(); let foundItemId=null; const op=`pet:equip:${gid}:${uid}:${pet.id}:${iid}:${Date.now()}`; let slot='weapon';
  if(/armor|armadura/.test(iid)) slot='armor'; else if(/shield|escudo/.test(iid)) slot='shield'; else if(/ring|anel|collar|colar/.test(iid)) slot='accessory'; else if(/potion|poção/.test(iid)) slot='potion';
  await economy.mutateAccount(uid, ({user})=>{const inv=user.economy?.inventory||{}; const found=Object.keys(inv).find(k=>k.toLowerCase().includes(iid)&&Number(inv[k])>0); if(!found) throw new ValidationError('Você não possui esse item no inventário.'); foundItemId=found; user.economy.inventory=inv; if(pet.equipment?.[slot]) inv[pet.equipment[slot]]=(inv[pet.equipment[slot]]||0)+1; inv[found]--; if(inv[found]<=0) delete inv[found]; return {found};},{reason:'pet.equip',operationId:op,extraSteps:[{collection:pets.PET_STORAGE_COLLECTION,update:d=>{const k=`${gid}::${uid}`,cur=d.pets?.[k]?.[pet.id];if(!cur)throw new ValidationError('Pet não encontrado.');cur.equipment=cur.equipment||{};cur.equipment[slot]=foundItemId||iid;d.pets[k][pet.id]=pets.normalizePet(cur);return d;}}]});
  return pets.list(gid,uid).find(p=>p.id===pet.id);
}

export async function unequip(ctx,index,slot='accessory') {
  const uid=user(ctx),gid=scope(ctx),listNow=await list(ctx),pet=Number(index)>0?listNow[Number(index)-1]:listNow.find(p=>p.id===String(index));
  if(!pet) throw new ValidationError('Pet não encontrado.'); const item=pet.equipment?.[slot]; if(!item) throw new ValidationError('Esse pet não possui equipamento nesse slot.');
  await economy.mutateAccount(uid,({user})=>{user.economy ||= {};user.economy.inventory ||= {};user.economy.inventory[item]=(user.economy.inventory[item]||0)+1;return {amount:0};},{reason:'pet.unequip',operationId:`pet:unequip:${gid}:${uid}:${pet.id}:${slot}:${Date.now()}`,extraSteps:[{collection:pets.PET_STORAGE_COLLECTION,update:d=>{const k=`${gid}::${uid}`,cur=d.pets?.[k]?.[pet.id];if(!cur)throw new ValidationError('Pet não encontrado.');cur.equipment=cur.equipment||{};delete cur.equipment[slot];d.pets[k][pet.id]=pets.normalizePet(cur);return d;}}]});
  return pets.list(gid,uid).find(p=>p.id===pet.id);
}

export async function battle(ctx,targetUserId,bet=0,index=1) {
  const gid=scope(ctx); if(gid==='global') throw new ValidationError('Batalha de pets funciona em grupos.');
  const uid=user(ctx), mine=(await list(ctx))[Number(index)-1]; const other=pets.list(gid,targetUserId)[0]; if(!mine||!other) throw new ValidationError('Os dois participantes precisam possuir pets.');
  const amount=Math.max(0,Number(bet)||0); const myPower=(mine.attack||0)+(mine.defense||0)+(mine.speed||0)+(mine.level||1)*10+Math.floor(Math.random()*20); const opPower=(other.attack||0)+(other.defense||0)+(other.speed||0)+(other.level||1)*10+Math.floor(Math.random()*20); const won=myPower>=opPower;
  if(amount){ if(amount>Number((getUser(uid)?.economy?.wallet)||0)) throw new ValidationError('Você não tem saldo suficiente.'); if(amount>Number((getUser(targetUserId)?.economy?.wallet)||0)) throw new ValidationError('Seu oponente não tem saldo suficiente.'); if(won){ await economy.debit(targetUserId,amount,'pet.battle.loss'); await economy.credit(uid,amount,'pet.battle.reward'); } else { await economy.debit(uid,amount,'pet.battle.loss'); await economy.credit(targetUserId,amount,'pet.battle.reward'); } }
  await pets.updatePet(gid,uid,mine.id,p=>{p.wins=(p.wins||0)+(won?1:0);p.losses=(p.losses||0)+(won?0:1);return p;});
  await pets.updatePet(gid,targetUserId,other.id,p=>{p.wins=(p.wins||0)+(won?0:1);p.losses=(p.losses||0)+(won?1:0);return p;});
  return {mine,other,myPower,opPower,won,amount};
}

export default { scope, user, list, listByScope, catalog, speciesList, adopt, acquire, action, rename, release, duel, ranking, evolve, equip, unequip, battle, ACTIONS };
