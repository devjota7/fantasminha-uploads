/**
 * Normaliza respostas Markdown de provedores de IA para o formato compacto
 * esperado pelas mensagens do WhatsApp.
 *
 * Regra preservada do handler legado; esta extração não altera o contrato.
 */
export function formatAIResponse(text) {
  if (!text || typeof text !== 'string') return text;
  return text
    .replace(/\*\*\*([^*]+)\*\*\*/g, '*$1*')
    .replace(/\*\*([^*]+)\*\*/g, '*$1*')
    .replace(/_{2,}([^_]+)_{2,}/g, '_$1_')
    .replace(/```[\s\S]*?```/g, '')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

export default formatAIResponse;
