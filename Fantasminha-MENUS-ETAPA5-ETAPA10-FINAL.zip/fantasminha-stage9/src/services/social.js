import { getUser, upsertUser, readCollection, updateCollection } from '../database/store.js';
import { resolveMentionTargets, resolveUserIdentity } from '../platform/identity/resolver.js';

const userError = (msg) => Object.assign(new Error(msg), { userMessage: msg });
const pendingBestFriendRequests = new Map();
const REQUEST_TIMEOUT_MS = 2 * 60 * 1000; // 2 minutos

function cleanPendingRequests() {
  const now = Date.now();
  for (const [key, req] of pendingBestFriendRequests.entries()) {
    if (req.expiresAt <= now) pendingBestFriendRequests.delete(key);
  }
}

export function listBestFriends(userId, aliases = []) {
  const users = readCollection('users', { byId: {} });
  const rawCandidates = [...new Set([userId, ...aliases].flat(Infinity).filter(Boolean).map(x => String(x).trim().toLowerCase()))];
  const candidates = new Set(rawCandidates);
  for (const c of rawCandidates) {
    const base = c.split('@')[0].split(':')[0].replace(/\D/g, '');
    if (base) {
      candidates.add(base);
      candidates.add(`${base}@s.whatsapp.net`);
      candidates.add(`${base}:0@s.whatsapp.net`);
      candidates.add(`${base}@lid`);
    }
  }

  for (const key of candidates) {
    const current = users.byId?.[key];
    if (current) {
      const list = Array.isArray(current.bestFriends) ? current.bestFriends : (current.bestFriend ? [current.bestFriend] : []);
      const cleanList = list.filter(Boolean).map(j => {
        const phone = String(j).split('@')[0].split(':')[0].replace(/\D/g, '');
        return phone ? `${phone}@s.whatsapp.net` : j;
      });
      if (cleanList.length) {
        return [...new Set(cleanList)].slice(0, 3);
      }
    }
  }
  return [];
}

export async function requestBestFriend(ctx, target = null) {
  cleanPendingRequests();
  const [person] = await resolveMentionTargets(ctx, target ? [target] : null);
  if (!person?.realJid && !person?.lid) {
    throw userError('Não consegui resolver o contato desse usuário. Mencione a pessoa ou responda à mensagem dela.');
  }

  const me = await resolveUserIdentity(ctx, ctx.sender);
  const meJid = me.realJid || ctx.sender;
  const targetJid = person.realJid || person.lid;

  const meBase = (me.number || meJid.split('@')[0].split(':')[0]).replace(/\D/g, '');
  const targetBase = (person.number || targetJid.split('@')[0].split(':')[0]).replace(/\D/g, '');

  if ((meBase && targetBase && meBase === targetBase) || (person.realJid && me.realJid && person.realJid === me.realJid)) {
    throw userError('Você não pode adicionar a si mesmo como Best Friend.');
  }

  const myFriends = listBestFriends(meJid, [ctx.sender, me.lid]);
  const isAlready = myFriends.some(f => {
    const fBase = String(f).split('@')[0].split(':')[0].replace(/\D/g, '');
    return (targetBase && fBase === targetBase) || f === person.realJid;
  });
  if (isAlready) {
    return { status: 'already', person, me };
  }

  if (myFriends.length >= 3) {
    throw userError('Você já atingiu o limite de 3 Best Friends. Remova um com ×rmvbestfriend antes de adicionar outro.');
  }

  const groupId = ctx.from || 'private';
  for (const req of pendingBestFriendRequests.values()) {
    if (req.groupId === groupId && req.fromBase === meBase && req.toBase === targetBase && req.expiresAt > Date.now()) {
      return { status: 'pending', person, me, remainingSec: Math.ceil((req.expiresAt - Date.now()) / 1000) };
    }
  }

  const reqId = `${groupId}:${meBase}:${targetBase}:${Date.now()}`;
  const fromClean = meBase ? `${meBase}@s.whatsapp.net` : (me.realJid || ctx.sender);
  const toClean = targetBase ? `${targetBase}@s.whatsapp.net` : (person.realJid || person.lid);

  const request = {
    id: reqId,
    groupId,
    fromBase: meBase,
    toBase: targetBase,
    fromSender: ctx.sender,
    fromRealJid: fromClean,
    fromLid: me.lid || null,
    fromName: me.name || ctx.pushname || 'Alguém',
    toSender: target,
    toRealJid: toClean,
    toLid: person.lid || null,
    toName: person.name || 'Alguém',
    targetCandidates: [person.realJid, person.lid, targetBase, target].filter(Boolean),
    createdAt: Date.now(),
    expiresAt: Date.now() + REQUEST_TIMEOUT_MS
  };

  pendingBestFriendRequests.set(reqId, request);
  return { status: 'requested', request, person, me };
}

export async function findPendingBestFriendRequest(ctx) {
  cleanPendingRequests();
  const groupId = ctx.from || 'private';
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const myBase = (me.number || ctx.sender.split('@')[0].split(':')[0]).replace(/\D/g, '');
  const myCandidates = [ctx.sender, ctx.senderOriginal, ctx.senderAlternate, me.realJid, me.lid, myBase].filter(Boolean).map(x => String(x).toLowerCase());

  for (const [key, req] of pendingBestFriendRequests.entries()) {
    if (req.groupId !== groupId) continue;
    if (req.expiresAt <= Date.now()) {
      pendingBestFriendRequests.delete(key);
      continue;
    }
    const isTarget = myCandidates.some(c => {
      const cBase = c.split('@')[0].split(':')[0].replace(/\D/g, '');
      return (myBase && req.toBase === myBase) ||
             (cBase && req.toBase === cBase) ||
             req.targetCandidates.some(tc => String(tc).toLowerCase() === c);
    });

    if (isTarget) return { reqId: key, request: req };
  }
  return null;
}

export async function acceptBestFriendRequest(ctx) {
  const hit = await findPendingBestFriendRequest(ctx);
  if (!hit) return null;
  const { reqId, request } = hit;
  pendingBestFriendRequests.delete(reqId);

  const fromJid = request.fromRealJid;
  const toJid = request.toRealJid;

  const myKeysA = [request.fromSender, request.fromLid, request.fromRealJid, `${request.fromBase}@s.whatsapp.net`].filter(Boolean);
  const myFriendsA = listBestFriends(fromJid, myKeysA);
  const nextA = [...new Set([...myFriendsA, toJid])].slice(0, 3);
  for (const k of myKeysA) {
    await upsertUser(k, { bestFriends: nextA, bestFriend: nextA[0] || null, bestFriendUpdatedAt: Date.now() });
  }

  const me = await resolveUserIdentity(ctx, ctx.sender);
  const myKeysB = [ctx.sender, ctx.senderOriginal, ctx.senderAlternate, me.realJid, me.lid, `${request.toBase}@s.whatsapp.net`].filter(Boolean);
  const myFriendsB = listBestFriends(toJid, myKeysB);
  const nextB = [...new Set([...myFriendsB, fromJid])].slice(0, 3);
  for (const k of myKeysB) {
    await upsertUser(k, { bestFriends: nextB, bestFriend: nextB[0] || null, bestFriendUpdatedAt: Date.now() });
  }

  return { request, fromJid, toJid };
}

export async function rejectBestFriendRequest(ctx) {
  const hit = await findPendingBestFriendRequest(ctx);
  if (!hit) return null;
  const { reqId, request } = hit;
  pendingBestFriendRequests.delete(reqId);
  return { request };
}

export async function removeBestFriend(ctx, target = null) {
  const [person] = await resolveMentionTargets(ctx, target ? [target] : null);
  if (!person?.realJid && !person?.lid) throw userError('Não consegui resolver o contato desse usuário.');
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const targetBase = (person.number || (person.realJid || person.lid).split('@')[0].split(':')[0]).replace(/\D/g, '');
  const targetCleanJid = targetBase ? `${targetBase}@s.whatsapp.net` : person.realJid;

  const myKeys = [ctx.sender, ctx.senderOriginal, me.realJid, me.lid].filter(Boolean);
  const list = listBestFriends(me.realJid || ctx.sender, myKeys);
  const has = list.some(f => {
    const fBase = String(f).split('@')[0].split(':')[0].replace(/\D/g, '');
    return (targetBase && fBase === targetBase) || f === person.realJid;
  });

  if (!has) return { changed: false, person, list };

  const next = list.filter(f => {
    const fBase = String(f).split('@')[0].split(':')[0].replace(/\D/g, '');
    return !(targetBase && fBase === targetBase) && f !== person.realJid;
  });

  for (const k of myKeys) {
    await upsertUser(k, { bestFriends: next, bestFriend: next[0] || null, bestFriendUpdatedAt: Date.now() });
  }
  const targetKeys = [person.realJid, person.lid, targetCleanJid, `${targetBase}@lid`].filter(Boolean);
  const targetFriends = listBestFriends(targetCleanJid, targetKeys);
  const reciprocal = targetFriends.filter(f => {
    const base = String(f).split('@')[0].split(':')[0].replace(/\D/g, '');
    const mine = (me.number || (me.realJid || ctx.sender).split('@')[0].split(':')[0]).replace(/\D/g, '');
    return !(base && mine && base === mine);
  });
  for (const k of targetKeys) {
    await upsertUser(k, { bestFriends: reciprocal, bestFriend: reciprocal[0] || null, bestFriendUpdatedAt: Date.now() });
  }
  return { changed: true, person, list: next, removedJid: targetCleanJid };
}

export function afkKey(jid) { return String(jid || '').trim().toLowerCase(); }

function afkGroupKey(groupId, userKey) {
  return `${afkKey(groupId)}::${afkKey(userKey)}`;
}

function afkGroupId(ctx) {
  const groupId = String(ctx?.from || '').trim();
  if (!groupId || !groupId.endsWith('@g.us')) return null;
  return groupId;
}

function afkCommandOnly(body, prefix) {
  const text = String(body || '').trim().toLowerCase();
  const p = String(prefix || '×').trim().toLowerCase();
  return text === `${p}afk` || text.startsWith(`${p}afk `);
}

function afkRecordFor(groupId, me, ctx, reason) {
  const userKey = afkKey(me.realJid || me.lid || ctx.sender);
  return {
    userId: userKey,
    groupId,
    lid: me.lid || null,
    name: ctx.pushname || me.pushName || 'Alguém',
    reason: String(reason || '').trim().slice(0, 180) || 'Não especificado',
    since: Date.now()
  };
}

export async function setAfk(ctx, reason = '') {
  const groupId = afkGroupId(ctx);
  if (!groupId) throw userError('AFK só pode ser usado em grupos.');
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const userKey = afkKey(me.realJid || me.lid || ctx.sender);
  const key = afkGroupKey(groupId, userKey);
  const rec = afkRecordFor(groupId, me, ctx, reason);
  let previous = null;
  await updateCollection('afk', d => {
    d.byGroupUser ??= {};
    previous = d.byGroupUser[key] || null;
    d.byGroupUser[key] = rec;
    return d;
  }, { byGroupUser: {} });
  return { ...rec, updated: !!previous, previous };
}

export async function clearAfk(ctx) {
  const groupId = afkGroupId(ctx);
  if (!groupId || !ctx?.sender) return null;
  const me = await resolveUserIdentity(ctx, ctx.sender);
  const aliases = [me.realJid, me.lid, ctx.sender, ctx.senderOriginal, ctx.senderAlternate]
    .filter(Boolean).map(afkKey);
  const current = readCollection('afk', { byGroupUser: {} });
  let removed = null;
  const keys = aliases.map(k => afkGroupKey(groupId, k));
  for (const k of keys) {
    if (current.byGroupUser?.[k]) { removed = current.byGroupUser[k]; break; }
  }
  if (!removed) return null;
  await updateCollection('afk', d => {
    d.byGroupUser ??= {};
    for (const k of keys) delete d.byGroupUser[k];
    return d;
  }, { byGroupUser: {} });
  return removed;
}

export async function clearAfkFromMessage(ctx) {
  if (!ctx?.sender || !ctx?.isGroup || ctx?.fromMe) return null;
  const body = String(ctx.body || ctx.text || '').trim();
  if (afkCommandOnly(body, ctx.prefix || '×')) return null;
  return clearAfk(ctx);
}

export async function findAfk(ctx, target) {
  const groupId = afkGroupId(ctx);
  if (!groupId || !target) return null;
  const person = await resolveUserIdentity(ctx, target);
  const d = readCollection('afk', { byGroupUser: {} });
  const aliases = [person.realJid, person.lid, target].filter(Boolean).map(afkKey);
  for (const alias of aliases) {
    const record = d.byGroupUser?.[afkGroupKey(groupId, alias)];
    if (record) return { record, person };
  }
  return null;
}

const POOLS = Object.freeze({
  aparencia:['CEO de alguma coisa que ninguém sabe explicar','lenda urbana com Wi‑Fi','protagonista de um anime que só existe no grupo','espírito de segunda-feira'],
  hobby:['treinar 3 dias e contar por 30','abrir o WhatsApp e esquecer por que abriu','sumir quando chega a cobrança','colecionar histórias que começam com “não foi minha culpa”'],
  profissao:['Influencer do próprio grupo','consultor de decisões questionáveis','gerente do caos','especialista em responder “já vou”'],
  horario:['quando ninguém está cobrando resposta','03:17, horário oficial das ideias duvidosas','na hora exata em que o grupo dorme','quando aparece uma fofoca'],
  musica:['aquela que toca na cabeça quando faz besteira','trilha sonora de fuga em câmera lenta','um remix que ninguém pediu','o silêncio antes da próxima confusão'],
  clima:['32°C e reclamando que está calor','chuva com vontade de dormir','frio suficiente para justificar o sumiço','qualquer clima que permita ficar no celular'],
  signo:['Capricórnio do Além','Gêmeos em modo espectral','Escorpião da Cripta','Libra do Limbo'],
  animal:['um pombo com confiança demais','um gato julgando todo mundo','uma capivara com acesso de administrador','um corvo com fofoca'],
  qualidade:['faz o grupo rir sem perceber','aparece exatamente quando precisa','tem criatividade para situações improváveis','transforma qualquer conversa em história'],
  defeito:['responde na cabeça e esquece de enviar','some por tempo espiritualmente indefinido','promete “rapidinho” e desaparece','tem talento para escolher a pior hora'],
  energia:['92% caos controlado','68% protagonista','100% entidade online','47% mistério, 53% improviso'],
  profissaoAlem:['guardião da porta errada','contador de almas atrasadas','fiscal de fantasmas','moderador do Limbo'],
  poder:['teletransportar só até a cozinha','saber quem visualizou e não respondeu','invocar uma desculpa em 0,2 segundos','encontrar Wi‑Fi onde ninguém encontra'],
  preso:['por abrir 17 abas e esquecer todas','por excesso de opinião em assunto aleatório','por perturbação da paz do cemitério','por fugir de uma cobrança oficial do Além'],
  talento:['decorar detalhes completamente inúteis','aparecer com uma resposta na última hora','criar apelidos instantaneamente','sobreviver a conversas que deveriam ter acabado'],
  frase:['“calma que eu resolvo”','“já tô indo”','“foi sem querer”','“eu nem vi”']
});
function pick(a){return a[Math.floor(Math.random()*a.length)];}
const last = new Map();
export function personality(targetName='Pessoa', targetKey='') {
  let out;
  for(let tries=0;tries<6;tries++){
    out={aparencia:pick(POOLS.aparencia),hobby:pick(POOLS.hobby),profissao:pick(POOLS.profissao),horario:pick(POOLS.horario),musica:pick(POOLS.musica),clima:pick(POOLS.clima),signo:pick(POOLS.signo),animal:pick(POOLS.animal),qualidade:pick(POOLS.qualidade),defeito:pick(POOLS.defeito),energia:pick(POOLS.energia),profissaoAlem:pick(POOLS.profissaoAlem),poder:pick(POOLS.poder),preso:pick(POOLS.preso),talento:pick(POOLS.talento),frase:pick(POOLS.frase)};
    const sig=JSON.stringify(out); if(last.get(targetKey)!==sig){last.set(targetKey,sig);break;}
  }
  return {name:targetName,...out};
}
export const addBestFriend = requestBestFriend;
export default {
  listBestFriends,
  requestBestFriend,
  addBestFriend,
  findPendingBestFriendRequest,
  acceptBestFriendRequest,
  rejectBestFriendRequest,
  removeBestFriend,
  setAfk,
  clearAfk,
  clearAfkFromMessage,
  findAfk,
  personality
};
