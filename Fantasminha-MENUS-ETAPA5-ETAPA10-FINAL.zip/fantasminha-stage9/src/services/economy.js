/**
 * Ghostcoins — economia transacional e resistente a race conditions.
 * Todas as mutações críticas passam pela camada de transações.
 */
import { getUser, upsertUser, readCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import { transact } from '../platform/transactions/index.js';

const DAILY = 1000;
const WEEKLY = 5000;
const WORK_MIN = 200;
const WORK_MAX = 800;
const WORK_CD = 60 * 60 * 1000;
const DAILY_CD = 20 * 60 * 60 * 1000;
const WEEKLY_CD = 6 * 24 * 60 * 60 * 1000;
const MAX_WALLET = 50_000_000;
const MAX_AMOUNT = Number.MAX_SAFE_INTEGER;

function ensureEco(u) {
  u.economy ??= { wallet: 0, bank: 0, lastDaily: 0, lastWeekly: 0, lastWork: 0, inventory: {} };
  u.economy.inventory ??= {};
  u.economy.operations ??= {};
  return u.economy;
}

async function atomicUserAndLedger(userId, mutate, ledgerEntry = null, meta = {}) {
  const steps = [{
    collection: 'users',
    update: (users) => {
      users.byId ??= {};
      const u = users.byId[userId] || { id: userId, name: '', economy: {} };
      ensureEco(u);
      users.byId[userId] = mutate(u) || u;
      users.byId[userId].updatedAt = Date.now();
      return users;
    }
  }];
  if (ledgerEntry) steps.push({
    collection: 'economy_ledger',
    update: (L) => {
      L.entries ??= [];
      const operationId = ledgerEntry.operationId || meta.operationId;
      if (operationId && L.entries.some(e => e.operationId === operationId)) return L;
      L.entries.push({ ...ledgerEntry, operationId, at: Date.now() });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000);
      return L;
    }
  });
  return transact(steps, { actor: userId, type: 'economy.atomic', ...meta });
}

export async function getBalance(userId) {
  const u = getUser(userId) || (await upsertUser(userId), getUser(userId));
  const e = ensureEco(u || { economy: {} });
  return { wallet: Number(e.wallet || 0), bank: Number(e.bank || 0), total: Number(e.wallet || 0) + Number(e.bank || 0) };
}

export async function addWallet(userId, amount, reason = 'adjust', name = '', operationId = null) {
  if (!userId || !Number.isFinite(Number(amount)) || Number(amount) === 0 || Math.abs(Number(amount)) > MAX_AMOUNT) throw new ValidationError('Valor inválido.');
  const delta = Number(amount);
  let finalWallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name;
    const e = ensureEco(u);
    if (operationId && e.operations?.[operationId]) { finalWallet = Number(e.wallet || 0); return u; }
    const next = (e.wallet || 0) + delta;
    if (next < 0) throw new ValidationError('Saldo insuficiente.');
    if (next > MAX_WALLET) throw new ValidationError('Limite da carteira atingido.');
    finalWallet = next;
    e.wallet = finalWallet;
    if (operationId) e.operations[operationId] = { at: Date.now(), reason };
    return u;
  }, { userId, amount: delta, reason }, { operationId });
  return ensureEco(getUser(userId));
}

export async function credit(userId, amount, reason = 'credit', name = '', operationId = null) {
  return addWallet(userId, Math.abs(Number(amount)), reason, name, operationId);
}

export async function debit(userId, amount, reason = 'debit', name = '', operationId = null) {
  const value = Math.abs(Number(amount));
  if (!Number.isInteger(value) || value <= 0 || value > MAX_AMOUNT) throw new ValidationError('Valor inválido.');
  return addWallet(userId, -value, reason, name, operationId);
}

export function assertAmount(amount) {
  const value = Number(amount);
  if (!Number.isSafeInteger(value) || value <= 0 || value > MAX_AMOUNT) throw new ValidationError('Valor inválido.');
  return value;
}

export { MAX_WALLET };

function feeRateReadStep(feeReader, expectedKey, capture) {
  if (feeReader?.key !== expectedKey || typeof feeReader.calculateFee !== 'function' || typeof feeReader.createTransactionReadStep !== 'function') {
    throw new ValidationError('Leitor de taxas inválido.');
  }
  const step = feeReader.createTransactionReadStep(capture);
  if (!step || step.readOnly !== true || typeof step.update !== 'function') throw new ValidationError('Leitura transacional de taxa indisponível.');
  return step;
}

export async function transfer(fromId, toId, amount, fromName = '', toName = '', operationId = null) {
  const value = Math.floor(Number(amount));
  if (!Number.isSafeInteger(value) || value <= 0 || value > MAX_AMOUNT || fromId === toId) throw new ValidationError('Transferência inválida.');
  await transact([
    { collection: 'users', update: (users) => {
      users.byId ??= {};
      const from = users.byId[fromId] || { id: fromId, economy: {} };
      const to = users.byId[toId] || { id: toId, economy: {} };
      const ef = ensureEco(from), et = ensureEco(to);
      if (operationId && (ef.operations?.[operationId] || et.operations?.[operationId])) return users;
      if ((ef.wallet || 0) < value) throw new ValidationError('Saldo insuficiente no bolso.');
      if ((et.wallet || 0) + value > MAX_WALLET) throw new ValidationError('Carteira do destinatário atingiu o limite.');
      ef.wallet -= value; et.wallet += value;
      if (operationId) { ef.operations[operationId] = { at: Date.now(), reason: 'transfer_out', to: toId }; et.operations[operationId] = { at: Date.now(), reason: 'transfer_in', from: fromId }; }
      if (fromName) from.name = fromName; if (toName) to.name = toName;
      from.updatedAt = to.updatedAt = Date.now(); users.byId[fromId] = from; users.byId[toId] = to; return users;
    }},
    { collection: 'economy_ledger', update: (L) => {
      L.entries ??= [];
      if (operationId && L.entries.some(e => e.operationId === operationId)) return L;
      L.entries.push({ userId: fromId, amount: -value, reason: 'transfer_out', to: toId, operationId, at: Date.now() });
      L.entries.push({ userId: toId, amount: value, reason: 'transfer_in', from: fromId, operationId, at: Date.now() });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000); return L;
    }}
  ], { actor: fromId, type: 'economy.transfer', from: fromId, to: toId, amount: value, operationId });
  return { amount: value };
}

export async function transferWithFee(fromId, toId, amount, meta = {}, feeReader) {
  const value = assertAmount(amount);
  if (!fromId || !toId || fromId === toId) throw new ValidationError('Transferência inválida.');
  const operationId = meta?.operationId || null;
  let rateBps = feeReader?.defaultRateBps;
  let result;
  let duplicate = false;
  const rateStep = feeRateReadStep(feeReader, 'transferencia', next => { rateBps = next; });
  await transact([
    rateStep,
    { collection: 'economy_ledger', update: L => {
      L.entries ??= [];
      const existing = operationId && L.entries.find(entry => entry.operationId === operationId);
      if (existing) {
        const existingAmount = Number(existing.requestedAmount ?? Math.abs(Number(existing.amount || 0)));
        if (existing.reason !== 'transfer_out' || existing.userId !== fromId || existing.to !== toId || existingAmount !== value) throw new ValidationError('Identificador de operação já utilizado.');
        duplicate = true;
        rateBps = Number(existing.feeRateBps ?? rateBps);
        const fee = Number(existing.fee || 0);
        result = { amount: value, fee, net: value, feeRate: rateBps / 100, feeRateBps: rateBps, duplicate: true };
        return L;
      }
      const fee = feeReader.calculateFee(value, rateBps);
      const totalDebit = value + fee;
      if (!Number.isSafeInteger(totalDebit)) throw new ValidationError('Valor total da transferência inválido.');
      result = { amount: value, fee, net: value, feeRate: rateBps / 100, feeRateBps: rateBps };
      const at = Date.now();
      L.entries.push({ id: `LED-${crypto.randomUUID()}`, userId: fromId, amount: -value, reason: 'transfer_out', to: toId, requestedAmount: value, fee, net: value, feeRateBps: rateBps, operationId, at });
      L.entries.push({ id: `LED-${crypto.randomUUID()}`, userId: toId, amount: value, reason: 'transfer_in', from: fromId, operationId, at });
      if (fee > 0) L.entries.push({ id: `LED-${crypto.randomUUID()}`, userId: fromId, amount: -fee, reason: 'fee.transferencia', feeKey: 'transferencia', feeRateBps: rateBps, operationId, at });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000);
      return L;
    }},
    { collection: 'users', update: users => {
      if (duplicate) return users;
      users.byId ??= {};
      const from = users.byId[fromId] || { id: fromId, economy: {} };
      const to = users.byId[toId] || { id: toId, economy: {} };
      const ef = ensureEco(from), et = ensureEco(to);
      if (operationId && (ef.operations?.[operationId] || et.operations?.[operationId])) throw new ValidationError('Identificador de operação já utilizado.');
      ef.wallet = Number(ef.wallet || 0); et.wallet = Number(et.wallet || 0);
      if (Number(ef.wallet || 0) < value + result.fee) throw new ValidationError('Saldo insuficiente para valor e taxa da transferência.');
      if (Number(et.wallet || 0) + value > MAX_WALLET) throw new ValidationError('Carteira do destinatário atingiu o limite.');
      ef.wallet -= value + result.fee;
      et.wallet += value;
      if (operationId) {
        ef.operations[operationId] = { at: Date.now(), reason: 'transfer_out', to: toId };
        et.operations[operationId] = { at: Date.now(), reason: 'transfer_in', from: fromId };
      }
      if (meta?.name) from.name = meta.name;
      if (meta?.toName) to.name = meta.toName;
      from.updatedAt = to.updatedAt = Date.now();
      users.byId[fromId] = from; users.byId[toId] = to;
      return users;
    }}
  ], { actor: fromId, type: 'economy.transfer', from: fromId, to: toId, amount: value, operationId, feeKey: 'transferencia' });
  return result;
}

export async function deposit(userId, amount) {
  const value = amount === 'all' ? Number(getUser(userId)?.economy?.wallet || 0) : Math.floor(Number(amount));
  if (!Number.isInteger(value) || value <= 0) throw new ValidationError('Valor inválido.');
  await atomicUserAndLedger(userId, (u) => { const e = ensureEco(u); if ((e.wallet || 0) < value) throw new ValidationError('Saldo insuficiente.'); e.wallet -= value; e.bank = (e.bank || 0) + value; return u; }, { userId, amount: value, reason: 'deposit' });
  return ensureEco(getUser(userId));
}

export async function withdraw(userId, amount) {
  const value = amount === 'all' ? Number(getUser(userId)?.economy?.bank || 0) : Math.floor(Number(amount));
  if (!Number.isInteger(value) || value <= 0) throw new ValidationError('Valor inválido.');
  await atomicUserAndLedger(userId, (u) => { const e = ensureEco(u); if ((e.bank || 0) < value) throw new ValidationError('Banco insuficiente.'); e.bank -= value; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + value); return u; }, { userId, amount: value, reason: 'withdraw' });
  return ensureEco(getUser(userId));
}

export async function withdrawWithFee(userId, amount, meta = {}, feeReader) {
  const value = assertAmount(amount);
  if (!userId) throw new ValidationError('Usuário inválido.');
  const operationId = meta?.operationId || null;
  let rateBps = feeReader?.defaultRateBps;
  let result;
  let duplicate = false;
  const rateStep = feeRateReadStep(feeReader, 'saque', next => { rateBps = next; });
  await transact([
    rateStep,
    { collection: 'economy_ledger', update: L => {
      L.entries ??= [];
      const existing = operationId && L.entries.find(entry => entry.operationId === operationId);
      if (existing) {
        const existingAmount = Number(existing.requestedAmount ?? existing.amount);
        if (existing.reason !== 'withdraw' || existing.userId !== userId || existingAmount !== value) throw new ValidationError('Identificador de operação já utilizado.');
        duplicate = true;
        rateBps = Number(existing.feeRateBps ?? rateBps);
        const fee = Number(existing.fee || 0);
        const net = Number(existing.net ?? (value - fee));
        result = { amount: value, fee, net, feeRate: rateBps / 100, feeRateBps: rateBps, duplicate: true };
        return L;
      }
      const fee = feeReader.calculateFee(value, rateBps);
      const net = value - fee;
      result = { amount: value, fee, net, feeRate: rateBps / 100, feeRateBps: rateBps };
      const at = Date.now();
      L.entries.push({ id: `LED-${crypto.randomUUID()}`, userId, amount: value, reason: 'withdraw', requestedAmount: value, fee, net, feeRateBps: rateBps, operationId, at });
      if (fee > 0) L.entries.push({ id: `LED-${crypto.randomUUID()}`, userId, amount: -fee, reason: 'fee.saque', feeKey: 'saque', feeRateBps: rateBps, operationId, at });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000);
      return L;
    }},
    { collection: 'users', update: users => {
      if (duplicate) return users;
      users.byId ??= {};
      const user = users.byId[userId] || { id: userId, name: '', economy: {} };
      const economy = ensureEco(user);
      if (operationId && economy.operations?.[operationId]) throw new ValidationError('Identificador de operação já utilizado.');
      if (Number(economy.bank || 0) < value) throw new ValidationError('Banco insuficiente.');
      economy.bank -= value;
      economy.wallet = Math.min(MAX_WALLET, Number(economy.wallet || 0) + result.net);
      if (operationId) economy.operations[operationId] = { at: Date.now(), reason: 'withdraw' };
      if (meta?.name) user.name = meta.name;
      user.updatedAt = Date.now();
      users.byId[userId] = user;
      return users;
    }}
  ], { actor: userId, type: 'economy.withdraw', userId, amount: value, operationId, feeKey: 'saque' });
  return result;
}

export async function daily(userId, name = '') {
  let gained = DAILY;
  try { const { dailyBonus } = await import('./vipBenefits.js'); gained += dailyBonus(userId) || 0; } catch {}
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastDaily && now - e.lastDaily < DAILY_CD) throw new ValidationError(`Daily já coletado. Volte em ~${Math.ceil((DAILY_CD - (now - e.lastDaily)) / 3600000)}h.`);
    e.lastDaily = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + gained); wallet = e.wallet; return u;
  }, { userId, amount: gained, reason: 'daily' });
  try { const { addWeeklyScore } = await import('./rankings.js'); await addWeeklyScore(userId, name, 'economy', gained); } catch {}
  return { gained, wallet };
}

export async function weekly(userId, name = '') {
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastWeekly && now - e.lastWeekly < WEEKLY_CD) throw new ValidationError('Weekly ainda em cooldown.');
    e.lastWeekly = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + WEEKLY); wallet = e.wallet; return u;
  }, { userId, amount: WEEKLY, reason: 'weekly' });
  return { gained: WEEKLY, wallet };
}

export async function work(userId, name = '') {
  const gained = WORK_MIN + Math.floor(Math.random() * (WORK_MAX - WORK_MIN + 1));
  let wallet = 0;
  await atomicUserAndLedger(userId, (u) => {
    if (name) u.name = name; const e = ensureEco(u), now = Date.now();
    if (e.lastWork && now - e.lastWork < WORK_CD) throw new ValidationError(`Descansando. Trabalho em ${Math.ceil((WORK_CD - (now - e.lastWork)) / 60000)} min.`);
    e.lastWork = now; e.wallet = Math.min(MAX_WALLET, (e.wallet || 0) + gained); wallet = e.wallet; return u;
  }, { userId, amount: gained, reason: 'work' });
  return { gained, wallet };
}

export async function mutateAccount(userId, mutator, { reason = 'adjust', operationId = null, name = '', extraSteps = [], userMutator = null } = {}) {
  if (!userId || typeof mutator !== 'function') throw new ValidationError('Operação econômica inválida.');
  let result;
  const steps = [
    { collection:'users', update:users=>{
      users.byId ??= {};
      const user=users.byId[userId] || {id:userId,name:'',economy:{}};
      const economy=ensureEco(user);
      if(operationId && economy.operations?.[operationId]) { result={duplicate:true,user}; return users; }
      const account={
        get wallet(){return Number(economy.wallet||0)},
        get bank(){return Number(economy.bank||0)},
        credit(amount){const n=assertAmount(amount);const next=Number(economy.wallet||0)+n;if(next>MAX_WALLET)throw new ValidationError('Limite da carteira atingido.');economy.wallet=next;return next;},
        debit(amount){const n=assertAmount(amount);const next=Number(economy.wallet||0)-n;if(next<0)throw new ValidationError('Saldo insuficiente.');economy.wallet=next;return next;},
        deposit(amount){const n=assertAmount(amount);if(Number(economy.wallet||0)<n)throw new ValidationError('Saldo insuficiente.');economy.wallet-=n;economy.bank=Number(economy.bank||0)+n;return {wallet:economy.wallet,bank:economy.bank};},
        withdraw(amount){const n=assertAmount(amount);if(Number(economy.bank||0)<n)throw new ValidationError('Banco insuficiente.');const next=Number(economy.wallet||0)+n;if(next>MAX_WALLET)throw new ValidationError('Limite da carteira atingido.');economy.bank-=n;economy.wallet=next;return {wallet:economy.wallet,bank:economy.bank};}
      };
      result=mutator({user,economy,account}) || result || {};
      if (typeof userMutator === 'function') userMutator({ users, user, economy, account, result });
      if(name)user.name=name;
      if(operationId)economy.operations[operationId]={at:Date.now(),reason};
      user.updatedAt=Date.now(); users.byId[userId]=user; return users;
    }},
    { collection:'economy_ledger', update:L=>{L.entries??=[];if(operationId&&L.entries.some(e=>e.operationId===operationId))return L;const entry={id:`LED-${crypto.randomUUID()}`,at:Date.now(),userId,reason,operationId};if(result?.amount!=null)entry.amount=Number(result.amount);L.entries.push(entry);if(L.entries.length>5000)L.entries=L.entries.slice(-3000);return L;}},
    ...((Array.isArray(extraSteps) ? extraSteps : []).map(step => ({ ...step })))
  ];
  await transact(steps, {actor:userId,type:'economy.mutate',reason,operationId});
  return result;
}

export async function purchaseItem(userId, itemId, price, qty = 1, name = '', operationId = null) {
  const value = assertAmount(price);
  const quantity = assertAmount(qty);
  const total = value * quantity;
  if (!Number.isSafeInteger(total)) throw new ValidationError('Valor total inválido.');
  let inventory = {};
  await transact([
    { collection: 'users', update: users => {
      users.byId ??= {};
      const u = users.byId[userId] || { id: userId, name: '', economy: {} };
      const e = ensureEco(u);
      if (operationId && e.operations?.[operationId]) { inventory = { ...e.inventory }; return users; }
      if ((e.wallet || 0) < total) throw new ValidationError('Ghostcoins insuficientes no bolso.');
      e.wallet -= total;
      e.inventory[itemId] = Number(e.inventory[itemId] || 0) + quantity;
      if (name) u.name = name;
      if (operationId) e.operations[operationId] = { at: Date.now(), reason: 'purchase', itemId, quantity };
      inventory = { ...e.inventory };
      u.updatedAt = Date.now(); users.byId[userId] = u; return users;
    }},
    { collection: 'economy_ledger', update: L => {
      L.entries ??= [];
      if (operationId && L.entries.some(e => e.operationId === operationId)) return L;
      L.entries.push({ id:`LED-${crypto.randomUUID()}`, at:Date.now(), userId, amount:-total, reason:'purchase', itemId, qty:quantity, operationId });
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000); return L;
    }}
  ], { actor:userId, type:'economy.purchase', operationId, itemId, amount:total });
  return { inventory, amount: total };
}

export async function sellItem(userId, itemId, value, qty = 1, name = '', operationId = null) {
  const unit = assertAmount(value);
  const quantity = assertAmount(qty);
  const total = unit * quantity;
  if (!Number.isSafeInteger(total)) throw new ValidationError('Valor total inválido.');
  let wallet = 0, remaining = 0;
  await transact([
    { collection: 'users', update: users => {
      users.byId ??= {};
      const u = users.byId[userId]; if (!u) throw new ValidationError('Usuário não encontrado.');
      const e = ensureEco(u);
      if (operationId && e.operations?.[operationId]) { wallet = Number(e.wallet || 0); remaining = Number(e.inventory[itemId] || 0); return users; }
      const owned = Number(e.inventory[itemId] || 0);
      if (owned < quantity) throw new ValidationError(`Você possui ${owned} unidade(s).`);
      e.inventory[itemId] = owned - quantity; if (e.inventory[itemId] <= 0) delete e.inventory[itemId];
      e.wallet = Math.min(MAX_WALLET, Number(e.wallet || 0) + total);
      if (name) u.name = name;
      if (operationId) e.operations[operationId] = { at: Date.now(), reason:'sell', itemId, quantity };
      wallet = e.wallet; remaining = Number(e.inventory[itemId] || 0); u.updatedAt=Date.now(); users.byId[userId]=u; return users;
    }},
    { collection:'economy_ledger', update:L=>{ L.entries??=[]; if(operationId&&L.entries.some(e=>e.operationId===operationId))return L; L.entries.push({id:`LED-${crypto.randomUUID()}`,at:Date.now(),userId,amount:total,reason:'sell',itemId,qty:quantity,operationId}); if(L.entries.length>5000)L.entries=L.entries.slice(-3000); return L; }}
  ], { actor:userId, type:'economy.sell', operationId, itemId, amount:total });
  return { wallet, remaining, value: total };
}

export async function tradeMarketOffer(buyerId, offerId, buyerName = '', operationId = null) {
  if (!buyerId || !offerId) throw new ValidationError('Compra inválida.');
  const op = operationId || `market-buy:${buyerId}:${offerId}`;
  let purchased = null;
  await transact([
    { collection: 'market', update: M => {
      M.offers ??= {};
      if (Array.isArray(M.offers)) {
        const already = M.offers.find(o => o.id === offerId && o.saleOperationId === op);
        if (already) { purchased = { ...already, price: assertAmount(already.price), qty: assertAmount(already.qty) }; return M; }
        const offer = M.offers.find(o => o.id === offerId && o.active !== false);
        if (!offer) throw new ValidationError('Oferta não encontrada ou já vendida.');
        if (offer.sellerId === buyerId) throw new ValidationError('Não compra a própria oferta.');
        const price = assertAmount(offer.price), qty = assertAmount(offer.qty);
        if (qty > 100000 || !Number.isSafeInteger(price * qty)) throw new ValidationError('Oferta inválida.');
        purchased = { ...offer, price, qty };
        offer.active = false; offer.soldAt = Date.now(); offer.saleOperationId = op;
      } else { throw new ValidationError('Mercado inválido.'); }
      return M;
    }},
    { collection: 'users', update: users => {
      users.byId ??= {};
      const buyer = users.byId[buyerId];
      if (!buyer) throw new ValidationError('Usuário comprador não encontrado.');
      const seller = users.byId[purchased?.sellerId];
      if (!seller) throw new ValidationError('Vendedor não encontrado.');
      ensureEco(buyer); ensureEco(seller);
      if (buyer.economy.operations?.[op] || seller.economy.operations?.[op]) return users;
      const total = assertAmount(purchased.price * purchased.qty);
      if (buyer.economy.wallet < total) throw new ValidationError('GC insuficientes.');
      if (seller.economy.wallet + total > MAX_WALLET) throw new ValidationError('Carteira do vendedor atingiu o limite.');
      buyer.economy.wallet -= total;
      seller.economy.wallet += total;
      buyer.economy.inventory[purchased.itemId] = Number(buyer.economy.inventory[purchased.itemId] || 0) + purchased.qty;
      buyer.economy.operations[op] = { at: Date.now(), reason: 'market.buy', offerId };
      seller.economy.operations[op] = { at: Date.now(), reason: 'market.sell', offerId };
      if (buyerName) buyer.name = buyerName;
      buyer.updatedAt = seller.updatedAt = Date.now();
      users.byId[buyerId] = buyer; users.byId[purchased.sellerId] = seller;
      return users;
    }},
    { collection: 'economy_ledger', update: L => {
      L.entries ??= [];
      if (L.entries.some(e => e.operationId === op)) return L;
      const total = assertAmount(purchased.price * purchased.qty);
      L.entries.push(
        { id:`LED-${crypto.randomUUID()}`, at:Date.now(), userId:buyerId, amount:-total, reason:'market_buy', offerId, operationId:op },
        { id:`LED-${crypto.randomUUID()}`, at:Date.now(), userId:purchased.sellerId, amount:total, reason:'market_sell', offerId, operationId:op }
      );
      if (L.entries.length > 5000) L.entries = L.entries.slice(-3000);
      return L;
    }}
  ], { actor: buyerId, type: 'market.buy', offerId, operationId: op });
  return purchased;
}

export function richRanking(limit = 10) {
  const users = readCollection('users', { byId: {} });
  return Object.values(users.byId || {}).map(u => ({ id: u.id, name: u.name || u.id?.split?.('@')[0], total: (u.economy?.wallet || 0) + (u.economy?.bank || 0) })).sort((a,b) => b.total-a.total).slice(0, limit);
}

export default { getBalance, addWallet, credit, debit, transfer, deposit, withdraw, mutateAccount, daily, weekly, work, purchaseItem, sellItem, tradeMarketOffer, richRanking, assertAmount, MAX_WALLET };
