import { env } from '../../config/env.js';
import { fantasminhaApi } from './FantasminhaApiClient.js';

const integrationCache = new Map();
const IDENTITY_TTL = Math.max(1000, Number(env.FANTASMINHA_API_IDENTITY_CACHE_MS || 15*60*1000) || 15*60*1000);
const GROUP_TTL = Math.max(1000, Number(env.FANTASMINHA_API_GROUP_SYNC_MS || 10*60*1000) || 10*60*1000);
const CACHE_MAX_ENTRIES = Math.max(100, Number(env.FANTASMINHA_API_INTEGRATION_CACHE_MAX || 5000) || 5000);
const ERROR_TTL = Math.max(1000, Number(env.FANTASMINHA_API_INTEGRATION_ERROR_CACHE_MS || 30_000) || 30_000);

function cacheSet(key, value) {
  if (integrationCache.size >= CACHE_MAX_ENTRIES && !integrationCache.has(key)) {
    const oldest = integrationCache.keys().next().value;
    if (oldest) integrationCache.delete(oldest);
  }
  integrationCache.set(key, value);
}

function clean(v){ return typeof v==='string' && v.trim() ? v.trim() : null; }

export async function syncWhatsAppContext(ctx={}) {
  if(!fantasminhaApi.enabled) return {enabled:false};
  const apiCtx={userId:clean(ctx.apiUserId)||undefined,groupId:ctx.isGroup?clean(ctx.from)||undefined:undefined,whatsappJid:clean(ctx.sender)||undefined,whatsappLid:clean(ctx.senderAlternate||ctx.senderLid)||undefined,source:'whatsapp-bot',command:ctx.command||undefined,requestId:ctx.requestId||undefined};
  const result={enabled:true,identity:null,group:null,error:null};
  if(apiCtx.whatsappJid){
    const key=`i:${apiCtx.whatsappJid}`; const hit=integrationCache.get(key); const ttl=hit?.error ? ERROR_TTL : IDENTITY_TTL; if(!hit || Date.now()-hit.ts>ttl){
      try { const r=await fantasminhaApi.resolveIdentity(apiCtx.whatsappJid,apiCtx); result.identity=r?.data?.identity||null; cacheSet(key,{ts:Date.now(),value:result.identity,error:null}); } catch(e) { result.error=e; cacheSet(key,{ts:Date.now(),value:null,error:e}); }
    } else { result.identity=hit.value; if (hit.error) result.error=hit.error; }
  }
  if(apiCtx.groupId){
    const key=`g:${apiCtx.groupId}`; const hit=integrationCache.get(key); const ttl=hit?.error ? ERROR_TTL : GROUP_TTL; if(!hit || Date.now()-hit.ts>ttl){
      try { const r=await fantasminhaApi.upsertGroup({provider:'whatsapp',externalId:apiCtx.groupId,name:clean(ctx.groupName)||undefined,status:'active'},apiCtx); result.group=r?.data||null; cacheSet(key,{ts:Date.now(),value:result.group,error:null}); } catch(e) { result.error=result.error||e; cacheSet(key,{ts:Date.now(),value:null,error:e}); }
    } else { result.group=hit.value; if (hit.error) result.error=result.error||hit.error; }
  }
  return result;
}

export function clearIntegrationCache(){ integrationCache.clear(); }
export function integrationCacheSize(){ return integrationCache.size; }
