/**
 * Single Point of Integration — Fantasminha API.
 * Toda comunicação bot -> API passa por este cliente.
 * Sem dependências externas: fetch + AbortController.
 */
import crypto from 'node:crypto';
import { env } from '../../config/env.js';

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
function requestId(){ return crypto.randomUUID(); }
function hashBody(body){ return crypto.createHash('sha256').update(JSON.stringify(body ?? null)).digest('hex'); }

export class ApiClientError extends Error {
  constructor(message, { code='API_ERROR', status=0, requestId:rid=null, retryable=false, cause }={}){ super(message,{cause}); this.name='ApiClientError'; this.code=code; this.status=status; this.requestId=rid; this.retryable=retryable; }
}

export class CircuitBreaker {
  constructor({failureThreshold=5, resetMs=30000}={}){ this.failureThreshold=failureThreshold; this.resetMs=resetMs; this.failures=0; this.openedAt=0; }
  canRequest(){ if(!this.openedAt) return true; if(Date.now()-this.openedAt>=this.resetMs){ this.openedAt=0; this.failures=0; return true; } return false; }
  success(){ this.failures=0; this.openedAt=0; }
  failure(){ this.failures++; if(this.failures>=this.failureThreshold) this.openedAt=Date.now(); }
  state(){ return this.openedAt ? 'open' : (this.failures ? 'degraded' : 'closed'); }
}

export class FantasminhaApiClient {
  constructor({baseUrl=env.FANTASMINHA_API_URL||'',clientSecret=env.FANTASMINHA_API_CLIENT_SECRET||'',bearerToken=env.FANTASMINHA_API_TOKEN||'',timeoutMs=Number(env.FANTASMINHA_API_TIMEOUT_MS||15000),maxRetries, retries, enabled=env.FANTASMINHA_API_ENABLED==='true',source='whatsapp-bot',logger=console}={}){
    const configuredRetries = maxRetries ?? retries ?? Number(env.FANTASMINHA_API_RETRIES||2);
    this.baseUrl=String(baseUrl).replace(/\/$/,''); this.clientSecret=clientSecret; this.bearerToken=bearerToken; this.timeoutMs=Math.max(1000,Number(timeoutMs)||15000); this.maxRetries=Math.max(0,Math.min(5,Number(configuredRetries)||0)); this.enabled=Boolean(enabled&&this.baseUrl&&(clientSecret||bearerToken)); this.source=source; this.logger=logger; this.breaker=new CircuitBreaker(); this.inflight=new Map();
  }
  status(){ return {enabled:this.enabled,configured:Boolean(this.baseUrl&&(this.clientSecret||this.bearerToken)),baseUrl:this.baseUrl?this.baseUrl.replace(/\/\/.*?@/,'//***@'): '',circuit:this.breaker.state()}; }
  _headers(ctx={}, idem){
    const h={'accept':'application/json','user-agent':'Fantasminha-Bot-API-Client/5','x-request-id':ctx.requestId||requestId(),'x-fantasminha-source':ctx.source||this.source};
    if(this.clientSecret) h['x-api-client-secret']=this.clientSecret; else if(this.bearerToken) h.authorization=`Bearer ${this.bearerToken}`;
    if(ctx.userId) h['x-fantasminha-user-id']=ctx.userId; if(ctx.groupId) h['x-fantasminha-group-id']=ctx.groupId; if(ctx.whatsappJid) h['x-fantasminha-whatsapp-jid']=ctx.whatsappJid; if(ctx.whatsappLid) h['x-fantasminha-whatsapp-lid']=ctx.whatsappLid; if(ctx.command) h['x-fantasminha-command']=ctx.command;
    if(idem) h['idempotency-key']=idem; return h;
  }
  async request(path,{method='GET',body,ctx={},idempotencyKey,timeoutMs=this.timeoutMs,retries=this.maxRetries}={}){
    if(!this.enabled) throw new ApiClientError('API central desativada',{code:'API_DISABLED'});
    if(!this.breaker.canRequest()) throw new ApiClientError('API central temporariamente indisponível',{code:'API_CIRCUIT_OPEN',retryable:true});
    const safeTimeout=Math.max(1000,Number(timeoutMs)||this.timeoutMs); const safeRetries=Math.max(0,Math.min(5,Number(retries)||0));
    const headers=this._headers(ctx,idempotencyKey); if(body!==undefined) headers['content-type']='application/json';
    const rid=headers['x-request-id']; const serialized=body===undefined?undefined:JSON.stringify(body); let last;
    for(let attempt=0;attempt<=safeRetries;attempt++){
      const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),safeTimeout); let retryAfterMs=0;
      try{
        const res=await fetch(`${this.baseUrl}${path}`,{method,headers,body:serialized,signal:controller.signal});
        const retryAfter=Number(res.headers.get('retry-after')||0); retryAfterMs=Number.isFinite(retryAfter)?Math.max(0,retryAfter*1000):0;
        const text=await res.text(); let payload=null; try{payload=text?JSON.parse(text):null;}catch{payload={ok:false,error:{code:'INVALID_API_RESPONSE',message:'Resposta inválida da API.'}};}
        if(res.ok && payload?.ok!==false){ this.breaker.success(); return {...payload,requestId:payload.requestId||rid,status:res.status}; }
        const code=payload?.error?.code||`HTTP_${res.status}`; const retryable=res.status===408||res.status===429||res.status>=500;
        last=new ApiClientError(payload?.error?.message||'Falha na API',{code,status:res.status,requestId:payload?.requestId||rid,retryable});
        if(!retryable || attempt>=safeRetries) break;
      }catch(e){ last=e instanceof ApiClientError?e:new ApiClientError(e?.message||'Falha de rede',{code:e?.name==='AbortError'?'API_TIMEOUT':'API_NETWORK_ERROR',requestId:rid,retryable:true,cause:e}); if(attempt>=safeRetries) break; }
      finally{clearTimeout(timer);}
      await sleep(Math.min(5000,Math.max(250*Math.pow(2,attempt)+Math.floor(Math.random()*150),retryAfterMs)));
    }
    if(last?.retryable) this.breaker.failure(); else this.breaker.success();
    throw last||new ApiClientError('Falha na API',{requestId:rid,retryable:true});
  }
  async requestIdempotent(path,body,ctx={},key=hashBody(body)){
    const subject=ctx.userId||ctx.groupId||ctx.whatsappJid||'service'; const dedupe=`${path}:${subject}:${key}`;
    if(this.inflight.has(dedupe)) return this.inflight.get(dedupe);
    const p=this.request(path,{method:'POST',body,ctx,idempotencyKey:key}).finally(()=>this.inflight.delete(dedupe)); this.inflight.set(dedupe,p); return p;
  }
  providers(ctx){return this.request('/api/v1/providers',{ctx});}
  capabilities(ctx){return this.request('/api/v1/capabilities',{ctx});}
  aiText(body,ctx){return this.request('/api/v1/ai/text',{method:'POST',body,ctx});}
  aiJson(body,ctx){return this.request('/api/v1/ai/json',{method:'POST',body,ctx});}
  aiVision(body,ctx){return this.request('/api/v1/ai/vision',{method:'POST',body,ctx});}
  aiImage(body,ctx){return this.requestIdempotent('/api/v1/ai/image',body,ctx);}
  mediaSearch(body,ctx){return this.request('/api/v1/media/search',{method:'POST',body,ctx});}
  mediaDownload(body,ctx){return this.requestIdempotent('/api/v1/media/download',body,ctx);}
  async artifact(id,ctx){
    if(!this.enabled) throw new ApiClientError('API central desativada',{code:'API_DISABLED'});
    if(!/^[0-9a-f-]{36}$/i.test(String(id))) throw new ApiClientError('Artefato inválido',{code:'INVALID_ARTIFACT_ID'});
    if(!this.breaker.canRequest()) throw new ApiClientError('API central temporariamente indisponível',{code:'API_CIRCUIT_OPEN',retryable:true});
    const maxBytes=Math.max(1024,Number(env.FANTASMINHA_API_ARTIFACT_MAX_BYTES||64*1024*1024));
    const headers=this._headers(ctx); const rid=headers['x-request-id']; let last;
    for(let attempt=0;attempt<=this.maxRetries;attempt++){
      const controller=new AbortController(); const timer=setTimeout(()=>controller.abort(),this.timeoutMs);
      try{
        const r=await fetch(`${this.baseUrl}/api/v1/media/artifacts/${id}`,{headers,signal:controller.signal});
        const len=Number(r.headers.get('content-length')||0);
        if(len>maxBytes) throw new ApiClientError('Artefato excede o limite permitido',{code:'ARTIFACT_TOO_LARGE',status:413,requestId:r.headers.get('x-request-id')||rid,retryable:false});
        if(!r.ok){const retryable=r.status===408||r.status===429||r.status>=500; last=new ApiClientError('Artefato indisponível',{code:r.status===404?'ARTIFACT_NOT_FOUND':r.status===403?'ARTIFACT_ACCESS_DENIED':'ARTIFACT_UNAVAILABLE',status:r.status,requestId:r.headers.get('x-request-id')||rid,retryable});if(!retryable||attempt>=this.maxRetries)break;continue;}
        const b=Buffer.from(await r.arrayBuffer()); if(b.length>maxBytes) throw new ApiClientError('Artefato excede o limite permitido',{code:'ARTIFACT_TOO_LARGE',status:413,requestId:r.headers.get('x-request-id')||rid,retryable:false});
        this.breaker.success(); return {buffer:b,mimeType:r.headers.get('content-type')||'application/octet-stream',requestId:r.headers.get('x-request-id')||rid};
      }catch(e){last=e instanceof ApiClientError?e:new ApiClientError(e?.message||'Falha ao baixar artefato',{code:e?.name==='AbortError'?'API_TIMEOUT':'API_NETWORK_ERROR',requestId:rid,retryable:true,cause:e});if(!last.retryable||attempt>=this.maxRetries)break;}
      finally{clearTimeout(timer);}
      await sleep(Math.min(5000,250*Math.pow(2,attempt)+Math.floor(Math.random()*150)));
    }
    this.breaker.failure(); throw last||new ApiClientError('Falha ao baixar artefato',{requestId:rid,retryable:true});
  }
  resolveIdentity(externalId,ctx={}){return this.request('/api/v1/integration/identity/resolve',{method:'POST',body:{provider:'whatsapp',externalId},ctx});}
  upsertGroup(body,ctx={}){return this.request('/api/v1/integration/group/upsert',{method:'POST',body,ctx});}
  event(body,ctx={}){return this.request('/api/v1/integration/event',{method:'POST',body,ctx});}
}

export const fantasminhaApi = new FantasminhaApiClient();
export default fantasminhaApi;
