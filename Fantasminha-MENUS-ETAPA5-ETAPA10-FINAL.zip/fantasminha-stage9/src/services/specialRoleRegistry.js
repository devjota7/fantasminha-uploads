/**
 * Registro centralizado dos cargos especiais persistentes.
 *
 * Etapa 4: cria uma porta única para atribuições novas (inicialmente Suporte),
 * sem migrar os armazenamentos legados de Dono/Subdono/Aranha/VIP.
 */
import { readCollection, updateCollection } from '../database/store.js';

const COLLECTION = 'special_roles';
const DEFAULT = Object.freeze({ version: 1, global: {}, updatedAt: 0 });
const norm = value => String(value ?? '').trim().toLowerCase();
const base = value => norm(value).replace(/:\d+(?=@)/, '').split('@')[0];

function sameIdentity(a, b) {
  return norm(a) === norm(b) || (base(a) && base(a) === base(b));
}

export function listGlobalRoleUsers(roleId) {
  const role = norm(roleId);
  if (!role) return [];
  const db = readCollection(COLLECTION, DEFAULT);
  const users = Array.isArray(db.global?.[role]) ? db.global[role] : [];
  return [...new Set(users.map(norm).filter(Boolean))];
}

export function hasGlobalRole(userId, roleId) {
  const uid = norm(userId);
  if (!uid) return false;
  return listGlobalRoleUsers(roleId).some(candidate => sameIdentity(candidate, uid));
}

export async function grantGlobalRole(userId, roleId, actor = null) {
  const uid = norm(userId);
  const role = norm(roleId);
  if (!uid || !role) throw new Error('Usuário e cargo são obrigatórios.');
  let result;
  const next = await updateCollection(COLLECTION, db => {
    db.version ||= 1;
    db.global ||= {};
    db.global[role] = Array.isArray(db.global[role]) ? db.global[role] : [];
    const exists = db.global[role].some(candidate => sameIdentity(candidate, uid));
    if (!exists) db.global[role].push(uid);
    db.updatedAt = Date.now();
    result = { changed: !exists, roleId: role, userId: uid, actor: actor ? norm(actor) : null };
    return db;
  }, DEFAULT);
  return { ...result, store: next };
}

export async function revokeGlobalRole(userId, roleId) {
  const uid = norm(userId);
  const role = norm(roleId);
  if (!uid || !role) throw new Error('Usuário e cargo são obrigatórios.');
  let result;
  const next = await updateCollection(COLLECTION, db => {
    db.version ||= 1;
    db.global ||= {};
    const users = Array.isArray(db.global[role]) ? db.global[role] : [];
    const filtered = users.filter(candidate => !sameIdentity(candidate, uid));
    const changed = filtered.length !== users.length;
    if (changed) db.global[role] = filtered;
    db.updatedAt = Date.now();
    result = { changed, roleId: role, userId: uid };
    return db;
  }, DEFAULT);
  return { ...result, store: next };
}

export function getGlobalRoleAssignments() {
  const db = readCollection(COLLECTION, DEFAULT);
  return Object.fromEntries(Object.entries(db.global || {}).map(([role, users]) => [role, Array.isArray(users) ? [...users] : []]));
}

export default { listGlobalRoleUsers, hasGlobalRole, grantGlobalRole, revokeGlobalRole, getGlobalRoleAssignments };
