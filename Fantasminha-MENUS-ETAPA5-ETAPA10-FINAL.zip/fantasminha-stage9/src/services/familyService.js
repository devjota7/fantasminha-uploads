import { getUser, upsertUser, transactionCollections } from '../database/store.js';
import { mutateAccount } from './economy.js';

const MAX_PARENTS = 2;
const MAX_DEPTH = 32;
const VALID_FILIATION = new Set(['biologico', 'adotivo']);

function familyOf(u = {}) {
  u.family ??= {};
  u.family.spouse ??= null;
  u.family.children = clean(u.family.children);
  u.family.parents = clean(u.family.parents);
  u.family.siblings = clean(u.family.siblings);
  u.family.filiation ??= {};
  return u.family;
}

const clean = ids => [...new Set((ids || []).filter(Boolean).map(String))];
const normalizeType = type => VALID_FILIATION.has(type) ? type : 'adotivo';
const ensureId = id => String(id || '').trim();

function ancestors(id, seen = new Set()) {
  id = ensureId(id);
  if (!id || seen.has(id) || seen.size >= MAX_DEPTH) return seen;
  seen.add(id);
  const u = getUser(id);
  for (const p of familyOf(u || {}).parents) ancestors(p, seen);
  return seen;
}

function descendants(id, seen = new Set()) {
  id = ensureId(id);
  if (!id || seen.has(id) || seen.size >= MAX_DEPTH) return seen;
  seen.add(id);
  const u = getUser(id);
  for (const c of familyOf(u || {}).children) descendants(c, seen);
  return seen;
}

function wouldCycle(parent, child) {
  parent = ensureId(parent); child = ensureId(child);
  return parent === child || ancestors(parent).has(child) || descendants(child).has(parent);
}

export function get(userId) {
  return familyOf(getUser(userId) || { id: userId });
}

export function relationCount(userId) {
  const f = get(userId);
  return f.parents.length + f.children.length + f.siblings.length + (f.spouse ? 1 : 0);
}

export function getFiliationType(childId, parentId) {
  const child = getUser(childId);
  const f = familyOf(child || {});
  return normalizeType(f.filiation?.[parentId] || child?.filiationType);
}

export function listChildren(parentId) {
  const f = get(parentId);
  return f.children.map(childId => ({ childId, type: getFiliationType(childId, parentId) }));
}

export async function adopt({ parentId, childId, biological = false, debitCost = 0 }) {
  parentId = ensureId(parentId); childId = ensureId(childId);
  if (!parentId || !childId || parentId === childId) throw new Error('Vínculo familiar inválido.');
  if (wouldCycle(parentId, childId)) throw new Error('Esse vínculo criaria um ciclo na árvore familiar.');

  const type = biological ? 'biologico' : 'adotivo';
  const parent = getUser(parentId) || { id: parentId, family: {} };
  const child = getUser(childId) || { id: childId, family: {} };
  const pf = familyOf(parent), cf = familyOf(child);

  if (cf.parents.length >= MAX_PARENTS && !cf.parents.includes(parentId)) {
    throw new Error('Essa pessoa já possui dois pais/responsáveis.');
  }
  if (pf.children.includes(childId)) {
    const current = getFiliationType(childId, parentId);
    if (current === type) throw new Error('Já existe esse vínculo.');
    throw new Error(`Esse vínculo já existe como ${current === 'biologico' ? 'biológico' : 'adotivo'}.`);
  }

  const op = `family:${type}:${parentId}:${childId}`;
  const apply = d => {
    d.byId ??= {};
    const p = d.byId[parentId] || { id: parentId, family: {} };
    const c = d.byId[childId] || { id: childId, family: {} };
    const pF = familyOf(p), cF = familyOf(c);
    pF.children = clean([...pF.children, childId]);
    cF.parents = clean([...cF.parents, parentId]);
    cF.filiation[parentId] = type;
    // Compatibilidade com a estrutura antiga: mantém o tipo quando existe um único pai.
    c.filiationType = cF.parents.length === 1 ? type : undefined;
    if (c.filiationType === undefined) delete c.filiationType;
    d.byId[parentId] = p;
    d.byId[childId] = c;
    return d;
  };

  if (debitCost > 0) {
    const wallet = Number(parent?.economy?.wallet || 0);
    if (wallet < debitCost) throw new Error(`Você precisa de ${Number(debitCost).toLocaleString('pt-BR')} moedas para adotar!`);
    await mutateAccount(parentId, ({ account }) => {
      account.debit(debitCost);
      return { amount: -debitCost };
    }, { reason: 'family.adoption', operationId: op, userMutator: ({ users }) => apply(users) });
  } else {
    await transactionCollections([{ collection: 'users', update: apply }], { reason: op });
  }
  return getUser(childId);
}

export async function removeChild({ parentId, childId }) {
  parentId = ensureId(parentId); childId = ensureId(childId);
  if (!parentId || !childId || parentId === childId) throw new Error('Vínculo familiar inválido.');
  const parent = getUser(parentId), child = getUser(childId);
  if (!parent || !child) throw new Error('Usuário não encontrado.');
  const pf = familyOf(parent), cf = familyOf(child);
  if (!pf.children.includes(childId) || !cf.parents.includes(parentId)) throw new Error('Esta pessoa não é seu filho(a).');

  const removedType = getFiliationType(childId, parentId);
  await transactionCollections([{
    collection: 'users',
    update: users => {
      users.byId ??= {};
      const p = users.byId[parentId], c = users.byId[childId];
      if (!p || !c) throw new Error('Usuário não encontrado.');
      const pF = familyOf(p), cF = familyOf(c);
      pF.children = pF.children.filter(id => id !== childId);
      cF.parents = cF.parents.filter(id => id !== parentId);
      delete cF.filiation[parentId];
      if (cF.parents.length === 1) c.filiationType = normalizeType(cF.filiation[cF.parents[0]]);
      else delete c.filiationType;
      users.byId[parentId] = p;
      users.byId[childId] = c;
      return users;
    }
  }], { reason: `family.removeChild:${parentId}:${childId}` });
  return { childId, type: removedType };
}

export async function leaveFamily({ userId }) {
  userId = ensureId(userId);
  if (!userId) throw new Error('Usuário inválido.');
  const me = getUser(userId);
  if (!me) throw new Error('Usuário não encontrado.');
  const f = familyOf(me);
  if (!f.parents.length && !f.children.length) return { parentsRemoved: [], childrenRemoved: [] };

  const parentIds = [...f.parents];
  const childIds = [...f.children];
  await transactionCollections([{
    collection: 'users',
    update: users => {
      users.byId ??= {};
      const u = users.byId[userId];
      if (!u) throw new Error('Usuário não encontrado.');
      const uf = familyOf(u);
      for (const parentId of parentIds) {
        const p = users.byId[parentId]; if (!p) continue;
        const pf = familyOf(p);
        pf.children = pf.children.filter(id => id !== userId);
        users.byId[parentId] = p;
      }
      for (const childId of childIds) {
        const c = users.byId[childId]; if (!c) continue;
        const cf = familyOf(c);
        cf.parents = cf.parents.filter(id => id !== userId);
        delete cf.filiation[userId];
        if (cf.parents.length === 1) c.filiationType = normalizeType(cf.filiation[cf.parents[0]]);
        else delete c.filiationType;
        users.byId[childId] = c;
      }
      uf.parents = [];
      uf.children = [];
      uf.filiation = {};
      users.byId[userId] = u;
      return users;
    }
  }], { reason: `family.leave:${userId}` });
  return { parentsRemoved: parentIds, childrenRemoved: childIds };
}

export function tree(userId) {
  const seen = new Set(), lines = [], mentions = [];
  const walk = (id, label, depth = 0) => {
    if (!id || depth > 3 || seen.has(`${label}:${id}`)) return;
    seen.add(`${label}:${id}`);
    const u = getUser(id) || {};
    const f = familyOf(u);
    lines.push(`${'  '.repeat(depth)}${label} ${id.startsWith('@') ? '' : '@'}${String(id).split('@')[0]}`);
    mentions.push(id);
    if (depth < 3) for (const p of f.parents) walk(p, `👴👵${getFiliationType(id, p) === 'biologico' ? ' 🧬' : ' 🍼'}`, depth + 1);
    if (depth < 3) for (const c of f.children) walk(c, `👶${getFiliationType(c, id) === 'biologico' ? ' 🧬' : ' 🍼'}`, depth + 1);
  };
  walk(userId, '👤');
  return { lines, mentions: [...new Set(mentions)] };
}

export async function migrateLegacyShape(userId) {
  const u = getUser(userId); if (!u) return null;
  const f = familyOf(u);
  await upsertUser(userId, { family: { ...f } });
  return f;
}

export default { get, relationCount, getFiliationType, listChildren, adopt, removeChild, leaveFamily, tree, migrateLegacyShape };
