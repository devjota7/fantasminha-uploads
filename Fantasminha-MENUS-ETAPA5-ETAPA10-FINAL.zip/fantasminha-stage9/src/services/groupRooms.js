import fs from 'node:fs/promises';
import path from 'node:path';
import * as groupRoomRepository from '../database/repositories/groupRoomRepository.js';

const COLLECTION = 'group_rooms';
const LEGACY_FILE = new URL('../../dados/database/groupRooms.json', import.meta.url);
let migrationChecked = false;

function cleanCode(code) {
  return [...String(code ?? '').trim().replace(/\s+/g, ' ')].slice(0, 15).join('');
}

function loadCanonical() {
  const data = groupRoomRepository.read();
  if (!data.byId || typeof data.byId !== 'object') data.byId = {};
  return data;
}

export async function initializeGroupRoomsPersistence() {
  if (migrationChecked) return;
  migrationChecked = true;
  try {
    const raw = await fs.readFile(LEGACY_FILE, 'utf8');
    const legacy = JSON.parse(raw);
    if (!legacy || typeof legacy !== 'object' || !Object.keys(legacy).length) return;
    await groupRoomRepository.update(current => {
      current.byId ||= {};
      for (const [groupId, room] of Object.entries(legacy)) {
        if (!current.byId[groupId] && room && typeof room === 'object') current.byId[groupId] = room;
      }
      return current;
    });
    const backup = `${LEGACY_FILE.pathname}.migrated-${Date.now()}`;
    await fs.rename(LEGACY_FILE, backup);
  } catch (error) {
    if (error?.code !== 'ENOENT') console.error('[GROUP_ROOMS] migração legada não concluída:', error.message);
  }
}

export function getRoom(groupId) {
  if (!groupId) return null;
  return loadCanonical().byId[groupId] || null;
}

export async function setRoom(groupId, code, userId) {
  if (!groupId) throw new Error('Grupo inválido.');
  const clean = cleanCode(code);
  if (!clean) throw new Error('Informe o código da sala.');
  const now = new Date().toISOString();
  let result;
  await groupRoomRepository.update(current => {
    current.byId ||= {};
    const previous = current.byId[groupId];
    result = current.byId[groupId] = {
      code: clean,
      createdAt: previous?.createdAt || now,
      createdBy: previous?.createdBy || userId || null,
      updatedAt: now,
      updatedBy: userId || null
    };
    return current;
  });
  return result;
}

export async function removeRoom(groupId) {
  if (!groupId) return false;
  let removed = false;
  await groupRoomRepository.update(current => {
    current.byId ||= {};
    if (!current.byId[groupId]) return current;
    delete current.byId[groupId];
    removed = true;
    return current;
  });
  return removed;
}

export function roomStatus(groupId) { return getRoom(groupId); }

export default { getRoom, setRoom, removeRoom, roomStatus, initializeGroupRoomsPersistence };
