import { SPECIAL_ROLE } from '../core/specialRoles.js';
import { listGlobalRoleUsers } from './specialRoleRegistry.js';
import { listBotRoles } from './botRoles.js';
import { listActiveVipUsers, getVipPlan } from './vipBenefits.js';
import { getSubdonos } from '../../dados/src/utils/database.js';

export function getSpecialRoleStats(ctx = {}, roleId) {
  const role = String(roleId || '').trim().toLowerCase();
  if (role === SPECIAL_ROLE.ARANHA) {
    const users = ctx.from?.endsWith?.('@g.us') ? listBotRoles(ctx.from).filter(item => item.role?.id === SPECIAL_ROLE.ARANHA) : [];
    return { role, total: users.length, scope: ctx.from?.endsWith?.('@g.us') ? 'group' : 'none' };
  }
  if (role === SPECIAL_ROLE.SUPPORT) {
    return { role, total: listGlobalRoleUsers(SPECIAL_ROLE.SUPPORT).length, scope: 'global' };
  }
  if (role === SPECIAL_ROLE.SUB_OWNER) {
    return { role, total: getSubdonos().length, scope: 'global' };
  }
  if (role === SPECIAL_ROLE.VIP) {
    const users = listActiveVipUsers();
    const plans = { bronze: 0, prata: 0, ouro: 0 };
    for (const id of users) { const plan = getVipPlan(id) || 'prata'; plans[plan] = (plans[plan] || 0) + 1; }
    return { role, total: users.length, scope: 'global', plans };
  }
  return { role, total: 0, scope: 'unknown' };
}

export default { getSpecialRoleStats };
