/**
 * Fantasminha — comandos extras, jogos e identidade
 * Tema: pós-vida / purgatório / submundo / dark
 */

import fs from 'fs';
import path from 'path';
import { caixa, smallCaps } from '../respostas/estilo.js';
import { pickFrase } from '../respostas/frases.js';

const FRASES_ALEM = [
  "No purgatório o café esfria, mas a fila nunca acaba.",
  "Do outro lado do véu o wi-fi é eterno. A paciência, não.",
  "Almas não mentem — só omitem o anexo.",
  "A morte é só o loading screen da próxima fase.",
  "Seu karma pediu reembolso. Negado.",
  "O submundo tem regras. Ninguém as lê.",
  "Fantasmas não dormem. Só fingem.",
  "Julgamento final: falta carimbo.",
  "Você não está perdido. Está em modo espectador.",
  "O véu é fino. Sua desculpa, mais ainda.",
  "Bem-vindo ao limbo. Senha: esqueci.",
  "Eco do além: pare de gritar no grupo.",
  "Cemitério digital: aqui descansam os comandos sem prefixo.",
  "Sombra não te segue. Ela já chegou.",
  "Ceifador de plantão: só coleta conversa hoje."
];

const ORACULOS = [
  "Os ossos dizem: hoje não. Amanhã também não.",
  "Três velas, um aviso: evite decisões impulsivas.",
  "A roda gira. Você está no meio.",
  "Sorte cinza: nem bênção, nem maldição. Só terça-feira.",
  "Uma porta se abre. É a do banheiro. Ainda assim, avance.",
  "O oráculo tossiu. Interprete como quiser.",
  "Destino carimbado: 'em análise'.",
  "As estrelas estão offline. Tente o submundo."
];

const PEADOS = ["preguiça etérea", "ironia excessiva", "furar fila no limbo", "zoar o ceifador", "spam de sticker", "prometer e não voltar", "ler e não responder"];
const VIRTUDES = ["paciência de túmulo", "lealdade de sombra", "humor negro saudável", "escuta ativa do além", "coragem de atravessar o véu"];

const PALAVRAS_FORCA = ["purgatorio", "fantasma", "submundo", "cemiterio", "esqueleto", "caveira", "esquecimento", "barqueiro", "limbo", "sussurro", "velorio", "obituario", "necroterio", "alma", "espirito"];
const QUIZ = [
  { q: "Quem rema as almas no rio?", a: ["barqueiro", "caronte", "charon"] },
  { q: "Lugar entre o céu e o inferno?", a: ["purgatorio", "limbo"] },
  { q: "Nome comum para espírito residual?", a: ["fantasma", "alma", "espectro"] },
  { q: "Objeto que ilumina túmulos em clichês?", a: ["vela", "lanterna"] },
  { q: "Documento da morte (humor)?", a: ["obituario", "atestado"] }
];

function rand(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function pct(seed = "") {
  let h = 0;
  const s = String(seed) + Date.now().toString().slice(0, -5);
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
  return (h % 101);
}

function ensureDir(p) {
  const d = path.dirname(p);
  if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true });
}

function loadGameState(baseDir, groupId) {
  const file = path.join(baseDir, "games_alem", `${groupId.replace(/[^a-zA-Z0-9@._-]/g, "_")}.json`);
  ensureDir(file);
  if (!fs.existsSync(file)) return { file, data: {} };
  try {
    return { file, data: JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return { file, data: {} };
  }
}

function saveGameState(file, data) {
  ensureDir(file);
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}


function scoresFile(baseDir, groupId) {
  return path.join(baseDir, "games_alem", `scores_${String(groupId).replace(/[^a-zA-Z0-9@._-]/g, "_")}.json`);
}

function loadScores(baseDir, groupId) {
  const file = scoresFile(baseDir, groupId);
  ensureDir(file);
  if (!fs.existsSync(file)) return { file, data: { players: {} } };
  try {
    return { file, data: JSON.parse(fs.readFileSync(file, "utf8")) };
  } catch {
    return { file, data: { players: {} } };
  }
}

function addScore(baseDir, groupId, userId, userName, points, game) {
  const { file, data } = loadScores(baseDir, groupId);
  const id = String(userId || "x").replace(/[^a-zA-Z0-9@._-]/g, "_");
  if (!data.players[id]) data.players[id] = { name: userName || id.split("@")[0], points: 0, wins: 0, games: {} };
  data.players[id].name = userName || data.players[id].name;
  data.players[id].points += points;
  if (points > 0) data.players[id].wins += 1;
  if (!data.players[id].games[game]) data.players[id].games[game] = 0;
  data.players[id].games[game] += points;
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
  return data.players[id];
}

function rankText(baseDir, groupId, limit = 10) {
  const { data } = loadScores(baseDir, groupId);
  const list = Object.entries(data.players || {})
    .map(([id, p]) => ({ id, ...p }))
    .sort((a, b) => b.points - a.points)
    .slice(0, limit);
  if (!list.length) return "🏆 *Placar do Além*\\n\\nNenhuma alma pontuou ainda.";
  const lines = list.map((p, i) => `${i + 1}. *${p.name}* — ${p.points} pts (${p.wins} vitórias)`);
  return `🏆 *Placar do Além*\\n\\n${lines.join("\\n")}`;
}

export function placarAlem(baseDir, groupId) {
  return rankText(baseDir, groupId);
}


export function fraseAlem() {
  return `🕯️ *Eco do véu*\n\n_${rand(FRASES_ALEM)}_\n\n— Fantasminha`;
}

export function statusAlem() {
  const estados = ["observando a fila", "carimbando almas", "reiniciando o limbo", "apagando velas", "contando ecos", "zoando o ceifador"];
  return `👻 *Status do Além*\n\n• Fantasminha: *online no véu*\n• Submundo: *${rand(estados)}*\n• Fila do purgatório: *${20 + Math.floor(Math.random() * 980)} almas*\n• Wi-fi eterno: *estável*\n• Humor negro: *ativo*`;
}

export function oraculo() {
  return `👁️ *Oráculo do Submundo*\n\n${rand(ORACULOS)}`;
}

export function veuMsg() {
  return `🌑 *O Véu*\n\nFino o bastante para ouvir o grupo.\nEspesso o bastante para você não fugir do prefixo.\n\nAtravesse com: comandos, não com desculpas.`;
}

export function purgatorioMsg() {
  return `⛓️ *Purgatório*\n\nRegras:\n1. Espere.\n2. Reespere.\n3. Aceite o meme.\n\nCafé: frio.\nFila: eterna.\nVocê: ainda aqui.`;
}

export function submundoMsg() {
  return `🕳️ *Submundo*\n\nNão é inferno. É escritório com iluminação pior.\nAqui o Fantasminha manda nos menus.\nVocê manda... nos stickers.`;
}

export function cemiterioMsg() {
  return `⚰️ *Cemitério Digital*\n\nAqui descansam:\n• comandos sem prefixo\n• promessas de "já volto"\n• figuris que ninguém salvou\n\nDescanse em paz (ou reinicie o bot).`;
}

export function ecoMsg(text) {
  if (!text) return `📢 *Eco*\nUse: eco <texto>\nO além repete. Sem filtro emocional.`;
  return `📢 *Eco do além*\n\n${text}\n\n_${text}_\n\n**${text}**`;
}

const ALMA_VARIETY = {
  tipos: ["Alma Travessa", "Alma Antiga", "Alma Errante", "Alma Nebulosa", "Alma Teimosa", "Alma de Plantão", "Alma Indisciplinada", "Alma Silenciosa", "Alma Inquieta", "Alma Improvisada", "Alma Fora de Rota", "Alma de Baixa Frequência", "Alma Relâmpago", "Alma Sonâmbula", "Alma Enigmática", "Alma Sobrecarregada", "Alma de Segunda-feira", "Alma Sem Manual", "Alma Interdimensional", "Alma Suspeita"],
  origens: ["nascida entre dois portais", "extraviada na fila do purgatório", "registrada no livro errado", "encontrada atrás do véu", "chegou sem documentação", "escapou de uma sessão espírita", "veio de uma dimensão com sinal fraco", "apareceu no radar do Além", "foi encaminhada pelo departamento de mistérios", "entrou pela porta errada", "foi confundida com uma notificação", "surgiu durante uma atualização do limbo"],
  auras: ["Violeta Espectral", "Azul de Emergência", "Cinza Lunar", "Branca Instável", "Verde de Purgatório", "Roxa Nebulosa", "Prateada", "Eclipse", "Fumaça Azul", "Âmbar Fantasma", "Preta com brilho suspeito", "Transparente demais", "Vermelha de Alerta", "Chuva de Estrelas Mortas"],
  elementos: ["Névoa", "Ectoplasma", "Sombra", "Eco", "Vento do Véu", "Cinza", "Lua", "Trovão", "Silêncio", "Luz Fantasma", "Caos", "Gelo de Purgatório"],
  virtudes: ["Lealdade", "Coragem", "Paciência", "Curiosidade", "Persistência", "Criatividade", "Generosidade", "Bom humor", "Instinto de sobrevivência", "Capacidade de ouvir", "Esperança", "Diplomacia", "Resistência ao caos", "Talento para improvisar"],
  pecados: ["Preguiça", "Ironia excessiva", "Curiosidade onde não devia", "Furar fila no limbo", "Spam de sticker", "Ler e não responder", "Prometer e esquecer", "Zoar o ceifador", "Atraso espiritual", "Mexer onde está escrito NÃO MEXA", "Acumular desculpas", "Caos gratuito", "Discutir com o oráculo", "Usar o portal sem bater"],
  manias: ["abre portais só para ver onde dão", "desconfia de toda placa escrita 'não entre'", "cumprimenta fantasmas desconhecidos", "guarda tickets de fila que nunca usa", "faz perguntas ao sistema", "some quando chega a hora de ajudar", "tenta negociar com o ceifador", "confia demais em atalhos", "acha que todo ruído é uma mensagem", "entra no limbo e esquece por quê"],
  talentos: ["encontrar atalhos no Além", "detectar mentira espiritual", "sobreviver a reuniões do limbo", "invocar confusão sem esforço", "encontrar portas secretas", "acalmar fantasmas nervosos", "transformar azar em história engraçada", "aparecer exatamente quando ninguém chamou", "entender sinais do véu", "escapar de filas impossíveis"],
  fraquezas: ["cafés frios", "filas longas", "portas sem maçaneta", "notificações misteriosas", "fantasmas que dizem 'precisamos conversar'", "placas de manutenção", "o botão vermelho", "questionários do Além", "Wi-Fi do purgatório", "o som de uma impressora espiritual"],
  destinos: ["Guardião do Portal", "Porteiro do Purgatório", "Cartógrafo do Além", "Consultor de Assombrações", "Fiscal de Almas", "Mensageiro do Véu", "Barqueiro Reserva", "Técnico de Portais", "Arquivista do Limbo", "Detetive Espiritual", "Supervisor de Ecos", "Visitante VIP do Submundo", "Cargo ainda em análise", "Entidade não identificada"],
  animais: ["gato espectral", "corvo que sabe demais", "lobo de névoa", "coruja do limbo", "raposa fantasma", "morcego burocrata", "peixe astral", "cachorro que atravessa paredes", "coelho interdimensional", "nenhum — até o animal espiritual ficou com medo"],
  objetos: ["uma vela que nunca apaga", "um ticket de fila infinito", "um mapa que muda sozinho", "uma chave sem porta", "um sino que toca sozinho", "um crachá de visitante", "um espelho que discorda de você", "uma moeda de karma", "um guarda-chuva para tempestades espirituais", "um controle remoto sem televisão"],
  comidas: ["pizza espectral", "café do limbo", "sopa de névoa", "pudim ectoplasmático", "biscoito do purgatório", "macarrão interdimensional", "sanduíche de madrugada", "nada — a alma está de dieta espiritual", "bolo que aparece quando ninguém olha", "pipoca de ectoplasma"],
  ocorrencias: ["Um fantasma tentou te entrevistar e esqueceu as perguntas.", "O portal piscou três vezes. Ninguém sabe por quê.", "O sistema procurou sua ficha e encontrou um meme.", "Uma alma desconhecida acenou para você e desapareceu.", "O ceifador olhou sua ficha e pediu para falar depois.", "O oráculo travou por alguns segundos. Isso foi considerado um resultado.", "A fila do purgatório abriu uma faixa exclusiva. Ela fechou imediatamente.", "Um funcionário do Além carimbou sua ficha sem ler.", "Seu eco chegou antes de você.", "O véu identificou sua presença como 'talvez'.", "Uma porta secreta apareceu. Depois fingiu que nunca existiu.", "O sistema detectou atividade paranormal e descobriu que era você."],
  vereditos: [
    "Pode atravessar o véu. Mas não toque nas portas sem identificação.",
    "Aprovado com ressalvas. O departamento espiritual ainda está desconfiado.",
    "Liberado para circulação. O Além não assume responsabilidade.",
    "Volta pra fila. Seu passe espiritual está em manutenção.",
    "Alma autorizada. Comportamento: questionável.",
    "Você passou. Ninguém sabe como.",
    "Resultado inconclusivo. A própria alma pediu um segundo parecer.",
    "Entrada permitida. Não conte para o ceifador.",
    "Aprovado pelo sistema. Reprovado pelo bom senso.",
    "O Além aceitou sua alma e imediatamente se arrependeu."
  ],
  frases: [
    "Sua alma tem potencial. O manual, infelizmente, não.",
    "O Além analisou. O Além julgou. O Além ficou em dúvida.",
    "Existe método nisso. Só não sabemos qual.",
    "Sua assinatura espiritual é estranhamente familiar.",
    "O resultado é oficial até alguém atualizar o sistema.",
    "Nem toda alma precisa fazer sentido. A sua definitivamente não precisa.",
    "O véu não é problema. A burocracia é.",
    "Seu histórico espiritual foi classificado como 'interessante'.",
    "A análise terminou sem incidentes. Isso já é raro.",
    "O Fantasminha recomenda não questionar os números."
  ]
};

const ALMA_RARITIES = [
  { name: "Comum", weight: 70 },
  { name: "Incomum", weight: 18 },
  { name: "Raro", weight: 8 },
  { name: "Épico", weight: 3 },
  { name: "Lendário", weight: 0.9 },
  { name: "???", weight: 0.1 }
];

const almaRecent = new Map();

function almaSeeded(seed) {
  let h = 2166136261 >>> 0;
  const s = String(seed);
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return () => {
    h += 0x6D2B79F5;
    let t = h;
    t = Math.imul(t ^ t >>> 15, t | 1);
    t ^= t + Math.imul(t ^ t >>> 7, t | 61);
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}

function almaPick(rng, arr) {
  return arr[Math.floor(rng() * arr.length)];
}

function almaInt(rng, min, max) {
  return min + Math.floor(rng() * (max - min + 1));
}

function almaWeighted(rng) {
  const total = ALMA_RARITIES.reduce((a, x) => a + x.weight, 0);
  let n = rng() * total;
  for (const r of ALMA_RARITIES) {
    n -= r.weight;
    if (n <= 0) return r.name;
  }
  return "Comum";
}

function almaSpecial(rarity, rng) {
  if (rarity === "???") return {
    event: "⚠️ O sistema encontrou uma alma que não consta no banco de dados.",
    destiny: "Registro ALM-000",
    verdict: "Não sabemos se você foi analisado ou se foi você quem analisou o sistema."
  };
  if (rarity === "Lendário") return {
    event: almaPick(rng, ["O Portal Principal abriu sozinho ao detectar sua assinatura.", "O ceifador conferiu sua ficha duas vezes e fez um sinal de respeito.", "Uma sala secreta do Além reconheceu seu nome."]),
    destiny: almaPick(rng, ["Guardião Supremo do Véu", "Visitante Lendário do Além", "Administrador temporário de uma dimensão"]),
    verdict: "Resultado lendário. Até o Fantasminha ficou sem uma piada pronta."
  };
  if (rarity === "Épico") return {
    event: almaPick(rng, ["Três portais apareceram ao mesmo tempo. Todos levavam para o mesmo lugar.", "Seu eco voltou com uma mensagem assinada por você.", "O sistema registrou uma ocorrência e marcou como 'boa sorte'."]),
    destiny: almaPick(rng, ["Guardião de Portal Secreto", "Especialista em Anomalias", "Cartógrafo da Zona Proibida"]),
    verdict: "Resultado épico. A burocracia espiritual vai demorar para entender."
  };
  return null;
}

export function almaMsg(nome) {
  const n = String(nome || "Alguém").trim().slice(0, 80) || "Alguém";
  const bucket = Math.floor(Date.now() / 2500);
  const key = n.toLocaleLowerCase('pt-BR');
  let seed = `${key}|${bucket}|${Math.floor(Date.now() / 30000)}`;
  const recent = almaRecent.get(key) || [];
  let rng = almaSeeded(seed);
  let rarity = almaWeighted(rng);
  const p = almaInt(rng, 5, 98);
  const purity = almaInt(rng, 10, 96);
  const corruption = 100 - purity;
  const energy = almaInt(rng, 8, 99);
  const chaos = almaInt(rng, 1, 100);
  const karma = almaInt(rng, -99, 99);
  const special = almaSpecial(rarity, rng);
  let signature = ["ALM", almaInt(rng, 10, 99), String(almaInt(rng, 100, 999))].join("-");
  if (recent.some((r) => r.signature === signature)) {
    seed += `|fresh-${Date.now()}-${Math.random()}`;
    rng = almaSeeded(seed);
    signature = ["ALM", almaInt(rng, 10, 99), String(almaInt(rng, 100, 999))].join("-");
  }

  const result = {
    seed,
    rarity,
    signature,
    type: almaPick(rng, ALMA_VARIETY.tipos),
    origin: almaPick(rng, ALMA_VARIETY.origens),
    aura: almaPick(rng, ALMA_VARIETY.auras),
    element: almaPick(rng, ALMA_VARIETY.elementos),
    virtue: almaPick(rng, ALMA_VARIETY.virtudes),
    sin: almaPick(rng, ALMA_VARIETY.pecados),
    mania: almaPick(rng, ALMA_VARIETY.manias),
    talent: almaPick(rng, ALMA_VARIETY.talentos),
    weakness: almaPick(rng, ALMA_VARIETY.fraquezas),
    animal: almaPick(rng, ALMA_VARIETY.animais),
    object: almaPick(rng, ALMA_VARIETY.objetos),
    food: almaPick(rng, ALMA_VARIETY.comidas),
    purity,
    corruption,
    energy,
    chaos,
    karma,
    presence: p,
    event: special?.event || almaPick(rng, ALMA_VARIETY.ocorrencias),
    destiny: special?.destiny || almaPick(rng, ALMA_VARIETY.destinos),
    verdict: special?.verdict || almaPick(rng, ALMA_VARIETY.vereditos),
    phrase: almaPick(rng, ALMA_VARIETY.frases)
  };

  recent.unshift({ signature: result.signature, seed: result.seed, rarity: result.rarity });
  almaRecent.set(key, recent.slice(0, 8));
  if (almaRecent.size > 500) almaRecent.delete(almaRecent.keys().next().value);

  const rarityLine = rarity === "Comum" ? "" : `\n│ ✦ Raridade      ${rarity}`;
  const karmaText = karma >= 0 ? `+${karma}` : String(karma);
  return `👻 *ANÁLISE DA ALMA*\n\n╭─「 ${n} 」────────╮\n│ 🧬 Tipo          ${result.type}\n│ 🌑 Origem        ${result.origin}\n│ 🌌 Aura          ${result.aura}\n│ 🔮 Elemento      ${result.element}\n│ ✨ Pureza        ${result.purity}%\n│ 🕯️ Corrupção     ${result.corruption}%\n│ ⚡ Energia        ${result.energy}%\n│ 🎲 Caos          ${result.chaos}%\n│ ⚖️ Karma          ${karmaText}${rarityLine}\n╰──────────────────╯\n\n╭─「 🪽 CARACTERÍSTICAS 」─╮\n│ Virtude: ${result.virtue}\n│ Pecado: ${result.sin}\n│ Mania: ${result.mania}\n│ Talento: ${result.talent}\n│ Fraqueza: ${result.weakness}\n╰────────────────────────╯\n\n🐾 Animal espiritual: *${result.animal}*\n🎒 Objeto espiritual: *${result.object}*\n🍽️ Alimentação no Além: *${result.food}*\n🧿 Destino: *${result.destiny}*\n\n⚠️ *OCORRÊNCIA*\n${result.event}\n\n⚖️ *VEREDITO*\n_${result.verdict}_\n\n🕯️ ${result.phrase}\n🔐 Assinatura: ${result.signature}`;
}

export const JULGAMENTO_RECENTES = new Map();

const JULGAMENTO_ACUSACOES = [
  "existir no grupo sem autorização do além",
  "visualizar e responder três horas depois",
  "mandar \"kkkk\" sem achar graça",
  "prometer que já vai e continuar online",
  "sumir justamente quando precisam de você",
  "usar figurinha como argumento jurídico",
  "ler o menu e ainda perguntar qual comando existe",
  "falar \"é rapidinho\" e criar um problema de 40 minutos",
  "chegar atrasado até em conversas assombradas",
  "acumular mensagens não respondidas",
  "perturbar o sossego do purgatório",
  "ter opinião sem apresentar evidência",
  "culpar o lag por uma decisão claramente duvidosa",
  "invocar o Fantasminha sem motivo plausível",
  "confundir bom senso com item opcional",
  "agir como se o grupo fosse propriedade particular",
  "cometer excesso de confiança sem licença",
  "tentar vencer uma discussão usando \"confia\"",
  "ser suspeito por motivos que o tribunal prefere não comentar",
  "existir com uma quantidade preocupante de audácia"
];

const JULGAMENTO_PROVAS = [
  "uma figurinha apreendida no local",
  "três mensagens fora de contexto",
  "um áudio de origem duvidosa",
  "um print que convenientemente não mostra o começo",
  "o silêncio suspeito do réu",
  "um \"kkkk\" considerado tecnicamente insuficiente",
  "um histórico de decisões questionáveis",
  "uma testemunha que só apareceu para causar",
  "um recibo espiritual sem validade jurídica",
  "uma mensagem apagada antes da perícia",
  "um emoji encontrado perto da cena",
  "a própria cara de quem sabe que fez besteira",
  "um relato do porteiro do limbo",
  "evidências que o estagiário do Além perdeu",
  "um documento carimbado com \"depois eu vejo\"",
  "um silêncio de sete segundos, considerado extremamente suspeito",
  "um boato com convicção demais",
  "uma testemunha fantasma que ninguém consegue localizar",
  "um pacote de provas com metade faltando",
  "uma anotação do Ceifador: \"não confio nesse indivíduo\""
];

const JULGAMENTO_TESTEMUNHAS = [
  "o Fantasma do Grupo",
  "o porteiro do Purgatório",
  "um esqueleto que estava passando",
  "a testemunha que chegou só pelo entretenimento",
  "o estagiário do Tribunal do Além",
  "uma alma que prefere permanecer anônima",
  "o Ceifador, que pediu intervalo",
  "um vizinho espiritual extremamente fofoqueiro",
  "o barqueiro do rio",
  "uma entidade que claramente não leu o processo",
  "a única pessoa que disse ter visto tudo",
  "uma testemunha que mudou de versão quatro vezes",
  "o protocolo eletrônico do além",
  "ninguém — e isso deixou o tribunal desconfortável"
];

const JULGAMENTO_ARGUMENTOS = [
  "A defesa declarou que foi sem querer. O tribunal não acreditou nem por educação.",
  "A defesa alegou inocência. O juiz pediu uma versão menos criativa.",
  "O réu ficou em silêncio. Finalmente uma decisão sensata.",
  "A defesa apresentou um argumento tão fraco que quase pediu desculpas sozinho.",
  "O advogado pediu clemência. O sistema respondeu com um emoji de caixão.",
  "A defesa alegou falta de provas. As provas levantaram a mão.",
  "O réu tentou explicar. O tribunal decidiu preservar a própria sanidade.",
  "A defesa disse \"confia em mim\". O tribunal marcou isso como agravante.",
  "O argumento foi considerado tecnicamente possível e espiritualmente vergonhoso.",
  "A defesa apresentou contexto. O contexto piorou tudo.",
  "O réu tentou jogar a culpa no lag. O lag apresentou contraprova.",
  "A defesa pediu mais tempo. O Além respondeu: \"eternidade já não basta?\"",
  "O advogado pediu uma pausa. O Purgatório chamou isso de férias.",
  "A defesa trouxe lógica. Infelizmente, ela não veio assinada.",
  "O tribunal ouviu atentamente. Depois fingiu que não ouviu."
];

const JULGAMENTO_CIRCUNSTANCIAS = [
  "A favor do réu: ninguém morreu de tédio durante a audiência.",
  "A favor do réu: ele apareceu para o próprio julgamento.",
  "Contra o réu: apareceu atrasado.",
  "Contra o réu: tentou negociar com o juiz usando figurinha.",
  "A favor do réu: pelo menos não tentou fugir pelo portal.",
  "Contra o réu: chamou a acusação de \"drama\".",
  "A favor do réu: demonstrou uma quantidade mínima de arrependimento.",
  "Contra o réu: o arrependimento parecia estar no modo econômico.",
  "Contra o réu: a própria testemunha pediu distância.",
  "A favor do réu: o tribunal estava com preguiça de preencher papelada.",
  "Contra o réu: o histórico de mensagens não ajudou absolutamente nada.",
  "A favor do réu: o Fantasminha precisava encerrar o expediente."
];

const JULGAMENTO_DECISOES = [
  "ABSOLVIDO POR FALTA DE PACIÊNCIA DO TRIBUNAL",
  "CULPADO POR EXCESSO DE AUDÁCIA",
  "INOCENTE — MAS SOB OBSERVAÇÃO ESPIRITUAL",
  "CULPADO EM PRIMEIRO GRAU DE CHATICE",
  "ENVIADO PARA O LIMBO ADMINISTRATIVO",
  "ABSOLVIDO POR UM ERRO NO CARIMBO",
  "CULPADO, MAS COM DIREITO A UMA FIGURINHA DE RECURSO",
  "ARQUIVADO POR FALTA DE VERGONHA ALHEIA",
  "CONDENADO À LIBERDADE VIGIADA PELO FANTASMINHA",
  "INOCENTE POR UM DETALHE TÉCNICO RIDÍCULO",
  "CULPADO. O TRIBUNAL NEM PRECISOU TERMINAR O CAFÉ",
  "SENTENÇA ADIADA POR INCOMPETÊNCIA DO JUIZ",
  "ABSOLVIDO POR SER UM CASO TRISTEMENTE ENGRAÇADO",
  "CULPADO PORQUE ATÉ O SILÊNCIO DELE É SUSPEITO",
  "MANDADO PARA REVISÃO DO DEPARTAMENTO DE ALMAS PROBLEMÁTICAS",
  "LIMBO. NEM CULPADO NEM INOCENTE: SÓ COMPLICADO"
];

const JULGAMENTO_PENAS = [
  "3 horas lendo o menu do bot",
  "7 minutos ouvindo o Ceifador reclamar",
  "serviço comunitário no Purgatório",
  "ficar responsável pela fila das almas",
  "organizar as cadeiras do tribunal até a eternidade acabar",
  "pedir desculpas formalmente ao próprio bom senso",
  "ser fiscal de figurinha por um turno",
  "explicar para um fantasma por que o Wi-Fi caiu",
  "cumprir pena escrevendo \"eu deveria ter pensado antes\"",
  "ficar proibido de usar \"confia\" como argumento",
  "auxiliar o barqueiro sem perguntar quando chega",
  "fazer plantão no Portal do Além",
  "revisar 300 mensagens antigas em busca de contexto",
  "ser promovido a estagiário do caos",
  "ficar em liberdade, mas com o Fantasminha de olho",
  "nenhuma pena: o julgamento já foi sofrimento suficiente"
];

const JULGAMENTO_TROCADILHOS = [
  "A sentença foi pesada. Felizmente o réu já estava acostumado com peso espiritual.",
  "O caso foi encerrado. O problema continua aberto.",
  "O tribunal deu o veredito. A alma deu um \"ué\".",
  "Foi julgado pelo Além. Pelo bom senso, o processo ainda está em andamento.",
  "O réu apelou. O portal respondeu: \"não existe botão voltar\".",
  "A sessão acabou. A vergonha ficou para cumprir pena.",
  "O processo foi arquivado porque até o arquivo pediu demissão.",
  "O Fantasminha bateu o martelo. Era uma figurinha, mas funcionou.",
  "A justiça é cega. Neste tribunal, ela também é meio distraída.",
  "Caso encerrado. Favor recolher sua dignidade na saída.",
  "O julgamento terminou sem mortos. O departamento de estatísticas está decepcionado.",
  "A sentença foi publicada. O réu fingiu que não recebeu.",
  "O Além decidiu. Reclamações devem ser encaminhadas ao além do Além.",
  "A audiência acabou. O Fantasminha ainda está procurando quem marcou isso na agenda.",
  "O tribunal chegou a uma conclusão. Não pergunte como.",
  "A justiça venceu. Por pouco, mas venceu."
];

const JULGAMENTO_FECHAMENTOS = [
  "⚖️ Processo encerrado. Próximo réu, por favor não seja tão trabalhoso.",
  "👻 Fantasminha: \"Pronto. Agora suma daqui antes que eu reabra o processo.\"",
  "🪦 Carimbo oficial: APROVADO PELO CAOS JUDICIAL.",
  "🌑 O véu fechou. A burocracia, infelizmente, ficou aberta.",
  "👻 O tribunal agradece sua colaboração e lamenta profundamente sua existência jurídica.",
  "⚰️ Audiência encerrada. O martelo sobreviveu. Por enquanto.",
  "🕯️ A alma pode seguir. A ficha criminal espiritual fica com a gente.",
  "🌌 Fim do julgamento. Não houve apelação porque ninguém descobriu onde fica a porta.",
  "👻 Caso encerrado. O Fantasminha não assume responsabilidade por futuras decisões ruins.",
  "⚖️ Sentença emitida. O bom senso foi dispensado por justa causa."
];
function julgamentoPick(arr, key, used) {
  const recent = JULGAMENTO_RECENTES.get(key) || [];
  const pool = arr.filter(x => !used.has(x) && !recent.includes(x));
  return rand(pool.length ? pool : arr.filter(x => !used.has(x)));
}

function julgamentoRemember(key, values) {
  const old = JULGAMENTO_RECENTES.get(key) || [];
  const merged = [...old, ...values].slice(-24);
  JULGAMENTO_RECENTES.set(key, merged);
  if (JULGAMENTO_RECENTES.size > 500) {
    const first = JULGAMENTO_RECENTES.keys().next().value;
    JULGAMENTO_RECENTES.delete(first);
  }
}

export function julgamentoMsg(nome) {
  const n = String(nome || "o réu").trim().slice(0, 80) || "o réu";
  const key = n.toLowerCase();
  const used = new Set();
  const acusacao = julgamentoPick(JULGAMENTO_ACUSACOES, key, used); used.add(acusacao);
  const prova = julgamentoPick(JULGAMENTO_PROVAS, key, used); used.add(prova);
  const testemunha = julgamentoPick(JULGAMENTO_TESTEMUNHAS, key, used); used.add(testemunha);
  const argumento = julgamentoPick(JULGAMENTO_ARGUMENTOS, key, used); used.add(argumento);
  const circunstancia = julgamentoPick(JULGAMENTO_CIRCUNSTANCIAS, key, used); used.add(circunstancia);
  const decisao = julgamentoPick(JULGAMENTO_DECISOES, key, used); used.add(decisao);
  const pena = julgamentoPick(JULGAMENTO_PENAS, key, used); used.add(pena);
  const trocadilho = julgamentoPick(JULGAMENTO_TROCADILHOS, key, used); used.add(trocadilho);
  const fechamento = julgamentoPick(JULGAMENTO_FECHAMENTOS, key, used);
  julgamentoRemember(key, [acusacao, prova, testemunha, argumento, decisao, pena, trocadilho, fechamento]);

  return `╭━━━「 ⚖️ JULGAMENTO 」━━━╮
┃
┃ 👤 Réu: *${n}*
┃
┃ 📜 Acusação
┃ ${acusacao}
┃
┃ 🔎 Prova principal
┃ ${prova}
┃
┃ 👻 Testemunha
┃ ${testemunha}
┃
┃ 🗣️ Defesa
┃ ${argumento}
┃
┃ ⚠️ Circunstância
┃ ${circunstancia}
┃
┃ ⚖️ SENTENÇA
┃ *${decisao}*
┃
┃ 🪦 Pena
┃ ${pena}
┃
╰━━━━━━━━━━━━━━━━━━━━╯

💀 ${trocadilho}

${fechamento}`;
}

export function perfilAlem(nome) {
  const n = nome || "Viajante";
  return `🌑 *Perfil do Além — ${n}*\n\n• Classe: ${rand(["Espectro", "Sombra", "Barqueiro trainee", "Alma inquieta", "Ceifador júnior"])}\n• Nível no limbo: ${1 + (pct(n) % 50)}\n• Karma: ${pct(n + "k") - 50}\n• Inventário: vela, ironia, 1 ticket de fila\n• Status: *consciente do meme*`;
}

export function sombraMsg(nome) {
  return `🌑 *Sombra de ${nome || "você"}*\n\nEla não copia seus passos.\nCopia suas desculpas.\n\nHoje a sombra está: *${rand(["silenciosa", "julgando", "rindo baixo", "adiantada"])}*.`;
}

export function destinoMsg() {
  const d = ["fila preferencial no limbo", "dia de silêncio etéreo", "sorte cinza", "convite pro purgatório VIP", "reset de karma parcial", "missão: ler o menudono"];
  return `🔮 *Destino puxado do véu*\n\n→ *${rand(d)}*`;
}

export function pecadoMsg() { return `😈 *Pecado do dia*\n\n${rand(PEADOS)}\n\nMulta: 1 reflexão.`; }
export function virtudeMsg() { return `✨ *Virtude residual*\n\n${rand(VIRTUDES)}\n\nBônus: +1 paciência.`; }

export function karmaMsg(nome) {
  const k = pct(nome || "x") - 50;
  return `☯️ *Karma — ${nome || "você"}*\n\nSaldo: *${k > 0 ? "+" : ""}${k}*\n${k >= 20 ? "Fila rápida." : k <= -20 ? "Volta pro fim." : "Fila normal. Como sempre."}`;
}

export function horarioVeu() {
  const now = new Date();
  const br = now.toLocaleString("pt-BR", { timeZone: "America/Sao_Paulo" });
  return `🕯️ *Horário do Véu*\n\nLado de cá (BR): *${br}*\nLado de lá: *sempre tarde demais*\nTurno do Fantasminha: *eterno*`;
}

export function contagemAlmas(n) {
  const q = typeof n === "number" ? n : Math.floor(Math.random() * 200) + 12;
  return `👻 *Contagem de almas no grupo*\n\nDetectadas: *${q}*\n(incluindo quem só visualiza)`;
}

export function shipAlem(a, b) {
  const s = pct((a || "") + (b || ""));
  return `💀 *Ship do Cemitério*\n\n${a || "Alma A"} ⚰️ ${b || "Alma B"}\nCompatibilidade etérea: *${s}%*\n${s > 70 ? "Casamento no limbo liberado." : s > 40 ? "Amizade de túmulo." : "Melhor cada um no seu caixão."}`;
}

export function percentualAlma(nome) {
  return `📊 *Percentual de alma — ${nome || "você"}*\n\n• Humanidade: ${pct(nome)}%\n• Fantasma: ${100 - pct(nome)}%\n• Ironia: ${pct(nome + "i")}%`;
}

export function verdadeAlem() {
  const v = ["Você já abriu o menu e fingiu que leu.", "Alguém no grupo deve um sticker.", "O dono viu e não comentou.", "Seu último áudio tinha eco do além.", "O bot não esquece. Só finge."];
  return `🕯️ *Verdade do além*\n\n${rand(v)}`;
}

export function desafioAlem() {
  const d = ["Mande um elogio sarcástico.", "Fique 5 min sem sticker.", "Leia o menualem inteiro.", "Admita um pecado digital.", "Marque alguém e peça perdão teatral."];
  return `⚔️ *Desafio do purgatório*\n\n${rand(d)}\n\nFalhou? Volta pra fila.`;
}

export function conselhoAlem() {
  const c = ["Menos impulso, mais véu.", "Se não cabe num comando, cabe num silêncio.", "Ironia resolve 60%. O resto é sticker.", "Durma. O limbo não paga hora extra.", "Respeite o prefixo. Ele respeita você."];
  return `📜 *Conselho do Fantasminha*\n\n${c[Math.floor(Math.random() * c.length)]}`;
}

export function diarioAlem() {
  return `📓 *Diário do Além — entrada aleatória*\n\nHoje a fila andou ${Math.floor(Math.random() * 3)} passos.\nO ceifador pediu café.\nNinguém levou.\nFim do registro.`;
}

// ——— JOGOS ———

export function startForca(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  const palavra = rand(PALAVRAS_FORCA);
  data.forca = {
    palavra,
    masked: palavra.replace(/./g, "▮"),
    tentativas: 6,
    usadas: [],
    by: user
  };
  saveGameState(file, data);
  return `🎲 *Forca do Além*\n\nPalavra: \`${data.forca.masked}\`\nTentativas: ${data.forca.tentativas}\n\nChute: \`letra <x>\` ou use o comando com a letra.\nTema: submundo.`;
}

export function playForca(baseDir, groupId, letra, user = null, userName = null) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.forca) return "Nenhuma forca ativa. Use *forcaalem*.";
  const L = (letra || "").toLowerCase().replace(/[^a-zà-ú]/gi, "").slice(0, 1);
  if (!L) return "Envie uma letra. Ex: letra a";
  const g = data.forca;
  if (g.usadas.includes(L)) return `Letra *${L}* já usada.
\`${g.masked}\` — tentativas: ${g.tentativas}`;
  g.usadas.push(L);
  const name = userName || (user ? String(user).split("@")[0] : "alma");
  if (g.palavra.includes(L)) {
    g.masked = g.palavra.split("").map((ch) => (g.usadas.includes(ch) ? ch : "▮")).join("");
    if (user) addScore(baseDir, groupId, user, name, 2, "forca");
    if (g.masked === g.palavra) {
      if (user) addScore(baseDir, groupId, user, name, 13, "forca");
      delete data.forca;
      saveGameState(file, data);
      return `✨ *Acertou!* A palavra era *${g.palavra}*.
*${name}* +15 pts

${rankText(baseDir, groupId, 5)}`;
    }
    saveGameState(file, data);
    return `✅ *${L}* existe. (+2 pts)
\`${g.masked}\`
Tentativas: ${g.tentativas}`;
  }
  g.tentativas--;
  if (g.tentativas <= 0) {
    const w = g.palavra;
    delete data.forca;
    saveGameState(file, data);
    return `💀 *Enforcado no limbo.*
A palavra era *${w}*.`;
  }
  saveGameState(file, data);
  return `❌ *${L}* não tem.
\`${g.masked}\`
Tentativas: ${g.tentativas}`;
}

export function startQuiz(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  const item = rand(QUIZ);
  data.quiz = { ...item };
  saveGameState(file, data);
  return `❓ *Quiz do Além*\n\n${item.q}\n\nResponda com: *respostaquiz <texto>*`;
}

export function answerQuiz(baseDir, groupId, ans, user = null, userName = null) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.quiz) return "Nenhum quiz ativo. Use *quizalem*.";
  const answers = data.quiz.a || [];
  const ok = answers.some((a) => (ans || "").toLowerCase().includes(a));
  delete data.quiz;
  saveGameState(file, data);
  if (ok) {
    const name = userName || (user ? String(user).split("@")[0] : "alma");
    if (user) addScore(baseDir, groupId, user, name, 10, "quiz");
    return `✅ *Correto.* O véu aprova.
*${name}* +10 pts

${rankText(baseDir, groupId, 5)}`;
  }
  return `❌ *Errado.* O além ri baixo.
Respostas válidas: ${answers.join(", ") || "segredo"}`;
}

export function roletaAlem(baseDir = null, groupId = null, user = null, userName = null) {
  const slots = [
    { t: "💀 alma perdida", pts: -5 },
    { t: "🕯️ vela extra", pts: 5 },
    { t: "⛓️ +1 fila", pts: -2 },
    { t: "👻 fantasma aliado", pts: 8 },
    { t: "🌑 nada (clássico)", pts: 0 },
    { t: "✨ karma +10", pts: 10 },
    { t: "⚰️ reset parcial", pts: -8 }
  ];
  const pick = rand(slots);
  let extra = "";
  if (baseDir && groupId && user && pick.pts !== 0) {
    const name = userName || String(user).split("@")[0];
    addScore(baseDir, groupId, user, name, pick.pts, "roleta");
    extra = "\n\n" + rankText(baseDir, groupId, 5);
  }
  return `🎰 *Roleta da Alma*\n\n→ *${pick.t}*\nPontos: *${pick.pts > 0 ? "+" : ""}${pick.pts}*${extra}`;
}

export function batalhaAlmas(a, b) {
  const pa = pct(a || "a");
  const pb = pct(b || "b");
  const vencedor = pa >= pb ? (a || "Alma A") : (b || "Alma B");
  return `⚔️ *Batalha de Almas*\n\n${a || "Alma A"} (${pa}) vs ${b || "Alma B"} (${pb})\n\nVencedor etéreo: *${vencedor}*\nO perdedor volta pra fila com dignidade duvidosa.`;
}

export function caminhoVeu(escolha) {
  const map = {
    esquerda: "Você acha um corredor de ecos. +1 mistério, -1 certeza.",
    direita: "Porta do purgatório. Fila andou 2 metros. Parabéns?",
    frente: "O véu se abre. É só o menu de novo. Ainda assim, avanço.",
    tras: "Voltar não é opção. O chão sumiu."
  };
  const e = (escolha || "").toLowerCase();
  if (!map[e]) return `🛤️ *Caminho do Véu*\n\nEscolha: *esquerda*, *direita*, *frente* ou *tras*\nEx: caminhoveu frente`;
  return `🛤️ *Caminho do Véu — ${e}*\n\n${map[e]}`;
}

export function memoriaFantasma() {
  const simb = ["👻", "💀", "🕯️", "⛓️", "🌑", "⚰️"];
  const seq = [rand(simb), rand(simb), rand(simb), rand(simb)];
  return `🧠 *Memória Fantasma*\n\nSequência (decore e repita no chat):\n${seq.join(" ")}\n\n_O além não confere. Sua consciência sim._`;
}

export function anagramaAlma() {
  const palavra = rand(PALAVRAS_FORCA);
  const mist = palavra.split("").sort(() => Math.random() - 0.5).join("");
  return `🔤 *Anagrama da Alma*\n\nDesembaralhe: *${mist}*\n\n(Tema: além. Resposta no coração — ou no quiz.)`;
}

export function cacaAlma() {
  const grid = "F A N T A S M A\nP U R G A T O R\nL I M B O X Y Z\nS O M B R A Q W\nC E I F A D O R";
  return `🔎 *Caça-Alma*\n\n\`\`\`\n${grid}\n\`\`\`\nAche: FANTASMA, LIMBO, SOMBRA, CEIFADOR, PURGATOR (quase).`;
}

export function juizFinal(opcao) {
  const o = (opcao || "").toLowerCase();
  if (!["culpado", "inocente", "limbo"].includes(o)) {
    return `⚖️ *Juiz Final*\nVote: *culpado*, *inocente* ou *limbo*\nEx: juizfinal limbo`;
  }
  return `⚖️ *Urna do Submundo*\n\nSeu voto: *${o}*\nComputado nas sombras.\nResultado oficial: *${rand(["empate eterno", "limbo vence", "adiado", "carimbado"])}*`;
}

export function torreLimbo(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.torre) data.torre = {};
  const u = user || "anon";
  data.torre[u] = (data.torre[u] || 0) + 1;
  const andar = data.torre[u];
  saveGameState(file, data);
  const eventos = ["degrau range", "eco responde", "vela apaga", "fila atravessa", "nada acontece (pior)"];
  return `🗼 *Torre do Limbo*\n\n${u.split("@")[0]} subiu para o andar *${andar}*.\nEvento: ${rand(eventos)}\n\nContinue com *torrelimbo* para subir de novo.`;
}

export function topAlmasFake() {
  return `🏆 *Top Almas (simbólico)*\n\n1. Quem lê o menu\n2. Quem usa prefixo certo\n3. Quem não spamma\n4. O dono\n5. O Fantasminha (fora de competição)`;
}



export function batalhaDesafiar(baseDir, groupId, challenger, challengerName, targetId, targetName) {
  if (!targetId) return "⚔️ Use: *batalhaalmas @user* — alvo aceita com *aceitarbatalha*.";
  const { file, data } = loadGameState(baseDir, groupId);
  data.batalha = { from: challenger, fromName: challengerName || String(challenger).split("@")[0], to: targetId, toName: targetName || String(targetId).split("@")[0], at: Date.now() };
  saveGameState(file, data);
  return `⚔️ *Desafio*\n*${data.batalha.fromName}* vs *${data.batalha.toName}*\nAceitar: *aceitarbatalha* | Recusar: *recusarbatalha*`;
}

export function batalhaAceitar(baseDir, groupId, user) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.batalha) return "Nenhum desafio ativo.";
  const a = pct(data.batalha.from + Date.now());
  const b = pct(data.batalha.to + Date.now() + 7);
  const winA = a >= b;
  const winner = winA ? data.batalha.from : data.batalha.to;
  const winnerName = winA ? data.batalha.fromName : data.batalha.toName;
  addScore(baseDir, groupId, winner, winnerName, 12, "batalha");
  const msg = `⚔️ *Batalha*\\n${data.batalha.fromName} (${a}) vs ${data.batalha.toName} (${b})\n🏆 *${winnerName}* +12 pts\n\n${rankText(baseDir, groupId, 5)}`;
  delete data.batalha;
  saveGameState(file, data);
  return msg;
}

export function batalhaRecusar(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.batalha) return "Nenhum desafio ativo.";
  delete data.batalha;
  saveGameState(file, data);
  return "🏳️ Desafio recusado.";
}

export function startMemoria(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  const simb = ["👻", "💀", "🕯️", "⛓️", "🌑", "⚰️"];
  const seq = [rand(simb), rand(simb), rand(simb), rand(simb)];
  data.memoria = { seq, seqStr: seq.join(" ") };
  saveGameState(file, data);
  return `🧠 *Memória Fantasma*\\n\\n${seq.join(" ")}\\n\\nRepita: *respostamemoria 👻 💀 ...* (+8 pts)`;
}

export function answerMemoria(baseDir, groupId, ans, user, userName) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.memoria) return "Use *memoriafantasma* primeiro.";
  const clean = (ans || "").replace(/\\s+/g, " ").trim();
  const ok = clean === data.memoria.seqStr || clean.replace(/ /g, "") === data.memoria.seq.join("");
  delete data.memoria;
  saveGameState(file, data);
  if (ok && user) {
    const name = userName || String(user).split("@")[0];
    addScore(baseDir, groupId, user, name, 8, "memoria");
    return `✅ *${name}* +8 pts\n\n${rankText(baseDir, groupId, 5)}`;
  }
  return ok ? "✅ Correto!" : "❌ Sequência errada.";
}

export function juizStart(baseDir, groupId, alvo) {
  const { file, data } = loadGameState(baseDir, groupId);
  data.juiz = { alvo: alvo || "réu anônimo", votos: {} };
  saveGameState(file, data);
  return `⚖️ *Julgamento* — réu: *${data.juiz.alvo}*\\nVote: *juizfinal culpado|inocente|limbo*\\nEncerre: *encerrarjuiz*`;
}

export function juizVotar(baseDir, groupId, opcao, user, userName) {
  const { file, data } = loadGameState(baseDir, groupId);
  const o = (opcao || "").toLowerCase();
  if (!data.juiz) return juizStart(baseDir, groupId, "réu misterioso");
  if (!["culpado", "inocente", "limbo"].includes(o)) return "Vote: culpado, inocente ou limbo";
  data.juiz.votos[String(user)] = { voto: o, name: userName || String(user).split("@")[0] };
  saveGameState(file, data);
  return `🗳️ Voto *${o}* registrado. Total: ${Object.keys(data.juiz.votos).length}. Encerre: *encerrarjuiz*`;
}

export function juizEncerrar(baseDir, groupId) {
  const { file, data } = loadGameState(baseDir, groupId);
  if (!data.juiz) return "Nenhuma sessão ativa.";
  const counts = { culpado: 0, inocente: 0, limbo: 0 };
  for (const v of Object.values(data.juiz.votos)) counts[v.voto] = (counts[v.voto] || 0) + 1;
  const winner = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
  const alvo = data.juiz.alvo;
  const total = Object.keys(data.juiz.votos).length;
  delete data.juiz;
  saveGameState(file, data);
  return `⚖️ *Encerrado* — réu *${alvo}* | votos ${total}\\nCulpado ${counts.culpado} | Inocente ${counts.inocente} | Limbo ${counts.limbo}\\nVeredito: *${winner[0]}*`;
}

export function menuInfoHeader({ botName, userName, cargo, ownerName, device }) {
  return caixa({ titulo: 'Infos do bot', icone: '🩸', linhas: [
    `▸ ${smallCaps('bot')}: ${botName || "Fantasminha"}`,
    `▸ ${smallCaps('usuario')}: ${userName || "Viajante"}`,
    `▸ ${smallCaps('cargo')}: ${cargo || "Membro"}`,
    ...(device ? [`▸ ${smallCaps('dispositivo')}: ${device}`] : []),
    `▸ ${smallCaps('dono')}: ${ownerName || "Jota"}`
  ], category: 'sistema', tipo: 'info', command: 'menu-info-header' });
}

export function errMsg(detail) {
  return caixa({ titulo: 'Erro', icone: '🩸', linhas: [detail || 'Tente de novo.'], rodape: pickFrase('erro', Math.random, 'extra:erro'), category: 'sistema', tipo: 'erro', command: 'extra:erro' });
}

export function cmdNotFoundMsg(prefix, cmd) {
  const p = prefix || "×";
  const cm = cmd || "?";
  return caixa({ titulo: 'Comando perdido', icone: '🕯️', linhas: [`▸ \`${p}${cm}\` não existe neste plano.`, `▸ Tente \`${p}menu\``], rodape: pickFrase('erro', Math.random, `extra:comando:${cm}`), category: 'sistema', tipo: 'erro', command: `extra:comando:${cm}` });
}

export function statusBotDetailed({ nomebot, prefix, uptimeSec, nodeVersion }) {
  const h = Math.floor(uptimeSec / 3600);
  const m = Math.floor((uptimeSec % 3600) / 60);
  const mem = process.memoryUsage();
  const mb = (n) => (n / 1024 / 1024).toFixed(1);
  return `👻 *Status Fantasminha*\n\n• Bot: *${nomebot}*\n• Prefixo: *${prefix}*\n• Uptime: *${h}h ${m}m*\n• Node: *${nodeVersion}*\n• RAM: *${mb(mem.heapUsed)} MB*\n• Tema: além / purgatório`;
}

export function backupConfig(configPath, backupDir) {
  ensureDir(backupDir + "/x");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const dest = path.join(backupDir, `config_${stamp}.json`);
  fs.copyFileSync(configPath, dest);
  return dest;
}

export default {
  fraseAlem, statusAlem, oraculo, veuMsg, purgatorioMsg, submundoMsg, cemiterioMsg, ecoMsg,
  almaMsg, julgamentoMsg, perfilAlem, sombraMsg, destinoMsg, pecadoMsg, virtudeMsg, karmaMsg,
  horarioVeu, contagemAlmas, shipAlem, percentualAlma, verdadeAlem, desafioAlem, conselhoAlem, diarioAlem,
  startForca, playForca, startQuiz, answerQuiz, roletaAlem, batalhaAlmas, caminhoVeu, memoriaFantasma,
  anagramaAlma, cacaAlma, juizFinal, torreLimbo, topAlmasFake, placarAlem,
  batalhaDesafiar, batalhaAceitar, batalhaRecusar, startMemoria, answerMemoria,
  juizStart, juizVotar, juizEncerrar, menuInfoHeader, errMsg, cmdNotFoundMsg,
  statusBotDetailed, backupConfig
};
