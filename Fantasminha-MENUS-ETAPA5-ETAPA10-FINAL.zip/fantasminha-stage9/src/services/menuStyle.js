import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../database/store.js';

const COLLECTION = 'menu_style';
const DEFAULT_STYLE = 'carrossel';
const VALID_STYLES = new Set(['carrossel', 'botao', 'lista']);

function normalizeStyle(value) {
  const v = String(value ?? '').trim().toLowerCase();
  if (v === 'novo') return 'carrossel';
  if (v === 'antigo' || v === 'botão') return 'botao';
  if (v === 'texto') return 'lista';
  return VALID_STYLES.has(v) ? v : null;
}

function actorOf(by) {
  if (by && typeof by === 'object') return { actor: by.sender || by.actor || null, group: by.from || by.group || null };
  return { actor: by || null, group: null };
}

function defaults() { return { global: null, groups: {}, lockedGroups: {}, updatedAt: 0 }; }

function readState() {
  const raw = readCollection(COLLECTION, defaults());
  return {
    ...defaults(),
    ...raw,
    groups: raw?.groups && typeof raw.groups === 'object' ? raw.groups : {},
    lockedGroups: raw?.lockedGroups && typeof raw.lockedGroups === 'object' ? raw.lockedGroups : {}
  };
}

function envStyle(env = process.env) { return normalizeStyle(env?.MENU_PRINCIPAL_ESTILO) || DEFAULT_STYLE; }

async function writeAudit(action, by, details = {}) {
  const { actor, group } = actorOf(by);
  await updateCollection('audit', d => {
    d.events ||= [];
    d.events.push({ id: `AUD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`, at: Date.now(), action, actor, group, details });
    if (d.events.length > 5000) d.events.splice(0, d.events.length - 5000);
    return d;
  }, { events: [] });
}

export function getMenuStyleFor({ groupId = null, env = process.env } = {}) {
  const state = readState();
  const groupStyle = groupId ? normalizeStyle(state.groups?.[groupId]) : null;
  if (groupStyle) return groupStyle;
  const globalStyle = normalizeStyle(state.global);
  if (globalStyle) return globalStyle;
  return envStyle(env);
}

export function getMenuStyleSource({ groupId = null, env = process.env } = {}) {
  const state = readState();
  if (groupId && normalizeStyle(state.groups?.[groupId])) return 'grupo';
  if (normalizeStyle(state.global)) return 'dono';
  return normalizeStyle(env?.MENU_PRINCIPAL_ESTILO) ? 'ambiente' : 'padrao';
}

export async function setGlobalStyle(style, by) {
  const nextStyle = normalizeStyle(style);
  if (!nextStyle) throw new Error('Estilo inválido. Use carrossel, botao ou lista.');
  const before = readState().global;
  await updateCollection(COLLECTION, state => ({ ...defaults(), ...state, global: nextStyle, updatedAt: Date.now() }), defaults());
  await writeAudit('MENU_STYLE_GLOBAL_CHANGED', by, { oldValue: normalizeStyle(before), newValue: nextStyle });
  return { oldValue: normalizeStyle(before), newValue: nextStyle };
}

export async function clearGlobalStyle(by) {
  const before = readState().global;
  await updateCollection(COLLECTION, state => ({ ...defaults(), ...state, global: null, updatedAt: Date.now() }), defaults());
  await writeAudit('MENU_STYLE_GLOBAL_CLEARED', by, { oldValue: normalizeStyle(before), newValue: null });
  return { oldValue: normalizeStyle(before), newValue: null };
}

export async function setGroupStyle(groupId, style, by) {
  const id = String(groupId || '').trim();
  const nextStyle = normalizeStyle(style);
  if (!id) throw new Error('Grupo inválido.');
  if (!nextStyle) throw new Error('Estilo inválido. Use carrossel, botao ou lista.');
  const before = normalizeStyle(readState().groups?.[id]);
  await updateCollection(COLLECTION, state => {
    const next = { ...defaults(), ...state, groups: { ...(state.groups || {}) } };
    next.groups[id] = nextStyle;
    next.updatedAt = Date.now();
    return next;
  }, defaults());
  await writeAudit('MENU_STYLE_GROUP_CHANGED', by, { oldValue: before, newValue: nextStyle, groupId: id });
  return { oldValue: before, newValue: nextStyle };
}

export async function clearGroupStyle(groupId, by) {
  const id = String(groupId || '').trim();
  if (!id) throw new Error('Grupo inválido.');
  const before = normalizeStyle(readState().groups?.[id]);
  await updateCollection(COLLECTION, state => {
    const next = { ...defaults(), ...state, groups: { ...(state.groups || {}) } };
    delete next.groups[id];
    next.updatedAt = Date.now();
    return next;
  }, defaults());
  await writeAudit('MENU_STYLE_GROUP_CLEARED', by, { oldValue: before, newValue: null, groupId: id });
  return { oldValue: before, newValue: null };
}

export async function applyLocalStyle(changes, by, details = {}) {
  const list = Array.isArray(changes) ? changes.filter(x => x?.groupId) : [];
  if (!list.length) throw new Error('Nenhum grupo selecionado.');
  const nextStyle = normalizeStyle(list[0].style);
  if (!nextStyle || list.some(x => normalizeStyle(x.style) !== nextStyle)) throw new Error('Estilo inválido.');
  const stateBefore = readState();
  const auditGroups = list.map(x => ({
    id: String(x.groupId), name: String(x.name || x.groupId), before: normalizeStyle(stateBefore.groups?.[x.groupId]) || getMenuStyleFor({ groupId: x.groupId }), after: nextStyle, trancado: Boolean(x.locked)
  }));
  await updateCollection(COLLECTION, state => {
    const next = { ...defaults(), ...state, groups: { ...(state.groups || {}) }, lockedGroups: { ...(state.lockedGroups || {}) } };
    for (const item of list) {
      const id = String(item.groupId);
      next.groups[id] = nextStyle;
      if (item.locked) next.lockedGroups[id] = true;
      else delete next.lockedGroups[id];
    }
    next.updatedAt = Date.now();
    return next;
  }, defaults());
  await writeAudit('MENU_STYLE_DEFINED', by, { scope: 'local', newStyle: nextStyle, groups: auditGroups, ...details });
  return { style: nextStyle, groups: auditGroups };
}

export async function applyGlobalStyle(style, groups, by, details = {}) {
  const nextStyle = normalizeStyle(style);
  if (!nextStyle) throw new Error('Estilo inválido.');
  const stateBefore = readState();
  const selected = Array.isArray(groups) ? groups : [];
  const auditGroups = selected.map(x => ({
    id: String(x.id || x.groupId), name: String(x.name || x.id || x.groupId), before: normalizeStyle(stateBefore.groups?.[x.id || x.groupId]) || getMenuStyleFor({ groupId: x.id || x.groupId }), after: nextStyle, trancado: Boolean(stateBefore.lockedGroups?.[x.id || x.groupId])
  }));
  await updateCollection(COLLECTION, state => {
    const next = { ...defaults(), ...state, global: nextStyle, groups: { ...(state.groups || {}) }, lockedGroups: { ...(state.lockedGroups || {}) } };
    for (const item of selected) {
      const id = String(item.id || item.groupId);
      if (!next.lockedGroups[id]) delete next.groups[id];
    }
    next.updatedAt = Date.now();
    return next;
  }, defaults());
  await writeAudit('MENU_STYLE_DEFINED', by, { scope: 'global', newStyle: nextStyle, groups: auditGroups, ...details });
  return { style: nextStyle, groups: auditGroups, affected: auditGroups.filter(x => !x.trancado), locked: auditGroups.filter(x => x.trancado) };
}

export function isGroupLocked(groupId) { return !!readState().lockedGroups?.[String(groupId || '').trim()]; }

export function getSnapshot({ env = process.env } = {}) {
  const state = readState();
  const groups = Object.fromEntries(Object.entries(state.groups).filter(([, value]) => normalizeStyle(value)));
  return {
    global: normalizeStyle(state.global),
    globalSource: normalizeStyle(state.global) ? 'dono' : (normalizeStyle(env?.MENU_PRINCIPAL_ESTILO) ? 'ambiente' : 'padrao'),
    groups,
    lockedGroups: Object.keys(state.lockedGroups).filter(id => state.lockedGroups[id]),
    groupCount: Object.keys(groups).length,
    envStyle: envStyle(env),
    defaultStyle: DEFAULT_STYLE
  };
}

export function normalizeMenuStyle(value) { return normalizeStyle(value); }
export const MENU_STYLES = Object.freeze(['carrossel', 'botao', 'lista']);

export default { getMenuStyleFor, getMenuStyleSource, setGlobalStyle, clearGlobalStyle, setGroupStyle, clearGroupStyle, applyLocalStyle, applyGlobalStyle, isGroupLocked, getSnapshot, normalizeMenuStyle };
