import crypto from 'node:crypto';
import sharp from '../../dados/src/utils/safeSharp.js';

const CACHE_TTL = 30 * 60 * 1000;
const CACHE_MAX = 500;
const MAX_TEXT = 500;
const MAX_LINES = 10;
const MAX_LINE_CHARS = 42;
const WINDOW_MS = 60_000;
const MAX_PER_ACTOR = 8;
const MAX_GLOBAL = 80;
const cache = new Map();
const inflight = new Map();
const buckets = new Map();

const COLORS = new Set(['white','black','red','green','blue','yellow','purple','pink','orange','gray','grey','transparent']);
const HEX = /^#?(?:[0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i;

function cleanText(value) {
  let s = String(value ?? '').replace(/\u0000/g, '').replace(/\r\n?/g, '\n').trim();
  if (!s) throw new Error('O texto é obrigatório.');
  if (s.length > MAX_TEXT) throw new Error(`O texto deve ter no máximo ${MAX_TEXT} caracteres.`);
  return s;
}
function color(value, fallback) {
  const s = String(value ?? '').trim().toLowerCase();
  if (!s) return fallback;
  if (COLORS.has(s)) return s === 'grey' ? 'gray' : s;
  if (HEX.test(s)) return `#${s.replace(/^#/, '')}`;
  throw new Error('Cor inválida. Use um nome simples ou hexadecimal (#RGB/#RRGGBB).');
}
function blurValue(value) {
  if (value === '' || value == null) return 0;
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0 || n > 20) throw new Error('Blur deve ficar entre 0 e 20.');
  return Math.round(n);
}
function graphemes(s) {
  if (typeof Intl?.Segmenter === 'function') return [...new Intl.Segmenter('pt-BR', { granularity: 'grapheme' }).segment(s)].map(x => x.segment);
  return [...s];
}
function wrapLine(input) {
  const words = input.trim().split(/\s+/).filter(Boolean);
  const out = [];
  let line = '';
  for (const word of words) {
    const parts = graphemes(word);
    if (parts.length > MAX_LINE_CHARS) {
      if (line) { out.push(line); line = ''; }
      for (let i = 0; i < parts.length; i += MAX_LINE_CHARS) out.push(parts.slice(i, i + MAX_LINE_CHARS).join(''));
      continue;
    }
    const next = line ? `${line} ${word}` : word;
    if (graphemes(next).length <= MAX_LINE_CHARS) line = next;
    else { if (line) out.push(line); line = word; }
  }
  if (line) out.push(line);
  return out;
}
function wrap(text) {
  const lines = text.split('\n').flatMap(wrapLine);
  if (lines.length > MAX_LINES) throw new Error(`O texto ultrapassa o limite de ${MAX_LINES} linhas.`);
  return lines;
}
function esc(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;'); }
function cacheGet(key) { const x = cache.get(key); if (!x) return null; if (Date.now() - x.at > CACHE_TTL) { cache.delete(key); return null; } return x.buffer; }
function cacheSet(key, buffer) { if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value); cache.set(key, { at: Date.now(), buffer }); }
function admit(actor = 'global') {
  const now = Date.now();
  for (const [k, v] of buckets) { v.times = v.times.filter(t => now - t < WINDOW_MS); if (!v.times.length) buckets.delete(k); }
  const key = String(actor || 'global');
  const user = buckets.get(key) || { times: [] };
  if (user.times.length >= MAX_PER_ACTOR) throw new Error('⏳ Limite temporário do Brat atingido. Aguarde um minuto.');
  const global = buckets.get('__global__') || { times: [] };
  if (global.times.length >= MAX_GLOBAL) throw new Error('⏳ O gerador Brat está ocupado. Tente novamente em instantes.');
  user.times.push(now); global.times.push(now); buckets.set(key, user); buckets.set('__global__', global);
}
function keyOf(text, bg, fg, blur) { return crypto.createHash('sha256').update(JSON.stringify([text,bg,fg,blur])).digest('hex'); }

export async function generateBrat({ text, background='white', textColor='black', blur=0, actor='global' } = {}) {
  const value = cleanText(text);
  const bg = color(background, 'white');
  const fg = color(textColor, 'black');
  const blurN = blurValue(blur);
  const lines = wrap(value);
  const key = keyOf(value,bg,fg,blurN);
  const cached = cacheGet(key);
  if (cached) return { ok:true, buffer:cached, cached:true, mime:'image/webp', sha256:key, lines:lines.length };
  admit(actor);
  if (inflight.has(key)) return { ok:true, ...(await inflight.get(key)), deduped:true };
  const job = (async () => {
    const size = 1080;
    const maxFont = lines.length <= 2 ? 104 : lines.length <= 4 ? 88 : lines.length <= 7 ? 72 : 60;
    const lineGap = Math.round(maxFont * 1.08);
    const total = lineGap * lines.length;
    const startY = (size - total) / 2 + maxFont * 0.78;
    const tspans = lines.map((line,i) => `<text x="540" y="${Math.round(startY+i*lineGap)}" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="${maxFont}" font-weight="700" fill="${esc(fg)}">${esc(line)}</text>`).join('');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}"><rect width="100%" height="100%" fill="${esc(bg)}"/>${tspans}</svg>`;
    let image = sharp(Buffer.from(svg), { failOn: 'error' });
    if (blurN) image = image.blur(blurN);
    const buffer = await image.webp({ quality: 92, effort: 4 }).toBuffer();
    cacheSet(key, buffer);
    return { buffer, mime:'image/webp', sha256:key, lines:lines.length, cached:false };
  })();
  inflight.set(key, job);
  try { return { ok:true, ...(await job) }; }
  finally { inflight.delete(key); }
}

export function bratHealth() { return { cache:cache.size, inflight:inflight.size, actors:buckets.size, limits:{maxText:MAX_TEXT,maxLines:MAX_LINES,maxLineChars:MAX_LINE_CHARS,perMinute:MAX_PER_ACTOR,globalPerMinute:MAX_GLOBAL} }; }
export default { generateBrat, bratHealth };
