/** Compatibilidade histórica: operações RPG agora são canônicas em rpgService.js. */
export * from './rpgService.js';
import rpg from './rpgService.js';
export default rpg;
