import { normalizeMenuStyle } from './menuStyle.js';

export const FLOW_TTL_MS = 3 * 60 * 1000;

export function normalizeFlowText(value) {
  return String(value ?? '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

export function parseStyleInput(value) {
  const v = normalizeFlowText(value);
  if (v === '1') return 'carrossel';
  if (v === '2') return 'lista';
  if (v === '3') return 'botao';
  return normalizeMenuStyle(v);
}

function messageForStyle() {
  return 'Qual estilo de menu você quer usar?\n1 - carrossel (cartões com botão)\n2 - lista (texto com os comandos)\n3 - botão (sem comandos, só o botão)\nDigite o número ou escreva o nome. (cancelar para sair)';
}

function styleLabel(style) {
  return style === 'botao' ? 'botão' : style;
}

function groupCountLabel(count) {
  const n = Number(count) || 0;
  return `${n} ${n === 1 ? 'grupo' : 'grupos'}`;
}

function affectedGroupLabel(count) {
  const n = Number(count) || 0;
  return `${groupCountLabel(n)} ${n === 1 ? 'será afetado' : 'serão afetados'}`;
}

function lockedStatusLabel(count) {
  const n = Number(count) || 0;
  return n === 1 ? '1 trancado permanece como está' : `${n} trancados permanecem como estão`;
}

function messageForScope(style) {
  return `Estilo *${styleLabel(style)}* escolhido. Onde aplicar? 1 - global (todos os grupos) · 2 - local (grupos que eu escolher). Digite o número ou escreva global/local.`;
}

function parseScope(value) {
  const v = normalizeFlowText(value);
  if (v === '1' || v === 'global') return 'global';
  if (v === '2' || v === 'local') return 'local';
  return null;
}

function parseYesNo(value) {
  const v = normalizeFlowText(value);
  if (['1', 'sim', 's'].includes(v)) return true;
  if (['2', 'nao', 'n'].includes(v)) return false;
  return null;
}

function parseConfirm(value) {
  const v = normalizeFlowText(value);
  if (['1', 'sim', 'confirmar', 'confirma'].includes(v)) return true;
  if (['2', 'nao', 'cancelar', 'cancela'].includes(v)) return false;
  return null;
}

export function parseGroupSelection(input, count) {
  const raw = normalizeFlowText(input);
  if (!raw) return { numbers: [], invalid: [] };
  if (raw === 'todos') return { numbers: Array.from({ length: count }, (_, i) => i + 1), invalid: [] };
  const tokens = raw.replace(/,/g, ' ').split(/\s+/).filter(Boolean);
  const numbers = new Set();
  const invalid = [];
  for (const token of tokens) {
    const range = token.match(/^(\d+)-(\d+)$/);
    if (range) {
      const a = Number(range[1]); const b = Number(range[2]);
      if (a > b || a < 1 || b > count) { invalid.push(token); continue; }
      for (let n = a; n <= b; n++) numbers.add(n);
      continue;
    }
    if (/^\d+$/.test(token)) {
      const n = Number(token);
      if (n >= 1 && n <= count) numbers.add(n); else invalid.push(token);
      continue;
    }
    invalid.push(token);
  }
  return { numbers: [...numbers].sort((a, b) => a - b), invalid };
}

function groupListMessage(groups) {
  const lines = ['Escolha os grupos.'];
  groups.forEach((g, i) => {
    const n = i + 1;
    const total = Number.isFinite(Number(g.size)) ? Number(g.size) : (Array.isArray(g.participants) ? g.participants.length : '?');
    lines.push(`${n}. ${g.name} · ${total} membros · ${styleLabel(g.style)} (${g.source}) ${g.locked ? '🔒' : ''}`.trim());
  });
  lines.push('Digite os números, ex.: 1, 3, 5, 7 (também aceito 1-5 e todos).');
  return lines.join('\n');
}

export function createFlowController({ now = () => Date.now(), ttlMs = FLOW_TTL_MS } = {}) {
  const states = new Map();
  const keyOf = (sender, chat) => `${String(sender || '').trim().toLowerCase()}::${String(chat || '').trim().toLowerCase()}`;
  const valid = state => state && now() - state.updatedAt <= ttlMs;
  const touch = state => ({ ...state, updatedAt: now() });
  const start = (sender, chat, styleInput = null) => {
    const key = keyOf(sender, chat);
    const style = styleInput == null ? null : parseStyleInput(styleInput);
    const state = style ? { step: 'scope', style, updatedAt: now() } : { step: 'style', updatedAt: now() };
    states.set(key, state);
    return { state, messages: [style ? messageForScope(style) : messageForStyle()], effects: [] };
  };
  const cancel = (sender, chat) => { states.delete(keyOf(sender, chat)); return { cancelled: true }; };
  const get = (sender, chat) => {
    const key = keyOf(sender, chat); const state = states.get(key);
    if (!state) return null;
    if (!valid(state)) { states.delete(key); return null; }
    return state;
  };
  const peek = (sender, chat) => {
    const state = states.get(keyOf(sender, chat));
    if (!state) return { active: false, expired: false, state: null };
    return { active: true, expired: !valid(state), state };
  };
  const consume = (sender, chat, text, context = {}) => {
    const key = keyOf(sender, chat);
    let state = states.get(key);
    if (!state) return { handled: false };
    if (!valid(state)) { states.delete(key); return { handled: true, expired: true, messages: ['⏱️ Este fluxo expirou. Use ×definirmenu para começar de novo.'], effects: [] }; }
    const input = String(text ?? '').trim();
    if (normalizeFlowText(input) === 'cancelar') { states.delete(key); return { handled: true, cancelled: true, messages: ['❌ Fluxo cancelado.'], effects: [] }; }

    if (state.step === 'style') {
      const style = parseStyleInput(input);
      if (!style) return { handled: true, state, messages: [messageForStyle(), 'Dica: use 1, 2, 3, carrossel, lista ou botão.'], effects: [] };
      state = touch({ step: 'scope', style }); states.set(key, state);
      return { handled: true, state, messages: [messageForScope(style)], effects: [] };
    }
    if (state.step === 'scope') {
      const scope = parseScope(input);
      if (!scope) return { handled: true, state, messages: [messageForScope(state.style), 'Dica: use 1 para global ou 2 para local.'], effects: [] };
      if (scope === 'global') {
        const groups = Array.isArray(context.groups) ? context.groups : [];
        const affected = groups.filter(g => !g.locked).length;
        const locked = groups.filter(g => g.locked).length;
        state = touch({ step: 'confirmGlobal', style: state.style, groups }); states.set(key, state);
        return { handled: true, state, messages: [`Confirme: estilo *${styleLabel(state.style)}* no global. ${affectedGroupLabel(affected)}; ${lockedStatusLabel(locked)}. 1 - confirmar · 2 - cancelar (ou escreva confirmar/cancelar).`], effects: [] };
      }
      state = touch({ step: 'groups', style: state.style, groups: Array.isArray(context.groups) ? context.groups : [] }); states.set(key, state);
      return { handled: true, state, messages: [groupListMessage(state.groups)], effects: [] };
    }
    if (state.step === 'groups') {
      const parsed = parseGroupSelection(input, state.groups.length);
      if (!parsed.numbers.length || parsed.invalid.length) {
        const invalid = parsed.invalid.length ? `Números inválidos: ${parsed.invalid.join(', ')}.\n` : '';
        return { handled: true, state, messages: [`${invalid}${groupListMessage(state.groups)}`], effects: [] };
      }
      const selected = parsed.numbers.map(n => ({ ...state.groups[n - 1], number: n })).filter(Boolean);
      state = touch({ step: 'lock', style: state.style, groups: state.groups, selected }); states.set(key, state);
      return { handled: true, state, messages: ['Trancar os grupos selecionados? 1 - sim (o global NÃO altera esses grupos) · 2 - não (o global pode alterá-los).'], effects: [] };
    }
    if (state.step === 'lock') {
      const locked = parseYesNo(input);
      if (locked === null) return { handled: true, state, messages: ['Trancar os grupos selecionados? 1 - sim (o global NÃO altera esses grupos) · 2 - não (o global pode alterá-los).', 'Dica: use 1/sim ou 2/não.'], effects: [] };
      const names = state.selected.map(g => g.name).join(', ');
      state = touch({ step: 'confirmLocal', style: state.style, groups: state.groups, selected: state.selected, locked }); states.set(key, state);
      return { handled: true, state, messages: [`Confirme: estilo *${styleLabel(state.style)}* em ${groupCountLabel(state.selected.length)}: ${names}. Trancados: ${locked ? 'sim' : 'não'}. 1 - confirmar · 2 - cancelar (ou escreva confirmar/cancelar).`], effects: [] };
    }
    if (state.step === 'confirmLocal') {
      const confirm = parseConfirm(input);
      if (confirm === null) return { handled: true, state, messages: [`Confirme: estilo *${styleLabel(state.style)}* em ${groupCountLabel(state.selected.length)}. Trancados: ${state.locked ? 'sim' : 'não'}. 1 - confirmar · 2 - cancelar (ou escreva confirmar/cancelar).`], effects: [] };
      states.delete(key);
      if (!confirm) return { handled: true, cancelled: true, messages: ['❌ Alteração cancelada.'], effects: [] };
      return { handled: true, messages: [], effects: [{ type: 'DEFINE_LOCAL', style: state.style, locked: state.locked, selected: state.selected }] };
    }
    if (state.step === 'confirmGlobal') {
      const confirm = parseConfirm(input);
      if (confirm === null) return { handled: true, state, messages: [`Confirme: estilo *${styleLabel(state.style)}*. 1 - confirmar · 2 - cancelar (ou escreva confirmar/cancelar).`], effects: [] };
      states.delete(key);
      if (!confirm) return { handled: true, cancelled: true, messages: ['❌ Alteração cancelada.'], effects: [] };
      return { handled: true, messages: [], effects: [{ type: 'DEFINE_GLOBAL', style: state.style, groups: state.groups }] };
    }
    return { handled: true, messages: ['❌ Fluxo inválido. Use ×definirmenu para começar.'], effects: [] };
  };
  return { start, cancel, get, peek, consume, keyOf };
}

export function flowPrompt() { return messageForStyle(); }
export default { createFlowController, parseStyleInput, parseGroupSelection, normalizeFlowText, FLOW_TTL_MS };
