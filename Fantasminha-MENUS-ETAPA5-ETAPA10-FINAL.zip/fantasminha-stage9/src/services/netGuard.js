import dns from 'node:dns/promises';
import net from 'node:net';
let axiosClient;
async function getAxios(){ if (!axiosClient) axiosClient=(await import('axios')).default; return axiosClient; }

const DEFAULT_MAX_REDIRECTS = 3;
const DEFAULT_TIMEOUT = 15_000;
const DEFAULT_MAX_BYTES = 80 * 1024 * 1024;

function blockedError(message = 'URL não permitida por segurança.') {
  const err = new Error(message);
  err.userMessage = `🌑 ${message}`;
  return err;
}

function ipv4ToInt(ip) {
  return ip.split('.').reduce((n, oct) => (n * 256) + Number(oct), 0) >>> 0;
}
function in4(ip, base, mask) {
  const a = ipv4ToInt(ip), b = ipv4ToInt(base);
  return ((a & mask) >>> 0) === ((b & mask) >>> 0);
}
function isBlockedIp(address) {
  const version = net.isIP(address);
  if (version === 4) {
    return in4(address,'0.0.0.0',0xff000000) ||
      in4(address,'10.0.0.0',0xff000000) ||
      in4(address,'100.64.0.0',0xffc00000) ||
      in4(address,'127.0.0.0',0xff000000) ||
      in4(address,'169.254.0.0',0xffff0000) ||
      in4(address,'172.16.0.0',0xfff00000) ||
      in4(address,'192.0.0.0',0xffffff00) ||
      in4(address,'192.168.0.0',0xffff0000) ||
      in4(address,'224.0.0.0',0xf0000000);
  }
  if (version !== 6) return true;
  const v = address.toLowerCase().split('%')[0];
  if (v === '::1' || v === '::' || v.startsWith('ff')) return true;
  if (v.startsWith('fe80:') || v.startsWith('fc') || v.startsWith('fd')) return true;
  const mapped = v.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/i);
  return !!mapped && isBlockedIp(mapped[1]);
}
function validateHost(host) {
  const h = String(host || '').toLowerCase().replace(/\.$/,'');
  if (!h || h === 'localhost' || h.endsWith('.local') || h.endsWith('.internal')) throw blockedError('O endereço informado não é permitido.');
}
async function resolveAll(host, lookup = dns.lookup) {
  const normalizedHost = String(host || '').replace(/^\[|\]$/g,'');
  if (net.isIP(normalizedHost)) return [{ address: normalizedHost }];
  validateHost(normalizedHost);
  try { return await lookup(normalizedHost, { all: true, verbatim: true }); }
  catch { throw blockedError('Não foi possível validar o endereço informado.'); }
}
export async function assertPublicHttpUrl(input, options = {}) {
  let u;
  try { u = new URL(String(input)); } catch { throw blockedError('URL inválida.'); }
  if (!['http:','https:'].includes(u.protocol)) throw blockedError('Somente URLs HTTP/HTTPS são permitidas.');
  if (u.username || u.password) throw blockedError('URLs com usuário ou senha não são permitidas.');
  if (u.port && !['80','443'].includes(u.port)) throw blockedError('A porta informada não é permitida.');
  validateHost(u.hostname);
  const addresses = await resolveAll(u.hostname, options.lookup || dns.lookup);
  if (!addresses.length || addresses.some(x => isBlockedIp(x.address))) throw blockedError('O endereço informado aponta para uma rede privada ou reservada.');
  return u;
}
async function safeRequest(method, input, opts = {}) {
  let current = String(input);
  const maxRedirects = Math.min(DEFAULT_MAX_REDIRECTS, Math.max(0, Number(opts.maxRedirects ?? DEFAULT_MAX_REDIRECTS)));
  const timeout = Math.max(1000, Number(opts.timeout ?? DEFAULT_TIMEOUT));
  const maxBytes = Number(opts.maxContentLength ?? DEFAULT_MAX_BYTES);
  for (let hop=0; hop<=maxRedirects; hop++) {
    const u = await assertPublicHttpUrl(current, { lookup: opts.lookup });
    const client = opts.client || await getAxios();
    const { client: _client, lookup: _lookup, maxRedirects: _redirects, ...requestOpts } = opts;
    const response = await client.request({
      ...requestOpts, method, url: u.toString(), maxRedirects: 0, timeout,
      maxContentLength: maxBytes, maxBodyLength: Number(opts.maxBodyLength ?? maxBytes),
      validateStatus: () => true
    });
    if (response.status >= 300 && response.status < 400 && response.headers?.location) {
      if (hop === maxRedirects) throw blockedError('Número máximo de redirecionamentos excedido.');
      current = new URL(response.headers.location, u).toString();
      continue;
    }
    return response;
  }
  throw blockedError('Redirecionamento inválido.');
}
export const safeGet = (url, opts = {}) => safeRequest('GET', url, opts);
export const safeHead = (url, opts = {}) => safeRequest('HEAD', url, opts);
export const _netGuard = { isBlockedIp, resolveAll };
