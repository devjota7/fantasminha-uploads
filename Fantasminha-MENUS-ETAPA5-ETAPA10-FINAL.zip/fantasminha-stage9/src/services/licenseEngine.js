import commercial from './platformCommercial.js';
import { auditFind } from '../platform/audit/index.js';

export function get(groupId) { return commercial.getRental(groupId); }
export function status(groupId) { const r = commercial.getRental(groupId); return r || { plan: 'BASIC', state: 'ACTIVE', premium: false, active: false, expiresAt: null }; }
export function upsert({ groupId, plan = 'BASIC', state = 'ACTIVE', days = 30, features = [], actor = 'system' } = {}) {
  const current = commercial.getRental(groupId);
  if (plan === 'BASIC') { return current || { groupId, plan, state, features, premium: false, active: false, expiresAt: null }; }
  if (!current) {
    const key = commercial.createKey({ durationDays: days, actor });
    const result = commercial.activateKey(key.secret, groupId, actor, `license-upsert-${Date.now()}-${Math.random()}`);
    return { ...result.rental, licenseId: result.rental.rentalId, features };
  }
  const renewed = commercial.renewRental(groupId, days, actor);
  return { ...renewed.rental, licenseId: renewed.rental.rentalId, features };
}
export function trial(groupId, days = 7, actor = 'system') { const key = commercial.createKey({ durationDays: days, actor }); const r = commercial.activateKey(key.secret, groupId, actor, `trial-${Date.now()}-${Math.random()}`); return { ...r.rental, plan: 'TRIAL', licenseId: r.rental.rentalId }; }
export function renew(groupId, days = 30, actor = 'system') { const r = commercial.renewRental(groupId, days, actor); return { ...r.rental, licenseId: r.rental.rentalId }; }
export function setState(groupId, state, actor = 'system') { return commercial.setRentalState(groupId, state, actor); }
export function canUse(groupId, feature) { return commercial.canUse(groupId, feature); }
export function history(groupId) { return auditFind(e => !groupId || e.target === groupId || e.details?.groupId === groupId).filter(e => String(e.action || '').startsWith('RENTAL_')).map(e => ({ at:e.at, type:e.action, actor:e.actor, groupId:e.target, license:{ groupId:e.target, ...(e.after || {}) } })); }
export default { get, status, upsert, trial, renew, setState, canUse, history };
