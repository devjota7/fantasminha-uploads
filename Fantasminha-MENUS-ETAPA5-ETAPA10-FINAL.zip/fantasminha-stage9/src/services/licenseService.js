import commercial from './platformCommercial.js';
import { auditFind } from '../platform/audit/index.js';

function toLicense(rental) {
  if (!rental) return null;
  return {
    licenseId: rental.rentalId, rentalId: rental.rentalId, groupId: rental.groupId,
    clientId: rental.clientId ?? null, plan: rental.plan || 'PREMIUM', state: rental.state,
    active: rental.active === true, permanent: rental.permanent === true,
    issuedAt: rental.createdAt ?? null, createdAt: rental.createdAt ?? null, updatedAt: rental.updatedAt ?? null,
    expiresAt: rental.expiresAt ?? null, features: Array.isArray(rental.features) ? rental.features : [],
  };
}

function resolve(groupId) {
  const gid = String(groupId ?? '').trim();
  if (!gid) throw Object.assign(new Error('groupId obrigatório.'), { statusCode: 400 });
  const rental = commercial.getRental(gid);
  if (!rental) throw Object.assign(new Error('Licença não encontrada.'), { statusCode: 404 });
  return rental;
}

export function status(groupId) { return toLicense(groupId ? commercial.getRental(groupId) : null); }

export function evaluateLicenseState(actor = 'system') {
  const expired = commercial.evaluateCommercialLifecycle(actor);
  return { evaluatedAt: Date.now(), expiredGroups: expired, count: expired.length };
}

export function activateLicense(groupId, actor = 'owner') {
  const current = resolve(groupId);
  if (current.state === 'ACTIVE' && current.active) return toLicense(current);
  if (current.state === 'EXPIRED') throw Object.assign(new Error('Licença expirada deve ser renovada antes de ser ativada.'), { statusCode: 409 });
  if (current.state === 'CANCELLED' || current.state === 'REVOKED') throw Object.assign(new Error('Licença cancelada/revogada é terminal.'), { statusCode: 409 });
  return toLicense(commercial.setRentalState(current.groupId, 'ACTIVE', actor));
}

export function renewLicense(groupId, days = 30, actor = 'owner', operationId = null) {
  const current = resolve(groupId);
  if (current.state === 'CANCELLED' || current.state === 'REVOKED') throw Object.assign(new Error('Licença cancelada/revogada não pode ser renovada.'), { statusCode: 409 });
  return toLicense(commercial.renewRental(current.groupId, days, actor, operationId).rental);
}

export function suspendLicense(groupId, actor = 'owner') {
  const current = resolve(groupId);
  if (current.state === 'SUSPENDED') return toLicense(current);
  if (current.state === 'EXPIRED' || current.state === 'CANCELLED' || current.state === 'REVOKED') throw Object.assign(new Error('Licença não pode ser suspensa neste estado.'), { statusCode: 409 });
  return toLicense(commercial.setRentalState(current.groupId, 'SUSPENDED', actor));
}

export function resumeLicense(groupId, actor = 'owner') {
  const current = resolve(groupId);
  if (current.state === 'ACTIVE' && current.active) return toLicense(current);
  if (current.state !== 'SUSPENDED') throw Object.assign(new Error('Somente licença suspensa pode ser reativada.'), { statusCode: 409 });
  return toLicense(commercial.setRentalState(current.groupId, 'ACTIVE', actor));
}

export function expireLicense(groupId, actor = 'system') {
  const current = resolve(groupId);
  if (current.state === 'EXPIRED') return toLicense(current);
  if (current.permanent) throw Object.assign(new Error('Licença permanente não expira.'), { statusCode: 409 });
  return toLicense(commercial.setRentalState(current.groupId, 'EXPIRED', actor));
}

export function cancelLicense(groupId, actor = 'owner') {
  const current = resolve(groupId);
  if (current.state === 'CANCELLED') return toLicense(current);
  if (current.state === 'REVOKED') return toLicense(current);
  return toLicense(commercial.setRentalState(current.groupId, 'CANCELLED', actor));
}

export function history(groupId) {
  if (!groupId) return [];
  const gid = String(groupId).trim();
  return auditFind(e => e.scope === `group:${gid}` && String(e.action || '').match(/^(RENTAL_|LICENSE_)/))
    .map(e => ({ id:e.id, at:e.at, action:e.action, actor:e.actor, result:e.result, reason:e.reason, operationId:e.operationId, details:e.details }))
    .sort((a,b) => a.at - b.at);
}

export function list() { return commercial.listRentals().map(toLicense); }

export function commercialLifecycleIntegrity() {
  const base = commercial.commercialLifecycleIntegrity();
  return { ...base, checkedAt: Date.now() };
}

export default { status, evaluateLicenseState, activateLicense, renewLicense, suspendLicense, resumeLicense, expireLicense, cancelLicense, history, list, commercialLifecycleIntegrity };
