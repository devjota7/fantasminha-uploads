import { env } from '../../config/env.js';
import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import commercial from '../platformCommercial.js';
import { recordAudit } from '../../platform/audit/index.js';

const COLLECTION = 'provisioning';
const MAX_ID = 160;
const OP_TTL_MS = 7 * 86400000;
const STATES = new Set(['provisioning','starting','running','stopping','stopped','restarting','destroying','destroyed','failed','unknown']);

function clean(v) { return String(v ?? '').trim(); }
function operationId() { return `PROV-${crypto.randomUUID()}`; }
function baseDb() { return { version: 2, resources: {}, operations: {} }; }
function db() { const d = readCollection(COLLECTION, baseDb()); return { ...baseDb(), ...d, resources: d.resources || {}, operations: d.operations || {} }; }
function unavailableError(operation = null) {
  const error = new Error('Provisionamento indisponível: nenhum provider de infraestrutura está configurado.');
  error.statusCode = 503; error.code = 'PROVIDER_UNAVAILABLE';
  if (operation?.operationId) error.operationId = operation.operationId;
  return error;
}
function invalidState(state) { return !STATES.has(String(state)); }

// Etapa 22 deliberately keeps the system fail-closed because the audited environment
// contains no real infrastructure provider credentials/configuration. No fake IDs/IPs
// or simulated resources are ever returned.
export const provisioningProvider = Object.freeze({
  name: clean(env.PROVISIONING_PROVIDER) || 'unavailable',
  configured: false,
  async status() { return { available: false, provider: this.name, reason: 'no_provider_configured' }; },
  async create() { throw unavailableError(); },
  async start() { throw unavailableError(); },
  async stop() { throw unavailableError(); },
  async restart() { throw unavailableError(); },
  async destroy() { throw unavailableError(); },
  async getStatus() { return { available: false, provider: this.name, reason: 'no_provider_configured' }; },
  async getHealth() { return { available: false, provider: this.name, reason: 'no_provider_configured' }; },
  async health() { return this.getHealth(); }
});

function rentalFor(id) {
  const key = clean(id);
  if (!key || key.length > MAX_ID) throw Object.assign(new Error('Rental inválido.'), { statusCode: 400, code: 'INVALID_RENTAL_ID' });
  const rental = commercial.getRental(key) || commercial.listRentals().find(r => r.rentalId === key);
  if (!rental) throw Object.assign(new Error('Rental não encontrado.'), { statusCode: 404, code: 'RENTAL_NOT_FOUND' });
  return rental;
}

function eligibleRental(rental, action) {
  if (!rental.active) throw Object.assign(new Error('Licença/aluguel não está ativo.'), { statusCode: 409, code: 'LICENSE_INELIGIBLE', action });
}

function pruneOperations(d) {
  const cutoff = Date.now() - OP_TTL_MS;
  for (const [id, op] of Object.entries(d.operations)) {
    const at = Number(op.updatedAt || op.createdAt || 0);
    if (at && at < cutoff && ['success','failed','unavailable','destroyed'].includes(String(op.status))) delete d.operations[id];
  }
}

export function getProvisioning(rentalId) {
  const rental = rentalFor(rentalId);
  const d = db();
  const resource = d.resources[rental.rentalId] || null;
  const latest = listOperations(rental.rentalId)[0] || null;
  return {
    rentalId: rental.rentalId,
    clientId: rental.clientId ?? null,
    state: resource?.state || 'unknown',
    provider: provisioningProvider.name,
    available: provisioningProvider.configured,
    configured: provisioningProvider.configured,
    resource: resource ? { ...resource } : null,
    lastOperation: latest,
    providerStatus: { available: false, provider: provisioningProvider.name, reason: 'no_provider_configured' }
  };
}

async function recordOperation(rental, action, actor, requestId, state = 'pending') {
  const requested = clean(requestId);
  return updateCollection(COLLECTION, d => {
    pruneOperations(d);
    if (requested) {
      const existing = Object.values(d.operations).find(x => x.requestId === requested && x.rentalId === rental.rentalId && x.action === action);
      if (existing) return d;
    }
    const opId = operationId();
    d.operations[opId] = {
      operationId: opId, rentalId: rental.rentalId, action,
      instanceId: d.resources[rental.rentalId]?.instanceId || null,
      provider: provisioningProvider.name, status: state, state,
      requestId: requested || null, actor, createdAt: Date.now(), updatedAt: Date.now()
    };
    return d;
  }, baseDb());
}

async function getOrCreateOperation(rental, action, actor, requestId) {
  const requested = clean(requestId);
  let selected = null;
  await updateCollection(COLLECTION, d => {
    pruneOperations(d);
    if (requested) selected = Object.values(d.operations).find(x => x.requestId === requested && x.rentalId === rental.rentalId && x.action === action) || null;
    if (!selected) {
      const opId = operationId();
      selected = { operationId: opId, rentalId: rental.rentalId, action, instanceId: d.resources[rental.rentalId]?.instanceId || null, provider: provisioningProvider.name, status: 'pending', state: 'unknown', requestId: requested || null, actor, createdAt: Date.now(), updatedAt: Date.now() };
      d.operations[opId] = selected;
    }
    return d;
  }, baseDb());
  return selected;
}

async function failUnavailable(rental, action, actor = 'owner', requestId = null) {
  const op = await getOrCreateOperation(rental, action, actor, requestId);
  if (op.status !== 'unavailable') {
    await updateCollection(COLLECTION, d => {
      const current = d.operations[op.operationId] || op;
      current.status = 'unavailable'; current.state = 'UNAVAILABLE'; current.errorCode = 'PROVIDER_UNAVAILABLE'; current.error = 'no_provider_configured'; current.updatedAt = Date.now();
      d.operations[op.operationId] = current;
      return d;
    }, baseDb());
    await recordAudit({ actor, target: rental.rentalId, action: `PROVISIONING_${action.toUpperCase()}`, scope: 'provisioning', requestId, operationId: op.operationId, result: 'unavailable', details: { provider: provisioningProvider.name, reason: 'no_provider_configured' } });
  }
  throw unavailableError(op);
}

export async function provision(rentalId, actor = 'owner', requestId = null) {
  const rental = rentalFor(rentalId); eligibleRental(rental, 'provision');
  return failUnavailable(rental, 'provision', actor, requestId);
}
export async function start(rentalId, actor = 'owner', requestId = null) { const rental = rentalFor(rentalId); eligibleRental(rental, 'start'); return failUnavailable(rental, 'start', actor, requestId); }
export async function stop(rentalId, actor = 'owner', requestId = null) { const rental = rentalFor(rentalId); return failUnavailable(rental, 'stop', actor, requestId); }
export async function restart(rentalId, actor = 'owner', requestId = null) { const rental = rentalFor(rentalId); return failUnavailable(rental, 'restart', actor, requestId); }
export async function destroy(rentalId, actor = 'owner', requestId = null) { const rental = rentalFor(rentalId); return failUnavailable(rental, 'destroy', actor, requestId); }
export async function health(rentalId) { rentalFor(rentalId); return provisioningProvider.getHealth(); }
export async function reconcileProvisioning() {
  const d = db();
  if (!provisioningProvider.configured) return { available: false, provider: provisioningProvider.name, checked: 0, orphans: [], changed: 0, reason: 'no_provider_configured' };
  return { available: false, provider: provisioningProvider.name, checked: Object.keys(d.resources).length, orphans: [], changed: 0, reason: 'provider_adapter_not_configured' };
}
export function listOperations(rentalId = null) { const d = db(); const all = Object.values(d.operations); return (rentalId ? all.filter(x => x.rentalId === clean(rentalId)) : all).sort((a,b) => Number(b.createdAt)-Number(a.createdAt)); }
export function provisioningIntegrity() {
  const d = db(); const issues = [];
  for (const [rentalId, r] of Object.entries(d.resources)) {
    if (!rentalId || !r) issues.push({ type: 'INVALID_RESOURCE', rentalId });
    if (r.state && invalidState(r.state)) issues.push({ type: 'INVALID_RESOURCE_STATE', rentalId, state: r.state });
    if (!r.instanceId && r.state !== 'destroyed') issues.push({ type: 'RESOURCE_MISSING_INSTANCE_ID', rentalId });
  }
  return { ok: issues.length === 0, issues, checkedAt: Date.now() };
}

export default { provisioningProvider, getProvisioning, provision, start, stop, restart, destroy, health, listOperations, reconcileProvisioning, provisioningIntegrity };
