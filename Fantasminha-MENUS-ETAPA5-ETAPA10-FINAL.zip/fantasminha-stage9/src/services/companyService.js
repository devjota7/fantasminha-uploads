import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../database/store.js';
import { mutateAccount } from './economy.js';
const C='mega_companies', empty={byId:{},byOwner:{}};
const id=p=>`${p}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
export function getByOwner(owner){const d=readCollection(C,empty);return d.byId?.[d.byOwner?.[owner]]||null;}
export function get(idOrOwner){const d=readCollection(C,empty);return d.byId?.[idOrOwner]||d.byId?.[d.byOwner?.[idOrOwner]]||null;}
export async function create(owner,name,cost=100000){if(getByOwner(owner))throw new Error('Você já possui uma empresa.');const op=`company:create:${owner}:${Date.now()}`;let company;const result=await mutateAccount(owner,({account})=>{account.debit(cost);company={id:id('COS'),name:String(name).trim().slice(0,60),owner,capital:cost,level:1,revenue:0,employees:[],branches:0,createdAt:Date.now()};return {amount:-cost,company};},{reason:'company.create',operationId:op,extraSteps:[{collection:C,update:d=>{d.byId??={};d.byOwner??={};if(d.byOwner[owner])throw new Error('Você já possui uma empresa.');d.byId[company.id]=company;d.byOwner[owner]=company.id;return d;}}]});if(result?.duplicate)return getByOwner(owner);return company;}
// The economy debit is idempotent; company persistence is separately locked and keyed by the same operation identity.
export async function hire(owner,name,role='Assistente'){const co=getByOwner(owner);if(!co)throw new Error('Crie uma empresa.');if(co.capital<5000)throw new Error('Capital insuficiente.');co.capital-=5000;co.employees??=[];co.employees.push({id:id('NPC'),name:String(name).slice(0,30),role:String(role).slice(0,40),salary:500+co.employees.length*250,skill:1,morale:100});return updateCollection(C,d=>{d.byId[co.id]=co;return d;},empty).then(()=>co);}
export async function fire(owner,index){const co=getByOwner(owner);if(!co||!co.employees?.[index-1])throw new Error('NPC não encontrado.');const [e]=co.employees.splice(index-1,1);await updateCollection(C,d=>{d.byId[co.id]=co;return d;},empty);return e;}
export async function upgrade(owner,type){
 const co=getByOwner(owner);if(!co)throw new Error('Crie uma empresa.');
 const costs={nivel:25000*(co.level||1),filial:100000*((co.branches||0)+1),marketing:25000},cost=costs[type];
 if(!cost)throw new Error('Tipo de expansão inválido.');if((co.capital||0)<cost)throw new Error(`Capital insuficiente: ${cost.toLocaleString('pt-BR')} GC.`);
 co.capital-=cost;
 if(type==='nivel'){co.level=(co.level||1)+1;co.revenue=(co.revenue||0)+5000*co.level;}
 if(type==='filial'){co.branches=(co.branches||0)+1;co.revenue=(co.revenue||0)+15000;}
 if(type==='marketing')co.revenue=(co.revenue||0)+10000;
 co.updatedAt=Date.now();await updateCollection(C,d=>{d.byId[co.id]=co;return d;},empty);return co;
}
export async function train(owner,index){const co=getByOwner(owner),e=co?.employees?.[Number(index)-1];if(!e)throw new Error('NPC não encontrado.');const cost=5000+(e.skill||1)*2500;if((co.capital||0)<cost)throw new Error(`Treinamento custa ${cost.toLocaleString('pt-BR')} GC.`);co.capital-=cost;e.skill=(e.skill||1)+1;e.morale=Math.max(0,Math.min(100,(e.morale??100)+5));co.updatedAt=Date.now();await updateCollection(C,d=>{d.byId[co.id]=co;return d;},empty);return e;}
export async function promote(owner,index){const co=getByOwner(owner),e=co?.employees?.[Number(index)-1];if(!e)throw new Error('NPC não encontrado.');e.role=String(e.role||'Funcionário').startsWith('Sênior ')?e.role:`Sênior ${e.role||'Funcionário'}`;e.salary=Math.floor((e.salary||500)*1.35);e.skill=(e.skill||1)+1;co.updatedAt=Date.now();await updateCollection(C,d=>{d.byId[co.id]=co;return d;},empty);return e;}
export function payroll(owner){const co=getByOwner(owner);if(!co)throw new Error('Crie uma empresa.');return {company:co,total:(co.employees||[]).reduce((sum,e)=>sum+(Number(e.salary)||0),0),count:(co.employees||[]).length};}
export function ranking(limit=10){return Object.values(readCollection(C,empty).byId||{}).sort((a,b)=>(b.capital||0)-(a.capital||0)).slice(0,limit);}
export default {getByOwner,get,create,hire,fire,upgrade,train,promote,payroll,ranking};
