import crypto from 'node:crypto';
import { createCollectionRepository } from '../database/repositories/collectionRepository.js';

const COLLECTION = 'group_registry';
const repository = createCollectionRepository(COLLECTION, { byGroupId: {}, byFantId: {} });
const ID_RE = /^FANTGRUP-[A-Z0-9]{8,12}$/i;

function cleanName(name, fallback = 'Grupo') {
  const value = String(name || '').replace(/[\r\n]+/g, ' ').trim();
  return value.slice(0, 120) || fallback;
}
function normalizeGroupId(id) { return String(id || '').trim(); }
function normalizeFantId(id) { return String(id || '').trim().toUpperCase(); }
function clone(v) { return structuredClone(v); }
function makeId(existing) {
  for (let i = 0; i < 50; i++) {
    const bytes = crypto.randomBytes(6);
    const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let out = '';
    let n = BigInt('0x' + bytes.toString('hex'));
    for (let j = 0; j < 10; j++) { out += alphabet[Number(n % 32n)]; n /= 32n; }
    const id = `FANTGRUP-${out}`;
    if (!existing[id]) return id;
  }
  throw new Error('Não foi possível gerar um ID global de grupo único.');
}

export function isFantGroupId(value) { return ID_RE.test(String(value || '').trim()); }
export function read() {
  const data = repository.read();
  data.byGroupId ||= {};
  data.byFantId ||= {};
  return data;
}

export async function registerGroup({ groupId, name = '', status = 'active', botAdmin = null } = {}, now = Date.now()) {
  const externalId = normalizeGroupId(groupId);
  if (!externalId) throw new Error('ID real do grupo inválido.');
  let result;
  await repository.update(data => {
    data.byGroupId ||= {}; data.byFantId ||= {};
    const previous = data.byGroupId[externalId];
    const fantId = previous?.fantId || makeId(data.byFantId);
    const next = {
      fantId,
      groupId: externalId,
      name: cleanName(name, previous?.name || 'Grupo'),
      status: status || previous?.status || 'active',
      botAdmin: botAdmin == null ? (previous?.botAdmin ?? null) : !!botAdmin,
      createdAt: previous?.createdAt || now,
      updatedAt: now,
      lastSeenAt: now
    };
    data.byGroupId[externalId] = next;
    data.byFantId[fantId] = externalId;
    result = next;
    return data;
  });
  return clone(result);
}

export async function migrateLegacyGroupIds(groupIds = [], now = Date.now()) {
  const ids = [...new Set((Array.isArray(groupIds) ? groupIds : []).map(normalizeGroupId).filter(Boolean))];
  if (!ids.length) return [];
  const results = [];
  await repository.update(data => {
    data.byGroupId ||= {}; data.byFantId ||= {};
    for (const groupId of ids) {
      const previous = data.byGroupId[groupId];
      const fantId = previous?.fantId || makeId(data.byFantId);
      const next = {
        fantId,
        groupId,
        name: cleanName(previous?.name, 'Grupo'),
        status: previous?.status || 'unavailable',
        botAdmin: previous?.botAdmin ?? null,
        createdAt: previous?.createdAt || now,
        updatedAt: now,
        lastSeenAt: previous?.lastSeenAt || null
      };
      data.byGroupId[groupId] = next;
      data.byFantId[fantId] = groupId;
      results.push(next);
    }
    return data;
  });
  return results.map(clone);
}

export function auditIntegrity() {
  const data = read();
  const errors = [];
  const seenFant = new Set();
  for (const [groupId, record] of Object.entries(data.byGroupId)) {
    if (!record?.fantId || !isFantGroupId(record.fantId)) errors.push(`Registro inválido: ${groupId}`);
    if (seenFant.has(record?.fantId)) errors.push(`FANTGRUP duplicado: ${record.fantId}`);
    if (record?.fantId) seenFant.add(record.fantId);
    if (record?.fantId && data.byFantId[record.fantId] !== groupId) errors.push(`Índice inconsistente: ${record.fantId}`);
  }
  for (const [fantId, groupId] of Object.entries(data.byFantId)) {
    if (!data.byGroupId[groupId]) errors.push(`Índice órfão: ${fantId}`);
  }
  return { ok: errors.length === 0, errors, total: Object.keys(data.byGroupId).length };
}

export async function sync(groups = [], now = Date.now()) {
  if (!Array.isArray(groups)) return [];
  const seen = new Set();
  const results = [];
  await repository.update(data => {
    data.byGroupId ||= {}; data.byFantId ||= {};
    for (const raw of groups) {
      const groupId = normalizeGroupId(raw?.id);
      if (!groupId) continue;
      seen.add(groupId);
      const previous = data.byGroupId[groupId];
      const fantId = previous?.fantId || makeId(data.byFantId);
      const next = {
        fantId,
        groupId,
        name: cleanName(raw?.name || raw?.subject, previous?.name || 'Grupo'),
        status: 'active',
        botAdmin: raw?.botAdmin == null ? (previous?.botAdmin ?? null) : !!raw.botAdmin,
        createdAt: previous?.createdAt || now,
        updatedAt: now,
        lastSeenAt: now
      };
      data.byGroupId[groupId] = next;
      data.byFantId[fantId] = groupId;
      results.push(next);
    }
    for (const [groupId, record] of Object.entries(data.byGroupId)) {
      if (!seen.has(groupId) && record.status !== 'unavailable') {
        data.byGroupId[groupId] = { ...record, status: 'unavailable', botAdmin: false, updatedAt: now };
      }
    }
    return data;
  });
  return results.map(clone);
}

export function getByFantId(id) {
  const key = normalizeFantId(id);
  if (!isFantGroupId(key)) return null;
  const data = read();
  const groupId = data.byFantId[key];
  return groupId ? clone(data.byGroupId[groupId] || null) : null;
}
export function getByGroupId(groupId) {
  const data = read();
  return clone(data.byGroupId[normalizeGroupId(groupId)] || null);
}
export function list({ includeUnavailable = true } = {}) {
  const rows = Object.values(read().byGroupId).filter(x => includeUnavailable || x.status === 'active');
  return rows.sort((a, b) => String(a.name).localeCompare(String(b.name), 'pt-BR')).map(clone);
}
export function search(query) {
  const q = String(query || '').trim().toLocaleLowerCase('pt-BR');
  if (!q) return list();
  return list().filter(x => x.name.toLocaleLowerCase('pt-BR').includes(q) || x.fantId.toLocaleLowerCase().includes(q));
}
export default { isFantGroupId, read, registerGroup, migrateLegacyGroupIds, sync, auditIntegrity, getByFantId, getByGroupId, list, search };
