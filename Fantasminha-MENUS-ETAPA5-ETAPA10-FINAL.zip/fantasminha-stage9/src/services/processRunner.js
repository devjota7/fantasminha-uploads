import { spawn } from 'node:child_process';
import { registerShutdownHook } from '../core/lifecycle.js';

const DEFAULT_TIMEOUT_MS = Math.max(1000, Number(process.env.PROCESS_TIMEOUT_MS || 120000));
const MAX_ACTIVE = Math.max(1, Number(process.env.MEDIA_MAX_CONCURRENT_PROCESSES || 4));
const active = new Set();

function normalizeTimeout(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : DEFAULT_TIMEOUT_MS;
}

export function getActiveProcessCount() { return active.size; }

export async function runProcess(command, args = [], options = {}) {
  if (!Array.isArray(args)) throw new TypeError('process args deve ser array');
  if (active.size >= MAX_ACTIVE) throw new Error('limite de processos de mídia atingido');

  const timeoutMs = normalizeTimeout(options.timeout);
  const child = spawn(command, args.map(String), {
    cwd: options.cwd,
    env: options.env ? { ...process.env, ...options.env } : process.env,
    stdio: options.stdio || ['ignore', 'pipe', 'pipe'],
    shell: false,
    detached: false
  });
  active.add(child);

  return await new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    let settled = false;
    let timedOut = false;
    let timer;

    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      if (timer) clearTimeout(timer);
      active.delete(child);
      fn(value);
    };

    if (child.stdout) child.stdout.on('data', d => { stdout += d.toString(); });
    if (child.stderr) child.stderr.on('data', d => { stderr += d.toString(); });

    timer = setTimeout(() => {
      timedOut = true;
      try { child.kill('SIGTERM'); } catch {}
      setTimeout(() => {
        if (child.exitCode === null) {
          try { child.kill('SIGKILL'); } catch {}
        }
      }, Math.min(5000, timeoutMs));
    }, timeoutMs);

    child.once('error', error => finish(reject, Object.assign(error, { stdout, stderr })));
    child.once('close', (code, signal) => {
      if (timedOut) {
        return finish(reject, Object.assign(new Error(`processo ${command} excedeu ${timeoutMs}ms`), {
          code, signal, stdout, stderr, processTimeout: true
        }));
      }
      if (code === 0) return finish(resolve, { code, signal, stdout, stderr });
      finish(reject, Object.assign(new Error(`${command} terminou com código ${code ?? 'null'}${signal ? ` (${signal})` : ''}`), { code, signal, stdout, stderr }));
    });
  });
}

export async function killAllActiveProcesses() {
  const children = [...active];
  for (const child of children) {
    try { child.kill('SIGTERM'); } catch {}
  }
  if (!children.length) return;
  await new Promise(resolve => setTimeout(resolve, 250));
  for (const child of children) {
    try { if (child.exitCode === null) child.kill('SIGKILL'); } catch {}
  }
}

registerShutdownHook('process-runner', killAllActiveProcesses);

export default { runProcess, killAllActiveProcesses, getActiveProcessCount };
