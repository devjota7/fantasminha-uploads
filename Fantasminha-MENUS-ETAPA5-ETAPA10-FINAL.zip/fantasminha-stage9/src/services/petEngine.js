import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { getUser, readCollection, updateCollection, transactionCollections } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import * as economy from './economy.js';
import config from '../core/config.js';

export const PET_STORAGE_COLLECTION = 'pet_engine';
export const PET_STORAGE_VERSION = 2;
export const PET_SCOPE_GLOBAL = 'global';
export const MAX_PETS = 10;

const C = PET_STORAGE_COLLECTION;
const GLOBAL = PET_SCOPE_GLOBAL;

export const SPECIES = {
  lobo: { emoji: '🐺', rarity: 'comum', price: 3000, attack: 14, defense: 10, speed: 14, name: 'Lobo' },
  gato: { emoji: '🐈', rarity: 'comum', price: 2500, attack: 10, defense: 8, speed: 16, name: 'Gato' },
  coelho: { emoji: '🐇', rarity: 'comum', price: 2200, attack: 8, defense: 7, speed: 18, name: 'Coelho' },
  raposa: { emoji: '🦊', rarity: 'raro', price: 6500, attack: 17, defense: 12, speed: 19, name: 'Raposa' },
  aranha: { emoji: '🕷️', rarity: 'raro', price: 7000, attack: 20, defense: 13, speed: 15, name: 'Aranha' },
  coruja: { emoji: '🦉', rarity: 'raro', price: 7200, attack: 16, defense: 14, speed: 20, name: 'Coruja' },
  tigre: { emoji: '🐯', rarity: 'epico', price: 12000, attack: 28, defense: 22, speed: 18, name: 'Tigre' },
  aguia: { emoji: '🦅', rarity: 'epico', price: 12500, attack: 25, defense: 17, speed: 25, name: 'Águia' },
  dragao: { emoji: '🐉', rarity: 'lendario', price: 40000, attack: 45, defense: 35, speed: 24, name: 'Dragão' },
  fenix: { emoji: '🔥', rarity: 'lendario', price: 50000, attack: 42, defense: 32, speed: 30, name: 'Fênix' },
  espectro: { emoji: '👻', rarity: 'mistico', price: 75000, attack: 55, defense: 40, speed: 35, name: 'Espectro' }
};

const PERSONALITIES = ['brincalhão', 'curioso', 'calmo', 'aventureiro'];
const clamp = (n, a, b) => Math.max(a, Math.min(b, Number(n) || 0));
const pid = () => `PET-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
const key = (groupId, userId) => `${groupId || GLOBAL}::${userId}`;
const randomPersonality = () => PERSONALITIES[Math.floor(Math.random() * PERSONALITIES.length)];
const cloneJson = value => {
  if (value == null) return value;
  try { return JSON.parse(JSON.stringify(value)); } catch { return value; }
};

/**
 * Canonical pet storage contract.
 * All new writes must live under pet_engine and use this shape. Legacy-only
 * fields are retained intentionally until the migration phase is complete.
 */
function db() { return readCollection(C, { pets: {} }); }

export function normalizePet(raw = {}) {
  const speciesId = String(raw.speciesId || raw.species || raw.type || '').toLowerCase();
  const meta = SPECIES[speciesId] || {};
  const p = {
    id: raw.id || pid(),
    operationId: raw.operationId || null,
    speciesId,
    species: raw.species || meta.name || speciesId || 'Fantasma',
    emoji: raw.emoji || meta.emoji || '🐾',
    rarity: raw.rarity || meta.rarity || 'comum',
    name: String(raw.name || meta.name || 'Fantasma').slice(0, 30),
    personality: raw.personality || randomPersonality(),
    level: Math.max(1, Number(raw.level || 1)),
    xp: Number(raw.xp ?? raw.exp ?? 0) || 0,
    energy: clamp(raw.energy ?? 100, 0, 100),
    hunger: clamp(raw.hunger ?? 100, 0, 100),
    hygiene: clamp(raw.hygiene ?? 100, 0, 100),
    happiness: clamp(raw.happiness ?? raw.mood ?? 80, 0, 100),
    maxHp: Math.max(1, Number(raw.maxHp || 100)),
    health: 0,
    training: clamp(raw.training ?? 0, 0, 100),
    attack: Number(raw.attack ?? meta.attack ?? 10),
    defense: Number(raw.defense ?? meta.defense ?? 10),
    speed: Number(raw.speed ?? meta.speed ?? 10),
    wins: Number(raw.wins || 0),
    losses: Number(raw.losses || 0),
    age: Number(raw.age || 1),
    createdAt: Number(raw.createdAt || Date.now()),
    history: Array.isArray(raw.history) ? raw.history.slice(-100) : [],
    // Compatibility fields: preserved now, normalized/used later by the
    // controller and migration phases instead of being silently discarded.
    equipment: raw.equipment && typeof raw.equipment === 'object' ? cloneJson(raw.equipment) : {},
    evolutions: Number(raw.evolutions ?? raw.evolution ?? 0) || 0,
    element: raw.element ?? null,
    lastUpdate: raw.lastUpdate ?? null,
    legacySource: raw.legacySource ?? null,
    legacyUserId: raw.legacyUserId ?? null,
    legacyMigratedAt: raw.legacyMigratedAt ?? null,
    legacyData: raw.legacyData && typeof raw.legacyData === 'object' ? cloneJson(raw.legacyData) : null,
    storageVersion: PET_STORAGE_VERSION
  };
  p.health = clamp(raw.health ?? raw.hp ?? 100, 0, p.maxHp);
  return p;
}

function all(groupId, userId) {
  return Object.values(db().pets?.[key(groupId, userId)] || {}).map(normalizePet);
}

export function list(groupId, userId) { return all(groupId, userId); }
export function listGroup(groupId) { const prefix=`${groupId || GLOBAL}::`; const out=[]; for(const [k,arr] of Object.entries(db().pets||{})){ if(!k.startsWith(prefix)) continue; const userId=k.slice(prefix.length); for(const p of Object.values(arr||{})) out.push({userId,pet:normalizePet(p)}); } return out; }
export async function listAsync(groupId, userId) {
  if (groupId === GLOBAL || !groupId) await migrateLegacyGlobal(userId);
  return all(groupId || GLOBAL, userId);
}

function legacyDatabasePath() {
  return process.env.DATABASE_PATH || path.join(config.root, 'database');
}

function readLegacyEconomy() {
  const file = path.join(legacyDatabasePath(), 'economy.json');
  try {
    if (!fs.existsSync(file)) return { users: {} };
    const parsed = JSON.parse(fs.readFileSync(file, 'utf8'));
    return parsed && typeof parsed === 'object' ? parsed : { users: {} };
  } catch {
    return { users: {} };
  }
}

function stableLegacyId(userId, source, index, raw) {
  const seed = `${userId}|${source}|${index}|${JSON.stringify(raw || {})}`;
  const digest = crypto.createHash('sha1').update(seed).digest('hex').slice(0, 10).toUpperCase();
  return `LEGACY-${digest}`;
}

function normalizeLegacyPet(raw, userId, source, index) {
  const input = { ...(raw || {}) };
  if (!input.id) input.id = stableLegacyId(userId, source, index, raw);
  input.legacySource = source;
  input.legacyUserId = userId;
  input.legacyMigratedAt = Date.now();
  // Keep an exact copy of fields not represented by the canonical contract.
  input.legacyData = cloneJson(raw || {});
  return normalizePet(input);
}

function collectLegacyPets(userId) {
  const out = [];
  const legacyUser = getUser(userId);
  for (const [source, list] of [['users.megaPets', legacyUser?.megaPets], ['users.pets', legacyUser?.pets]]) {
    if (!Array.isArray(list)) continue;
    list.forEach((raw, index) => out.push(normalizeLegacyPet(raw, userId, source, index)));
  }
  const economy = readLegacyEconomy();
  const economyUser = economy.users?.[userId];
  if (Array.isArray(economyUser?.pets)) {
    economyUser.pets.forEach((raw, index) => out.push(normalizeLegacyPet(raw, userId, 'economy.users.pets', index)));
  }
  return out;
}

export async function migrateLegacyGlobal(userId) {
  if (!userId) return [];
  const existing = all(GLOBAL, userId);
  const legacy = collectLegacyPets(userId);
  if (!legacy.length) return existing;

  const byId = new Map(existing.map(p => [p.id, p]));
  for (const p of legacy) {
    // Canonical data wins if the same pet ID already exists.
    if (!byId.has(p.id)) byId.set(p.id, p);
  }
  const merged = [...byId.values()];
  if (merged.length > MAX_PETS) {
    throw new ValidationError(`Migração bloqueada: ${userId} possui ${merged.length} pets e o limite canônico é ${MAX_PETS}. Nenhum dado foi alterado.`);
  }

  await updateCollection(C, d => {
    d.pets ??= {};
    d.migrations ??= {};
    d.migrations.legacyPets ??= {};
    d.pets[key(GLOBAL, userId)] = Object.fromEntries(merged.map(p => [p.id, p]));
    d.migrations.legacyPets[userId] = {
      version: 1,
      migratedAt: Date.now(),
      sources: [...new Set(legacy.map(p => p.legacySource))],
      legacyCount: legacy.length,
      canonicalCount: merged.length,
      destructiveCleanupPending: true
    };
    return d;
  }, { pets: {}, migrations: {} });

  // Deliberadamente não removemos users.*.pets/megaPets nem economy.users.*.pets.
  // A limpeza só acontece na etapa 6, depois da validação da migração.
  return merged;
}

function buildPet(name, speciesId) {
  const meta = SPECIES[speciesId];
  return normalizePet({ id: pid(), speciesId, species: meta.name, emoji: meta.emoji, rarity: meta.rarity, name, attack: meta.attack, defense: meta.defense, speed: meta.speed });
}

export async function adopt(groupId, userId, name, speciesId = null) {
  const gid = groupId || GLOBAL;
  let created;
  await updateCollection(C, d => {
    d.pets ??= {};
    const kk = key(gid, userId);
    const arr = d.pets[kk] ||= {};
    if (Object.keys(arr).length >= MAX_PETS) throw new ValidationError(`Limite de ${MAX_PETS} pets atingido.`);
    const ids = Object.keys(SPECIES);
    const chosen = SPECIES[String(speciesId || '').toLowerCase()] ? String(speciesId).toLowerCase() : ids[Math.floor(Math.random() * ids.length)];
    created = buildPet(String(name || 'Fantasma').slice(0, 30), chosen);
    arr[created.id] = created;
    return d;
  }, { pets: {} });
  return created;
}

export async function acquire(groupId, userId, speciesId, name = '', operationId = null) {
  const gid = groupId || GLOBAL;
  const sid = String(speciesId || '').toLowerCase();
  const meta = SPECIES[sid];
  if (!meta) throw new ValidationError(`Pet inválido. Escolha: ${Object.keys(SPECIES).join(' | ')}`);
  const op = operationId || `pet-acquire:${gid}:${userId}:${sid}:${Date.now()}`;
  let created = null;
  await economy.mutateAccount(userId, ({ economy: e }) => {
    if (e.operations?.[op]) return { duplicate: true };
    if (Number(e.wallet || 0) < meta.price) throw new ValidationError(`Você precisa de ${meta.price.toLocaleString('pt-BR')} Ghostcoins.`);
    e.wallet -= meta.price;
    return { amount: -meta.price };
  }, {
    reason: 'pet.acquire', operationId: op, name,
    extraSteps: [{ collection: C, update: d => {
      d.pets ??= {};
      if (Object.values(d.pets).some(a => Object.values(a || {}).some(p => p.operationId === op))) return d;
      const arr = d.pets[key(gid, userId)] ||= {};
      if (Object.keys(arr).length >= MAX_PETS) throw new ValidationError(`Limite de ${MAX_PETS} pets atingido.`);
      created = buildPet(String(name || meta.name).slice(0, 30), sid);
      created.operationId = op;
      arr[created.id] = created;
      return d;
    }}]
  });
  return created || all(gid, userId).find(p => p.operationId === op) || null;
}

export async function act(groupId, userId, petId, action) {
  const gid = groupId || GLOBAL;
  const delta = { feed: { hunger: 20, happiness: 5, energy: -2 }, play: { happiness: 15, energy: -10, hunger: -8 }, care: { hygiene: 20, happiness: 8, energy: -3 }, walk: { happiness: 10, energy: -15, hunger: -8 }, train: { training: 10, xp: 20, energy: -12, hunger: -5 }, rest: { energy: 25, health: 5 }, sleep: { energy: 45, happiness: 3 }, bath: { hygiene: 40, happiness: 5, energy: -4 }, adventure: { xp: 35, energy: -25, hunger: -12, hygiene: -8, happiness: 15 } }[action];
  if (!delta) throw new ValidationError('Ação de pet inválida.');
  let result;
  await updateCollection(C, d => {
    const p = d.pets?.[key(gid, userId)]?.[petId];
    if (!p) throw new ValidationError('Pet não encontrado.');
    const n = normalizePet(p);
    for (const [field, val] of Object.entries(delta)) {
      if (field === 'xp') n.xp += val;
      else if (field === 'training') n.training = clamp(n.training + val, 0, 100);
      else n[field] = clamp(n[field] + val, 0, 100);
    }
    while (n.xp >= n.level * 100) { n.xp -= n.level * 100; n.level++; n.maxHp += 10; n.health = n.maxHp; n.history.push({ at: Date.now(), type: 'LEVEL_UP', level: n.level }); }
    n.history.push({ at: Date.now(), type: action });
    d.pets[key(gid, userId)][petId] = n;
    result = n;
    return d;
  }, { pets: {} });
  return result;
}

export async function rename(groupId, userId, petId, name) {
  const gid = groupId || GLOBAL;
  let result;
  const safe = String(name || 'Fantasma').trim().slice(0, 30);
  if (!safe) throw new ValidationError('Nome do pet inválido.');
  await updateCollection(C, d => {
    const p = d.pets?.[key(gid, userId)]?.[petId];
    if (!p) throw new ValidationError('Pet não encontrado.');
    p.name = safe; p.history = Array.isArray(p.history) ? p.history : []; p.history.push({ at: Date.now(), type: 'RENAME', name: safe });
    d.pets[key(gid, userId)][petId] = normalizePet(p); result = d.pets[key(gid, userId)][petId]; return d;
  }, { pets: {} });
  return result;
}

export async function updatePet(groupId, userId, petId, mutator) {
  const gid = groupId || GLOBAL;
  if (typeof mutator !== 'function') throw new ValidationError('Atualização de pet inválida.');
  let result;
  await updateCollection(C, d => {
    const p = d.pets?.[key(gid, userId)]?.[petId];
    if (!p) throw new ValidationError('Pet não encontrado.');
    const n = normalizePet(p);
    const next = mutator(n) || n;
    result = normalizePet(next);
    result.history = Array.isArray(result.history) ? result.history.slice(-100) : [];
    result.history.push({ at: Date.now(), type: 'UPDATE' });
    d.pets[key(gid, userId)][petId] = result;
    return d;
  }, { pets: {} });
  return result;
}

export async function release(groupId, userId, petId) {
  const gid = groupId || GLOBAL;
  await updateCollection(C, d => {
    const arr = d.pets?.[key(gid, userId)];
    if (!arr?.[petId]) throw new ValidationError('Pet não encontrado.');
    delete arr[petId]; return d;
  }, { pets: {} });
  return true;
}

export function speciesList() { return Object.entries(SPECIES).map(([id, p]) => `${p.emoji} ${id} — ${p.rarity} — ${p.price.toLocaleString('pt-BR')} GC`); }
export function catalog() { return Object.entries(SPECIES).map(([id, p]) => ({ id, ...p })); }
export function getByIndex(groupId, userId, index) { return list(groupId, userId)[Number(index) - 1] || null; }

export default { SPECIES, MAX_PETS, PET_STORAGE_COLLECTION, PET_STORAGE_VERSION, PET_SCOPE_GLOBAL, normalizePet, list, listGroup, listAsync, migrateLegacyGlobal, adopt, acquire, act, rename, release, updatePet, speciesList, catalog, getByIndex };
