import { getUser, upsertUser, updateCollection } from '../database/store.js';
import { ValidationError } from '../core/errors.js';
import * as economy from './economy.js';

export const CLASSES = {
  guerreiro: { name: 'Guerreiro', mods: { strength: 3, defense: 1 } },
  paladino: { name: 'Paladino', mods: { defense: 3, vitality: 2 } },
  ladino: { name: 'Ladino', mods: { agility: 3, crit: 0.08 } },
  mago: { name: 'Mago', mods: { mana: 4 } },
  curandeiro: { name: 'Curandeiro', mods: { healing: 0.15 } },
  espectro: { name: 'Espectro', mods: { agility: 2, mana: 1 } },
  barqueiro: { name: 'Barqueiro', mods: { vitality: 2, defense: 1 } },
  ceifador: { name: 'Ceifador', mods: { strength: 2, agility: 2 } },
  sombra: { name: 'Sombra', mods: { agility: 2, defense: 1 } },
  alma_errante: { name: 'Alma Errante', mods: { vitality: 1, mana: 1 } }
};

export const LEGACY_CLASS_ALIASES = {
  'alma errante': 'alma_errante',
  almaerrante: 'alma_errante',
  'espectro': 'espectro',
  'barqueiro': 'barqueiro',
  'ceifador': 'ceifador',
  'sombra': 'sombra'
};

export const EQUIP = {
  foice_enferrujada: { slot: 'arma', atk: 8, def: 0, name: 'Foice Enferrujada', price: 2000 },
  lamina_veu: { slot: 'arma', atk: 18, def: 0, name: 'Lâmina do Véu', price: 8000 },
  manto_sombra: { slot: 'armadura', atk: 0, def: 10, name: 'Manto Sombra', price: 5000 },
  coroa_limbo: { slot: 'armadura', atk: 0, def: 20, name: 'Coroa do Limbo', price: 12000 }
};

export const BOSSES = [
  { id: 'caronte', name: 'Caronte', hp: 120, atk: 15, xp: 80, gold: 400, minLevel: 1 },
  { id: 'cerbero', name: 'Cérbero', hp: 220, atk: 25, xp: 160, gold: 900, minLevel: 3 },
  { id: 'hadoes', name: 'Sombra de Hades', hp: 400, atk: 40, xp: 350, gold: 2000, minLevel: 6 }
];

export const DUNGEONS = [
  { id: 'cripta', name: 'Cripta Úmida', floors: 3, minLevel: 1, xpPerFloor: 40, goldPerFloor: 150 },
  { id: 'rio_estilo', name: 'Rio Estige', floors: 5, minLevel: 3, xpPerFloor: 70, goldPerFloor: 280 },
  { id: 'trono', name: 'Trono Quebrado', floors: 7, minLevel: 6, xpPerFloor: 120, goldPerFloor: 500 }
];

export function normalizeClass(value) {
  const raw = String(value ?? '').trim().toLowerCase();
  if (CLASSES[raw]) return raw;
  return LEGACY_CLASS_ALIASES[raw] || null;
}

export function ensureRpg(user = {}) {
  user.rpg ??= {};
  const r = user.rpg;
  r.class = normalizeClass(r.class) || r.class || null;
  r.level = Number.isSafeInteger(Number(r.level)) && Number(r.level) >= 1 ? Number(r.level) : 1;
  r.xp = Number.isFinite(Number(r.xp)) && Number(r.xp) >= 0 ? Number(r.xp) : 0;
  r.hp = Number.isFinite(Number(r.hp)) ? Math.max(0, Number(r.hp)) : 100;
  r.maxHp = Number.isFinite(Number(r.maxHp)) && Number(r.maxHp) >= 1 ? Number(r.maxHp) : 100 + r.level * 10;
  r.hp = Math.min(r.hp, r.maxHp);
  r.attributes ??= {};
  r.equip ??= { arma: null, armadura: null };
  r.equip.arma ??= null;
  r.equip.armadura ??= null;
  r.bag ??= {};
  return r;
}

export function xpForLevel(level) {
  const l = Math.max(1, Math.floor(Number(level) || 1));
  return 50 * Math.pow(l - 1, 2);
}

export function xpForNextLevel(level) {
  return xpForLevel(Math.max(1, Number(level) || 1) + 1);
}

export function levelForXp(xp) {
  const n = Math.max(0, Number(xp) || 0);
  return Math.max(1, Math.floor(Math.sqrt(n / 50)) + 1);
}

export function applyXp(rpg, amount) {
  const r = ensureRpg({ rpg });
  const gain = Number(amount) || 0;
  if (!Number.isFinite(gain) || gain < 0) throw new ValidationError('XP inválido.');
  r.xp += gain;
  r.level = levelForXp(r.xp);
  r.maxHp = 100 + r.level * 10;
  r.hp = Math.min(r.maxHp, Number(r.hp ?? r.maxHp));
  return r;
}

export async function createCharacter(userId, classId = 'alma_errante', name = '') {
  const cls = normalizeClass(classId) || 'alma_errante';
  const existing = getUser(userId);
  if (existing?.rpg?.class) throw new ValidationError('Você já possui um personagem.');
  const r = ensureRpg({ rpg: {} });
  r.class = cls;
  await upsertUser(userId, { name, rpg: r });
  return r;
}

export function getRpg(userId) {
  return getUser(userId)?.rpg ? ensureRpg(getUser(userId)) : null;
}

export async function chooseClass(userId, classId) {
  const cls = normalizeClass(classId);
  if (!cls) throw new ValidationError(`Classe inválida. Opções: ${Object.keys(CLASSES).join(', ')}`);
  const u = getUser(userId) || (await upsertUser(userId), getUser(userId));
  const r = ensureRpg(u);
  r.class = cls;
  await upsertUser(userId, { rpg: r });
  return r;
}

export async function train(userId, attribute) {
  const allowed = { forca: 'strength', defesa: 'defense', agilidade: 'agility', vitalidade: 'vitality', mana: 'mana' };
  const key = allowed[String(attribute || '').trim().toLowerCase()];
  if (!key) throw new ValidationError('Treino: forca | defesa | agilidade | vitalidade | mana');
  const u = getUser(userId) || (await upsertUser(userId), getUser(userId));
  const r = ensureRpg(u);
  if (!r.class) throw new ValidationError('Crie seu personagem primeiro: rpgcriar');
  r.attributes[key] = Number(r.attributes[key] || 0) + 1;
  applyXp(r, 10);
  await upsertUser(userId, { rpg: r });
  return { attribute: key, value: r.attributes[key], xp: 10, level: r.level };
}

export const RPG_ACTIVITY_XP = Object.freeze({
  pescar: 10,
  explorar: 12,
  cacar: 12,
  minerar: 15,
  trabalhar: 12,
  forjar: 10,
  cozinhar: 10,
  plantar: 5,
  colher: 8,
  dungeon: 0,
  boss: 0,
  arena: 0,
  duelo: 0,
  treino: 10,
  missao: 0
});

/**
 * Concede XP de atividade ao RPG central. Atividades legadas podem criar
 * automaticamente a classe padrão Alma Errante para não bloquear a progressão.
 * Retorna o ganho, nível anterior/novo e progresso atual.
 */
export async function grantActivityXp(userId, amount, name = '', source = 'rpg.activity') {
  const gain = Number(amount);
  if (!Number.isFinite(gain) || gain < 0) throw new ValidationError('XP de atividade inválido.');
  let result;
  await updateCollection('users', users => {
    users.byId ??= {};
    const u = users.byId[userId] || { id: userId, name: '', rpg: {} };
    const r = ensureRpg(u);
    if (!r.class) r.class = 'alma_errante';
    const oldLevel = r.level;
    const oldXp = r.xp;
    applyXp(r, gain);
    if (name) u.name = String(name).slice(0, 80);
    u.updatedAt = Date.now();
    u.rpg = r;
    users.byId[userId] = u;
    result = { source, gain, oldLevel, level: r.level, oldXp, xp: r.xp, levelUp: r.level > oldLevel, class: r.class };
    return users;
  }, { byId: {} });
  return result;
}

export async function addXp(userId, amount, name = '') {
  let result;
  await updateCollection('users', users => {
    users.byId ??= {};
    const u = users.byId[userId] || { id: userId, name: '', rpg: {} };
    const r = ensureRpg(u);
    if (!r.class) throw new ValidationError('Crie seu personagem primeiro: rpgcriar');
    applyXp(r, amount);
    if (name) u.name = name;
    u.updatedAt = Date.now();
    result = { xp: r.xp, level: r.level, maxHp: r.maxHp };
    users.byId[userId] = u;
    return users;
  }, { byId: {} });
  return result;
}

export function stats(userId) {
  const u = getUser(userId);
  if (!u?.rpg) return null;
  const r = ensureRpg(u);
  const attrs = r.attributes || {};
  const mods = CLASSES[normalizeClass(r.class)]?.mods || {};
  const strength = Number(attrs.strength || 0) + Number(mods.strength || 0);
  const defense = Number(attrs.defense || 0) + Number(mods.defense || 0);
  const agility = Number(attrs.agility || 0) + Number(mods.agility || 0);
  const vitality = Number(attrs.vitality || 0) + Number(mods.vitality || 0);
  const mana = Number(attrs.mana || 0) + Number(mods.mana || 0);
  return { level: r.level, xp: r.xp, hp: r.hp, maxHp: r.maxHp, class: normalizeClass(r.class) || r.class || null, attributes: { strength, defense, agility, vitality, mana }, attack: 10 + strength + Math.floor(agility / 2) + Number(r.equip?.arma && EQUIP[r.equip.arma]?.atk || 0), armor: 5 + defense + Math.floor(vitality / 2) + Number(r.equip?.armadura && EQUIP[r.equip.armadura]?.def || 0), maxMana: 50 + mana * 5 };
}

export function power(rpg) {
  const r = ensureRpg({ rpg: rpg || {} }).rpg;
  const s = statsFrom(r);
  return { atk: s.attack, def: s.armor, score: s.attack + s.armor + r.level * 3 };
}

function statsFrom(r) {
  const attrs = r.attributes || {};
  const mods = CLASSES[normalizeClass(r.class)]?.mods || {};
  const strength = Number(attrs.strength || 0) + Number(mods.strength || 0);
  const defense = Number(attrs.defense || 0) + Number(mods.defense || 0);
  const agility = Number(attrs.agility || 0) + Number(mods.agility || 0);
  const vitality = Number(attrs.vitality || 0) + Number(mods.vitality || 0);
  const attack = 10 + strength + Math.floor(agility / 2) + Number(r.equip?.arma && EQUIP[r.equip.arma]?.atk || 0);
  const armor = 5 + defense + Math.floor(vitality / 2) + Number(r.equip?.armadura && EQUIP[r.equip.armadura]?.def || 0);
  return { attack, armor };
}

export async function equipItem(userId, itemId) {
  const item = EQUIP[itemId];
  if (!item) throw new ValidationError('Equip desconhecido.');
  let result;
  await updateCollection('users', users => {
    const u = users.byId?.[userId];
    if (!u) throw new ValidationError('Usuário não encontrado.');
    const r = ensureRpg(u);
    if (!r.class) throw new ValidationError('Crie personagem: rpgcriar');
    if (!(r.bag[itemId] > 0)) throw new ValidationError('Você não tem esse item na bag.');
    r.bag[itemId]--;
    if (r.bag[itemId] <= 0) delete r.bag[itemId];
    const old = r.equip[item.slot];
    if (old) r.bag[old] = (r.bag[old] || 0) + 1;
    r.equip[item.slot] = itemId;
    result = { item, r: structuredClone(r) };
    users.byId[userId] = u;
    return users;
  }, { byId: {} });
  return result;
}

export async function buyEquip(userId, itemId, name = '', operationId = null) {
  const item = EQUIP[itemId];
  if (!item) throw new ValidationError('Item inválido.');
  let result;
  await economy.mutateAccount(userId, ({ user, account }) => {
    const r = ensureRpg(user);
    if (!r.class) r.class = 'alma_errante';
    account.debit(item.price);
    r.bag[itemId] = Number(r.bag[itemId] || 0) + 1;
    user.rpg = r;
    result = item;
    return { amount: -item.price };
  }, { reason: 'rpg.equip.purchase', name, operationId: operationId || `rpg-equip:${userId}:${itemId}:${Date.now()}` });
  return result;
}

export async function fightBoss(userId, bossId, name = '', operationId = null) {
  const boss = BOSSES.find(b => b.id === bossId);
  if (!boss) throw new ValidationError('Boss: caronte | cerbero | hadoes');
  const u = getUser(userId);
  if (!u?.rpg?.class) throw new ValidationError('rpgcriar primeiro');
  const r = ensureRpg(u);
  if (r.level < boss.minLevel) throw new ValidationError(`Nível mínimo ${boss.minLevel}.`);
  if (r.hp < 20) throw new ValidationError('HP baixo. Use rpgcurar.');
  const p = power(r);
  let bHp = boss.hp, log = [], turns = 0;
  while (bHp > 0 && r.hp > 0 && turns < 20) {
    turns++;
    const dmg = Math.max(1, p.atk + Math.floor(Math.random() * 10) - Math.floor(boss.atk / 5));
    bHp -= dmg; log.push(`Você: -${dmg} no boss`);
    if (bHp <= 0) break;
    const bd = Math.max(1, boss.atk - Math.floor(p.def / 2) + Math.floor(Math.random() * 8));
    r.hp -= bd; log.push(`Boss: -${bd} em você`);
  }
  const win = bHp <= 0 && r.hp > 0;
  if (!win) r.hp = Math.max(1, Math.floor(r.maxHp * 0.3));
  if (win) applyXp(r, boss.xp);
  const op = operationId || `rpg-boss:${userId}:${boss.id}:${Date.now()}`;
  await economy.mutateAccount(userId, ({ user, account }) => {
    user.rpg = r;
    if (win) account.credit(boss.gold);
    return { amount: win ? boss.gold : 0 };
  }, { reason: 'rpg.boss', name, operationId: op });
  return { win, boss, hp: r.hp, xp: r.xp, level: r.level, log: log.slice(-6), gold: win ? boss.gold : 0 };
}

export async function runDungeon(userId, dungeonId, name = '', operationId = null) {
  const d = DUNGEONS.find(x => x.id === dungeonId);
  if (!d) throw new ValidationError('Dungeon: cripta | rio_estilo | trono');
  const u = getUser(userId);
  if (!u?.rpg?.class) throw new ValidationError('rpgcriar primeiro');
  const r = ensureRpg(u);
  if (r.level < d.minLevel) throw new ValidationError(`Nível mínimo ${d.minLevel}.`);
  let floorsClear = 0, totalXp = 0, totalGold = 0;
  const p = power(r);
  for (let f = 1; f <= d.floors; f++) {
    const enemyAtk = 8 + f * 5 + d.minLevel * 2;
    const chance = p.score / (p.score + enemyAtk + Math.random() * 20);
    if (chance < 0.35) { r.hp = Math.max(1, r.hp - enemyAtk); break; }
    floorsClear++; totalXp += d.xpPerFloor; totalGold += d.goldPerFloor; r.hp = Math.max(1, r.hp - Math.floor(enemyAtk / 3));
  }
  applyXp(r, totalXp);
  const op = operationId || `rpg-dungeon:${userId}:${d.id}:${Date.now()}`;
  await economy.mutateAccount(userId, ({ user, account }) => { user.rpg = r; if (totalGold) account.credit(totalGold); return { amount: totalGold }; }, { reason: 'rpg.dungeon', name, operationId: op });
  return { dungeon: d, floorsClear, totalXp, totalGold, hp: r.hp, level: r.level };
}

export async function heal(userId, name = '', operationId = null) {
  const cost = 300;
  let result;
  const op = operationId || `rpg-heal:${userId}:${Date.now()}`;
  await economy.mutateAccount(userId, ({ user, account }) => {
    const r = ensureRpg(user);
    if (!r.class) throw new ValidationError('Crie personagem: rpgcriar');
    account.debit(cost);
    r.hp = r.maxHp;
    user.rpg = r;
    result = structuredClone(r);
    return { amount: -cost };
  }, { reason: 'rpg.heal', name, operationId: op });
  return result;
}

export default { CLASSES, EQUIP, BOSSES, DUNGEONS, RPG_ACTIVITY_XP, normalizeClass, ensureRpg, levelForXp, applyXp, createCharacter, getRpg, chooseClass, train, addXp, grantActivityXp, stats, power, equipItem, buyEquip, fightBoss, runDungeon, heal };
