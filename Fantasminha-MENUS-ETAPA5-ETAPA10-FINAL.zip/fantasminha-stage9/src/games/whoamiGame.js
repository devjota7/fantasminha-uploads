import { updateCollection, readCollection } from '../database/store.js';
import game from '../services/gameEngine.js';
import { findWhoamiEntry, isWhoamiAnswer } from './whoamiBank.js';
import { calculateWhoamiReward } from './whoamiRewards.js';
import stats from '../services/statsEngine.js';
import { dossierHeader, gameFooter, graffitiHeader } from './gamePresentation.js';

export const WHOAMI_ROUND_MS = 60_000;
export const WHOAMI_MAX_ROUNDS = 3;
export const WHOAMI_DAILY_LIMIT = 10;
export const WHOAMI_RESET_HOUR = 23;
export const WHOAMI_RESET_MINUTE = 55;
const GAME_TYPE = 'whoami';
const DAILY_COLLECTION = 'whoami_daily';
const timers = new Map();
const locks = new Map();

const norm = value => String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9\s.-]/g, ' ').replace(/\s+/g, ' ').trim();
const keyForGroup = groupId => String(groupId || 'unknown');

export function dailyBucket(date = new Date()) {
  const d = new Date(date);
  if (d.getHours() > WHOAMI_RESET_HOUR || (d.getHours() === WHOAMI_RESET_HOUR && d.getMinutes() >= WHOAMI_RESET_MINUTE)) d.setDate(d.getDate() + 1);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

export function getDailyUsage(groupId, date = new Date()) {
  const bucket = dailyBucket(date);
  const data = readCollection(DAILY_COLLECTION, { groups: {} });
  const row = data.groups?.[keyForGroup(groupId)];
  return row?.bucket === bucket ? Number(row.used || 0) : 0;
}

async function reserveDailySlot(groupId) {
  const bucket = dailyBucket();
  const key = keyForGroup(groupId);
  return updateCollection(DAILY_COLLECTION, db => {
    db.groups ||= {};
    const row = db.groups[key];
    if (!row || row.bucket !== bucket) db.groups[key] = { bucket, used: 0 };
    if (db.groups[key].used >= WHOAMI_DAILY_LIMIT) throw new Error('WHOAMI_DAILY_LIMIT');
    db.groups[key].used += 1;
    db.groups[key].updatedAt = Date.now();
    return db;
  }, { groups: {} }).then(db => db.groups[key]);
}

function clearTimer(gameId) {
  const timer = timers.get(gameId);
  if (timer) clearTimeout(timer);
  timers.delete(gameId);
}

function setTimer(gameId, ms, fn) {
  clearTimer(gameId);
  const timer = setTimeout(() => fn().catch(() => {}), Math.max(1, ms));
  timer.unref?.();
  timers.set(gameId, timer);
}

async function exclusive(groupId, fn) {
  const previous = locks.get(groupId) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  locks.set(groupId, previous.then(() => current));
  await previous;
  try { return await fn(); }
  finally { release(); if (locks.get(groupId) === current) locks.delete(groupId); }
}

function active(groupId) { return game.listActiveGames(groupId).find(x => x.gameType === GAME_TYPE) || null; }
function currentHint(state) { return state.hints?.[state.round - 1]?.text || state.hints?.at(-1)?.text || 'Descubra o personagem!'; }
function publicRound(state) {
  return [graffitiHeader('Quem sou eu?'), 'Uma nova identidade atravessou o véu.', `DICA ${state.round}: ${currentHint(state)}`, `⌛ Tempo: 1:00 · Rodada ${state.round}/${WHOAMI_MAX_ROUNDS}`, 'Palpite: ×quemevoce <resposta>', gameFooter('info', 'game:whoami:round')].join('\n');
}

async function send(ctx, text) {
  if (typeof ctx?.reply === 'function') return ctx.reply(text);
  if (typeof ctx?.sendMessage === 'function') return ctx.sendMessage(ctx.from, { text });
  return null;
}

async function finishExpired(g, ctx) {
  clearTimer(g.gameId);
  const current = game.getGame(g.gameId);
  if (!current) return;
  const answer = current.state.answers?.[0] || current.state.answer || 'desconhecida';
  const wrongUsers = [...new Set((current.state.responses || []).filter(r => !r.correct && r.userId).map(r => r.userId))];
  for (const userId of wrongUsers) await stats.recordResult({ groupId: current.groupId, userId, gameType: GAME_TYPE, result: 'loss', score: 0, xp: 0, win: false, loss: true, draw: false, operationId: `whoami:${g.gameId}:loss:${userId}` });
  await game.finishGame(g.gameId, current.groupId, { status: 'EXPIRED', reason: 'three_rounds_timeout', result: { answer, rounds: current.state.round } });
  await send(ctx, [dossierHeader('Quem sou eu · tempo encerrado'), 'Ninguém acertou nas três rodadas.', `Resposta revelada: ${answer}`, `Rodada final: ${current.state.round}/${WHOAMI_MAX_ROUNDS}`, '', gameFooter('info', 'game:whoami:result')].join('\n'));
}

async function advance(g, ctx, reason = 'timeout') {
  const current = game.getGame(g.gameId);
  if (!current) return;
  if (current.state.round >= WHOAMI_MAX_ROUNDS) return finishExpired(current, ctx);
  const nextRound = current.state.round + 1;
  const updated = await game.updateGame(current.gameId, current.groupId, x => {
    x.state.round = nextRound;
    x.state.roundStartedAt = Date.now();
    x.state.roundReason = reason;
    return x;
  });
  await send(ctx, publicRound(updated.state));
  setTimer(updated.gameId, WHOAMI_ROUND_MS, () => advance(updated, ctx, 'timeout'));
}

export async function start(ctx) {
  if (!ctx?.isGroup) return send(ctx, '⚠️ O ×quemsoueu funciona apenas em grupos.');
  const groupId = ctx.from;
  return exclusive(groupId, async () => {
    const existing = active(groupId);
    if (existing) return send(ctx, [graffitiHeader('Quem sou eu · em andamento'), `Rodada ativa: ${existing.state.round}/${WHOAMI_MAX_ROUNDS}`, 'A rodada atual continua recebendo palpites.'].join('\n'));
    try { await reserveDailySlot(groupId); }
    catch (error) {
      if (error?.message === 'WHOAMI_DAILY_LIMIT') return send(ctx, [dossierHeader('Limite diário atingido'), `Este grupo já utilizou as ${WHOAMI_DAILY_LIMIT} partidas de hoje.`, 'Renovação: 23:55.'].join('\n'));
      throw error;
    }
    const item = findWhoamiEntry('geral');
    const state = { entryId: item.id, category: item.category, answers: item.answers, hints: item.hints, round: 1, maxRounds: WHOAMI_MAX_ROUNDS, roundStartedAt: Date.now(), startedAt: Date.now(), responses: [], winnerId: null };
    const g = await game.createGame({ groupId, gameType: GAME_TYPE, creatorId: ctx.sender || 'unknown', maxPlayers: 1, onePerGroup: true, timeoutMs: WHOAMI_ROUND_MS * WHOAMI_MAX_ROUNDS, state });
    try {
      await send(ctx, publicRound(state));
      setTimer(g.gameId, WHOAMI_ROUND_MS, () => advance(g, ctx, 'timeout'));
      return { ok: true, gameId: g.gameId };
    } catch (error) {
      clearTimer(g.gameId);
      await game.finishGame(g.gameId, groupId, { status: 'CANCELLED', reason: 'start_send_failed' }).catch(() => {});
      throw error;
    }
  });
}

export async function answer(ctx, rawAnswer) {
  if (!ctx?.isGroup) return { handled: false };
  const groupId = ctx.from;
  return exclusive(groupId, async () => {
  const g = active(groupId);
  if (!g) return { handled: false };
  const answer = norm(rawAnswer);
  if (!answer) return send(ctx, '💬 Use: ×quemevoce <resposta>');
  const now = Date.now();
  const elapsed = Math.max(0, now - Number(g.state.roundStartedAt || now));
  if (elapsed >= WHOAMI_ROUND_MS) { await advance(g, ctx, 'timeout'); return { handled: true, expiredRound: true }; }
  const correct = isWhoamiAnswer({ answers: g.state.answers }, answer);
  if (correct) {
    clearTimer(g.gameId);
    const winnerId = ctx.sender || 'unknown';
    const reward = calculateWhoamiReward({ responseTimeMs: elapsed, roundMs: WHOAMI_ROUND_MS });
    const result = { answer: g.state.answers?.[0] || 'desconhecida', winnerId, responseTimeMs: elapsed, round: g.state.round, correct: true, points: reward.points };
    await game.finishGame(g.gameId, groupId, { status: 'FINISHED', winnerId, result });
    await stats.recordResult({ groupId, userId: winnerId, gameType: GAME_TYPE, result: 'correct', score: reward.points, xp: 0, win: true, loss: false, draw: false, operationId: `whoami:${g.gameId}:winner` });
    const wrongUsers = [...new Set((g.state.responses || []).filter(r => !r.correct && r.userId && r.userId !== winnerId).map(r => r.userId))];
    for (const userId of wrongUsers) await stats.recordResult({ groupId, userId, gameType: GAME_TYPE, result: 'loss', score: 0, xp: 0, win: false, loss: true, draw: false, operationId: `whoami:${g.gameId}:loss:${userId}` });
    await send(ctx, [dossierHeader('Quem sou eu · resultado'), `Resposta: ${result.answer}`, `Tempo de resposta: ${(elapsed / 1000).toFixed(1)}s`, `Pontuação: ${reward.points}`, `Vencedor: @${String(winnerId).split('@')[0]}`, '', gameFooter('sucesso', 'game:whoami:result')].join('\n'));
    return { handled: true, correct: true, result };
  }
  const responderId = ctx.sender || 'unknown';
  await game.updateGame(g.gameId, groupId, x => {
    x.state.responses ||= [];
    x.state.responses.push({ userId: responderId, answer, correct: false, responseTimeMs: elapsed, round: x.state.round, at: now });
    return x;
  });
  await stats.recordError({ groupId, userId: responderId, gameType: GAME_TYPE, errors: 1, operationId: `whoami:${g.gameId}:error:${now}:${responderId}` });
  clearTimer(g.gameId);
  await send(ctx, `${graffitiHeader('Palpite incorreto')}\n@${String(ctx.sender || 'unknown').split('@')[0]} errou.\nA próxima dica foi liberada para todos.`);
  await advance(g, ctx, 'wrong_answer');
  return { handled: true, correct: false };
  });
}

export function dispose(gameId) { clearTimer(gameId); }
export default { start, answer, dispose, dailyBucket, getDailyUsage, WHOAMI_ROUND_MS, WHOAMI_MAX_ROUNDS, WHOAMI_DAILY_LIMIT };
