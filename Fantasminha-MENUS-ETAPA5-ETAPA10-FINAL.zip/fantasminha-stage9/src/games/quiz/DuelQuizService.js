import fs from 'node:fs';

const FALLBACK_QUIZ_DB = {
  geral: [{ p: 'Qual é o maior planeta?', r: ['jupiter'], d: 'Júpiter' }]
};

function loadQuizDB(quizPath, log = console) {
  let quizDB = {};
  try {
    quizDB = JSON.parse(fs.readFileSync(quizPath, 'utf-8'));
  } catch (e) {
    log?.error?.('Erro ao carregar quiz.json:', e);
    quizDB = FALLBACK_QUIZ_DB;
  }
  return quizDB;
}

export function handleDuelQuiz({
  isGroup,
  from,
  sender,
  menc_os2,
  args = [],
  prefix,
  reply,
  normalizar,
  quizPath = new URL('../../../dados/src/funcs/json/quiz.json', import.meta.url),
  log = console
}) {
  if (!isGroup) return reply('⚔️ Este jogo só funciona em grupos!');

  const quizDB = loadQuizDB(quizPath, log);

  if (!global.dueloQuizGames) global.dueloQuizGames = {};
  if (!global.dueloQuizChallenges) global.dueloQuizChallenges = {};

  const gameKey = isGroup ? from : sender;

  if (menc_os2 && menc_os2 !== sender) {
    if (global.dueloQuizChallenges[gameKey] && Date.now() - global.dueloQuizChallenges[gameKey].created > 60000) {
      delete global.dueloQuizChallenges[gameKey];
    }

    if (global.dueloQuizGames[gameKey] && Date.now() - global.dueloQuizGames[gameKey].iniciado > 300000) {
      delete global.dueloQuizGames[gameKey];
    }

    const numPerguntas = parseInt(args.find(arg => !isNaN(parseInt(arg)))) || 5;

    if (numPerguntas < 3 || numPerguntas > 20) {
      return reply('❌ Número de perguntas inválido! Use entre 3 e 20 perguntas.\n\n💡 Exemplo: ${prefix}dueloquiz @usuario 10');
    }

    if (global.dueloQuizChallenges[gameKey] || global.dueloQuizGames[gameKey]) {
      return reply('⚠️ Já existe um duelo ou desafio pendente neste grupo!');
    }

    global.dueloQuizChallenges[gameKey] = {
      challenger: sender,
      challenged: menc_os2,
      numPerguntas,
      status: 'pending',
      created: Date.now()
    };

    return reply(`⚔️ *DESAFIO DE QUIZ*\n\n@${sender.split('@')[0]} desafiou @${menc_os2.split('@')[0]} para um duelo de ${numPerguntas} perguntas!\n\n💡 O desafiado deve usar: ${prefix}dueloquiz aceitar\n⏱️ O desafio expira em 60 segundos.`, { mentions: [sender, menc_os2] });
  }

  if (args[0]?.toLowerCase() === 'aceitar') {
    const challenge = global.dueloQuizChallenges[gameKey];

    if (!challenge || challenge.challenged !== sender || challenge.status !== 'pending') {
      return reply('❌ Não há desafio pendente para você aceitar!');
    }

    if (Date.now() - challenge.created > 60000) {
      delete global.dueloQuizChallenges[gameKey];
      return reply('⏰ O desafio expirou!');
    }

    const categoriasDisponiveis = Object.keys(quizDB);
    const perguntasSelecionadas = [];
    const categoriasUsadas = new Set();
    const perguntasUsadas = new Set();
    const todasPerguntas = [];

    categoriasDisponiveis.forEach(cat => {
      quizDB[cat].forEach((pergunta, idx) => {
        todasPerguntas.push({ categoria: cat, pergunta, id: `${cat}_${idx}` });
      });
    });

    while (perguntasSelecionadas.length < challenge.numPerguntas && todasPerguntas.length > 0) {
      const idx = Math.floor(Math.random() * todasPerguntas.length);
      const pergunta = todasPerguntas.splice(idx, 1)[0];

      if (!perguntasUsadas.has(pergunta.id)) {
        perguntasSelecionadas.push(pergunta);
        perguntasUsadas.add(pergunta.id);
        categoriasUsadas.add(pergunta.categoria);
      }
    }

    if (perguntasSelecionadas.length < challenge.numPerguntas) {
      return reply('❌ Não há perguntas suficientes no banco de dados!');
    }

    global.dueloQuizGames[gameKey] = {
      jogador1: challenge.challenger,
      jogador2: challenge.challenged,
      perguntas: perguntasSelecionadas,
      perguntaAtual: 0,
      respostas1: [],
      respostas2: [],
      turno: challenge.challenger,
      status: 'active',
      iniciado: Date.now()
    };

    delete global.dueloQuizChallenges[gameKey];

    const primeiraPergunta = perguntasSelecionadas[0];
    return reply(`⚔️ *DUELO DE QUIZ INICIADO!*\n\n@${challenge.challenger.split('@')[0]} vs @${challenge.challenged.split('@')[0]}\n\n📊 ${challenge.numPerguntas} perguntas\n\n🎯 *Pergunta 1/${challenge.numPerguntas}*\n📂 Categoria: ${primeiraPergunta.categoria}\n\n❓ ${primeiraPergunta.pergunta.p}\n\n💡 É a vez de @${challenge.challenger.split('@')[0]} responder!\nUse: ${prefix}dueloquiz [resposta]`, { mentions: [challenge.challenger, challenge.challenged] });
  }

  if (global.dueloQuizGames[gameKey] && args.length > 0 && args[0].toLowerCase() !== 'aceitar') {
    const game = global.dueloQuizGames[gameKey];

    if (game.status !== 'active') return reply('❌ Este duelo já terminou!');
    if (game.turno !== sender) return reply('⏳ Não é sua vez! Aguarde o oponente.');

    const perguntaAtual = game.perguntas[game.perguntaAtual];
    const resposta = normalizar(args.join(' ').toLowerCase());
    const acertou = perguntaAtual.pergunta.r.some(r =>
      normalizar(r) === resposta || resposta.includes(normalizar(r))
    );

    if (sender === game.jogador1) {
      game.respostas1.push({ acertou, tempo: Date.now() - game.iniciado });
    } else {
      game.respostas2.push({ acertou, tempo: Date.now() - game.iniciado });
    }

    game.perguntaAtual++;
    game.turno = sender === game.jogador1 ? game.jogador2 : game.jogador1;

    if (game.perguntaAtual >= game.perguntas.length) {
      game.status = 'finished';

      const acertos1 = game.respostas1.filter(r => r.acertou).length;
      const acertos2 = game.respostas2.filter(r => r.acertou).length;

      let resultado = `⚔️ *DUELO FINALIZADO!*\n\n`;
      resultado += `📊 *Resultado:*\n`;
      resultado += `@${game.jogador1.split('@')[0]}: ${acertos1}/${game.perguntas.length} acertos\n`;
      resultado += `@${game.jogador2.split('@')[0]}: ${acertos2}/${game.perguntas.length} acertos\n\n`;

      if (acertos1 > acertos2) {
        resultado += `🏆 *VENCEDOR:* @${game.jogador1.split('@')[0]}!`;
      } else if (acertos2 > acertos1) {
        resultado += `🏆 *VENCEDOR:* @${game.jogador2.split('@')[0]}!`;
      } else {
        resultado += `🤝 *EMPATE!*`;
      }

      delete global.dueloQuizGames[gameKey];
      return reply(resultado, { mentions: [game.jogador1, game.jogador2] });
    }

    const proximaPergunta = game.perguntas[game.perguntaAtual];
    let respostaMsg = acertou ? `✅ *CORRETO!*` : `❌ *ERRADO!*\n✅ Resposta: ${perguntaAtual.pergunta.d}`;
    respostaMsg += `\n\n🎯 *Pergunta ${game.perguntaAtual + 1}/${game.perguntas.length}*\n`;
    respostaMsg += `📂 Categoria: ${proximaPergunta.categoria}\n\n`;
    respostaMsg += `❓ ${proximaPergunta.pergunta.p}\n\n`;
    respostaMsg += `💡 É a vez de @${game.turno.split('@')[0]} responder!\n`;
    respostaMsg += `Use: ${prefix}dueloquiz [resposta]`;

    return reply(respostaMsg, { mentions: [game.jogador1, game.jogador2] });
  }

  if (global.dueloQuizGames[gameKey]) {
    const game = global.dueloQuizGames[gameKey];
    const perguntaAtual = game.perguntas[game.perguntaAtual];

    let status = `⚔️ *DUELO DE QUIZ*\n\n`;
    status += `@${game.jogador1.split('@')[0]} vs @${game.jogador2.split('@')[0]}\n\n`;
    status += `🎯 *Pergunta ${game.perguntaAtual + 1}/${game.perguntas.length}*\n`;
    status += `📂 Categoria: ${perguntaAtual.categoria}\n\n`;
    status += `❓ ${perguntaAtual.pergunta.p}\n\n`;
    status += `⏭️ Turno: @${game.turno.split('@')[0]}\n`;
    status += `💡 Use: ${prefix}dueloquiz [resposta]`;

    return reply(status, { mentions: [game.jogador1, game.jogador2] });
  }

  return reply(`⚔️ *DUELO DE QUIZ*\n\n💡 *Como jogar:*\n\n1️⃣ Desafie alguém:\n${prefix}dueloquiz @usuario [número]\n\n2️⃣ O desafiado aceita:\n${prefix}dueloquiz aceitar\n\n3️⃣ Respondam as perguntas alternadamente!\n\n🏆 Quem acertar mais perguntas vence!\n\n📌 Exemplo: ${prefix}dueloquiz @usuario 10`);
}
