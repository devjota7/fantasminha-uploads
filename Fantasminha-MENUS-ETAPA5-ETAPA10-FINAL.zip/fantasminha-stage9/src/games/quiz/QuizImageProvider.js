import { env } from '../../config/env.js';
import { requestAIImage } from '../../services/aiService.js';

export class QuizImageProvider {
  async generate({ prompt }) {
    return requestAIImage({
      prompt,
      model: env.QUIZ_IMAGE_MODEL || env.OPENAI_IMAGE_MODEL || 'gpt-image-2.5-flare',
      quality: env.QUIZ_IMAGE_QUALITY || 'low',
      size: env.QUIZ_IMAGE_SIZE || '1024x1024',
      timeoutMs: Number(env.QUIZ_IMAGE_TIMEOUT_MS || 90000)
    });
  }
}

export default QuizImageProvider;
