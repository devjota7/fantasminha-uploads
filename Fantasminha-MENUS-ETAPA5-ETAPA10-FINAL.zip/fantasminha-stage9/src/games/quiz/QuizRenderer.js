import { categoryLabel } from './QuizCategoryEngine.js';
import { difficultyLabel } from './QuizDifficultyEngine.js';
import { dossierHeader, gameFooter, hudHeader } from '../gamePresentation.js';

export function maskQuestion(question) {
  return String(question).replace(/\S/g, '_');
}

export function renderQuestion(session) {
  return [
    hudHeader('Quiz em andamento', 'QUIZ'),
    `◈ ${categoryLabel(session.category)}`,
    `⚙️ Dificuldade: ${difficultyLabel(session.difficulty)}`,
    '',
    `? ${session.question}`,
    '',
    ...session.options.map((option, index) => `${index + 1}️⃣ ${option.text}`),
    '',
    '⏳ Tempo para responder: 45 segundos.',
    gameFooter('info', 'game:quiz:question')
  ].join('\n');
}

export function renderPreparing() {
  return [hudHeader('Preparando a rodada', 'QUIZ'), '✎ A pergunta está atravessando o véu…', gameFooter('espera', 'game:quiz:preparing')].join('\n');
}

export function renderBusy() {
  return [hudHeader('Rodada em andamento', 'QUIZ'), 'Já existe uma partida ativa neste grupo.', 'Aguarde o encerramento antes de iniciar outra.', gameFooter('espera', 'game:quiz:busy')].join('\n');
}

export function renderError() {
  return [hudHeader('Falha na rodada', 'QUIZ'), 'Não foi possível preparar esta partida.', 'Tente novamente com `×quiz`.', gameFooter('erro', 'game:quiz:error')].join('\n');
}

export function renderResult(result, mention = id => `@${String(id).split('@')[0]}`, reason = 'expired') {
  const winners = [...result.correctAnswers].sort((a, b) => b.points - a.points || a.responseTimeMs - b.responseTimeMs);
  const podium = winners.map((entry, index) => `${['🥇', '🥈', '🥉'][index] || '•'} ${mention(entry.userId)} — +${entry.points} pontos`).join('\n') || 'Nenhum acerto registrado.';
  return [
    dossierHeader('Resultado do quiz'),
    reason === 'expired' ? '⏱️ Tempo encerrado.' : '◈ Rodada encerrada.',
    `Resposta correta: ${result.correctAnswer}`,
    `Participações: ${result.responses}`,
    `Acertos: ${result.correctCount} · Erros: ${result.wrongCount}`,
    '',
    '† Classificação',
    podium,
    '',
    gameFooter(result.correctCount > 0 ? 'sucesso' : 'info', 'game:quiz:result')
  ].join('\n');
}

export function renderRecoveryError() {
  return [hudHeader('Sessão encerrada', 'QUIZ'), 'A rodada anterior não pôde ser recuperada com segurança.', 'Inicie outra partida com `×quiz`.', gameFooter('aviso', 'game:quiz:recovery')].join('\n');
}

export default { renderQuestion, renderPreparing, renderBusy, renderError, renderResult, maskQuestion, renderRecoveryError };
