const entry = (id, category, difficulty, answers, hints) => Object.freeze({ id, category, difficulty, answers: Object.freeze(answers), hints: Object.freeze(hints) });

export const WHOAMI_BANK = Object.freeze([
  entry('naruto','anime','facil',['naruto','naruto uzumaki'],[
    {type:'origem',text:'Vivo em uma vila ninja.'},{type:'habilidade',text:'Sou conhecido por técnicas como o Rasengan.'},{type:'identidade',text:'Meu nome começa com N.'}
  ]),
  entry('tanjiro','anime','facil',['tanjiro','tanjiro kamado'],[
    {type:'origem',text:'Sou um caçador de demônios.'},{type:'aparencia',text:'Tenho uma marca na testa.'},{type:'habilidade',text:'Meu olfato é excepcional.'}
  ]),
  entry('goku','anime','medio',['goku','son goku'],[
    {type:'origem',text:'Vim de outro planeta e cresci na Terra.'},{type:'habilidade',text:'Consigo usar o Kamehameha.'},{type:'identidade',text:'Sou um Saiyajin.'}
  ]),
  entry('luffy','anime','medio',['luffy','monkey d luffy','monkey d. luffy'],[
    {type:'origem',text:'Sou capitão de um bando de piratas.'},{type:'aparencia',text:'Meu chapéu de palha é uma marca registrada.'},{type:'objetivo',text:'Quero encontrar o One Piece.'}
  ]),
  entry('pikachu','games','facil',['pikachu','pikachu pokemon'],[
    {type:'aparencia',text:'Sou pequeno, amarelo e tenho orelhas pontudas.'},{type:'habilidade',text:'Uso eletricidade em meus ataques.'},{type:'origem',text:'Faço parte do universo Pokémon.'}
  ]),
  entry('mario','games','facil',['mario','super mario','mario bros','mario brothers'],[
    {type:'aparencia',text:'Uso boné e roupas vermelhas.'},{type:'universo',text:'Minhas aventuras têm muitos cogumelos.'},{type:'relacao',text:'Meu irmão é Luigi.'}
  ]),
  entry('luigi','games','facil',['luigi'],[
    {type:'relacao',text:'Sou irmão de um famoso encanador.'},{type:'aparencia',text:'Minha roupa costuma ser verde.'},{type:'universo',text:'Vivo no universo de Mario.'}
  ]),
  entry('steve','games','facil',['steve','minecraft steve'],[
    {type:'universo',text:'Vivo em um mundo feito de blocos.'},{type:'habilidade',text:'Posso construir ferramentas e estruturas.'},{type:'origem',text:'Sou associado a Minecraft.'}
  ]),
  entry('link','games','medio',['link','link zelda'],[
    {type:'universo',text:'Vivo em Hyrule.'},{type:'aparencia',text:'Costumo usar roupas verdes.'},{type:'relacao',text:'Minha aventura é ligada à princesa Zelda.'}
  ]),
  entry('kratos','games','medio',['kratos','kratos god of war'],[
    {type:'universo',text:'Minha história envolve mitologia e deuses.'},{type:'aparencia',text:'Tenho pele muito clara e marcas vermelhas.'},{type:'habilidade',text:'Luto usando armas poderosas.'}
  ]),
  entry('batman','herois','facil',['batman','homem morcego','homem-morcego'],[
    {type:'universo',text:'Minha cidade é Gotham.'},{type:'aparencia',text:'Uso uma roupa inspirada em um morcego.'},{type:'identidade',text:'Não possuo superpoderes naturais.'}
  ]),
  entry('superman','herois','facil',['superman','super homem','super-homem'],[
    {type:'origem',text:'Minha origem está ligada a Krypton.'},{type:'habilidade',text:'Posso voar e tenho superforça.'},{type:'identidade',text:'Meu símbolo é um S.'}
  ]),
  entry('homem-aranha','herois','facil',['homem aranha','homem-aranha','spider man','spiderman','peter parker'],[
    {type:'habilidade',text:'Consigo escalar paredes.'},{type:'aparencia',text:'Uso uma roupa inspirada em uma aranha.'},{type:'identidade',text:'Meu nome civil mais conhecido é Peter Parker.'}
  ]),
  entry('thor','herois','medio',['thor','thor marvel'],[
    {type:'origem',text:'Minha história envolve Asgard.'},{type:'habilidade',text:'Uso um poderoso martelo.'},{type:'relacao',text:'Sou membro dos Vingadores.'}
  ]),
  entry('hulk','herois','facil',['hulk','incrivel hulk','incrível hulk'],[
    {type:'aparencia',text:'Fico verde quando transformado.'},{type:'identidade',text:'Meu nome é Bruce Banner.'},{type:'habilidade',text:'Tenho força extraordinária.'}
  ]),
  entry('capitao-america','herois','medio',['capitao america','capitão américa','captain america','steve rogers'],[
    {type:'aparencia',text:'Meu escudo é minha marca.'},{type:'relacao',text:'Faço parte dos Vingadores.'},{type:'identidade',text:'Meu nome é Steve Rogers.'}
  ]),
  entry('harry-potter','filmes','facil',['harry potter','harry james potter'],[
    {type:'universo',text:'Estudo em uma escola de magia.'},{type:'aparencia',text:'Tenho uma cicatriz famosa na testa.'},{type:'relacao',text:'Meus amigos incluem Ron e Hermione.'}
  ]),
  entry('homem-de-ferro','filmes','facil',['homem de ferro','homem-de-ferro','iron man','tony stark'],[
    {type:'identidade',text:'Meu nome civil é Tony Stark.'},{type:'habilidade',text:'Uso uma armadura tecnológica.'},{type:'relacao',text:'Faço parte dos Vingadores.'}
  ]),
  entry('elsa','filmes','facil',['elsa','rainha elsa'],[
    {type:'habilidade',text:'Tenho poderes ligados ao gelo.'},{type:'universo',text:'Minha história acontece em Arendelle.'},{type:'relacao',text:'Anna é minha irmã.'}
  ]),
  entry('shrek','filmes','facil',['shrek'],[
    {type:'aparencia',text:'Sou um ogro verde.'},{type:'universo',text:'Moro em um pântano.'},{type:'relacao',text:'Minha companheira é Fiona.'}
  ]),
  entry('wednesday','series','medio',['wandinha','wednesday','wednesday addams'],[
    {type:'identidade',text:'Faço parte da família Addams.'},{type:'aparencia',text:'Meu visual é marcado por roupas escuras e tranças.'},{type:'universo',text:'Estudo na Academia Nevermore.'}
  ]),
  entry('sherlock','series','medio',['sherlock','sherlock holmes'],[
    {type:'habilidade',text:'Sou famoso por dedução e investigação.'},{type:'relacao',text:'Meu parceiro mais conhecido é Watson.'},{type:'identidade',text:'Meu sobrenome é Holmes.'}
  ]),
  entry('bob-esponja','series','facil',['bob esponja','bob-esponja','spongebob','sponge bob'],[
    {type:'aparencia',text:'Sou amarelo e vivo no fundo do mar.'},{type:'trabalho',text:'Trabalho no Siri Cascudo.'},{type:'relacao',text:'Meu melhor amigo é Patrick.'}
  ]),
  entry('homelander','series','dificil',['homelander','capitao patria','capitão pátria'],[
    {type:'universo',text:'Faço parte de uma série sobre super-heróis.'},{type:'aparencia',text:'Uso um uniforme inspirado nas cores dos Estados Unidos.'},{type:'personalidade',text:'Sou o líder dos Sete.'}
  ]),
  entry('geralt','fantasia','medio',['geralt','geralt de rivia','geralt de rivia'],[
    {type:'profissao',text:'Sou um caçador de monstros profissional.'},{type:'universo',text:'Minha história envolve o Continente.'},{type:'identidade',text:'Sou conhecido como o Lobo Branco.'}
  ]),
  entry('frodo','fantasia','medio',['frodo','frodo bolseiro','frodo baggins'],[
    {type:'universo',text:'Minha jornada passa pela Terra-média.'},{type:'objeto',text:'Carrego um anel extremamente perigoso.'},{type:'relacao',text:'Sam é meu grande companheiro de jornada.'}
  ]),
  entry('darth-vader','filmes','medio',['darth vader','darth vader star wars','anakin skywalker'],[
    {type:'universo',text:'Faço parte de Star Wars.'},{type:'aparencia',text:'Uso uma máscara preta e uma armadura.'},{type:'identidade',text:'Meu passado está ligado a Anakin Skywalker.'}
  ]),
  entry('jack-sparrow','filmes','medio',['jack sparrow','capitao jack sparrow','capitão jack sparrow'],[
    {type:'profissao',text:'Sou um pirata.'},{type:'aparencia',text:'Uso chapéu e tenho um estilo bem característico.'},{type:'universo',text:'Minha história envolve os Piratas do Caribe.'}
  ]),
  entry('neo','filmes','dificil',['neo','thomas anderson','thomas anderson matrix'],[
    {type:'universo',text:'Minha história envolve uma realidade simulada.'},{type:'identidade',text:'Meu nome é Thomas Anderson.'},{type:'habilidade',text:'Consigo desafiar as regras da Matrix.'}
  ]),
  entry('deadpool','herois','medio',['deadpool','wade wilson'],[
    {type:'identidade',text:'Meu nome é Wade Wilson.'},{type:'habilidade',text:'Tenho fator de cura acelerado.'},{type:'personalidade',text:'Sou conhecido por quebrar a quarta parede.'}
  ]),
  entry('pikachu-rival','games','medio',['charizard','charizard pokemon'],[
    {type:'aparencia',text:'Sou um Pokémon com aparência de dragão.'},{type:'habilidade',text:'Uso ataques de fogo.'},{type:'origem',text:'Faço parte da linha evolutiva de Charmander.'}
  ]),
  entry('ichigo','anime','medio',['ichigo','ichigo kurosaki'],[
    {type:'identidade',text:'Meu nome é Ichigo Kurosaki.'},{type:'habilidade',text:'Uso uma zanpakutō.'},{type:'origem',text:'Minha história envolve Soul Reapers.'}
  ]),
  entry('sailor-moon','anime','facil',['sailor moon','usagi','usagi tsukino'],[
    {type:'identidade',text:'Meu nome civil é Usagi Tsukino.'},{type:'aparencia',text:'Uso um uniforme de marinheira.'},{type:'habilidade',text:'Luto em nome da Lua.'}
  ]),
  entry('gojo','anime','medio',['gojo','satoru gojo'],[
    {type:'identidade',text:'Meu nome é Satoru Gojo.'},{type:'habilidade',text:'Sou conhecido pelos Seis Olhos.'},{type:'universo',text:'Faço parte de Jujutsu Kaisen.'}
  ]),
  entry('deku','anime','facil',['deku','izuku midoriya','izuku'],[
    {type:'identidade',text:'Meu nome é Izuku Midoriya.'},{type:'habilidade',text:'Possuo o One For All.'},{type:'universo',text:'Estudo para ser herói.'}
  ]),
  entry('ash','anime','facil',['ash','ash ketchum','ash pokemon'],[
    {type:'profissao',text:'Sou treinador Pokémon.'},{type:'relacao',text:'Meu parceiro mais famoso é Pikachu.'},{type:'objetivo',text:'Quero me tornar um grande mestre Pokémon.'}
  ]),
  entry('nezuko','anime','facil',['nezuko','nezuko kamado'],[
    {type:'relacao',text:'Sou irmã de Tanjiro.'},{type:'aparencia',text:'Tenho uma mordaça de bambu.'},{type:'universo',text:'Faço parte de Demon Slayer.'}
  ]),
  entry('sonic','games','facil',['sonic','sonic the hedgehog'],[
    {type:'aparencia',text:'Sou azul e tenho espinhos.'},{type:'habilidade',text:'Sou extremamente veloz.'},{type:'universo',text:'Meu rival famoso é Dr. Eggman.'}
  ]),
  entry('pacman','games','facil',['pacman','pac man'],[
    {type:'aparencia',text:'Tenho formato redondo e sou amarelo.'},{type:'objetivo',text:'Como pontos e fujo de fantasmas.'},{type:'universo',text:'Vivo em labirintos.'}
  ]),
  entry('lara-croft','games','medio',['lara croft','lara-croft'],[
    {type:'profissao',text:'Sou arqueóloga e aventureira.'},{type:'habilidade',text:'Exploro tumbas e locais perigosos.'},{type:'identidade',text:'Meu nome é Lara Croft.'}
  ]),
  entry('flash','herois','facil',['flash','the flash'],[
    {type:'habilidade',text:'Minha principal habilidade é a supervelocidade.'},{type:'identidade',text:'Um dos meus nomes civis é Barry Allen.'},{type:'universo',text:'Faço parte da DC.'}
  ]),
  entry('coringa','filmes','medio',['coringa','joker'],[
    {type:'aparencia',text:'Meu visual é associado a maquiagem de palhaço.'},{type:'relacao',text:'Sou um dos maiores inimigos do Batman.'},{type:'personalidade',text:'Sou conhecido pelo riso e pelo caos.'}
  ]),
  entry('eleven','series','medio',['eleven','onze','jane hopper'],[
    {type:'habilidade',text:'Tenho poderes mentais.'},{type:'universo',text:'Minha história envolve o Mundo Invertido.'},{type:'identidade',text:'Também sou conhecida como Eleven.'}
  ]),
  entry('walter-white','series','dificil',['walter white','walter-white','heisenberg'],[
    {type:'profissao',text:'Começo minha história como professor de química.'},{type:'identidade',text:'Também sou conhecido como Heisenberg.'},{type:'universo',text:'Minha história envolve Breaking Bad.'}
  ]),
  entry('michael-scott','series','medio',['michael scott'],[
    {type:'profissao',text:'Sou gerente de um escritório.'},{type:'personalidade',text:'Tenho um jeito peculiar de lidar com colegas.'},{type:'universo',text:'Faço parte de The Office.'}
  ]),
  entry('gandalf','fantasia','medio',['gandalf','gandalf o cinzento','gandalf the grey'],[
    {type:'universo',text:'Vivo na Terra-média.'},{type:'habilidade',text:'Sou um poderoso mago.'},{type:'relacao',text:'Ajudo uma companhia em uma grande jornada.'}
  ]),
  entry('legolas','fantasia','medio',['legolas','legolas senhor dos aneis'],[
    {type:'habilidade',text:'Sou um excelente arqueiro.'},{type:'origem',text:'Sou um elfo.'},{type:'universo',text:'Faço parte da Terra-média.'}
  ]),
  entry('hermione','fantasia','facil',['hermione','hermione granger'],[
    {type:'identidade',text:'Meu nome é Hermione Granger.'},{type:'habilidade',text:'Sou uma bruxa muito estudiosa.'},{type:'relacao',text:'Sou amiga de Harry e Ron.'}
  ]),
  entry('aragorn','fantasia','medio',['aragorn','aragorn senhor dos aneis','passolargo'],[
    {type:'identidade',text:'Também sou conhecido como Passolargo.'},{type:'origem',text:'Tenho ligação com a linhagem dos reis.'},{type:'habilidade',text:'Sou um habilidoso guerreiro.'}
  ]),
  entry('yennefer','fantasia','dificil',['yennefer','yennefer de vengerberg'],[
    {type:'identidade',text:'Meu nome é Yennefer de Vengerberg.'},{type:'habilidade',text:'Sou uma poderosa feiticeira.'},{type:'relacao',text:'Tenho uma ligação importante com Geralt.'}
  ]),

]);

export function normalizeWhoamiAnswer(value) {
  return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
}

const CATEGORY_ALIASES = Object.freeze({
  anime:'anime', animes:'anime',
  game:'games', games:'games', jogos:'games',
  heroi:'herois', herois:'herois', herói:'herois', heróis:'herois',
  filme:'filmes', filmes:'filmes',
  serie:'series', series:'series', série:'series', séries:'series',
  fantasia:'fantasia'
});

const DIFFICULTY_ALIASES = Object.freeze({
  facil:'facil', fácil:'facil', easy:'facil',
  medio:'medio', médio:'medio', medium:'medio',
  dificil:'dificil', difícil:'dificil', hard:'dificil'
});

export function resolveWhoamiCategory(value='geral') {
  const key = String(value ?? 'geral').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  return CATEGORY_ALIASES[key] || (key === 'geral' || !key ? 'geral' : null);
}

export function resolveWhoamiDifficulty(value=null) {
  if (value == null || String(value).trim() === '') return null;
  const key = String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();
  return DIFFICULTY_ALIASES[key] || null;
}

export function findWhoamiEntry(category='geral', difficulty=null) {
  const resolvedCategory = resolveWhoamiCategory(category) || 'geral';
  const resolvedDifficulty = resolveWhoamiDifficulty(difficulty);
  let pool = WHOAMI_BANK.filter(x => resolvedCategory === 'geral' || x.category === resolvedCategory);
  if (resolvedDifficulty) {
    const filtered = pool.filter(x => x.difficulty === resolvedDifficulty);
    if (filtered.length) pool = filtered;
  }
  if (!pool.length) pool = [...WHOAMI_BANK];
  return pool[Math.floor(Math.random()*pool.length)];
}

export function isWhoamiAnswer(entry, answer) {
  const value = normalizeWhoamiAnswer(answer);
  return entry.answers.some(a => normalizeWhoamiAnswer(a) === value);
}

export const WHOAMI_CATEGORIES = Object.freeze([...new Set(WHOAMI_BANK.map(x=>x.category))]);
export const WHOAMI_DIFFICULTIES = Object.freeze(['facil','medio','dificil']);
