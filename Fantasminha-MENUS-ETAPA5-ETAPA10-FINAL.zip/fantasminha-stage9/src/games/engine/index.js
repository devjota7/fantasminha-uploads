/** Game Engine arquitetural: adapter para o engine de sessões existente. */
export { default } from '../../services/gameEngine.js';
export * from '../../services/gameEngine.js';
