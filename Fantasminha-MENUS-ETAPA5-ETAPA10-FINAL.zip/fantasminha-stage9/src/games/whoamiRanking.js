import { listStats, listAllStats } from '../services/statsEngine.js';

function project(row) {
  const game = row.games?.whoami || {};
  return { userId: row.userId, plays: Number(game.plays)||0, correct: Number(game.wins)||0, errors: Number(game.errors)||0, points: Number(game.score)||0, bestStreak: Number(game.bestStreak)||0 };
}

function sortRows(rows, limit=10) {
  return rows.filter(x => x.plays > 0 || x.correct > 0 || x.errors > 0 || x.points > 0)
    .sort((a,b)=>b.points-a.points||b.correct-a.correct||a.errors-b.errors||b.bestStreak-a.bestStreak||a.userId.localeCompare(b.userId))
    .slice(0,Math.max(1,Math.min(50,Number(limit)||10)))
    .map((x,i)=>({...x,position:i+1}));
}

export function rankWhoamiRows(rows, limit=10){ return sortRows(rows.map(project),limit); }

export function whoamiRanking(groupId, limit=10, scope='local') {
  const mode=String(scope||'local').toLowerCase();
  if(mode==='global') {
    const map=new Map();
    for(const row of listAllStats()) {
      const x=project(row); if(!x.userId) continue;
      const cur=map.get(x.userId)||{userId:x.userId,plays:0,correct:0,errors:0,points:0,bestStreak:0};
      cur.plays+=x.plays; cur.correct+=x.correct; cur.errors+=x.errors; cur.points+=x.points; cur.bestStreak=Math.max(cur.bestStreak,x.bestStreak); map.set(x.userId,cur);
    }
    return sortRows([...map.values()],limit);
  }
  return rankWhoamiRows(listStats(groupId),limit);
}

export function whoamiPlayerStats(groupId,userId) {
  const local=whoamiRanking(groupId,50,'local').find(x=>x.userId===userId) || {userId,plays:0,correct:0,errors:0,points:0,bestStreak:0,position:null};
  return local;
}

export default { whoamiRanking, whoamiPlayerStats, rankWhoamiRows };
