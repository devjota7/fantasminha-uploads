import { GARTIC_CATEGORIES } from './data/words.js';
export function selectCategory(preferred=null){ if(!GARTIC_CATEGORIES.length) throw new Error('Gartic em manutenção: categorias indisponíveis.'); const c=String(preferred||'').trim().toLowerCase(); return GARTIC_CATEGORIES.includes(c)?c:GARTIC_CATEGORIES[Math.floor(Math.random()*GARTIC_CATEGORIES.length)]; }
export default {selectCategory};
