import { dossierHeader, gameFooter, graffitiHeader } from '../gamePresentation.js';

const label = { easy: 'Fácil', medium: 'Médio', hard: 'Difícil', insane: 'Insano' };
const cat = { animais: 'Animais 🐾', objetos: 'Objetos 📦', comidas: 'Comidas 🍕', lugares: 'Lugares 🌎', natureza: 'Natureza 🌿', profissões: 'Profissões 👷', veículos: 'Veículos 🚗', esportes: 'Esportes ⚽', tecnologia: 'Tecnologia 💻', personagens: 'Personagens 🎭', fantasia: 'Fantasia 🔮', casa: 'Casa 🏠', escola: 'Escola 📚', música: 'Música 🎵', espaço: 'Espaço 🚀', 'corpo humano': 'Corpo humano', transporte: 'Transporte', ferramentas: 'Ferramentas', roupas: 'Roupas', bebidas: 'Bebidas', 'categoria surpresa': 'Categoria surpresa 🎲' };
const mask = word => [...word].map(char => char === ' ' ? '  ' : /[\p{L}\p{N}]/u.test(char) ? '_' : char).join(' ');

export function preparing() {
  return [graffitiHeader('Preparando o desenho'), 'A arte está atravessando o véu…', 'A rodada começa assim que a imagem chegar.'].join('\n');
}

export function round({ category, difficulty, word, timeoutMs = 60000 }) {
  return [
    graffitiHeader('Gartic · adivinhe o desenho'),
    `◈ Categoria: ${cat[category] || category}`,
    `▧ Dificuldade: ${label[difficulty] || difficulty}`,
    `Letras: ${mask(word)}`,
    '',
    'O que aparece no desenho? Envie seu palpite no chat.',
    `⌛ Tempo: ${Math.round(timeoutMs / 1000)} segundos.`,
    '_Imagem original desta rodada._'
  ].join('\n');
}

export function won({ winnerName, word, score }) {
  return [
    dossierHeader('Gartic · rodada encerrada'),
    `Vencedor: @${String(winnerName || 'Jogador').split('@')[0]}`,
    `Desenho: ${String(word).toUpperCase()}`,
    `Pontuação: +${score} pontos`,
    '',
    gameFooter('sucesso', 'game:gartic:result')
  ].join('\n');
}

export function expired({ word }) {
  return [
    dossierHeader('Gartic · tempo encerrado'),
    'Ninguém acertou dentro do prazo.',
    `Desenho revelado: ${String(word).toUpperCase()}`,
    '',
    gameFooter('info', 'game:gartic:timeout')
  ].join('\n');
}

export function failed() {
  return [graffitiHeader('Gartic · falha na rodada'), 'Não foi possível preparar a imagem.', 'Tente iniciar outra rodada com `×gartic`.', gameFooter('erro', 'game:gartic:error')].join('\n');
}

export function busy() {
  return [graffitiHeader('Gartic · partida ativa'), 'Já existe uma rodada acontecendo neste grupo.', 'Aguarde o resultado antes de iniciar outra.'].join('\n');
}

export function maintenance() {
  return [dossierHeader('Gartic em manutenção'), 'O catálogo de palavras ainda não foi instalado.', 'A partida está bloqueada até a manutenção ser concluída.', gameFooter('info', 'game:gartic:maintenance')].join('\n');
}

export default { preparing, round, won, expired, failed, busy, maintenance };
