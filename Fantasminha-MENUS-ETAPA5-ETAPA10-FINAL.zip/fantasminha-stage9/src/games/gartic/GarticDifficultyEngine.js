import { GARTIC_DIFFICULTIES } from './data/words.js';
export function selectDifficulty(preferred=null){ if(!GARTIC_DIFFICULTIES.length) throw new Error('Gartic em manutenção: dificuldades indisponíveis.'); const d=String(preferred||'').trim().toLowerCase(); return GARTIC_DIFFICULTIES.includes(d)?d:GARTIC_DIFFICULTIES[Math.floor(Math.random()*GARTIC_DIFFICULTIES.length)]; }
export default {selectDifficulty};
