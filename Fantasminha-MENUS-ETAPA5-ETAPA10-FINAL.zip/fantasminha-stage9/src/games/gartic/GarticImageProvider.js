import { env } from '../../config/env.js';
import { GarticConfig } from './GarticConfig.js';
import { fantasminhaApi } from '../../services/api/index.js';

const timeoutFetch = async (url, options, ms) => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms); timer.unref?.();
  try { return await fetch(url, { ...options, signal: controller.signal }); }
  finally { clearTimeout(timer); }
};

function resolveConfig(){
  if (GarticConfig.imageApiUrl) return { url:GarticConfig.imageApiUrl, key:GarticConfig.imageApiKey, model:GarticConfig.imageModel };
  if (env.OPENAI_API_KEY) return { url:'https://api.openai.com/v1/images/generations', key:env.OPENAI_API_KEY, model:env.GARTIC_IMAGE_MODEL || env.OPENAI_IMAGE_MODEL || 'gpt-image-2.5-flare' };
  return null;
}

async function fetchImageUrl(url){
  const res=await timeoutFetch(url,{headers:{'user-agent':'Fantasminha-Gartic/11.7.10'}},GarticConfig.generationTimeoutMs);
  if(!res.ok) throw new Error(`Download da imagem falhou (${res.status})`);
  const ab=await res.arrayBuffer(); return Buffer.from(ab);
}

export async function generate(prompt, context={}){
  if (fantasminhaApi.enabled) {
    try {
      const result=await fantasminhaApi.aiImage({prompt,size:GarticConfig.imageSize},{...context,command:'gartic'});
      const artifactId=result?.data?.artifactId;
      if (artifactId) {
        const file=await fantasminhaApi.artifact(artifactId,{...context,command:'gartic'});
        if (file?.buffer) return file.buffer;
      }
    } catch (error) {
      throw error;
    }
  }
  const cfg=resolveConfig();
  if(!cfg) throw new Error('Nenhum provedor de geração de imagem do Gartic está configurado.');
  const res=await timeoutFetch(cfg.url,{method:'POST',headers:{'content-type':'application/json',...(cfg.key?{authorization:`Bearer ${cfg.key}`}:{})},body:JSON.stringify({model:cfg.model,prompt,n:1,size:GarticConfig.imageSize,response_format:'b64_json'})},GarticConfig.generationTimeoutMs);
  if(!res.ok){ const text=await res.text().catch(()=> ''); throw new Error(`Geração de imagem falhou (${res.status}): ${text.slice(0,180)}`); }
  const data=await res.json(); const item=data?.data?.[0] || data?.images?.[0] || data?.image || data;
  if(item?.b64_json) return Buffer.from(item.b64_json,'base64');
  if(typeof item === 'string' && /^[A-Za-z0-9+/=]+$/.test(item)) return Buffer.from(item,'base64');
  if(item?.url) return fetchImageUrl(item.url);
  if(item?.data && typeof item.data === 'string') { const m=item.data.match(/^data:[^;]+;base64,(.+)$/); if(m) return Buffer.from(m[1],'base64'); }
  if(data?.image_url) return fetchImageUrl(data.image_url);
  throw new Error('O provedor não retornou uma imagem utilizável.');
}
export function providerInfo(){const c=resolveConfig();return c?{configured:true,model:c.model,url:c.url}: {configured:false};}
export default {generate,providerInfo};
