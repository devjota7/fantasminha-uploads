export function scoreRound(participants = [], validations = {}, config = {}) {
  const duplicateGroups = new Map();
  for (const [user, cats] of Object.entries(validations || {})) {
    for (const [category, value] of Object.entries(cats || {})) {
      if (value?.status === 'VALID' && value.answerNormalized) {
        const key = `${category}::${value.answerNormalized}`;
        if (!duplicateGroups.has(key)) duplicateGroups.set(key, []);
        duplicateGroups.get(key).push(user);
      }
    }
  }
  const scoring = config.scoring || {};
  const speed = config.speedBonus || {};
  for (const cats of Object.values(validations || {})) {
    for (const [category, value] of Object.entries(cats || {})) {
      if (!value || value.status !== 'VALID') { if (value) value.points = 0; continue; }
      const key = `${category}::${value.answerNormalized}`;
      const users = duplicateGroups.get(key) || [];
      const duplicate = users.length > 1;
      if (duplicate && config.rules?.allowDuplicateAnswers === false) {
        value.status = 'INVALID'; value.reason = 'Resposta repetida não permitida nesta partida.'; value.points = 0; continue;
      }
      value.status = duplicate ? 'VALID_DUPLICATE' : 'VALID_UNIQUE';
      let points = duplicate ? Number(scoring.duplicate ?? 5) : Number(scoring.mode === 'competitive' ? (scoring.unique ?? 15) : (scoring.valid ?? 10));
      const submittedAt = Number(value.submittedAt || 0);
      const startedAt = Number(value.roundStartedAt || 0);
      if (speed.enabled && submittedAt && startedAt && submittedAt >= startedAt) {
        const elapsed = (submittedAt - startedAt) / 1000;
        const threshold = Math.max(1, Number(speed.thresholdSeconds || 10));
        const maxBonus = Math.max(0, Number(speed.maxBonus || 0));
        if (elapsed <= threshold && maxBonus > 0) {
          const ratio = Math.max(0, Math.min(1, (threshold - elapsed) / threshold));
          const bonus = Math.min(maxBonus, Math.floor(maxBonus * ratio));
          points += bonus;
          value.speedBonus = bonus;
        }
      }
      value.points = Math.max(0, Math.floor(points));
    }
  }
  return participants.map(p => {
    const r = validations[p.identityKey] || {};
    return { identityKey: p.identityKey, userId: p.canonicalJid || null, results: r, points: Object.values(r).reduce((a, v) => a + Number(v.points || 0), 0) };
  });
}
export default { scoreRound };
