export const STOP_LIMITS = Object.freeze({
  rounds: { min: 1, max: 20, default: 5 },
  roundTimeSeconds: { min: 15, max: 180, default: 45 },
  maxPlayers: { min: 2, max: 50, default: 20 },
  categories: { min: 3, max: 10, default: 8 },
  basePoints: { min: 1, max: 100, default: 10 },
  duplicatePoints: { min: 0, max: 100, default: 5 },
  speedBonus: { min: 0, max: 25, default: 5 },
  speedThresholdSeconds: { min: 1, max: 60, default: 10 }
});

export const STOP_PRESETS = Object.freeze({
  rapido: { name: 'Rápido', rounds: 5, roundTimeSeconds: 20, maxPlayers: 10, categoryCount: 6, validationMode: 'fast', aiEnabled: false, speedBonusEnabled: false },
  normal: { name: 'Normal', rounds: 5, roundTimeSeconds: 45, maxPlayers: 20, categoryCount: 8, validationMode: 'strict', aiEnabled: true, speedBonusEnabled: false },
  competitivo: { name: 'Competitivo', rounds: 10, roundTimeSeconds: 30, maxPlayers: 20, categoryCount: 10, validationMode: 'strict_ai', aiEnabled: true, speedBonusEnabled: true }
});

export const DEFAULT_CATEGORIES = Object.freeze([
  'Animal', 'Comida', 'Pessoa', 'Lugar', 'Objeto', 'Profissão', 'Filme/Série', 'Jogo', 'Planta', 'Marca'
]);

export function clampInt(value, limits) {
  const n = Number(value);
  if (!Number.isInteger(n) || n < limits.min || n > limits.max) return null;
  return n;
}

export function normalizeCategoryList(raw) {
  const arr = Array.isArray(raw) ? raw : String(raw ?? '').split(/[\n,;|]+/);
  const seen = new Set();
  const out = [];
  for (const item of arr) {
    const name = String(item ?? '').replace(/\s+/g, ' ').trim().slice(0, 60);
    const key = name.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
    if (!name || !key || seen.has(key)) continue;
    seen.add(key);
    out.push(name);
    if (out.length >= STOP_LIMITS.categories.max) break;
  }
  return out;
}

export function makeStopConfig(overrides = {}) {
  const categories = normalizeCategoryList(overrides.categories?.length ? overrides.categories : DEFAULT_CATEGORIES);
  return {
    schemaVersion: 2,
    preset: overrides.preset || 'normal',
    rounds: clampInt(overrides.rounds ?? STOP_LIMITS.rounds.default, STOP_LIMITS.rounds) || STOP_LIMITS.rounds.default,
    roundTimeSeconds: clampInt(overrides.roundTimeSeconds ?? STOP_LIMITS.roundTimeSeconds.default, STOP_LIMITS.roundTimeSeconds) || STOP_LIMITS.roundTimeSeconds.default,
    categories,
    letterMode: overrides.letterMode === 'fixed' ? 'fixed' : overrides.letterMode === 'pool' ? 'pool' : 'random',
    fixedLetter: String(overrides.fixedLetter || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 1) || null,
    allowedLetters: [...new Set(String(overrides.allowedLetters || '').toUpperCase().replace(/[^A-Z]/g, '').split(''))],
    maxPlayers: clampInt(overrides.maxPlayers ?? STOP_LIMITS.maxPlayers.default, STOP_LIMITS.maxPlayers) || STOP_LIMITS.maxPlayers.default,
    scoring: {
      mode: ['normal', 'competitive'].includes(overrides.scoring?.mode) ? overrides.scoring.mode : 'normal',
      valid: clampInt(overrides.scoring?.valid ?? STOP_LIMITS.basePoints.default, STOP_LIMITS.basePoints) || STOP_LIMITS.basePoints.default,
      unique: clampInt(overrides.scoring?.unique ?? 15, STOP_LIMITS.basePoints) || 15,
      duplicate: clampInt(overrides.scoring?.duplicate ?? STOP_LIMITS.duplicatePoints.default, STOP_LIMITS.duplicatePoints) ?? STOP_LIMITS.duplicatePoints.default,
      invalid: 0
    },
    speedBonus: {
      enabled: Boolean(overrides.speedBonus?.enabled ?? overrides.speedBonusEnabled),
      maxBonus: clampInt(overrides.speedBonus?.maxBonus ?? STOP_LIMITS.speedBonus.default, STOP_LIMITS.speedBonus) ?? STOP_LIMITS.speedBonus.default,
      thresholdSeconds: clampInt(overrides.speedBonus?.thresholdSeconds ?? STOP_LIMITS.speedThresholdSeconds.default, STOP_LIMITS.speedThresholdSeconds) || STOP_LIMITS.speedThresholdSeconds.default
    },
    validation: {
      mode: ['fast', 'strict', 'strict_ai'].includes(overrides.validation?.mode || overrides.validationMode) ? (overrides.validation?.mode || overrides.validationMode) : 'strict',
      deterministicFirst: true,
      aiEnabled: Boolean(overrides.validation?.aiEnabled ?? overrides.aiEnabled ?? true),
      minConfidence: Math.min(1, Math.max(0, Number(overrides.validation?.minConfidence ?? 0.6) || 0.6))
    },
    rules: {
      allowDuplicateAnswers: overrides.rules?.allowDuplicateAnswers !== false,
      extraTime: Boolean(overrides.rules?.extraTime),
      elimination: Boolean(overrides.rules?.elimination),
      autoJoin: Boolean(overrides.rules?.autoJoin)
    },
    createdAt: Number(overrides.createdAt) || Date.now(),
    updatedAt: Date.now()
  };
}

export function applyPreset(name) {
  const key = String(name || '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const preset = STOP_PRESETS[key] || STOP_PRESETS.normal;
  return makeStopConfig({
    preset: key,
    rounds: preset.rounds,
    roundTimeSeconds: preset.roundTimeSeconds,
    maxPlayers: preset.maxPlayers,
    categories: DEFAULT_CATEGORIES.slice(0, preset.categoryCount),
    validationMode: preset.validationMode,
    aiEnabled: preset.aiEnabled,
    speedBonusEnabled: preset.speedBonusEnabled,
    scoring: { mode: key === 'competitivo' ? 'competitive' : 'normal' }
  });
}

export function validateStopConfig(config) {
  const c = makeStopConfig(config);
  const errors = [];
  if (c.categories.length < STOP_LIMITS.categories.min) errors.push(`mínimo de ${STOP_LIMITS.categories.min} categorias`);
  if (c.letterMode === 'fixed' && !c.fixedLetter) errors.push('letra fixa inválida');
  if (c.letterMode === 'pool' && !c.allowedLetters.length) errors.push('lista de letras vazia');
  if (c.rounds < STOP_LIMITS.rounds.min || c.rounds > STOP_LIMITS.rounds.max) errors.push('número de rodadas fora do limite');
  if (c.roundTimeSeconds < STOP_LIMITS.roundTimeSeconds.min || c.roundTimeSeconds > STOP_LIMITS.roundTimeSeconds.max) errors.push('tempo fora do limite');
  if (c.maxPlayers < STOP_LIMITS.maxPlayers.min || c.maxPlayers > STOP_LIMITS.maxPlayers.max) errors.push('limite de jogadores fora do limite');
  return { ok: errors.length === 0, errors, config: c };
}

export function formatStopConfig(c) {
  const config = makeStopConfig(c);
  const letter = config.letterMode === 'fixed' ? config.fixedLetter : config.letterMode === 'pool' ? config.allowedLetters.join('') : '🎲 Aleatória';
  return [
    `🎮 Modo: ${config.preset || 'personalizado'}`,
    `🔢 Rodadas: ${config.rounds}`,
    `⏱️ Tempo: ${config.roundTimeSeconds}s`,
    `📚 Categorias: ${config.categories.length}`,
    `🔤 Letra: ${letter}`,
    `👥 Jogadores: ${config.maxPlayers}`,
    `🏆 Pontuação: ${config.scoring.mode}`,
    `⚡ Bônus: ${config.speedBonus.enabled ? `ON (+${config.speedBonus.maxBonus})` : 'OFF'}`,
    `🤖 Validação: ${config.validation.mode}`,
    `🔄 Repetição: ${config.rules.allowDuplicateAnswers ? 'ON' : 'OFF'}`,
    `⏳ Tempo extra: ${config.rules.extraTime ? 'ON' : 'OFF'}`,
    `🚫 Eliminação: ${config.rules.elimination ? 'ON' : 'OFF'}`
  ].join('\n');
}
