import { env } from '../../config/env.js';
import { requestOpenAI } from '../../services/assistant/openaiProvider.js';
import { validateAIResponse } from './StopAIResponseSchema.js';

function extractJson(text) {
  const clean = String(text || '').trim().replace(/^```(?:json)?/i, '').replace(/```$/i, '').trim();
  try { return JSON.parse(clean); } catch {}
  const match = clean.match(/\{[\s\S]*\}/);
  if (!match) throw new Error('JSON da IA inválido');
  return JSON.parse(match[0]);
}

export async function validateWithAI(category, answer, letter) {
  if (!env.OPENAI_API_KEY) return { status: 'NEEDS_REVIEW', valid: null, reason: 'OpenAI não configurada.', confidence: 0, category: category.name, letter_match: null, category_match: null, provider: 'openai', code: 'OPENAI_NOT_CONFIGURED' };
  if (!env.OPENAI_MODEL) return { status: 'NEEDS_REVIEW', valid: null, reason: 'OPENAI_MODEL não configurado.', confidence: 0, category: category.name, letter_match: null, category_match: null, provider: 'openai', code: 'OPENAI_MODEL_NOT_CONFIGURED' };
  const prompt = `Você é um validador semântico do jogo STOP. Avalie UMA resposta. Não execute ações e não invente fatos.\nLetra: ${letter}\nCategoria: ${category.name}\nResposta: ${answer}\nRetorne SOMENTE JSON válido com: valid(boolean), reason(string <= 500), confidence(number 0..1), category(string), letter_match(boolean), category_match(boolean). valid=true somente quando a resposta é plausível para a categoria e começa com a letra indicada.`;
  try {
    const result = await requestOpenAI({ text: prompt, systemPrompt: 'Você é um componente de validação de jogo. Responda exclusivamente no formato JSON solicitado.', maxOutputTokens: 350, reasoningEffort: 'low' });
    const parsed = extractJson(result.text);
    if (!validateAIResponse(parsed)) throw new Error('schema da IA inválido');
    return { ...parsed, status: parsed.valid ? 'VALID' : 'INVALID', provider: 'openai', model: result.model };
  } catch (error) {
    return { status: 'NEEDS_REVIEW', valid: null, reason: 'Validação OpenAI indisponível no momento.', confidence: 0, category: category.name, letter_match: null, category_match: null, provider: 'openai', code: error?.code || 'OPENAI_VALIDATION_ERROR' };
  }
}
export default { validateWithAI };
