import { publicMention, assertNoLidInOutput } from './StopIdentity.js';
export function renderParticipantMention(participant) { return publicMention(participant); }
export function safeRender(text) { assertNoLidInOutput(text); return String(text); }
export default { renderParticipantMention, safeRender };
