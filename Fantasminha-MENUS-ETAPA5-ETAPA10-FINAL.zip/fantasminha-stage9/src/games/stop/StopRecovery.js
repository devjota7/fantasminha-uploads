export function inspectStopOrphans({ games = [], sessions = {}, activeGameIds = new Set() } = {}) {
  const orphans = [];
  for (const [id, session] of Object.entries(sessions || {})) {
    if (!activeGameIds.has(session.gameId || id) && ['FINISHED','CANCELLED','EXPIRED'].indexOf(session.status) === -1) {
      orphans.push({ type: 'session_without_game', sessionId: id });
    }
  }
  for (const game of games || []) {
    const session = game?.state?.stopSession;
    if (game?.gameType === 'STOP' && !session) orphans.push({ type: 'game_without_session', gameId: game.gameId });
  }
  return orphans;
}

export function cleanupPrivateStates(states, now = Date.now(), ttlMs = 15 * 60 * 1000) {
  let removed = 0;
  for (const [userId, state] of Object.entries(states || {})) {
    if (now - Number(state?.updatedAt || state?.startedAt || 0) > ttlMs) {
      delete states[userId]; removed += 1;
    }
  }
  return removed;
}

export default { inspectStopOrphans, cleanupPrivateStates };
