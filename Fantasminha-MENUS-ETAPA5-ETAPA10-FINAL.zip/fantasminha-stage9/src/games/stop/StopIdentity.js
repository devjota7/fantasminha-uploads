import { resolveUserIdentity } from '../../platform/identity/resolver.js';

export async function resolveStopIdentity(ctx = {}, raw = null) {
  const requested = raw || ctx.sender || '';
  const identity = await resolveUserIdentity(ctx, requested);
  const canonicalJid = identity?.realJid || null;
  const identityKey = canonicalJid || (identity?.lid ? `lid:${identity.lid}` : String(requested || '').trim());
  return {
    identityKey,
    canonicalJid,
    aliases: [identity?.lid, requested].filter(Boolean).filter((v, i, a) => a.indexOf(v) === i),
    name: identity?.name || identity?.pushName || '',
    resolvable: Boolean(canonicalJid)
  };
}

export async function resolveStopParticipant(ctx, raw) {
  return resolveStopIdentity(ctx, raw);
}

export function publicMention(identityOrParticipant) {
  const jid = identityOrParticipant?.canonicalJid || identityOrParticipant?.jid || null;
  if (!jid || !jid.endsWith('@s.whatsapp.net')) return { text: 'participante', mentions: [] };
  return { text: `@${jid.split('@')[0]}`, mentions: [jid] };
}

export function assertNoLidInOutput(text) {
  if (/@lid/i.test(String(text || ''))) {
    const error = new Error('STOP output attempted to expose a LID');
    error.code = 'STOP_LID_OUTPUT_BLOCKED';
    throw error;
  }
}

export default { resolveStopIdentity, resolveStopParticipant, publicMention, assertNoLidInOutput };
