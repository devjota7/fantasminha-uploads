import { readCollection, updateCollection } from '../../database/store.js';
export const readStopCollection = (name, fallback = {}) => readCollection(name, fallback);
export const writeStopCollection = (name, mutator, fallback = {}) => updateCollection(name, mutator, fallback);
export default { readStopCollection, writeStopCollection };
