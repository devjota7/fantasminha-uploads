const norm = s => String(s ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
export function validateDeterministic(category, answer, letter) {
  const v = norm(answer), l = norm(letter);
  if (!v) return { status: 'EMPTY', valid: false, reason: 'Resposta vazia.', confidence: 1 };
  if (v[0] !== l) return { status: 'INVALID', valid: false, reason: `A resposta não começa com ${letter}.`, confidence: 1, letterMatch: false };
  if (v.length > 120) return { status: 'INVALID', valid: false, reason: 'Resposta longa demais.', confidence: 1 };
  if (/^(asdf|qwerty|xxx|teste)$/i.test(v)) return { status: 'INVALID', valid: false, reason: 'Resposta sem conteúdo válido.', confidence: 1 };
  return { status: 'PENDING_AI', valid: null, reason: 'Resposta plausível; validação semântica pendente.', confidence: 0.5, letterMatch: true, categoryMatch: true };
}
export default { validateDeterministic };
