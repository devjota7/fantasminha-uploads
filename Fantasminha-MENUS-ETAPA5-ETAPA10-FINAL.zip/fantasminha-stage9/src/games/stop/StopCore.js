import { env } from '../../config/env.js';
import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import game from '../../services/gameEngine.js';
import stats from '../../services/statsEngine.js';
import { emit } from '../../events/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import { configuredOwner } from '../../core/permissions.js';
import { parseStopAnswers } from './StopAnswerParser.js';
import { validateDeterministic } from './StopAnswerValidator.js';
import { validateWithAI } from './StopAIValidator.js';
import { scoreRound } from './StopScoreEngine.js';
import { STOP_STATES } from './StopStateMachineConstants.js';
import { canTransition, transition } from './StopStateMachine.js';
import { resolveStopIdentity, publicMention, assertNoLidInOutput } from './StopIdentity.js';
import { STOP_LIMITS, STOP_PRESETS, makeStopConfig, applyPreset, normalizeCategoryList, validateStopConfig, formatStopConfig } from './StopConfig.js';
import { cleanupPrivateStates, inspectStopOrphans } from './StopRecovery.js';

export { STOP_STATES };
export const ROUND_MS = STOP_LIMITS.roundTimeSeconds.default * 1000;
export const LOBBY_MS = 60_000;
const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
const locks = new Map();
const pendingTimers = new Map();
const n = s => String(s ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
const now = () => Date.now();
const uid = ctx => ctx?.sender || ctx?.participant || 'unknown';
const gid = ctx => ctx?.from || 'private';
const mid = ctx => ctx?.message?.key?.id || ctx?.key?.id || null;

const STOP_CODE_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';

const lock = (key, fn) => {
  const prev = locks.get(key) || Promise.resolve();
  let release;
  const cur = new Promise(resolve => { release = resolve; });
  locks.set(key, prev.then(() => cur));
  return prev.then(async () => {
    try { return await fn(); }
    finally {
      release();
      if (locks.get(key) === cur) locks.delete(key);
    }
  });
};

async function audit(action, session, extra = {}) {
  try {
    await recordAudit({
      actor: extra.userId || session?.createdBy || null,
      target: session?.groupId || null,
      action,
      scope: session?.groupId || null,
      details: { ...(extra.details || {}), sessionId: session?.sessionId || null }
    });
  } catch {}
}

export function generateStopCode() {
  const db = readCollection('stop_sessions', { byId: {}, byCode: {} });
  let codeValue;
  do {
    const bytes = crypto.randomBytes(8);
    let body = '';
    for (const byte of bytes) body += STOP_CODE_ALPHABET[byte % STOP_CODE_ALPHABET.length];
    codeValue = `STP-${body}`;
  } while (db.byCode?.[codeValue]);
  return codeValue;
}

function configKey(userId) { return String(userId); }
function emptyConfig() { return makeStopConfig({ categories: [], createdAt: now() }); }
function sessionFromGame(g) { return g?.state?.stopSession || null; }
function gameActive(g) { return g && g.gameType === 'STOP' && ['WAITING', 'ACTIVE', 'RESOLVING'].includes(g.status) && ![STOP_STATES.FINISHED, STOP_STATES.CANCELLED, STOP_STATES.EXPIRED].includes(g.state?.stopSession?.status); }

export function getSessionByGroup(groupId) { return game.listActiveGames(groupId).find(gameActive) || null; }
export function getSessionByCode(stopCode) {
  const normalized = String(stopCode || '').trim().toUpperCase();
  if (!/^STP-[A-Z0-9]{8}$/.test(normalized)) return null;
  const db = readCollection('stop_sessions', { byId: {}, byCode: {} });
  const id = db.byCode?.[normalized];
  if (id && db.byId?.[id]) return db.byId[id];
  const active = game.listActiveGames().find(g => gameActive(g) && g.state?.stopSession?.stopCode === normalized);
  const recovered = active?.state?.stopSession || null;
  if (recovered) void persistSession(recovered).catch(() => {});
  return recovered;
}
export function getConfig(userId) { return readCollection('stop_user_configs', { byId: {} }).byId?.[configKey(userId)] || null; }

export function isStopPrivateInputAllowed(userId, text = '') {
  const id = String(userId || '').trim();
  if (!id) return false;
  const raw = String(text || '').trim();
  const privateState = readCollection('stop_private_state', { byUser: {} }).byUser?.[id];
  if (privateState?.step) return true;
  if (/^STP-[A-Z0-9]{8}$/i.test(raw)) return !!getSessionByCode(raw);
  return game.listActiveGames().filter(gameActive).some(g => {
    const s = sessionFromGame(g);
    return s?.participants?.some(p => p.identityKey === id || p.userId === id || p.canonicalJid === id);
  });
}

async function saveConfig(userId, patch) {
  return updateCollection('stop_user_configs', db => {
    db.byId ??= {};
    const prev = db.byId[configKey(userId)] || emptyConfig();
    db.byId[configKey(userId)] = { ...prev, ...patch, updatedAt: now() };
    return db;
  }, { byId: {} }).then(db => db.byId[configKey(userId)]);
}

function configMenuText(config = makeStopConfig()) {
  return `╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   ⚙️ CONFIGURAÇÃO\n╰━━━━━━━━━━━━━━━━━━╯\n\nEscolha um modo inicial:\n\n1️⃣ ⚡ Rápido\n2️⃣ 🎯 Normal\n3️⃣ 🔥 Competitivo\n4️⃣ 🎨 Personalizado\n\n${formatStopConfig(config)}\n\nDepois você poderá editar tudo no PV.\n\nDigite *cancelar* para sair.\n╰━━━━━━━━━━━━━━━━━━╯`;
}

function editorText(config) {
  return `╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   ✏️ EDITOR\n╰━━━━━━━━━━━━━━━━━━╯\n\n${formatStopConfig(config)}\n\nComandos de edição:\n• tempo 60\n• rodadas 10\n• jogadores 20\n• categorias Animal, Comida, Lugar\n• letra A\n• letras ABCDE\n• modo normal|competitivo\n• bonus on|off\n• ia on|off\n• repeticao on|off\n• extra on|off\n• eliminacao on|off\n• revisar\n• finalizar\n• cancelar\n\n💡 A configuração só congela quando a partida abrir o lobby.\n╰━━━━━━━━━━━━━━━━━━╯`;
}

function reviewText(config) {
  return `╭━━━━━━━━━━━━━━━━━━╮\n       👻 STOP\n   🔎 REVISÃO FINAL\n╰━━━━━━━━━━━━━━━━━━╯\n\n${formatStopConfig(config)}\n\n1️⃣ Salvar configuração\n2️⃣ Voltar a editar\n3️⃣ Cancelar\n\n╰━━━━━━━━━━━━━━━━━━╯`;
}

export async function beginConfig(ctx) {
  const userId = uid(ctx);
  const config = applyPreset('normal');
  await saveConfig(userId, { ...config, status: 'CONFIGURING', deletedAt: null });
  await updateCollection('stop_private_state', db => {
    db.byUser ??= {};
    db.byUser[userId] = { step: 'CONFIG_MENU', startedAt: now(), updatedAt: now() };
    return db;
  }, { byUser: {} });
  await audit('STOP_CONFIG_STARTED', null, { userId });
  await emit('STOP_CONFIG_STARTED', { userId });
  await ctx.sendMessage?.(userId, { text: configMenuText(config) });
  return { handled: true };
}

async function expirePrivateState(userId, state) {
  await updateCollection('stop_private_state', db => { delete db.byUser?.[userId]; return db; }, { byUser: {} });
  const c = getConfig(userId);
  if (c?.status === 'CONFIGURING') await saveConfig(userId, { status: 'EXPIRED', expiredAt: now() });
  await audit('STOP_CONFIG_EXPIRED', null, { userId });
  await emit('STOP_CONFIG_EXPIRED', { userId });
}

function parseOnOff(value) { return ['on', 'sim', 'true', '1', 'ligado'].includes(n(value)); }
function presetByNumber(value) { return ({ '1': 'rapido', '2': 'normal', '3': 'competitivo' })[String(value)] || null; }

async function applyEditorCommand(userId, config, text) {
  const raw = String(text || '').trim();
  const lower = n(raw);
  const [command, ...rest] = raw.split(/\s+/);
  const arg = rest.join(' ').trim();
  const c = makeStopConfig(config);
  const changed = {};
  if (lower === 'revisar' || lower === 'review') return { review: true, config: c };
  if (lower === 'finalizar' || lower === 'salvar' || lower === 'pronto') return { finalize: true, config: c };
  if (lower === 'voltar') return { config: c, step: 'EDITING' };
  if (['tempo', 'time'].includes(n(command))) {
    const v = Number(arg); const value = Number.isInteger(v) && v >= STOP_LIMITS.roundTimeSeconds.min && v <= STOP_LIMITS.roundTimeSeconds.max ? v : null;
    if (!value) return { error: `⏱️ O tempo deve ficar entre ${STOP_LIMITS.roundTimeSeconds.min}s e ${STOP_LIMITS.roundTimeSeconds.max}s.` };
    changed.roundTimeSeconds = value;
  } else if (['rodadas', 'rodada', 'rounds'].includes(n(command))) {
    const v = Number(arg); const value = Number.isInteger(v) && v >= STOP_LIMITS.rounds.min && v <= STOP_LIMITS.rounds.max ? v : null;
    if (!value) return { error: `🔢 As rodadas devem ficar entre ${STOP_LIMITS.rounds.min} e ${STOP_LIMITS.rounds.max}.` };
    changed.rounds = value;
  } else if (['jogadores', 'player', 'players'].includes(n(command))) {
    const v = Number(arg); const value = Number.isInteger(v) && v >= STOP_LIMITS.maxPlayers.min && v <= STOP_LIMITS.maxPlayers.max ? v : null;
    if (!value) return { error: `👥 O limite deve ficar entre ${STOP_LIMITS.maxPlayers.min} e ${STOP_LIMITS.maxPlayers.max} jogadores.` };
    changed.maxPlayers = value;
  } else if (['categorias', 'categoria', 'cats'].includes(n(command))) {
    const cats = normalizeCategoryList(arg); if (cats.length < STOP_LIMITS.categories.min) return { error: `📚 Escolha pelo menos ${STOP_LIMITS.categories.min} categorias.` };
    changed.categories = cats;
  } else if (n(command) === 'letra') {
    const letter = arg.toUpperCase().replace(/[^A-Z]/g, '').slice(0, 1); if (!letter) return { error: '🔤 Informe uma letra de A a Z.' };
    changed.letterMode = 'fixed'; changed.fixedLetter = letter; changed.allowedLetters = [];
  } else if (['letras', 'pool'].includes(n(command))) {
    const pool = [...new Set(arg.toUpperCase().replace(/[^A-Z]/g, '').split(''))]; if (!pool.length) return { error: '🔤 Informe pelo menos uma letra.' };
    changed.letterMode = 'pool'; changed.allowedLetters = pool; changed.fixedLetter = null;
  } else if (['aleatoria', 'aleatório', 'random'].includes(lower)) {
    changed.letterMode = 'random'; changed.fixedLetter = null; changed.allowedLetters = [];
  } else if (['modo', 'mode'].includes(n(command))) {
    const mode = n(arg); if (!['normal', 'competitivo'].includes(mode)) return { error: '🏆 Use: modo normal ou modo competitivo.' };
    changed.scoring = { ...c.scoring, mode };
  } else if (['bonus', 'bônus'].includes(n(command))) {
    changed.speedBonus = { ...c.speedBonus, enabled: parseOnOff(arg) };
  } else if (n(command) === 'ia') {
    changed.validation = { ...c.validation, aiEnabled: parseOnOff(arg) };
  } else if (['repeticao', 'repetição'].includes(n(command))) {
    changed.rules = { ...c.rules, allowDuplicateAnswers: parseOnOff(arg) };
  } else if (['extra', 'tempoextra'].includes(n(command))) {
    changed.rules = { ...c.rules, extraTime: parseOnOff(arg) };
  } else if (['eliminacao', 'eliminação'].includes(n(command))) {
    changed.rules = { ...c.rules, elimination: parseOnOff(arg) };
  } else {
    return { error: '⚠️ Não reconheci essa configuração. Use *revisar* para ver os comandos disponíveis.' };
  }
  const next = makeStopConfig({ ...c, ...changed, updatedAt: now(), preset: 'personalizado' });
  return { config: next, changed };
}

async function savePrivateState(userId, state) {
  return updateCollection('stop_private_state', db => { db.byUser ??= {}; db.byUser[userId] = { ...state, updatedAt: now() }; return db; }, { byUser: {} });
}

export async function handleConfigPrivate(ctx) {
  if (!ctx.isPrivate || !uid(ctx)) return { handled: false };
  const userId = uid(ctx);
  const state = readCollection('stop_private_state', { byUser: {} }).byUser?.[userId];
  if (!state) return { handled: false };
  if (now() - Number(state.updatedAt || state.startedAt || now()) > 15 * 60 * 1000) {
    await expirePrivateState(userId, state);
    await ctx.sendMessage?.(userId, { text: '⌛ A configuração do STOP expirou por inatividade. Use ×stopcriar novamente.' });
    return { handled: true, expired: true };
  }
  const text = String(ctx.body || ctx.text || '').trim();
  if (!text) return { handled: true };
  if (n(text) === 'cancelar') {
    await updateCollection('stop_private_state', db => { delete db.byUser?.[userId]; return db; }, { byUser: {} });
    await saveConfig(userId, { status: 'EXPIRED', expiredAt: now() });
    await ctx.sendMessage?.(userId, { text: '🛑 Configuração do STOP cancelada.' });
    return { handled: true, cancelled: true };
  }
  let config = getConfig(userId) || applyPreset('normal');
  if (state.step === 'CONFIG_MENU') {
    const preset = presetByNumber(text);
    if (preset) config = applyPreset(preset);
    else if (text === '4' || n(text) === 'personalizado') config = makeStopConfig({ ...config, preset: 'personalizado' });
    else return ctx.sendMessage?.(userId, { text: '⚠️ Escolha 1, 2, 3 ou 4.' }).then(() => ({ handled: true, invalid: true }));
    await saveConfig(userId, { ...config, status: 'CONFIGURING' });
    await savePrivateState(userId, { ...state, step: 'EDITING' });
    await audit('STOP_CONFIG_PRESET_SELECTED', null, { userId, details: { preset: config.preset } });
    await ctx.sendMessage?.(userId, { text: editorText(config) });
    return { handled: true, configured: true };
  }
  if (state.step === 'REVIEW') {
    if (text === '1') {
      const valid = validateStopConfig(config);
      if (!valid.ok) return ctx.sendMessage?.(userId, { text: `❌ Configuração inválida:\n• ${valid.errors.join('\n• ')}` }).then(() => ({ handled: true, invalid: true }));
      await saveConfig(userId, { ...valid.config, status: 'ACTIVE', completedAt: now() });
      await updateCollection('stop_private_state', db => { delete db.byUser?.[userId]; return db; }, { byUser: {} });
      await audit('STOP_CONFIG_COMPLETED', null, { userId, details: { rounds: valid.config.rounds, categories: valid.config.categories.length } });
      await emit('STOP_CONFIG_COMPLETED', { userId, config: valid.config });
      await ctx.sendMessage?.(userId, { text: `✅ Configuração salva!\n\n${formatStopConfig(valid.config)}\n\nUse ×stop no grupo para abrir a partida.` });
      return { handled: true, completed: true };
    }
    if (text === '2') { await savePrivateState(userId, { ...state, step: 'EDITING' }); return ctx.sendMessage?.(userId, { text: editorText(config) }).then(() => ({ handled: true })); }
    if (text === '3') { await updateCollection('stop_private_state', db => { delete db.byUser?.[userId]; return db; }, { byUser: {} }); return ctx.sendMessage?.(userId, { text: '🛑 Revisão cancelada.' }).then(() => ({ handled: true, cancelled: true })); }
    return ctx.sendMessage?.(userId, { text: '⚠️ Responda 1, 2 ou 3.' }).then(() => ({ handled: true }));
  }
  if (state.step === 'SESSION_EDIT') return handleSessionEditPrivate(ctx, state, text);
  if (state.step !== 'EDITING') return { handled: false };
  const result = await applyEditorCommand(userId, config, text);
  if (result.error) return ctx.sendMessage?.(userId, { text: result.error }).then(() => ({ handled: true, invalid: true }));
  if (result.review) { await savePrivateState(userId, { ...state, step: 'REVIEW' }); return ctx.sendMessage?.(userId, { text: reviewText(config) }).then(() => ({ handled: true, review: true })); }
  if (result.finalize) {
    const valid = validateStopConfig(config);
    if (!valid.ok) return ctx.sendMessage?.(userId, { text: `❌ Configuração inválida:\n• ${valid.errors.join('\n• ')}` }).then(() => ({ handled: true, invalid: true }));
    await saveConfig(userId, { ...valid.config, status: 'ACTIVE', completedAt: now() });
    await updateCollection('stop_private_state', db => { delete db.byUser?.[userId]; return db; }, { byUser: {} });
    await audit('STOP_CONFIG_COMPLETED', null, { userId, details: { rounds: valid.config.rounds, categories: valid.config.categories.length } });
    await emit('STOP_CONFIG_COMPLETED', { userId, config: valid.config });
    return ctx.sendMessage?.(userId, { text: `✅ Configuração salva!\n\n${formatStopConfig(valid.config)}\n\nUse ×stop no grupo para abrir a partida.` }).then(() => ({ handled: true, completed: true }));
  }
  const valid = validateStopConfig(result.config);
  if (!valid.ok) return ctx.sendMessage?.(userId, { text: `❌ ${valid.errors.join('\n')}` }).then(() => ({ handled: true, invalid: true }));
  await saveConfig(userId, { ...valid.config, status: 'CONFIGURING' });
  await savePrivateState(userId, state);
  const labels = { roundTimeSeconds: 'Tempo', rounds: 'Rodadas', maxPlayers: 'Jogadores', categories: 'Categorias', letterMode: 'Letra', scoring: 'Pontuação', speedBonus: 'Bônus', validation: 'IA', rules: 'Regras' };
  const changedKey = Object.keys(result.changed || {})[0];
  await audit('STOP_CONFIG_UPDATED', null, { userId, details: { field: labels[changedKey] || changedKey || 'config' } });
  await emit('STOP_CONFIG_UPDATED', { userId, field: changedKey || null });
  await ctx.sendMessage?.(userId, { text: `✅ Configuração atualizada.\n\n${formatStopConfig(valid.config)}\n\n${editorText(valid.config).split('\n\nComandos')[1] ? 'Continue editando ou use *revisar*.' : ''}` });
  return { handled: true, updated: true };
}

async function handleSessionEditPrivate(ctx, state, text) {
  const sessionId = state.sessionId;
  const g = getGameSession(sessionId);
  const s = sessionFromGame(g);
  if (!s || s.status !== STOP_STATES.LOBBY_OPEN || s.createdByIdentityKey !== state.identityKey) {
    await updateCollection('stop_private_state', db => { delete db.byUser?.[uid(ctx)]; return db; }, { byUser: {} });
    return ctx.sendMessage?.(uid(ctx), { text: '⚠️ Essa partida não pode mais ser configurada.' }).then(() => ({ handled: true, expired: true }));
  }
  if (n(text) === 'revisar') return ctx.sendMessage?.(uid(ctx), { text: `╭────「 🛑 CONFIGURAÇÃO DA PARTIDA 」────╮\n\n${formatStopConfig(s.config)}\n\nA partida ainda está no lobby. Você pode alterar novamente.\n╰──────────────────────────────────────╯` }).then(() => ({ handled: true }));
  const result = await applyEditorCommand(uid(ctx), s.config, text);
  if (result.error) return ctx.sendMessage?.(uid(ctx), { text: result.error }).then(() => ({ handled: true, invalid: true }));
  const valid = validateStopConfig(result.config);
  if (!valid.ok) return ctx.sendMessage?.(uid(ctx), { text: `❌ ${valid.errors.join('\n')}` }).then(() => ({ handled: true, invalid: true }));
  if (valid.config.maxPlayers < s.participants.length) return ctx.sendMessage?.(uid(ctx), { text: `❌ O limite de jogadores não pode ficar abaixo dos ${s.participants.length} participantes atuais.` }).then(() => ({ handled: true, invalid: true }));
  const old = s.config;
  const updated = await updateBoth(s.gameId, s.groupId, x => { x.config = valid.config; x.categoriesSnapshot = valid.config.categories.map(name => ({ name, key: n(name) })); x.roundsTotal = valid.config.rounds; return x; });
  await audit('STOP_CONFIG_UPDATED', updated, { userId: uid(ctx), details: { sessionId, field: Object.keys(result.changed || {})[0] || 'config' } });
  await emit('STOP_CONFIG_UPDATED', { sessionId, field: Object.keys(result.changed || {})[0] || 'config' });
  if (result.finalize) {
    await updateCollection('stop_private_state', db => { delete db.byUser?.[uid(ctx)]; return db; }, { byUser: {} });
    return ctx.sendMessage?.(uid(ctx), { text: `✅ Configuração da partida atualizada.\n\n${formatStopConfig(updated.config)}` }).then(() => ({ handled: true, completed: true }));
  }
  return ctx.sendMessage?.(uid(ctx), { text: `✅ Configuração atualizada.\n\n${formatStopConfig(updated.config)}` }).then(() => ({ handled: true, updated: true }));
}

export async function beginDelete(ctx) {
  const userId = uid(ctx); const c = getConfig(userId);
  if (!c || c.status === 'DELETED') return ctx.reply?.('⚠️ Você não possui uma configuração ativa do STOP.').then?.(() => ({ handled: true })) || { handled: true };
  await savePrivateState(userId, { step: 'DELETE_CONFIRM', startedAt: now(), updatedAt: now() });
  await ctx.sendMessage?.(userId, { text: '╭────「 👻 STOP 」────╮\n🗑️ EXCLUIR CONFIGURAÇÃO\n\n1️⃣ Sim, excluir\n2️⃣ Não, cancelar\n\n╰────────────────────╯' });
  return { handled: true };
}

async function handleDeleteConfirm(ctx) {
  const userId = uid(ctx); const p = readCollection('stop_private_state', { byUser: {} }).byUser?.[userId];
  if (!p || p.step !== 'DELETE_CONFIRM') return { handled: false };
  const text = String(ctx.body || ctx.text || '').trim();
  if (text === '1') {
    await saveConfig(userId, { status: 'DELETED', deletedAt: now() });
    await updateCollection('stop_private_state', d => { delete d.byUser?.[userId]; return d; }, { byUser: {} });
    await audit('STOP_CONFIG_DELETED', null, { userId }); await emit('STOP_CONFIG_DELETED', { userId });
    await ctx.sendMessage?.(userId, { text: '🗑️ Configuração excluída. O histórico das partidas permanece intacto. 👻' });
    return { handled: true, deleted: true };
  }
  if (text === '2' || n(text) === 'cancelar') {
    await updateCollection('stop_private_state', d => { delete d.byUser?.[userId]; return d; }, { byUser: {} });
    await ctx.sendMessage?.(userId, { text: '✅ Exclusão cancelada.' }); return { handled: true, cancelled: true };
  }
  await ctx.sendMessage?.(userId, { text: '⚠️ Responda somente com 1 ou 2.' }); return { handled: true };
}

function linkFor(ctx, stopCode) { const raw = String(ctx.botJid || '').split(':')[0]; const digits = raw.replace(/[^0-9]/g, ''); return digits ? `https://wa.me/${digits}?text=${encodeURIComponent(stopCode)}` : `https://wa.me/?text=${encodeURIComponent(stopCode)}`; }

function initialSession(ctx, cfg, stopCode, gameId, identity) {
  const t = now();
  return {
    sessionId: gameId, gameId, stopCode, groupId: gid(ctx), groupName: ctx.groupName || 'Grupo',
    createdBy: identity.canonicalJid || null, createdByIdentityKey: identity.identityKey,
    creatorResolvable: identity.resolvable, config: makeStopConfig(cfg), categoriesSnapshot: cfg.categories.map(name => ({ name, key: n(name) })),
    roundsTotal: cfg.rounds, currentRound: 0, status: STOP_STATES.LOBBY_OPEN,
    lobbyStartedAt: t, lobbyExpiresAt: t + LOBBY_MS, createdAt: t, updatedAt: t, finishedAt: null, cancelledAt: null,
    participants: [], rounds: [], processedMessageIds: [], processedSubmissions: {}, processedScores: {}, usedLetters: [], scores: {}
  };
}
async function persistSession(session) { return updateCollection('stop_sessions', db => { db.byId ??= {}; db.byCode ??= {}; db.byId[session.sessionId] = session; db.byCode[session.stopCode] = session.sessionId; return db; }, { byId: {}, byCode: {} }); }
async function persistParticipant(session, participant) { return updateCollection('stop_participants', db => { db.byId ??= {}; const k = `${session.sessionId}::${participant.identityKey}`; db.byId[k] = { ...participant, id: k, sessionId: session.sessionId }; return db; }, { byId: {} }); }
async function persistAnswers(session, round, identityKey, answers) { if (!answers?.length) return; await updateCollection('stop_answers', db => { db.byId ??= {}; for (const answer of answers) { const id = `${round.roundId}::${identityKey}::${answer.categoryKey}`; db.byId[id] = { id, roundId: round.roundId, sessionId: session.sessionId, identityKey, userId: identityKey, ...answer }; } return db; }, { byId: {} }); }
async function persistRoundResults(session) { await updateCollection('stop_round_results', db => { db.byId ??= {}; for (const p of session.participants) { const r = session.round.results?.[p.identityKey] || {}; const vals = Object.values(r); const id = `${session.round.roundId}::${p.identityKey}`; db.byId[id] = { id, roundId: session.round.roundId, sessionId: session.sessionId, identityKey: p.identityKey, userId: p.canonicalJid || null, validCount: vals.filter(v => String(v.status).startsWith('VALID')).length, uniqueCount: vals.filter(v => v.status === 'VALID_UNIQUE').length, duplicateCount: vals.filter(v => v.status === 'VALID_DUPLICATE').length, invalidCount: vals.filter(v => v.status === 'INVALID').length, emptyCount: vals.filter(v => v.status === 'EMPTY').length, points: vals.reduce((a, v) => a + Number(v.points || 0), 0), createdAt: now() }; } return db; }, { byId: {} }); }
async function persistValidationResults(session) { await updateCollection('stop_answers', db => { db.byId ??= {}; for (const [user, cats] of Object.entries(session.round.results || {})) for (const [categoryKey, v] of Object.entries(cats || {})) { const id = `${session.round.roundId}::${user}::${categoryKey}`; if (db.byId[id]) db.byId[id] = { ...db.byId[id], validationStatus: v.status, validationReason: v.reason || '', validationConfidence: Number(v.confidence) || 0, aiResult: v, points: Number(v.points) || 0, updatedAt: now() }; } return db; }, { byId: {} }); }

function mentionForParticipant(p) { return publicMention({ canonicalJid: p?.canonicalJid }); }
function safeText(text) { assertNoLidInOutput(text); return text; }

function lobbyText(s, ctx) {
  const creator = mentionForParticipant({ canonicalJid: s.createdBy });
  const mention = creator.text === 'participante' ? 'criador' : creator.text;
  const text = `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n    🎮 NOVA PARTIDA\n╰━━━━━━━━━━━━━━━━━━╯\n\n👤 Criador: ${mention}\n\n${formatStopConfig(s.config)}\n\n🚀 Participe pelo link abaixo:\n\n🔗 ${linkFor(ctx, s.stopCode)}\n\n⏱️ Inscrições abertas por 60 segundos.\n\n╰━━━━━━━━━━━━━━━━━━╯`;
  return safeText(text);
}

export async function createSession(ctx) {
  if (!ctx.isGroup) return ctx.reply?.('⚠️ ×stop funciona apenas em grupos.');
  const userIdentity = await resolveStopIdentity(ctx, uid(ctx));
  const cfg = getConfig(uid(ctx)) || getConfig(userIdentity.identityKey);
  if (!cfg || cfg.status !== 'ACTIVE') return ctx.reply?.(`⚠️ Você ainda não possui uma configuração válida do STOP.\n\nUse ${ctx.prefix || '×'}stopcriar no PV.`);
  const valid = validateStopConfig(cfg); if (!valid.ok) return ctx.reply?.(`⚠️ Sua configuração ficou inválida:\n• ${valid.errors.join('\n• ')}`);
  if (getSessionByGroup(gid(ctx))) return ctx.reply?.('⚠️ Já existe um STOP ativo neste grupo.');
  return lock(`group:${gid(ctx)}`, async () => {
    if (getSessionByGroup(gid(ctx))) return ctx.reply?.('⚠️ Já existe um STOP ativo neste grupo.');
    const stopCode = generateStopCode();
    const provisional = initialSession(ctx, valid.config, stopCode, 'PENDING', userIdentity);
    const g = await game.createGame({ groupId: gid(ctx), gameType: 'STOP', creatorId: userIdentity.canonicalJid || uid(ctx), maxPlayers: valid.config.maxPlayers, state: { stopSession: provisional }, timeoutMs: 0, metadata: { gameType: 'STOP' }, onePerGroup: true });
    const session = initialSession(ctx, valid.config, stopCode, g.gameId, userIdentity);
    await game.updateGame(g.gameId, gid(ctx), x => { x.state.stopSession = session; return x; });
    await persistSession(session);
    await emit('GAME_CREATED', { gameType: 'STOP', sessionId: g.gameId, groupId: gid(ctx) });
    await emit('GAME_LOBBY_OPENED', { gameType: 'STOP', sessionId: g.gameId, groupId: gid(ctx) });
    await emit('STOP_SESSION_CREATED', { sessionId: g.gameId, groupId: gid(ctx), stopCode });
    await emit('STOP_LOBBY_OPENED', { sessionId: g.gameId, groupId: gid(ctx) });
    await audit('STOP_SESSION_CREATED', session, { userId: userIdentity.identityKey, details: { categories: session.categoriesSnapshot.length, rounds: session.roundsTotal } });
    schedule(g.gameId, session.lobbyExpiresAt);
    const creatorMention = publicMention({ canonicalJid: session.createdBy });
    return ctx.reply?.(lobbyText(session, ctx), creatorMention.mentions.length ? { mentions: creatorMention.mentions } : undefined);
  });
}

function schedule(gameId, at) { clearTimer(gameId); const delay = Math.max(50, Number(at) - now()); const timer = setTimeout(() => tick(gameId).catch(() => {}), delay); timer.unref?.(); pendingTimers.set(gameId, { timer, dueAt: at }); }
function clearTimer(gameId) { const item = pendingTimers.get(gameId); if (item) { clearTimeout(item.timer || item); pendingTimers.delete(gameId); } }
function getGameSession(gameId) { const g = game.getGame(gameId); return g?.gameType === 'STOP' ? g : null; }
async function updateBoth(gameId, groupId, fn) { const updated = await game.updateGame(gameId, groupId, g => { g.state.stopSession = fn(structuredClone(g.state.stopSession)); return g; }); await persistSession(updated.state.stopSession); return updated.state.stopSession; }
async function tick(gameId) { const g = getGameSession(gameId); if (!g) return; const s = sessionFromGame(g); if (!s) return; if (s.status === STOP_STATES.LOBBY_OPEN && now() >= s.lobbyExpiresAt) return closeLobby(g); if (s.status === STOP_STATES.ROUND_ACTIVE && now() >= s.round?.expiresAt) return lockRound(g); if ([STOP_STATES.ROUND_ACTIVE, STOP_STATES.LOBBY_OPEN].includes(s.status)) schedule(gameId, s.status === STOP_STATES.LOBBY_OPEN ? s.lobbyExpiresAt : s.round.expiresAt); }

export async function joinByCode(ctx) {
  if (!ctx.isPrivate) return { handled: false };
  const text = String(ctx.body || ctx.text || '').trim().toUpperCase(); if (!/^STP-[A-Z0-9]{8}$/.test(text)) return { handled: false };
  const sess = getSessionByCode(text); if (!sess) return ctx.sendMessage?.(uid(ctx), { text: '❌ O código do STOP não foi encontrado.' }).then(() => ({ handled: true }));
  return lock(`session:${sess.sessionId}`, async () => {
    const g = getGameSession(sess.gameId); const s = sessionFromGame(g);
    if (!g || !s || s.groupId !== sess.groupId) return ctx.sendMessage?.(uid(ctx), { text: '❌ Esta partida não está disponível.' }).then(() => ({ handled: true }));
    if (s.status !== STOP_STATES.LOBBY_OPEN || now() > s.lobbyExpiresAt) return ctx.sendMessage?.(uid(ctx), { text: '⏰ O lobby desta partida já foi encerrado.' }).then(() => ({ handled: true }));
    const identity = await resolveStopIdentity(ctx, uid(ctx));
    const existing = s.participants.find(p => p.identityKey === identity.identityKey || (identity.canonicalJid && p.canonicalJid === identity.canonicalJid));
    if (existing) return ctx.sendMessage?.(uid(ctx), { text: `✅ Sua presença já está registrada!\n\n${formatStopConfig(s.config)}` }).then(() => ({ handled: true, duplicate: true }));
    if (s.participants.length >= s.config.maxPlayers) return ctx.sendMessage?.(uid(ctx), { text: '🚫 O limite de jogadores desta partida já foi atingido.' }).then(() => ({ handled: true, full: true }));
    const participant = { identityKey: identity.identityKey, userId: identity.canonicalJid || identity.identityKey, canonicalJid: identity.canonicalJid, aliases: identity.aliases, name: identity.name, joinedAt: now(), status: 'JOINED', lastActivityAt: now(), totalScore: 0 };
    const updated = await updateBoth(g.gameId, s.groupId, ss => { ss.participants.push(participant); return ss; });
    await persistParticipant(updated, participant);
    await audit('STOP_IDENTITY_RESOLVED', updated, { userId: identity.identityKey, details: { resolvable: identity.resolvable } });
    await emit(identity.resolvable ? 'STOP_IDENTITY_RESOLVED' : 'STOP_IDENTITY_UNRESOLVED', { sessionId: updated.sessionId, identityKey: identity.identityKey });
    await audit('STOP_PARTICIPANT_JOINED', updated, { userId: identity.identityKey });
    await emit('GAME_PLAYER_JOINED', { gameType: 'STOP', sessionId: updated.sessionId, groupId: updated.groupId, userId: identity.canonicalJid || identity.identityKey });
    await emit('STOP_PARTICIPANT_JOINED', { sessionId: updated.sessionId, groupId: updated.groupId, userId: identity.canonicalJid || identity.identityKey });
    await ctx.sendMessage?.(uid(ctx), { text: `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   ✅ PRESENÇA REGISTRADA\n╰━━━━━━━━━━━━━━━━━━╯\n\nVocê entrou na partida!\n\n${formatStopConfig(updated.config)}\n\n⚠️ Aguarde o encerramento do lobby.\n╰━━━━━━━━━━━━━━━━━━╯` });
    return { handled: true, joined: true };
  });
}

async function closeLobby(g) {
  const s = sessionFromGame(g); if (!s || s.status !== STOP_STATES.LOBBY_OPEN) return;
  clearTimer(g.gameId);
  const updated = await updateBoth(g.gameId, s.groupId, ss => transition(ss, STOP_STATES.LOBBY_CLOSED));
  await emit('GAME_LOBBY_CLOSED', { gameType: 'STOP', sessionId: g.gameId, groupId: s.groupId });
  await emit('STOP_LOBBY_CLOSED', { sessionId: g.gameId, groupId: s.groupId });
  await audit('STOP_LOBBY_CLOSED', updated, { userId: updated.createdByIdentityKey });
  await ctxSendGroup(updated.groupId, renderLobbyClosed(updated));
  const waiting = await updateBoth(g.gameId, s.groupId, ss => transition(ss, STOP_STATES.WAITING_CREATOR_START));
  if (!waiting.participants.length) return cancelSession(waiting, { sender: waiting.createdBy }, 'NO_PARTICIPANTS');
}
function renderLobbyClosed(s) {
  const rows = s.participants.map((p, i) => { const m = mentionForParticipant(p); return `${i + 1}. ${m.text}`; });
  const mentions = s.participants.flatMap(p => mentionForParticipant(p).mentions);
  const text = `╭━━━ 🛑 STOP ━━━╮\n⏰ LOBBY FECHADO!\n\n👥 PARTICIPANTES:\n${rows.join('\n') || 'Nenhum participante.'}\n\n━━━━━━━━━━━━━━━━\n\n🏁 A partida está pronta.\n\nSomente o criador deve responder:\n1️⃣ Sim\n2️⃣ Não\n╰━━━━━━━━━━━━━━━━╯`;
  return { text: safeText(text), mentions };
}
async function ctxSendGroup(groupId, payload, options = {}) { const transport = globalThis.__fantasminhaStopTransport; try { const content = typeof payload === 'string' ? { text: payload, ...options } : { ...payload, ...options }; safeText(content.text); return await transport?.sendMessage?.(groupId, content); } catch { return null; } }
export function attachTransport(ctx) { if (ctx?.sendMessage) globalThis.__fantasminhaStopTransport = { sendMessage: ctx.sendMessage }; }

async function startFromCreator(ctx, s) {
  const identity = await resolveStopIdentity(ctx, uid(ctx)); if (identity.identityKey !== s.createdByIdentityKey) return { handled: false };
  return lock(`session:${s.sessionId}`, async () => {
    const g = getGameSession(s.gameId); const ss = sessionFromGame(g); if (!g || !ss || ss.status !== STOP_STATES.WAITING_CREATOR_START) return { handled: false };
    if (!ss.participants.length) { await ctx.reply?.('⚠️ Não há participantes registrados.'); return { handled: true, started: false }; }
    const updated = await updateBoth(s.gameId, s.groupId, x => transition(x, STOP_STATES.ROUND_STARTING));
    await emit('STOP_START_CONFIRMED', { sessionId: s.sessionId, groupId: s.groupId, userId: identity.identityKey });
    await emit('GAME_STARTED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId });
    await startRound(updated, ctx); return { handled: true, started: true };
  });
}
async function cancelCreatorStart(ctx, s) { const identity = await resolveStopIdentity(ctx, uid(ctx)); if (identity.identityKey !== s.createdByIdentityKey) return { handled: false }; await cancelSession(s, ctx, 'START_CANCELLED'); return { handled: true, cancelled: true }; }

function selectLetter(s) {
  if (s.config?.letterMode === 'fixed' && s.config.fixedLetter) return s.config.fixedLetter;
  const pool = s.config?.letterMode === 'pool' && s.config.allowedLetters?.length ? s.config.allowedLetters : letters;
  const available = pool.filter(x => !s.usedLetters.includes(x)); return available.length ? available[crypto.randomInt(0, available.length)] : pool[crypto.randomInt(0, pool.length)];
}
function renderCategories(s) { return s.categoriesSnapshot.map((x, i) => `${['🐾','🍔','👤','🌍','📦','💼','🎬','🎮','🌿','🏷️'][i] || '📋'} ${x.name}`).join('\n'); }
function durationText(ms) { const sec = Math.ceil(ms / 1000); return `${Math.floor(sec / 60)}m ${sec % 60}s`; }

async function startRound(s, ctx) {
  const letter = selectLetter(s); const roundNumber = s.currentRound + 1; const t = now(); const duration = Number(s.config?.roundTimeSeconds || STOP_LIMITS.roundTimeSeconds.default) * 1000;
  const round = { roundId: `${s.sessionId}-${roundNumber}`, roundNumber, roundVersion: crypto.randomUUID(), letter, startedAt: t, expiresAt: t + duration, lockedAt: null, status: STOP_STATES.ROUND_ACTIVE, answers: {}, results: {}, createdAt: t, updatedAt: t, validationId: null, scoreOperationId: null };
  const updated = await updateBoth(s.gameId, s.groupId, x => { x.currentRound = roundNumber; x.status = STOP_STATES.ROUND_ACTIVE; x.usedLetters.push(letter); x.round = round; x.rounds.push({ roundId: round.roundId, roundNumber, letter, startedAt: t, expiresAt: t + duration, status: STOP_STATES.ROUND_ACTIVE, roundVersion: round.roundVersion }); return x; });
  await emit('GAME_ROUND_STARTED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId, roundNumber });
  await emit('STOP_ROUND_STARTED', { sessionId: s.sessionId, groupId: s.groupId, roundNumber, letter });
  await audit('STOP_ROUND_STARTED', updated, { details: { roundNumber, letter, roundTimeSeconds: updated.config.roundTimeSeconds } });
  await ctxSendGroup(s.groupId, `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n    🚨 RODADA ${roundNumber}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 LETRA: ${letter}\n\n📋 Categorias:\n${renderCategories(updated)}\n\n⏱️ TEMPO: ${durationText(duration)}\n\n📩 As respostas devem ser enviadas no PV do bot.\n\n🚀 VALENDO!\n╰━━━━━━━━━━━━━━━━━━╯`);
  await sendSheets(updated); schedule(s.gameId, round.expiresAt);
}
async function sendSheets(s) { for (const p of s.participants) { const text = `╭━━━ 👻 STOP ━━━╮\n🔄 RODADA ${s.currentRound}/${s.roundsTotal}\n🔤 LETRA: ${s.round.letter}\n\n${s.categoriesSnapshot.map(x => `${x.name}:\n⬜`).join('\n\n')}\n\n⏱️ RESTAM: ${durationText(s.round.expiresAt - now())}\n\nEnvie suas respostas no formato:\nCategoria: Resposta\nCategoria: Resposta\n\n╰━━━━━━━━━━━━━━╯`; try { await globalThis.__fantasminhaStopTransport?.sendMessage?.(p.canonicalJid || p.identityKey, { text: safeText(text) }); } catch (e) { await audit('STOP_ERROR', s, { userId: p.identityKey, details: { kind: 'private_send', error: e.message } }); } } }

export async function handleAnswer(ctx) {
  if (!ctx.isPrivate) return { handled: false }; attachTransport(ctx); const text = String(ctx.body || ctx.text || '').trim(); if (!text) return { handled: false };
  const identity = await resolveStopIdentity(ctx, uid(ctx));
  const activeSessions = game.listActiveGames().filter(gameActive);
  const candidates = activeSessions.map(sessionFromGame).filter(x => x?.participants?.some(p => p.identityKey === identity.identityKey || (identity.canonicalJid && p.canonicalJid === identity.canonicalJid)) && x.status === STOP_STATES.ROUND_ACTIVE);
  if (candidates.length > 1) { await ctx.sendMessage?.(uid(ctx), { text: '⚠️ Você participa de mais de um STOP ativo. Envie as respostas somente quando houver uma única rodada ativa para evitar mistura entre grupos.' }); return { handled: true, ambiguous: true }; }
  const activeRoundSession = candidates[0] || null;
  if (!activeRoundSession) { const configFlow = await handleConfigPrivate(ctx); if (configFlow.handled) return configFlow; const del = await handleDeleteConfirm(ctx); if (del.handled) return del; }
  const codeResult = await joinByCode(ctx); if (codeResult.handled) return codeResult; const s = activeRoundSession; if (!s) return { handled: false };
  const answerResult = await lock(`session:${s.sessionId}`, async () => {
    const g = getGameSession(s.gameId); const ss = sessionFromGame(g); if (!ss || ss.status !== STOP_STATES.ROUND_ACTIVE) return { handled: false };
    if (now() > ss.round.expiresAt) return { handled: true, expired: true, late: true, game: g };
    const parsed = parseStopAnswers(text, ss.categoriesSnapshot); if (!parsed.length) return { handled: false };
    const messageId = mid(ctx); let duplicateMessage = false; const submissionId = crypto.createHash('sha256').update(`${ss.round.roundVersion}:${identity.identityKey}:${messageId || text}`).digest('hex');
    const updated = await updateBoth(ss.gameId, ss.groupId, x => {
      x.processedMessageIds ??= []; x.processedSubmissions ??= {};
      if (messageId && x.processedMessageIds.includes(messageId)) { duplicateMessage = true; return x; }
      if (x.processedSubmissions[submissionId]) { duplicateMessage = true; return x; }
      if (messageId) x.processedMessageIds.push(messageId); x.processedSubmissions[submissionId] = now();
      const p = x.participants.find(p => p.identityKey === identity.identityKey || (identity.canonicalJid && p.canonicalJid === identity.canonicalJid)); if (!p) return x;
      p.lastActivityAt = now(); x.round.answers[identity.identityKey] ??= {};
      for (const a of parsed) x.round.answers[identity.identityKey][a.categoryKey] = { ...a, submittedAt: now(), updatedAt: now(), messageId, submissionId };
      return x;
    });
    if (duplicateMessage) return { handled: true, duplicate: true };
    await persistAnswers(updated, updated.round, identity.identityKey, parsed);
    await audit('STOP_ANSWER_SUBMITTED', updated, { userId: identity.identityKey, details: { count: parsed.length, submissionId } });
    await emit('STOP_ANSWER_SUBMITTED', { sessionId: s.sessionId, groupId: s.groupId, userId: identity.canonicalJid || identity.identityKey, count: parsed.length, submissionId });
    await ctx.sendMessage?.(uid(ctx), { text: '✅ Resposta(s) registrada(s)!\n\nVocê pode alterar qualquer categoria enquanto o tempo estiver aberto.' });
    return { handled: true, updated: true, submissionId };
  });
  if (answerResult?.late) { await lockRound(answerResult.game); await ctx.sendMessage?.(uid(ctx), { text: '⏰ O tempo da rodada terminou. Sua resposta não pode mais ser alterada.' }); return { handled: true, expired: true }; }
  return answerResult;
}

async function lockRound(g) {
  let locked = null; await lock(`session:${g.gameId}`, async () => { const current = getGameSession(g.gameId); const s = sessionFromGame(current); if (!s || s.status !== STOP_STATES.ROUND_ACTIVE) return; clearTimer(g.gameId); locked = await updateBoth(g.gameId, s.groupId, x => { transition(x, STOP_STATES.ROUND_LOCKED); x.round.status = STOP_STATES.ROUND_LOCKED; x.round.lockedAt = now(); return x; }); await emit('GAME_ROUND_LOCKED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId, roundNumber: s.currentRound }); await emit('STOP_ROUND_LOCKED', { sessionId: s.sessionId, groupId: s.groupId, roundNumber: s.currentRound }); await audit('STOP_ROUND_LOCKED', locked, { details: { roundNumber: s.currentRound } }); }); if (locked) await validateRound(locked); return locked;
}

async function validateRound(s) {
  const g = getGameSession(s.gameId); if (!g) return;
  const current = sessionFromGame(g); if (!current || ![STOP_STATES.ROUND_LOCKED, STOP_STATES.VALIDATING].includes(current.status)) return;
  const validationId = current.round.validationId || crypto.randomUUID();
  const updated = await updateBoth(s.gameId, s.groupId, x => { if (x.status === STOP_STATES.ROUND_LOCKED) transition(x, STOP_STATES.VALIDATING); x.round.validationId = validationId; return x; });
  await emit('GAME_VALIDATION_STARTED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId, roundNumber: s.currentRound, validationId });
  const validations = {}; const answers = updated.round.answers || {}; const aiCache = new Map(); const jobs = [];
  const concurrency = Math.max(1, Math.min(4, Number(env.STOP_AI_CONCURRENCY || 3)));
  const validateOne = async ({ p, cat, a }) => {
    validations[p.identityKey] ??= {};
    if (!a) { validations[p.identityKey][cat.key] = { status: 'EMPTY', valid: false, reason: 'Sem resposta.', confidence: 1, points: 0 }; return; }
    const det = validateDeterministic(cat, a.answerRaw, updated.round.letter);
    if (det.valid === false) { validations[p.identityKey][cat.key] = { ...det, points: 0, answerRaw: a.answerRaw, answerNormalized: a.answerNormalized }; return; }
    if (updated.config.validation.mode === 'fast' || !updated.config.validation.aiEnabled) {
      validations[p.identityKey][cat.key] = { ...det, status: 'VALID', valid: true, reason: 'Aceita pela validação rápida.', confidence: 0.7, points: 0, answerRaw: a.answerRaw, answerNormalized: a.answerNormalized };
      return;
    }
    const cacheKey = `${cat.key}::${a.answerNormalized}::${updated.round.letter}`;
    let aiPromise = aiCache.get(cacheKey); if (!aiPromise) { aiPromise = validateWithAI(cat, a.answerRaw, updated.round.letter); aiCache.set(cacheKey, aiPromise); }
    const ai = await aiPromise;
    const result = { ...ai, answerRaw: a.answerRaw, answerNormalized: a.answerNormalized, submittedAt: Number(a.submittedAt || 0), roundStartedAt: Number(updated.round.startedAt || 0) };
    if (ai.status === 'NEEDS_REVIEW' || ai.valid === null) result.status = 'NEEDS_REVIEW';
    else result.status = ai.valid === true && ai.letter_match !== false && ai.category_match !== false && Number(ai.confidence) >= Number(updated.config.validation.minConfidence) ? 'VALID' : 'INVALID';
    result.points = 0;
    validations[p.identityKey][cat.key] = result;
    await emit('STOP_AI_VALIDATION', { sessionId: s.sessionId, groupId: s.groupId, userId: p.canonicalJid || p.identityKey, category: cat.key, status: result.status, confidence: ai.confidence, validationId });
  };
  for (const p of updated.participants) { const userAnswers = answers[p.identityKey] || {}; validations[p.identityKey] = {}; for (const cat of updated.categoriesSnapshot) jobs.push({ p, cat, a: userAnswers[cat.key] }); }
  let cursor = 0; const workers = Array.from({ length: Math.min(concurrency, jobs.length || 1) }, async () => { while (true) { const i = cursor++; if (i >= jobs.length) return; await validateOne(jobs[i]); } }); await Promise.all(workers);
  scoreRound(updated.participants, validations, updated.config);
  const scoreOperationId = updated.round.scoreOperationId || `STOP_SCORE:${updated.sessionId}:${updated.round.roundVersion}`;
  const scored = await updateBoth(s.gameId, s.groupId, x => {
    if (x.round.scoreOperationId === scoreOperationId && x.status === STOP_STATES.ROUND_RESULT) return x;
    x.round.results = validations; x.round.scoreOperationId = scoreOperationId;
    const summary = x.rounds.find(r => r.roundId === x.round.roundId); if (summary) summary.results = validations;
    for (const p of x.participants) { const total = Object.values(validations[p.identityKey] || {}).reduce((a, v) => a + Number(v.points || 0), 0); p.totalScore = (Number(p.totalScore) || 0) + total; x.scores[p.identityKey] = (x.scores[p.identityKey] || 0) + total; }
    transition(x, STOP_STATES.ROUND_RESULT); x.round.status = STOP_STATES.ROUND_RESULT; return x;
  });
  await persistRoundResults(scored); await persistValidationResults(scored);
  await emit('GAME_SCORE_CALCULATED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId, roundNumber: s.currentRound, scoreOperationId });
  await emit('STOP_SCORE_CALCULATED', { sessionId: s.sessionId, groupId: s.groupId, roundNumber: s.currentRound, scoreOperationId });
  await audit('STOP_SCORE_CALCULATED', scored, { details: { roundNumber: s.currentRound, scoreOperationId } });
  await sendRoundResults(getGameSession(s.gameId)?.state?.stopSession || scored);
}

async function sendRoundResults(s) {
  const rows = s.participants.map(p => { const r = s.round.results?.[p.identityKey] || {}; const vals = Object.values(r); const m = mentionForParticipant(p); return { identityKey: p.identityKey, points: vals.reduce((a, v) => a + Number(v.points || 0), 0), valid: vals.filter(v => String(v.status).startsWith('VALID')).length, unique: vals.filter(v => v.status === 'VALID_UNIQUE').length, dup: vals.filter(v => v.status === 'VALID_DUPLICATE').length, invalid: vals.filter(v => v.status === 'INVALID' || v.status === 'EMPTY').length, mention: m.text, mentions: m.mentions }; }).sort((a, b) => b.points - a.points || b.unique - a.unique);
  const lines = rows.length ? rows.map((x, i) => `${['🥇','🥈','🥉'][i] || `${i + 1}️⃣`} ${x.mention} — ${x.points} pontos\n   ✅ ${x.valid} válidas · ⭐ ${x.unique} únicas${x.dup ? ` · 🔁 ${x.dup} repetidas` : ''}${x.invalid ? ` · ❌ ${x.invalid} inválidas/vazias` : ''}`).join('\n') : 'Ninguém respondeu.';
  const groupText = `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   🏆 RODADA ${s.currentRound}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 Letra: ${s.round.letter}\n⏰ Rodada encerrada!\n\n🏆 RESULTADO\n\n${lines}\n\n━━━━━━━━━━━━━━━━━━\n\n🤖 Validação híbrida concluída.\n╰━━━━━━━━━━━━━━━━━━╯`;
  await ctxSendGroup(s.groupId, groupText, { mentions: rows.flatMap(x => x.mentions) });
  for (const p of s.participants) { const r = s.round.results?.[p.identityKey] || {}; const linesP = s.categoriesSnapshot.map(cat => { const v = r[cat.key]; if (!v || v.status === 'EMPTY') return `📋 ${cat.name}\n⚪ Sem resposta\n+0 pontos`; return `📋 ${cat.name}\n${v.status === 'VALID_UNIQUE' ? '✅' : v.status === 'VALID_DUPLICATE' ? '🟡' : v.status === 'VALID' ? '✅' : v.status === 'NEEDS_REVIEW' ? '🟠' : '❌'} ${v.answerRaw || 'Sem resposta'}\n+${v.points || 0} pontos${v.status === 'NEEDS_REVIEW' ? '\n🟠 Revisão necessária.' : v.status === 'VALID_DUPLICATE' ? '\n🔁 Resposta repetida.' : v.status === 'INVALID' ? `\n💡 ${v.reason || 'Não foi considerada válida.'}` : ''}`; }).join('\n\n'); const total = Object.values(r).reduce((a, v) => a + Number(v.points || 0), 0); try { if (p.canonicalJid) await globalThis.__fantasminhaStopTransport?.sendMessage?.(p.canonicalJid, { text: safeText(`╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   📊 RODADA ${s.currentRound}/${s.roundsTotal}\n╰━━━━━━━━━━━━━━━━━━╯\n\n🔤 Letra: ${s.round.letter}\n\n${linesP}\n\n━━━━━━━━━━━━━━━━━━\n🏆 TOTAL DA RODADA: ${total} PONTOS\n╰━━━━━━━━━━━━━━━━━━╯`) }); } catch {} }
  if (s.currentRound < s.roundsTotal) { await new Promise(resolve => setTimeout(resolve, 300)); const g = getGameSession(s.gameId); if (g) await startRound(sessionFromGame(g), null); } else await finishSession(s);
}

function finalLines(s) { const rows = s.participants.map(p => { const m = mentionForParticipant(p); return { score: Number(p.totalScore) || 0, text: m.text, mentions: m.mentions }; }).sort((a, b) => b.score - a.score); return { text: rows.map((x, i) => `${['🥇','🥈','🥉'][i] || `${i + 1}️⃣`} ${x.text} — ${x.score} pontos`).join('\n') || 'Ninguém participou.', mentions: rows.flatMap(x => x.mentions) }; }
async function finishSession(s) { return lock(`session:${s.gameId}`, async () => { const g = getGameSession(s.gameId); const current = sessionFromGame(g); if (!current || [STOP_STATES.FINISHED, STOP_STATES.CANCELLED, STOP_STATES.EXPIRED].includes(current.status)) return; const fin = await updateBoth(s.gameId, s.groupId, x => { transition(x, STOP_STATES.FINISHED); x.finishedAt = now(); return x; }); const max = Math.max(0, ...fin.participants.map(x => Number(x.totalScore) || 0)); for (const p of fin.participants) { const score = Number(p.totalScore) || 0; try { await stats.recordResult({ groupId: fin.groupId, userId: p.canonicalJid || p.identityKey, gameType: 'STOP', result: 'play', score, win: score === max, operationId: `STOP:${fin.gameId}:${p.identityKey}` }); } catch {} } try { const { recordSession } = await import('./StopStatisticsService.js'); await recordSession(fin); } catch {} await emit('STOP_SESSION_FINISHED', { sessionId: fin.sessionId, groupId: fin.groupId }); await emit('GAME_FINISHED', { gameType: 'STOP', sessionId: fin.sessionId, groupId: fin.groupId }); await audit('STOP_SESSION_FINISHED', fin, { details: { participants: fin.participants.length } }); await game.finishGame(fin.gameId, fin.groupId, { status: 'FINISHED', winnerId: fin.participants.find(p => (Number(p.totalScore) || 0) === max)?.canonicalJid || null, reason: 'all_rounds_finished', result: { rounds: fin.roundsTotal, scores: fin.scores } }); clearTimer(fin.gameId); const final = finalLines(fin); await ctxSendGroup(fin.groupId, `╭━━━━━━━━━━━━━━━━━━╮\n       🛑 STOP\n   🏆 RESULTADO FINAL\n╰━━━━━━━━━━━━━━━━━━╯\n\n🎉 PARTIDA FINALIZADA!\n\n${final.text}\n\n━━━━━━━━━━━━━━━━━━\n🔄 Rodadas: ${fin.roundsTotal}\n📋 Categorias: ${fin.categoriesSnapshot.length}\n\nParabéns a todos! 👻\n╰━━━━━━━━━━━━━━━━━━╯`, { mentions: final.mentions }); }); }

async function cancelSession(s, ctx, reason = 'CANCELLED') { return lock(`session:${s.sessionId}`, async () => { const g = getGameSession(s.gameId); const current = sessionFromGame(g); if (!current || [STOP_STATES.FINISHED, STOP_STATES.CANCELLED, STOP_STATES.EXPIRED].includes(current.status)) return; clearTimer(s.gameId); const cancelled = await updateBoth(s.gameId, s.groupId, x => { transition(x, STOP_STATES.CANCELLED); x.cancelledAt = now(); return x; }); await emit('STOP_SESSION_CANCELLED', { sessionId: s.sessionId, groupId: s.groupId, userId: uid(ctx) }); await emit('GAME_CANCELLED', { gameType: 'STOP', sessionId: s.sessionId, groupId: s.groupId }); await audit('STOP_SESSION_CANCELLED', cancelled, { userId: uid(ctx), details: { reason } }); await game.finishGame(s.gameId, s.groupId, { status: 'CANCELLED', reason, result: { reason } }); await ctx.reply?.('🛑 STOP encerrado. A partida foi cancelada.'); }); }
export async function cancelForContext(ctx) { if (!ctx.isGroup) return { handled: false }; const g = getSessionByGroup(gid(ctx)); if (!g) return { handled: false }; const s = sessionFromGame(g); const identity = await resolveStopIdentity(ctx, uid(ctx)); const allowed = identity.identityKey === s.createdByIdentityKey || ctx.isGroupAdmin || ctx.isOwner || configuredOwner(uid(ctx)); if (!allowed) { await audit('STOP_SESSION_CANCELLED', s, { userId: identity.identityKey, details: { denied: true } }); await emit('STOP_ERROR', { sessionId: s.sessionId, groupId: s.groupId, reason: 'cancel_denied' }); await ctx.reply?.('🚫 Você não possui permissão para cancelar este STOP.'); return { handled: true, denied: true }; } await cancelSession(s, ctx); return { handled: true, cancelled: true }; }

export async function beginSessionConfigure(ctx) { if (!ctx.isGroup) return { handled: false }; const g = getSessionByGroup(gid(ctx)); if (!g) return ctx.reply?.('⚠️ Não existe STOP ativo neste grupo.').then?.(() => ({ handled: true })); const s = sessionFromGame(g); const identity = await resolveStopIdentity(ctx, uid(ctx)); if (identity.identityKey !== s.createdByIdentityKey) return ctx.reply?.('🚫 Somente o criador pode editar a configuração.').then?.(() => ({ handled: true, denied: true })); if (s.status !== STOP_STATES.LOBBY_OPEN) return ctx.reply?.('🔒 A configuração já foi congelada porque o lobby não está mais aberto.').then?.(() => ({ handled: true, locked: true })); await savePrivateState(uid(ctx), { step: 'SESSION_EDIT', sessionId: s.sessionId, identityKey: identity.identityKey, startedAt: now(), updatedAt: now() }); await ctx.sendMessage?.(identity.canonicalJid || uid(ctx), { text: `╭────「 🛑 EDITAR PARTIDA 」────╮\n\n${formatStopConfig(s.config)}\n\nEnvie no PV:\ntempo 60\nrodadas 10\ncategorias Animal, Comida, Lugar\nletra A\n\n🔒 Ao fechar o lobby, a configuração será congelada.\n╰──────────────────────────────╯` }); return { handled: true, opened: true }; }

export async function handleGroupInput(ctx) { if (!ctx.isGroup) return { handled: false }; attachTransport(ctx); const raw = String(ctx.body || ctx.text || '').trim(); const text = n(raw); if (!text) return { handled: false }; const g = getSessionByGroup(gid(ctx)); if (!g) return { handled: false }; const s = sessionFromGame(g); if (s.status === STOP_STATES.WAITING_CREATOR_START && (text === '1' || text === '2')) { const identity = await resolveStopIdentity(ctx, uid(ctx)); if (identity.identityKey !== s.createdByIdentityKey) return { handled: false }; return text === '1' ? startFromCreator(ctx, s) : cancelCreatorStart(ctx, s); } if (text === 'cancelar stop' || text === 'cancelarstop') return cancelForContext(ctx); return { handled: false }; }

export async function recover() { const games = game.listActiveGames().filter(gameActive); const sessions = readCollection('stop_sessions', { byId: {} }).byId || {}; const activeIds = new Set(games.map(g => g.gameId)); const orphanReport = inspectStopOrphans({ games, sessions, activeGameIds: activeIds }); for (const orphan of orphanReport) await audit('STOP_ORPHAN_REPAIRED', null, { details: orphan }); const privateStates = readCollection('stop_private_state', { byUser: {} }).byUser || {}; const expiredPrivate = cleanupPrivateStates(privateStates, now(), 15 * 60 * 1000); if (expiredPrivate) await updateCollection('stop_private_state', db => { db.byUser = privateStates; return db; }, { byUser: {} }); for (const g of games) { const s = sessionFromGame(g); if (!s) continue; await persistSession(s); if (s.status === STOP_STATES.LOBBY_OPEN) { if (now() >= s.lobbyExpiresAt) await closeLobby(g); else schedule(g.gameId, s.lobbyExpiresAt); } else if (s.status === STOP_STATES.ROUND_ACTIVE) { if (now() >= s.round?.expiresAt) await lockRound(g); else schedule(g.gameId, s.round.expiresAt); } else if (s.status === STOP_STATES.ROUND_LOCKED || s.status === STOP_STATES.VALIDATING) await validateRound(s); else if (s.status === STOP_STATES.ROUND_RESULT && s.currentRound >= s.roundsTotal) await finishSession(s); await emit('STOP_RECOVERY', { sessionId: s.sessionId, groupId: s.groupId, status: s.status, orphanCount: orphanReport.length, expiredPrivate }); } return games.length; }
export function stopOrphanCleanup() { const games = game.listActiveGames().filter(gameActive); const sessions = readCollection('stop_sessions', { byId: {} }).byId || {}; const activeIds = new Set(games.map(g => g.gameId)); return inspectStopOrphans({ games, sessions, activeGameIds: activeIds }); }
export const normalize = n;
export const helpers = { normalizeCategories: normalizeCategoryList, validRounds: v => { const x = Number(v); return Number.isInteger(x) && x >= STOP_LIMITS.rounds.min && x <= STOP_LIMITS.rounds.max ? x : null; }, makeStopConfig, validateStopConfig, formatStopConfig };
export default { beginConfig, beginDelete, createSession, handleAnswer, handleConfigPrivate, handleGroupInput, cancelForContext, beginSessionConfigure, recover, stopOrphanCleanup, attachTransport, getConfig, isStopPrivateInputAllowed, getSessionByGroup, getSessionByCode, joinByCode };
