export function summarizeRound(results = {}) {
  const values = Object.values(results || {}).flatMap(v => Object.values(v || {}));
  return { total: values.length, valid: values.filter(v => String(v.status).startsWith('VALID')).length, unique: values.filter(v => v.status === 'VALID_UNIQUE').length, duplicate: values.filter(v => v.status === 'VALID_DUPLICATE').length, invalid: values.filter(v => v.status === 'INVALID').length, needsReview: values.filter(v => v.status === 'NEEDS_REVIEW').length, points: values.reduce((sum, v) => sum + Number(v.points || 0), 0) };
}
export default { summarizeRound };
