const DEFAULT_ROUND_MS = 60_000;
const MIN_POINTS = 10;
const MAX_POINTS = 100;

/**
 * Pontuação do Quem Sou Eu baseada exclusivamente no tempo de resposta da
 * rodada atual. Não usa dificuldade, XP ou número de tentativas.
 *
 * 0s  -> 100 pontos
 * 60s -> 10 pontos
 */
export function calculateWhoamiPoints(responseTimeMs, roundMs = DEFAULT_ROUND_MS) {
  const elapsed = Math.max(0, Number(responseTimeMs) || 0);
  const duration = Math.max(1, Number(roundMs) || DEFAULT_ROUND_MS);
  const ratio = Math.min(1, elapsed / duration);
  const points = Math.round(MAX_POINTS - ((MAX_POINTS - MIN_POINTS) * ratio));
  return Math.max(MIN_POINTS, Math.min(MAX_POINTS, points));
}

export function calculateWhoamiReward({ responseTimeMs, roundMs = DEFAULT_ROUND_MS } = {}) {
  const points = calculateWhoamiPoints(responseTimeMs, roundMs);
  return Object.freeze({
    responseTimeMs: Math.max(0, Number(responseTimeMs) || 0),
    roundMs: Math.max(1, Number(roundMs) || DEFAULT_ROUND_MS),
    points,
  });
}

export const WHOAMI_REWARD_LIMITS = Object.freeze({
  min: MIN_POINTS,
  max: MAX_POINTS,
  roundMs: DEFAULT_ROUND_MS,
});
