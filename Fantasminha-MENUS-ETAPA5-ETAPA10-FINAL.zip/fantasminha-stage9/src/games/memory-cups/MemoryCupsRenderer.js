import { cleanGridTitle, dossierHeader, gameFooter } from '../gamePresentation.js';

const CUP = '🥤';
const GHOST = '👻';
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));

export function render({ cupCount, ghostPosition = null, showGhost = false, offsets = [] } = {}) {
  const count = Math.max(1, Number(cupCount) || 1);
  const cells = [];
  for (let i = 0; i < count; i += 1) {
    const offset = clamp(Number(offsets[i] || 0), -2, 2);
    const left = offset > 0 ? ' '.repeat(offset) : '';
    const right = offset < 0 ? ' '.repeat(Math.abs(offset)) : '';
    const item = showGhost && i === ghostPosition ? GHOST : CUP;
    cells.push(`${left}${item}${right}`);
  }
  return cells.join('   ');
}

export function renderRound({ level, cupCount, ghostPosition, showGhost = false, offsets = [], prompt = '' } = {}) {
  const board = render({ cupCount, ghostPosition, showGhost, offsets });
  return [cleanGridTitle('Memória dos copos'), `Nível ${level}`, '', board, ...(prompt ? ['', prompt] : [])].join('\n');
}

export function renderAnswerPrompt({ level, cupCount } = {}) {
  return renderRound({
    level,
    cupCount,
    showGhost: false,
    prompt: `Onde está o Fantasminha?\nEnvie a posição do copo (1 a ${cupCount}).`
  });
}

export function renderResult({ level, cupCount, selectedPosition, correctPosition, score, bestLevel, streak, timeout = false } = {}) {
  const correct = !timeout && Number(selectedPosition) === Number(correctPosition);
  const selected = selectedPosition == null ? null : `Sua escolha: ${selectedPosition}`;
  return [
    dossierHeader('Resultado · memória dos copos'),
    correct ? '✓ Posição encontrada.' : timeout ? '⏱️ O tempo da rodada terminou.' : '× Posição incorreta.',
    selected,
    `Posição do Fantasminha: ${correctPosition}${cupCount ? ` de ${cupCount}` : ''}`,
    `Nível alcançado: ${level}`,
    `Sequência: ${streak}`,
    `Pontuação: ${score}`,
    `Melhor nível: ${bestLevel}`,
    '',
    gameFooter(correct ? 'sucesso' : 'info', 'game:memory-cups:result')
  ].filter(line => line != null).join('\n');
}

export default { render, renderRound, renderAnswerPrompt, renderResult };
