import { stylize } from '../respostas/estilo.js';
import { pickFrase } from '../respostas/frases.js';

const plain = value => String(value ?? '').trim();

export function hudHeader(title, code = 'JOGO') {
  const safeCode = plain(code).toUpperCase().replace(/[^A-Z0-9_-]/g, '').slice(0, 20) || 'JOGO';
  return `// FANTASMINHA · 0x${safeCode}\n${stylize(plain(title).toUpperCase())}`;
}

export function dossierHeader(title) {
  return `† DOSSIÊ · ${stylize(plain(title).toUpperCase())}`;
}

export function graffitiHeader(title) {
  return `# ${stylize(plain(title).toUpperCase())} · FANTASMINHA`;
}

export function cleanGridTitle(title) {
  return `👻 ${stylize(plain(title).toUpperCase())}`;
}

export function gameFooter(type = 'info', scope = 'game:result') {
  return `† ${pickFrase(type, Math.random, scope)}`;
}
