/**
 * V2 pipeline adapter.
 * Keeps the legacy host thin while preserving the exact V2-first / legacy-fallback contract.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initV2, tryV2Command } from '../../../dados/src/v2bridge.js';
import { consumeFeedbackMessage } from '../../plugins/communityFeedback/index.js';
import { consumeMenuStyleFlow, cancelMenuStyleFlow, hasMenuStyleFlow } from '../../plugins/menuStyle/index.js';
import { getConnectionState, getGroupMetadataReliable, groupHealth, operationalHealth } from '../groupReliability.js';
import { botRoleName, getBotRolePermission } from '../../services/botRoles.js';
import { isRemovedCommand } from '../../core/v2Policy.js';
import { sendPoll } from '../whatsapp/messages.js';
import { getKnownSubBotJids } from '../subBots/identities.js';

export async function runV2Pipeline(deps) {
  const {
    isGroup, isGroupAdmin, isOwner, isBotAdmin, isPremium,
    from, sender, senderOriginal, senderAlternate, command, args, q, body,
    info, pushname, mentionName, mentionedJid, groupPrefix, prefix,
    groupMetadata, groupAdmins, groupData, nazu, reply
  } = deps;

  // O pipeline central precisa observar todas as mensagens: comandos,
  // respostas sem prefixo dos jogos e fluxos privados de códigos.
  // Quando o V2 não tratar a mensagem, o legado continua como fallback.
  const shouldRunV2 = true;
  if (shouldRunV2) {
    try {
      if (hasMenuStyleFlow({ sender, from })) {
        const rawBody = String(body || '').trim();
        const prefixes = [...new Set([groupPrefix, prefix].map(x => String(x || '').trim()).filter(Boolean))];
        if (command || prefixes.some(p => rawBody.startsWith(p))) {
          cancelMenuStyleFlow({ sender, from });
        } else if (isOwner) {
          const flowHandled = await consumeMenuStyleFlow({ sender, from, isOwner, isGroup, groupName: isGroup ? (groupMetadata?.subject || '') : '', sock: nazu, socket: nazu, message: info, reply }, rawBody);
          if (flowHandled) return true;
        } else {
          cancelMenuStyleFlow({ sender, from });
        }
      }
      if (command && isRemovedCommand(command)) {
        await reply('🌑 *Este comando não faz parte do Fantasminha 2.0.*\n\nO sistema foi removido desta versão e não está disponível.');
        return true;
      }
      if (!command) {
        const feedbackHandled = await consumeFeedbackMessage({ sender, from, pushname, isGroup, text: body, body, reply });
        if (feedbackHandled) return true;
      }
      if (!globalThis.__fantasmaV2Ready) {
        globalThis.__fantasmaV2Ready = await initV2();
      }
      const mentionedList = (typeof mentionedJid !== 'undefined' && mentionedJid) ? mentionedJid : (info?.message?.extendedTextMessage?.contextInfo?.mentionedJid || []);
      const quotedCtxMessage = info?.message?.extendedTextMessage?.contextInfo?.quotedMessage || null;
      const quotedText = quotedCtxMessage?.conversation || quotedCtxMessage?.extendedTextMessage?.text || quotedCtxMessage?.imageMessage?.caption || quotedCtxMessage?.videoMessage?.caption || quotedCtxMessage?.documentMessage?.caption || '';
      const v2ctx = {
        body: body,
        text: body,
        message: info,
        command,
        args: Array.isArray(args) ? args : [],
        q: typeof q === 'string' ? q : '',
        quotedText: String(quotedText || '').trim(),
        sender,
        senderOriginal,
        senderAlternate,
        senderAliases: [senderOriginal, senderAlternate].filter(Boolean),
        from,
        pushname: typeof pushname !== 'undefined' ? pushname : '',
        mentionName: typeof mentionName !== 'undefined' ? mentionName : (mentionedList[0] ? String(mentionedList[0]).split('@')[0] : ''),
        quotedParticipant: info?.message?.extendedTextMessage?.contextInfo?.participant || info?.message?.extendedTextMessage?.contextInfo?.remoteJid || '',
        quotedKey: (() => { const ci = info?.message?.extendedTextMessage?.contextInfo; return ci?.stanzaId ? { remoteJid: ci.remoteJid || from, fromMe: false, id: ci.stanzaId, ...(ci.participant ? { participant: ci.participant } : {}) } : null; })(),
        mentioned: mentionedList,
        isOwner: !!isOwner,
        isGroupAdmin: !!isGroupAdmin,
        isBotAdmin: !!isBotAdmin,
        isVip: !!(typeof isPremium !== 'undefined' && isPremium),
        isPremium: !!(typeof isPremium !== 'undefined' && isPremium),
        botRole: isGroup ? (botRoleName(from, sender) || null) : null,
        // Compatibilidade informativa apenas: Aranha é status, não nível de permissão.
        botRolePermission: 0,
        isGroup: !!isGroup,
        isPrivate: !isGroup,
        prefix: typeof groupPrefix !== 'undefined' ? groupPrefix : prefix,
        participantCount: isGroup && groupMetadata ? (groupMetadata.participants || []).length : 0,
        groupParticipants: isGroup && groupMetadata ? (groupMetadata.participants || []).map((p) => p?.id || p?.jid || p?.participant).filter(Boolean) : [],
        groupParticipantObjects: isGroup && groupMetadata ? (groupMetadata.participants || []) : [],
        groupAdmins: isGroup ? groupAdmins : [],
        groupModerators: isGroup ? (groupData.moderators || []) : [],
        groupOwner: isGroup ? (groupMetadata?.owner || groupMetadata?.ownerJid || groupMetadata?.creator || null) : null,
        groupName: isGroup ? (groupMetadata?.subject || '') : '',
        waConnected: getConnectionState().state === 'CONNECTED',
        connectionState: getConnectionState(),
        groupHealth: isGroup ? groupHealth(from) : null,
        botJid: nazu?.user?.id || '',
        subBotJids: getKnownSubBotJids(),
        // Compatibilidade explícita para comandos migrados que ainda utilizam
        // o contrato de socket do dispatcher antigo. O mesmo socket é usado
        // pelos helpers abaixo; não cria uma segunda conexão.
        sock: nazu,
        socket: nazu,
        reply: async (t, options = {}) => reply(t, { ...options, responseKey: options.responseKey || (command ? `command.${String(command).toLowerCase()}.default` : null) }),
        sendMessage: async (jid, content, options = {}) => {
          if (!jid || !nazu?.sendMessage) throw new Error('Socket indisponível');
          return nazu.sendMessage(jid, content, options);
        },
        sendPoll: async (chatId, payload) => sendPoll(nazu, chatId, payload),
        getGroupMetadata: async (jid) => {
          if (!jid || !nazu?.groupMetadata) throw new Error('Socket indisponível');
          return getGroupMetadataReliable(nazu, jid);
        },
        resolvePNForLID: async (lid) => {
          try {
            const value = String(lid || '').trim();
            if (!value) return null;

            const normalized = value.includes('@')
              ? value
              : `${value}@lid`;

            const mapping = nazu?.signalRepository?.lidMapping;

            if (!mapping?.getPNForLID) return null;

            const pn = await mapping.getPNForLID(normalized);

            if (!pn) return null;

            const result = String(pn).trim();

            return result.endsWith('@s.whatsapp.net')
              ? result
              : null;
          } catch (err) {
            console.warn(
              `[LID] Falha ao resolver ${String(lid || '')}: ${err?.message || err}`
            );
            return null;
          }
        },
        listGroups: async () => {
          if (!nazu?.groupFetchAllParticipating) return [];
          const all = await nazu.groupFetchAllParticipating();
          return Object.entries(all || {}).map(([id, g]) => ({ id, name: g?.subject || g?.name || id, subject: g?.subject || '', participants: g?.participants || [] }));
        },
        groupParticipantsUpdate: async (jid, participants, action) => {
          if (!nazu?.groupParticipantsUpdate) throw new Error('Socket indisponível');
          return nazu.groupParticipantsUpdate(jid, participants, action);
        },
        deleteMessage: async (messageKey = info?.key) => {
          if (!nazu?.sendMessage || !from || !messageKey) throw new Error('Mensagem/socket indisponível');
          return nazu.sendMessage(from, { delete: messageKey });
        },
        // Reações automáticas desativadas por design.
        sendWaitReact: async () => undefined,
        sendSuccessReact: async () => undefined,
        sendErrorReply: async (text) => reply(String(text || '❌ Erro ao processar.')),
        sendVideoFromURL: async (url, options={}) => nazu.sendMessage(from, { video:{url}, ...options }),
        sendStickerFromURL: async (url, options={}) => nazu.sendMessage(from, { sticker:{url}, ...options }),
        sendAudioFromFile: async (file, options={}) => nazu.sendMessage(from, { audio:fs.readFileSync(file), mimetype:'audio/mpeg', ptt:false, ...options }),
        sendImageFromFile: async (file, caption='') => nazu.sendMessage(from, { image:fs.readFileSync(file), caption }),
        downloadVideo: async (message) => {
          const { downloadContentFromMessage } = await import('baileys');
          const vm = message?.message?.videoMessage || message?.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage;
          if (!vm) throw new Error('Vídeo não encontrado.');
          const stream = await downloadContentFromMessage(vm, 'video');
          const chunks=[]; for await (const chunk of stream) chunks.push(chunk);
          const tmpDir=path.join(path.dirname(fileURLToPath(import.meta.url)),'../../../data/tmp'); fs.mkdirSync(tmpDir,{recursive:true});
          const file=path.join(tmpDir,`video-${Date.now()}-${Math.random().toString(36).slice(2,8)}.mp4`); fs.writeFileSync(file,Buffer.concat(chunks)); return file;
        },
        extractAudioToMp3: async (input) => {
          const { execFile } = await import('node:child_process'); const { promisify } = await import('node:util'); const run=promisify(execFile);
          const out=input.replace(/\.mp4$/i,'.mp3');
          await run('ffmpeg',['-y','-i',input,'-vn','-codec:a','libmp3lame','-q:a','4',out],{timeout:120000}); return out;
        },
        cleanupTemp: async (file) => { try { if(file && fs.existsSync(file)) fs.unlinkSync(file); } catch {} },
        profilePictureUrl: async (jid) => nazu.profilePictureUrl(jid,'image').catch(()=>null)
      };
      const v2res = await tryV2Command(v2ctx);
      if (v2res && v2res.handled && !v2res.legacy) {
        return true;
      }
    } catch (e) {
      console.error('[v2 pipeline]', e?.message || e);
      return false;
    }
  }
  return false;
}

export default runV2Pipeline;
