/**
 * 👻 Fantasminha — normalização de menções de saída.
 *
 * Objetivo: o bot NUNCA mostra dígitos de LID para o usuário. Toda menção sai
 * com o telefone real (@s.whatsapp.net) tanto em `mentions` quanto no texto
 * (@5511...), para o WhatsApp renderizar como menção clicável (@nome).
 *
 * Resolução LID -> telefone (nesta ordem):
 *   1) metadata do grupo (participant.phoneNumber / .jid / .id)
 *   2) signalRepository.lidMapping.getPNForLID (mapa oficial do Baileys)
 * Se não houver telefone real conhecido, a menção original é mantida (nunca
 * inventamos número a partir de LID).
 */
import { getGroupMetadataReliable } from '../groupReliability.js';

const baseOf = v => String(v || '').split('@')[0].split(':')[0].trim();
const isLidJid = v => typeof v === 'string' && v.endsWith('@lid');
const isPnJid = v => typeof v === 'string' && v.endsWith('@s.whatsapp.net');
const isGroupJid = v => typeof v === 'string' && v.endsWith('@g.us');
const toPn = v => {
  const s = String(v || '').trim().toLowerCase();
  if (!s) return null;
  if (isPnJid(s)) return `${baseOf(s)}@s.whatsapp.net`;
  return null;
};

function pnFromParticipants(participants, lidJid) {
  const base = baseOf(lidJid);
  for (const p of participants || []) {
    const ids = [p?.id, p?.lid, p?.jid, p?.participant].filter(Boolean);
    if (!ids.some(x => baseOf(x) === base)) continue;
    const direct = [p?.phoneNumber, p?.pn, p?.jid, p?.id, p?.participant].map(toPn).find(Boolean);
    if (direct) return direct;
    const digits = String(p?.phoneNumber || p?.pn || '').replace(/\D/g, '');
    if (digits) return `${digits}@s.whatsapp.net`;
  }
  return null;
}

export async function resolveOutgoingMentionJid(sock, chatJid, lidJid, options = {}) {
  const cache = options.cache || new Map();
  const participantsRef = options.participantsRef || { loaded: false, list: [] };
  if (!isLidJid(lidJid)) return lidJid;
  return (await resolvePn(sock, chatJid, lidJid, cache, participantsRef)) || lidJid;
}

async function resolvePn(sock, chatJid, lidJid, cache, participantsRef) {
  const key = baseOf(lidJid);
  if (cache.has(key)) return cache.get(key);
  let pn = null;

  if (String(chatJid || '').endsWith('@g.us')) {
    if (!participantsRef.loaded) {
      participantsRef.loaded = true;
      try { participantsRef.list = (await getGroupMetadataReliable(sock, chatJid))?.participants || []; } catch { participantsRef.list = []; }
    }
    pn = pnFromParticipants(participantsRef.list, lidJid);
  }

  if (!pn) {
    try {
      const mapped = await sock?.signalRepository?.lidMapping?.getPNForLID?.(lidJid);
      pn = toPn(mapped);
    } catch {}
  }

  cache.set(key, pn);
  return pn;
}

/**
 * Retorna um novo conteúdo com menções/ texto normalizados. Não muta o original.
 */
export async function normalizeOutgoingMentions(sock, chatJid, content) {
  if (!content || typeof content !== 'object' || Array.isArray(content)) return content;

  const topMentions = Array.isArray(content.mentions) ? content.mentions : null;
  const ctxMentions = Array.isArray(content.contextInfo?.mentionedJid) ? content.contextInfo.mentionedJid : null;
  const all = [...(topMentions || []), ...(ctxMentions || [])].filter(v => typeof v === 'string');
  const textSources = [content.text, content.caption].filter(v => typeof v === 'string');
  const textMentionDigits = new Set();
  for (const text of textSources) {
    for (const m of String(text).matchAll(/@(\d{5,})/g)) textMentionDigits.add(m[1]);
  }

  const cache = new Map();
  const participantsRef = { loaded: false, list: [] };
  const digitMap = new Map(); // dígitos do LID -> dígitos do telefone

  // Quando um comando escreveu @<LID> no texto mas esqueceu de preencher
  // `mentions`, tentamos identificar esse LID pelos participantes do grupo.
  // Nunca tratamos os dígitos do LID como telefone por conta própria.
  if (isGroupJid(chatJid) && textMentionDigits.size) {
    if (!participantsRef.loaded) {
      participantsRef.loaded = true;
      try { participantsRef.list = (await getGroupMetadataReliable(sock, chatJid))?.participants || []; } catch { participantsRef.list = []; }
    }
    for (const lidDigits of textMentionDigits) {
      const participant = participantsRef.list.find(p => [p?.lid, p?.id, p?.participant].some(v => isLidJid(String(v || '')) && baseOf(v) === lidDigits));
      const pn = participant ? pnFromParticipants([participant], `${lidDigits}@lid`) : null;
      if (pn) digitMap.set(lidDigits, baseOf(pn));
    }
  }
  const mapJid = async jid => {
    if (!isLidJid(jid)) return jid;
    const pn = await resolvePn(sock, chatJid, jid, cache, participantsRef);
    if (!pn) return jid;
    digitMap.set(baseOf(jid), baseOf(pn));
    return pn;
  };
  const mapList = async list => {
    const out = [];
    for (const j of list) { const m = await mapJid(j); if (!out.includes(m)) out.push(m); }
    return out;
  };

  const next = { ...content };
  if (topMentions) next.mentions = await mapList(topMentions);
  if (ctxMentions) next.contextInfo = { ...content.contextInfo, mentionedJid: await mapList(ctxMentions) };
  if (!digitMap.size) return next;

  const rewrite = text => String(text).replace(/@(\d{5,})(?!\d)/g, (m, d) => (digitMap.has(d) ? `@${digitMap.get(d)}` : m));
  if (typeof next.text === 'string') next.text = rewrite(next.text);
  if (typeof next.caption === 'string') next.caption = rewrite(next.caption);
  return next;
}

/** Envolve o sendMessage de um socket (uma única vez). Falhas nunca bloqueiam o envio. */
export function installOutgoingMentionNormalizer(sock) {
  if (!sock || typeof sock.sendMessage !== 'function' || sock.__mentionNormalizerInstalled) return sock;
  const original = sock.sendMessage.bind(sock);
  sock.sendMessage = async (jid, content, ...rest) => {
    let safe = content;
    try { safe = await normalizeOutgoingMentions(sock, jid, content); } catch { safe = content; }
    return original(jid, safe, ...rest);
  };
  sock.__mentionNormalizerInstalled = true;
  return sock;
}

export default { normalizeOutgoingMentions, resolveOutgoingMentionJid, installOutgoingMentionNormalizer };
