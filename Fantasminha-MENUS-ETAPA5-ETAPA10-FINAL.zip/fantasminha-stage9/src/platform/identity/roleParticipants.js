function normalizeIdentity(value) {
  return typeof value === 'string' ? value.trim().toLowerCase() : '';
}

export function roleIdentityCandidates(...values) {
  const flattened = values.flat(Infinity);
  return [...new Set(flattened.map(normalizeIdentity).filter(Boolean))];
}

export function hasRoleParticipant(list, identityCandidates) {
  if (!Array.isArray(list)) return false;
  const candidates = new Set(roleIdentityCandidates(identityCandidates));
  if (!candidates.size) return false;
  return list.some(value => candidates.has(normalizeIdentity(value)));
}

export function updateRolePresence(participants, identityCandidates, canonicalIdentity, presence) {
  if (!participants || typeof participants !== 'object') {
    throw new TypeError('participants deve ser um objeto');
  }
  if (!['going', 'notGoing', null].includes(presence)) {
    throw new TypeError('presence deve ser going, notGoing ou null');
  }

  const candidates = roleIdentityCandidates(identityCandidates);
  const canonical = normalizeIdentity(canonicalIdentity);
  if (!candidates.length || (presence && !canonical)) {
    return { changed: false, wasGoing: false, wasNotGoing: false };
  }

  const going = Array.isArray(participants.going) ? participants.going : [];
  const notGoing = Array.isArray(participants.notGoing) ? participants.notGoing : [];
  const wasGoing = hasRoleParticipant(going, candidates);
  const wasNotGoing = hasRoleParticipant(notGoing, candidates);
  const candidateSet = new Set(candidates);
  const nextGoing = going.filter(value => !candidateSet.has(normalizeIdentity(value)));
  const nextNotGoing = notGoing.filter(value => !candidateSet.has(normalizeIdentity(value)));

  if (presence === 'going') nextGoing.push(canonical);
  if (presence === 'notGoing') nextNotGoing.push(canonical);

  const changed = !sameArray(going, nextGoing) || !sameArray(notGoing, nextNotGoing);
  participants.going = nextGoing;
  participants.notGoing = nextNotGoing;
  return { changed, wasGoing, wasNotGoing };
}

function sameArray(left, right) {
  return left.length === right.length && left.every((value, index) => value === right[index]);
}
