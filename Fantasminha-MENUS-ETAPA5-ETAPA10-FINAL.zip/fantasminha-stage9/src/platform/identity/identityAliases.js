const normalizeAddress = (value) => {
  if (typeof value !== 'string') return null;
  const normalized = value.trim().toLowerCase().replace(/:\d+(?=@)/, '');
  if (normalized.endsWith('@lid') || normalized.endsWith('@s.whatsapp.net')) return normalized;
  return null;
};

export function identityCandidatesOverlap(left = [], right = []) {
  const leftValues = (Array.isArray(left) ? left : [left]).map(normalizeAddress).filter(Boolean);
  const rightValues = new Set((Array.isArray(right) ? right : [right]).map(normalizeAddress).filter(Boolean));
  return leftValues.some(value => rightValues.has(value));
}
