import { isLid, normalizeJid, phoneFromJid } from './lid.js';

const asJid = v => normalizeJid(v);
const pn = v => {
  const s = normalizeJid(v);
  if (!s) return null;
  if (s.endsWith('@s.whatsapp.net')) return s;
  const digits = s.replace(/\D/g, '');
  return digits ? `${digits}@s.whatsapp.net` : null;
};

function participantCandidates(p = {}) {
  return [p.jid, p.id, p.participant, p.phoneNumber, p.pn, p.phone, p.number].filter(Boolean).map(asJid);
}

export function participantRealJid(p = {}) {
  const candidates = participantCandidates(p);
  const direct = candidates.find(x => x.endsWith('@s.whatsapp.net'));
  if (direct) return direct;
  const rawPhone = p.phoneNumber || p.pn || p.phone || p.number;
  return pn(rawPhone);
}

export function buildIdentityIndex(participants = []) {
  const byAny = new Map();
  const rows = [];
  for (const p of participants || []) {
    if (!p) continue;
    const realJid = participantRealJid(p);
    const lid = [p.lid, p.id, p.participant].map(asJid).find(isLid) || null;
    const row = { realJid, lid, name: p.name || p.notify || p.pushName || p.pushname || '', pushName: p.pushName || p.pushname || p.notify || p.name || '', raw: p };
    rows.push(row);
    for (const x of participantCandidates(p)) byAny.set(x, row);
    if (lid) byAny.set(lid, row);
    if (realJid) byAny.set(realJid, row);
  }
  return { byAny, rows };
}

export async function resolveUserIdentity(ctx = {}, target = null) {
  const requested = normalizeJid(target || ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.sender || '');
  const requestedBase = requested.split('@')[0].split(':')[0];
  let participants = Array.isArray(ctx.groupParticipantObjects) ? ctx.groupParticipantObjects : [];
  if (!participants.length && ctx.getGroupMetadata && ctx.from?.endsWith('@g.us')) {
    try { participants = (await ctx.getGroupMetadata(ctx.from))?.participants || []; } catch {}
  }
  const index = buildIdentityIndex(participants);
  let row = index.byAny.get(requested);
  if (!row && requestedBase) row = index.rows.find(x => [x.realJid, x.lid].some(v => v?.split('@')[0].split(':')[0] === requestedBase));
  const senderAlternates = [ctx.sender, ctx.senderOriginal, ctx.senderAlternate].filter(Boolean).map(asJid);
  if (!row) for (const alt of senderAlternates) { row = index.byAny.get(alt); if (row) break; }

  let mappedPN = null;

  // ================================================================
  // RESOLUÇÃO REAL LID -> PN
  // ================================================================
  // Nunca utilizar os dígitos de @lid como telefone.
  // O telefone real deve vir exclusivamente do LIDMappingStore
  // ou de um PN já identificado como @s.whatsapp.net.
  if (typeof ctx.resolvePNForLID === 'function') {
    const lidCandidates = [
      isLid(requested) ? requested : null,
      row?.lid || null,
      row?.raw?.lid || null,
      row?.raw?.id && isLid(asJid(row.raw.id))
        ? asJid(row.raw.id)
        : null,
      row?.raw?.participant && isLid(asJid(row.raw.participant))
        ? asJid(row.raw.participant)
        : null
    ].filter(Boolean);

    for (const lid of [...new Set(lidCandidates)]) {
      try {
        const resolved = await ctx.resolvePNForLID(lid);

        if (!resolved) continue;

        const value = String(resolved).trim();

        if (value.endsWith('@s.whatsapp.net')) {
          mappedPN = value;
          break;
        }

        const digits = value.replace(/\D/g, '');

        if (digits) {
          mappedPN = `${digits}@s.whatsapp.net`;
          break;
        }
      } catch (err) {
        console.warn(
          `[IDENTITY] Falha ao resolver LID ${lid}: ${err?.message || err}`
        );
      }
    }
  }

  // IMPORTANTE:
  // mappedPN tem prioridade porque representa a resolução atual
  // do LID pelo armazenamento oficial do Baileys.
  const realJid =
    mappedPN ||
    row?.realJid ||
    (!isLid(requested) ? pn(requested) : null);
  const lid = row?.lid || (isLid(requested) ? requested : null);
  const number = phoneFromJid(realJid) || (row?.raw?.phoneNumber ? String(row.raw.phoneNumber).replace(/\D/g, '') : null);
  return {
    requested,
    number,
    realJid,
    lid,
    name: row?.name || ctx.pushname || '',
    pushName: row?.pushName || ctx.pushname || '',
    mentionJid: realJid || null,
    isResolvable: !!realJid,
    raw: row?.raw || null
  };
}


export async function resolveBotIdentity(ctx = {}, groupId = null) {
  const gid = groupId || ctx.from || '';
  // Correção: quando o chamador já buscou e passou os participantes do
  // grupo verificado (fluxos de contexto do grupo,
  // que sempre checam um grupo diferente do grupo atual), esses participantes
  // devem ser usados diretamente — nunca descartados. Antes, a condição
  // "gid === ctx.from" jogava fora a lista sempre que o grupo verificado era
  // diferente do grupo atual (ou seja, sempre, nesses fluxos), forçando uma
  // segunda busca de metadados redundante e sujeita a falhar por conta própria.
  let participants = Array.isArray(ctx.groupParticipantObjects)
    ? ctx.groupParticipantObjects
    : [];
  if (!participants.length && ctx.getGroupMetadata && gid?.endsWith('@g.us')) {
    try { participants = (await ctx.getGroupMetadata(gid))?.participants || []; } catch {}
  }
  const index = buildIdentityIndex(participants);
  const candidates = [
    ctx.botJid, ctx.botJidOriginal, ctx.botJidAlternate,
    ...(Array.isArray(ctx.botAliases) ? ctx.botAliases : []),
    ctx.user?.id
  ].filter(Boolean).map(asJid);
  let row = null;
  for (const candidate of candidates) {
    row = index.byAny.get(candidate);
    if (row) break;
    const base = candidate.split('@')[0].split(':')[0];
    if (base) {
      row = index.rows.find(x => [x.realJid, x.lid].some(v => v?.split('@')[0].split(':')[0] === base));
      if (row) break;
    }
  }
  const identity = row || (candidates[0] ? await resolveUserIdentity({ ...ctx, groupParticipantObjects: participants }, candidates[0]) : null);
  return {
    realJid: identity?.realJid || null,
    lid: identity?.lid || null,
    name: identity?.name || '',
    participant: identity?.raw || null,
    candidates: [...new Set(candidates)],
    participants
  };
}

export async function isBotGroupAdmin(ctx = {}, groupId = null) {
  const identity = await resolveBotIdentity(ctx, groupId);
  const p = identity.participant;
  return {
    ok: !!(p && (p.admin === 'admin' || p.admin === 'superadmin' || p.admin === true)),
    ...identity,
    role: p?.admin || null
  };
}

export async function resolveMentionTargets(ctx, targets = null) {
  const raw = targets || (ctx.mentioned?.length ? ctx.mentioned : ctx.quotedParticipant ? [ctx.quotedParticipant] : [ctx.sender]);
  const out = [];
  for (const target of raw) {
    const r = await resolveUserIdentity(ctx, target);
    if (r.realJid && !out.some(x => x.realJid === r.realJid)) out.push(r);
  }
  return out;
}

export default { resolveUserIdentity, resolveMentionTargets, resolveBotIdentity, isBotGroupAdmin, buildIdentityIndex, participantRealJid };
