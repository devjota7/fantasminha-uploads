const normalizeJid = (value, domain) => {
  if (typeof value !== 'string') return null;
  const normalized = value.trim().toLowerCase();
  const at = normalized.lastIndexOf('@');
  if (at < 1 || normalized.slice(at + 1) !== domain) return null;
  const local = normalized.slice(0, at).split(':')[0];
  if (!/^\d+$/.test(local)) return null;
  return `${local}@${domain}`;
};

export async function resolveMentionJids(userIds, resolvePNForLID) {
  const mentions = new Set();
  for (const raw of Array.isArray(userIds) ? userIds : []) {
    if (typeof raw !== 'string') continue;
    const normalized = raw.trim().toLowerCase();
    const direct = normalizeJid(normalized, 's.whatsapp.net');
    if (direct) {
      mentions.add(direct);
      continue;
    }
    const lid = normalizeJid(normalized, 'lid');
    if (!lid || typeof resolvePNForLID !== 'function') continue;
    try {
      const resolved = await resolvePNForLID(lid);
      const pn = normalizeJid(typeof resolved === 'string' ? resolved : '', 's.whatsapp.net');
      if (pn) mentions.add(pn);
    } catch {
      // LID sem resolução segura é omitido em vez de enviar menção inválida.
    }
  }
  return [...mentions];
}
