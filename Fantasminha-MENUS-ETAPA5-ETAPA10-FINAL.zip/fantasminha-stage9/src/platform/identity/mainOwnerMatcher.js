const normalizeAddress = (value) => {
  if (typeof value !== 'string') return null;
  const raw = value.trim().toLowerCase();
  if (/^\+?\d{5,20}$/.test(raw)) return `${raw.replace(/\D/g, '')}@s.whatsapp.net`;
  const at = raw.lastIndexOf('@');
  if (at < 1) return null;
  const domain = raw.slice(at + 1);
  if (domain !== 'lid' && domain !== 's.whatsapp.net') return null;
  const local = raw.slice(0, at).split(':')[0];
  if (!/^\d+$/.test(local)) return null;
  return `${local}@${domain}`;
};

export function isMainOwnerIdentityMatch({
  ownerBase,
  senderOriginal,
  sender,
  senderResolvedPN,
  nmrdn,
  ownerJid,
  lidownerAtual,
  fromMe = false,
  isBotSender = false
} = {}) {
  if (fromMe || isBotSender) return true;

  const actorIds = new Set([senderOriginal, sender, senderResolvedPN].map(normalizeAddress).filter(Boolean));
  if (!actorIds.size) return false;

  const ownerPhone = String(ownerBase || '').replace(/\D/g, '');
  if (ownerPhone && actorIds.has(`${ownerPhone}@s.whatsapp.net`)) return true;

  for (const configuredIdentity of [nmrdn, ownerJid, lidownerAtual]) {
    const normalized = normalizeAddress(configuredIdentity);
    if (normalized && actorIds.has(normalized)) return true;
  }
  return false;
}
