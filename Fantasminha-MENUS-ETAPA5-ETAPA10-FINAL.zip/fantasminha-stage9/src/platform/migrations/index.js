import { readCollection, updateCollection } from '../../database/store.js';
import { emit, PlatformEvents } from '../events/index.js';
const COLLECTION = 'migration_registry';
const migrations = new Map();

function load() {
  const data = readCollection(COLLECTION, { used: {} });
  if (!data.used || typeof data.used !== 'object') data.used = {};
  return data;
}

export function registerMigration({ legacy, target, mode='silent', enabled=true, note=null } = {}) {
  if (!legacy || !target) throw new Error('Migração exige legacy e target');
  const m = { legacy: String(legacy).toLowerCase(), target: String(target).toLowerCase(), mode, enabled, note };
  migrations.set(m.legacy, m);
  return m;
}

export function resolveMigration(name) {
  const m = migrations.get(String(name || '').toLowerCase());
  return m?.enabled ? m : null;
}

export async function noteMigrationUsed(m, ctx = {}) {
  if (!m?.legacy) throw new Error('Migração inválida');
  let count = 0;
  await updateCollection(COLLECTION, data => {
    data.used ||= {};
    count = data.used[m.legacy] = (data.used[m.legacy] || 0) + 1;
    return data;
  }, { used: {} });
  await emit(PlatformEvents.MIGRATION_USED, { migration: m, ctx, count });
  return count;
}

export function listMigrations() {
  const used = load().used || {};
  return [...migrations.values()].map(m => ({ ...m, uses: used[m.legacy] || 0 }));
}

export default { registerMigration, resolveMigration, noteMigrationUsed, listMigrations };
