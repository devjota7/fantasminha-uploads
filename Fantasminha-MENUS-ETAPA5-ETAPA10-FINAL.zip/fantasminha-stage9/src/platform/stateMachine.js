const LICENSE = Object.freeze({
  pending: ['active'], active: ['active','expired','suspended','cancelled'],
  suspended: ['active','cancelled'], expired: [], cancelled: [], revoked: []
});

export function canTransition(kind, from, to) {
  const map = kind === 'license' ? LICENSE : null;
  if (!map) return false;
  return (map[String(from || '').toLowerCase()] || []).includes(String(to || '').toLowerCase());
}

export function assertTransition(kind, from, to) {
  if (!canTransition(kind, from, to)) throw Object.assign(new Error('invalid_state_transition'), { code: 'invalid_state_transition', kind, from, to });
  return true;
}

export default { canTransition, assertTransition };
