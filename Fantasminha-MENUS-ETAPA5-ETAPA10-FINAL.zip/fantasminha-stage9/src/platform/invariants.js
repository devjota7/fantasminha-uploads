import commercial from '../services/platformCommercial.js';

export function commercialInvariants() {
  const d = commercial.commercialLifecycleIntegrity();
  const issues = [...(d.issues || [])];
  for (const r of commercial.listRentals()) {
    if (!r.rentalId || !r.groupId) issues.push({ type: 'RENTAL_IDENTITY_INVALID', rentalId: r.rentalId || null });
    if (r.active && r.state !== 'ACTIVE') issues.push({ type: 'RENTAL_ACTIVE_STATE_MISMATCH', rentalId: r.rentalId });
    if (!r.permanent && r.state === 'ACTIVE' && !Number.isFinite(Number(r.expiresAt))) issues.push({ type: 'RENTAL_ACTIVE_EXPIRY_INVALID', rentalId: r.rentalId });
  }
  return { ok: issues.length === 0, issues, checkedAt: Date.now() };
}

export function assertCommercialIntegrity() {
  const result = commercialInvariants();
  if (!result.ok) throw Object.assign(new Error('commercial_integrity_error'), { code: 'commercial_integrity_error', details: result });
  return result;
}

export default { commercialInvariants, assertCommercialIntegrity };
