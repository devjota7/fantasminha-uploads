import crypto from 'node:crypto';
import { promisify } from 'node:util';
import path from 'node:path';
import fs from 'node:fs';
import { recordAudit } from '../audit/index.js';
import { DB_ROOT, readCollection, updateCollection } from '../../database/store.js';
import { env } from '../../config/env.js';

const scrypt = promisify(crypto.scrypt);
const SESSION_COOKIE = 'fantasminha_session';
const SESSION_TTL_MS = clamp(Number(env.WEB_AUTH_SESSION_TTL_MS || 8 * 60 * 60 * 1000), 5 * 60 * 1000, 24 * 60 * 60 * 1000);
const RATE_WINDOW_MS = clamp(Number(env.WEB_AUTH_RATE_WINDOW_MS || 15 * 60 * 1000), 60 * 1000, 60 * 60 * 1000);
const RATE_MAX = clamp(Number(env.WEB_AUTH_RATE_MAX || 5), 3, 20);
const RATE_MAX_IP = clamp(Number(env.WEB_AUTH_RATE_MAX_IP || env.WEB_AUTH_RATE_MAX || 5), 3, 100);
const RATE_MAX_USER = clamp(Number(env.WEB_AUTH_RATE_MAX_USER || env.WEB_AUTH_RATE_MAX || 5), 3, 100);
const RATE_PERSIST = env.WEB_AUTH_RATE_PERSIST === 'true';
const TOTP_STEP_MS = 30_000;
const TOTP_REPLAY_MS = 90_000;
const TOTP_DIGITS = 6;
const NOTIFY_FAILURE_THRESHOLD = clamp(Number(env.WEB_AUTH_NOTIFY_FAILURE_THRESHOLD || 3), 1, 20);

const sessions = new Map();
const SESSION_COLLECTION = 'web_auth_sessions';
const EMPTY_SESSIONS = { version: 1, sessions: {} };
function persistedSessions() { return readCollection(SESSION_COLLECTION, EMPTY_SESSIONS); }
async function persistSession(key, value) { await updateCollection(SESSION_COLLECTION, d => { d.sessions ||= {}; d.sessions[key] = value; return d; }, EMPTY_SESSIONS); }
async function deletePersistedSession(key) { await updateCollection(SESSION_COLLECTION, d => { d.sessions ||= {}; delete d.sessions[key]; return d; }, EMPTY_SESSIONS); }
const attempts = new Map();
let rateDb = null;
let rateDbReady = false;
let rateDbInitAttempted = false;
let rateDbPath = null;
let whatsappNotifier = null;

function clamp(value, min, max) { return Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : min; }
function configuredUsername() { return String(env.WEB_AUTH_USERNAME || '').trim(); }
function configuredPasswordHash() { return String(env.WEB_AUTH_PASSWORD_HASH || '').trim(); }
function configuredTotpSecret() { return normalizeBase32(env.WEB_AUTH_TOTP_SECRET || ''); }
function totpEnabled() { return !!configuredTotpSecret(); }
function notifyEnabled() { return env.WEB_AUTH_NOTIFY_OWNER === 'true'; }
function secureCookie() { return env.WEB_AUTH_COOKIE_SECURE === undefined ? env.NODE_ENV === 'production' : env.WEB_AUTH_COOKIE_SECURE === 'true'; }
function genericCredentialError() { return Object.assign(new Error('Credenciais inválidas.'), { code: 'INVALID_CREDENTIALS', statusCode: 401 }); }
function notConfiguredError() { return Object.assign(new Error('Autenticação do proprietário não está configurada.'), { code: 'AUTH_NOT_CONFIGURED', statusCode: 503 }); }

function normalizeBase32(value) {
  return String(value || '').toUpperCase().replace(/[\s-]/g, '').replace(/=+$/g, '');
}

function validBase32(value) {
  return /^[A-Z2-7]+$/.test(value) && value.length >= 16;
}

function parseCookie(header = '') {
  const out = {};
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    try { out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); } catch {}
  }
  return out;
}

function tokenDigest(token) { return crypto.createHash('sha256').update(token).digest('hex'); }

function sameSecret(a, b) {
  const aa = Buffer.isBuffer(a) ? a : Buffer.from(String(a));
  const bb = Buffer.isBuffer(b) ? b : Buffer.from(String(b));
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function parsePasswordHash(value) {
  const parts = String(value).split('$');
  if (parts.length !== 6 || parts[0] !== 'scrypt') return null;
  const N = Number(parts[1]);
  const r = Number(parts[2]);
  const p = Number(parts[3]);
  if (!Number.isInteger(N) || !Number.isInteger(r) || !Number.isInteger(p) || N < 16384 || r < 8 || p < 1 || N > 2 ** 20 || r > 32 || p > 8) return null;
  try { return { N, r, p, salt: Buffer.from(parts[4], 'base64url'), hash: Buffer.from(parts[5], 'base64url') }; } catch { return null; }
}

export async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const N = 16384, r = 8, p = 1;
  const derived = await scrypt(String(password), salt, 64, { N, r, p, maxmem: 32 * 1024 * 1024 });
  return `scrypt$${N}$${r}$${p}$${salt.toString('base64url')}$${Buffer.from(derived).toString('base64url')}`;
}

async function verifyPassword(password, encoded) {
  const parsed = parsePasswordHash(encoded);
  if (!parsed) return false;
  const derived = await scrypt(String(password), parsed.salt, parsed.hash.length, { N: parsed.N, r: parsed.r, p: parsed.p, maxmem: 32 * 1024 * 1024 });
  return sameSecret(derived, parsed.hash);
}

function rateKey(kind, value) { return `${kind}|${String(value || '').trim().toLowerCase().slice(0, 160)}`; }
function rateLimitForKey(key) { return key.startsWith('ip|') ? RATE_MAX_IP : RATE_MAX_USER; }

function ensureRateDb() {
  if (!RATE_PERSIST || rateDbReady || rateDbInitAttempted) return rateDbReady;
  rateDbInitAttempted = true;
  try {
    const { DatabaseSync } = requireNodeSqlite();
    if (!DatabaseSync) throw new Error('node:sqlite indisponível');
    fs.mkdirSync(DB_ROOT, { recursive: true });
    rateDbPath = path.join(DB_ROOT, 'web_auth.sqlite');
    rateDb = new DatabaseSync(rateDbPath);
    rateDb.exec(`
      CREATE TABLE IF NOT EXISTS web_auth_attempts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL,
        value TEXT NOT NULL,
        at INTEGER NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_web_auth_attempts_lookup
        ON web_auth_attempts(kind, value, at);
    `);
    rateDbReady = true;
    return true;
  } catch (error) {
    rateDb = null;
    rateDbReady = false;
    console.warn(`[WEB-AUTH] persistência SQLite indisponível; usando memória: ${error?.message || error}`);
    return false;
  }
}

/*
 * O projeto fornecido usa atualmente JSON em src/database/store.js, não SQLite.
 * Para não introduzir uma dependência nativa pesada, a persistência de rate-limit
 * usa node:sqlite quando o runtime fornece essa API. Em runtimes sem ela, cai
 * silenciosamente para memória, preservando a disponibilidade do login.
 */
function requireNodeSqlite() {
  try {
    // eslint-disable-next-line no-undef
    return globalThis.__fantasminhaNodeSqlite || null;
  } catch {
    return null;
  }
}

async function initializeRatePersistence() {
  if (!RATE_PERSIST || rateDbInitAttempted) return;
  try {
    const sqlite = await import('node:sqlite');
    globalThis.__fantasminhaNodeSqlite = sqlite;
  } catch {}
  ensureRateDb();
}

function dbRows(kind, value, cutoff) {
  if (!ensureRateDb()) return null;
  try {
    return rateDb.prepare('SELECT at FROM web_auth_attempts WHERE kind = ? AND value = ? AND at >= ? ORDER BY at ASC').all(kind, value, cutoff).map(row => Number(row.at));
  } catch (error) {
    console.warn(`[WEB-AUTH] leitura SQLite falhou; usando memória: ${error?.message || error}`);
    return null;
  }
}

function memoryRows(key, cutoff) {
  const state = attempts.get(key);
  if (!state) return [];
  state.timestamps = state.timestamps.filter(at => at >= cutoff);
  if (!state.timestamps.length) attempts.delete(key);
  return state.timestamps;
}

function getAttemptTimestamps(kind, value, now = Date.now()) {
  const key = rateKey(kind, value);
  const cutoff = now - RATE_WINDOW_MS;
  const persisted = dbRows(kind, String(value || '').trim().toLowerCase().slice(0, 160), cutoff);
  return persisted ?? memoryRows(key, cutoff);
}

function purgePersisted(cutoff) {
  if (!ensureRateDb()) return;
  try { rateDb.prepare('DELETE FROM web_auth_attempts WHERE at < ?').run(cutoff); } catch {}
}

function persistFailure(kind, value, now) {
  if (!ensureRateDb()) return;
  try {
    rateDb.prepare('INSERT INTO web_auth_attempts(kind, value, at) VALUES (?, ?, ?)').run(kind, String(value || '').trim().toLowerCase().slice(0, 160), now);
  } catch (error) {
    console.warn(`[WEB-AUTH] escrita SQLite falhou; usando memória: ${error?.message || error}`);
  }
}

function deletePersisted(kind, value) {
  if (!ensureRateDb()) return;
  try { rateDb.prepare('DELETE FROM web_auth_attempts WHERE kind = ? AND value = ?').run(kind, String(value || '').trim().toLowerCase().slice(0, 160)); } catch {}
}

function rateRetryAfter(ip, username) {
  const now = Date.now();
  let retryAfter = 0;
  for (const [kind, value] of [['ip', ip], ['user', username]]) {
    const timestamps = getAttemptTimestamps(kind, value, now);
    const max = rateLimitForKey(rateKey(kind, value));
    if (timestamps.length >= max) {
      const oldest = timestamps[0] || now;
      retryAfter = Math.max(retryAfter, Math.max(1, Math.ceil((oldest + RATE_WINDOW_MS - now) / 1000)));
    }
  }
  return retryAfter;
}

function recordFailure(ip, username) {
  const now = Date.now();
  for (const [kind, value] of [['ip', ip], ['user', username]]) {
    const key = rateKey(kind, value);
    const cutoff = now - RATE_WINDOW_MS;
    const timestamps = memoryRows(key, cutoff);
    timestamps.push(now);
    attempts.set(key, { timestamps });
    persistFailure(kind, value, now);
  }
  purgePersisted(now - RATE_WINDOW_MS);
}

function failureCount(ip, username) {
  return Math.max(
    getAttemptTimestamps('ip', ip).length,
    getAttemptTimestamps('user', username).length
  );
}

function clearRate(ip, username) {
  for (const [kind, value] of [['ip', ip], ['user', username]]) {
    attempts.delete(rateKey(kind, value));
    deletePersisted(kind, value);
  }
}

function cleanup() {
  const now = Date.now();
  for (const [key, value] of attempts) {
    value.timestamps = value.timestamps.filter(at => now - at < RATE_WINDOW_MS);
    if (!value.timestamps.length) attempts.delete(key);
  }
  purgePersisted(now - RATE_WINDOW_MS);
  for (const [key, value] of sessions) if (value.expiresAt <= now) sessions.delete(key);
}

const cleanupTimer = setInterval(cleanup, Math.min(RATE_WINDOW_MS, 5 * 60 * 1000));
cleanupTimer.unref?.();
await initializeRatePersistence();

function totpCounterFor(timestamp = Date.now()) { return Math.floor(timestamp / TOTP_STEP_MS); }

function base32ToBuffer(secret) {
  const normalized = normalizeBase32(secret);
  if (!validBase32(normalized)) return null;
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  let bits = '';
  for (const char of normalized) {
    const value = alphabet.indexOf(char);
    if (value < 0) return null;
    bits += value.toString(2).padStart(5, '0');
  }
  const bytes = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) bytes.push(parseInt(bits.slice(i, i + 8), 2));
  return Buffer.from(bytes);
}

function totpCode(secret, counter) {
  const key = base32ToBuffer(secret);
  if (!key) return null;
  const message = Buffer.alloc(8);
  message.writeBigUInt64BE(BigInt(counter));
  const digest = crypto.createHmac('sha1', key).update(message).digest();
  const offset = digest[digest.length - 1] & 0x0f;
  const binary = ((digest[offset] & 0x7f) << 24) |
    ((digest[offset + 1] & 0xff) << 16) |
    ((digest[offset + 2] & 0xff) << 8) |
    (digest[offset + 3] & 0xff);
  return String(binary % 1_000_000).padStart(TOTP_DIGITS, '0');
}

let lastTotpReplay = { code: null, acceptedAt: 0 };

function verifyTotp(code, now = Date.now()) {
  const secret = configuredTotpSecret();
  if (!secret) return true;
  if (!validBase32(secret)) return false;
  const normalizedCode = String(code || '').trim();
  if (!/^\d{6}$/.test(normalizedCode)) return false;
  if (lastTotpReplay.code === normalizedCode && now - lastTotpReplay.acceptedAt < TOTP_REPLAY_MS) return false;
  const current = totpCounterFor(now);
  for (const delta of [-1, 0, 1]) {
    const expected = totpCode(secret, current + delta);
    if (expected && sameSecret(normalizedCode, expected)) {
      lastTotpReplay = { code: normalizedCode, acceptedAt: now };
      return true;
    }
  }
  return false;
}

export function getClientIp(req) {
  const remote = String(req.socket?.remoteAddress || 'unknown').slice(0, 128);
  if (env.TRUST_PROXY === 'true' && (remote === '127.0.0.1' || remote === '::1' || remote === '::ffff:127.0.0.1')) {
    const forwarded = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (forwarded) return forwarded.slice(0,128);
  }
  return remote;
}

export function getAllowedOrigins() { return String(env.WEB_ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean); }
export function isOriginAllowed(origin, req = null) {
  if (!origin) return true;
  const allowed = getAllowedOrigins();
  if (allowed.length) return allowed.includes(origin);
  try { return new URL(origin).host === String(req?.headers?.host || ''); } catch { return false; }
}
export function authCorsHeaders(origin) {
  if (!origin) return {};
  if (!isOriginAllowed(origin)) return { 'Vary': 'Origin' };
  return {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Allow-Headers': 'Content-Type, Accept, X-CSRF-Token',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Vary': 'Origin'
  };
}
export function csrfCookie(token) { return `fantasminha_csrf=${encodeURIComponent(token)}; Path=/; SameSite=Lax${secureCookie() ? '; Secure' : ''}`; }
export function clearCsrfCookie() { return `fantasminha_csrf=; Path=/; SameSite=Lax; Max-Age=0${secureCookie() ? '; Secure' : ''}`; }
export function sessionCookie(token) {
  const attrs = [`${SESSION_COOKIE}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax', `Max-Age=${Math.floor(SESSION_TTL_MS / 1000)}`];
  if (secureCookie()) attrs.push('Secure');
  return attrs.join('; ');
}
export function clearSessionCookie() { return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${secureCookie() ? '; Secure' : ''}`; }

export function sessionFromRequest(req) {
  const token = parseCookie(req.headers.cookie || '')[SESSION_COOKIE];
  if (!token) return null;
  const key = tokenDigest(token);
  let session = sessions.get(key);
  if (!session) { session = persistedSessions().sessions?.[key] || null; if (session) sessions.set(key, session); }
  if (!session) return null;
  if (session.expiresAt <= Date.now()) { sessions.delete(key); void deletePersistedSession(key).catch(() => {}); return null; }
  return { ...session, sessionKey: key };
}

export function validateCsrf(req, session) {
  if (!session?.csrfToken) return false;
  const supplied = String(req?.headers?.['x-csrf-token'] || '').trim();
  return !!supplied && sameSecret(supplied, session.csrfToken);
}

export function setWhatsAppNotifier(notifier) {
  whatsappNotifier = typeof notifier === 'function' ? notifier : null;
}

function safeAudit(action, { ip = null, username = null, result = 'success', details = {} } = {}) {
  const safeIp = String(ip || '').slice(0, 128);
  const safeDetails = { ...details };
  delete safeDetails.password;
  delete safeDetails.passwordHash;
  delete safeDetails.hash;
  delete safeDetails.totp;
  delete safeDetails.totpSecret;
  return recordAudit({
    actor: username ? { type: 'web_owner_auth', username: String(username).slice(0, 160) } : null,
    action,
    scope: 'control-center',
    result,
    details: { ...safeDetails, ip: safeIp }
  }).catch(error => console.warn(`[WEB-AUTH] audit falhou: ${error?.message || error}`));
}

function notifyOwner(text) {
  if (!notifyEnabled() || typeof whatsappNotifier !== 'function') return;
  try {
    Promise.resolve(whatsappNotifier(String(text))).catch(error => {
      console.warn(`[WEB-AUTH] notificação WhatsApp falhou: ${error?.message || error}`);
    });
  } catch (error) {
    console.warn(`[WEB-AUTH] notificação WhatsApp falhou: ${error?.message || error}`);
  }
}

function notificationText(type, { ip, at = Date.now(), retryAfter = null } = {}) {
  const when = new Date(at).toLocaleString('pt-BR', { timeZone: env.TZ || undefined });
  if (type === 'success') {
    return `╭━━━╮\n│ 👻 *CONTROL CENTER*\n│\n│ ✅ *Login realizado*\n│ 🕒 ${when}\n│ 🌐 IP: ${ip}\n╰━━━╯`;
  }
  if (type === 'rate') {
    return `╭━━━╮\n│ 👻 *CONTROL CENTER*\n│\n│ ⚠️ *Possível força bruta*\n│ 🚫 Rate limit acionado\n│ 🕒 ${when}\n│ 🌐 IP: ${ip}\n│ ⏱️ Retry: ${retryAfter ?? '?'}s\n╰━━━╯`;
  }
  return `╭━━━╮\n│ 👻 *CONTROL CENTER*\n│\n│ ⚠️ *Falhas consecutivas de login*\n│ 🔢 Tentativas: ${NOTIFY_FAILURE_THRESHOLD}+\n│ 🕒 ${when}\n│ 🌐 IP: ${ip}\n╰━━━╯`;
}

export async function authenticate(username, password, ip, totp = '') {
  const configuredUser = configuredUsername();
  const encoded = configuredPasswordHash();
  if (!configuredUser || !encoded) throw notConfiguredError();
  if (String(username || '').length > 160 || String(password || '').length > 1024) throw Object.assign(new Error('invalid request'), { statusCode: 400 });

  const retryAfter = rateRetryAfter(ip, username);
  if (retryAfter) {
    void safeAudit('AUTH_RATE_LIMITED', { ip, username, result: 'denied', details: { retryAfter } });
    notifyOwner(notificationText('rate', { ip, retryAfter }));
    return { ok: false, rateLimited: true, retryAfter };
  }

  const userOk = sameSecret(String(username || '').trim(), configuredUser);
  let passOk = false;
  try { passOk = await verifyPassword(password, encoded); } catch { passOk = false; }

  const totpOk = !totpEnabled()
    ? true
    : verifyTotp(totp);

  if (!userOk || !passOk || !totpOk) {
    recordFailure(ip, username);
    const count = failureCount(ip, username);
    void safeAudit('AUTH_LOGIN_FAILED', { ip, username, result: 'denied', details: { attemptCount: count } });
    if (count === NOTIFY_FAILURE_THRESHOLD) notifyOwner(notificationText('failure', { ip }));
    throw genericCredentialError();
  }

  clearRate(ip, username);
  const token = crypto.randomBytes(32).toString('base64url');
  const csrfToken = crypto.randomBytes(32).toString('base64url');
  const now = Date.now();
  const user = { role: 'owner', name: env.WEB_AUTH_DISPLAY_NAME || 'Proprietário' };
  const session = { user, csrfToken, createdAt: now, expiresAt: now + SESSION_TTL_MS };
  const sessionKey = tokenDigest(token);
  sessions.set(sessionKey, session);
  await persistSession(sessionKey, session);

  void safeAudit('AUTH_LOGIN_SUCCESS', { ip, username });
  notifyOwner(notificationText('success', { ip, at: now }));

  return { ok: true, token, csrfToken, user, expiresAt: now + SESSION_TTL_MS };
}

export function logout(req) {
  const session = sessionFromRequest(req);
  if (session) {
    sessions.delete(session.sessionKey);
    void deletePersistedSession(session.sessionKey).catch(() => {});
    void safeAudit('AUTH_LOGOUT', { ip: getClientIp(req), details: { sessionRevoked: true } });
  } else {
    void safeAudit('AUTH_LOGOUT', { ip: getClientIp(req), result: 'noop', details: { sessionRevoked: false } });
  }
  return !!session;
}

export function revokeAllSessions(currentSession = null, keepCurrent = false, ip = null) {
  const before = sessions.size;
  let revoked = 0;
  if (keepCurrent && currentSession?.sessionKey && sessions.has(currentSession.sessionKey)) {
    for (const key of sessions.keys()) {
      if (key === currentSession.sessionKey) continue;
      sessions.delete(key);
      void deletePersistedSession(key).catch(() => {});
      revoked++;
    }
  } else {
    revoked = sessions.size;
    for (const key of sessions.keys()) void deletePersistedSession(key).catch(() => {});
    sessions.clear();
  }
  void safeAudit('AUTH_SESSIONS_REVOKED', { ip, details: { revoked, keepCurrent } });
  return revoked;
}

export function authStatus(req) {
  const session = sessionFromRequest(req);
  if (!session) return null;
  return { user: session.user, expiresAt: session.expiresAt, csrfToken: session.csrfToken };
}

export function authConfigSummary() {
  return {
    configured: !!configuredUsername() && !!configuredPasswordHash(),
    sessionTtlMs: SESSION_TTL_MS,
    rateWindowMs: RATE_WINDOW_MS,
    rateMax: RATE_MAX,
    rateMaxIp: RATE_MAX_IP,
    rateMaxUser: RATE_MAX_USER,
    ratePersistence: RATE_PERSIST && rateDbReady,
    cookieSecure: secureCookie(),
    cookieHttpOnly: true,
    cookieSameSite: 'Lax',
    totpEnabled: totpEnabled(),
    notifyOwner: notifyEnabled()
  };
}

export function __testGenerateTotp(secret, timestamp = Date.now()) {
  return totpCode(secret, totpCounterFor(timestamp));
}

export function __testRateRetryAfter(ip, username, now = Date.now()) {
  let retryAfter = 0;
  for (const [kind, value] of [['ip', ip], ['user', username]]) {
    const timestamps = getAttemptTimestamps(kind, value, now);
    const max = rateLimitForKey(rateKey(kind, value));
    if (timestamps.length >= max) {
      const oldest = timestamps[0] || now;
      retryAfter = Math.max(retryAfter, Math.max(1, Math.ceil((oldest + RATE_WINDOW_MS - now) / 1000)));
    }
  }
  return retryAfter;
}

export function __testRecordFailure(ip, username, now = Date.now()) {
  for (const [kind, value] of [['ip', ip], ['user', username]]) {
    const key = rateKey(kind, value);
    const cutoff = now - RATE_WINDOW_MS;
    const timestamps = memoryRows(key, cutoff);
    timestamps.push(now);
    attempts.set(key, { timestamps });
    persistFailure(kind, value, now);
  }
}

export function __testClearRate(ip, username) {
  clearRate(ip, username);
}

export function __testResetAuthState() {
  sessions.clear();
  attempts.clear();
  lastTotpReplay = { code: null, acceptedAt: 0 };
}

export function __testCloseRateDb() {
  try { rateDb?.close?.(); } catch {}
  rateDb = null; rateDbReady = false; rateDbInitAttempted = true;
}
