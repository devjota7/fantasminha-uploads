import { platformAnalytics } from '../analytics.js';
import { registryStats } from '../../core/registry.js';
import { resourceStats } from '../../core/resourceManager.js';
import { queues } from '../../core/queue.js';
import { listRuntime } from '../../core/runtimeConfig.js';
import { auditFind } from '../audit/index.js';
import { listClients, clientStats } from './clients.js';
import { keyStats, listApiKeys } from '../../services/api/apiKeys.js';
import config from '../../core/config.js';
import commercial from '../../services/platformCommercial.js';
import { ownerDashboardSnapshot, ownerActivitySnapshot, ownerAlertsSnapshot } from './ownerDashboard.js';
import { paymentSnapshot } from '../../services/payments/index.js';
import licenseService from '../../services/licenseService.js';
import { getProvisioning } from '../../services/provisioning/index.js';

export function dashboardSnapshot() {
  const activity=auditFind(e=>String(e.action||'').match(/^(AUTH_|CLIENT_|API_KEY_)/)).slice(-50).reverse().map(e=>({id:e.id,at:e.at,actor:e.actor,target:e.target,action:e.action,result:e.result,details:e.details}));
  const alerts=auditFind(e=>['AUTH_RATE_LIMITED','API_RATE_LIMITED','API_SCOPE_DENIED'].includes(e.action)).slice(-50).reverse().map(e=>({id:e.id,at:e.at,action:e.action,target:e.target,result:e.result,details:e.details}));
  const legacy=ownerDashboardSnapshot();
  return {
    ok:true,
    generatedAt:new Date().toISOString(),
    groups:legacy.groups,
    system:{...legacy.system,botName:config.botName,version:config.botVersion,environment:config.env,controlCenter:true},
    analytics:platformAnalytics(),
    clients:{...clientStats(),items:listClients()},
    keys:{...keyStats(),items:listApiKeys()},
    commercial:{...commercial.commercialSnapshot(), licenseIntegrity:licenseService.commercialLifecycleIntegrity(), licenseStates:Object.fromEntries(['ACTIVE','EXPIRED','SUSPENDED','CANCELLED','REVOKED'].map(state=>[state,licenseService.list().filter(x=>x.state===state).length]))},
    payments:paymentSnapshot(),
    activity,
    alerts,
    resources:resourceStats(),
    registry:registryStats(),
    queues:Object.fromEntries(Object.entries(queues).map(([k,v])=>[k,v.getStatus()])),
    runtime:listRuntime()
  };
}

export function ownerActivitySnapshotForControlCenter(limit=50) {
  const legacy=ownerActivitySnapshot(limit);
  return {
    ok:true,
    available:legacy.available,
    events:legacy.events,
    items:legacy.events.map(e=>({id:e.id,at:e.timestamp,action:e.description,result:e.result})),
    ...(legacy.reason ? {reason:legacy.reason} : {})
  };
}

export function ownerAlertsSnapshotForControlCenter() {
  const legacy=ownerAlertsSnapshot();
  return {
    ok:true,
    available:legacy.available,
    count:legacy.count,
    alerts:legacy.alerts,
    items:legacy.alerts.map(e=>({id:e.id,at:e.createdAt,action:e.title,target:e.source,result:'open',severity:e.severity,occurrences:e.occurrences})),
    ...(legacy.reason ? {reason:legacy.reason} : {})
  };
}
export default {dashboardSnapshot};
