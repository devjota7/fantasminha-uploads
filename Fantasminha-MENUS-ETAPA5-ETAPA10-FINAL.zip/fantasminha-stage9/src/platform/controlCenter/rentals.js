import commercial from '../../services/platformCommercial.js';
import licenseService from '../../services/licenseService.js';

function cleanId(value) { return String(value ?? '').trim(); }
function rentalPublic(rental) {
  if (!rental) return null;
  const client = rental.clientId ? commercial.getClient(rental.clientId) : null;
  return {
    id: rental.rentalId,
    licenseId: rental.rentalId,
    groupId: rental.groupId,
    clientId: rental.clientId ?? null,
    clientName: client?.name ?? null,
    plan: rental.plan ?? null,
    state: rental.state,
    active: rental.active === true,
    permanent: rental.permanent === true,
    createdAt: rental.createdAt ?? null,
    updatedAt: rental.updatedAt ?? null,
    expiresAt: rental.expiresAt ?? null,
    premium: rental.premium === true,
  };
}

export function createRental(input, actor = 'owner', actorRole = null) { return rentalPublic(commercial.createRental({ ...input, actor, actorRole })); }

export function listRentals() {
  return commercial.listRentals().map(rentalPublic).sort((a, b) => String(a.id).localeCompare(String(b.id)));
}

export function getRental(id) {
  const key = cleanId(id);
  if (!key || key.length > 160) return null;
  const rental = commercial.listRentals().find(r => r.rentalId === key);
  return rentalPublic(rental || null);
}

function resolveGroup(id) {
  const key = cleanId(id);
  if (!key) throw Object.assign(new Error('rental not found'), { statusCode: 404 });
  const rental = commercial.listRentals().find(r => r.rentalId === key || r.groupId === key);
  if (!rental) throw Object.assign(new Error('rental not found'), { statusCode: 404 });
  return rental.groupId;
}

export function getLicense(id) {
  const key = cleanId(id);
  if (!key) return null;
  const rental = commercial.listRentals().find(r => r.rentalId === key || r.groupId === key);
  return rental ? licenseService.status(rental.groupId) : null;
}

export function licenseHistory(id) {
  const group = resolveGroup(id);
  return licenseService.history(group);
}

export function renewRental(id, days, actor = 'owner', actorRole = null) {
  return commercial.renewRental(resolveGroup(id), days, actor, null, actorRole);
}

export function setRentalState(id, state, actor = 'owner') {
  return commercial.setRentalState(resolveGroup(id), String(state || '').trim().toUpperCase(), actor);
}

export function expireDueRentals(actor = 'owner') { return licenseService.evaluateLicenseState(actor).expiredGroups; }
export function activateLicense(id, actor = 'owner') { return licenseService.activateLicense(resolveGroup(id), actor); }
export function renewLicense(id, days, actor = 'owner', operationId = null) { return licenseService.renewLicense(resolveGroup(id), days, actor, operationId); }
export function suspendLicense(id, actor = 'owner') { return licenseService.suspendLicense(resolveGroup(id), actor); }
export function resumeLicense(id, actor = 'owner') { return licenseService.resumeLicense(resolveGroup(id), actor); }
export function expireLicense(id, actor = 'owner') { return licenseService.expireLicense(resolveGroup(id), actor); }
export function cancelLicense(id, actor = 'owner') { return licenseService.cancelLicense(resolveGroup(id), actor); }
export function commercialLifecycleIntegrity() { return licenseService.commercialLifecycleIntegrity(); }

export function listPlans() { return commercial.listPlans(); }

export default { createRental, listRentals, getRental, getLicense, licenseHistory, renewRental, setRentalState, expireDueRentals, activateLicense, renewLicense, suspendLicense, resumeLicense, expireLicense, cancelLicense, commercialLifecycleIntegrity, listPlans };
