import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readCollection } from '../../database/store.js';
import { listIncidents } from '../incidents/index.js';
import commercial from '../../services/platformCommercial.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const GROUPS_DIR = path.join(ROOT, 'dados', 'database', 'grupos');

function unavailable(reason) {
  return { available: false, value: null, reason };
}

function registeredGroups() {
  try {
    if (!fs.existsSync(GROUPS_DIR)) return { available: true, value: 0 };
    const files = fs.readdirSync(GROUPS_DIR, { withFileTypes: true });
    const value = files.filter(entry => entry.isFile() && entry.name.endsWith('@g.us.json')).length;
    return { available: true, value };
  } catch (error) {
    return unavailable(`Não foi possível ler o registro de grupos: ${error.message}`);
  }
}

export function ownerDashboardSnapshot() {
  const registered = registeredGroups();
  const commercialData = commercial.commercialSnapshot();
  return {
    groups: {
      active: unavailable('O registro atual não mantém estado confiável de atividade por grupo.'),
      inactive: unavailable('O registro atual não mantém estado confiável de atividade por grupo.'),
      registered
    },
    commercial: { available: true, ...commercialData },
    system: {
      available: true,
      status: 'online',
      uptimeMs: Math.round(process.uptime() * 1000),
      connection: unavailable('O estado da conexão do WhatsApp não é exposto pelo módulo de Control Center nesta base.')
    }
  };
}

function auditDescription(event) {
  const action = String(event?.action || 'EVENT');
  const result = String(event?.result || 'success');
  return `${action}${result !== 'success' ? ` — ${result}` : ''}`;
}

export function ownerActivitySnapshot(limit = 12) {
  const events = readCollection('platform_audit', { events: [] }).events;
  if (!Array.isArray(events)) return { available: false, events: [], reason: 'A fonte de auditoria está em formato inválido.' };
  return {
    available: true,
    events: events.slice(-Math.max(1, Math.min(50, Number(limit) || 12))).reverse().map(event => ({
      id: event.id || null,
      timestamp: Number(event.at) || null,
      description: auditDescription(event),
      result: event.result || 'success'
    }))
  };
}

export function ownerAlertsSnapshot() {
  try {
    const incidents = listIncidents('open');
    return {
      available: true,
      count: incidents.length,
      alerts: incidents.slice(0, 20).map(item => ({
        id: item.id,
        title: item.title,
        severity: item.severity,
        source: item.source,
        createdAt: item.createdAt,
        occurrences: item.occurrences || 1
      }))
    };
  } catch (error) {
    return { available: false, count: null, alerts: [], reason: `Não foi possível ler os incidentes: ${error.message}` };
  }
}
