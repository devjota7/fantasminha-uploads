/** Control Center HTTP sem dependência externa. API local opcional + dashboard JSON/HTML. */
import http from 'node:http';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { platformAnalytics } from '../analytics.js';
import config from '../../core/config.js';
import { registryStats, listCommands } from '../../core/registry.js';
import { resourceStats } from '../../core/resourceManager.js';
import { queues } from '../../core/queue.js';
import { listRuntime } from '../../core/runtimeConfig.js';
import { listKnowledge } from '../../services/knowledge/index.js';
import logger from '../../core/logger.js';
import { authenticate, logout, authStatus, sessionCookie, clearSessionCookie, csrfCookie, clearCsrfCookie, getClientIp, authCorsHeaders, isOriginAllowed, authConfigSummary, validateCsrf, revokeAllSessions, sessionFromRequest } from './auth.js';
import { dashboardSnapshot, ownerActivitySnapshotForControlCenter, ownerAlertsSnapshotForControlCenter } from './dashboard.js';
import { listClients, getClient, createClient, updateClient, deleteClient } from './clients.js';
import { createApiKey, listApiKeys, getApiKey, revokeApiKey, rotateApiKey, authenticateApiKey } from './keys.js';
import { createRental, listRentals, getRental, getLicense, licenseHistory, renewRental, setRentalState, expireDueRentals, activateLicense, renewLicense, suspendLicense, resumeLicense, expireLicense, cancelLicense, commercialLifecycleIntegrity, listPlans } from './rentals.js';
import { auditFind, recordAudit, sanitizeAuditValue } from '../audit/index.js';
import { handleApiV1 } from '../apiV1.js';
import { getProvisioning, provision, start as startProvisioning, stop as stopProvisioning, restart as restartProvisioning, destroy as destroyProvisioning, health as provisioningHealth, listOperations as listProvisioningOperations } from '../../services/provisioning/index.js';
import ops from '../ops.js';
import { paymentConfig, paymentSnapshot, listPayments, getPayment, createCheckout, refreshPayment, handleWebhook } from '../../services/payments/index.js';
import { env } from '../../config/env.js';

let server = null;
let serverReadyPromise = null;
const CONTROL_WEB_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../web/control-center');
const WEB_ASSETS = new Map([
  ['/','index.html'],
  ['/index.html','index.html'],
  ['/control-center/app.css','app.css'],
  ['/control-center/app.js','app.js']
]);
const WEB_CONTENT_TYPES = { 'index.html':'text/html; charset=utf-8', 'app.css':'text/css; charset=utf-8', 'app.js':'text/javascript; charset=utf-8' };
function setSecurityHeaders(res) {
  if (env.NODE_ENV === 'production' && env.FORCE_HTTPS === 'true') res.setHeader('Strict-Transport-Security','max-age=31536000; includeSubDomains');
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  res.setHeader('Cache-Control','no-store');
}
function serveWeb(pathname, res) {
  const filename = WEB_ASSETS.get(pathname);
  if (!filename) return false;
  try {
    const body = readFileSync(path.join(CONTROL_WEB_DIR, filename));
    res.statusCode = 200;
    res.setHeader('Content-Type', WEB_CONTENT_TYPES[filename] || 'application/octet-stream');
    res.end(body);
  } catch (error) {
    logger.error('control-center-web', `falha ao servir ${filename}: ${error?.message || error}`);
    res.statusCode = 500; res.end('Control Center web indisponível');
  }
  return true;
}

export function controlSnapshot(){ return { analytics: platformAnalytics(), registry: registryStats(), queues:Object.fromEntries(Object.entries(queues).map(([k,v])=>[k,v.getStatus()])), resources:resourceStats(), runtime:listRuntime(), knowledge:listKnowledge(), commands:listCommands({includeHidden:true}).map(c=>({name:c.name,category:c.category,plugin:c.plugin,hidden:c.hidden})) }; }
export function controlAuthStatus() { return authConfigSummary(); }

function bearerToken(req) {
  const value = String(req.headers.authorization || '');
  const match = value.match(/^Bearer\s+(.+)$/i);
  return match ? match[1].trim() : '';
}
function requireRole(req, res, cors, role = 'owner') {
  const session = sessionFromRequest(req);
  if (!session) { json(res, 401, { error: 'unauthenticated' }, cors); return null; }
  if (session.user?.role !== role) { json(res, 403, { error: 'forbidden' }, cors); return null; }
  return session;
}
function requireOwner(req, res, cors) {
  return requireRole(req, res, cors, 'owner');
}
function requireApi(req, res, cors) {
  const credential = bearerToken(req);
  const context = authenticateApiKey(credential);
  if (!context) { json(res, 401, { error: 'invalid_api_key' }, cors); return null; }
  return context;
}
function clampNumber(value, min, max, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
const API_RATE_WINDOW_MS = clampNumber(env.API_RATE_WINDOW_MS || 60_000, 60_000, 60 * 60_000, 60_000);
const API_RATE_MAX = clampNumber(env.API_RATE_MAX || 60, 10, 1000, 60);
const API_RATE_MAX_IP = clampNumber(env.API_RATE_MAX_IP || API_RATE_MAX, 10, 5000, API_RATE_MAX);
const API_RATE_MAX_KEY = clampNumber(env.API_RATE_MAX_KEY || API_RATE_MAX, 10, 5000, API_RATE_MAX);
const apiRate = new Map();
function apiRateKey(req, context) { return context?.keyId ? `key:${context.keyId}` : `ip:${getClientIp(req)}`; }
function apiRateCheck(req, context) {
  const key = apiRateKey(req, context); const now = Date.now(); const state = apiRate.get(key);
  const limit = context?.keyId ? API_RATE_MAX_KEY : API_RATE_MAX_IP;
  if (!state || now - state.startedAt >= API_RATE_WINDOW_MS) { apiRate.set(key, { startedAt: now, count: 1 }); return { allowed: true }; }
  state.count += 1;
  if (state.count <= limit) return { allowed: true };
  return { allowed: false, retryAfter: Math.max(1, Math.ceil((API_RATE_WINDOW_MS - (now - state.startedAt)) / 1000)) };
}
function pruneApiRate() { const cutoff = Date.now() - API_RATE_WINDOW_MS; for (const [key, state] of apiRate) if (state.startedAt < cutoff) apiRate.delete(key); }
function auditApi(action, req, context, result='success', details={}) {
  void recordAudit({ actor: context?.clientId || null, target: context?.keyId || null, action, scope: 'api', result, details: sanitizeAuditValue({ method:req.method, path:(req.url||'').split('?')[0], ip:getClientIp(req), ...details }) }).catch(()=>{});
}

async function readJsonBody(req, maxBytes = 8192) {
  let size = 0; const chunks = [];
  for await (const chunk of req) { size += chunk.length; if (size > maxBytes) throw Object.assign(new Error('payload too large'), { statusCode: 413 }); chunks.push(chunk); }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); } catch { throw Object.assign(new Error('invalid json'), { statusCode: 400 }); }
}
async function readRawBody(req, maxBytes = 256 * 1024) { let size = 0; const chunks = []; for await (const chunk of req) { size += chunk.length; if (size > maxBytes) throw Object.assign(new Error('payload too large'), { statusCode: 413 }); chunks.push(chunk); } return Buffer.concat(chunks); }
function json(res, statusCode, body, headers = {}) { res.statusCode = statusCode; for (const [k,v] of Object.entries(headers)) res.setHeader(k,v); if (statusCode === 204) return res.end(); res.setHeader('Content-Type', 'application/json; charset=utf-8'); return res.end(JSON.stringify(body)); }
const PUBLIC_RATE_WINDOW_MS = clampNumber(env.WEB_PUBLIC_RATE_WINDOW_MS || 60_000, 10_000, 60 * 60_000, 60_000);
const PUBLIC_RATE_MAX = clampNumber(env.WEB_PUBLIC_RATE_MAX || 120, 20, 5000, 120);
const publicRate = new Map();
function publicRateCheck(req) {
  const key = `ip:${getClientIp(req)}`; const now = Date.now(); const state = publicRate.get(key);
  if (!state || now - state.startedAt >= PUBLIC_RATE_WINDOW_MS) { publicRate.set(key,{startedAt:now,count:1}); return {allowed:true}; }
  state.count += 1; if (state.count <= PUBLIC_RATE_MAX) return {allowed:true};
  return {allowed:false,retryAfter:Math.max(1,Math.ceil((PUBLIC_RATE_WINDOW_MS-(now-state.startedAt))/1000))};
}
function prunePublicRate() { const cutoff=Date.now()-PUBLIC_RATE_WINDOW_MS; for(const [k,v] of publicRate) if(v.startedAt<cutoff) publicRate.delete(k); }
function originRejected(req, res) {
  const origin = req.headers.origin;
  if (!origin || isOriginAllowed(origin, req)) return false;
  json(res, 403, { error: 'origin_not_allowed' }, authCorsHeaders(origin));
  return true;
}

export function startControlCenter({ host=env.DASHBOARD_HOST || '127.0.0.1', port=Number(env.DASHBOARD_PORT || 8787) } = {}) {
  if (server) return server.address() || { host, port };
  server=http.createServer(async (req,res)=>{
    const path=(req.url||'/').split('?')[0];
    setSecurityHeaders(res);
    const origin=req.headers.origin;
    const cors=authCorsHeaders(origin);
    for(const [k,v] of Object.entries(cors)) res.setHeader(k,v);
    if (path === '/api/webhooks/mercadopago' && req.method === 'POST') {
      prunePublicRate();
      const limit = publicRateCheck(req);
      if (!limit.allowed) { res.setHeader('Retry-After',String(limit.retryAfter)); return json(res,429,{error:'too_many_requests'},{}); }
      try {
        const raw = await readRawBody(req);
        let body = {};
        try { body = raw.length ? JSON.parse(raw.toString('utf8')) : {}; } catch { return json(res,400,{error:'invalid_json'},{}); }
        const url = new URL(req.url || '/', 'http://localhost');
        const result = await handleWebhook({ body, query: Object.fromEntries(url.searchParams.entries()), headers: req.headers });
        return json(res,200,{ok:true,...result},{});
      } catch (error) {
        const status=Number(error.statusCode)||500;
        if ([400,401,404,409,413,503].includes(status)) return json(res,status,{error:error.code||'webhook_error'},{});
        logger.error('mercadopago-webhook', error.message);
        return json(res,500,{error:'internal_error'},{});
      }
    }

    if (path.startsWith('/api/auth/')) {
      if (originRejected(req,res)) return;
      if (req.method === 'OPTIONS') return json(res,204,{},cors);
      try {
        if (path === '/api/auth/login' && req.method === 'POST') {
          const body=await readJsonBody(req);
          const username=String(body.username ?? '').trim();
          const password=String(body.password ?? '');
          if (!username || !password) return json(res,400,{error:'invalid_request'},cors);
          const totp=String(body.totp ?? '');
          const result=await authenticate(username,password,getClientIp(req),totp);
          if (result.rateLimited) { res.setHeader('Retry-After',String(result.retryAfter)); return json(res,429,{error:'too_many_attempts'},cors); }
          res.setHeader('Set-Cookie',[sessionCookie(result.token), csrfCookie(result.csrfToken)]);
          return json(res,200,{isAuthenticated:true,user:result.user,expiresAt:result.expiresAt,csrfToken:result.csrfToken},cors);
        }
        if (path === '/api/auth/session' && req.method === 'GET') {
          const status=authStatus(req);
          if (!status) return json(res,401,{error:'unauthenticated'},cors);
          return json(res,200,{isAuthenticated:true,user:status.user,expiresAt:status.expiresAt,csrfToken:status.csrfToken},cors);
        }
        if (path === '/api/auth/logout' && req.method === 'POST') {
          const currentSession = sessionFromRequest(req);
          if (currentSession && !validateCsrf(req, currentSession)) return json(res,403,{error:'csrf_mismatch'},cors);
          logout(req);
          res.setHeader('Set-Cookie',[clearSessionCookie(), clearCsrfCookie()]);
          return json(res,204,null,cors);
        }
        if (path === '/api/auth/revoke-all' && req.method === 'POST') {
          const currentSession=sessionFromRequest(req);
          if (!currentSession) return json(res,401,{error:'unauthenticated'},cors);
          if (!validateCsrf(req,currentSession)) return json(res,403,{error:'csrf_mismatch'},cors);
          const body=await readJsonBody(req);
          const keepCurrent=body.keepCurrent === true;
          const revoked=revokeAllSessions(currentSession,keepCurrent,getClientIp(req));
          if (!keepCurrent) res.setHeader('Set-Cookie',clearSessionCookie());
          return json(res,200,{revoked},cors);
        }
      } catch (error) {
        const status=Number(error.statusCode)||500;
        if (status === 401) return json(res,401,{error:'invalid_credentials'},cors);
        if (status === 503) return json(res,503,{error:'auth_not_configured'},cors);
        if (status === 400 || status === 413) return json(res,status,{error:'invalid_request'},cors);
        logger.error('control-center-auth', error.message);
        return json(res,500,{error:'internal_error'},cors);
      }
      return json(res,405,{error:'method_not_allowed'},cors);
    }

    // Owner Control Center API — every mutation is session + CSRF protected.
    if (path.startsWith('/api/owner/')) {
      if (originRejected(req,res)) return;
      if (req.method === 'OPTIONS') return json(res,204,{},cors);
      const session = requireOwner(req,res,cors);
      if (!session) return;
      try {
        if (path === '/api/owner/dashboard' && req.method === 'GET') return json(res,200,dashboardSnapshot(),cors);
        if (path === '/api/owner/ops/diagnostics' && req.method === 'GET') return json(res,200,{ok:true,item:ops.diagnostics()},cors);
        if (path === '/api/owner/ops/operations' && req.method === 'GET') { const u=new URL(req.url,'http://localhost'); return json(res,200,{ok:true,items:ops.listOperations({limit:u.searchParams.get('limit'),status:u.searchParams.get('status'),operation:u.searchParams.get('operation'),entityId:u.searchParams.get('entityId')})},cors); }
        if (path === '/api/owner/ops/reconcile' && req.method === 'POST') { if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors); const body=await readJsonBody(req); if (!['all','commercial','provisioning'].includes(body.scope||'all')) return json(res,400,{error:'invalid_scope'},cors); return json(res,200,{ok:true,item:await ops.reconcile({scope:body.scope||'all',dryRun:body.dryRun===true,actor:session.user?.name||'owner'})},cors); }
        if (path === '/api/owner/activity' && req.method === 'GET') return json(res,200,ownerActivitySnapshotForControlCenter(),cors);
        if (path === '/api/owner/alerts' && req.method === 'GET') return json(res,200,ownerAlertsSnapshotForControlCenter(),cors);
        if (path === '/api/owner/clients' && req.method === 'GET') return json(res,200,{ok:true,items:listClients()},cors);
        if (path === '/api/owner/clients' && req.method === 'POST') {
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          const body=await readJsonBody(req); const item=await createClient({name:body.name,actor:session.user?.name||'owner'}); return json(res,201,{ok:true,item},cors);
        }
        const cm=path.match(/^\/api\/owner\/clients\/([^/]+)$/);
        if (cm) { const id=decodeURIComponent(cm[1]);
          if (req.method==='GET') { const item=getClient(id); return item?json(res,200,{ok:true,item},cors):json(res,404,{error:'not_found'},cors); }
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          if (req.method==='PATCH' || req.method==='PUT') return json(res,200,{ok:true,item:await updateClient(id,await readJsonBody(req),{actor:session.user?.name||'owner'})},cors);
          if (req.method==='DELETE') return json(res,200,{ok:true,...await deleteClient(id,{actor:session.user?.name||'owner'})},cors);
        }
        if (path === '/api/owner/rentals' && req.method === 'GET') return json(res,200,{ok:true,items:listRentals()},cors);
        if (path === '/api/owner/rentals' && req.method === 'POST') { if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors); const body=await readJsonBody(req); const item=createRental({groupId:body.groupId,clientId:body.clientId,planId:body.planId},session.user?.name||'owner',session.user?.role||'owner'); return json(res,201,{ok:true,item},cors); }
        if (path === '/api/owner/plans' && req.method === 'GET') return json(res,200,{ok:true,items:listPlans()},cors);
        if (path === '/api/owner/commercial/integrity' && req.method === 'GET') return json(res,200,{ok:true,item:commercialLifecycleIntegrity()},cors);
        if (path === '/api/owner/rentals/expire-due' && req.method === 'POST') {
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          const groups=expireDueRentals(session.user?.name||'owner'); return json(res,200,{ok:true,groups},cors);
        }
        const pm=path.match(/^\/api\/owner\/rentals\/([^/]+)\/(instance|provision|start|stop|restart|destroy|health|operations)$/);
        if (pm) {
          const id=decodeURIComponent(pm[1]); const action=pm[2];
          if (req.method==='GET' && action==='instance') return json(res,200,{ok:true,item:getProvisioning(id)},cors);
          if (req.method==='GET' && action==='health') return json(res,200,{ok:true,item:await provisioningHealth(id)},cors);
          if (req.method==='GET' && action==='operations') return json(res,200,{ok:true,items:listProvisioningOperations(id)},cors);
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          if (req.method==='POST') {
            const actor=session.user?.name||'owner';
            if(action==='provision') await provision(id,actor,req.headers['x-request-id']||null);
            if(action==='start') await startProvisioning(id,actor,req.headers['x-request-id']||null);
            if(action==='stop') await stopProvisioning(id,actor,req.headers['x-request-id']||null);
            if(action==='restart') await restartProvisioning(id,actor,req.headers['x-request-id']||null);
            if(action==='destroy') await destroyProvisioning(id,actor,req.headers['x-request-id']||null);
          }
        }
        const rm=path.match(/^\/api\/owner\/rentals\/([^/]+)(?:\/(renew|state|license|history|license\/(activate|renew|suspend|resume|expire|cancel)))?$/);
        if (rm) {
          const id=decodeURIComponent(rm[1]);
          if (req.method==='GET' && !rm[2]) { const item=getRental(id); return item?json(res,200,{ok:true,item},cors):json(res,404,{error:'not_found'},cors); }
          if (req.method==='GET' && rm[2]==='license') { const item=getLicense(id); return item?json(res,200,{ok:true,item},cors):json(res,404,{error:'not_found'},cors); }
          if (req.method==='GET' && rm[2]==='history') { const item=getRental(id); return item?json(res,200,{ok:true,items:licenseHistory(id)},cors):json(res,404,{error:'not_found'},cors); }
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          if (req.method==='POST' && rm[2]?.startsWith('license/')) {
            const action=rm[3]; const actor=session.user?.name||'owner';
            if (action==='activate') return json(res,200,{ok:true,item:activateLicense(id,actor)},cors);
            if (action==='renew') { const body=await readJsonBody(req); return json(res,200,{ok:true,item:renewLicense(id,body.days,actor,req.headers['x-request-id']||null)},cors); }
            if (action==='suspend') return json(res,200,{ok:true,item:suspendLicense(id,actor)},cors);
            if (action==='resume') return json(res,200,{ok:true,item:resumeLicense(id,actor)},cors);
            if (action==='expire') return json(res,200,{ok:true,item:expireLicense(id,actor)},cors);
            if (action==='cancel') { const body=await readJsonBody(req); if (body.confirm !== true) return json(res,400,{error:'confirmation_required'},cors); return json(res,200,{ok:true,item:cancelLicense(id,actor)},cors); }
          }
          if (req.method==='POST' && rm[2]==='renew') { const body=await readJsonBody(req); const item=renewRental(id,body.days,session.user?.name||'owner',session.user?.role||'owner'); return json(res,200,{ok:true,item},cors); }
          if (req.method==='POST' && rm[2]==='state') { const body=await readJsonBody(req); const item=setRentalState(id,body.state,session.user?.name||'owner'); return json(res,200,{ok:true,item},cors); }
        }
        if (path === '/api/owner/payments' && req.method === 'GET') return json(res,200,{ok:true,items:listPayments()},cors);
        if (path === '/api/owner/payments/config' && req.method === 'GET') return json(res,200,{ok:true,item:paymentConfig()},cors);
        if (path === '/api/owner/payments/checkout' && req.method === 'POST') {
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          const body=await readJsonBody(req);
          const item=await createCheckout({rentalId:body.rentalId,planId:body.planId,actor:session.user?.name||'owner',operationId:req.headers['x-request-id']||null});
          return json(res,201,{ok:true,...item},cors);
        }
        const payMatch=path.match(/^\/api\/owner\/payments\/([^/]+)(?:\/refresh)?$/);
        if (payMatch) {
          const paymentId=decodeURIComponent(payMatch[1]);
          if (req.method==='GET') { const item=getPayment(paymentId); return item?json(res,200,{ok:true,item},cors):json(res,404,{error:'not_found'},cors); }
          if (path.endsWith('/refresh') && req.method==='POST') {
            if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
            const item=await refreshPayment(paymentId,session.user?.name||'owner');
            return json(res,200,{ok:true,item},cors);
          }
        }

        if (path === '/api/owner/keys' && req.method === 'GET') return json(res,200,{ok:true,items:listApiKeys()},cors);
        if (path === '/api/owner/keys' && req.method === 'POST') {
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          const body=await readJsonBody(req); const item=await createApiKey({clientId:body.clientId,expiresAt:body.expiresAt,actor:session.user?.name||'owner'}); return json(res,201,{ok:true,item},cors);
        }
        const km=path.match(/^\/api\/owner\/keys\/([^/]+)(?:\/(revoke|rotate))?$/);
        if (km) { const id=decodeURIComponent(km[1]); if (req.method==='GET' && !km[2]) { const item=getApiKey(id); return item?json(res,200,{ok:true,item},cors):json(res,404,{error:'not_found'},cors); }
          if (!validateCsrf(req,session)) return json(res,403,{error:'csrf_mismatch'},cors);
          if (req.method==='POST' && km[2]==='revoke') return json(res,200,{ok:true,...await revokeApiKey(id,{actor:session.user?.name||'owner'})},cors);
          if (req.method==='POST' && km[2]==='rotate') return json(res,200,{ok:true,item:await rotateApiKey(id,{actor:session.user?.name||'owner'})},cors);
        }
      } catch (error) {
        const status=Number(error.statusCode)||500;
        if (status===503) return json(res,503,{error:error.code||'service_unavailable',operationId:error.operationId||undefined},cors);
        if ([400,404,409,413].includes(status)) return json(res,status,{error:status===404?'not_found':status===409?'conflict':'invalid_request'},cors);
        logger.error('control-center-owner',error.message); return json(res,500,{error:'internal_error'},cors);
      }
      return json(res,405,{error:'method_not_allowed'},cors);
    }

    // Minimal real API consumer for persisted API keys. It proves authentication without inventing a business API.
    if (path.startsWith('/api/v1/')) {
      if (originRejected(req,res)) return;
      if (req.method === 'OPTIONS') return json(res,204,{},cors);
      pruneApiRate(); const ipLimit = apiRateCheck(req, null);
      if (!ipLimit.allowed) { res.setHeader('Retry-After', String(ipLimit.retryAfter)); auditApi('API_RATE_LIMITED', req, null, 'rate_limited', { retryAfter: ipLimit.retryAfter }); return json(res,429,{error:'too_many_requests'},cors); }
      const api = requireApi(req,res,cors); if (!api) return;
      const keyLimit = apiRateCheck(req, api);
      if (!keyLimit.allowed) { res.setHeader('Retry-After', String(keyLimit.retryAfter)); auditApi('API_RATE_LIMITED', req, api, 'rate_limited', { retryAfter: keyLimit.retryAfter, scope: 'key' }); return json(res,429,{error:'too_many_requests'},cors); }
      const handled = await handleApiV1(req,res,api,{path});
      if (handled || res.writableEnded) return;
      auditApi('API_AUTH_SUCCESS',req,api,'success',{status:404});
      return json(res,404,{error:'not_found'},cors);
    }
    if (serveWeb(path, res)) return;
    if(path==='/api/health'){res.setHeader('Content-Type','application/json; charset=utf-8'); return res.end(JSON.stringify({ok:true,status:'live',version:config.botVersion,uptimeMs:process.uptime()*1000}));}
    if(path==='/api/health/ready'){const ready=!!server?.listening; res.setHeader('Content-Type','application/json; charset=utf-8'); res.statusCode=ready?200:503; return res.end(JSON.stringify({ok:ready,status:'ready',version:config.botVersion}));}
    if(path==='/api/overview') {
      const session = requireOwner(req,res,cors);
      if (!session) return;
      return json(res,200,controlSnapshot(),cors);
    }
    res.statusCode=404; res.setHeader('Content-Type','application/json; charset=utf-8'); res.end(JSON.stringify({error:'not found'}));
  });
  server.on('error', e=>{ serverReadyPromise && logger.error('control-center', e.message); });
  serverReadyPromise = new Promise((resolve, reject) => { const onError = e => { server?.off('listening', onListening); reject(e); }; const onListening = () => { server?.off('error', onError); resolve(server.address()); }; server.once('error', onError); server.once('listening', onListening); });
  server.listen(port,host,()=>logger.info('control-center',`dashboard em http://${host}:${port}`)); return { host, port };
}

export async function waitForControlCenter() { if (serverReadyPromise) return serverReadyPromise; return server?.address() || null; }
export async function stopControlCenter(){ if(!server) return; await new Promise(resolve=>server.close(()=>resolve())); server=null; serverReadyPromise=null; }
export default { startControlCenter, stopControlCenter, waitForControlCenter, controlSnapshot };
