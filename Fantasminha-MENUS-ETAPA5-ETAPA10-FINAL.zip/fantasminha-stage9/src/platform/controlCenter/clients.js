import commercial from '../../services/platformCommercial.js';

const STATES = new Set(['active', 'suspended', 'disabled']);
function cleanId(value) { return String(value ?? '').trim(); }
function cleanName(value) { return String(value ?? '').trim().replace(/\s+/g, ' '); }
function publicClient(client) {
  if (!client) return null;
  return { id: client.clientId, name: client.name, status: String(client.status || 'ACTIVE').toLowerCase(), createdAt: client.createdAt, updatedAt: client.updatedAt };
}
function validateName(value) {
  const name = cleanName(value);
  if (!name || name.length > 120) throw Object.assign(new Error('invalid client name'), { statusCode: 400 });
  return name;
}
export function listClients() { return commercial.listClients().map(publicClient).sort((a,b) => (a.createdAt||0)-(b.createdAt||0)); }
export function getClient(id) { const key=cleanId(id); if (!key || key.length > 100) return null; return publicClient(commercial.listClients().find(c => c.clientId === key) || null); }
export async function createClient({ name, actor='owner' }={}) { return publicClient(commercial.ensureClient({ name: validateName(name), actor })); }
export async function updateClient(id, body, { actor='owner' }={}) {
  const key=cleanId(id); const allowed=new Set(['name','status']);
  for (const field of Object.keys(body||{})) if (!allowed.has(field)) throw Object.assign(new Error('unknown field'),{statusCode:400});
  const current=commercial.listClients().find(c=>c.clientId===key); if(!current) throw Object.assign(new Error('client not found'),{statusCode:404});
  const name=body?.name===undefined ? current.name : validateName(body.name);
  let status=String(body?.status===undefined ? current.status : body.status).trim().toUpperCase();
  if(!STATES.has(status.toLowerCase())) throw Object.assign(new Error('invalid client status'),{statusCode:400});
  status=status;
  const updated=commercial.updateClient({clientId:key,name,status,actor});
  return publicClient(updated);
}
export async function deleteClient(id,{actor='owner'}={}) { return commercial.deleteClient(id, actor); }
export function clientStats() { const items=listClients(); return {total:items.length,active:items.filter(x=>x.status==='active').length,suspended:items.filter(x=>x.status==='suspended').length,disabled:items.filter(x=>x.status==='disabled').length}; }
export default { listClients,getClient,createClient,updateClient,deleteClient,clientStats };
