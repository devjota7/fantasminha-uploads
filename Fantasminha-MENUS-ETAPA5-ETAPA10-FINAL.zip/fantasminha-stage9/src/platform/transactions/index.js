import crypto from 'node:crypto';
import { readCollection, transactionCollections } from '../../database/store.js';
import { recordAudit } from '../audit/index.js';

export async function transact(steps, meta = {}) {
  const result = await transactionCollections(steps, meta);
  const tx = {
    id: result.id,
    at: Date.now(),
    status: result.status,
    meta,
    collections: result.collections,
    steps: result.collections.map(collection => ({ collection, staged: true }))
  };
  await recordAudit({
    actor: meta.actor,
    action: 'TRANSACTION_COMMITTED',
    operationId: meta.operationId,
    requestId: meta.requestId,
    result: 'success',
    details: { id: result.id, collections: result.collections }
  });
  return tx;
}

export async function transferBalance({ from, to, amount, currency = 'ghostcoins', actor = null, requestId = null, operationId = null } = {}) {
  const value = Math.floor(Number(amount));
  if (!from || !to || from === to || !Number.isInteger(value) || value <= 0) throw new Error('Transferência inválida');
  return transact([
    {
      collection: 'users',
      update: d => {
        d.byId ||= {};
        const a = d.byId[from] || { id: from, economy: { wallet: 0, bank: 0, inventory: {} } };
        const b = d.byId[to] || { id: to, economy: { wallet: 0, bank: 0, inventory: {} } };
        a.economy = { ...(a.economy || {}) };
        b.economy = { ...(b.economy || {}) };
        const wa = Number(a.economy.wallet || 0);
        if (wa < value) throw new Error('Saldo insuficiente');
        a.economy.wallet = wa - value;
        b.economy.wallet = Number(b.economy.wallet || 0) + value;
        d.byId[from] = a;
        d.byId[to] = b;
        return d;
      }
    },
    {
      collection: 'economy_ledger',
      update: d => {
        d.entries ||= [];
        d.entries.push({
          id: `LED-${crypto.randomUUID()}`,
          at: Date.now(), from, to, amount: value, currency, actor, requestId, operationId,
          reason: 'transfer'
        });
        if (d.entries.length > 20000) d.entries.splice(0, d.entries.length - 20000);
        return d;
      }
    }
  ], { actor, requestId, operationId, type: 'economy.transfer', from, to, amount: value });
}

export default { transact, transferBalance };
