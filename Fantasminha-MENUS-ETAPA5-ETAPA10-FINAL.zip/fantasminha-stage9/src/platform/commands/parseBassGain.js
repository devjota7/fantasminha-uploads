export function parseBassGain(value, { defaultValue = 10, min = 1, max = 20 } = {}) {
  if (value === undefined || value === null || String(value).trim() === '') return defaultValue;
  const raw = String(value).trim();
  if (!/^\d+$/.test(raw)) return null;
  const gain = Number(raw);
  return Number.isSafeInteger(gain) && gain >= min && gain <= max ? gain : null;
}
