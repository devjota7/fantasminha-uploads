export function strictOneBasedArrayIndex(value, length) {
  const raw = String(value ?? '').trim();
  if (!/^[1-9]\d*$/.test(raw)) return null;
  const oneBased = Number(raw);
  if (!Number.isSafeInteger(oneBased) || !Number.isSafeInteger(length) || length < 0 || oneBased > length) return null;
  return oneBased - 1;
}
