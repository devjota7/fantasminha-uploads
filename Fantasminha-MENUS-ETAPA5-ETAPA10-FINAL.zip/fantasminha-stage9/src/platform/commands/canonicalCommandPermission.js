export function canonicalCommandName(value, lookupCommand) {
  const normalized = String(value ?? '').trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (!normalized) return '';
  try {
    const definition = typeof lookupCommand === 'function' ? lookupCommand(normalized) : null;
    return String(definition?.name || normalized).trim().toLowerCase();
  } catch {
    return normalized;
  }
}

export function isCanonicalCommandAllowed(command, allowedCommands, lookupCommand) {
  const requested = canonicalCommandName(command, lookupCommand);
  if (!requested || !Array.isArray(allowedCommands)) return false;
  return allowedCommands.some(allowed => canonicalCommandName(allowed, lookupCommand) === requested);
}
