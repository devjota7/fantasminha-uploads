import crypto from 'node:crypto';
import { validToken } from './config.js';

function safeEqual(a, b) {
  const left = Buffer.from(String(a));
  const right = Buffer.from(String(b));
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

export function extractBearer(req) {
  const header = req.headers.authorization;
  if (typeof header !== 'string') return null;
  const match = /^Bearer\s+(.+)$/i.exec(header.trim());
  return match?.[1] || null;
}

export function authorize(req, token) {
  if (!validToken(token)) return false;
  const supplied = extractBearer(req);
  return !!supplied && safeEqual(supplied, token);
}

export { safeEqual };
