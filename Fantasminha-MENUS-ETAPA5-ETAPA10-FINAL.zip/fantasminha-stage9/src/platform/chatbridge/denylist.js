const WORD_PATTERNS = [
  /\b(shell|eval|exec|spawn)\b/i,
  /\b(ban|banir|kick|expuls|expulsar)\b/i,
  /\b(remover|remove|silenciar|silence|mutar|mute|apagar|deletar|delete|limpar|resetar|reset)\b/i,
  /\b(bloquear|desbloquear|block|unblock)\b/i,
  /\b(promover|promove|rebaixar|addadm|deladm|seradm|setar\s*dono|setdono)\b/i,
  /\b(backup|restaurar|restore|dbbackup)\b/i,
  /\b(parar|desligar|shutdown|reiniciar|restart)\b/i,
  /\b(atualizar|update|deploy|release|upgrade)\b/i,
  /\b(sair|leave).*grupo/i,
  /\b(rm|mv|cp|write|delete|arquivo|file|nuke)\b/i
];

export function normalizeName(value) {
  return String(value ?? '')
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\u200B-\u200F\u2060\uFEFF]/g, '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, '');
}

export const HARD_BLOCKED = new Set(['addadm', 'addsubbot', 'addsubdono', 'addxp', 'apagar', 'atualizar', 'atualizarbot', 'backup', 'banir', 'bloquear', 'bloqueartudo', 'dbbackup', 'deladm', 'delsubdono', 'delxp', 'deploy', 'desbloquear', 'desbloqueartudo', 'desligar', 'expulsar', 'limpar', 'limpardb', 'modoaluguel', 'mutar', 'nuke', 'parar', 'prefix', 'prefixo', 'promover', 'rebaixar', 'reboot', 'reconnectsubbot', 'reiniciar', 'release', 'remover', 'rentalclean', 'resetar', 'resetrpg', 'resetrpgglobal', 'restart', 'restaurar', 'rmsubbot', 'rpgresetglobal', 'sairgp', 'seradm', 'setardono', 'setdono', 'silenciar', 'updates', 'upgrade', 'viewmsg']);
export const OWNER_ONLY = new Set(['addalias', 'addauto', 'addautomedia', 'addautomidia', 'addautoresponse', 'addblackglobal', 'addcmd-subdono', 'addcmdmedia', 'addcmdmidia', 'addcmdvip', 'adddiasaluguel', 'addindica', 'addindicacao', 'addindicar', 'addnopref', 'addnoprefix', 'addpremium', 'addpremiumgp', 'addsubbot', 'addsubdono', 'addvipcommand', 'addvipgp', 'addxp', 'adicionarcmd', 'adicionarcmdvip', 'aluguelist', 'antibanmarcar', 'antipv', 'antipv2', 'antipv3', 'antipv4', 'antipvmessage', 'antipvmsg', 'antispamcmd', 'apikey', 'apikeyia', 'ativarcmdvip', 'ativarperso', 'atualizar', 'atualizarbot', 'audiomenu', 'autohorarios', 'avatarbot', 'bangp', 'blockcmdg', 'blockuserg', 'bloqueartudo', 'botname', 'botoff', 'boton', 'cachedebug', 'cancelaraluguel', 'cases', 'comandospersonalizados', 'comandosvip', 'conectarsubbot', 'configcmdnotfound', 'configmenu', 'criarpers', 'dayfree', 'debugcache', 'delalias', 'delauto', 'delautoresponse', 'delcmdvip', 'deletaraluguel', 'delindicacao', 'delnopref', 'delnoprefix', 'delpremium', 'delpremiumgp', 'delsubbot', 'delsubdono', 'delvipgp', 'delxp', 'desativarcmdvip', 'desbangp', 'desbloqueartudo', 'designmenu', 'detalhesaluguel', 'diagnosticrpg', 'div', 'divdono', 'divulgar', 'edcmd', 'edcmdmidia', 'editcmd', 'editcmdmidia', 'entrar',  'estenderaluguel', 'extenderrental', 'fixdb', 'forcarassist', 'fotobot', 'fotomenu', 'fotoperfil', 'gerarcod', 'gerarcodigobr', 'getcase', 'guia', 'iaapikey', 'iaclear', 'infoaluguel', 'infoserver', 'lermais', 'lermaismenus', 'limparaluguel', 'limpardb', 'limparhist', 'limparrankg', 'listaaluguel', 'listagp', 'listalias', 'listaluguel', 'listapremium', 'listaralugueis', 'listaraluguel', 'listarcmd', 'listarsubbots', 'listasubdonos', 'listauto', 'listautoresponses', 'listavip', 'listbangp', 'listblackglobal', 'listblocks', 'listcmd', 'listcmd-subdono', 'listcmdvip', 'listgp', 'listnopref', 'listnoprefix', 'listprem', 'listpremium', 'listrentals', 'listsubbots', 'listsubdonos', 'listvipcommands', 'mediamenu', 'menuaudio', 'menulermais', 'midiamenu', 'modoaluguel', 'modoliteglobal', 'msgboton', 'msgprefix', 'nome-bot', 'nomebot', 'nomedono', 'novapers', 'nuke', 'numero-dono', 'numerodono', 'openaikey', 'perfilbot', 'personalizargrupo', 'prefix', 'prefixo', 'premiumlist', 'protecaomarcar', 'reboot', 'reconnectsubbot', 'reiniciar', 'removecmd-subdono', 'removecmdvip', 'removeraluguel', 'removercmd', 'removerindicacao', 'removesubbot', 'removevipcommand', 'remsubdono', 'rentalclean', 'rentalconfig', 'rentalstats', 'rentaltest', 'repairdb', 'resetarmenu', 'resetdesign', 'resetdesignmenu', 'resetgold', 'restart', 'reviverqr', 'rmblackglobal', 'rmcmdvip', 'rmindicacao', 'rmpremium', 'rmpremiumgp', 'rmsubbot', 'rmsubdono', 'rmvip', 'rmvipgp', 'sairgp', 'seradm', 'sermembro', 'setborda', 'setbordabaixo', 'setbordafim', 'setbordameio', 'setbordamiddle', 'setbordatopo', 'setbottomborder', 'setcabecalho', 'setcmdmsg', 'setdiv', 'setheader', 'setheadermenu', 'setiakey', 'seticoneitem', 'seticoneseparador', 'seticonetitulo', 'setitem', 'setitemicon', 'setkey', 'setmenuaudio', 'setmiddleborder', 'setpersonalidade', 'setppbot', 'setseparador', 'setseparatoricon', 'settitleicon', 'settitulo', 'settopborder',  'statusalemdono', 'statusaluguel', 'statustm', 'statustm2', 'subbots', 'testarcmd', 'testcmd', 'tm', 'tm2', 'togglecmdvip', 'tutorial', 'unbangp', 'unblockcmdg', 'unblockuserg', 'update', 'updates', 'veralugueis', 'verdesign', 'videomenu', 'viewmsg']);

export function denylistedCommand(name, text = '', aliases = []) {
  const names = [name, ...(Array.isArray(aliases) ? aliases : [])]
    .map(normalizeName).filter(Boolean);
  if (names.some(n => HARD_BLOCKED.has(n))) return true;
  return names.some(n => WORD_PATTERNS.some(r => r.test(n)));
}

export const DENYLIST_DESCRIPTION = 'operações bloqueadas pela política de segurança do Chat Bridge; argumentos não são usados para classificar a denylist.';
