import { listCommands } from '../../core/registry.js';
import { MENUS, LEGACY_UNREGISTERED, NAVIGATION_NAMES } from '../../../dados/src/menus/menuMap.js';
import { Role } from '../../core/permissions.js';

const safeCategories=new Set(['menu','menus','info','perfil','rank','ranking']);
function classification(cmd){
  if(cmd?.classification && cmd.classification!=='LEGACY' && cmd.classification!=='ACTIVE') return {destructive:false,simulationSafe:true};
  const c=String(cmd?.category||'').toLowerCase();
  if(safeCategories.has(c)||/perfil|rank|menu|info/.test(c)) return {destructive:false,simulationSafe:true};
  if(/econom|jogo|admin|dono|grupo/.test(c)) return {destructive:true,simulationSafe:false};
  return {destructive:false,simulationSafe:false};
}
export function buildCatalog(){
  const registry=listCommands({includeHidden:false});
  const reg=registry.map(c=>{const cls=classification(c);return {name:c.name,aliases:c.aliases,category:c.category,description:c.description||'',syntax:c.syntax||c.usage||`×${c.name}`,examples:c.examples||[],minRole:roleName(c.permission),destructive:!!cls.destructive,simulationSafe:!!cls.simulationSafe};});
  const legacy=LEGACY_UNREGISTERED.filter(x=>x.enabled!==false).map(x=>({name:x.name,aliases:x.aliases||[],category:x.menu||'legacy',description:x.description||'',syntax:`×${x.usage||x.name}`,examples:[],minRole:roleName(x.permission),destructive:true,simulationSafe:false,legacy:true}));
  const byName=new Set(reg.map(x=>x.name));
  const navigation= new Set(NAVIGATION_NAMES);
  const unlistedMenus=[]; for(const menu of Object.values(MENUS)) for(const section of menu.sections||[]) for(const name of section.commands||[]) if(!byName.has(name)&&!legacy.some(x=>x.name===name)&&!navigation.has(name)) unlistedMenus.push(name);
  return {prefix:'×',commands:[...reg,...legacy].filter((v,i,a)=>a.findIndex(x=>x.name===v.name)===i).sort((a,b)=>a.name.localeCompare(b.name)),coverage:{registry:reg.length,legacy:legacy.length,note:unlistedMenus.length?`O menuMap contém ${unlistedMenus.length} nomes sem entrada no Registry/LEGACY_UNREGISTERED; eles não foram inventados no catálogo.`:'Registry e LEGACY_UNREGISTERED cobrem os nomes publicados no menuMap.'}};
}
function roleName(permission){ const p=Number(permission||Role.USER); return p>=Role.OWNER?'OWNER':p>=Role.BOT_ADMIN?'ADMIN':p>=Role.GROUP_ADMIN?'ADMIN':p>=Role.USER?'USER':'USER'; }
export default {buildCatalog};
