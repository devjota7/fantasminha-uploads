import crypto from 'node:crypto';

export const CHAT_BRIDGE_VERSION = 2;
export const DEFAULT_PORT = 30100;
export const MAX_BODY_BYTES = 16 * 1024;
export const MAX_LONG_POLL_MS = 25_000;
export const QUIESCENCE_MS = 1_200;
export const MAX_EXECUTION_MS = 15_000;
export const MEDIA_INLINE_BYTES = 2 * 1024 * 1024;
export const MEDIA_TTL_MS = 10 * 60 * 1000;
export const DEFAULT_RATE_LIMIT = 60;
export const DEFAULT_RATE_WINDOW_MS = 60_000;

export function readConfig(env = process.env) {
  const token = String(env.CHAT_BRIDGE_TOKEN || '');
  const requestedRole = String(env.CHAT_BRIDGE_ACTOR_ROLE || 'member').trim().toLowerCase();
  const validRoles = new Set(['member', 'admin', 'owner']);
  let actorRole = validRoles.has(requestedRole) ? requestedRole : 'member';
  const allowOwnerActor = String(env.CHAT_BRIDGE_ALLOW_OWNER_ACTOR || 'false').toLowerCase() === 'true';
  if (actorRole === 'owner' && !allowOwnerActor) {
    actorRole = 'member';
    console.warn('[CHAT-BRIDGE] CHAT_BRIDGE_ACTOR_ROLE=owner ignorado porque CHAT_BRIDGE_ALLOW_OWNER_ACTOR não está habilitado; usando member.');
  }
  const allowRealDb = String(env.CHAT_BRIDGE_ALLOW_REAL_DB || 'false').toLowerCase() === 'true';
  if (allowRealDb) console.warn('[CHAT-BRIDGE] CHAT_BRIDGE_ALLOW_REAL_DB=true: comandos do Bridge podem usar o banco de runtime.');
  return Object.freeze({
    enabled: String(env.CHAT_BRIDGE_ENABLED || 'false').toLowerCase() === 'true',
    port: Number.isInteger(Number(env.CHAT_BRIDGE_PORT)) && Number(env.CHAT_BRIDGE_PORT) > 0 ? Number(env.CHAT_BRIDGE_PORT) : DEFAULT_PORT,
    token,
    allowReal: String(env.CHAT_BRIDGE_ALLOW_REAL || 'false').toLowerCase() === 'true',
    allowRealDb,
    actorRole,
    allowOwnerActor,
    realChatIds: new Set(String(env.CHAT_BRIDGE_REAL_CHAT_IDS || '').split(',').map(x => x.trim()).filter(Boolean)),
    rateLimit: Math.max(1, Number(env.CHAT_BRIDGE_RATE_LIMIT || DEFAULT_RATE_LIMIT)),
    rateWindowMs: Math.max(1000, Number(env.CHAT_BRIDGE_RATE_WINDOW_MS || DEFAULT_RATE_WINDOW_MS)),
    socketTimeoutMs: Math.max(1000, Number(env.CHAT_BRIDGE_SOCKET_TIMEOUT_MS || 30_000))
  });
}

export function validToken(token) { return typeof token === 'string' && token.length >= 32; }
export function randomId(prefix = 'r-') { return `${prefix}${crypto.randomBytes(8).toString('hex')}`; }
