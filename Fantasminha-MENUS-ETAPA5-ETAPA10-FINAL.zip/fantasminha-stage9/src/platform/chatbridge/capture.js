import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { MEDIA_INLINE_BYTES, MEDIA_TTL_MS } from './config.js';

const media = new Map();
let mediaDir = null;

function unwrapContent(input) {
  let content = input;
  const wrappers = ['viewOnceMessage','viewOnceMessageV2','viewOnceMessageV2Extension','ephemeralMessage','documentWithCaptionMessage'];
  for (let i = 0; i < 8 && content && typeof content === 'object'; i++) {
    const key = wrappers.find(k => content?.[k]?.message);
    if (!key) break;
    content = content[key].message;
  }
  return content;
}

function normalizeRows(sections = []) {
  return (Array.isArray(sections) ? sections : []).map(section => ({
    title: String(section?.title || ''),
    rows: (Array.isArray(section?.rows) ? section.rows : []).map(row => ({
      id: String(row?.rowId ?? row?.id ?? ''),
      title: String(row?.title || ''),
      description: row?.description == null ? undefined : String(row.description)
    }))
  }));
}

function parseJson(value) {
  if (!value || typeof value !== 'string') return null;
  try { return JSON.parse(value); } catch { return null; }
}

function buttonLabel(value) {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  return String(value.display_text ?? value.displayText ?? value.text ?? value.label ?? value.name ?? '');
}

function nativeFlowContent(native, bodyText = '') {
  const buttons = [];
  let list = null;
  for (const raw of Array.isArray(native?.buttons) ? native.buttons : []) {
    const name = String(raw?.name || '').toLowerCase();
    const params = parseJson(raw?.buttonParamsJson) || parseJson(raw?.paramsJson) || {};
    if (name === 'quick_reply') {
      buttons.push({ id: String(params.id ?? params.button_id ?? ''), label: buttonLabel(params.display_text ?? params.displayText ?? params) });
      continue;
    }
    if (name === 'single_select') {
      const sections = normalizeRows(params.sections);
      list = {
        title: String(params.title || ''),
        text: bodyText,
        buttonText: String(params.button_text ?? params.buttonText ?? params.title ?? ''),
        sections
      };
      continue;
    }
    if (name === 'cta_url' || name === 'cta_copy' || name === 'cta_call') {
      const label = buttonLabel(params.display_text ?? params.displayText ?? params.label ?? params);
      const value = String(params.url ?? params.copy_code ?? params.phone_number ?? params.phoneNumber ?? '');
      buttons.push({ id: '', label: value ? `${label} — ${value}` : label, informational: true, actionType: name });
      continue;
    }
    if (name === 'carousel' || name === 'carousel_message') {
      return { type: 'carousel', text: bodyText };
    }
  }
  if (list) return { type: 'list', ...list };
  if (buttons.length) return { type: 'buttons', text: bodyText, buttons };
  return null;
}

export function createCaptureStore() {
  const warnings = [];
  const messages = [];
  const listeners = new Set();
  let lastCaptureAt = 0;
  let seq = 0;
  async function ensureDir() { if (!mediaDir) mediaDir = await fs.mkdtemp(path.join(os.tmpdir(), 'fantasminha-chatbridge-')); return mediaDir; }
  function notify(message) { lastCaptureAt = Date.now(); for (const fn of listeners) { try { fn(message); } catch {} } }
  function push(message) { const normalized = { id: message.id || `m${++seq}`, ts: message.ts || Math.floor(Date.now()/1000), type: message.type, ...message }; messages.push(normalized); notify(normalized); return normalized; }
  function warn(value) { const s = String(value); if (!warnings.includes(s)) warnings.push(s); }
  async function mediaRef(value, mime = 'application/octet-stream') {
    if (Buffer.isBuffer(value)) {
      if (value.length <= MEDIA_INLINE_BYTES) return { dataBase64: value.toString('base64') };
      const dir = await ensureDir(); const mediaId = crypto.randomBytes(12).toString('hex'); const file = path.join(dir, mediaId);
      await fs.writeFile(file, value); media.set(mediaId, { file, mime, expiresAt: Date.now() + MEDIA_TTL_MS }); return { mediaId };
    }
    if (typeof value === 'string') return /^https?:\/\//i.test(value) ? { url: value } : { dataBase64: Buffer.from(value).toString('base64') };
    if (value && typeof value.pipe === 'function') {
      const chunks=[]; for await (const c of value) chunks.push(Buffer.from(c)); return mediaRef(Buffer.concat(chunks), mime);
    }
    return null;
  }
  function mediaSource(value) {
    if (Buffer.isBuffer(value)) return value;
    if (typeof value === 'string') return value;
    if (value && typeof value === 'object') return Buffer.isBuffer(value.buffer) ? value.buffer : (Buffer.isBuffer(value.data) ? value.data : (typeof value.url === 'string' ? value.url : null));
    return null;
  }
  async function normalize(jid, rawContent, options = {}) {
    const id = options.messageId || `m${++seq}`; const ts = Math.floor(Date.now()/1000); const content = unwrapContent(rawContent); const quotedId = options.quotedId || content?.contextInfo?.stanzaId || null;
    if (!content || typeof content !== 'object') return push({id,ts,type:'unsupported',rawType:typeof content});
    if (content.react) return push({id,ts,type:'reaction',targetId:content.react.key?.id || content.react.id || '',emoji:content.react.text || ''});
    if (content.edit) return push({id,ts,type:'edit',targetId:content.edit.key?.id || content.edit.id || '',text:String(content.edit.text || '')});
    if (content.delete) return push({id,ts,type:'delete',targetId:content.delete.key?.id || content.delete.id || ''});

    // Buttons/lists/interactive must be detected before the generic text path.
    if (content.buttons || content.buttonsMessage || content.templateButtons) {
      const b = content.buttonsMessage || content; const buttons = (b.buttons || b.templateButtons || []).map(x => ({id:String(x.buttonId || x.button?.buttonId || x.id || ''),label:String(x.buttonText?.displayText || x.buttonText || x.text || x.label || '')}));
      return push({id,ts,type:'buttons',text:String(b.contentText || b.text || ''),footer:b.footerText || b.footer,buttons,quotedId});
    }
    if (content.sections || content.listMessage) {
      const l=content.listMessage || content; const sections=normalizeRows(l.sections);
      return push({id,ts,type:'list',title:String(l.title || ''),text:String(l.description||l.text||''),buttonText:String(l.buttonText||''),sections,quotedId});
    }

    const interactive = content.interactiveMessage;
    if (interactive) {
      const bodyText = String(interactive.body?.text || interactive.text || '');
      const native = interactive.nativeFlowMessage;
      if (interactive.carouselMessage || nativeFlowContent(native, bodyText)?.type === 'carousel') {
        return push({id,ts,type:'unsupported',rawType:'carousel',text:bodyText,quotedId});
      }
      if (interactive.header?.imageMessage) {
        const image = interactive.header.imageMessage;
        const source = mediaSource(image);
        const ref = await mediaRef(source, image?.mimetype || image?.mimeType || 'image/jpeg');
        if (ref) push({id:`${id}-header`,ts,type:'image',caption:bodyText,mime:image?.mimetype || image?.mimeType || 'image/jpeg',...ref,quotedId});
        else warn('interactiveMessage.header.imageMessage presente, mas a mídia não estava disponível para captura.');
      }
      const nativeResult = nativeFlowContent(native, bodyText);
      if (nativeResult?.type === 'list') return push({id,ts,type:'list',title:nativeResult.title,text:nativeResult.text,buttonText:nativeResult.buttonText,sections:nativeResult.sections,quotedId});
      if (nativeResult?.type === 'buttons') return push({id,ts,type:'buttons',text:nativeResult.text,buttons:nativeResult.buttons,quotedId});
      return push({id,ts,type:'unsupported',rawType:'interactiveMessage',text:bodyText,quotedId});
    }
    if (content.nativeFlowMessage) {
      const nativeResult = nativeFlowContent(content.nativeFlowMessage, String(content.body?.text || content.text || ''));
      if (nativeResult?.type === 'list') return push({id,ts,type:'list',title:nativeResult.title,text:nativeResult.text,buttonText:nativeResult.buttonText,sections:nativeResult.sections,quotedId});
      if (nativeResult?.type === 'buttons') return push({id,ts,type:'buttons',text:nativeResult.text,buttons:nativeResult.buttons,quotedId});
      if (nativeResult?.type === 'carousel') return push({id,ts,type:'unsupported',rawType:'carousel',text:nativeResult.text,quotedId});
    }

    if (content.pollCreationMessage || content.poll) {
      const p=content.pollCreationMessage || content.poll;
      const rawOptions = p.options || p.values || [];
      return push({id,ts,type:'poll',name:String(p.name||''),options:rawOptions.map(x=>String(x?.optionName ?? x?.name ?? x)),selectableCount:p.selectableOptionsCount ?? p.selectableCount});
    }
    if (typeof content.text === 'string') return push({id,ts,type:'text',text:content.text,mentions:Array.isArray(content.mentions)?content.mentions:[],quotedId});
    if (content.image || content.video || content.audio || content.sticker || content.document || content.ptv) {
      const key = content.image ? 'image' : content.video ? 'video' : content.audio ? 'audio' : content.sticker ? 'sticker' : content.document ? 'document' : 'video';
      const value = content[key]; const mime = value?.mimetype || value?.mimeType || (key === 'image' ? 'image/jpeg' : 'application/octet-stream');
      const source = mediaSource(value) || (Buffer.isBuffer(value?.data) ? value.data : value?.data);
      const ref = await mediaRef(source, mime);
      if (!ref) return push({id,ts,type:'unsupported',rawType:key});
      if (key === 'document') return push({id,ts,type:'document',fileName:value?.fileName || 'document',mime, ...ref});
      if (key === 'audio') return push({id,ts,type:'audio',ptt:!!value?.ptt,seconds:value?.seconds,...ref});
      if (key === 'sticker') return push({id,ts,type:'sticker',mime,...ref});
      return push({id,ts,type:key,caption:value?.caption || content.caption,mime,width:value?.width,height:value?.height,...ref});
    }
    if (content.contacts || content.contact) { const c=content.contacts?.[0] || content.contact; return push({id,ts,type:'contact',displayName:String(c?.displayName||c?.name||''),vcard:String(c?.vcard||'')}); }
    if (content.location || content.locationMessage) { const l=content.location || content.locationMessage; return push({id,ts,type:'location',lat:Number(l.degreesLatitude||l.lat),lng:Number(l.degreesLongitude||l.lng),name:l.name}); }
    return push({id,ts,type:'unsupported',rawType:Object.keys(content).find(k=>!k.startsWith('__')) || 'unknown'});
  }
  return { messages, warnings, normalize, push, warn, on: fn => { listeners.add(fn); return () => listeners.delete(fn); }, get lastCaptureAt(){return lastCaptureAt;}, get count(){return messages.length;}, async cleanup(){ for(const [id,item] of media){if(item.expiresAt<=Date.now()){try{await fs.unlink(item.file)}catch{} media.delete(id)}} }, async dispose(){for(const item of media.values()){try{await fs.unlink(item.file)}catch{}} media.clear();if(mediaDir){try{await fs.rm(mediaDir,{recursive:true,force:true})}catch{}}mediaDir=null;} };
}
export async function readMedia(mediaId) { const item=media.get(mediaId); if(!item || item.expiresAt<Date.now()){media.delete(mediaId);return null;} try{return {mime:item.mime, data:await fs.readFile(item.file)}}catch{return null;} }
export default { createCaptureStore, readMedia };
