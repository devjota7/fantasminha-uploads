const state = { whatsapp: 'unknown', startedAt: Date.now(), version: '2.0.0' };
export function setWhatsappState(connection) {
  state.whatsapp = connection === 'open' ? 'open' : connection === 'connecting' ? 'connecting' : connection === 'close' || connection === 'closed' ? 'closed' : 'unknown';
}
export function getHealth(realEnabled = false) {
  return { ok: true, whatsapp: state.whatsapp, uptimeSec: Math.floor((Date.now() - state.startedAt) / 1000), version: state.version,
    chatBridge: { version: 2, modes: ['simulation', ...(realEnabled ? ['real'] : [])], realEnabled: !!realEnabled } };
}
export default { setWhatsappState, getHealth };
