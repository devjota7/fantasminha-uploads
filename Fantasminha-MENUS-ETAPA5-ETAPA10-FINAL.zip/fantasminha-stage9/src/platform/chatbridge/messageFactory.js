import crypto from 'node:crypto';
import { configuredOwner } from '../../core/permissions.js';
import config from '../../core/config.js';

const fake = { member:'5500000000000@s.whatsapp.net', admin:'5500000000001@s.whatsapp.net' };
function ownerJid() { const candidates=[...(config.ownerIds||[]),config.ownerNumber,process.env.OWNER_NUMBER].filter(Boolean); const jid=candidates.map(String).find(x=>configuredOwner(x)); return jid ? (String(jid).includes('@')?String(jid):`${String(jid).replace(/\D/g,'')}@s.whatsapp.net`) : ''; }
export function actorJid(actor={}) { if(actor.role==='owner'){const jid=ownerJid(); if(!jid) throw new Error('Dono não configurado: OWNER_NUMBER/OWNER_IDS/OWNER_LID ausente ou inválido.'); return jid;} return fake[actor.role] || fake.member; }
export function chatJid(chat={}, actor={}) { if(chat.type==='group') return chat.id && String(chat.id).includes('@') ? String(chat.id) : '120363000000000000@g.us'; return actorJid(actor); }
export function createVirtualMessage({text,chat,actor,quotedId=null}) { const participant=actorJid(actor); const remoteJid=chat.type==='dm' ? participant : chatJid(chat,actor); const id=`FSIM${crypto.randomBytes(8).toString('hex')}`; const body=String(text||''); const message=body.includes('\n')||body.length?{extendedTextMessage:{text:body,contextInfo:quotedId?{stanzaId:quotedId}:undefined}}:{conversation:body}; return { key:{remoteJid,fromMe:false,id,participant:chat.type==='group'?participant:undefined}, pushName:String(actor?.pushName||'Jota'), messageTimestamp:Math.floor(Date.now()/1000), message, __fantasminhaChatBridge:true };
}
export function createInteractionMessage({chat,actor,targetId,buttonId,listRowId,mode='button'}) { const base=createVirtualMessage({text:'',chat,actor}); base.key.id=`FSIM${crypto.randomBytes(8).toString('hex')}`; if(mode==='list') base.message={listResponseMessage:{singleSelectReply:{selectedRowId:String(listRowId)},title:''}}; else if(mode==='interactive') base.message={interactiveResponseMessage:{nativeFlowResponseMessage:{paramsJson:JSON.stringify({id:String(buttonId||listRowId||'')})}}}; else base.message={buttonsResponseMessage:{selectedButtonId:String(buttonId||listRowId||'')}}; base.messageTimestamp=Math.floor(Date.now()/1000); base.__fantasminhaChatBridgeTargetId=targetId; return base; }
export default {createVirtualMessage,createInteractionMessage,actorJid,chatJid};
