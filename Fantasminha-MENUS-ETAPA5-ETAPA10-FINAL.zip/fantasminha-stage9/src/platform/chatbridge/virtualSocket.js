import { decorateOutgoingContent } from '../../respostas/outgoing.js';

const ACTIONS = new Map([
 ['groupParticipantsUpdate', 'atualizar participantes do grupo'], ['groupSettingUpdate','alterar configurações do grupo'], ['groupUpdateSubject','alterar assunto do grupo'], ['groupUpdateDescription','alterar descrição do grupo'], ['groupLeave','sair do grupo'], ['updateBlockStatus','alterar bloqueio'], ['chatModify','modificar chat'], ['updateProfilePicture','alterar foto do perfil'], ['groupAcceptInvite','aceitar convite do grupo'], ['groupRequestParticipantsUpdate','solicitar participantes do grupo']
]);
const READS = new Set(['groupMetadata','groupFetchAllParticipating','onWhatsApp','profilePictureUrl','getName','groupInviteCode']);
export function createVirtualSocket({realSock,capture,actor,chat,commandContext={}}) {
  const baseUser=realSock?.user ? {id:realSock.user.id,lid:realSock.user.lid} : {id:'0@s.whatsapp.net',lid:null};
  const action = (name,args) => { capture.push({type:'action',name,summary:`${name}: ${summarize(name,args)}`,simulated:true}); return {ok:true,simulated:true}; };
  const summarize=(name,args)=>{try{return JSON.stringify(args).slice(0,700)}catch{return 'argumentos indisponíveis'}};
  const target={ user:baseUser };
  target.ev={emit(){},on(){},off(){},removeAllListeners(){}};
  target.sendMessage=async(jid,content,options={})=>{const styled=decorateOutgoingContent(content,{command:commandContext.command,prefix:commandContext.prefix}); const result=await capture.normalize(jid,styled,{quotedId:options?.quoted?.key?.id || styled?.contextInfo?.stanzaId}); return {key:{remoteJid:jid,fromMe:true,id:`FSIMOUT${Date.now().toString(16)}`},message:styled,messageTimestamp:Math.floor(Date.now()/1000),__fantasminhaChatBridge:true,__capturedId:result.id};};
  target.react=async(jid,key,emoji)=>capture.normalize(jid,{react:{text:emoji,key} });
  target.relayMessage=async(jid,message)=>capture.normalize(jid,message);
  target.readMessages=async()=>undefined;
  target.sendPresenceUpdate=async()=>{capture.warn('sendPresenceUpdate ignorado em simulação');return undefined;};
  target.presenceSubscribe=async()=>undefined;
  target.query=async()=>{capture.warn('query ignorado em simulação');return {};};
  target.groupMetadata=async(jid)=>({id:jid,subject:'Fantasminha (simulação)',participants:[{id:actor?.jid,admin:actor?.role==='owner'||actor?.role==='admin'?'admin':null},{id:baseUser.id,admin:'admin'}]});
  target.groupFetchAllParticipating=async()=>({[chat?.id||'120363000000000000@g.us']:await target.groupMetadata(chat?.id||'120363000000000000@g.us')});
  target.onWhatsApp=async(...ids)=>ids.map(jid=>({exists:true,jid:String(jid).includes('@')?jid:`${jid}@s.whatsapp.net`}));
  target.profilePictureUrl=async()=>'';
  target.getName=async jid=>String(jid).split('@')[0];
  target.groupInviteCode=async()=> 'SIMULATED';
  for(const [name] of ACTIONS) target[name]=async(...args)=>action(name,args);
  target.groupRequestParticipantsUpdate=async(...args)=>action('groupRequestParticipantsUpdate',args);
  target.signalRepository=realSock?.signalRepository;
  target.authState=realSock?.authState;
  target.ws={close(){}};
  return new Proxy(target,{get(t,p){if(p in t)return t[p]; if(READS.has(p)) return async()=>({}); if(p==='then'||p==='toJSON'||typeof p==='symbol')return undefined; return (...args)=>{capture.warn(`método ${String(p)} indisponível em simulação`);return undefined;};},set(t,p,v){t[p]=v;return true;}});
}
export default {createVirtualSocket};
