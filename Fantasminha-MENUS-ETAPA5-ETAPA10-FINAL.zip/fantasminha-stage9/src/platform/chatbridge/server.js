import http from 'node:http';
import crypto from 'node:crypto';
import { authorize } from './auth.js';
import { readConfig, validToken, MAX_BODY_BYTES, MAX_LONG_POLL_MS, QUIESCENCE_MS, MAX_EXECUTION_MS, randomId } from './config.js';
import { getHealth } from './health.js';
import { createVirtualSocket } from './virtualSocket.js';
import { createVirtualMessage, createInteractionMessage, actorJid, chatJid } from './messageFactory.js';
import { createCaptureStore, readMedia } from './capture.js';
import { buildCatalog } from './catalog.js';
import { denylistedCommand, DENYLIST_DESCRIPTION, normalizeName, HARD_BLOCKED, OWNER_ONLY } from './denylist.js';
import { getCommand } from '../../core/registry.js';
import { getEffectivePrefix } from '../../core/prefix.js';
import { configuredOwner, Role } from '../../core/permissions.js';
import config from '../../core/config.js';

let singleton = null;

function json(res,status,payload,extra={}){const body=Buffer.from(JSON.stringify(payload));res.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':body.length,'cache-control':'no-store',...extra});res.end(body);}
function parseUrl(req){return new URL(req.url||'/',`http://${req.headers.host||'127.0.0.1'}`);}
async function readBody(req){let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>MAX_BODY_BYTES){ const e=new Error('PAYLOAD_TOO_LARGE');e.code='PAYLOAD_TOO_LARGE';throw e;}chunks.push(chunk);}if(!chunks.length)return {};try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{const e=new Error('INVALID_JSON');e.code='INVALID_JSON';throw e;}}
function tokenIdentity(req){const auth=req.headers.authorization;const token=/^Bearer\s+(.+)$/i.exec(typeof auth==='string'?auth.trim():'')?.[1]||'';return crypto.createHash('sha256').update(token).digest('hex').slice(0,16);}
function rateLimited(rt, identity){const now=Date.now();let rate=rt.rates.get(identity);if(!rate || now-rate.started>=rt.cfg.rateWindowMs){rate={started:now,count:0};rt.rates.set(identity,rate);}rate.count++;for(const [key,item] of rt.rates){if(now-item.started>=rt.cfg.rateWindowMs)rt.rates.delete(key);}while(rt.rates.size>64){const oldest=rt.rates.keys().next().value;rt.rates.delete(oldest);}if(rate.count>rt.cfg.rateLimit)return Math.max(1,Math.ceil((rt.cfg.rateWindowMs-(now-rate.started))/1000));return 0;}
function sanitizeText(value,max=64,fallback='Jota'){const clean=String(value??'').replace(/[\u0000-\u001F\u007F-\u009F\u200B-\u200F\u2060\uFEFF]/g,'').trim();return clean.slice(0,max)||fallback;}
function validateClientId(value, field){if(value==null)return null;const v=String(value);if(field==='chat.id'){if(v!=='virtual'&&!/^[0-9]{5,30}(?:-[0-9]+)?@g\.us$/.test(v))return null;return v;}if(v.length>128)return null;return v;}
function normalizeFreeText(value){return String(value??'').replace(/[\u200B-\u200F\u2060\uFEFF]/g,'').trim();}
function extractCommand(text,chat={}){const raw=String(text||'').trim();const prefix=(chat?.type==='group'&&String(chat?.id||'').endsWith('@g.us')?getEffectivePrefix(String(chat.id)):'×');if(!raw.startsWith(prefix))return {name:'',raw,commandText:raw,prefix};const rest=raw.slice(prefix.length).trim();const name=normalizeName(rest.split(/\s+/)[0]||'');return {name,raw,commandText:rest,prefix};}
function minRoleForActor(role){return role==='owner'?Role.OWNER:role==='admin'?Role.GROUP_ADMIN:Role.USER;}
export const SPECIAL_ROLE_DELEGATED_COMMANDS = new Set([
  'addaluguel', 'gerarcod', 'gerarcodigobr',
  'listaraluguel', 'listaralugueis', 'veralugueis', 'listrentals',
  'infoaluguel', 'statusaluguel', 'detalhesaluguel',
  'estenderaluguel', 'adddiasaluguel', 'extenderrental'
]);

export const SAFE_READONLY_ALLOWLIST = new Set([
  'menu','menus','menubn','menujogos','menuia','menugrupo','menurpg','menualem','menudown','ferramentas','menusistema','menuadm','menudono','menuvip','menuaranha',
  'perfil','meustatus','perfilrpg','rank','ranking','rankjogos','ranklevel','ranklvl','rankgc','rankglobal','rankgads','rankpeques',
  'ping','info','ajuda','regras','statusbot','statusgp','botstats','tempoativo','recursos','sobrebot','criador','dono','catalogo','comandos','cmdinfo','comandobusca','aliasinfo','aliasbusca','mapabot','guia','guiafantasminha','listaferramentas','conhecimento'
]);

function commandPolicy(name,text,actor,confirmSideEffects,bridgeConfig=readConfig()){
  const typed=normalizeName(name);
  if(!typed)return {canonical:'',simulationSafe:true,freeText:true};
  const cmd=getCommand(typed);
  const canonical=normalizeName(cmd?.name || typed);
  const aliases=cmd?.aliases || [];
  const names=[typed,canonical,...aliases.map(normalizeName)];
  if(names.some(n=>HARD_BLOCKED.has(n)))return {blocked:true,permanent:true,reason:'blocked',canonical};
  const ownerOnly=(names.some(n=>OWNER_ONLY.has(n)) && !names.some(n=>SPECIAL_ROLE_DELEGATED_COMMANDS.has(n))) || Number(cmd?.permission||0)>=Role.BOT_ADMIN || cmd?.ownerOnly===true;
  if(ownerOnly && !(actor==='owner' && bridgeConfig.allowOwnerActor))return {blocked:true,permanent:true,reason:'blocked',canonical};
  if(denylistedCommand(canonical,'',aliases))return {blocked:true,permanent:false,reason:'denylist',detail:DENYLIST_DESCRIPTION,canonical};
  const simulationSafe=SAFE_READONLY_ALLOWLIST.has(canonical);
  const destructive=!!cmd && (cmd.permission>=Role.GROUP_ADMIN || /econom|jogo|admin|dono|grupo/.test(String(cmd.category||'').toLowerCase()));
  if(!simulationSafe&&!confirmSideEffects)return {requiresConfirmation:true,commands:[canonical||typed],sideEffects:[cmd?(destructive?'o comando pode alterar estado externo/persistente':'o comando não está na SAFE_READONLY_ALLOWLIST'):'o comando é desconhecido ou não está classificado na SAFE_READONLY_ALLOWLIST'],canonical,cmd};
  return {cmd,canonical,destructive,simulationSafe};
}

function isProvablyInertFreeText(text){return !!text && !/^\$|^>>/.test(normalizeFreeText(text));}
function audit(rt,data){const row={at:new Date().toISOString(),...data};rt.audit.push(row);if(rt.audit.length>500)rt.audit.shift();try{console.log(JSON.stringify({chatBridgeAudit:row}));}catch{}}
function enqueueEvents(rt,messages){if(!messages.length)return;for(const m of messages){const cursor=String(++rt.cursor);rt.events.push({cursor,message:m});if(rt.events.length>500)rt.events.shift();}for(const waiter of [...rt.waiters]){try{waiter();}catch{} }}
function latestCursor(rt){return String(rt.cursor);}
function waitForEvents(rt,cursor,waitMs){const start=Date.now();const found=()=>rt.events.filter(e=>Number(e.cursor)>Number(cursor||0)).map(e=>e.message);if(found().length)return Promise.resolve(found());return new Promise(resolve=>{const finish=()=>{clearTimeout(timer);rt.waiters.delete(finish);resolve(found());};const timer=setTimeout(finish,Math.min(MAX_LONG_POLL_MS,Math.max(0,Number(waitMs)||20_000)));rt.waiters.add(finish);});}
async function waitQuiescent(capture,startCount){const deadline=Date.now()+MAX_EXECUTION_MS;let last=capture.lastCaptureAt||Date.now();while(Date.now()<deadline){await new Promise(r=>setTimeout(r,100));const current=capture.lastCaptureAt||last;if(current!==last){last=current;continue;}if(Date.now()-last>=QUIESCENCE_MS)return;}}

export function createChatBridgeServer({realSock=null,indexModule,getMessagesCache=()=>null,rentalExpirationManager=null,onClose=()=>{}}={}){
  if(singleton) return singleton;
  const cfg=readConfig();
  const rt={cfg,server:null,realSock,indexModule,getMessagesCache,rentalExpirationManager,rates:new Map(),startedAt:Date.now(),cursor:0,events:[],waiters:new Set(),audit:[],mediaStores:new Set(),closed:false};
  rt.updateSocket=(sock)=>{rt.realSock=sock;};
  if(!cfg.enabled){console.log('[CHAT-BRIDGE] desativado: CHAT_BRIDGE_ENABLED não é true.');singleton={server:null,updateSocket:rt.updateSocket,close:async()=>{}};return singleton;}
  if(!validToken(cfg.token)){console.log('[CHAT-BRIDGE] não iniciado: CHAT_BRIDGE_TOKEN ausente ou menor que 32 caracteres.');singleton={server:null,updateSocket:rt.updateSocket,close:async()=>{}};return singleton;}
  const server=http.createServer(async(req,res)=>{
    req.setTimeout(cfg.socketTimeoutMs); res.setHeader('x-content-type-options','nosniff');
    const url=parseUrl(req); const path=url.pathname;
    try{
      if(req.method==='GET'&&path==='/health')return json(res,200,getHealth(cfg.allowReal));
      if(!authorize(req,cfg.token))return json(res,401,{error:'unauthorized'});
      const retry=rateLimited(rt,tokenIdentity(req)); if(retry)return json(res,429,{error:'rateLimit'}, {'Retry-After':String(retry)});
      if(req.method==='GET'&&path==='/v2/commands')return json(res,200,buildCatalog());
      if(req.method==='GET'&&path.startsWith('/v2/media/')){const item=await readMedia(path.slice('/v2/media/'.length));if(!item)return json(res,404,{error:'notFound'});res.writeHead(200,{'content-type':item.mime,'cache-control':'private, max-age=0'});return res.end(item.data);}
      if(req.method==='GET'&&path==='/v2/chat/events'){const msgs=await waitForEvents(rt,url.searchParams.get('cursor')||'0',url.searchParams.get('waitMs'));return json(res,200,{cursor:latestCursor(rt),messages:msgs});}
      if(req.method==='POST'&&(path==='/v2/chat/send'||path==='/v2/chat/interact'||path==='/chat')){
        let body;try{body=await readBody(req);}catch(e){if(e.code==='PAYLOAD_TOO_LARGE'){ const out=json(res,413,{error:'payloadTooLarge'}); setImmediate(()=>{try{req.destroy();}catch{}}); return out; }return json(res,400,{error:'invalidJson'});}
        const suppliedActorRole=body?.actor?.role;
        if(path==='/chat') body={...body,mode:'simulation',chat:{type:'dm',id:'virtual'},actor:{...(body.actor||{}),role:'member'}};
        const requestId=randomId(); const started=Date.now(); let commandName=''; const role=cfg.actorRole;
        const warnings=[];
        if(suppliedActorRole!=null && String(suppliedActorRole).toLowerCase()!==role)warnings.push('actor.role ignorado; usando o papel configurado');
        const actor={...(body.actor||{}),role,pushName:sanitizeText(body.actor?.pushName,64,'Jota')};
        if(path==='/v2/chat/send' && typeof body.text!=='string')return json(res,400,{error:'invalidField',field:'text'});
        if(path==='/v2/chat/interact' && (!body.targetId || (!body.buttonId&&!body.listRowId)))return json(res,400,{error:'invalidField',field:'targetId/buttonId'});
        const chat=body.chat||{type:'dm',id:'virtual'};
        const chatId=validateClientId(chat.id,'chat.id');
        if(chat.id!=null && !chatId)return json(res,400,{error:'invalidField',field:'chat.id'});
        for(const field of ['quotedId','targetId','buttonId','listRowId'])if(body[field]!=null&&validateClientId(body[field],field)==null)return json(res,400,{error:'invalidField',field});
        const mode=body.mode||'simulation';
        if(mode==='real' && !(cfg.allowReal&&cfg.realChatIds.has(String(body.chat?.id))))return json(res,403,{error:'blocked',reason:'realMode'});
        if(mode!=='simulation'&&mode!=='real')return json(res,400,{error:'invalidField',field:'mode'});
        if(mode==='real'){return await executeReal(rt,res,{body:{...body,actor,chat:{...chat,id:chatId||'virtual'}},requestId,started,role,warnings,cfg});}
        const parsed=extractCommand(body.text,chat);commandName=parsed.name;
        const freeText=normalizeFreeText(body.text);
        if(!commandName && (/^\$/.test(freeText)||/^>>/.test(freeText)))return json(res,403,{error:'blocked',reason:'metaCommand'});
        const policy=path==='/v2/chat/interact' ? {canonical:'',simulationSafe:true} : commandPolicy(commandName,body.text,role,body.confirmSideEffects===true,cfg);
        commandName=policy.canonical || commandName;
        if(policy.blocked){
          if(!policy.permanent && body.confirmSideEffects!==true){
            audit(rt,{requestId,command:commandName,actor:role,mode,result:'requiresConfirmation'});
            return json(res,409,{error:'requiresConfirmation',commands:[commandName],sideEffects:[policy.detail || DENYLIST_DESCRIPTION]});
          }
          audit(rt,{requestId,command:commandName,actor:role,mode,result:'blocked'});
          return json(res,403,{error:'blocked',reason:policy.reason});
        }
        if(!policy.simulationSafe && !cfg.allowRealDb && !process.env.FANTASMINHA_DB_ROOT){
          return json(res,409,{error:'dbNotIsolated',reason:'defina FANTASMINHA_DB_ROOT para uma cópia sandbox ou CHAT_BRIDGE_ALLOW_REAL_DB=true'});
        }
        if(policy.requiresConfirmation){audit(rt,{requestId,command:commandName,actor:role,mode,result:'requiresConfirmation'});return json(res,409,{error:'requiresConfirmation',commands:policy.commands,sideEffects:policy.sideEffects});}
        if(role==='owner' && commandName && !configuredOwner(actorJid(actor)))return json(res,403,{error:'blocked',reason:'ownerNotConfigured'});
        const capture=createCaptureStore();rt.mediaStores.add(capture);const before=capture.count;
        const virtual=createVirtualSocket({realSock:rt.realSock,capture,actor:{...actor,jid:actorJid(actor)},chat,commandContext:{command:commandName,prefix:parsed.prefix||'×'}});
        const info=path==='/v2/chat/send'?createVirtualMessage({text:body.text,chat,actor,quotedId:body.quotedId||null}):createInteractionMessage({chat,actor,targetId:body.targetId,buttonId:body.buttonId,listRowId:body.listRowId,mode:body.listRowId?'list':body.buttonId?'button':'interactive'});
        let error=null;
        try{if(typeof rt.indexModule!=='function')throw new Error('indexModule indisponível');await Promise.race([rt.indexModule(virtual,info,null,rt.getMessagesCache(),rt.rentalExpirationManager),new Promise((_,rej)=>setTimeout(()=>rej(new Error('execution timeout')),MAX_EXECUTION_MS))]);await waitQuiescent(capture,before);}catch(e){error=e;}
        const messages=[...capture.messages];rt.cursor += messages.length;const cursor=String(rt.cursor);capture.on(m=>{if(!messages.some(x=>x.id===m.id))enqueueEvents(rt,[m]);});const cleanupTimer=setTimeout(()=>{capture.dispose().catch(()=>{});rt.mediaStores.delete(capture);},15_000);cleanupTimer.unref();
        const responseWarnings=[...new Set([...warnings,...capture.warnings])]; if(cfg.allowRealDb)responseWarnings.push('CHAT_BRIDGE_ALLOW_REAL_DB=true está em uso; o banco de runtime não está isolado.');
        if(error){audit(rt,{requestId,command:commandName,actor:role,mode,result:'error'});return json(res,500,{error:'internal',requestId});}
        audit(rt,{requestId,command:commandName,actor:role,mode,result:'success',durationMs:Date.now()-started});
        const legacy=path==='/chat';if(legacy){const first=messages.find(x=>x.type==='text');return json(res,200,{text:first?.text||'',buttons:first?.buttons||[],imageUrl:first?.url||null});}
        return json(res,200,{ok:true,requestId,mode:'simulation',cursor,durationMs:Date.now()-started,warnings:responseWarnings,messages});
      }
      if(req.method==='POST'&&path==='/v2/sandbox/reset')return json(res,403,{error:'blocked',reason:'sandboxUnavailable'});
      return json(res,404,{error:'notFound'});
    }catch(e){return json(res,500,{error:'internal',requestId:randomId()});}
  });
  server.on('clientError',(err,socket)=>{try{socket.end('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n')}catch{}});
  server.on('connection',socket=>{socket.setTimeout(cfg.socketTimeoutMs);socket.on('timeout',()=>socket.destroy());});
  server.on('error',err=>{console.error(`[CHAT-BRIDGE] não foi possível ouvir em 127.0.0.1:${cfg.port}: ${err?.code||err?.message}. O bot segue sem o bridge.`);rt.closed=true;if(singleton===rt)singleton=null;try{server.close()}catch{}});
  server.listen(cfg.port,'127.0.0.1',()=>console.log(`[CHAT-BRIDGE] ouvindo em 127.0.0.1:${cfg.port}`));
  rt.server=server;singleton=rt;
  rt.close=async()=>{if(rt.closed)return;rt.closed=true;for(const c of rt.mediaStores)await c.dispose();rt.mediaStores.clear();for(const waiter of rt.waiters)try{waiter()}catch{}rt.waiters.clear();try{server.closeIdleConnections?.();server.closeAllConnections?.();}catch{}await new Promise(resolve=>{if(!server.listening)return resolve();server.close(()=>resolve());});onClose();};
  return rt;
}

async function executeReal(rt,res,{body,requestId,started,role,warnings=[],cfg}){
  const chat=body.chat||{type:'dm',id:'virtual'};
  const parsed=extractCommand(body.text,chat);
  const freeText=normalizeFreeText(body.text);
  if(!parsed.name && (/^\$/.test(freeText)||/^>>/.test(freeText)))return json(res,403,{error:'blocked',reason:'metaCommand'});
  const policy=commandPolicy(parsed.name,body.text,role,body.confirmSideEffects===true,cfg);
  if(policy.blocked){
    if(!policy.permanent && body.confirmSideEffects!==true)return json(res,409,{error:'requiresConfirmation',commands:[parsed.name],sideEffects:[policy.detail || DENYLIST_DESCRIPTION]});
    audit(rt,{requestId,command:parsed.name,actor:role,mode:'real',result:'blocked'});return json(res,403,{error:'blocked',reason:policy.reason});
  }
  if(policy.requiresConfirmation){return json(res,409,{error:'requiresConfirmation',commands:policy.commands,sideEffects:policy.sideEffects});}
  if(!parsed.name && !isProvablyInertFreeText(freeText))return json(res,409,{error:'dbNotIsolated',reason:'defina FANTASMINHA_DB_ROOT para uma cópia sandbox ou CHAT_BRIDGE_ALLOW_REAL_DB=true'});
  try{
    if(typeof rt.indexModule!=='function') throw new Error('indexModule indisponível');
    const info=createVirtualMessage({text:body.text,chat,actor:body.actor||{role:'member',pushName:'Jota'},quotedId:body.quotedId||null});
    await rt.indexModule(rt.realSock,info,null,rt.getMessagesCache(),rt.rentalExpirationManager);
    audit(rt,{requestId,command:parsed.name,actor:role,mode:'real',result:'success',durationMs:Date.now()-started});
    return json(res,200,{ok:true,requestId,mode:'real',cursor:latestCursor(rt),durationMs:Date.now()-started,warnings:[...warnings],messages:[]});
  }catch{audit(rt,{requestId,command:parsed.name,actor:role,mode:'real',result:'error'});return json(res,500,{error:'internal',requestId});}
}

export { extractCommand, rateLimited, normalizeFreeText };
export function getChatBridge(){return singleton;}
export async function stopChatBridge(){if(singleton?.close)await singleton.close();singleton=null;}
export default {createChatBridgeServer,getChatBridge,stopChatBridge};
