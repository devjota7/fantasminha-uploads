/** Pequenos adaptadores de envio do WhatsApp; módulos não conhecem Baileys. */
export async function sendPoll(sock, chatId, { name, options, selectableCount = 1 } = {}) {
  if (!sock?.sendMessage) throw new Error('Socket indisponível');
  if (!chatId) throw new Error('Chat obrigatório');
  if (!name || !Array.isArray(options) || options.length < 2) throw new Error('Enquete inválida');
  return sock.sendMessage(chatId, {
    poll: {
      name: String(name),
      values: options.map(value => String(value)),
      selectableCount: Number(selectableCount) || 1
    }
  });
}

export default { sendPoll };
