/** Download de mídia recebida (única camada que fala com o Baileys para a Triagem). */
export async function downloadReceivedImage(imageMessage) {
  if (!imageMessage) return null;
  const { downloadContentFromMessage } = await import('baileys');
  const stream = await downloadContentFromMessage(imageMessage, 'image');
  const chunks = [];
  for await (const chunk of stream) chunks.push(Buffer.from(chunk));
  const buffer = Buffer.concat(chunks);
  return buffer.length ? buffer : null;
}
export default { downloadReceivedImage };
