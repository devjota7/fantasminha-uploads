/** Integrações: entrypoint sem trocar clientes ou endpoints existentes. */
export { default as httpClient } from '../http/client.js';
export { default as spiderXApi } from '../../services/spider-x-api.js';
export { fantasminhaApi, FantasminhaApiClient, ApiClientError, CircuitBreaker } from '../../services/api/index.js';
export { getOpenAIConfig } from '../../services/assistant/openaiProvider.js';
