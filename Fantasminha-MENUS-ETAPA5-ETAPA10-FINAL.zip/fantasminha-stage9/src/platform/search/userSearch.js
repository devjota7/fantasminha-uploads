/**
 * 👻 Fantasminha — busca de usuários (somente dono).
 *
 * Fontes:
 *  - groupFetchAllParticipating(): em quais grupos a pessoa está AGORA, papel (ADM/membro),
 *    número real (phoneNumber) e se o bot é ADM (para gerar link de convite).
 *  - dados/database/grupos/<id>.json -> contador[]: nome do ZAP (pushname), 1ª/última atividade e contagens.
 *  - coleções users e nicks: nome salvo e nick.
 */
import fs from 'node:fs';
import path from 'node:path';
import { readCollection } from '../../database/store.js';
import { GRUPOS_DIR } from '../../../dados/src/utils/paths.js';

const MAX_RESULTS = 10;
const DETAIL_LIMIT = 3;        // até 3 pessoas: modo detalhado (com links)
const MAX_GROUPS_DETAIL = 10;  // grupos listados por pessoa no modo detalhado
const GROUPS_CACHE_MS = 2 * 60_000;
const LINK_CACHE_MS = 10 * 60_000;

const baseOf = v => String(v || '').split('@')[0].split(':')[0].trim().toLowerCase();
const norm = s => String(s || '').normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase().trim();
const isPnJid = v => typeof v === 'string' && v.endsWith('@s.whatsapp.net');

let groupsCache = { at: 0, data: null };
const linkCache = new Map();

async function fetchGroups(sock, force = false) {
  if (!force && groupsCache.data && Date.now() - groupsCache.at < GROUPS_CACHE_MS) return groupsCache.data;
  const all = await sock.groupFetchAllParticipating();
  groupsCache = { at: Date.now(), data: Object.values(all || {}) };
  return groupsCache.data;
}

function readGroupCounter(groupId) {
  try {
    const file = path.join(GRUPOS_DIR, `${groupId}.json`);
    if (!fs.existsSync(file)) return new Map();
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    const map = new Map();
    for (const u of Array.isArray(data?.contador) ? data.contador : []) {
      const b = baseOf(u?.id);
      if (b) map.set(b, u);
    }
    return map;
  } catch { return new Map(); }
}

function botAliases(sock) {
  const me = sock?.authState?.creds?.me || {};
  return new Set([sock?.user?.id, sock?.user?.lid, me.id, me.lid].map(baseOf).filter(Boolean));
}

async function participantPn(sock, p) {
  for (const v of [p?.phoneNumber, p?.pn, p?.jid]) if (isPnJid(v)) return baseOf(v);
  if (isPnJid(p?.id)) return baseOf(p.id);
  const lid = [p?.lid, p?.id].find(v => typeof v === 'string' && v.endsWith('@lid'));
  if (lid) {
    try {
      const mapped = await sock?.signalRepository?.lidMapping?.getPNForLID?.(lid);
      if (isPnJid(mapped)) return baseOf(mapped);
    } catch {}
  }
  return null;
}

export function fmtDate(ts, withTime = false) {
  if (!ts) return '—';
  const d = new Date(ts);
  if (Number.isNaN(d.getTime())) return '—';
  const opts = { timeZone: 'America/Sao_Paulo', day: '2-digit', month: '2-digit', year: 'numeric', ...(withTime ? { hour: '2-digit', minute: '2-digit' } : {}) };
  return d.toLocaleString('pt-BR', opts);
}

function fmtPhone(pn) { return pn ? `+${pn}` : null; }

/** Monta o índice de pessoas (união por qualquer alias: LID / número). */
async function buildPeople(sock, groups) {
  const bot = botAliases(sock);
  const people = [];
  const byAlias = new Map();
  const users = readCollection('users', { byId: {} }).byId || {};
  const nicks = Object.values(readCollection('nicks', { byId: {} }).byId || {});
  const nameByBase = new Map();
  for (const u of Object.values(users)) { const b = baseOf(u?.id || u?.platformId); if (b && u?.name) nameByBase.set(b, u.name); }
  const nickByBase = new Map();
  for (const n of nicks) { const b = baseOf(n?.platformId); if (b && n?.nick && n.active !== false) nickByBase.set(b, n.nick); }

  for (const g of groups) {
    const counter = readGroupCounter(g.id);
    const participants = Array.isArray(g.participants) ? g.participants : [];
    const botIsAdmin = participants.some(p => (p?.admin === 'admin' || p?.admin === 'superadmin') && [p.id, p.lid, p.phoneNumber, p.jid].some(v => bot.has(baseOf(v))));
    for (const p of participants) {
      const pn = await participantPn(sock, p);
      const aliases = [...new Set([p?.id, p?.lid, p?.jid, p?.phoneNumber, p?.pn, pn].map(baseOf).filter(Boolean))];
      if (!aliases.length) continue;
      let person = aliases.map(a => byAlias.get(a)).find(Boolean);
      if (!person) { person = { aliases: new Set(), pn: null, names: new Set(), nick: null, groups: [] }; people.push(person); }
      for (const a of aliases) { person.aliases.add(a); byAlias.set(a, person); }
      if (pn && !person.pn) person.pn = pn;

      const entry = aliases.map(a => counter.get(a)).find(Boolean);
      if (entry?.pushname && entry.pushname !== 'Usuário Desconhecido') person.names.add(entry.pushname);
      for (const a of aliases) {
        if (nameByBase.has(a)) person.names.add(nameByBase.get(a));
        if (!person.nick && nickByBase.has(a)) person.nick = nickByBase.get(a);
      }
      person.groups.push({
        id: g.id,
        subject: g.subject || g.id,
        role: p?.admin === 'superadmin' ? 'DONO DO GRUPO' : p?.admin === 'admin' ? 'ADM' : 'membro',
        botIsAdmin,
        msgs: entry ? (entry.msg || 0) + (entry.cmd || 0) + (entry.figu || 0) : null,
        firstSeen: entry?.firstSeen || null,
        lastActivity: entry?.lastActivity || null
      });
    }
  }
  return { people, byAlias };
}

function matchScore(person, query) {
  const q = norm(query);
  const hay = [...person.names, person.nick].filter(Boolean).map(norm);
  if (hay.some(h => h === q)) return 3;
  if (hay.some(h => h.startsWith(q))) return 2;
  if (hay.some(h => h.includes(q))) return 1;
  return 0;
}

async function groupLink(sock, g) {
  if (!g.botIsAdmin) return null;
  const cached = linkCache.get(g.id);
  if (cached && Date.now() - cached.at < LINK_CACHE_MS) return cached.url;
  try {
    const code = await sock.groupInviteCode(g.id);
    const url = code ? `https://chat.whatsapp.com/${code}` : null;
    if (url) linkCache.set(g.id, { url, at: Date.now() });
    return url;
  } catch { return null; }
}

async function fillLinks(sock, persons) {
  const wanted = new Map();
  for (const p of persons) for (const g of p.groups.slice(0, MAX_GROUPS_DETAIL)) if (g.botIsAdmin) wanted.set(g.id, g);
  const list = [...wanted.values()];
  for (let i = 0; i < list.length; i += 5) {
    await Promise.all(list.slice(i, i + 5).map(async g => { g.link = await groupLink(sock, g); }));
  }
  for (const p of persons) for (const g of p.groups) if (!g.link && wanted.has(g.id)) g.link = wanted.get(g.id).link || null;
}

/**
 * @returns {{text:string, mentions:string[]}}
 */
export async function searchUsers(sock, { query = '', mentionedJid = null, quotedJid = null, prefix = '×' } = {}) {
  const raw = String(query || '').trim();
  const targetBase = baseOf(mentionedJid || quotedJid || '');
  const digitsQuery = /^[+\d\s()-]{5,}$/.test(raw) ? raw.replace(/\D/g, '') : '';
  if (!raw && !targetBase) {
    return { text: `🔎 *BUSCAR USUÁRIO*\n\nUse:\n• ${prefix}buscarusuario <nome ou nick>\n• ${prefix}buscarusuario <número>\n• ${prefix}buscarusuario @menção\n• respondendo a uma mensagem da pessoa`, mentions: [] };
  }
  if (!targetBase && !digitsQuery && norm(raw).length < 2) return { text: '🔎 Digite pelo menos 2 letras para buscar por nome.', mentions: [] };

  const groups = await fetchGroups(sock);
  const { people } = await buildPeople(sock, groups);

  let found = [];
  if (targetBase) found = people.filter(p => p.aliases.has(targetBase)).map(p => ({ p, score: 3 }));
  else if (digitsQuery) found = people.filter(p => [...p.aliases].some(a => a.includes(digitsQuery))).map(p => ({ p, score: [...p.aliases].some(a => a === digitsQuery || a.endsWith(digitsQuery)) ? 3 : 1 }));
  else found = people.map(p => ({ p, score: matchScore(p, raw) })).filter(x => x.score > 0);

  found.sort((a, b) => b.score - a.score || b.p.groups.length - a.p.groups.length);
  const total = found.length;
  const shown = found.slice(0, MAX_RESULTS).map(x => x.p);
  if (!shown.length) return { text: `🔎 Nenhum usuário encontrado para *${raw || 'essa pessoa'}* nos grupos em que o bot está.`, mentions: [] };

  const detailed = shown.length <= DETAIL_LIMIT;
  if (detailed) await fillLinks(sock, shown);

  const mentions = [];
  const blocks = shown.map((p, i) => {
    const name = [...p.names][0] || p.nick || 'Sem nome';
    const mentionJid = p.pn ? `${p.pn}@s.whatsapp.net` : null;
    if (mentionJid) mentions.push(mentionJid);
    const phone = fmtPhone(p.pn);
    const first = p.groups.map(g => g.firstSeen).filter(Boolean).sort()[0];
    const last = p.groups.map(g => g.lastActivity).filter(Boolean).sort().slice(-1)[0];

    if (!detailed) {
      const gl = p.groups.slice(0, 3).map(g => g.subject).join(', ') + (p.groups.length > 3 ? ` +${p.groups.length - 3}` : '');
      return `*${i + 1}.* ${name}${p.nick ? ` (${p.nick})` : ''}\n   ${mentionJid ? `@${p.pn}` : 'número não disponível'} · ${p.groups.length} grupo(s)\n   ${gl}`;
    }

    const head = [
      `*${i + 1}. ${name}*`,
      p.nick ? `🏷️ Nick: ${p.nick}` : null,
      p.names.size > 1 ? `📛 Outros nomes: ${[...p.names].slice(1).join(', ')}` : null,
      phone ? `📱 Número: ${phone}` : '📱 Número: não disponível (só identificador interno)',
      mentionJid ? `🔗 Menção: @${p.pn}` : null,
      `🕐 1ª vez visto: ${fmtDate(first)} · última atividade: ${fmtDate(last, true)}`,
      `👥 Grupos (${p.groups.length}):`
    ].filter(Boolean);
    const gl = p.groups.slice(0, MAX_GROUPS_DETAIL).map(g => {
      const lines = [`  • *${g.subject}* — ${g.role}`];
      if (g.msgs != null) lines.push(`     💬 ${g.msgs} msgs · 1ª: ${fmtDate(g.firstSeen)} · última: ${fmtDate(g.lastActivity, true)}`);
      lines.push(`     🔗 ${g.link || (g.botIsAdmin ? 'link indisponível' : 'sem link (bot não é ADM)')}`);
      return lines.join('\n');
    });
    if (p.groups.length > MAX_GROUPS_DETAIL) gl.push(`  … e mais ${p.groups.length - MAX_GROUPS_DETAIL} grupo(s)`);
    return [...head, ...gl].join('\n');
  });

  const title = `🔎 *BUSCA DE USUÁRIOS* — ${total} resultado(s)${total > shown.length ? ` (mostrando ${shown.length})` : ''}`;
  const foot = detailed ? '' : `\n\n💡 Refine a busca (nome completo, número ou @menção) para ver detalhes e links dos grupos.`;
  return { text: `${title}\n\n${blocks.join('\n\n')}${foot}`, mentions: [...new Set(mentions)] };
}

export default { searchUsers, fmtDate };
