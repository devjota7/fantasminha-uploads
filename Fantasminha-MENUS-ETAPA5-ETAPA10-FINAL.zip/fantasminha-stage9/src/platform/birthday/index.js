import crypto from 'node:crypto';
import { readCollection, updateCollection, transactionCollections } from '../../database/store.js';
import { ensureMember } from '../member/index.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';

const recordKey = (groupId, memberId) => `${String(groupId || 'global')}::${String(memberId)}`;
const nowYear = () => new Date().getFullYear();

function valid(day, month) {
  const d = Number(day), m = Number(month);
  if (!Number.isInteger(d) || !Number.isInteger(m) || m < 1 || m > 12 || d < 1 || d > 31) throw new Error('Data de aniversário inválida. Use DD/MM ou DD/MM/AAAA.');
  const max = new Date(2024, m, 0).getDate();
  if (d > max) throw new Error('Essa data não existe.');
  return { day: d, month: m };
}

export function parseBirthday(text) {
  const m = String(text || '').trim().match(/^(\d{1,2})[\/-](\d{1,2})(?:[\/-](\d{4}))?$/);
  if (!m) throw new Error('Use DD/MM ou DD/MM/AAAA.');
  const { day, month } = valid(m[1], m[2]);
  const year = m[3] ? Number(m[3]) : null;
  if (year !== null && (year < 1900 || year > nowYear() + 100)) throw new Error(`Ano de aniversário inválido. Use entre 1900 e ${nowYear() + 100}.`);
  return { day, month, year };
}

function normalizeStore(d) { d.byId ||= {}; return d; }
function findRecord(d, groupId, memberId) {
  const k = recordKey(groupId, memberId);
  if (d.byId?.[k]) return d.byId[k];
  const legacy = d.byId?.[memberId];
  if (legacy && String(legacy.groupId || '') === String(groupId || '')) return legacy;
  return null;
}

export function listBirthdays(groupId = null) {
  const d = readCollection('birthdays', { byId: {} });
  return Object.values(d.byId || {}).filter(x => x && x.active !== false && (!groupId || x.groupId === groupId)).sort((a,b) => a.month-b.month || a.day-b.day || String(a.platformId||'').localeCompare(String(b.platformId||'')));
}

export async function setBirthday(platformId, date, { groupId = null, actor = platformId, reason = null } = {}) {
  if (!groupId) throw new Error('Grupo obrigatório para cadastrar aniversário.');
  const parsed = typeof date === 'string' ? parseBirthday(date) : { ...valid(date.day, date.month), year: date.year == null ? null : Number(date.year) };
  if (parsed.year !== null && (parsed.year < 1900 || parsed.year > nowYear() + 100)) throw new Error(`Ano de aniversário inválido. Use entre 1900 e ${nowYear() + 100}.`);
  const member = await ensureMember(platformId);
  const memberId = member.memberId;
  let before = null, after = null;

  await transactionCollections([
    { collection:'birthdays', update: async d => {
      normalizeStore(d);
      const k = recordKey(groupId, memberId);
      before = d.byId[k] || findRecord(d, groupId, memberId) || null;
      after = { id:before?.id || `BD-${crypto.randomUUID()}`, memberId, platformId:String(platformId), groupId, day:parsed.day, month:parsed.month, year:parsed.year ?? before?.year ?? null, active:true, createdAt:before?.createdAt || Date.now(), updatedAt:Date.now() };
      d.byId[k] = after;
      if (d.byId[memberId] && d.byId[memberId] !== before) delete d.byId[memberId];
      return d;
    } },
    { collection:'birthday_history', update: async d => {
      d.entries ||= [];
      d.entries.push({ id:`BIRTHDAY-HIST-${crypto.randomUUID()}`, action:'BIRTHDAY_CHANGED', groupId, memberId, before, after, actor, reason, at:Date.now() });
      if (d.entries.length > 5000) d.entries = d.entries.slice(-5000);
      return d;
    } }
  ], { feature:'birthday', action:'change', groupId, memberId });
  await recordAudit({ actor, target: memberId, action: 'BIRTHDAY_CHANGED', before, after, reason });
  await emit(PlatformEvents.PROFILE_CHANGED, { type: 'birthday', memberId, groupId, before, after });
  await emit(PlatformEvents.BIRTHDAY_CHANGED, { memberId, groupId, before, after });
  return after;
}

export async function removeBirthday(memberId, { groupId = null, actor = null, reason = null } = {}) {
  if (!groupId) throw new Error('Grupo obrigatório para remover aniversário.');
  let before = null, after = null;
  await transactionCollections([
    { collection:'birthdays', update: async d => {
      normalizeStore(d);
      const k = recordKey(groupId, memberId);
      before = d.byId[k] || findRecord(d, groupId, memberId);
      if (!before || before.active === false) throw new Error('Aniversário não encontrado neste grupo.');
      after = { ...before, active:false, updatedAt:Date.now() };
      d.byId[k] = after;
      if (d.byId[memberId] && d.byId[memberId].groupId === groupId) delete d.byId[memberId];
      return d;
    } },
    { collection:'birthday_history', update: async d => {
      d.entries ||= [];
      d.entries.push({ id:`BIRTHDAY-HIST-${crypto.randomUUID()}`, action:'BIRTHDAY_REMOVED', groupId, memberId, before, after, actor, reason, at:Date.now() });
      if (d.entries.length > 5000) d.entries = d.entries.slice(-5000);
      return d;
    } }
  ], { feature:'birthday', action:'remove', groupId, memberId });

  await recordAudit({ actor, target: memberId, action: 'BIRTHDAY_REMOVED', before, after, reason });
  await emit(PlatformEvents.PROFILE_CHANGED, { type: 'birthday', memberId, groupId, before, after });
  await emit(PlatformEvents.BIRTHDAY_CHANGED, { memberId, groupId, before, after });
  return after;
}

export function getBirthdayForMember(groupId, memberId) {
  if (!groupId || !memberId) return null;
  const d = readCollection('birthdays', { byId: {} });
  const row = findRecord(d, groupId, memberId);
  return row && row.active !== false ? row : null;
}

export function todayBirthdays(groupId = null, now = new Date(), timeZone = 'America/Sao_Paulo') {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(now);
  const month = Number(parts.find(x => x.type === 'month')?.value);
  const day = Number(parts.find(x => x.type === 'day')?.value);
  return listBirthdays(groupId).filter(x => x.month === month && x.day === day);
}

function isLeapYear(year) { return year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0); }
function occurrenceForYear(row, year) {
  if (row.month === 2 && row.day === 29 && !isLeapYear(year)) return null;
  // UTC midnight representa apenas a data civil e evita que o fuso do processo altere o dia.
  return new Date(Date.UTC(year, row.month - 1, row.day));
}

function localCalendarDate(now, timeZone = 'America/Sao_Paulo') {
  const parts = new Intl.DateTimeFormat('en-CA', { timeZone, year:'numeric', month:'2-digit', day:'2-digit' }).formatToParts(now);
  return {
    year: Number(parts.find(x => x.type === 'year')?.value),
    month: Number(parts.find(x => x.type === 'month')?.value),
    day: Number(parts.find(x => x.type === 'day')?.value)
  };
}

function nextOccurrence(row, now, timeZone = 'America/Sao_Paulo') {
  const local = localCalendarDate(now, timeZone);
  let year = local.year;
  let date = occurrenceForYear(row, year);
  const todayKey = Date.UTC(local.year, local.month - 1, local.day);
  if (!date || date.getTime() < todayKey) {
    do { year += 1; date = occurrenceForYear(row, year); } while (!date);
  }
  return date;
}

export function nextBirthdays(groupId = null, limit = 5, now = new Date(), timeZone = 'America/Sao_Paulo') {
  const safeLimit = Math.max(1, Math.min(100, Number(limit) || 5));
  const local = localCalendarDate(now, timeZone);
  const todayKey = Date.UTC(local.year, local.month - 1, local.day);
  return listBirthdays(groupId)
    .map(x => { const occurrence = nextOccurrence(x, now, timeZone); return { ...x, occurrenceDate: occurrence, delta: occurrence.getTime() - todayKey }; })
    .sort((a,b) => a.delta - b.delta)
    .slice(0, safeLimit);
}

export default { parseBirthday, listBirthdays, setBirthday, removeBirthday, todayBirthdays, nextBirthdays };
