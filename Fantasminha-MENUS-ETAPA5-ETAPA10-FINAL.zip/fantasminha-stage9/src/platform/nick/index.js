import crypto from 'node:crypto';
import { readCollection, updateCollection, transactionCollections } from '../../database/store.js';
import { ensureMember } from '../member/index.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';

const normalize = s => String(s ?? '').normalize('NFKC').trim().replace(/[\u0000-\u001F\u007F]/g, '');
const key = s => normalize(s).toLocaleLowerCase('pt-BR');
const recordKey = (groupId, memberId) => `${String(groupId || 'global')}::${String(memberId)}`;

function policy(groupId) {
  const d = readCollection('nick_policies', { byGroup: {} });
  return { unique: true, minLength: 2, maxLength: 24, ...(d.byGroup?.[groupId] || {}) };
}

function validateNick(nick, p) {
  if (!nick) throw new Error('Informe o nick.');
  if (nick.length < p.minLength || nick.length > p.maxLength) throw new Error(`Nick deve ter ${p.minLength}-${p.maxLength} caracteres.`);
  if (/[@\n\r\u2028\u2029]/.test(nick)) throw new Error('Nick inválido: não use @ ou quebras de linha.');
  if (!/[\p{L}\p{N}]/u.test(nick)) throw new Error('Nick precisa conter pelo menos uma letra ou número.');
  return nick;
}

function normalizeStore(d) {
  d.byId ||= {};
  return d;
}

function findRecord(d, groupId, memberId) {
  const k = recordKey(groupId, memberId);
  if (d.byId?.[k]) return d.byId[k];
  // Compatibilidade com a estrutura antiga (uma chave global por memberId).
  const legacy = d.byId?.[memberId];
  if (legacy && String(legacy.groupId || '') === String(groupId || '')) return legacy;
  return null;
}

function activeRows(d, groupId) {
  return Object.values(d.byId || {}).filter(x => x && x.active !== false && (!groupId || x.groupId === groupId));
}

export function listNicks(groupId = null, { section = null, order = 'alpha' } = {}) {
  const d = readCollection('nicks', { byId: {} });
  let list = activeRows(d, groupId);
  if (section) list = list.filter(x => x.sectionId === section);
  if (order === 'alpha') list.sort((a,b) => key(a.nick).localeCompare(key(b.nick), 'pt-BR'));
  else if (order === 'reverse') list.sort((a,b) => key(b.nick).localeCompare(key(a.nick), 'pt-BR'));
  else if (order === 'newest') list.sort((a,b) => Number(b.updatedAt||0) - Number(a.updatedAt||0));
  else if (order === 'oldest') list.sort((a,b) => Number(a.createdAt||0) - Number(b.createdAt||0));
  return list;
}

export async function setNick(platformId, nick, { groupId = null, actor = platformId, sectionId = null, reason = null } = {}) {
  if (!groupId) throw new Error('Grupo obrigatório para cadastrar nick.');
  nick = validateNick(normalize(nick), policy(groupId));
  const member = await ensureMember(platformId);
  const memberId = member.memberId;
  const p = policy(groupId);
  let before = null, after = null;

  await transactionCollections([
    { collection:'nicks', update: async d => {
      normalizeStore(d);
      const existing = activeRows(d, groupId).find(x => p.unique && key(x.nick) === key(nick) && x.memberId !== memberId);
      if (existing) throw new Error('Esse nick já está em uso neste grupo.');
      const k = recordKey(groupId, memberId);
      before = d.byId[k] || findRecord(d, groupId, memberId) || null;
      const id = before?.id || `NICK-${crypto.randomUUID()}`;
      after = { id, memberId, platformId: String(platformId), groupId, nick, sectionId: sectionId ?? before?.sectionId ?? null, active: true, createdAt: before?.createdAt || Date.now(), updatedAt: Date.now() };
      d.byId[k] = after;
      if (d.byId[memberId] && d.byId[memberId] !== before) delete d.byId[memberId];
      return d;
    } },
    { collection:'nick_history', update: async d => {
      d.entries ||= [];
      d.entries.push({ id:`NICK-HIST-${crypto.randomUUID()}`, action:'NICK_CHANGED', groupId, memberId, before, after, actor, reason, at:Date.now() });
      if (d.entries.length > 5000) d.entries = d.entries.slice(-5000);
      return d;
    } }
  ], { feature:'nick', action:'change', groupId, memberId });
  await recordAudit({ actor, target: memberId, action: 'NICK_CHANGED', before, after, reason });
  await emit(PlatformEvents.PROFILE_CHANGED, { type: 'nick', memberId, groupId, before, after });
  await emit(PlatformEvents.NICK_CHANGED, { memberId, groupId, before, after });
  return after;
}

export async function removeNick(memberId, { groupId = null, actor = null, reason = null } = {}) {
  if (!groupId) throw new Error('Grupo obrigatório para remover nick.');
  let before = null, after = null;
  await transactionCollections([
    { collection:'nicks', update: async d => {
      normalizeStore(d);
      const k = recordKey(groupId, memberId);
      before = d.byId[k] || findRecord(d, groupId, memberId);
      if (!before || before.active === false) throw new Error('Nick não encontrado neste grupo.');
      after = { ...before, active:false, updatedAt:Date.now() };
      d.byId[k] = after;
      if (d.byId[memberId] && d.byId[memberId].groupId === groupId) delete d.byId[memberId];
      return d;
    } },
    { collection:'nick_history', update: async d => {
      d.entries ||= [];
      d.entries.push({ id:`NICK-HIST-${crypto.randomUUID()}`, action:'NICK_REMOVED', groupId, memberId, before, after, actor, reason, at:Date.now() });
      if (d.entries.length > 5000) d.entries = d.entries.slice(-5000);
      return d;
    } }
  ], { feature:'nick', action:'remove', groupId, memberId });

  await recordAudit({ actor, target: memberId, action: 'NICK_REMOVED', before, after, reason });
  await emit(PlatformEvents.PROFILE_CHANGED, { type: 'nick', memberId, groupId, before, after });
  await emit(PlatformEvents.NICK_CHANGED, { memberId, groupId, before, after });
  return after;
}

export async function setSectionPolicy(groupId, patch) {
  let out;
  await updateCollection('nick_policies', d => {
    d.byGroup ||= {};
    out = d.byGroup[groupId] = { ...policy(groupId), ...patch };
    return d;
  }, { byGroup: {} });
  return out;
}

export function getNickForMember(groupId, memberId) {
  if (!groupId || !memberId) return null;
  const d = readCollection('nicks', { byId: {} });
  const row = findRecord(d, groupId, memberId);
  return row && row.active !== false ? row : null;
}

export function missingNicksByMemberIds(groupId, currentMemberIds = []) {
  const current = [...new Set((currentMemberIds || []).filter(Boolean).map(String))];
  if (!current.length) return [];
  const rows = listNicks(groupId);
  const identities = new Set(rows.map(x => String(x.memberId || '')).filter(Boolean));
  return current.filter(id => !identities.has(id));
}

export function missingNicks(groupId, currentIds = []) {
  const current = [...new Set((currentIds || []).filter(Boolean).map(String))];
  if (!current.length) return [];
  const rows = listNicks(groupId);
  const identities = new Set(rows.flatMap(x => [x.platformId, x.memberId].filter(Boolean).map(String)));
  return current.filter(id => !identities.has(id));
}

export default { listNicks, setNick, removeNick, setSectionPolicy, getNickForMember, missingNicksByMemberIds, missingNicks };
