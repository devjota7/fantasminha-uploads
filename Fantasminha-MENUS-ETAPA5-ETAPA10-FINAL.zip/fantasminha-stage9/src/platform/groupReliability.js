/**
 * Etapa 9 — estado operacional de conexão e grupos.
 * Mantém somente estado efêmero; não substitui a persistência do projeto.
 */
import { isGroupJid, normalizeJid } from './identity/lid.js';

const GROUP_TTL_MS = 5 * 60_000;
const PRUNE_INTERVAL_MS = 60_000;
const MAX_GROUPS = 1000;
const groups = new Map();
const metadataInflight = new Map();
let lastPruneAt = 0;

function pruneExpired(force = false) {
  const current = now();
  if (!force && current - lastPruneAt < PRUNE_INTERVAL_MS) return;
  lastPruneAt = current;
  for (const [id, entry] of groups) {
    const last = Number(entry.lastMetadataAt || entry.updatedAt || entry.firstSeenAt || 0);
    if (last && current - last > GROUP_TTL_MS * 2 && entry.state !== 'removed') groups.delete(id);
  }
}

let connection = {
  state: 'DISCONNECTED',
  generation: 0,
  connectedAt: null,
  lastChangeAt: Date.now(),
  lastDisconnectAt: null,
  lastDisconnectReason: null,
  reconnectCount: 0,
  lastGroupSyncAt: null,
  lastGroupSyncCount: 0
};

function now() { return Date.now(); }
function touch(groupId, patch = {}) {
  pruneExpired();
  const id = normalizeJid(groupId);
  if (!isGroupJid(id)) return null;
  const current = groups.get(id) || { groupId: id, state: 'unknown', firstSeenAt: now() };
  const next = { ...current, ...patch, groupId: id, updatedAt: now() };
  groups.set(id, next);
  if (groups.size > MAX_GROUPS) {
    const oldest = [...groups.values()].sort((a, b) => (a.updatedAt || 0) - (b.updatedAt || 0))[0];
    if (oldest) groups.delete(oldest.groupId);
  }
  return next;
}

export function setConnectionState(state, details = {}) {
  const nextState = String(state || 'DISCONNECTED').toUpperCase();
  const previous = connection.state;
  connection = {
    ...connection,
    state: nextState,
    lastChangeAt: now(),
    ...(nextState === 'CONNECTED' ? { connectedAt: now() } : {}),
    ...(nextState !== 'CONNECTED' && previous === 'CONNECTED' ? { lastDisconnectAt: now() } : {}),
    ...details
  };
  if (nextState === 'CONNECTED') connection.connectedAt ||= now();
  return { ...connection };
}

export function getConnectionState() {
  pruneExpired();
  return { ...connection, groupCount: groups.size };
}

export function markReconnect(generation = null) {
  connection = {
    ...connection,
    generation: generation ?? connection.generation + 1,
    reconnectCount: connection.reconnectCount + 1,
    state: 'RECONNECTING',
    lastChangeAt: now()
  };
  return getConnectionState();
}

export function clearRuntimeGroupState() {
  metadataInflight.clear();
  for (const [id, entry] of groups) {
    if (entry.state !== 'removed') groups.set(id, { ...entry, state: 'unknown', updatedAt: now() });
  }
}

export function recordGroupMetadata(groupId, metadata, source = 'metadata') {
  const id = normalizeJid(groupId || metadata?.id);
  if (!isGroupJid(id) || !metadata) return null;
  return touch(id, {
    state: 'active',
    subject: metadata.subject || '',
    participantCount: Array.isArray(metadata.participants) ? metadata.participants.length : 0,
    owner: metadata.owner || metadata.ownerJid || metadata.creator || null,
    lastMetadataAt: now(),
    source,
    metadata
  });
}

/**
 * Descarta o metadata em cache de um grupo (ex.: após promote/demote/add/remove).
 * Sem isso o bot continuava usando a lista de admins antiga por até 5 min e
 * não percebia que tinha virado ADM.
 */
export function invalidateGroupMetadata(groupId) {
  const id = normalizeJid(groupId);
  const entry = groups.get(id);
  if (!entry) return false;
  groups.set(id, { ...entry, metadata: null, lastMetadataAt: 0, updatedAt: now() });
  metadataInflight.delete(id);
  return true;
}

export function markGroupEvent(groupId, patch = {}) {
  return touch(groupId, patch);
}

export function markGroupRemoved(groupId) {
  const id = normalizeJid(groupId);
  metadataInflight.delete(id);
  return touch(id, { state: 'removed', removedAt: now() });
}

export function listKnownGroups() {
  pruneExpired();
  return [...groups.values()].map(({ metadata, ...entry }) => ({ ...entry }));
}

export async function getGroupMetadataReliable(sock, groupId, options = {}) {
  const id = normalizeJid(groupId);
  if (!isGroupJid(id)) throw new Error('ID de grupo inválido.');
  if (!sock?.groupMetadata) throw new Error('Socket indisponível.');

  const force = options.force === true;
  const cached = groups.get(id);
  if (!force && cached?.metadata && (now() - (cached.lastMetadataAt || 0) < GROUP_TTL_MS)) {
    return cached.metadata;
  }

  if (metadataInflight.has(id)) return metadataInflight.get(id);

  const promise = (async () => {
    try {
      const metadata = await sock.groupMetadata(id);
      if (!metadata) throw new Error('Metadata de grupo não retornado.');
      recordGroupMetadata(id, metadata, 'whatsapp');
      return metadata;
    } catch (error) {
      touch(id, { state: cached?.state === 'active' ? 'degraded' : 'unknown', lastMetadataErrorAt: now(), lastMetadataError: String(error?.message || error) });
      // Se o WhatsApp falhou (rate-limit, timeout), usa o último metadata conhecido
      // em vez de devolver vazio — vazio fazia o bot achar que não é ADM e ignorar o grupo.
      if (cached?.metadata) return cached.metadata;
      throw error;
    } finally {
      metadataInflight.delete(id);
    }
  })();
  metadataInflight.set(id, promise);
  return promise;
}

export async function syncParticipatingGroups(sock) {
  if (!sock?.groupFetchAllParticipating) return { ok: false, count: 0, reason: 'unsupported' };
  try {
    const all = await sock.groupFetchAllParticipating();
    const entries = Object.values(all || {});
    const seen = new Set();
    for (const meta of entries) {
      const id = normalizeJid(meta?.id);
      if (!isGroupJid(id)) continue;
      seen.add(id);
      recordGroupMetadata(id, meta, 'sync');
    }
    for (const [id, entry] of groups) {
      if (entry.state === 'active' && !seen.has(id)) touch(id, { state: 'unknown', lastSyncMissAt: now() });
    }
    connection = { ...connection, lastGroupSyncAt: now(), lastGroupSyncCount: seen.size };
    return { ok: true, count: seen.size };
  } catch (error) {
    connection = { ...connection, lastGroupSyncAt: now(), lastGroupSyncCount: 0, lastGroupSyncError: String(error?.message || error) };
    return { ok: false, count: 0, reason: String(error?.message || error) };
  }
}

export function operationalHealth(groupId = null) {
  const state = getConnectionState();
  const group = groupId ? groupHealth(groupId) : null;
  return {
    ok: state.state === 'CONNECTED',
    status: state.state === 'CONNECTED' ? 'healthy' : state.state === 'RECONNECTING' || state.state === 'CONNECTING' ? 'degraded' : 'offline',
    connection: state,
    group
  };
}

export function groupHealth(groupId) {
  const id = normalizeJid(groupId);
  const entry = groups.get(id);
  if (!entry) return { groupId: id, state: 'unknown', known: false };
  return { groupId: id, known: true, ...Object.fromEntries(Object.entries(entry).filter(([k]) => k !== 'metadata')) };
}

export default {
  setConnectionState,
  getConnectionState,
  markReconnect,
  clearRuntimeGroupState,
  recordGroupMetadata,
  markGroupEvent,
  invalidateGroupMetadata,
  markGroupRemoved,
  listKnownGroups,
  getGroupMetadataReliable,
  syncParticipatingGroups,
  groupHealth,
  operationalHealth
};
