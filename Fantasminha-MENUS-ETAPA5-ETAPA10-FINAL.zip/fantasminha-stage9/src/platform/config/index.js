import { readCollection, updateCollection } from '../../database/store.js';

const COLLECTION = 'platform_config';
const DEFAULTS = { global: {}, groups: {}, users: {}, commands: {} };
function load() {
  const d = readCollection(COLLECTION, DEFAULTS);
  return {
    global: d.global && typeof d.global === 'object' ? d.global : {},
    groups: d.groups && typeof d.groups === 'object' ? d.groups : {},
    users: d.users && typeof d.users === 'object' ? d.users : {},
    commands: d.commands && typeof d.commands === 'object' ? d.commands : {}
  };
}
function merge(...xs) { return Object.assign({}, ...xs.filter(Boolean)); }
export function getLayers() { return load(); }
export function resolveConfig({ groupId = null, userId = null, command = null } = {}) {
  const d = load();
  return merge(d.global, groupId && d.groups[groupId], userId && d.users[userId], command && d.commands[command]);
}
export async function setLayer(layer, id, patch) {
  if (!['global', 'groups', 'users', 'commands'].includes(layer)) throw new Error('Camada inválida');
  if (layer === 'global') {
    return updateCollection(COLLECTION, d => ({ ...DEFAULTS, ...d, global: merge(d.global, id || {}, patch || {}) }), DEFAULTS);
  }
  const key = String(id || '').trim();
  if (!key) throw new Error('id obrigatório');
  return updateCollection(COLLECTION, d => {
    const next = { ...DEFAULTS, ...d, [layer]: { ...(d[layer] || {}) } };
    next[layer][key] = merge(next[layer][key], patch);
    return next;
  }, DEFAULTS);
}
export default { getLayers, resolveConfig, setLayer };
