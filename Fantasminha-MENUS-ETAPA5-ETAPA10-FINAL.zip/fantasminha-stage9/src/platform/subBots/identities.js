import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const PROJECT_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../..');
const SUBBOTS_FILE = path.join(PROJECT_ROOT, 'dados', 'database', 'subbots.json');

export function getKnownSubBotJids(filePath = SUBBOTS_FILE) {
  try {
    if (!fs.existsSync(filePath)) return [];
    const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const subbots = data?.subbots && typeof data.subbots === 'object' ? Object.values(data.subbots) : [];
    return [...new Set(subbots.flatMap(bot => [bot?.phoneNumber, bot?.number, bot?.subBotLid]).filter(Boolean).map(String))];
  } catch {
    return [];
  }
}

export default { getKnownSubBotJids };
