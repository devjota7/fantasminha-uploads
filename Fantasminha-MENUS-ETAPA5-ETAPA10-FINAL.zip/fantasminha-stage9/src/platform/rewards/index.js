import crypto from 'node:crypto';
import { getUser, upsertUser, updateCollection } from '../../database/store.js';
import { mutateAccount } from '../../services/economy.js';
import { recordAudit } from '../audit/index.js';
import { emit, PlatformEvents } from '../events/index.js';
import { applyXp, ensureRpg } from '../../services/rpgService.js';

export async function grant(userId,{coins=0,xp=0,items={},reputation=0,reason='reward',source='system',name='',operationId=null}={}) {
  const normalizedCoins = Number(coins) || 0;
  const normalizedXp = Number(xp) || 0;
  const normalizedRep = Number(reputation) || 0;
  const result = { id:`RW-${crypto.randomUUID()}`, userId, coins:normalizedCoins, xp:normalizedXp, items:{...items}, reputation:normalizedRep, reason, source, at:Date.now(), operationId };
  const existing = operationId ? (await import('../../database/store.js')).readCollection('reward_ledger',{entries:[]}).entries?.find(e=>e.operationId===operationId) : null;
  if (existing) return existing;
  const accountResult = await mutateAccount(userId, ({ user, economy, account }) => {
    if (normalizedCoins > 0) account.credit(normalizedCoins);
    const inv={...(economy.inventory||{})};
    for(const [k,v] of Object.entries(result.items)) inv[k]=(inv[k]||0)+Number(v);
    economy.inventory=inv;
    const rpg=ensureRpg(user);
    if (normalizedXp > 0) applyXp(rpg, normalizedXp);
    user.rpg=rpg; user.reputation=Number(user.reputation||0)+normalizedRep;
    return { amount: normalizedCoins };
  }, {reason,operationId,name});
  if (accountResult?.duplicate) {
    const prior = (await import('../../database/store.js')).readCollection('reward_ledger',{entries:[]}).entries?.find(e=>e.operationId===operationId);
    return prior || result;
  }
  await updateCollection('reward_ledger',d=>{d.entries??=[];if(operationId&&d.entries.some(e=>e.operationId===operationId))return d;d.entries.push(result);if(d.entries.length>20000)d.entries.splice(0,d.entries.length-20000);return d;},{entries:[]});
  await recordAudit({actor:source,target:userId,action:'REWARD_GRANTED',result:'success',operationId,details:result});
  await emit(PlatformEvents.REWARD_GRANTED,result).catch(()=>{});
  return result;
}
export default {grant};
