/** Compatibilidade: o domínio RPG canônico vive em services/rpgService.js. */
export * from '../../services/rpgService.js';
import rpg from '../../services/rpgService.js';
export default rpg;
