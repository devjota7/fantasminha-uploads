import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { recordAudit } from '../audit/index.js';

const TTL = 24 * 3600_000;
const KEY_MAX = 180;
function validateKey(key) {
  const value = String(key || '').trim();
  if (!value || value.length > KEY_MAX || !/^[A-Za-z0-9_.:/-]+$/.test(value)) throw Object.assign(new Error('invalid_operation_key'), { code: 'invalid_operation_key' });
  return value;
}

export async function beginOperation({ key, actor = null, command = null, requestId = null, ttlMs = TTL } = {}) {
  const k = validateKey(key); const now = Date.now(); let created = false; let existing;
  await updateCollection('platform_operations', d => {
    d.items ||= {};
    const old = d.items[k];
    if (old && now - old.createdAt < ttlMs) { existing = old; return d; }
    const operation = { id:`OP-${crypto.randomUUID()}`, key:k, actor, command, requestId, createdAt:now, status:'running', retryCount:0 };
    d.items[k] = operation; existing = operation; created = true; return d;
  }, { items:{} });
  return { created, replay: !created && ['completed','failed'].includes(existing?.status), operation: existing };
}

export async function finishOperation(key, result = {}) {
  const k = validateKey(key); let operation;
  await updateCollection('platform_operations', d => { d.items ||= {}; operation=d.items[k]; if (operation) d.items[k]={...operation,...result,status:result.status||'completed',finishedAt:Date.now()}; return d; }, {items:{}});
  return operation;
}

export async function runIdempotent({ key, actor = null, command = null, requestId = null, handler }) {
  if (typeof handler !== 'function') throw new Error('handler obrigatório');
  const started = await beginOperation({key,actor,command,requestId});
  if (!started.created) {
    if (started.operation?.command !== command) throw Object.assign(new Error('operation_conflict'), {code:'operation_conflict'});
    if (started.replay) return {replay:true,result:started.operation.result,operation:started.operation};
    return {replay:false,inProgress:true,operation:started.operation};
  }
  try {
    const result=await handler(started.operation);
    await finishOperation(key,{status:'completed',result});
    await recordAudit({actor,action:'OPERATION_COMPLETED',operationId:started.operation.id,requestId,result:'success',details:{key,command}});
    return {replay:false,result,operation:started.operation};
  } catch(error) {
    await finishOperation(key,{status:'failed',result:{error:error.message,code:error.code||null}});
    await recordAudit({actor,action:'OPERATION_FAILED',operationId:started.operation.id,requestId,result:'error',details:{key,command,error:error.code||error.message}});
    throw error;
  }
}

export default {beginOperation,finishOperation,runIdempotent};
