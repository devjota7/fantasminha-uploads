const FIELDS = ['points', 'upvotes', 'downvotes', 'karma', 'fame'];

function safeNonNegativeInteger(value) {
  if (value === null || value === undefined || value === '') return 0;
  const numeric = Number(value);
  return Number.isSafeInteger(numeric) && numeric >= 0 ? numeric : 0;
}

export function normalizeReputation(value) {
  const source = value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  return Object.fromEntries(FIELDS.map(field => [field, safeNonNegativeInteger(source[field])]));
}

export function findExistingEconomyUser(users, orderedAliases) {
  if (!users || typeof users !== 'object' || Array.isArray(users) || !Array.isArray(orderedAliases)) return null;
  for (const candidate of orderedAliases) {
    if (typeof candidate !== 'string') continue;
    const key = candidate.trim();
    if (key && Object.hasOwn(users, key) && users[key] && typeof users[key] === 'object' && !Array.isArray(users[key])) {
      return { key, user: users[key] };
    }
  }
  return null;
}
