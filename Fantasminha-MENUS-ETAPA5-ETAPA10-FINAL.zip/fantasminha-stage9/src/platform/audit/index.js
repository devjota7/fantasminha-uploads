import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';

const SENSITIVE_KEYS = /^(?:password|passwd|secret|token|accesstoken|refreshtoken|apikey|authorization|cookie|session|csrf|totp|otp|credential|privatekey|clientsecret)$/i;
export function sanitizeAuditValue(value, depth = 0) {
  if (depth > 8) return '[truncated]';
  if (Array.isArray(value)) return value.map(item => sanitizeAuditValue(item, depth + 1));
  if (value && typeof value === 'object') {
    const out = {};
    for (const [key, item] of Object.entries(value)) out[key] = SENSITIVE_KEYS.test(key) ? '[redacted]' : sanitizeAuditValue(item, depth + 1);
    return out;
  }
  if (typeof value === 'string' && value.length > 4096) return `${value.slice(0, 4096)}…`;
  return value;
}

export async function recordAudit({ actor = null, target = null, action, scope = null, before = null, after = null, reason = null, requestId = null, operationId = null, result = 'success', details = {} } = {}) {
  if (!action) throw new Error('action obrigatório');
  const event = { id: `AUD-${crypto.randomUUID()}`, at: Date.now(), actor, target, action, scope, before: sanitizeAuditValue(before), after: sanitizeAuditValue(after), reason: sanitizeAuditValue(reason), requestId, operationId, result, details: sanitizeAuditValue(details) };
  await updateCollection('platform_audit', d => { d.events ||= []; d.events.push(event); if (d.events.length > 20000) d.events.splice(0, d.events.length - 20000); return d; }, { events: [] });
  return event;
}
export function auditStats() { const d = readCollection('platform_audit', { events: [] }); return { total: d.events.length, last: d.events.at(-1) || null }; }
export function auditFind(predicate) { return readCollection('platform_audit', { events: [] }).events.filter(predicate); }
export default { recordAudit, auditStats, auditFind };
