import { env } from '../config/env.js';
import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../database/store.js';
import { snapshot as metricsSnapshot, increment } from '../core/metrics.js';
import { checkDatabase } from '../database/store.js';
import commercial from '../services/platformCommercial.js';
import licenseService from '../services/licenseService.js';
import provisioning from '../services/provisioning/index.js';
import { recordAudit } from './audit/index.js';
import invariants from './invariants.js';

const COLLECTION='platform_ops';
const MAX_HISTORY=1000;
const id=()=>`OPS-${crypto.randomUUID()}`;
const base=()=>({version:1,operations:{},runs:{}});
const db=()=>{const d=readCollection(COLLECTION,base());return {...base(),...d,operations:d.operations||{},runs:d.runs||{}}};
function prune(d){const entries=Object.entries(d.operations).sort((a,b)=>(b[1].startedAt||0)-(a[1].startedAt||0)); for(const [k] of entries.slice(MAX_HISTORY)) delete d.operations[k];}
export async function startOperation({operation,entityType=null,entityId=null,actor='system',correlationId=null,requestId=null}={}){let out;await updateCollection(COLLECTION,d=>{const existing=Object.values(d.operations).find(x=>requestId&&x.requestId===requestId&&x.operation===operation&&x.entityId===entityId);if(existing){out=existing;return d;}out={operationId:id(),operation,entityType,entityId,actor,correlationId:correlationId||id(),requestId,status:'running',startedAt:Date.now(),finishedAt:null,durationMs:null,errorCode:null};d.operations[out.operationId]=out;prune(d);return d},base());return out;}
export async function finishOperation(operationId,{status='success',errorCode=null}={}){let out;await updateCollection(COLLECTION,d=>{const x=d.operations[operationId];if(!x){out=null;return d;}out={...x,status,finishedAt:Date.now(),durationMs:Date.now()-x.startedAt,errorCode};d.operations[operationId]=out;return d},base());return out;}
export function listOperations({limit=50,status=null,operation=null,entityId=null}={}){const d=db();let a=Object.values(d.operations);if(status)a=a.filter(x=>x.status===status);if(operation)a=a.filter(x=>x.operation===operation);if(entityId)a=a.filter(x=>x.entityId===entityId);return a.sort((x,y)=>y.startedAt-x.startedAt).slice(0,Math.min(200,Math.max(1,Number(limit)||50)));}
export function diagnostics(){const commercialCheck=commercial.commercialLifecycleIntegrity();
  const invariantCheck=invariants.commercialInvariants();const prov=provisioning.provisioningIntegrity();let provider={available:false,provider:'unavailable',reason:'unknown'};try{provider={available:provisioning.provisioningProvider.configured,provider:provisioning.provisioningProvider.name,reason:provisioning.provisioningProvider.configured?'configured':'no_provider_configured'}}catch{}return {generatedAt:new Date().toISOString(),application:{ok:true,uptimeSeconds:Math.floor(process.uptime()),version:env.BOT_VERSION||null},persistence:{ok:!!checkDatabase()},payments:{status:'unknown'},provisioning:{provider,integrity:prov},commercial:{integrity:commercialCheck,invariants:invariantCheck},operations:{pending:listOperations({status:'running'}),failed:listOperations({status:'failed',limit:20})},metrics:metricsSnapshot()};}
export async function reconcile({scope='all',dryRun=false,actor='owner'}={}){const result={scope,dryRun,generatedAt:new Date().toISOString(),commercial:null,provisioning:null,actions:[]};if(scope==='commercial'||scope==='all'){const check=commercial.commercialLifecycleIntegrity();result.commercial=check;if(check.issues.length)result.actions.push(...check.issues.map(i=>({type:'commercial_issue',issue:i,action:'manual_review'})));}
if(scope==='provisioning'||scope==='all'){result.provisioning=await provisioning.reconcileProvisioning();}
if(!dryRun && result.commercial?.ok===false){/* severe inconsistencies remain diagnostic-only */}
const runId=id();await updateCollection(COLLECTION,d=>{d.runs[runId]={runId,scope,dryRun,actor,startedAt:Date.now(),finishedAt:Date.now(),result};return d},base());increment('ops.reconcile');await recordAudit({actor,action:'OPS_RECONCILE',result:'success',details:{scope,dryRun,issues:(result.commercial?.issues||[]).length}});return result;}
export default {startOperation,finishOperation,listOperations,diagnostics,reconcile};
