import { readCollection, updateCollection } from '../../database/store.js';

const COLLECTION = 'feature_flags';
const defaults = {
  'platform.identity': true,
  'platform.audit': true,
  'platform.operations': true,
  'platform.transactions': true,
  'platform.jobs': true,
  'platform.personal': true,
  'platform.migrations': true,
  'platform.integrity': true,
  'platform.search': true
};
function load() {
  const d = readCollection(COLLECTION, defaults);
  return { ...defaults, ...(d && typeof d === 'object' ? d : {}) };
}
export function featureEnabled(name, fallback = false) { const v = load()[name]; return v === undefined ? fallback : !!v; }
export function getFeatureFlags() { return load(); }
export async function setFeatureFlag(name, value) {
  const key = String(name);
  const next = await updateCollection(COLLECTION, flags => ({ ...defaults, ...(flags || {}), [key]: !!value }), defaults);
  return !!next[key];
}
export default { featureEnabled, getFeatureFlags, setFeatureFlag };
