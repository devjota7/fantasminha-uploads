/**
 * Persistência JSON robusta para Termux.
 * - escrita atômica
 * - lock por coleção em memória
 * - lock entre processos via mkdir exclusivo
 * - recuperação de lock antigo
 * - API compatível com a V2 atual
 *
 * Mantemos JSON nesta versão para não exigir módulo nativo no Android.
 * A camada fica isolada para futura migração transparente para SQLite.
 */
import fs from 'fs';
import path from 'path';
import config from '../core/config.js';
import logger from '../core/logger.js';

export const DB_ROOT = path.resolve(process.env.FANTASMINHA_DB_ROOT || path.join(config.root, 'data', 'db'));
const LOCK_ROOT = path.join(DB_ROOT, '.locks');
const locks = new Map();
const activeOperations = new Set();
const LOCK_STALE_MS = 120_000;
const LOCK_WAIT_MS = 25;
const LOCK_TIMEOUT_MS = 30_000;
const CORRUPT_DIR = path.join(DB_ROOT, '.corrupt');
const TX_JOURNAL = path.join(DB_ROOT, '.transaction-journal.json');
const TX_BACKUP_DIR = path.join(DB_ROOT, '.transaction-backups');

function clone(value) { return value == null ? value : structuredClone(value); }
function fsyncDirectory(dir = DB_ROOT) {
  try {
    const dirFd = fs.openSync(dir, 'r');
    try { fs.fsyncSync(dirFd); } finally { fs.closeSync(dirFd); }
    return true;
  } catch { return false; }
}

function writeDurableFile(file, content) {
  const fd = fs.openSync(file, 'w');
  try { fs.writeFileSync(fd, content, 'utf8'); fs.fsyncSync(fd); }
  finally { fs.closeSync(fd); }
}

function durableRename(source, target) {
  fs.renameSync(source, target);
  fsyncDirectory(path.dirname(target));
}

function recoverInterruptedTransaction() {
  if (!fs.existsSync(TX_JOURNAL)) return;
  let cleanupAllowed = false;
  try {
    const journal = JSON.parse(fs.readFileSync(TX_JOURNAL, 'utf8'));
    if (!journal?.id || !Array.isArray(journal.items)) throw new Error('Journal de transação inválido');
    if (journal.status === 'committed') {
      cleanupAllowed = true;
    } else if (journal.status === 'prepared') {
      for (const item of journal.items) {
        if (item.backup && fs.existsSync(item.backup)) {
          fs.copyFileSync(item.backup, item.target);
          const fd = fs.openSync(item.target, 'r');
          try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
        } else if (item.hadOriginal === false) {
          fs.rmSync(item.target, { force: true });
        } else {
          throw new Error(`Backup ausente para ${item.collection}`);
        }
      }
      fsyncDirectory(DB_ROOT);
      cleanupAllowed = true;
    } else {
      throw new Error(`Status de journal desconhecido: ${journal.status}`);
    }
  } catch (e) {
    logger.db('transaction-recovery-failed', e?.message || String(e));
    const stamp = Date.now();
    try { fs.renameSync(TX_JOURNAL, `${TX_JOURNAL}.failed.${stamp}`); fsyncDirectory(DB_ROOT); } catch {}
    try { if (fs.existsSync(TX_BACKUP_DIR)) fs.renameSync(TX_BACKUP_DIR, `${TX_BACKUP_DIR}.failed.${stamp}`); fsyncDirectory(DB_ROOT); } catch {}
    return;
  }
  if (cleanupAllowed) {
    try { fs.rmSync(TX_JOURNAL, { force: true }); } catch {}
    try { fs.rmSync(TX_BACKUP_DIR, { recursive: true, force: true }); } catch {}
    fsyncDirectory(DB_ROOT);
  }
}
function ensure() { fs.mkdirSync(DB_ROOT, { recursive: true }); fs.mkdirSync(LOCK_ROOT, { recursive: true }); }
ensure();
recoverInterruptedTransaction();
function safeName(collection) { const name = String(collection || '').replace(/[^a-zA-Z0-9_.-]/g, '_'); if (!name) throw new Error('Coleção inválida'); return name; }
function fileFor(collection) { return path.join(DB_ROOT, `${safeName(collection)}.json`); }
function lockFor(collection) { return path.join(LOCK_ROOT, `${safeName(collection)}.lock`); }

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

function trackOperation(promise) {
  activeOperations.add(promise);
  promise.finally(() => activeOperations.delete(promise)).catch(() => {});
  return promise;
}

export async function drain(timeoutMs = 30_000) {
  const deadline = Date.now() + Math.max(0, Number(timeoutMs) || 0);
  while (activeOperations.size) {
    const pending = [...activeOperations];
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new Error(`Timeout drenando persistência (${activeOperations.size} operações ativas)`);
    await Promise.race([Promise.allSettled(pending), sleep(Math.min(remaining, 50))]);
  }
  return true;
}

async function acquireProcessLock(collection) {
  ensure();
  const lock = lockFor(collection);
  const started = Date.now();
  while (true) {
    try {
      fs.mkdirSync(lock);
      fs.writeFileSync(path.join(lock, 'owner.json'), JSON.stringify({ pid: process.pid, at: Date.now() }));
      return () => { try { fs.rmSync(lock, { recursive: true, force: true }); } catch {} };
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      try {
        const ownerFile = path.join(lock, 'owner.json');
        let ownerPid = 0;
        try { ownerPid = Number(JSON.parse(fs.readFileSync(ownerFile, 'utf8')).pid || 0); } catch {}
        let ownerAlive = true;
        if (ownerPid > 0) { try { process.kill(ownerPid, 0); } catch (err) { ownerAlive = err.code === 'EPERM'; } }
        const st = fs.statSync(lock);
        if (!ownerAlive || Date.now() - st.mtimeMs > LOCK_STALE_MS) fs.rmSync(lock, { recursive: true, force: true });
      } catch {}
      if (Date.now() - started > LOCK_TIMEOUT_MS) throw new Error(`Timeout de lock da coleção ${collection}`);
      await sleep(LOCK_WAIT_MS);
    }
  }
}

async function withLock(collection, fn) {
  return trackOperation(withLockInternal(collection, fn));
}

async function withLockInternal(collection, fn) {
  const prev = locks.get(collection) || Promise.resolve();
  let releaseMemory;
  const next = new Promise(r => { releaseMemory = r; });
  const chain = prev.then(() => next);
  locks.set(collection, chain);
  await prev;
  let releaseFile;
  try {
    releaseFile = await acquireProcessLock(collection);
    return await fn();
  } finally {
    try { releaseFile?.(); } catch {}
    releaseMemory();
    if (locks.get(collection) === chain) locks.delete(collection);
  }
}

function reportCorruptFile(collection, error) {
  logger.db('corrupt', error?.message || 'invalid collection', { collection });
}

export function readCollection(collection, fallback = {}) {
  ensure();
  const f = fileFor(collection);
  try {
    if (!fs.existsSync(f)) return clone(fallback);
    const parsed = JSON.parse(fs.readFileSync(f, 'utf8'));
    return parsed ?? clone(fallback);
  } catch (e) {
    reportCorruptFile(collection, e);
    try {
      fs.mkdirSync(CORRUPT_DIR, { recursive: true });
      const quarantined = path.join(CORRUPT_DIR, `${safeName(collection)}.${Date.now()}.json`);
      fs.renameSync(f, quarantined);
    } catch {}
    // Corrupção isolada não deve derrubar o bot inteiro: preservamos o arquivo
    // original em quarentena e devolvemos o fallback solicitado.
    return clone(fallback);
  }
}

function writeCollectionRaw(collection, data) {
  ensure();
  if (data === undefined) throw new Error(`Não é permitido persistir undefined em ${collection}`);
  const f = fileFor(collection);
  const tmp = `${f}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
  const json = JSON.stringify(data, null, 2);
  if (json === undefined) throw new Error(`Dados não serializáveis em ${collection}`);
  try {
    writeDurableFile(tmp, json);
    durableRename(tmp, f);
  } finally {
    try { fs.rmSync(tmp, { force: true }); } catch {}
  }
}

// API síncrona legada: escrita atômica/durável. Para read-modify-write use
// updateCollection(), que adiciona lock por coleção.
export function writeCollection(collection, data) {
  writeCollectionRaw(collection, data);
}

export async function withCollectionLocks(collections, fn) {
  const names = [...new Set((collections || []).map(safeName))].sort();
  const releases = [];
  const enter = async i => {
    if (i >= names.length) return fn();
    return withLock(names[i], async () => enter(i + 1));
  };
  return enter(0);
}

export async function transactionCollections(steps = [], meta = {}) {
  if (!Array.isArray(steps) || !steps.length) throw new Error('Transação sem etapas');
  const collections = [...new Set(steps.map(s => s?.collection).filter(Boolean))];
  if (collections.length !== steps.length) throw new Error('Cada etapa deve apontar para uma coleção única');
  for (const step of steps) {
    if (!step?.collection || typeof step.update !== 'function') throw new Error('Etapa de transação inválida');
  }
  if (!steps.some(step => step.readOnly !== true)) throw new Error('Transação precisa de ao menos uma etapa de escrita');
  return withCollectionLocks(collections, async () => {
    const before = new Map();
    const next = new Map();
    for (const step of steps) {
      const current = readCollection(step.collection, step.fallback ?? {});
      if (step.readOnly !== true) before.set(step.collection, clone(current));
      const updated = await step.update(clone(current));
      if (updated === undefined) throw new Error(`Etapa não retornou estado: ${step.collection}`);
      if (step.readOnly !== true) next.set(step.collection, updated);
    }
    const staged = [];
    const txId = `TX-${Date.now()}-${process.pid}-${Math.random().toString(36).slice(2, 8)}`;
    const txBackupDir = path.join(TX_BACKUP_DIR, txId);
    const journal = { id: txId, status: 'prepared', items: [], backups: [] };
    try {
      fs.mkdirSync(txBackupDir, { recursive: true });
      for (const [collection] of next) {
        const target = fileFor(collection);
        const backup = path.join(txBackupDir, `${safeName(collection)}.bak`);
        const hadOriginal = fs.existsSync(target);
        if (hadOriginal) {
          fs.copyFileSync(target, backup);
          const backupFd = fs.openSync(backup, 'r');
          try { fs.fsyncSync(backupFd); } finally { fs.closeSync(backupFd); }
        }
        journal.items.push({ collection, target, backup, hadOriginal });
        journal.backups.push(backup);
      }
      const journalTmp = `${TX_JOURNAL}.${process.pid}.tmp`;
      writeDurableFile(journalTmp, JSON.stringify(journal, null, 2));
      durableRename(journalTmp, TX_JOURNAL);
      for (const [collection, data] of next) {
        const tmp = path.join(DB_ROOT, `.${safeName(collection)}.${txId}.stage`);
        const fd = fs.openSync(tmp, 'w');
        try { fs.writeFileSync(fd, JSON.stringify(data, null, 2), 'utf8'); fs.fsyncSync(fd); }
        finally { fs.closeSync(fd); }
        staged.push([collection, tmp]);
      }
      for (const [collection, tmp] of staged) {
        durableRename(tmp, fileFor(collection));
      }
      journal.status = 'committed';
      const commitJournalTmp = `${TX_JOURNAL}.${process.pid}.tmp`;
      writeDurableFile(commitJournalTmp, JSON.stringify(journal, null, 2));
      durableRename(commitJournalTmp, TX_JOURNAL);
      for (const [, tmp] of staged) { try { fs.rmSync(tmp, { force: true }); } catch {} }
      try { fs.rmSync(txBackupDir, { recursive: true, force: true }); } catch {}
      try { fs.rmSync(TX_JOURNAL, { force: true }); } catch {}
      fsyncDirectory(DB_ROOT);
      return { id: txId, status: 'committed', collections: collections.map(safeName), meta };
    } catch (error) {
      let rollbackOk = true;
      for (const [collection, data] of before) {
        try { writeCollectionRaw(collection, data); } catch { rollbackOk = false; }
      }
      for (const [, tmp] of staged) { try { fs.rmSync(tmp, { force: true }); } catch { rollbackOk = false; } }
      if (rollbackOk) {
        try { fs.rmSync(txBackupDir, { recursive: true, force: true }); } catch { rollbackOk = false; }
        try { fs.rmSync(TX_JOURNAL, { force: true }); } catch { rollbackOk = false; }
        fsyncDirectory(DB_ROOT);
      } else {
        logger.db('transaction-rollback-incomplete', error?.message || String(error), { txId });
      }
      throw error;
    }
  });
}

export async function updateCollection(collection, updater, fallback = {}) {
  return withLock(collection, async () => {
    const cur = readCollection(collection, fallback);
    const next = (await updater(cur)) ?? cur;
    writeCollectionRaw(collection, next);
    return next;
  });
}

export function getUser(userId) {
  if (!userId) return null;
  const users = readCollection('users', { byId: {} });
  return users.byId?.[userId] || null;
}

export async function upsertUser(userId, patch = {}) {
  if (!userId) throw new Error('userId obrigatório');
  return updateCollection('users', users => {
    if (!users.byId) users.byId = {};
    const prev = users.byId[userId] || {
      id: userId, name: '', createdAt: Date.now(),
      economy: { wallet: 0, bank: 0, lastDaily: 0, lastWeekly: 0, lastWork: 0, inventory: {} },
      rpg: { class: null, level: 1, xp: 0, hp: 100, maxHp: 100 },
      premium: { active: false, until: 0, plan: null }, warns: 0
    };
    users.byId[userId] = { ...prev, ...patch,
      economy: { ...prev.economy, ...(patch.economy || {}) },
      rpg: { ...prev.rpg, ...(patch.rpg || {}) },
      premium: { ...prev.premium, ...(patch.premium || {}) }, updatedAt: Date.now() };
    return users;
  }, { byId: {} });
}

export function metaGet() { return readCollection('_meta', { version: 0 }); }
export async function metaSet(patch) { return updateCollection('_meta', cur => ({ ...cur, ...patch }), { version: 0 }); }

export function checkDatabase() {
  try {
    ensure();
    const probe = path.join(DB_ROOT, `.health-${process.pid}.tmp`);
    fs.writeFileSync(probe, 'ok'); fs.rmSync(probe, { force: true });
    readCollection('_meta', { version: 0 });
    return true;
  } catch (e) {
    logger.db('health', e.message);
    return false;
  }
}

export default { readCollection, writeCollection, updateCollection, withCollectionLocks, transactionCollections, drain, getUser, upsertUser, metaGet, metaSet, checkDatabase, DB_ROOT };
