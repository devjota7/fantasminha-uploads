/** Repository genérico: persistência somente, sem mensagens, WhatsApp ou permissões. */
import { readCollection, updateCollection, writeCollection } from '../store.js';

export function createCollectionRepository(collection, fallback = {}) {
  if (!collection) throw new TypeError('collection obrigatória');
  return Object.freeze({
    collection,
    read: () => readCollection(collection, fallback),
    write: data => writeCollection(collection, data),
    update: updater => updateCollection(collection, updater, fallback)
  });
}
export default { createCollectionRepository };
