import { createCollectionRepository } from './collectionRepository.js';
const repository = createCollectionRepository('groups', { byId: {} });
export function findById(groupId) { return groupId ? repository.read().byId?.[groupId] || null : null; }
export const read = () => repository.read();
export const update = updater => repository.update(updater);
export default { findById, read, update };
