import { createCollectionRepository } from './collectionRepository.js';
const repository = createCollectionRepository('profiles', { byId: {} });
export function findById(userId) { return userId ? repository.read().byId?.[userId] || null : null; }
export const read = () => repository.read();
export const update = updater => repository.update(updater);
export default { findById, read, update };
