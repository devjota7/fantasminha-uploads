import { createCollectionRepository } from './collectionRepository.js';
import { getUser, upsertUser } from '../store.js';
const repository = createCollectionRepository('users', { byId: {} });
export { getUser, upsertUser };
export const read = () => repository.read();
export const update = updater => repository.update(updater);
export default { getUser, upsertUser, read, update };
