import { createCollectionRepository } from './collectionRepository.js';

const repository = createCollectionRepository('group_rooms', { byId: {} });

export function findByGroupId(groupId) {
  if (!groupId) return null;
  return repository.read().byId?.[groupId] || null;
}
export const read = () => repository.read();
export const update = updater => repository.update(updater);
export async function save(groupId, room) {
  if (!groupId || !room || typeof room !== 'object') throw new Error('Group room inválida.');
  let result;
  await repository.update(current => {
    current.byId ||= {};
    result = current.byId[groupId] = room;
    return current;
  });
  return result;
}
export async function remove(groupId) {
  if (!groupId) return false;
  let removed = false;
  await repository.update(current => {
    current.byId ||= {};
    if (current.byId[groupId]) { delete current.byId[groupId]; removed = true; }
    return current;
  });
  return removed;
}
export default { findByGroupId, read, update, save, remove };
