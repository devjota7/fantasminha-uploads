import fs from 'node:fs';
import path from 'node:path';
import { metaGet, metaSet, readCollection, writeCollection } from './store.js';
import config from '../core/config.js';
import { fantasminhaId } from '../platform/identity/index.js';
import logger from '../core/logger.js';

const migrations = [
  {
    version: 1,
    name: 'init_collections',
    up() {
      if (!readCollection('users', null)) writeCollection('users', { byId: {} });
      writeCollection('users', readCollection('users', { byId: {} }));
      writeCollection('groups', readCollection('groups', { byId: {} }));
      writeCollection('economy_ledger', readCollection('economy_ledger', { entries: [] }));
      writeCollection('clans', readCollection('clans', { byId: {} }));
    }
  },
  {
    version: 2,
    name: 'indexes_meta',
    up() {
      writeCollection('_indexes', readCollection('_indexes', {
        richTop: [],
        xpTop: []
      }));
    }
  },
  {
    version: 3,
    name: 'premium_and_rate',
    up() {
      writeCollection('premium_plans', {
        bronze: { price: 0, days: 7, benefits: { cooldownMult: 0.8 } },
        prata: { price: 0, days: 30, benefits: { cooldownMult: 0.5, dailyBonus: 500 } },
        ouro: { price: 0, days: 30, benefits: { cooldownMult: 0.3, dailyBonus: 1500 } }
      });
    }
  },
  {
    version: 4,
    name: 'fantasminha_world_clans_wars',
    up() {
      const old = readCollection('clans', { byId: {} });
      const current = readCollection('global_clans', { byId: {}, byMember: {} });
      current.byId ||= {}; current.byMember ||= {};
      for (const c of Object.values(old.byId || {})) {
        if (current.byId[c.id]) continue;
        const migrated = { ...c, type: 'global', members: [...new Set(c.members || [])], updatedAt: Date.now() };
        current.byId[c.id] = migrated;
        for (const member of migrated.members) current.byMember[member] = migrated.id;
      }
      writeCollection('global_clans', current);
      writeCollection('group_clans', readCollection('group_clans', { byId: {} }));
      writeCollection('wars', readCollection('wars', { byId: {}, history: [] }));
    }
  },

  {
    version: 5,
    name: 'core_platform_v6',
    up() {
      writeCollection('platform_audit', readCollection('platform_audit', { events: [] }));
      writeCollection('platform_operations', readCollection('platform_operations', { byKey: {} }));
    }
  },
  {
    version: 6,
    name: 'member_rpg_economy_platform_v7',
    up() {
      writeCollection('members', readCollection('members', { byId: {} }));
      writeCollection('nicks', readCollection('nicks', { byId: {} }));
      writeCollection('nick_policies', readCollection('nick_policies', { byGroup: {} }));
      writeCollection('birthdays', readCollection('birthdays', { byId: {} }));
      writeCollection('preferences', readCollection('preferences', { byUser: {} }));
      writeCollection('reward_ledger', readCollection('reward_ledger', { entries: [] }));
      writeCollection('views', readCollection('views', { byGroup: {} }));
      writeCollection('platform_migrations', readCollection('platform_migrations', { used: {} }));
    }
  },
  {
    version: 7,
    name: 'v7_hardening_and_indexes',
    up() {
      writeCollection('nick_history', readCollection('nick_history', { entries: [] }));
      writeCollection('birthday_history', readCollection('birthday_history', { entries: [] }));
      writeCollection('platform_metrics', readCollection('platform_metrics', { counters: {} }));
      writeCollection('platform_search', readCollection('platform_search', { version: 1 }));
      writeCollection('platform_feature_audit', readCollection('platform_feature_audit', { events: [] }));
    }
  },
  {
    version: 9,
    name: 'remove_legacy_clans_wars',
    up() {
      // Clãs/guerras foram removidos da 2.0 para uma futura reconstrução.
      // Apaga os dados legados para impedir que o sistema reapareça por resíduos.
      for (const collection of ['clans', 'global_clans', 'group_clans', 'wars']) {
        try {
          const file = path.join(config.root, 'data', 'db', `${collection}.json`);
          if (fs.existsSync(file)) fs.rmSync(file, { force: true });
        } catch (e) {
          logger.warn({ err: e, collection }, 'Falha ao remover coleção legada de clãs/guerras');
        }
      }
      const users = readCollection('users', { byId: {} });
      let changed = false;
      for (const user of Object.values(users.byId || {})) {
        if (user && Object.prototype.hasOwnProperty.call(user, 'clan')) { delete user.clan; changed = true; }
      }
      if (changed) writeCollection('users', users);
    }
  },
  {
    version: 8,
    name: 'nick_birthday_group_scope',
    up() {
      const scoped = (collection) => {
        const d = readCollection(collection, { byId: {} });
        const out = { byId: {} };
        for (const [key, row] of Object.entries(d.byId || {})) {
          if (!row || typeof row !== 'object') continue;
          const groupId = row.groupId || null;
          const memberId = row.memberId || (key.startsWith('FNT-') ? key : null);
          if (!groupId || !memberId) { out.byId[key] = row; continue; }
          out.byId[`${groupId}::${memberId}`] = row;
        }
        writeCollection(collection, out);
      };
      scoped('nicks');
      scoped('birthdays');

      // Importa o formato antigo de aniversários somente uma vez. O comando
      // legado já não grava esses arquivos; o novo serviço passa a ser a fonte
      // única de verdade. LIDs podem permanecer internamente até serem
      // resolvidos pelo contexto do grupo, mas jamais são exibidos diretamente.
      const legacyDir = path.join(config.root, 'dados', 'database', 'grupos');
      const birthdays = readCollection('birthdays', { byId: {} });
      const history = readCollection('birthday_history', { entries: [] });
      birthdays.byId ||= {}; history.entries ||= [];
      if (fs.existsSync(legacyDir)) {
        for (const file of fs.readdirSync(legacyDir)) {
          if (!file.endsWith('_aniversarios.json')) continue;
          const groupId = file.slice(0, -'_aniversarios.json'.length);
          if (!groupId) continue;
          try {
            const legacy = JSON.parse(fs.readFileSync(path.join(legacyDir, file), 'utf8'));
            for (const [platformId, value] of Object.entries(legacy || {})) {
              const day = Number(value?.dia), month = Number(value?.mes);
              if (!Number.isInteger(day) || !Number.isInteger(month) || month < 1 || month > 12 || day < 1 || day > 31) continue;
              const memberId = fantasminhaId(platformId);
              const k = `${groupId}::${memberId}`;
              if (birthdays.byId[k]) continue;
              const row = { id:`BD-MIGRATED-${memberId}-${month}-${day}`, memberId, platformId:String(platformId), groupId, day, month, year:null, active:true, createdAt:Date.now(), updatedAt:Date.now(), migratedFrom:'legacy_group_birthday' };
              birthdays.byId[k] = row;
              history.entries.push({ id:`BIRTHDAY-HIST-MIGRATED-${memberId}-${Date.now()}`, action:'BIRTHDAY_MIGRATED', groupId, memberId, before:null, after:row, actor:'system', reason:'legacy_group_birthday_import', at:Date.now() });
            }
          } catch (error) { logger.warn('migrate', `falha ao importar ${file}: ${error?.message || error}`); }
        }
      }
      if (history.entries.length > 5000) history.entries = history.entries.slice(-5000);
      writeCollection('birthdays', birthdays);
      writeCollection('birthday_history', history);
    }
  },
  {
    version: 10,
    name: 'repair_nick_birthday_group_scope_after_ordering_gap',
    up() {
      // A versão 8 ficou historicamente depois da 9. Reexecute-a por meio
      // do mesmo código idempotente para instalações que já gravaram v9.
      migrations.find(m => m.version === 8)?.up();
    }
  },

];

export async function runMigrations() {
  const meta = metaGet();
  let v = meta.version || 0;
  for (const m of migrations) {
    if (m.version <= v) continue;
    logger.db('migrate', `v${m.version} ${m.name}`);
    m.up();
    v = m.version;
    await metaSet({ version: v, lastMigration: m.name, at: Date.now() });
  }
  return v;
}

export default { runMigrations };
