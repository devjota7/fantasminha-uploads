/** Transações arquiteturais sobre o mecanismo JSON já validado. */
export { transactionCollections, withCollectionLocks } from '../store.js';
import store from '../store.js';
export default { transactionCollections: store.transactionCollections, withCollectionLocks: store.withCollectionLocks };
