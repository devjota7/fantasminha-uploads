import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import * as economy from '../../services/economy.js';

const CARDS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];
const valueOf = cards => {
  let total = 0, aces = 0;
  for (const card of cards) {
    if (card === 'A') { total += 11; aces++; }
    else total += ['J', 'Q', 'K'].includes(card) ? 10 : Number(card);
  }
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
};
const draw = (random = Math.random) => CARDS[Math.floor(random() * CARDS.length)];

export function playBlackjack({ bet, random = Math.random } = {}) {
  const player = [draw(random), draw(random)];
  const dealer = [draw(random), draw(random)];
  while (valueOf(player) < 17) player.push(draw(random));
  while (valueOf(dealer) < 17) dealer.push(draw(random));
  const playerValue = valueOf(player), dealerValue = valueOf(dealer);
  let delta;
  if (playerValue > 21) delta = -bet;
  else if (dealerValue > 21 || playerValue > dealerValue) {
    const winnings = playerValue === 21 && player.length === 2 ? Math.floor(bet * 1.8) : Math.floor(bet * 1.4);
    delta = winnings - bet;
  } else if (playerValue === dealerValue) delta = -Math.floor(bet * 0.3);
  else delta = -bet;
  return { player, dealer, playerValue, dealerValue, delta };
}

const tag = text => `👻 FANTASMINHA\n\n${text}`;

export async function register() {
  registerCommand({
    name: 'blackjack', aliases: ['bj', '21'], category: 'jogos', plugin: 'blackjack',
    permission: Role.USER, groupOnly: true, cooldown: 10,
    description: 'Joga blackjack com Ghostcoins.', usage: 'blackjack <valor>',
    handler: async ctx => {
      const bet = economy.assertAmount(ctx.args?.[0] ?? ctx.q);
      const balance = await economy.getBalance(ctx.sender);
      if (bet > balance.wallet) throw new ValidationError('Saldo insuficiente.');
      const result = playBlackjack({ bet });
      const operationId = `blackjack:${ctx.sender}:${Date.now()}:${Math.random().toString(36).slice(2)}`;
      if (result.delta > 0) await economy.credit(ctx.sender, result.delta, 'blackjack_win', ctx.pushname, operationId);
      else if (result.delta < 0) await economy.debit(ctx.sender, -result.delta, 'blackjack_loss', ctx.pushname, operationId);
      const outcome = result.delta > 0 ? `🏆 Vitória! +${result.delta.toLocaleString('pt-BR')} GC` : result.delta < 0 ? `💀 Derrota. ${result.delta.toLocaleString('pt-BR')} GC` : '🤝 Empate.';
      return ctx.reply(tag(`🃏 *BLACKJACK*\n\n👤 Você: ${result.player.join(' ')} = ${result.playerValue}\n🎰 Dealer: ${result.dealer.join(' ')} = ${result.dealerValue}\n\n${outcome}`));
    }
  });
}

export default { register };
