import { registerCommand } from '../../core/registry.js';
import { Role, configuredOwner } from '../../core/permissions.js';
import { handleSuporte, handleChamados, handleFechar } from '../../../dados/src/utils/suporte.js';

export function legacySupportContext(ctx) {
  return {
    sock: ctx.sock || ctx.socket,
    info: ctx.message || ctx.info || { key: { remoteJid: ctx.from } },
    from: ctx.from,
    sender: ctx.sender,
    isGroup: Boolean(ctx.isGroup),
    args: Array.isArray(ctx.args) ? ctx.args : String(ctx.q || '').trim().split(/\s+/).filter(Boolean),
    pushName: ctx.pushname || ctx.pushName || ctx.message?.pushName,
    // O registry também reconhece o dono pela configuração; o adaptador legado
    // precisa preservar a mesma decisão para não negar o acesso depois da autorização.
    isOwner: Boolean(ctx.isOwner || configuredOwner(ctx.sender))
  };
}

export async function register() {
  registerCommand({ name:'suporte', aliases:['ticketsuporte','ajuda-suporte'], category:'suporte', plugin:'support', permission:Role.USER, cooldown:2, description:'Abre um chamado de suporte ou mostra o contato oficial.', usage:'×suporte [motivo]', handler:ctx=>handleSuporte(legacySupportContext(ctx)) });
  registerCommand({ name:'chamados', aliases:['listachamados'], category:'dono', plugin:'support', permission:Role.OWNER, ownerOnly:true, privateOnly:true, cooldown:0, description:'Lista chamados de suporte abertos.', handler:ctx=>handleChamados(legacySupportContext(ctx)) });
  registerCommand({ name:'fecharchamado', aliases:['fechar','fechar-ticket'], category:'dono', plugin:'support', permission:Role.OWNER, ownerOnly:true, privateOnly:true, cooldown:0, description:'Fecha um chamado pelo ID.', usage:'×fecharchamado <id>', handler:ctx=>handleFechar(legacySupportContext(ctx)) });
}
export default { register };
