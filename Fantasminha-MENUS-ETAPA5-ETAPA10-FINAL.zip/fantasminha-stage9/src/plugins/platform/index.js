import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fantasminhaId } from '../../platform/identity/index.js';
import { getPersonal, updatePersonal, setCustom, isVip } from '../../platform/personal/index.js';
import { snapshot as metricsSnapshot } from '../../core/metrics.js';
import { registryStats } from '../../core/registry.js';
import socialProfileService from '../../services/socialProfileService.js';
import licenseService from '../../services/licenseService.js';

const tag = s => `👻 *FANTASMINHA 10.3.0*\n\n${s}`;

/**
 * Comandos exclusivos da camada Platform.
 * Diagnóstico, snapshots, auditoria e migrações ficam no Owner Power,
 * evitando duas fontes de verdade para a mesma operação.
 */
export async function register() {
  const defs = [
    { name:'botstats', aliases:['estatisticasbot','statsbot'], category:'sistema', permission:Role.USER, cooldown:3, description:'Estatísticas e atividade do Fantasminha.', handler: async ctx => { const social=socialProfileService.snapshot(); const rows=social.ranking||[]; const metrics=metricsSnapshot(); const registry=registryStats(); const fmt=n=>Number(n||0).toLocaleString('pt-BR'); const mention=id=>`@${String(id).split('@')[0]}`; const top=rows.slice(0,5).map((x,i)=>`${i+1}. ${mention(x[0])} — ${fmt(x[1])}`).join('\n')||'Sem dados de atividade.'; return ctx.reply(tag(`📊 *ESTATÍSTICAS DO BOT*\n\n👑 Mais ativo: ${rows[0]?mention(rows[0][0]):'—'} — ${rows[0]?fmt(rows[0][1]):0}\n⚡ Hoje: ${fmt(social.today)}\n📜 Histórico: ${fmt(social.total)}\n🧩 Comandos: ${registry.total} · aliases: ${registry.aliases}\n⏱️ Uptime: ${Math.floor(metrics.uptimeMs/3600000)}h\n\n🔥 *TOP 5*\n${top}`), {mentions:rows.slice(0,5).map(x=>x[0])}); } },
    { name:'statuslicenca', aliases:['statusmega','statusmega701','licencastatus'], category:'plataforma', permission:Role.USER, cooldown:3, description:'Consulta o status da licença deste grupo.', groupOnly:true, handler: async ctx => { const l=licenseService.status(ctx.from); if(!l) return ctx.reply(tag('🪪 *STATUS DA LICENÇA*\n\n❌ Nenhuma licença registrada para este grupo.')); const date=v=>v?new Date(v).toLocaleDateString('pt-BR'):'sem expiração'; return ctx.reply(tag(`🪪 *STATUS DA LICENÇA*\n\n🆔 ${l.licenseId}\n📦 ${l.plan}\n🔵 Estado: ${l.state}\n📅 Emitida: ${date(l.issuedAt)}\n⏳ Expira: ${date(l.expiresAt)}\n🔐 Recursos: ${l.features?.length?l.features.join(', '):'todos'}`)); } },
    { name:'fantasminhaid', aliases:['fid','meuid'], category:'personal', permission:Role.USER, cooldown:3,
      handler: async ctx => ctx.reply(tag(`🪪 *Fantasminha ID*\n\n${fantasminhaId(ctx.sender)}`)) },
    { name:'personal', aliases:['fpersonal','personalizar'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:3,
      handler: async ctx => { const p=getPersonal(ctx.sender); return ctx.reply(tag(`⚙️ *Fantasminha Personal*\n\nIdioma: ${p.language}\nTema: ${p.theme}\nEstilo: ${p.responseStyle}\nNotificações: ${p.notifications?'ON':'OFF'}\nPlano: ${isVip(ctx.sender)?'💎 VIP':'🆓 FREE'}`)); } },
    { name:'preferencia', aliases:['pref'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:2,
      handler: async ctx => { const [k,...rest]=ctx.args||[]; if(!k) return ctx.reply(tag('Use: ×preferencia chave valor')); const value=rest.join(' '); const p=await updatePersonal(ctx.sender,{[k]:value},{actor:ctx.sender,requestId:ctx.requestId}); return ctx.reply(tag(`⚙️ ${k} = ${p[k]}`)); } },
    { name:'personaltema', aliases:['tema'], category:'personal', permission:Role.USER, privateOnly:true, cooldown:3,
      handler: async ctx => { const theme=ctx.args?.[0]; if(!theme) return ctx.reply(tag('Temas: limbo, cosmos, neon, minimal')); const allowed=['limbo','cosmos','neon','minimal']; if(!allowed.includes(theme)) return ctx.reply(tag('Tema inválido.')); await updatePersonal(ctx.sender,{theme},{actor:ctx.sender}); return ctx.reply(tag(`🎨 Tema pessoal: *${theme}*`)); } },
    { name:'personalcustom', aliases:['customizar'], category:'personal', permission:Role.USER, specialPermission:'use_vip_benefits', specialRoles:['vip'], privateOnly:true, cooldown:3,
      handler: async ctx => { const [key,...rest]=ctx.args||[]; if(!key||!rest.length) return ctx.reply(tag('Uso VIP: ×personalcustom chave valor')); await setCustom(ctx.sender,key,rest.join(' '),{premium:true,actor:ctx.sender}); return ctx.reply(tag(`💎 Personalização salva: *${key}*`)); } },
    { name:'buscarcomando', aliases:['buscarcmd','findcmd'], category:'sistema', permission:Role.USER, cooldown:2,
      handler: async ctx => { const q=String(ctx.q||'').toLowerCase().trim(); if(!q) return ctx.reply(tag('Use: ×buscarcomando termo')); const {listCommands}=await import('../../core/registry.js'); const hits=listCommands().filter(c=>[c.name,c.description,c.category,...c.aliases].join(' ').toLowerCase().includes(q)).slice(0,12); return ctx.reply(tag(hits.length?`🔎 *Resultados:* ${q}\n\n${hits.map(c=>`• ${c.name}${c.description?` — ${c.description}`:''}`).join('\n')}`:'Nenhum comando encontrado.')); } }
  ];
  for (const def of defs) registerCommand({ ...def, plugin:'platform', version:'6.0.0' });
}
export default { register };
