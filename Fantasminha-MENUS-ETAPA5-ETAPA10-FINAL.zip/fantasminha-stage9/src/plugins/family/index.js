import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import familyService from '../../services/familyService.js';
import { getUser, readCollection } from '../../database/store.js';

const target = c => c.mentioned?.[0] || (Array.isArray(c.args) && c.args[0]) || null;
const at = id => `@${String(id || '').split('@')[0]}`;
const fmt = n => Number(n || 0).toLocaleString('pt-BR');
const guard = c => {
  if (!c.isGroup || !c.from) return '👻 Este comando de família funciona apenas em grupos.';
  if (!c.groupData?.modorpg) return '⚔️ Modo RPG desativado! Ative com ×modorpg para usar o sistema de família.';
  return null;
};
const confirmed = c => Array.isArray(c.args) && c.args.some(a => String(a).toLowerCase() === 'confirmar');

async function adopt(c, biological=false) {
  const g=guard(c); if(g) return c.reply(g); const childId=target(c);
  if(!childId) return c.reply(`👨‍👩‍👧‍👦 Marque alguém.\n\nExemplo: ×${biological?'biologico':'adotaruser'} @user`);
  if(childId===c.sender) return c.reply('❌ Você não pode criar um vínculo familiar com você mesmo.');
  const cost=biological?0:10000;
  try { await familyService.adopt({parentId:c.sender,childId,biological,debitCost:cost}); return c.reply(`${biological?'🧬':'🍼'} ${at(childId)} agora é seu filho(a) *${biological?'biológico':'adotivo'}*.${cost?`\n💰 Custo: ${fmt(cost)} GC`:''}`,{mentions:[childId]}); }
  catch(e) { return c.reply(`❌ ${e?.message||'Não foi possível criar o vínculo familiar.'}`); }
}
async function desherdar(c) {
  const g=guard(c); if(g) return c.reply(g); const childId=target(c);
  if(!childId) return c.reply('💔 Marque o filho(a) que deseja desherdar.\n\nExemplo: ×desherdar @user confirmar');
  if(!confirmed(c)) return c.reply(`⚠️ *Confirmação necessária.*\n\nVocê está prestes a remover ${at(childId)} da sua família. Isso remove o vínculo entre vocês, seja 🧬 biológico ou 🍼 adotivo.\n\nUse *×desherdar @user confirmar* para confirmar.`,{mentions:[childId]});
  if(childId===c.sender) return c.reply('❌ Você não pode remover a si mesmo por este comando. Use ×sairfamilia.');
  try { await familyService.removeChild({parentId:c.sender,childId}); const f=familyService.get(c.sender); return c.reply(`💔 ${at(childId)} foi removido(a) da sua família.\n\n👶 Filhos restantes: ${f.children.length}`,{mentions:[childId]}); }
  catch(e) { return c.reply(`❌ ${e?.message||'Não foi possível remover o vínculo familiar.'}`); }
}
async function leave(c) {
  const g=guard(c); if(g) return c.reply(g);
  if(!confirmed(c)) return c.reply('⚠️ *Confirmação necessária.*\n\n×sairfamilia remove seus vínculos de pais e filhos. Seu relacionamento/conjuge não é alterado.\n\nUse *×sairfamilia confirmar* para confirmar.');
  try { const r=await familyService.leaveFamily({userId:c.sender}); if(!r.parentsRemoved.length&&!r.childrenRemoved.length) return c.reply('👻 Você não possui vínculos de pais/filhos para sair da família.'); const mentions=[...new Set([...r.parentsRemoved,...r.childrenRemoved])]; return c.reply(`🚪 Você saiu dos vínculos de pais/filhos da sua família.\n\n👴👵 Vínculos com pais removidos: ${r.parentsRemoved.length}\n👶 Vínculos com filhos removidos: ${r.childrenRemoved.length}`,{mentions}); }
  catch(e) { return c.reply(`❌ ${e?.message||'Não foi possível sair da família.'}`); }
}
async function tree(c) {
  const g=guard(c); if(g) return c.reply(g); const userId=target(c)||c.sender; if(!getUser(userId)) return c.reply('❌ Usuário não encontrado.'); const r=familyService.tree(userId);
  return c.reply(`╭─〔 🌳 *ÁRVORE GENEALÓGICA* 〕─╮\n${r.lines.join('\n')}\n╰────────────────────╯\n🧬 Biológico • 🍼 Adotivo`,{mentions:r.mentions});
}
async function lineage(c) {
  const g=guard(c); if(g) return c.reply(g); const userId=target(c)||c.sender; if(!getUser(userId)) return c.reply('❌ Usuário não encontrado.'); const r=familyService.tree(userId);
  return c.reply(`🌳 *LINHAGEM DO ALÉM*\n\n${r.lines.join('\n')}\n\n🧬 Biológico • 🍼 Adotivo`,{mentions:r.mentions});
}
async function summary(c) {
  const g=guard(c); if(g) return c.reply(g); const f=familyService.get(c.sender);
  const parents=f.parents.map(id=>`${at(id)} ${familyService.getFiliationType(c.sender,id)==='biologico'?'🧬':'🍼'}`);
  const children=f.children.map(id=>`${at(id)} ${familyService.getFiliationType(id,c.sender)==='biologico'?'🧬':'🍼'}`);
  const mentions=[...new Set([...f.parents,...f.children,...(f.spouse?[f.spouse]:[])])];
  return c.reply(`👨‍👩‍👧‍👦 *FAMÍLIA DO ALÉM*\n\n👴👵 Pais (${parents.length}): ${parents.join(', ')||'nenhum'}\n👶 Filhos (${children.length}): ${children.join(', ')||'nenhum'}\n💍 Cônjuge: ${f.spouse?at(f.spouse):'nenhum'}\n\n🧬 Biológico • 🍼 Adotivo\n🌳 Use ×arvore para visualizar a árvore completa.`,{mentions});
}
async function familyRanking(c) {
  const g=guard(c); if(g) return c.reply(g);
  const users=readCollection('users',{byId:{}}).byId||{};
  const rows=Object.entries(users).map(([key,u])=>({id:String(u?.id||key),count:familyService.relationCount(u?.id||key)}))
    .filter(x=>x.id).sort((a,b)=>b.count-a.count||a.id.localeCompare(b.id)).slice(0,10);
  return c.reply(`👨‍👩‍👧‍👦 *RANKING FAMILIAR*\n\n${rows.map((x,i)=>`${i+1}. ${at(x.id)} — ${x.count} vínculos`).join('\n')||'Sem dados.'}`,{mentions:rows.map(x=>x.id)});
}
const common={permission:Role.USER,groupOnly:true,category:'rpg-familia',plugin:'family',cooldown:2,audit:true};
export async function register(){
  registerCommand({...common,name:'adotaruser',aliases:['adotarfilho','adotar701','adocaosolo','adotarfilho701'],description:'Adota um usuário como filho(a).',usage:'×adotaruser @user',handler:c=>adopt(c,false)});
  registerCommand({...common,name:'biologico',aliases:['filhobiologico','registrarfilho'],description:'Registra um filho(a) como vínculo biológico fictício.',usage:'×biologico @user',handler:c=>adopt(c,true)});
  registerCommand({...common,name:'desherdar',aliases:['deserdar','removerfilho'],description:'Remove um filho(a), seja biológico ou adotivo.',usage:'×desherdar @user confirmar',handler:desherdar});
  registerCommand({...common,name:'sairfamilia',description:'Remove seus vínculos de pais e filhos.',usage:'×sairfamilia confirmar',handler:leave});
  registerCommand({...common,name:'arvore',aliases:['familytree','arvore701','familytree701','arvorefamilia'],description:'Mostra a árvore genealógica familiar.',usage:'×arvore [@user]',handler:tree});
  registerCommand({...common,name:'linhagem',description:'Mostra a linhagem familiar.',usage:'×linhagem [@user]',handler:lineage});
  registerCommand({...common,name:'familia',aliases:['familia701','family701'],description:'Mostra o resumo da sua família.',usage:'×familia',handler:summary});
  registerCommand({...common,name:'rankingfamilia',aliases:['rankfamilias'],description:'Ranking de usuários por vínculos familiares.',usage:'×rankingfamilia',handler:familyRanking});
}
export default {register};
