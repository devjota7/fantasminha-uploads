import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { applyGlobalStyle, applyLocalStyle, getMenuStyleFor, getMenuStyleSource, isGroupLocked, normalizeMenuStyle } from '../../services/menuStyle.js';
import { createFlowController, parseStyleInput } from '../../services/menuStyleFlow.js';

const tag = text => `× 👻 FANTASMINHA\n\n${text}`;
const flow = createFlowController();

function args(ctx) { return Array.isArray(ctx.args) ? ctx.args.map(x => String(x || '').trim()).filter(Boolean) : []; }
function reply(ctx, text, options = {}) { return ctx.reply(tag(text), { quoted: ctx.message || undefined, ...options }); }

async function fetchGroups(ctx) {
  const socket = ctx.sock || ctx.socket;
  const fetch = socket?.groupFetchAllParticipating;
  if (typeof fetch !== 'function') throw new Error('Socket do WhatsApp indisponível para listar grupos.');
  const raw = await fetch.call(socket);
  return Object.entries(raw || {})
    .map(([key, g]) => {
      const id = String(g?.id || key || '').trim();
      const name = String(g?.subject || g?.name || '').trim() || id || 'Grupo';
      const participants = Array.isArray(g?.participants) ? g.participants : null;
      const size = Number.isFinite(Number(g?.size)) ? Number(g.size) : (participants ? participants.length : null);
      return { id, name, size, participants, style: id ? getMenuStyleFor({ groupId: id }) : 'carrossel', source: id ? getMenuStyleSource({ groupId: id }) : 'padrao', locked: id ? isGroupLocked(id) : false };
    })
    .filter(g => g.id)
    .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }) || a.id.localeCompare(b.id));
}

function normalizeGroupSnapshot(groups) {
  return groups.map(g => ({ ...g, style: getMenuStyleFor({ groupId: g.id }), source: getMenuStyleSource({ groupId: g.id }), locked: isGroupLocked(g.id) }));
}

async function executeEffects(ctx, effects) {
  const outputs = [];
  for (const effect of effects || []) {
    if (effect.type === 'DEFINE_LOCAL') {
      const changes = effect.selected.map(g => ({ groupId: g.id, name: g.name, style: effect.style, locked: effect.locked }));
      const result = await applyLocalStyle(changes, ctx, { chat: ctx.from || null });
      outputs.push(`Pronto: ${result.groups.length} grupo(s) alterado(s) para *${result.style}*. Trancados: ${effect.locked ? 'sim' : 'não'}.`);
    } else if (effect.type === 'DEFINE_GLOBAL') {
      const result = await applyGlobalStyle(effect.style, effect.groups.map(g => ({ id: g.id, name: g.name })), ctx, { chat: ctx.from || null });
      outputs.push(`Pronto: global definido como *${result.style}*. ${result.affected.length} grupo(s) passam a seguir o global; ${result.locked.length} trancado(s) permanecem como estão.`);
    }
  }
  return outputs;
}

async function consume(ctx, text) {
  const status = flow.peek(ctx.sender, ctx.from);
  if (!status.active) return false;
  if (status.expired) {
    const expired = flow.consume(ctx.sender, ctx.from, text, {});
    for (const message of expired.messages || []) await reply(ctx, message);
    return true;
  }
  const current = status.state;
  let context = {};
  if (current.step === 'scope') {
    const value = String(text || '').trim().toLowerCase();
    if (value === '2' || value === 'local') context.groups = normalizeGroupSnapshot(await fetchGroups(ctx));
    else if (value === '1' || value === 'global') context.groups = normalizeGroupSnapshot(await fetchGroups(ctx));
  }
  const result = flow.consume(ctx.sender, ctx.from, text, context);
  if (!result.handled) return false;
  for (const message of result.messages || []) await reply(ctx, message);
  const effectMessages = await executeEffects(ctx, result.effects);
  for (const message of effectMessages) await reply(ctx, message);
  return true;
}

export function cancelMenuStyleFlow(ctx) { return flow.cancel(ctx.sender, ctx.from); }
export function hasMenuStyleFlow(ctx) { return Boolean(flow.get(ctx.sender, ctx.from)); }
export async function consumeMenuStyleFlow(ctx, text) { return consume(ctx, text); }

export async function register() {
  registerCommand({
    name: 'definirmenu', aliases: [], category: 'dono', plugin: 'menuStyle', permission: Role.OWNER, ownerOnly: true, cooldown: 1,
    description: 'Define o estilo do menu principal em conversa guiada.', usage: '×definirmenu [carrossel|lista|botao]',
    handler: async ctx => {
      const a = args(ctx);
      if (a.length) {
        const first = a.join(' ');
        const parsed = parseStyleInput(first);
        const result = flow.start(ctx.sender, ctx.from, first);
        if (!parsed) return reply(ctx, `${result.messages[0]}\n\nDica: use 1, 2, 3, carrossel, lista ou botao.`);
        return reply(ctx, result.messages[0]);
      }
      const result = flow.start(ctx.sender, ctx.from);
      return reply(ctx, result.messages[0]);
    }
  });
}

export default { register, consumeMenuStyleFlow, cancelMenuStyleFlow, hasMenuStyleFlow };
