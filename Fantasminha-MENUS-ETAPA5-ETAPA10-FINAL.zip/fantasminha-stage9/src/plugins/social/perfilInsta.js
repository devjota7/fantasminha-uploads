import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fetchInstagramProfile, downloadInstagramImage } from '../../services/social/instagramService.js';
import { renderSocialProfile } from '../../services/social/socialProfileRenderer.js';
import { formatSocialProfile, usageMessage, notFoundMessage, errorMessage } from '../../services/social/socialProfileFormatter.js';

export async function registerPerfilInstagram() {
  registerCommand({
    name: 'perfilinsta', aliases: [], category: 'comunidade', plugin: 'social', permission: Role.USER,
    cooldown: 5, timeoutMs: 20_000,
    description: 'Consulta um perfil público do Instagram em uma ficha visual com posts recentes.',
    usage: '×perfilinsta <usuario>', examples: ['×perfilinsta cristiano', '×perfilinsta @cristiano'],
    handler: async ctx => {
      const raw = String(ctx.q || ctx.args?.[0] || '').trim();
      if (!raw) return ctx.reply(usageMessage('instagram', ctx.prefix || '×'));
      const data = await fetchInstagramProfile(raw);
      if (data.status === 'invalid') return ctx.reply(usageMessage('instagram', ctx.prefix || '×'));
      if (data.status === 'not_found') return ctx.reply(notFoundMessage);
      if (data.status !== 'ok') return ctx.reply(errorMessage);

      const posts = (data.recentPosts || []).slice(0, 3);
      const avatarBuffer = await downloadInstagramImage(data.avatarUrl);
      const postBuffers = await Promise.all(posts.map(p => downloadInstagramImage(p.imageUrl)));
      const renderedPosts = posts.map((p, i) => ({ ...p, imageBuffer: postBuffers[i] || null }));

      try {
        const image = await renderSocialProfile(data, { avatarBuffer, posts: renderedPosts });
        const links = [
          `🔗 *Perfil:* ${data.profileUrl}`,
          ...renderedPosts.filter(p => p?.url).map((p, i) => `📸 *Post ${i + 1}:* ${p.url}`)
        ].join('\n');
        if (typeof ctx.sendMessage === 'function') {
          await ctx.sendMessage(ctx.from, { image, caption: `👻 *FANTASMINHA • PERFIL INSTAGRAM*\n\n${links}` });
          return;
        }
      } catch {}
      return ctx.reply(formatSocialProfile(data, `${ctx.prefix || '×'}perfilinsta`));
    }
  });
}
export default { registerPerfilInstagram };
