import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { fetchTikTokProfile, downloadTikTokImage } from '../../services/social/tiktokService.js';
import { renderSocialProfile } from '../../services/social/socialProfileRenderer.js';
import { formatSocialProfile, usageMessage, notFoundMessage, errorMessage } from '../../services/social/socialProfileFormatter.js';

export async function registerPerfilTikTok() {
  registerCommand({
    name: 'perfiltiktok', aliases: [], category: 'comunidade', plugin: 'social', permission: Role.USER,
    cooldown: 5, timeoutMs: 20_000,
    description: 'Consulta um perfil público do TikTok em uma ficha visual com vídeos recentes.',
    usage: '×perfiltiktok <usuario>', examples: ['×perfiltiktok mrbeast', '×perfiltiktok @mrbeast'],
    handler: async ctx => {
      const raw = String(ctx.q || ctx.args?.[0] || '').trim();
      if (!raw) return ctx.reply(usageMessage('tiktok', ctx.prefix || '×'));
      const data = await fetchTikTokProfile(raw);
      if (data.status === 'invalid') return ctx.reply(usageMessage('tiktok', ctx.prefix || '×'));
      if (data.status === 'not_found') return ctx.reply(notFoundMessage);
      if (data.status !== 'ok') return ctx.reply(errorMessage);

      const videos = (data.recentVideos || []).slice(0, 3);
      const avatarBuffer = await downloadTikTokImage(data.avatarUrl);
      const videoBuffers = await Promise.all(videos.map(v => downloadTikTokImage(v.imageUrl)));
      const renderedVideos = videos.map((v, i) => ({ ...v, imageBuffer: videoBuffers[i] || null }));

      try {
        const image = await renderSocialProfile(data, { avatarBuffer, posts: renderedVideos });
        const links = [
          `🔗 *Perfil:* ${data.profileUrl}`,
          ...renderedVideos.filter(v => v?.url).map((v, i) => `🎬 *Vídeo ${i + 1}:* ${v.url}`)
        ].join('\n');
        if (typeof ctx.sendMessage === 'function') {
          await ctx.sendMessage(ctx.from, { image, caption: `👻 *FANTASMINHA • PERFIL TIKTOK*\n\n${links}` });
          return;
        }
      } catch {}
      return ctx.reply(formatSocialProfile(data, `${ctx.prefix || '×'}perfiltiktok`));
    }
  });
}
export default { registerPerfilTikTok };
