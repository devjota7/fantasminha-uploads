import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { requestBestFriend, acceptBestFriendRequest, rejectBestFriendRequest, removeBestFriend, setAfk, findAfk, personality } from '../../services/social.js';
import { mentionAll } from '../../services/mentionManager.js';
import { initializeGroupRoomsPersistence } from '../../services/groupRooms.js';
import { getGroupRoom, setGroupRoom, removeGroupRoom } from '../../application/usecases/groupRooms.js';
import { resolveUserIdentity } from '../../platform/identity/resolver.js';
import { on, Events } from '../../events/index.js';
import { registerPerfilInstagram } from './perfilInsta.js';
import { registerPerfilTikTok } from './perfilTikTok.js';
import { generateWAMessageFromContent } from 'baileys';

const tag = s => `👻 *FANTASMINHA — ALÉM SOCIAL*\n\n${s}`;
const targetArg = ctx => ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || null;
let listenerInstalled = false;

export async function register() {
  await initializeGroupRoomsPersistence();
  await registerPerfilInstagram();
  await registerPerfilTikTok();
  registerCommand({name:'addbestfriend',aliases:['addbf','melhoramigo'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:3,description:'Envia um pedido de Best Friend para uma pessoa aceitar.',usage:'×addbestfriend @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); if(!t) return ctx.reply(tag('👻 *COMO USAR:*\n\nMencione a pessoa ou responda à mensagem dela para enviar o pedido.\n\nExemplo: *' + (ctx.prefix || '×') + 'addbestfriend @amigo*'));
    const r=await requestBestFriend(ctx,t);
    if (r.status === 'already') {
      const j = r.person.realJid || t;
      return ctx.reply(tag(`🫂 Essa pessoa já está como seu Best Friend.`), { mentions: [j] });
    }
    if (r.status === 'pending') {
      return ctx.reply(tag(`⏳ Já existe um pedido pendente para essa pessoa (${r.remainingSec}s restantes). Aguarde a resposta ou o tempo expirar.`));
    }
    const fromMention = r.request.fromRealJid;
    const toMention = r.request.toRealJid;
    const fromPhone = fromMention.split('@')[0];
    const toPhone = toMention.split('@')[0];
    const body = `🫂 *PEDIDO DE BEST FRIEND!*

👤 @${fromPhone} enviou um pedido para ser seu *Best Friend*, @${toPhone}!

💬 Para aceitar: responda com *sim* ou digite *${ctx.prefix || '×'}aceitarbest*
💬 Para recusar: responda com *nao* ou digite *${ctx.prefix || '×'}recusarbest*
⏳ O pedido expira em *2 minutos*.`;
    return ctx.reply(tag(body), { mentions: [fromMention, toMention] });
  }});
  registerCommand({name:'aceitarbest',aliases:['aceitarbf','simbest'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:2,description:'Aceita um pedido pendente de Best Friend.',usage:'×aceitarbest',handler:async ctx=>{
    const r=await acceptBestFriendRequest(ctx);
    if (!r) return ctx.reply(tag('👻 Você não possui nenhum pedido pendente de Best Friend para aceitar ou o tempo de 2 minutos já expirou.'));
    const fromPhone = r.fromJid.split('@')[0];
    const toPhone = r.toJid.split('@')[0];
    const body = `🫂 *BEST FRIEND CONFIRMADO!*

✨ @${toPhone} aceitou o pedido de @${fromPhone}!
Agora vocês são *Best Friends* oficiais no perfil! 🎉`;
    return ctx.reply(tag(body), { mentions: [r.fromJid, r.toJid] });
  }});
  registerCommand({name:'recusarbest',aliases:['recusarbf','naobest'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:2,description:'Recusa um pedido pendente de Best Friend.',usage:'×recusarbest',handler:async ctx=>{
    const r=await rejectBestFriendRequest(ctx);
    if (!r) return ctx.reply(tag('👻 Você não possui nenhum pedido pendente de Best Friend para recusar.'));
    const toPhone = (r.request.toRealJid || ctx.sender).split('@')[0];
    const toMention = r.request.toRealJid || ctx.sender;
    return ctx.reply(tag(`🕯️ *PEDIDO RECUSADO*\n\nO pedido de Best Friend foi recusado por @${toPhone}.`), { mentions: [toMention] });
  }});
  registerCommand({name:'rmvbestfriend',aliases:['removebestfriend','rmbf','removerbestfriend'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:3,description:'Remove um Best Friend do seu perfil.',usage:'×rmvbestfriend @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); if(!t) return ctx.reply(tag('👻 *COMO USAR:*\n\nMencione a pessoa ou responda à mensagem dela para remover o vínculo.\n\nExemplo: *' + (ctx.prefix || '×') + 'rmvbestfriend @amigo*'));
    const r=await removeBestFriend(ctx,t);
    const j = r.removedJid || r.person?.realJid || t;
    const phone = j.split('@')[0];
    return ctx.reply(tag(r.changed?`🕯️ *BEST FRIEND REMOVIDO*\n\n👤 @${phone}\nO vínculo saiu da sua ficha.`:`🕯️ Essa pessoa não está na sua lista de Best Friends.`),{mentions:[j]});
  }});

  const salaNotice = (title, body) => `🕸️ *${title}*\\n\\n${body}`;

  registerCommand({name:'addsala',aliases:['addsalas'],category:'comunidade',plugin:'social',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:3,description:'Registra ou atualiza uma sala do Among Us para o grupo.',usage:'×addsala <código>',handler:async ctx=>{
    const code=String(ctx.q||'').trim();
    if(!code) return ctx.reply(salaNotice('CÓDIGO AUSENTE','Informe o código da sala.\\n\\nExemplo: ×addsala TESTES'));
    if([...code].length>15) return ctx.reply(salaNotice('CÓDIGO INVÁLIDO','O código da sala pode ter no máximo *15 caracteres*.'));
    try {
      await setGroupRoom({ groupId: ctx.from, code, userId: ctx.sender });
    } catch (error) {
      return ctx.reply(salaNotice('NÃO FOI POSSÍVEL REGISTRAR','O código não pôde ser salvo. Tente novamente.'));
    }
    return ctx.reply(salaNotice('SALA REGISTRADA','O código foi salvo para este grupo.\n\n🎮 *Código:* ' + code));
  }});

  registerCommand({name:'sala',aliases:['salaus','salamong'],category:'comunidade',plugin:'social',permission:Role.USER,groupOnly:true,cooldown:0,description:'Abre a sala registrada e menciona os participantes.',usage:'×sala',handler:async ctx=>{
    const room=getGroupRoom({ groupId: ctx.from });
    if(!room) return ctx.reply(salaNotice('NENHUMA SALA REGISTRADA','Nenhum código está configurado neste grupo.\n\nUse ×addsala <código> para registrar uma.'));
    const roomCode = String(room.code);
    const visualText = [
      '╭━━━〔 👻 FANTASMINHA 〕━━━╮',
      '│',
      '│  🕸️ 𝑺𝑨𝑳𝑨 · 𝑨𝑻𝑰𝑽𝑨',
      '│',
      '│  ╭─────── ✦ ───────╮',
      `│  │    🎮 ${roomCode}  │`,
      '│  ╰─────── ✦ ───────╯',
      '│',
      '│  🕯️ Portal aberto · entre agora',
      '│',
      '╰━━━━━━━〔 🕸️ 〕━━━━━━━╯'
    ].join('\n');
    const socket = ctx.sock || ctx.socket;
    if (!socket?.relayMessage) return ctx.reply(salaNotice('SALA INDISPONÍVEL','Não foi possível abrir o painel agora. Tente novamente em instantes.'));
    const userJid = socket?.authState?.creds?.me?.id || socket?.user?.id;
    const copyButton = {
      name: 'cta_copy',
      buttonParamsJson: JSON.stringify({
        display_text: '📋 Copiar código',
        copy_code: roomCode
      })
    };
    const panel = generateWAMessageFromContent(ctx.from, {
      viewOnceMessage: { message: {
        interactiveMessage: {
          body: { text: visualText },
          nativeFlowMessage: {
            buttons: [copyButton],
            messageParamsJson: '{}'
          }
        }
      }}
    }, { userJid, quoted: ctx.message });
    try {
      await socket.relayMessage(ctx.from, panel.message, {
        messageId: panel.key.id,
        additionalNodes: [{ tag: 'biz', attrs: {}, content: [{ tag: 'interactive', attrs: { type: 'native_flow', v: '1' }, content: [{ tag: 'native_flow', attrs: { v: '9', name: 'mixed' } }] }] }]
      });
    } catch (error) {
      return ctx.reply(salaNotice('FALHA AO ABRIR A SALA','O painel não pôde ser enviado. O código continua registrado.'));
    }
    let payload;
    try {
      payload=await mentionAll(ctx,roomCode,{excludeBot:true});
    } catch (error) {
      return ctx.reply(salaNotice('FALHA NAS MENÇÕES','O painel foi enviado, mas não foi possível preparar as menções.'));
    }
    // 2ª mensagem: SOMENTE o código, sem moldura/decoração. As menções ficam no payload.
    try {
      const technicalMessage = { text: roomCode, mentions: Array.isArray(payload?.mentions) ? payload.mentions : [], __skipVisualDecorate: true };
      await ctx.sendMessage(ctx.from, technicalMessage);
      return true;
    } catch (error) {
      return ctx.reply(salaNotice('FALHA AO CONCLUIR','A sala foi aberta, mas a mensagem técnica não pôde ser enviada.'));
    }
  }});

  registerCommand({name:'rmsala',aliases:['removesala','delsala'],category:'comunidade',plugin:'social',permission:Role.GROUP_ADMIN,groupOnly:true,cooldown:3,description:'Remove a sala registrada do grupo.',usage:'×rmsala',handler:async ctx=>{
    try {
      if(!(await removeGroupRoom({ groupId: ctx.from }))) return ctx.reply(salaNotice('NENHUMA SALA REGISTRADA','Não existe um código configurado neste grupo.'));
    } catch (error) {
      return ctx.reply(salaNotice('NÃO FOI POSSÍVEL REMOVER','O registro não pôde ser removido. Tente novamente.'));
    }
    return ctx.reply(salaNotice('SALA REMOVIDA','O código da sala foi removido deste grupo.'));
  }});
  registerCommand({name:'personalidade',aliases:['pers','analisepessoa'],category:'perfil',plugin:'social',permission:Role.USER,cooldown:5,description:'Gera uma análise espiritual aleatória, apenas recreativa.',usage:'×personalidade @pessoa',handler:async ctx=>{
    const t=targetArg(ctx); const person=await resolveUserIdentity(ctx,t||ctx.sender); const j=person.realJid || ctx.sender; const p=personality(person.name||ctx.pushname||'Pessoa',j);
    const body=`✨ *ANÁLISE ESPIRITUAL DE @${j.split('@')[0]}* ✨\n\n↳ 🏛️ Aparência espiritual: ${p.aparencia}\n↳ 🏋️ Hobby provável: ${p.hobby}\n↳ 🎭 Profissão ideal: ${p.profissao}\n↳ ⏰ Horário favorito: ${p.horario}\n↳ 🎵 Trilha sonora: ${p.musica}\n↳ 🌡️ Clima ideal: ${p.clima}\n↳ ♑ Signo espiritual: ${p.signo}\n↳ 🦈 Animal interior: ${p.animal}\n↳ 👻 Qualidade marcante: ${p.qualidade}\n↳ 🌀 Defeito provável: ${p.defeito}\n↳ ⚡ Energia: ${p.energia}\n↳ 🪦 Profissão no Além: ${p.profissaoAlem}\n↳ 🪄 Superpoder inútil: ${p.poder}\n↳ 🚔 Motivo pelo qual seria preso no Além: ${p.preso}\n↳ 🎁 Talento secreto: ${p.talento}\n↳ 💬 Frase que representa: ${p.frase}\n\n🔮 _Brincadeira recreativa. A precisão foi espiritualmente questionável._`;
    return ctx.reply(tag(body),{mentions:[j]});
  }});
  registerCommand({name:'afk',aliases:[],category:'perfil',plugin:'social',permission:Role.USER,groupOnly:true,cooldown:3,description:'Marca você como ausente no grupo até enviar uma nova mensagem.',usage:'×afk [motivo]',handler:async ctx=>{
    const r=await setAfk(ctx,ctx.q);
    return ctx.reply(tag(`😴 *VOCÊ ESTÁ AFK*\n\n👤 ${r.name}\n🕯️ Motivo: *${r.reason}*\n⏳ Desde: *${new Date(r.since).toLocaleTimeString('pt-BR',{hour:'2-digit',minute:'2-digit',timeZone:'America/Sao_Paulo'})}*\n\nQuando você falar novamente neste grupo, seu AFK será removido automaticamente. 💀`));
  }});

  if (listenerInstalled) return;
  listenerInstalled = true;
  on(Events.MESSAGE, async ctx=>{
    if(!ctx?.body) return;
    const rawText = String(ctx.body || ctx.text || '').trim();

    // Resposta natural sim/nao para pedido de Best Friend
    if (!rawText.startsWith(ctx.prefix || '×')) {
      const lower = rawText.toLowerCase();
      if (/^(sim|s|aceito|aceitar|yes|y)$/i.test(lower)) {
        try {
          const r = await acceptBestFriendRequest(ctx);
          if (r) {
            const fromPhone = r.fromJid.split('@')[0];
            const toPhone = r.toJid.split('@')[0];
            const body = `🫂 *BEST FRIEND CONFIRMADO!*\n\n✨ @${toPhone} aceitou o pedido de @${fromPhone}!\nAgora vocês são *Best Friends* oficiais no perfil! 🎉`;
            return await ctx.reply(tag(body), { mentions: [r.fromJid, r.toJid] });
          }
        } catch {}
      } else if (/^(nao|não|n|recuso|recusar|no)$/i.test(lower)) {
        try {
          const r = await rejectBestFriendRequest(ctx);
          if (r) {
            const toPhone = (r.request.toRealJid || ctx.sender).split('@')[0];
            const toMention = r.request.toRealJid || ctx.sender;
            return await ctx.reply(tag(`🕯️ *PEDIDO RECUSADO*\n\nO pedido de Best Friend foi recusado por @${toPhone}.`), { mentions: [toMention] });
          }
        } catch {}
      }
    }

    if(!ctx?.isGroup || !ctx.mentioned?.length || rawText.startsWith(ctx.prefix||'×')) return;
    for(const target of ctx.mentioned.slice(0,3)) {
      try { const hit=await findAfk(ctx,target); if(!hit) continue; const j=hit.person.realJid || hit.record.userId; const reason=hit.record.reason && hit.record.reason !== 'Não especificado' ? `\n💭 Motivo: ${hit.record.reason}` : ''; await ctx.reply(tag(`😴 @${j.split('@')[0]} está AFK desde ${new Date(hit.record.since).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'})}.${reason}`),{mentions:[j]}); } catch {}
    }
  });
}
export default {register};
