import crypto from 'crypto';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { readCollection, updateCollection, getUser, upsertUser } from '../../database/store.js';
import { transact } from '../../platform/transactions/index.js';
import * as economy from '../../services/economy.js';
import petService from '../../services/petEngine.js';
import companyService from '../../services/companyService.js';

const PREFIX = 'world';
const uid = p => `${p}-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
const a = c => Array.isArray(c.args) ? c.args : String(c.q || '').trim().split(/\s+/).filter(Boolean);
const q = c => String(c.q || '').trim();
const target = c => c.mentioned?.[0] || a(c)[0] || null;
const mention = id => `@${String(id || '').split('@')[0]}`;
const fmt = n => Number(n || 0).toLocaleString('pt-BR');
const clamp = (n, min, max) => Math.max(min, Math.min(max, n));
const user = id => getUser(id) || { id, name: '', economy: { wallet: 0, bank: 0, inventory: {} }, rpg: { level: 1, xp: 0, hp: 100, maxHp: 100 } };
const save = (name, fn, fallback = {}) => updateCollection(name, fn, fallback);

const REGIONS = {
  vila: { name: 'Vila dos Espíritos', icon: '🏚️', level: 1, desc: 'Refúgio dos espíritos recém-chegados.' },
  cemiterio: { name: 'Cemitério Antigo', icon: '🪦', level: 3, desc: 'Ruínas, túmulos e ecos de almas antigas.' },
  floresta: { name: 'Floresta Sombria', icon: '🌲', level: 6, desc: 'Uma mata viva que observa quem entra.' },
  purgatorio: { name: 'Purgatório', icon: '⚖️', level: 10, desc: 'Terra de provações e julgamentos.' },
  abismo: { name: 'Abismo', icon: '🔥', level: 20, desc: 'Região hostil onde monstros antigos despertam.' },
  reino: { name: 'Reino dos Mortos', icon: '🏰', level: 30, desc: 'Capital espiritual e sede das grandes facções.' },
  perdida: { name: 'Dimensão Perdida', icon: '🌌', level: 50, desc: 'Uma dimensão instável, quase impossível de alcançar.' }
};

const HOUSES = {
  barraco: ['🛖', 'Barraco Espiritual', 25000, 1],
  casa: ['🏠', 'Casa do Além', 75000, 5],
  mansao: ['🏡', 'Mansão Espectral', 250000, 15],
  castelo: ['🏰', 'Castelo do Véu', 750000, 30],
  reino: ['🌌', 'Domínio Espiritual', 2500000, 50]
};

const ITEMS = {
  essencia: { name: 'Essência Espiritual', price: 2500, power: 10 },
  elixir: { name: 'Elixir do Além', price: 7500, power: 30 },
  cristal: { name: 'Cristal do Véu', price: 15000, power: 50 },
  chave: { name: 'Chave Dimensional', price: 50000, power: 0 }
};

const ACHIEVEMENTS = [
  ['primeiro_passo', '👻 Primeiro Passo', 'Visite sua primeira região.'],
  ['explorador', '🗺️ Explorador do Véu', 'Visite 5 regiões.'],
  ['magnata', '💰 Magnata', 'Acumule 1.000.000 GC.'],
  ['senhor_casa', '🏰 Senhor do Véu', 'Possua um Castelo ou melhor.'],
  ['familia', '👨‍👩‍👧‍👦 Grande Linhagem', 'Tenha 5 vínculos familiares.'],
  ['pet_lenda', '🐉 Guardião Lendário', 'Possua um pet lendário ou superior.'],
  ['boss', '⚔️ Caçador de Bosses', 'Derrote um boss mundial.'],
  ['empresa', '🏢 Magnata Empresarial', 'Tenha uma empresa.'],
  ['npc', '🤖 Mestre dos NPCs', 'Conheça 10 NPCs.'],
  ['dimensao', '🌌 Além do Além', 'Alcance a Dimensão Perdida.']
];

function ensureWorld(u) {
  u.world ??= { region: 'vila', visited: ['vila'], energy: 100, reputation: 0, achievements: [], inventory: {}, house: null, investments: {}, profileTitle: null };
  u.world.visited ??= ['vila']; u.world.inventory ??= {}; u.world.investments ??= {};
  return u.world;
}

async function patchUser(id, patch) { return upsertUser(id, patch); }
async function award(c, key) {
  const u = user(c.sender), w = ensureWorld(u);
  if (w.achievements.includes(key)) return false;
  const found = ACHIEVEMENTS.find(x => x[0] === key); if (!found) return false;
  w.achievements.push(key); await patchUser(c.sender, { world: w });
  await c.reply(`🏆 *CONQUISTA DESBLOQUEADA!*\n\n${found[1]}\n${found[2]}`); return true;
}

async function mundo(c) {
  const u = user(c.sender), w = ensureWorld(u);
  return c.reply(`╭─〔 🌌 *FANTASMINHA WORLD ENGINE* 〕─╮\n│ ${Object.entries(REGIONS).map(([k,v]) => `${v.icon} ${v.name} — Nv.${v.level}${w.visited.includes(k) ? ' ✅' : ' 🔒'}`).join('\n│ ')}\n╰────────────────────────────╯\n\n📍 Local atual: ${REGIONS[w.region].name}\n⚡ Energia: ${w.energy}/100\n⭐ Reputação: ${w.reputation}`);
}

async function mapa(c) { return mundo(c); }

async function local(c) {
  const u = user(c.sender), w = ensureWorld(u), r = REGIONS[w.region];
  return c.reply(`${r.icon} *${r.name}*\n\n${r.desc}\n\n🔓 Requisito: nível ${r.level}\n👻 Seu nível: ${u.rpg?.level || 1}\n⚡ Energia: ${w.energy}/100`);
}

async function viajar(c) {
  const key = String(a(c)[0] || '').toLowerCase();
  const r = REGIONS[key]; if (!r) return c.reply(`🗺️ Regiões: ${Object.keys(REGIONS).join(', ')}`);
  const u = user(c.sender), w = ensureWorld(u), level = u.rpg?.level || 1;
  if (level < r.level) return c.reply(`🔒 Você precisa do nível ${r.level}. Seu nível: ${level}.`);
  if (w.energy < 10) return c.reply('⚡ Você está sem energia. Use ×descansar.');
  w.energy -= 10; w.region = key; if (!w.visited.includes(key)) w.visited.push(key);
  await patchUser(c.sender, { world: w });
  await c.reply(`🌀 Você atravessou o Véu e chegou em ${r.icon} *${r.name}*.`);
  if (w.visited.length >= 5) await award(c, 'explorador');
  if (key === 'perdida') await award(c, 'dimensao');
  return true;
}

async function descansar(c) {
  const cooldown = 15 * 60 * 1000; let restored = false;
  await updateCollection('users', users => {
    users.byId ??= {}; const u = users.byId[c.sender] || { id:c.sender, economy:{wallet:0,bank:0,inventory:{}}, rpg:{level:1,xp:0,hp:100,maxHp:100} };
    const w = ensureWorld(u), now = Date.now();
    if (w.lastRest && now - w.lastRest < cooldown) throw new Error(`Descanso em cooldown por ${Math.ceil((cooldown-(now-w.lastRest))/60000)} min.`);
    w.lastRest = now; w.energy = 100; users.byId[c.sender] = u; restored = true; return users;
  }, {byId:{}});
  return restored && c.reply('🛌 Você descansou no Além. ⚡ Energia restaurada para 100.');
}

async function perfil(c) {
  const id = target(c) || c.sender, u = user(id), w = ensureWorld(u), f = u.family || { parents: [], children: [], spouse: null };
  const pets = await petService.listAsync('global', id);
  return c.reply(`╭─═〔 👻 *PERFIL DO ALÉM* 〕═─╮\n│ 👤 ${mention(id)}\n│ ⭐ Nível: ${u.rpg?.level || 1}\n│ ⚔️ XP: ${fmt(u.rpg?.xp || 0)}\n│ 💰 Ghostcoins: ${fmt((u.economy?.wallet || 0) + (u.economy?.bank || 0))}\n│ 📍 Região: ${REGIONS[w.region]?.name || w.region}\n│ 🏠 Casa: ${w.house ? HOUSES[w.house]?.[1] : 'Nenhuma'}\n│ 🐾 Pets: ${pets.length}\n│ 👨‍👩‍👧 Vínculos: ${(f.parents?.length || 0) + (f.children?.length || 0) + (f.spouse ? 1 : 0)}\n│ 🏆 Conquistas: ${w.achievements.length}/${ACHIEVEMENTS.length}\n╰──────────────────────╯`, { mentions: [id] });
}

async function conquistas(c) {
  const u = user(c.sender), w = ensureWorld(u);
  return c.reply(`🏆 *CONQUISTAS DO ALÉM*\n\n${ACHIEVEMENTS.map(x => `${w.achievements.includes(x[0]) ? '✅' : '🔒'} ${x[1]} — ${x[2]}`).join('\n')}`);
}

async function casa(c) {
  const u = user(c.sender), w = ensureWorld(u);
  if (!w.house) return c.reply(`🏠 Você ainda não possui uma casa.\n\n${Object.entries(HOUSES).map(([k,v]) => `${v[0]} ${k} — ${v[1]} — ${fmt(v[2])} GC — Nv.${v[3]}`).join('\n')}\n\nUse ×comprarcasa <tipo>`);
  return c.reply(`🏠 *${HOUSES[w.house][1]}*\n📈 Tier: ${w.house}\n🛡️ Seu domínio está protegido pelo Véu.`);
}

async function comprarCasa(c) {
  const key = String(a(c)[0] || '').toLowerCase(), h = HOUSES[key]; if (!h) return casa(c);
  const u = user(c.sender), w = ensureWorld(u), level = u.rpg?.level || 1;
  if (level < h[3]) return c.reply(`🔒 Nível mínimo: ${h[3]}.`);
  if ((u.economy?.wallet || 0) < h[2]) return c.reply(`💰 Você precisa de ${fmt(h[2])} GC.`);
  if (w.house) return c.reply('🏠 Você já possui uma propriedade. Venda/upgrade antes de comprar outra.');
  await economy.mutateAccount(c.sender, ({user,account}) => { const world = ensureWorld(user); account.debit(h[2]); world.house = key; user.world = world; }, {reason:'world.house.purchase',name:c.pushname,operationId:`world-house:${c.sender}:${key}`});
  await c.reply(`🏠 *PROPRIEDADE ADQUIRIDA*\n\n${h[0]} ${h[1]}\n💰 Investimento: ${fmt(h[2])} GC`);
  if (h[3] >= 30) await award(c, 'senhor_casa');
}

async function melhorarCasa(c) {
  const u = user(c.sender), w = ensureWorld(u); if (!w.house) return c.reply('🏠 Compre uma casa primeiro.');
  const keys = Object.keys(HOUSES), i = keys.indexOf(w.house), next = HOUSES[keys[i + 1]];
  if (!next) return c.reply('👑 Sua propriedade já está no nível máximo.');
  const cost = Math.floor(next[2] * 0.65); if ((u.economy?.wallet || 0) < cost) return c.reply(`💰 Upgrade custa ${fmt(cost)} GC.`);
  await economy.mutateAccount(c.sender, ({user,account}) => { const world = ensureWorld(user); account.debit(cost); world.house = keys[i + 1]; user.world = world; }, {reason:'world.house.upgrade',name:c.pushname,operationId:`world-house-upgrade:${c.sender}:${keys[i+1]}`});
  return c.reply(`⬆️ Casa evoluída para ${next[0]} *${next[1]}*!`);
}

async function inventario(c) {
  const u = user(c.sender), w = ensureWorld(u), inv = { ...(u.economy?.inventory || {}), ...(w.inventory || {}) };
  const lines = Object.entries(inv).filter(([,n]) => n > 0).map(([k,n]) => `• ${k}: ${n}`);
  return c.reply(`🎒 *INVENTÁRIO DO ALÉM*\n\n${lines.join('\n') || 'Vazio.'}`);
}

async function loja(c) { return c.reply(`🛒 *LOJA DO VÉU*\n\n${Object.entries(ITEMS).map(([k,v]) => `🔹 ${k} — ${v.name} — ${fmt(v.price)} GC`).join('\n')}\n\n×compraritem <item> [quantidade]`); }

async function comprarItem(c) {
  const aa = a(c), key = String(aa[0] || '').toLowerCase(), item = ITEMS[key], qty = clamp(Number(aa[1] || 1) || 1, 1, 50);
  if (!item) return loja(c); const u = user(c.sender), w = ensureWorld(u), cost = item.price * qty;
  if ((u.economy?.wallet || 0) < cost) return c.reply(`💰 Você precisa de ${fmt(cost)} GC.`);
  await economy.mutateAccount(c.sender, ({user,account}) => { const world = ensureWorld(user); account.debit(cost); world.inventory[key] = (world.inventory[key] || 0) + qty; user.world = world; }, {reason:'world.item.purchase',name:c.pushname,operationId:`world-item:${c.sender}:${key}:${Date.now()}`});
  return c.reply(`🛍️ Comprado: ${qty}× ${item.name}.\n💰 -${fmt(cost)} GC`);
}

async function usarItem(c) {
  const key = String(a(c)[0] || '').toLowerCase(), item = ITEMS[key]; if (!item) return loja(c);
  const u = user(c.sender), w = ensureWorld(u); if (!(w.inventory[key] > 0)) return c.reply('❌ Você não possui esse item.');
  w.inventory[key]--; if (key === 'elixir' || key === 'essencia') w.energy = clamp(w.energy + item.power, 0, 100);
  await patchUser(c.sender, { world: w }); return c.reply(`✨ Você usou ${item.name}. ⚡ Energia: ${w.energy}/100`);
}

async function banco(c) { const u = user(c.sender); return c.reply(`🏦 *BANCO DO ALÉM*\n\n💵 Carteira: ${fmt(u.economy?.wallet || 0)} GC\n🏦 Banco: ${fmt(u.economy?.bank || 0)} GC\n💰 Patrimônio: ${fmt((u.economy?.wallet || 0) + (u.economy?.bank || 0))} GC\n\n×depositar <valor>\n×sacar <valor>`); }
async function depositar(c) { const n = Math.floor(Number(a(c)[0])); if (!Number.isFinite(n) || n <= 0) return c.reply('🏦 ×depositar <valor>'); const e = await economy.deposit(c.sender,n); return c.reply(`🏦 Depositado: ${fmt(n)} GC.`); }
async function sacar(c) { const n = Math.floor(Number(a(c)[0])); if (!Number.isFinite(n) || n <= 0) return c.reply('🏦 ×sacar <valor>'); await economy.withdraw(c.sender,n); return c.reply(`💵 Sacado: ${fmt(n)} GC.`); }
async function extrato(c) { const d = readCollection('world_transactions', { byUser: {} }), rows = (d.byUser?.[c.sender] || []).slice(-10).reverse(); return c.reply(`📜 *EXTRATO*\n\n${rows.map(x => `${new Date(x.at).toLocaleString('pt-BR')} — ${x.type} — ${fmt(x.amount)} GC`).join('\n') || 'Sem movimentações.'}`); }

async function investir(c) {
  const aa = a(c), key = String(aa[0] || '').toLowerCase(), n = Math.floor(Number(aa[1]));
  const markets = { cristal: 0.03, energia: 0.015, sombras: -0.01, almas: 0.02 }; if (!markets[key] || !Number.isFinite(n) || n <= 0) return c.reply('📈 ×investir <cristal|energia|sombras|almas> <valor>');
  const u = user(c.sender), w = ensureWorld(u); if ((u.economy?.bank || 0) < n) return c.reply('🏦 Coloque o dinheiro no banco primeiro.');
  await economy.mutateAccount(c.sender, ({user,account}) => { const world=ensureWorld(user); const r=account.withdraw(n); world.investments[key]=(world.investments[key]||0)+n; user.world=world; }, {reason:'world.investment',name:c.pushname,operationId:`world-invest:${c.sender}:${key}:${Date.now()}`});
  return c.reply(`📈 Investimento realizado em *${key}*: ${fmt(n)} GC.`);
}
async function carteira(c) { const u = user(c.sender), w = ensureWorld(u); return c.reply(`📈 *CARTEIRA*\n\n${Object.entries(w.investments).map(([k,v]) => `• ${k}: ${fmt(v)} GC`).join('\n') || 'Nenhum investimento.'}`); }
async function mercado(c) { return c.reply(`📊 *MERCADO DO VÉU*\n\n💎 Cristal: +3%\n⚡ Energia: +1,5%\n🌑 Sombras: -1%\n👻 Almas: +2%\n\nValores são fictícios e usados apenas no RPG.`); }

function battlePower(u) { return (u.rpg?.level || 1) * 10 + (u.rpg?.hp || 100) / 5 + Math.floor(Math.random() * 30); }
async function duelo(c) {
  const t = target(c); if (!t || t === c.sender) return c.reply('⚔️ Marque um adversário.');
  const x = user(c.sender), y = user(t), px = battlePower(x), py = battlePower(y), win = px >= py, winner = win ? c.sender : t;
  await save('world_battles', d => { d.matches ??= []; d.matches.push({ id: uid('BAT'), at: Date.now(), a: c.sender, b: t, winner, pa: px, pb: py }); d.matches = d.matches.slice(-5000); return d; }, { matches: [] });
  return c.reply(`⚔️ *DUELO DO VÉU*\n\n${mention(c.sender)} ⚔️ ${mention(t)}\n⚡ Poder: ${px} × ${py}\n🏆 Vencedor: ${mention(winner)}`, { mentions: [c.sender, t] });
}
async function boss(c) {
  const bosses = [{ name: 'Rei Espectral', hp: 5000, reward: 25000 }, { name: 'Aracnídeo do Abismo', hp: 7500, reward: 40000 }, { name: 'Devorador do Véu', hp: 12000, reward: 75000 }];
  const b = bosses[Math.floor(Math.random() * bosses.length)]; let power = 0, won = false;
  const u0=user(c.sender), w0=ensureWorld(u0); power=battlePower(u0)*3;
  if (w0.lastBoss && Date.now()-w0.lastBoss<6*60*60*1000) throw new Error(`Este boss está em cooldown por ${Math.ceil((6*60*60*1000-(Date.now()-w0.lastBoss))/3600000)}h.`);
  if (power >= b.hp) {
    await economy.mutateAccount(c.sender, ({user,account}) => { const w=ensureWorld(user); w.lastBoss=Date.now(); w.reputation+=10; account.credit(b.reward); user.world=w; }, {reason:'world.boss.reward',name:c.pushname,operationId:`world-boss:${c.sender}:${w0.lastBoss||0}:${b.name}`});
    won=true;
  }
  if(!won) return c.reply(`👹 *${b.name}* apareceu!\n❤️ HP: ${b.hp}\n⚔️ Seu poder: ${Math.floor(power)}\n\nTreine e volte mais forte.`);
  await c.reply(`🏆 *BOSS DERROTADO!*\n\n👹 ${b.name}\n💰 +${fmt(b.reward)} GC\n⭐ +10 reputação`); await award(c, 'boss');
}
async function dungeon(c) {
  let reward=0, energy=0;
  await economy.mutateAccount(c.sender, ({user,account}) => { const w=ensureWorld(user), now=Date.now(), cd=30*60*1000; if(w.lastDungeon&&now-w.lastDungeon<cd) throw new Error(`Dungeon em cooldown por ${Math.ceil((cd-(now-w.lastDungeon))/60000)} min.`); if(w.energy<25) throw new Error('⚡ Energia insuficiente.'); w.lastDungeon=now; w.energy-=25; reward=5000+(user.rpg?.level||1)*500; account.credit(reward); energy=w.energy; user.world=w; }, {reason:'world.dungeon.reward',name:c.pushname,operationId:`world-dungeon:${c.sender}:${Date.now()}`});
  return c.reply(`🏰 *DUNGEON CONCLUÍDA*\n💰 +${fmt(reward)} GC\n⚡ Energia: ${energy}/100`);
}

async function npcInfo(c) {
  const name = a(c)[0]; if (!name) return c.reply('🤖 ×npcinfo <nome>');
  const d = readCollection('world_npcs', { byName: {} }); const n = d.byName[name.toLowerCase()] || { name, role: 'Errante', region: 'vila', affinity: 0, trust: 0, respect: 0, memories: [] };
  return c.reply(`🤖 *NPC ${n.name}*\n\n🎭 Cargo: ${n.role}\n📍 Região: ${REGIONS[n.region]?.name || n.region}\n❤️ Afinidade: ${n.affinity}\n🤝 Confiança: ${n.trust}\n🛡️ Respeito: ${n.respect}\n🧠 Memórias: ${n.memories.length}`);
}
async function npcInteracao(c) {
  const aa = a(c), name = aa[0], act = (aa[1] || 'conversar').toLowerCase(); if (!name) return c.reply('🤖 ×npc <nome> <conversar|elogiar|rivalizar>');
  const d = readCollection('world_npcs', { byName: {} }), k = name.toLowerCase(); const n = d.byName[k] || { name, role: 'Errante', region: ensureWorld(user(c.sender)).region, affinity: 0, trust: 0, respect: 0, memories: [] };
  const delta = { conversar: [3, 3, 1], elogiar: [5, 2, 0], rivalizar: [-4, -1, 3], ajudar: [8, 5, 2] }[act] || [1, 1, 0];
  n.affinity = clamp(n.affinity + delta[0], -100, 100); n.trust = clamp(n.trust + delta[1], -100, 100); n.respect = clamp(n.respect + delta[2], -100, 100); n.memories.push({ user: c.sender, act, at: Date.now() });
  d.byName[k] = n; await save('world_npcs', () => d, { byName: {} });
  return c.reply(`🤖 ${n.name} reagiu a *${act}*.\n❤️ ${n.affinity} • 🤝 ${n.trust} • 🛡️ ${n.respect}`);
}
async function npcs(c) { const d = readCollection('world_npcs', { byName: {} }), list = Object.values(d.byName).slice(0, 30); return c.reply(`🤖 *NPCs CONHECIDOS*\n\n${list.map(n => `• ${n.name} — ${n.role} — ${REGIONS[n.region]?.name || n.region}`).join('\n') || 'Nenhum NPC registrado.'}`); }

async function legado(c) { const u = user(c.sender), w = ensureWorld(u), f = u.family || { parents: [], children: [] }, co = readCollection('mega_companies', { byId: {}, byOwner: {} }).byOwner?.[c.sender], pets = await petService.listAsync('global', c.sender); return c.reply(`📜 *LEGADO DE ${mention(c.sender)}*\n\n👨‍👩‍👧 Descendentes: ${(f.children || []).length}\n🐾 Pets: ${pets.length}\n🏢 Empresa: ${co ? 'Sim' : 'Não'}\n🏠 Domínio: ${w.house ? HOUSES[w.house][1] : 'Nenhum'}\n🏆 Conquistas: ${w.achievements.length}\n⭐ Reputação: ${w.reputation}`); }

async function evento(c) { const events = ['🌑 Lua de Sangue: monstros estão mais fortes.', '🌌 Fenda Dimensional: uma região desconhecida foi avistada.', '👻 Festival das Almas: espíritos recebem +10 reputação.', '🔥 Invasão do Abismo: prepare-se para os bosses.']; return c.reply(`🌐 *EVENTO MUNDIAL*\n\n${events[Math.floor(Math.random() * events.length)]}`); }
async function temporada(c) { const d = readCollection('world_season', { number: 1, name: 'Era do Véu', endsAt: Date.now() + 30 * 86400000 }); const days = Math.max(0, Math.ceil((d.endsAt - Date.now()) / 86400000)); return c.reply(`🏆 *TEMPORADA ${d.number} — ${d.name}*\n\n⏳ Restam ${days} dias\n🎁 Recompensas: títulos, pets, itens e Ghostcoins.`); }
async function ranking(c) { const users = readCollection('users', { byId: {} }).byId || {}; const rows = Object.values(users).map(u => ({ id: u.id, score: (u.world?.reputation || 0) + (u.rpg?.level || 1) * 10 + (u.world?.achievements?.length || 0) * 25 })).sort((x,y) => y.score - x.score).slice(0,10); return c.reply(`🏆 *RANKING DO ALÉM*\n\n${rows.map((x,i)=>`${i+1}. ${mention(x.id)} — ${x.score} pts`).join('\n') || 'Sem dados.'}`, { mentions: rows.map(x=>x.id) }); }
async function busca(c) { const s = q(c).toLowerCase(); if (!s) return c.reply('🔎 ×buscar <termo>'); const hits = Object.entries(REGIONS).filter(([k,v]) => k.includes(s) || v.name.toLowerCase().includes(s)); return c.reply(`🔎 *BUSCA DO VÉU*\n\n${hits.map(([k,v])=>`${v.icon} ${k} — ${v.name}`).join('\n') || 'Nenhum resultado.'}`); }

async function statsWorld(c) { const d = readCollection('world_stats', { commands: {}, total: 0 }); const rows = Object.entries(d.commands).sort((x,y)=>y[1]-x[1]).slice(0,10); return c.reply(`📊 *WORLD STATS*\n\n⚡ Execuções: ${fmt(d.total)}\n\n${rows.map((x,i)=>`${i+1}. ×${x[0]} — ${fmt(x[1])}`).join('\n') || 'Sem dados.'}`); }


async function empresaMundo(c) {
  const co = companyService.getByOwner(c.sender);
  if (!co) return c.reply('🏢 Você ainda não possui uma empresa. Use ×criarempresa <nome>.');
  return c.reply(`🏢 *EMPRESA 2.0*\n\n🏷️ ${co.name}\n🆔 ${co.id}\n📈 Nível: ${co.level}\n💰 Capital: ${fmt(co.capital)} GC\n📊 Receita: ${fmt(co.revenue)} GC\n🏭 Filiais: ${co.branches || 0}\n🤖 Funcionários NPC: ${(co.employees || []).length}\n\n×uparpresa • ×abrirfilial • ×treinarnpc <n> • ×promovernpc <n>`);
}
async function createCompany(c) {
  const name=q(c); if(!name) return c.reply('🏢 ×criarempresa <nome>');
  try { const co=await companyService.create(c.sender,name); return c.reply(`🏢 *EMPRESA CRIADA*\n\n🏷️ ${co.name}\n🆔 ${co.id}\n💰 Capital: ${fmt(co.capital)} GC`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível criar a empresa.'}`); }
}
async function hireCompanyNpc(c) {
  const aa=a(c),name=aa[0],role=aa.slice(1).join(' ')||'Assistente'; if(!name) return c.reply('🤖 ×contratarnpc <nome> <cargo>');
  try { const e=await companyService.hire(c.sender,name,role); return c.reply(`🤖 NPC contratado: ${e.name} — ${e.role}\n💰 Salário por ciclo: ${fmt(e.salary)} GC`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível contratar o NPC.'}`); }
}
async function fireCompanyNpc(c) {
  const n=Number(a(c)[0]); if(!Number.isInteger(n)||n<1) return c.reply('🤖 ×demitirnpc <número>');
  try { const e=await companyService.fire(c.sender,n); return c.reply(`📤 ${e.name} foi demitido.`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível demitir o NPC.'}`); }
}
async function rankingEmpresas(c) {
  const rows=companyService.ranking(10);
  return c.reply(`🏢 *RANKING EMPRESARIAL*\n\n${rows.map((x,i)=>`${i+1}. ${x.name} — ${fmt(x.capital)} GC`).join('\n')||'Nenhuma empresa.'}`);
}
async function uparEmpresa(c) {
  try { const co=await companyService.upgrade(c.sender,'nivel'); return c.reply(`⬆️ Empresa evoluída para o nível ${co.level}.\n📈 Receita: ${fmt(co.revenue)} GC`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível evoluir a empresa.'}`); }
}
async function filial(c) {
  try { const co=await companyService.upgrade(c.sender,'filial'); return c.reply(`🏭 Filial inaugurada! Total: ${co.branches}.\n💰 Capital restante: ${fmt(co.capital)} GC`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível abrir a filial.'}`); }
}
async function treinarNpc(c) {
  const n=Number(a(c)[0]); if(!Number.isInteger(n)||n<1) return c.reply('🤖 ×treinarnpc <número>');
  try { const e=await companyService.train(c.sender,n); return c.reply(`🎓 ${e.name} foi treinado. 🧠 Skill ${e.skill}.`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível treinar o NPC.'}`); }
}
async function promoverNpc(c) {
  const n=Number(a(c)[0]); if(!Number.isInteger(n)||n<1) return c.reply('🤖 ×promovernpc <número>');
  try { const e=await companyService.promote(c.sender,n); return c.reply(`📈 ${e.name} foi promovido a ${e.role}.`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível promover o NPC.'}`); }
}
async function folha(c) {
  try { const r=companyService.payroll(c.sender); return c.reply(`💼 *FOLHA EMPRESARIAL*\n\n👥 NPCs: ${r.count}\n💰 Custo por ciclo: ${fmt(r.total)} GC\n🏦 Caixa: ${fmt(r.company.capital)} GC`); }
  catch(e) { return c.reply(`❌ ${e?.message || 'Não foi possível consultar a folha.'}`); }
}

async function criarReino(c) {
  const name = q(c); if (!name) return c.reply('👑 ×criarreino <nome>');
  const cost = 1000000;
  let k = null;
  const op = `world-kingdom:create:${c.sender}:${name.slice(0,60)}`;
  const existing = readCollection('world_kingdoms', { byId: {}, byOwner: {} });
  if (existing.byOwner?.[c.sender]) return c.reply('👑 Você já governa um reino.');
  try {
    await economy.mutateAccount(c.sender, ({ user, account }) => {
      account.debit(cost);
      return { amount: -cost };
    }, {
      reason: 'world.kingdom.create', operationId: op,
      userMutator: ({ user }) => { const w = ensureWorld(user); w.reputation += 25; user.world = w; },
      extraSteps: [{ collection: 'world_kingdoms', update: d => {
        d.byId ??= {}; d.byOwner ??= {};
        if (d.byOwner[c.sender]) throw new ValidationError('Você já governa um reino.');
        k = { id: uid('REI'), name: name.slice(0,60), owner: c.sender, level: 1, treasury: cost, territory: 1, allies: [], createdAt: Date.now(), operationId: op };
        d.byId[k.id] = k; d.byOwner[c.sender] = k.id; return d;
      }}]
    });
  } catch (e) { return c.reply(e?.message || 'Não foi possível fundar o reino.'); }
  return c.reply(`👑 *REINO FUNDADO*

🏰 ${k.name}
🆔 ${k.id}
💰 Tesouro: ${fmt(cost)} GC
🗺️ Territórios: 1`);
}
async function reino(c) { const d = readCollection('world_kingdoms', { byId: {}, byOwner: {} }), k = d.byId?.[d.byOwner?.[c.sender]]; if (!k) return c.reply('👑 Você não possui um reino.'); return c.reply(`👑 *${k.name}*\n\n🆔 ${k.id}\n📈 Nível: ${k.level}\n💰 Tesouro: ${fmt(k.treasury)} GC\n🗺️ Territórios: ${k.territory}\n🤝 Alianças: ${k.allies.length}`); }
async function rankingReinos(c) { const d = readCollection('world_kingdoms', { byId: {} }), r = Object.values(d.byId||{}).sort((x,y)=>(y.territory-x.territory)+(y.level-x.level)).slice(0,10); return c.reply(`👑 *RANKING DOS REINOS*\n\n${r.map((x,i)=>`${i+1}. ${x.name} — Nv.${x.level} — ${x.territory} territórios`).join('\n') || 'Nenhum reino.'}`); }
async function misterio(c) { const cases = [['O Túmulo Sem Nome','Três símbolos aparecem em um túmulo abandonado. Descubra quem está tentando quebrar o selo.'],['A Alma Desaparecida','Uma alma sumiu do registro do Purgatório. Siga as pistas antes do amanhecer.'],['A Teia do Abismo','Uma criatura aracnídea está deixando marcas nas fronteiras. Descubra a origem.']]; const [title,desc]=cases[Math.floor(Math.random()*cases.length)]; await updateCollection('world_cases', d=>{ d.active??={}; if(d.active[c.sender]) throw new Error('Você já possui um caso ativo.'); d.active[c.sender]={title,desc,at:Date.now(),steps:0}; return d; }, {active:{}}); return c.reply(`🕵️ *CASO: ${title}*\n\n${desc}\n\nUse ×pista, ×investigar e ×resolver para avançar.`); }
async function pista(c) { const d=readCollection('world_cases',{active:{}}), z=d.active?.[c.sender]; if(!z) return c.reply('🕵️ Nenhum caso ativo. Use ×misterio.'); z.steps++; await save('world_cases',()=>d,{active:{}}); const clues=['🩸 Há uma marca recente perto do local.','🕯️ Uma testemunha ouviu passos depois da meia-noite.','🕷️ Pequenas teias levam para uma passagem escondida.','📜 O registro oficial foi alterado há pouco.']; return c.reply(`🔎 Pista ${z.steps}: ${clues[(z.steps-1)%clues.length]}`); }
async function resolver(c) {
  const op = `world-case:resolve:${c.sender}`;
  try {
    await economy.mutateAccount(c.sender, ({ account, user }) => {
      const w = ensureWorld(user);
      account.credit(7500);
      w.reputation += 5; user.world = w;
      return { amount: 7500 };
    }, {
      reason: 'world.case.resolve', operationId: op,
      extraSteps: [{ collection: 'world_cases', update: d => {
        d.active ??= {}; const z = d.active[c.sender];
        if (!z) throw new ValidationError('🕵️ Nenhum caso ativo.');
        if ((z.steps || 0) < 2) throw new ValidationError('🕵️ Você ainda não reuniu pistas suficientes.');
        delete d.active[c.sender]; return d;
      }}]
    });
  } catch (e) { return c.reply(e?.message || 'Não foi possível resolver o caso.'); }
  return c.reply(`🕵️ *CASO RESOLVIDO!*
💰 +7.500 GC
⭐ +5 reputação`);
}

export async function register() {
  const defs = [
    ['mundo', mundo, 'Mostra o mundo do Além.'],
    ['mapa', mapa, 'Mostra o mapa do Além.'],
    ['local', local, 'Mostra sua localização atual.'],
    ['viajar', viajar, 'Viaja para outra região.'],
    ['descansar', descansar, 'Recupera energia.'],
    ['perfil', perfil, 'Mostra seu perfil do mundo.'],
    ['conquistas', conquistas, 'Mostra suas conquistas.'],
    ['casa', casa, 'Mostra sua casa.'],
    ['comprarcasa', comprarCasa, 'Compra uma casa.'],
    ['melhorarcasa', melhorarCasa, 'Melhora sua casa.'],
    ['inventario', inventario, 'Mostra seu inventário.'],
    ['loja', loja, 'Mostra a Loja do Véu.'],
    ['compraritem', comprarItem, 'Compra itens na Loja do Véu.'],
    ['usaritem', usarItem, 'Usa um item do inventário.'],
    ['banco', banco, 'Mostra sua conta bancária.'],
    ['depositar', depositar, 'Deposita Ghostcoins no banco.'],
    ['sacar', sacar, 'Saca Ghostcoins do banco.'],
    ['extrato', extrato, 'Mostra seu extrato bancário.'],
    ['investir', investir, 'Investe Ghostcoins no mercado.'],
    ['carteira', carteira, 'Mostra sua carteira de investimentos.'],
    ['mercado', mercado, 'Mostra o Mercado do Véu.'],
    ['duelo', duelo, 'Desafia outro jogador para um duelo.'],
    ['boss', boss, 'Enfrenta um boss do Além.'],
    ['dungeon', dungeon, 'Entra em uma dungeon.'],
    ['npcinfo', npcInfo, 'Mostra informações de um NPC.'],
    ['npc', npcInteracao, 'Interage com um NPC.'],
    ['npcs', npcs, 'Lista os NPCs conhecidos.'],
    ['legado', legado, 'Mostra seu legado no Além.'],
    ['evento', evento, 'Mostra o evento mundial atual.'],
    ['temporada', temporada, 'Mostra a temporada atual.'],
    ['ranking', ranking, 'Mostra o ranking do Além.'],
    ['buscar', busca, 'Busca regiões do Véu.'],
    ['worldstats', statsWorld, 'Mostra as estatísticas do World Engine.'],
    ['empresa', empresaMundo, 'Mostra sua empresa', ['minhaempresa', 'empresa_info', 'funcionariosnpc', 'funcionarios']],
    ['criarempresa', createCompany, 'Cria uma empresa', ['fundarempresa']],
    ['contratarnpc', hireCompanyNpc, 'Contrata um NPC para sua empresa', ['hirenpc']],
    ['demitirnpc', fireCompanyNpc, 'Demite um NPC da sua empresa', ['firenpc']],
    ['rankingempresa', rankingEmpresas, 'Mostra o ranking empresarial', ['rankempresa']],
    ['uparpresa', uparEmpresa, 'Melhora sua empresa', ['empresaexpandir', 'expandirempresa']],
    ['abrirfilial', filial, 'Abre uma filial da empresa'],
    ['treinarnpc', treinarNpc, 'Treina um NPC da empresa'],
    ['promovernpc', promoverNpc, 'Promove um NPC da empresa'],
    ['folha', folha, 'Mostra a folha empresarial'],
    ['criarreino', criarReino, 'Cria seu próprio reino.'],
    ['reino', reino, 'Mostra seu reino.'],
    ['rankingreinos', rankingReinos, 'Mostra o ranking dos reinos.'],
    ['misterio', misterio, 'Inicia um caso de mistério.'],
    ['pista', pista, 'Recebe uma pista do caso ativo.'],
    ['resolver', resolver, 'Resolve o caso ativo.'],
  ];

  for (const [name, handler, description, aliases = []] of defs) {
    registerCommand({
      name,
      aliases,
      category: 'world',
      plugin: 'worldEngine',
      permission: Role.USER,
      cooldown: 2,
      description,
      handler,
    });
  }
}

export default { register };
