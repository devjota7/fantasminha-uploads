import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { getUser, upsertUser, readCollection } from '../../database/store.js';
import { ValidationError } from '../../core/errors.js';
import * as specialRoleManager from '../../services/specialRoleManagement.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCommand({
    name: 'vip',
    aliases: ['premium', 'meuvip'],
    category: 'premium',
    plugin: 'premium',
    cooldown: 3,
    handler: async (ctx) => {
      const u = getUser(ctx.sender);
      const p = u?.premium || { active: false };
      const active = p.active && (!p.until || p.until > Date.now());
      const { vipSummary } = await import('../../services/vipBenefits.js');
      const s = vipSummary(ctx.sender);
      await ctx.reply(tag(
        active
          ? `💎 *Premium ativo*\nPlano: *${p.plan || 'custom'}*\nAté: *${p.until ? new Date(p.until).toLocaleDateString('pt-BR') : '∞'}*\nCooldown ×${s.cooldownMult}\nDaily bônus +${s.dailyBonus} GC\nLimites maiores de download/IA`
          : `💎 Sem premium (free).\naddvip @user <dias> [bronze|prata|ouro]`
      ));
    }
  });

  registerCommand({
    name: 'addvip',
    aliases: ['concedervip'],
    category: 'premium',
    plugin: 'premium',
    permission: Role.OWNER,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      const days = Number(ctx.args?.find((a) => /^\d+$/.test(a))) || 30;
      const plan = ctx.args?.find((a) => /bronze|prata|ouro/i.test(a)) || 'prata';
      if (!target) throw new ValidationError('addvip @user <dias> [plano]');
      const result = await specialRoleManager.grant(ctx, 'vip', target, { days, plan });
      await ctx.reply(tag(`💎 ${result.message || `VIP *${plan}* por *${days}* dias.`}`));
    }
  });

  registerCommand({
    name: 'delvip',
    aliases: ['rmvvip'],
    category: 'premium',
    plugin: 'premium',
    permission: Role.OWNER,
    cooldown: 3,
    handler: async (ctx) => {
      const target = ctx.mentioned?.[0];
      if (!target) throw new ValidationError('delvip @user');
      const result = await specialRoleManager.revoke(ctx, 'vip', target);
      await ctx.reply(tag(`💎 ${result.message || 'Premium removido.'}`));
    }
  });

  registerCommand({
    name: 'planosvip',
    category: 'premium',
    plugin: 'premium',
    cooldown: 5,
    handler: async (ctx) => {
      const plans = readCollection('premium_plans', {});
      const lines = Object.entries(plans).map(([k, v]) => `• *${k}* — ${v.days}d`);
      await ctx.reply(tag(`💎 *Planos*\n\n${lines.join('\n') || 'Nenhum'}`));
    }
  });
}

export default { register };
