import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { downloadMedia, searchYoutube, probeUrl } from '../../services/download.js';
import { ValidationError } from '../../core/errors.js';
import { canUseVipBenefit } from '../../services/vipBenefits.js';
import { createPlayService } from '../../../dados/src/services/play/playService.js';

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCommand({
  name: 'play',
  aliases: ['yt', 'ytmp3'],
  category: 'downloads',
  plugin: 'downloads',
  cooldown: 8,
  timeoutMs: 300000,
  description: 'Busca e baixa áudio do YouTube.',
  handler: async (ctx) => {
    const query = String(ctx.q || '').trim();
    if (!query) throw new ValidationError('play <nome da música>');

    const limit = await canUseVipBenefit(ctx.sender, 'download');
    if (!limit.ok) throw new ValidationError(limit.msg);

    const bot = ctx.sock || ctx.socket;
    if (!bot || typeof bot.sendMessage !== 'function') {
      throw new ValidationError('O mecanismo de envio de áudio está indisponível no momento.');
    }

    const service = createPlayService({
      bot,
      chatId: ctx.from,
      quoted: ctx.message,
      reply: ctx.reply,
      requester: {
        participantId: ctx.sender,
        displayName: ctx.pushname || ctx.mentionName || 'Usuário'
      }
    });

    const result = await service.execute(query);
    if (!result?.ok && result?.message) {
      await ctx.reply(result.message);
    }
  }
  });
    registerCommand({
    name: 'dl',
    aliases: ['download', 'baixar'],
    category: 'downloads',
    plugin: 'downloads',
    cooldown: 10,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('dl <url>');
      const limit = await canUseVipBenefit(ctx.sender, 'download');
      if (!limit.ok) throw new ValidationError(limit.msg);
      await ctx.reply(tag('📥 Processando via DownloadService…'));
      const r = await downloadMedia({ url: ctx.q.trim(), type: 'auto' });
      if (!r.ok) throw new ValidationError(r.message || 'Falha no download.');
      const downloadedBuffer = Buffer.isBuffer(r.buffer) ? r.buffer : Buffer.isBuffer(r.data?.buffer) ? r.data.buffer : null;
      const downloadedUrl = r.url || r.data?.url || r.data?.dlurl || null;
      if (!downloadedBuffer && !downloadedUrl) throw new ValidationError('O provider não retornou um arquivo para envio.');
      const mime = r.mimeType || r.mimetype || r.data?.mimeType || r.data?.mimetype || 'application/octet-stream';
      const fileName = r.filename || r.data?.filename || `download-${Date.now()}`;
      if (downloadedBuffer) {
        await ctx.sendMessage(ctx.from, { document: downloadedBuffer, fileName, mimetype: mime });
      } else {
        await ctx.sendMessage(ctx.from, { document: { url: downloadedUrl }, fileName, mimetype: mime });
      }
      await ctx.reply(tag(
        `✅ *${r.provider}* OK (${r.ms}ms)\n${r.title ? `📌 ${r.title}\n` : ''}📎 Arquivo enviado.`
      ));
    }
  });

  registerCommand({
    name: 'probeurl',
    category: 'downloads',
    plugin: 'downloads',
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('probeurl <url>');
      const p = await probeUrl(ctx.q);
      await ctx.reply(tag(`🔬 Provider: *${p.provider}*\nStatus: ${p.status || p.error}\nTipo: ${p.contentType || '?'}\nSize: ${p.size || 0}`));
    }
  });
}

export default { register };
