/**
 * 🕷️ PERFIL ARANHA
 * Camada visual exclusiva sobre o perfil oficial do Fantasminha.
 * Não duplica identidade: dados básicos vêm de buildPublicProfile().
 */
import crypto from 'node:crypto';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection } from '../../database/store.js';
import { buildPublicProfile } from '../../services/profile.js';
import { BOT_ROLE, getBotRole, grantBotRole, revokeBotRole, listBotRoles } from '../../services/botRoles.js';
import { resolveUserIdentity } from '../../platform/identity/resolver.js';
import config from '../../core/config.js';
import * as specialRoleManager from '../../services/specialRoleManagement.js';

const PLUGIN = 'aranha';
const TAG = '× 👻 FANTASMINHA';
const DEFAULT = { byUser: {} };
const norm = v => String(v || '').trim().toLowerCase();
const baseId = v => norm(v).split('@')[0].split(':')[0];
const sameId = (a, b) => norm(a) === norm(b) || baseId(a) === baseId(b);
const esc = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const num = v => Number.isFinite(Number(v)) ? Number(v) : 0;
const fmt = v => num(v).toLocaleString('pt-BR');
const clamp = (v,a,b) => Math.max(a, Math.min(b, num(v)));
const TEIA_DURATION_MS = 20_000;
const TEIA_COOLDOWN_MS = 8_000;
const TEIA_ESCAPE_CHANCE = 0.45;
const WEB_DEFAULT = { byKey: {}, history: [] };

function webKey(groupId, targetId) {
  return `${norm(groupId)}::${norm(targetId)}`;
}

function readWebState(groupId, targetId) {
  const d = readCollection('spider_web', WEB_DEFAULT);
  return d.byKey?.[webKey(groupId, targetId)] || null;
}

async function cleanupExpiredWebs(now = Date.now()) {
  await updateCollection('spider_web', d => {
    d.byKey ||= {};
    for (const [key, web] of Object.entries(d.byKey)) {
      if (!web?.expiresAt || web.expiresAt <= now) delete d.byKey[key];
    }
    return d;
  }, WEB_DEFAULT);
}

async function writeWebResult(result) {
  await updateCollection('spider_web', d => {
    d.byKey ||= {};
    d.history ||= [];
    const key = webKey(result.groupId, result.targetId);
    delete d.byKey[key];
    d.history.push(result);
    if (d.history.length > 1000) d.history.splice(0, d.history.length - 1000);
    return d;
  }, WEB_DEFAULT);
}

function activeWebForActor(groupId, actorId) {
  const d = readCollection('spider_web', WEB_DEFAULT);
  return Object.values(d.byKey || {}).find(web => web.groupId === groupId && sameId(web.actorId, actorId)) || null;
}

function activeWebForTarget(groupId, targetId) {
  return readWebState(groupId, targetId);
}

function remainingSeconds(web, now = Date.now()) {
  return Math.max(1, Math.ceil((Number(web.expiresAt) - now) / 1000));
}

async function createWeb(ctx, actorId, targetId) {
  await cleanupExpiredWebs();
  const now = Date.now();
  const existingTarget = activeWebForTarget(ctx.from, targetId);
  if (existingTarget) throw new Error('🕸️ Essa pessoa já está presa em uma teia ativa.');
  const existingActor = activeWebForActor(ctx.from, actorId);
  if (existingActor) throw new Error('🕷️ Você já lançou uma teia que ainda está ativa.');

  const last = readCollection('spider_web', WEB_DEFAULT).history?.slice().reverse().find(x => x.groupId === ctx.from && sameId(x.actorId, actorId) && x.type === 'launch');
  if (last && now - Number(last.at || 0) < TEIA_COOLDOWN_MS) {
    const wait = Math.ceil((TEIA_COOLDOWN_MS - (now - Number(last.at || 0))) / 1000);
    throw new Error(`🕸️ Sua teia ainda está recarregando. Aguarde ${wait}s.`);
  }

  const web = {
    id: `WEB-${crypto.randomBytes(5).toString('hex').toUpperCase()}`,
    groupId: ctx.from,
    actorId,
    targetId,
    createdAt: now,
    expiresAt: now + TEIA_DURATION_MS,
    escapeAttempts: 0,
    maxEscapeAttempts: 1,
    type: 'active'
  };
  await updateCollection('spider_web', d => {
    d.byKey ||= {};
    d.history ||= [];
    d.byKey[webKey(ctx.from, targetId)] = web;
    d.history.push({ type:'launch', at:now, groupId:ctx.from, actorId, targetId, webId:web.id });
    if (d.history.length > 1000) d.history.splice(0, d.history.length - 1000);
    return d;
  }, WEB_DEFAULT);
  return web;
}

async function attemptEscape(ctx, targetId) {
  const web = activeWebForTarget(ctx.from, targetId);
  if (!web) throw new Error('🕸️ Você não está preso em nenhuma teia ativa.');
  if (!sameId(web.targetId, targetId)) throw new Error('🕸️ Esta teia não pertence a você.');
  if (web.expiresAt <= Date.now()) {
    await writeWebResult({ type:'expired', at:Date.now(), groupId:ctx.from, actorId:web.actorId, targetId:web.targetId, webId:web.id });
    return { outcome:'expired', web };
  }
  if (web.escapeAttempts >= web.maxEscapeAttempts) throw new Error('💨 Você já tentou escapar desta teia.');

  const success = crypto.randomInt(0, 10_000) / 10_000 < TEIA_ESCAPE_CHANCE;
  if (success) {
    await writeWebResult({ type:'escape', at:Date.now(), groupId:ctx.from, actorId:web.actorId, targetId:web.targetId, webId:web.id });
    return { outcome:'escape', web };
  }

  await updateCollection('spider_web', d => {
    const key = webKey(ctx.from, targetId);
    if (d.byKey?.[key]) d.byKey[key].escapeAttempts = 1;
    return d;
  }, WEB_DEFAULT);
  return { outcome:'failed_escape', web };
}


function target(ctx) {
  return ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || ctx.sender;
}

function isOwner(ctx) { return !!ctx.isOwner; }

async function resolvedIdentity(ctx, userId) {
  const requested = String(userId || '').trim();
  if (!requested) return { canonical: requested, candidates: [requested] };
  try {
    const identity = await resolveUserIdentity({ ...ctx, sender: requested }, requested);
    const canonical = identity.realJid || (identity.number ? `${identity.number}@s.whatsapp.net` : null) || identity.requested || requested;
    const candidates = [...new Set([
      canonical, identity.requested, identity.lid, identity.raw?.id, identity.raw?.jid,
      identity.raw?.participant, requested
    ].filter(Boolean).map(value => String(value).trim().toLowerCase()))];
    return { canonical, candidates };
  } catch {
    return { canonical: requested, candidates: [requested.toLowerCase()] };
  }
}

function existingSpiderKey(candidates) {
  const d = readCollection('spider_profile', DEFAULT);
  return candidates.find(key => d.byUser?.[key]) || null;
}

async function canonicalUserId(ctx, userId) {
  return (await resolvedIdentity(ctx, userId)).canonical;
}

async function spiderStorageKey(ctx, userId) {
  const identity = await resolvedIdentity(ctx, userId);
  return existingSpiderKey(identity.candidates) || identity.canonical;
}

function readSpider(userId) {
  const d = readCollection('spider_profile', DEFAULT);
  return d.byUser?.[userId] || null;
}

async function upsertSpider(userId, patch = {}) {
  let out;
  await updateCollection('spider_profile', d => {
    d.byUser ||= {};
    const prev = d.byUser[userId] || {
      userId,
      enabled: false,
      spiderLevel: 1,
      spiderXp: 0,
      title: 'Aranha',
      badges: [],
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    out = d.byUser[userId] = { ...prev, ...patch, userId, updatedAt: Date.now() };
    return d;
  }, DEFAULT);
  return out;
}

const WEB_XP = Object.freeze({ launch: 2, escape: 5, failedEscape: 10, capture: 25 });

function normalizeWebStats(stats = {}) {
  return {
    launched: Math.max(0, Math.floor(num(stats.launched))),
    captures: Math.max(0, Math.floor(num(stats.captures))),
    escapes: Math.max(0, Math.floor(num(stats.escapes))),
    escapeAttempts: Math.max(0, Math.floor(num(stats.escapeAttempts))),
    failedEscapes: Math.max(0, Math.floor(num(stats.failedEscapes))),
    xpEarned: Math.max(0, Math.floor(num(stats.xpEarned))),
    lastEventAt: num(stats.lastEventAt) || 0
  };
}

function calculateSpiderProgress(xp, level = 1) {
  let currentXp = Math.max(0, Math.floor(num(xp)));
  let currentLevel = Math.max(1, Math.floor(num(level)) || 1);
  while (currentXp >= currentLevel * 1000) {
    currentXp -= currentLevel * 1000;
    currentLevel += 1;
  }
  return { spiderLevel: currentLevel, spiderXp: currentXp };
}

function badgesForWeb(stats) {
  const badges = [];
  if (stats.launched >= 1) badges.push('Primeira Teia');
  if (stats.launched >= 10) badges.push('Tecelão');
  if (stats.captures >= 10) badges.push('Caçador de Teias');
  if (stats.captures >= 25) badges.push('Mestre da Teia');
  if (stats.escapes >= 10) badges.push('Teia Inquebrável');
  return badges;
}

async function awardWebProgress(userId, event) {
  const amount = WEB_XP[event] || 0;
  let result;
  await updateCollection('spider_profile', d => {
    d.byUser ||= {};
    const prev = d.byUser[userId] || {
      userId, enabled: false, spiderLevel: 1, spiderXp: 0, title: 'Aranha', badges: [],
      webStats: normalizeWebStats(), createdAt: Date.now(), updatedAt: Date.now()
    };
    const stats = normalizeWebStats(prev.webStats);
    if (event === 'launch') stats.launched += 1;
    if (event === 'escape') { stats.escapes += 1; stats.escapeAttempts += 1; }
    if (event === 'failedEscape') { stats.failedEscapes += 1; stats.escapeAttempts += 1; }
    if (event === 'capture') stats.captures += 1;
    stats.xpEarned += amount;
    stats.lastEventAt = Date.now();
    const progress = calculateSpiderProgress(num(prev.spiderXp) + amount, prev.spiderLevel);
    const badges = [...new Set([...(Array.isArray(prev.badges) ? prev.badges : []), ...badgesForWeb(stats)])];
    result = d.byUser[userId] = { ...prev, ...progress, badges, webStats:stats, userId, updatedAt:Date.now() };
    return d;
  }, DEFAULT);
  return { ...result, xpGained: amount, webEvent:event };
}

async function registerWebLaunch(userId) {
  return awardWebProgress(userId, 'launch');
}

async function registerWebOutcome(userId, outcome) {
  return awardWebProgress(userId, outcome);
}

async function audit(ctx, action, details = {}) {
  await updateCollection('audit', d => {
    d.events ||= [];
    d.events.push({ id:`AUD-${crypto.randomBytes(3).toString('hex').toUpperCase()}`, at:Date.now(), action, actor:ctx.sender, group:ctx.from || null, details });
    if (d.events.length > 10000) d.events.splice(0, d.events.length - 10000);
    return d;
  }, { events:[] });
}

async function sessionAccess(ctx, userId) {
  const resolvedUserId = await resolvedIdentity(ctx, userId);
  const resolvedCallerId = await canonicalUserId(ctx, ctx.sender);
  const storageKey = existingSpiderKey(resolvedUserId.candidates) || resolvedUserId.canonical;
  const session = readSpider(storageKey);
  const allowed = isOwner(ctx) || (!!session?.enabled && sameId(session.userId, storageKey) && sameId(resolvedUserId.canonical, resolvedCallerId));
  return { allowed, userId: resolvedUserId.canonical, storageKey, session };
}

function gameStats(groupId, userId) {
  const d = readCollection('stats_engine', { players:{} });
  const direct = d.players?.[`${groupId || 'global'}::${userId}`];
  if (direct) return direct;
  const found = Object.values(d.players || {}).find(x => x.groupId === (groupId || 'global') && sameId(x.userId, userId));
  return found || { plays:0, wins:0, losses:0, draws:0, xp:0, score:0, streak:0, bestStreak:0 };
}

function webSvg(p, spider, stats) {
  const W = 1080, H = 1350;
  const name = esc(p.name || 'Não informado');
  const nick = esc(p.nick || 'Não cadastrado');
  const birthday = esc(p.birthday || 'Não cadastrado');
  const role = esc(p.role || 'Membro');
  const trail = esc(p.number || 'Não informado');
  const messages = fmt(p.messages);
  const botUses = fmt(p.botUses);
  const plays = fmt(stats.plays);
  const wins = fmt(stats.wins);
  const score = fmt(stats.score);
  const level = Math.max(1, Math.floor(num(spider.spiderLevel) || 1));
  const xp = Math.max(0, num(spider.spiderXp));
  const xpNext = level * 1000;
  const xpPct = clamp((xp / Math.max(1, xpNext)) * 100, 0, 100);
  const title = esc(spider.title || 'Aranha');
  const badge = esc((spider.badges || []).length ? `${spider.badges.length} distintivo(s)` : 'Sem distintivos');
  const webStats = normalizeWebStats(spider.webStats);
  const rings = Math.min(10, 4 + Math.floor(level / 5));
  const spokes = 12;
  const cx = 540, cy = 555;
  const web = [];
  for (let r=1; r<=rings; r++) {
    const rr = 105 + r*48;
    const pts = [];
    for (let i=0;i<spokes;i++) {
      const a = (Math.PI*2*i/spokes) - Math.PI/2;
      pts.push(`${(cx+Math.cos(a)*rr).toFixed(1)},${(cy+Math.sin(a)*rr).toFixed(1)}`);
    }
    web.push(`<polygon points="${pts.join(' ')}" fill="none" stroke="#aeb6c1" stroke-opacity="${0.18 + r*0.025}" stroke-width="2"/>`);
  }
  for (let i=0;i<spokes;i++) {
    const a = (Math.PI*2*i/spokes) - Math.PI/2;
    web.push(`<line x1="${cx}" y1="${cy}" x2="${cx+Math.cos(a)*600}" y2="${cy+Math.sin(a)*600}" stroke="#e6e9ed" stroke-opacity="0.25" stroke-width="2"/>`);
  }
  const nodeDots = Array.from({length:spokes},(_,i)=>{
    const a=(Math.PI*2*i/spokes)-Math.PI/2, x=cx+Math.cos(a)*585, y=cy+Math.sin(a)*585;
    return `<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="7" fill="#e32632"/>`;
  }).join('');
  const spiderGraphic = `
    <g transform="translate(${cx} ${cy})">
      <ellipse cx="0" cy="18" rx="92" ry="116" fill="#12151a" stroke="#e32632" stroke-width="6"/>
      <circle cx="0" cy="-82" r="62" fill="#12151a" stroke="#e32632" stroke-width="6"/>
      <path d="M-32 -88 L-8 -104 L-20 -54 Z M32 -88 L8 -104 L20 -54 Z" fill="#f2f4f6" stroke="#e32632" stroke-width="3"/>
      <path d="M-80 -35 L-180 -110 M-92 -5 L-205 -25 M-86 35 L-185 85 M80 -35 L180 -110 M92 -5 L205 -25 M86 35 L185 85" stroke="#e32632" stroke-width="9" stroke-linecap="round"/>
      <path d="M-40 28 Q0 70 40 28 M-52 50 Q0 92 52 50" fill="none" stroke="#e32632" stroke-width="4" opacity=".8"/>
    </g>`;
  const panel = (x,y,w,h,title,rows) => `<g><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="24" fill="#090b0f" fill-opacity="0.92" stroke="#d8dde3" stroke-opacity="0.22" stroke-width="2"/><text x="${x+26}" y="${y+38}" fill="#e32632" font-family="Arial" font-size="23" font-weight="700">${esc(title)}</text>${rows.map((r,i)=>`<text x="${x+26}" y="${y+78+i*42}" fill="#f2f4f6" font-family="Arial" font-size="22"><tspan fill="#aeb6c1">${esc(r[0])}</tspan><tspan dx="10" font-weight="700">${esc(r[1])}</tspan></text>`).join('')}</g>`;
  return `<?xml version="1.0" encoding="UTF-8"?>
  <svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <radialGradient id="bg"><stop offset="0" stop-color="#161b22"/><stop offset="1" stop-color="#050608"/></radialGradient>
      <filter id="glow"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    </defs>
    <rect width="100%" height="100%" fill="url(#bg)"/>
    <path d="M0 80 Q270 0 540 80 T1080 80" fill="none" stroke="#e32632" stroke-opacity=".35" stroke-width="4"/>
    <text x="540" y="70" text-anchor="middle" fill="#f5f7fa" font-family="Arial" font-size="38" font-weight="800" letter-spacing="4">PERFIL DA ARANHA</text>
    <text x="540" y="105" text-anchor="middle" fill="#aeb6c1" font-family="Arial" font-size="17" letter-spacing="3">A MESMA IDENTIDADE • UMA NOVA TEIA</text>
    <g filter="url(#glow)">${web.join('')}${nodeDots}</g>
    ${panel(55,185,355,270,'IDENTIDADE CIVIL',[['Nome',name],['Codinome',nick],['Dia da Picada',birthday],['Posição na Teia',role]])}
    ${panel(670,185,355,270,'RASTRO-ARANHA',[['Rastro',trail],['Vozes na Teia',messages],['Uso do Fantasminha',botUses],['Título',title]])}
    ${spiderGraphic}
    <text x="540" y="725" text-anchor="middle" fill="#f2f4f6" font-family="Arial" font-size="34" font-weight="800">${name}</text>
    <text x="540" y="757" text-anchor="middle" fill="#e32632" font-family="Arial" font-size="21" font-weight="700" letter-spacing="3">${title}</text>
    <rect x="290" y="790" width="500" height="3" fill="#e32632" opacity=".7"/>
    ${panel(55,830,470,270,'TEIA PESSOAL',[['Nível da Teia',String(level)],['Experiência-Aranha',fmt(xp)],['Próximo nível',fmt(xpNext)],['Distintivos',badge]])}
    ${panel(555,830,470,270,'REGISTROS DA TEIA',[['Teias lançadas',fmt(webStats.launched)],['Capturas',fmt(webStats.captures)],['Fugas',fmt(webStats.escapes)],['Tentativas de fuga',fmt(webStats.escapeAttempts)]])}
    <text x="540" y="1145" text-anchor="middle" fill="#aeb6c1" font-family="Arial" font-size="18">PROGRESSO DA TEIA</text>
    <rect x="210" y="1165" width="660" height="22" rx="11" fill="#171b21" stroke="#68717d" stroke-opacity=".35"/>
    <rect x="210" y="1165" width="${6.6*xpPct}" height="22" rx="11" fill="#e32632"/>
    <text x="540" y="1218" text-anchor="middle" fill="#f2f4f6" font-family="Arial" font-size="19" font-weight="700">${fmt(xp)} / ${fmt(xpNext)} XP • ${xpPct.toFixed(0)}%</text>
    <text x="540" y="1275" text-anchor="middle" fill="#e32632" font-family="Arial" font-size="18" font-weight="700" letter-spacing="3">FANTASMINHA • ARQUIVO ARANHA</text>
    <text x="540" y="1305" text-anchor="middle" fill="#7f8995" font-family="Arial" font-size="14">PERFIL DINÂMICO • DADOS REAIS • ACESSO RESTRITO</text>
  </svg>`;
}

async function renderProfile(ctx, userId, storageKey = userId) {
  const p = await buildPublicProfile({
    userId: ctx.sender,
    displayUserId: userId,
    groupId: ctx.from || 'private',
    pushname: ctx.pushname || '',
    groupParticipants: ctx.groupParticipants || [],
    groupParticipantObjects: ctx.groupParticipantObjects || [],
    groupAdmins: ctx.groupAdmins || [],
    groupOwner: ctx.groupOwner || null,
    resolvePNForLID: ctx.resolvePNForLID
  });
  const spider = readSpider(storageKey) || readSpider(p.displayUserId) || { spiderLevel:1, spiderXp:0, title:'Aranha', badges:[] };
  const stats = gameStats(ctx.from || 'global', p.displayUserId);
  const { default: sharp } = await import('sharp');
  const png = await sharp(Buffer.from(webSvg(p, spider, stats))).png().toBuffer();
  const mentions = [p.mention].filter(x => String(x).endsWith('@s.whatsapp.net'));
  const caption = `${TAG}\n\n🕷️ *PERFIL DA ARANHA*\n🕸️ A identidade é a mesma do seu perfil oficial. Esta é apenas a versão exclusiva da Teia.`;
  if (ctx.sendMessage) return ctx.sendMessage(ctx.from || ctx.sender, { image: png, caption, mentions });
  return ctx.reply(caption, { mentions });
}

export async function register() {
  registerCommand({
    name:'perfilaranha', aliases:['aranhaperfil'], category:'perfil', plugin:PLUGIN, permission:Role.USER,
    hidden:true, cooldown:4, description:'Mostra o perfil exclusivo em uma interface dinâmica de teia.',
    usage:'×perfilaranha',
    handler:async ctx=>{
      const requested = target(ctx);
      if (!sameId(requested, ctx.sender) && !isOwner(ctx)) throw new Error('🕷️ O Perfil Aranha é privado.');
      const uid = sameId(requested, ctx.sender) ? ctx.sender : requested;
      const access = await sessionAccess(ctx, uid);
      if (!access.allowed) throw new Error('🕸️ Sua conta não possui uma Sessão Aranha ativa.');
      return renderProfile(ctx, access.userId, access.storageKey);
    }
  });

  registerCommand({
    name:'teia', aliases:['lancarteia'], category:'perfil', plugin:PLUGIN, permission:Role.USER,
    hidden:true, groupOnly:true, cooldown:2, description:'Lança uma teia virtual temporária em outra pessoa.', usage:'×teia @pessoa',
    handler:async ctx=>{
      const access = await sessionAccess(ctx, ctx.sender);
      if (!access.allowed) throw new Error('🕸️ A Teia é exclusiva da Sessão Aranha.');
      const requested = ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0];
      if (!requested) throw new Error('🕷️ Mencione ou responda à pessoa que receberá a teia.');
      const targetId = await canonicalUserId(ctx, requested);
      const actorId = access.userId;
      if (sameId(targetId, actorId)) throw new Error('🕷️ Uma aranha não pode lançar teia em si mesma.');
      const web = await createWeb(ctx, actorId, targetId);
      const progress = await registerWebLaunch(actorId);
      const seconds = remainingSeconds(web);
      const actorMention = String(actorId).endsWith('@s.whatsapp.net') ? actorId : requested;
      return ctx.reply(`${TAG}\n\n🕸️ *TEIA LANÇADA!*\n\n🕷️ @${baseId(actorMention)} lançou uma teia em @${baseId(requested)}!\n\n⏳ A teia ficará ativa por *${seconds} segundos*.\n💨 A pessoa capturada pode usar *${config.prefix}escapar* uma vez para tentar fugir.

✨ +${progress.xpGained} XP de Teia`, { mentions:[actorMention, requested] });
    }
  });

  registerCommand({
    name:'escapar', aliases:['fugirdateia'], category:'perfil', plugin:PLUGIN, permission:Role.USER,
    hidden:true, groupOnly:true, cooldown:2, description:'Tenta escapar de uma teia ativa.', usage:'×escapar',
    handler:async ctx=>{
      const targetId = await canonicalUserId(ctx, ctx.sender);
      const result = await attemptEscape(ctx, targetId);
      const web = result.web;
      if (result.outcome === 'expired') {
        const progress = await registerWebOutcome(web.actorId, 'capture');
        return ctx.reply(`${TAG}\n\n🕸️ *TEIA FINALIZADA!*\n\nA teia de @${baseId(web.actorId)} venceu o tempo. @${baseId(ctx.sender)} foi capturado.\n\n🎯 +${progress.xpGained} XP de captura`, { mentions:[web.actorId, ctx.sender] });
      }
      if (result.outcome === 'escape') {
        const progress = await registerWebOutcome(web.actorId, 'escape');
        return ctx.reply(`${TAG}\n\n💨 *ESCAPOU!*\n\n@${baseId(ctx.sender)} conseguiu escapar da teia de @${baseId(web.actorId)}!\n\n🕸️ A captura foi encerrada.\n\n✨ +${progress.xpGained} XP pela teia`, { mentions:[ctx.sender, web.actorId] });
      }
      const progress = await registerWebOutcome(web.actorId, 'failedEscape');
      return ctx.reply(`${TAG}\n\n🕸️ *NÃO FOI DESSA VEZ!*\n\n@${baseId(ctx.sender)} tentou escapar da teia de @${baseId(web.actorId)}, mas ela segurou.\n\n⏳ Ainda restam *${remainingSeconds(web)}s*.\n\n✨ +${progress.xpGained} XP pela resistência`, { mentions:[ctx.sender, web.actorId] });
    }
  });

  registerCommand({
    name:'addaranha', aliases:['aranhaadd','ativaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true, groupOnly:true,
    cooldown:2, audit:true, description:'Concede o cargo interno 🕷️ Aranha neste grupo.', usage:'×addaranha @pessoa',
    handler:async ctx=>{
      const u = target(ctx); if (!u || sameId(u, ctx.sender)) throw new Error('Mencione a pessoa que receberá o cargo 🕷️ Aranha.');
      const resolvedUserId = await spiderStorageKey(ctx, u);
      const result = await specialRoleManager.grant(ctx, 'aranha', u);
      await upsertSpider(resolvedUserId, { enabled:true });
      await audit(ctx,'BOT_ROLE_GRANTED',{target:u, role:BOT_ROLE.ARANHA, changed:result.changed, group:ctx.from});
      return ctx.reply(`${TAG}\n\n🕷️ *CARGO ARANHA ${result.changed ? 'CONCEDIDO' : 'JÁ ATIVO'}*\n\n👤 @${baseId(u)}\n🏷️ Cargo do bot: *🕷️ Aranha*\n👥 Cargo no WhatsApp: *inalterado*\n🕸️ Perfil Aranha: *ATIVO*\n📍 Escopo: *este grupo*\n\nO cargo do Fantasminha não promove nem remove ninguém do WhatsApp.`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'rmaranha', aliases:['rmvaranha','aranharemove','desativaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true, groupOnly:true,
    cooldown:2, audit:true, description:'Remove o cargo interno 🕷️ Aranha deste grupo.', usage:'×rmaranha @pessoa',
    handler:async ctx=>{
      const u = target(ctx); if (!u || sameId(u, ctx.sender)) throw new Error('Mencione a pessoa.');
      const resolvedUserId = await spiderStorageKey(ctx, u);
      const result = await specialRoleManager.revoke(ctx, 'aranha', u);
      await upsertSpider(resolvedUserId,{enabled:false});
      await audit(ctx,'BOT_ROLE_REVOKED',{target:u, role:BOT_ROLE.ARANHA, changed:result.changed, group:ctx.from});
      return ctx.reply(`${TAG}\n\n${result.changed ? '🔒 *CARGO ARANHA REMOVIDO*' : '🕸️ *CARGO ARANHA JÁ ESTAVA INATIVO*'}\n\n👤 @${baseId(u)}\n🏷️ Cargo do bot: *${result.changed ? 'removido' : 'inativo'}*\n👥 Cargo no WhatsApp: *inalterado*\n📍 Escopo: *este grupo*\n🪪 Perfil oficial: *preservado*`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'aranhastatus', aliases:['statusaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Consulta a Sessão Aranha de uma pessoa.', usage:'×aranhastatus @pessoa',
    handler:async ctx=>{
      const u=target(ctx); if(!u) throw new Error('Mencione a pessoa.');
      const resolvedUserId = await canonicalUserId(ctx, u);
      const s=readSpider(resolvedUserId);
      const role = ctx.from ? getBotRole(ctx.from, resolvedUserId) : null;
      return ctx.reply(`${TAG}\n\n🕷️ *STATUS DA ARANHA*\n\n👤 @${baseId(u)}\n🏷️ Cargo do bot: *${role?.label || 'Nenhum'}*\n📍 Escopo: *${ctx.from ? 'este grupo' : 'não aplicável'}*\n👥 Cargo no WhatsApp: *não alterado*\n🕸️ Sessão Aranha: *${s?.enabled?'ATIVA':'INATIVA'}*\n⭐ Nível: *${s?.spiderLevel||1}*\n✨ XP: *${fmt(s?.spiderXp||0)}*\n💎 Distintivos: *${s?.badges?.length||0}*\n📅 Criada: *${s?.createdAt?new Date(s.createdAt).toLocaleString('pt-BR'):'não criada'}*`,{mentions:[u]});
    }
  });

  registerCommand({
    name:'listaranhas', aliases:['aranhas'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true, groupOnly:true,
    cooldown:2, audit:true, description:'Lista os usuários com cargo 🕷️ Aranha neste grupo.', usage:'×listaranhas',
    handler:async ctx=>{
      const rows=listBotRoles(ctx.from).filter(x=>x.role?.id===BOT_ROLE.ARANHA);
      if (!rows.length) return ctx.reply(`${TAG}\n\n🕸️ Nenhum cargo *🕷️ Aranha* está ativo neste grupo.`);
      return ctx.reply(`${TAG}\n\n🕷️ *ARANHAS DESTE GRUPO*\n\n${rows.map((x,i)=>`${i+1}. @${baseId(x.userId)} — *${x.role.label}*`).join('\n')}\n\n📍 Escopo: *este grupo*`,{mentions:rows.map(x=>x.userId)});
    }
  });

  registerCommand({
    name:'aranhaadmin', aliases:['adminaranha'], category:'dono', plugin:PLUGIN, permission:Role.OWNER, ownerOnly:true,
    cooldown:2, audit:true, description:'Painel administrativo da Sessão Aranha.', usage:'×aranhaadmin',
    handler:async ctx=>ctx.reply(`${TAG}\n\n╭──────── 👑 🕷️ ────────╮\n        *ARANHA ADMIN*\n╰────────────────────────╯\n\n🕷️ ${config.prefix}aranhaadd @pessoa\n   Ativa a Sessão Aranha.\n\n🔒 ${config.prefix}aranharemove @pessoa\n   Desativa sem apagar o perfil oficial.\n\n📊 ${config.prefix}aranhastatus @pessoa\n   Consulta estado, nível e XP.\n\n🖼️ ${config.prefix}perfilaranha @pessoa\n   Visualiza o perfil autorizado.\n\n🧬 Regra: dados de identidade vêm do ${config.prefix}perfil.\n🕸️ Regra: comandos administrativos ficam na categoria *dono* e, portanto, no *menudono*.`)
  });
}

export default { register };
