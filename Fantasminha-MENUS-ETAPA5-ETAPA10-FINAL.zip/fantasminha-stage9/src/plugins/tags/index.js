/**
 * 👻 Fantasminha — comandos de tags por grupo.
 *   ×addtag <nome 1-10> <tag>   (ADM)  cadastra
 *   ×tags                       (todos) lista numerada
 *   ×deltag <nome|número>       (ADM)  apaga
 *   ×tag <nome>                 (todos) revela só o símbolo
 */
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection } from '../../database/store.js';

const COLLECTION = 'group_tags';
const MAX_NAME = 10;
const MAX_TAG = 10;
const MAX_PER_GROUP = 5;

const frame = s => `× 👻 FANTASMINHA\n\n${s}`;
const keyOf = name => String(name || '').normalize('NFD').replace(/\p{Diacritic}/gu, '').trim().toLowerCase();
const isNumber = v => /^\d+$/.test(String(v || '').trim());

function groupTags(data, groupId) {
  data.byGroup ||= {};
  data.byGroup[groupId] ||= [];
  return data.byGroup[groupId];
}
function readList(groupId) {
  return readCollection(COLLECTION, { byGroup: {} }).byGroup?.[groupId] || [];
}
function splitFirst(text) {
  const t = String(text || '').trim();
  const m = t.match(/^(\S+)\s+([\s\S]+)$/);
  return m ? { name: m[1], rest: m[2].trim() } : { name: t, rest: '' };
}

export async function register() {
  registerCommand({
    name: 'addtag', aliases: [], category: 'grupo', plugin: 'tags', permission: Role.GROUP_ADMIN,
    groupOnly: true, cooldown: 2, description: 'Cadastra uma tag neste grupo.', usage: 'addtag <nome> <tag>',
    handler: async ctx => {
      const { name, rest } = splitFirst(ctx.q);
      if (!name || !rest) return ctx.reply(frame(`Use: *${ctx.prefix}addtag <nome> <tag>*\nEx.: ${ctx.prefix}addtag cosmos 宇`));
      if ([...name].length > MAX_NAME) return ctx.reply(frame(`👻 O nome da tag pode ter de 1 a ${MAX_NAME} caracteres.`));
      if (isNumber(name)) return ctx.reply(frame('👻 O nome não pode ser só número, porque os números identificam as tags na lista.'));
      if ([...rest].length > MAX_TAG) return ctx.reply(frame(`👻 A tag pode ter no máximo ${MAX_TAG} caracteres.`));

      let result = null;
      await updateCollection(COLLECTION, data => {
        const list = groupTags(data, ctx.from);
        if (list.some(t => keyOf(t.name) === keyOf(name))) { result = 'dup'; return data; }
        if (list.length >= MAX_PER_GROUP) { result = 'full'; return data; }
        list.push({ name, tag: rest, createdBy: ctx.sender, createdAt: Date.now() });
        result = 'ok';
        return data;
      }, { byGroup: {} });

      if (result === 'dup') return ctx.reply(frame(`👻 Já existe uma tag chamada *${name}* neste grupo. Apague com ${ctx.prefix}deltag antes de recadastrar.`));
      if (result === 'full') return ctx.reply(frame(`👻 Este grupo atingiu o limite de ${MAX_PER_GROUP} tags.`));
      return ctx.reply(frame(`✨ Tag *${rest}* cadastrada como *${name}*!\n\nUse *${ctx.prefix}tag ${name}* para consultar.`));
    }
  });

  registerCommand({
    name: 'tags', aliases: [], category: 'grupo', plugin: 'tags', permission: Role.USER,
    groupOnly: true, cooldown: 3, description: 'Lista as tags cadastradas neste grupo.', usage: 'tags',
    handler: async ctx => {
      const list = readList(ctx.from);
      if (!list.length) return ctx.reply(frame(`👻 Nenhuma tag cadastrada neste grupo.\nUse *${ctx.prefix}addtag <nome> <tag>*.`));
      const rows = list.map((t, i) => `${i + 1}. ${t.name}\nTag: ${t.tag}`).join('\n\n');
      return ctx.reply(frame(`🏷️ *TAGS CADASTRADAS* (${list.length})\n\n${rows}`));
    }
  });

  registerCommand({
    name: 'deltag', aliases: [], category: 'grupo', plugin: 'tags', permission: Role.GROUP_ADMIN,
    groupOnly: true, cooldown: 2, description: 'Apaga uma tag pelo nome ou número da lista.', usage: 'deltag <nome|número>',
    handler: async ctx => {
      const target = String(ctx.q || '').trim();
      if (!target) return ctx.reply(frame(`Use: *${ctx.prefix}deltag <nome ou número>*\nVeja os números com ${ctx.prefix}tags.`));

      let removed = null;
      await updateCollection(COLLECTION, data => {
        const list = groupTags(data, ctx.from);
        const idx = isNumber(target) ? Number(target) - 1 : list.findIndex(t => keyOf(t.name) === keyOf(target));
        if (idx >= 0 && idx < list.length) removed = list.splice(idx, 1)[0];
        return data;
      }, { byGroup: {} });

      if (!removed) return ctx.reply(frame(`👻 Não encontrei a tag *${target}*. Veja a lista com ${ctx.prefix}tags.`));
      return ctx.reply(frame(`🗑️ Tag *${removed.name}* deletada.`));
    }
  });

  registerCommand({
    name: 'tag', aliases: [], category: 'grupo', plugin: 'tags', permission: Role.USER,
    groupOnly: true, cooldown: 2, description: 'Mostra o símbolo de uma tag cadastrada.', usage: 'tag <nome>',
    handler: async ctx => {
      const name = String(ctx.q || '').trim();
      if (!name) return ctx.reply(frame(`Use: *${ctx.prefix}tag <nome>*`));
      const found = readList(ctx.from).find(t => keyOf(t.name) === keyOf(name));
      if (!found) return ctx.reply(frame(`👻 Não existe tag *${name}* neste grupo.`));
      return ctx.reply(found.tag);
    }
  });
}

export default { register };
