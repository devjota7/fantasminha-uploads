import fs from 'node:fs';
import path from 'node:path';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import config from '../../core/config.js';

const root = process.cwd();
const dir = path.join(root, 'dados/database/community-feedback');
const files = { bugs:path.join(dir,'bugs.json'), suggestions:path.join(dir,'suggestions.json') };
const sessions = new Map();
const now=()=>Date.now();
function ensure(){fs.mkdirSync(dir,{recursive:true});for(const f of Object.values(files))if(!fs.existsSync(f))fs.writeFileSync(f,'[]\n');}
function load(file){ensure();try{return JSON.parse(fs.readFileSync(file,'utf8'))||[]}catch{return[]}}
function save(file,data){ensure();const tmp=`${file}.tmp-${process.pid}`;fs.writeFileSync(tmp,JSON.stringify(data,null,2)+'\n');fs.renameSync(tmp,file)}
function owner(c){return !!c.isOwner || Number(c.permission||0)>=Role.OWNER || String(c.sender||'')===String(config.ownerNumber||'') || String(c.sender||'')===String(config.ownerLid||'');}
function key(c,type){return `${type}:${c.sender||''}:${c.from||''}`}
function begin(c,type){sessions.set(key(c,type),{expires:now()+10*60*1000});}
function consume(c,type,text){const k=key(c,type),s=sessions.get(k);if(!s)return null;sessions.delete(k);if(s.expires<now())return {expired:true};return String(text||'').trim()}
function record(file,c,text,type){const rows=load(file);const id=(rows.at(-1)?.id||0)+1;const r={id,type,status:'novo',text,user:{jid:c.sender||'',name:c.pushname||c.userName||'Usuário'},origin:{chatId:c.from||'',isGroup:!!c.isGroup},createdAt:new Date().toISOString()};rows.push(r);save(file,rows);return r}
function list(file){return load(file).sort((a,b)=>b.id-a.id)}
function ref(rows,q){const n=Number(String(q||'').replace(/^#/,'').trim());return rows.find(x=>x.id===n)}
export async function consumeFeedbackMessage(ctx){
  for(const type of ['bug','sugestao']){const text=consume(ctx,type,ctx.text||ctx.body);if(text===null)continue;if(text?.expired){await ctx.reply?.('⌛ A sessão expirou. Execute o comando novamente.');return true}if(!text){await ctx.reply?.('❌ O texto não pode ficar vazio.');return true}const file=files[type==='bug'?'bugs':'suggestions'];const r=record(file,ctx,text,type);await ctx.reply?.(`${type==='bug'?'🐛':'💡'} Registro #${r.id} recebido. Obrigado por contribuir com o Fantasminha! 👻`);return true}return false;
}
export async function register(){
 registerCommand({name:'bug',category:'comunidade',permission:Role.USER,cooldown:2,description:'Registra um problema encontrado no bot.',handler:async c=>{begin(c,'bug');return c.reply?.(`🐛 *CENTRAL DE BUGS*\n\nDescreva o problema em uma única mensagem.\n\nDigite *cancelar* para cancelar.`)}});
 registerCommand({name:'sugestao',category:'comunidade',permission:Role.USER,cooldown:2,description:'Envia uma sugestão ao dono.',handler:async c=>{begin(c,'sugestao');return c.reply?.(`💡 *NOVA SUGESTÃO*\n\nEnvie sua ideia em uma única mensagem.\n\nDigite *cancelar* para cancelar.`)}});
 registerCommand({name:'listabugs',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar os bugs.');const rows=list(files.bugs);return c.reply?.(`🐛 *CENTRAL DE BUGS*\n\n${rows.length?rows.map(r=>`#${r.id} • ${r.status} • ${r.text.slice(0,90)}`).join('\n'):'Nenhum bug registrado.'}`)}});
 registerCommand({name:'listasugestoes',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar as sugestões.');const rows=list(files.suggestions);return c.reply?.(`💡 *SUGESTÕES*\n\n${rows.length?rows.map(r=>`#${r.id} • ${r.status} • ${r.text.slice(0,90)}`).join('\n'):'Nenhuma sugestão registrada.'}`)}});
 registerCommand({name:'verbug',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar os bugs.');const r=ref(load(files.bugs),c.q);return c.reply?.(r?`🐛 *BUG #${r.id}*\n\nStatus: *${r.status}*\nUsuário: ${r.user.name}\n\n${r.text}`:'❌ Bug não encontrado.')}});
 registerCommand({name:'versugestao',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar as sugestões.');const r=ref(load(files.suggestions),c.q);return c.reply?.(r?`💡 *SUGESTÃO #${r.id}*\n\nStatus: *${r.status}*\nUsuário: ${r.user.name}\n\n${r.text}`:'❌ Sugestão não encontrada.')}});
 registerCommand({name:'corrigirbug',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar os bugs.');const rows=load(files.bugs),r=ref(rows,String(c.q).split(/\s+/)[0]);if(!r)return c.reply?.('❌ Bug não encontrado.');r.status='corrigido';r.resolution=String(c.q).split(/\s+/).slice(1).join(' ')||'Corrigido pelo dono.';r.updatedAt=new Date().toISOString();save(files.bugs,rows);return c.reply?.(`✅ Bug #${r.id} marcado como corrigido.`)}});
 registerCommand({name:'reabrirbug',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar os bugs.');const rows=load(files.bugs),r=ref(rows,c.q);if(!r)return c.reply?.('❌ Bug não encontrado.');r.status='reaberto';r.updatedAt=new Date().toISOString();save(files.bugs,rows);return c.reply?.(`🟠 Bug #${r.id} reaberto.`)}});
 registerCommand({name:'aprovarsugestao',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar as sugestões.');const rows=load(files.suggestions),r=ref(rows,String(c.q).split(/\s+/)[0]);if(!r)return c.reply?.('❌ Sugestão não encontrada.');r.status='aprovada';r.decision=String(c.q).split(/\s+/).slice(1).join(' ')||'Aprovada pelo dono.';r.updatedAt=new Date().toISOString();save(files.suggestions,rows);return c.reply?.(`✅ Sugestão #${r.id} aprovada.`)}});
 registerCommand({name:'reprovarsugestao',category:'dono',permission:Role.OWNER,visibleInHelp:false,handler:c=>{if(!owner(c))return c.reply?.('🚫 Apenas o dono principal pode gerenciar as sugestões.');const rows=load(files.suggestions),r=ref(rows,String(c.q).split(/\s+/)[0]);if(!r)return c.reply?.('❌ Sugestão não encontrada.');r.status='reprovada';r.decision=String(c.q).split(/\s+/).slice(1).join(' ')||'Reprovada pelo dono.';r.updatedAt=new Date().toISOString();save(files.suggestions,rows);return c.reply?.(`❌ Sugestão #${r.id} reprovada.`)}});
}
export default {register,consumeFeedbackMessage};
