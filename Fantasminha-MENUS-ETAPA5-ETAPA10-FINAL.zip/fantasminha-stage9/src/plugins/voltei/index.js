import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { clearAfk } from '../../services/social.js';

export async function register() {
  registerCommand({
    name: 'voltei', aliases: [], category: 'perfil', plugin: 'voltei', permission: Role.USER,
    groupOnly: true, cooldown: 3, description: 'Encerra explicitamente seu estado AFK.', usage: 'voltei',
    handler: async ctx => {
      const removed = await clearAfk(ctx);
      if (!removed) return ctx.reply('👻 Você não estava marcado(a) como AFK neste grupo.');
      return ctx.reply(`👻 Bem-vindo(a) de volta, ${ctx.pushname || 'espírito'}! Seu AFK foi removido.`);
    }
  });
}

export default { register };
