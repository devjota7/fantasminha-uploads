import { registerCommand, registerAlias, getCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { buildCatalogMenu, parseMenuNavigationArgs, renderMenuNavigationError } from '../../../dados/src/menus/catalogMenu.js';

const ALIASES = Object.freeze({
  hangman:'forca', trivia:'quiz', weather:'clima', work:'trabalhar', ytmp3:'play', tictactoe:'ttt',
  inventory:'inventario', memory:'memoria', masmorra:'dungeon', petbattle:'batalhapet', statsrpg:'meustats',
  achievements:'conquistas', advertir:'adv', calcular:'calc', curiosidade:'fato', tempo:'clima', note:'nota', notes:'notas',
  help:'ajuda'
});
const DIRECT_MENU_COMMANDS = Object.freeze({
  menubn:'bn', menujogos:'jogos', menuia:'ia', menugrupo:'comunidade',
  menurpg:'rpg', menualem:'alem', menudown:'midia', ferramentas:'ferramentas',
  menuadm:'adm', menudono:'dono', menusistema:'sistema', menuvip:'premium'
});
// ×menudono, ×menuadm, ×menuvip etc. precisam renderizar o MESMO catálogo
// visual que ×menu <categoria> produz. Antes isso dependia de um comando
// canônico "menu" registrado no Registry V2 — que nunca existiu (o "menu"
// real só roda pelo switch legado em dados/src/index.js). Por isso todo
// comando direto (×menudono, os botões do catálogo do ×menu, etc.) caía
// sempre na mensagem de erro "catálogo ainda não foi carregado". Chamamos
// buildCatalogMenu diretamente para eliminar essa dependência quebrada.
function resolveMenuPermission(ctx) {
  const base = ctx.isOwner ? 100 : (ctx.isBotAdmin && ctx.isGroupAdmin ? 80 : ctx.isGroupAdmin ? 60 : ctx.isPremium ? 40 : 10);
  return Math.max(base, Number(ctx.botRolePermission || 0));
}
async function menuShortcut(ctx, category) {
  const prefix = ctx.prefix || '×';
  const nav = parseMenuNavigationArgs(category ? [category] : []);
  const text = nav.ok
    ? buildCatalogMenu(prefix, nav.category, {
        botName: ctx.botName || 'Fantasminha',
        userName: ctx.pushname || ctx.userName || 'Alma',
        permission: resolveMenuPermission(ctx),
        menuCatalogAll: false
      })
    : renderMenuNavigationError(prefix, nav.error);
  return ctx.reply?.(text);
}
async function legacyAddReact(ctx){const trigger=String(ctx.args?.[0]||'').trim(),emoji=String(ctx.args?.[1]||'').trim();if(!trigger||!emoji)return ctx.reply?.(`Uso: ${ctx.prefix||'×'}addreact gatilho emoji`);const cmd=getCommand('react');return cmd?.handler({...ctx,args:['add',`${trigger} | ${emoji}`,'EXACT',ctx.isGroup?'LOCAL':'GLOBAL_PRIVATE']});}
async function legacyDelReact(ctx){const id=String(ctx.args?.[0]||'').trim();if(!id)return ctx.reply?.(`Uso: ${ctx.prefix||'×'}delreact ID`);return getCommand('react')?.handler({...ctx,args:['del',id]});}
async function legacyListReact(ctx){return getCommand('react')?.handler({...ctx,args:['lista']});}
export async function register(){
  for(const [a,t] of Object.entries(ALIASES)){if(a!==t)registerAlias(a,t);}
  registerCommand({name:'addreact',category:'social',plugin:'nazuna-compat',permission:Role.OWNER,ownerOnly:true,visibleInHelp:false,cooldown:1,handler:legacyAddReact});
  registerCommand({name:'delreact',category:'social',plugin:'nazuna-compat',permission:Role.OWNER,ownerOnly:true,visibleInHelp:false,cooldown:1,handler:legacyDelReact});
  registerCommand({name:'listreact',category:'social',plugin:'nazuna-compat',permission:Role.OWNER,ownerOnly:true,visibleInHelp:false,cooldown:1,handler:legacyListReact});
  for(const [name,category] of Object.entries(DIRECT_MENU_COMMANDS)){if(getCommand(name))continue;registerCommand({name,category:'menu',plugin:'nazuna-compat',permission:Role.USER,hidden:true,cooldown:1,handler:ctx=>menuShortcut(ctx,category)});}
  return true;
}
export default {register};
