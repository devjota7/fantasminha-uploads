import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { setNick, listNicks, removeNick, getNickForMember } from '../../platform/nick/index.js';
import { setBirthday, listBirthdays, todayBirthdays, nextBirthdays, removeBirthday, getBirthdayForMember } from '../../platform/birthday/index.js';
import { reconcile } from '../../platform/reconciliation/index.js';
import { getPreferences, setPreference } from '../../platform/preferences/index.js';
import { searchGlobal } from '../../platform/search/index.js';
import { searchUsers } from '../../platform/search/userSearch.js';
import { resolveUserIdentity } from '../../platform/identity/resolver.js';
import { ensureMember } from '../../platform/member/index.js';

const tag = s => `× 👻 FANTASMINHA\n\n${s}`;
const cleanMention = jid => String(jid || '').trim().toLowerCase().endsWith('@s.whatsapp.net') ? String(jid).trim() : null;

async function identity(ctx, target = null) {
  const r = await resolveUserIdentity(ctx, target || ctx.mentioned?.[0] || ctx.sender);
  if (!r?.realJid) throw new ValidationError('Não consegui resolver a pessoa para uma menção válida. Tente mencionar o membro novamente.');
  return r;
}

async function mention(ctx, id) {
  const r = await resolveUserIdentity(ctx, id);
  const jid = cleanMention(r?.realJid);
  return jid ? { text: `@${jid.split('@')[0]}`, jid } : null;
}

function currentIds(ctx) { return Array.isArray(ctx.groupParticipants) ? ctx.groupParticipants : []; }
async function currentRealJids(ctx) {
  const source = Array.isArray(ctx.groupParticipantObjects) && ctx.groupParticipantObjects.length ? ctx.groupParticipantObjects : currentIds(ctx).map(id => ({ id }));
  const out = [];
  for (const participant of source) { const r = await resolveUserIdentity(ctx, participant?.id || participant?.jid || participant?.participant || participant); if (r?.realJid && !out.includes(r.realJid)) out.push(r.realJid); }
  return out;
}
function targetRaw(ctx) { return ctx.mentioned?.[0] || ctx.sender; }

async function renderNickRows(ctx, rows) {
  if (!rows.length) return 'Nenhum nick cadastrado.';
  const sections = new Map();
  for (const r of rows) { const k = r.sectionId || 'membros'; if (!sections.has(k)) sections.set(k, []); sections.get(k).push(r); }
  const allMentions = [];
  const blocks = [];
  for (const [section, list] of sections) {
    const lines = [];
    for (const x of list) {
      const m = await mention(ctx, x.platformId || x.memberId);
      if (!m) continue;
      allMentions.push(m.jid);
      lines.push(`• ${m.text} → 「${x.nick}」`);
    }
    if (lines.length) blocks.push(`📂 *${section}*\n${lines.join('\n')}`);
  }
  return { text: blocks.length ? blocks.join('\n\n') : 'Nenhum membro com menção resolvível.', mentions: [...new Set(allMentions)] };
}

async function renderBirthdayRows(ctx, rows) {
  const months = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
  const mentions = [];
  const blocks = [];
  for (let i = 0; i < months.length; i++) {
    const r = rows.filter(x => x.month === i + 1);
    const lines = [];
    for (const x of r) {
      const m = await mention(ctx, x.platformId || x.memberId);
      if (!m) continue;
      mentions.push(m.jid);
      lines.push(`• ${String(x.day).padStart(2,'0')}/${String(x.month).padStart(2,'0')} • ${m.text}`);
    }
    blocks.push(`📅 *${months[i]}*\n${lines.length ? lines.join('\n') : '• Nenhum cadastrado.'}`);
  }
  return { text: blocks.join('\n\n'), mentions: [...new Set(mentions)] };
}

async function mentionList(ctx, ids) {
  const texts = [], mentions = [];
  for (const id of ids || []) {
    const m = await mention(ctx, id);
    if (m) { texts.push(m.text); mentions.push(m.jid); }
  }
  return { text: texts, mentions: [...new Set(mentions)] };
}

async function canEditOther(ctx, targetJid) {
  if (ctx.isOwner || ctx.isGroupAdmin || (ctx.isBotAdmin && ctx.isGroupAdmin)) return true;
  if (String(targetJid || '').toLowerCase() === String(ctx.sender || '').toLowerCase()) return true;
  try { const self = await resolveUserIdentity(ctx, ctx.sender); return String(self?.realJid || '').toLowerCase() === String(targetJid || '').toLowerCase(); } catch { return false; }
}

export async function register() {
  registerCommand({ name:'nick', aliases:['cnick'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx => {
    const args = [...(ctx.args || [])];
    const hasMention = !!ctx.mentioned?.[0];
    const first = String(args[0] || '').toLowerCase();
    const isRemove = ['remover','remove','apagar','delete'].includes(first);
    const target = await identity(ctx, hasMention ? ctx.mentioned[0] : ctx.sender);
    const member = await ensureMember(target.realJid);

    if (isRemove) {
      if (!(await canEditOther(ctx, target.realJid))) throw new ValidationError('Você não pode remover o nick de outra pessoa.');
      const out = await removeNick(member.memberId, { groupId:ctx.from, actor:ctx.sender });
      await ctx.reply(tag(`🗑️ *APELIDO REMOVIDO*\n\n👤 @${target.realJid.split('@')[0]}\n\nA Ficha da Alma foi atualizada.`), { mentions:[target.realJid] });
      return out;
    }

    const parts = hasMention ? args.slice(1) : args;
    if (!parts.length) {
      const current = getNickForMember(ctx.from, member.memberId);
      const text = current
        ? `🎭 *Apelido:* ${current.nick}\n\n📍 Cadastrado neste grupo.\n\n×nick <novo apelido> → alterar\n×nick remover → remover`
        : `🎭 *Apelido:* Não cadastrado\n\nVocê ainda não possui um apelido cadastrado neste grupo.\n\nPara cadastrar:\n×nick <seu apelido>\n\nExemplo:\n×nick Fantasma`;
      await ctx.reply(tag(`🎭 *${hasMention ? 'APELIDO' : 'SEU APELIDO'}*\n\n${hasMention ? `👤 @${target.realJid.split('@')[0]}\n\n` : ''}${text}`), { mentions:[target.realJid] });
      return current;
    }

    if (!(await canEditOther(ctx, target.realJid))) throw new ValidationError('Você não pode alterar o nick de outra pessoa.');
    const r = await setNick(target.realJid, parts.join(' '), { groupId:ctx.from, actor:ctx.sender });
    await ctx.reply(tag(`🎭 *APELIDO ATUALIZADO*\n\n👤 @${target.realJid.split('@')[0]}\n🎭 *${r.nick}*\n\nSua Ficha da Alma foi atualizada.`), { mentions:[target.realJid] });
  }});

  registerCommand({ name:'nicks', aliases:['listacnick'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx => {
    const rows = listNicks(ctx.from,{order:'alpha'}); const rendered = await renderNickRows(ctx,rows);
    await ctx.reply(tag(`🏷️ *LISTA DE NICKS*\n\n${rendered.text}\n\n📌 Total: *${rows.length}*`), { mentions:rendered.mentions });
  }});

  registerCommand({ name:'semaNick', aliases:['semcnick'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx => {
    const source = Array.isArray(ctx.groupParticipantObjects) && ctx.groupParticipantObjects.length ? ctx.groupParticipantObjects : currentIds(ctx).map(id => ({id}));
    if (!source.length) throw new ValidationError('A lista de participantes não está disponível neste contexto.');
    const missing = [];
    for (const participant of source) {
      const r = await identity(ctx, participant?.id || participant?.jid || participant?.participant || participant);
      if (!r?.realJid) continue;
      const member = await ensureMember(r.realJid);
      if (!getNickForMember(ctx.from, member.memberId)) missing.push(r.realJid);
    }
    const rendered=await mentionList(ctx,missing);
    await ctx.reply(tag(`👻 *SEM NICK*\n\n${rendered.text.length?rendered.text.join('\n'):'Todos os participantes possuem nick ou não foi possível resolver a menção.'}\n\nTotal: *${rendered.text.length}*`), { mentions:rendered.mentions });
  }});

  registerCommand({ name:'aniversario', aliases:['cdata'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx => {
    const args = [...(ctx.args || [])];
    const hasMention = !!ctx.mentioned?.[0];
    const first = String(args[0] || '').toLowerCase();
    const isRemove = ['remover','remove','apagar','delete'].includes(first);
    const target = await identity(ctx, hasMention ? ctx.mentioned[0] : ctx.sender);
    const member = await ensureMember(target.realJid);

    if (isRemove) {
      if (!(await canEditOther(ctx,target.realJid))) throw new ValidationError('Você não pode remover o aniversário de outra pessoa.');
      await removeBirthday(member.memberId,{groupId:ctx.from,actor:ctx.sender});
      await ctx.reply(tag(`🗑️ *ANIVERSÁRIO REMOVIDO*\n\n👤 @${target.realJid.split('@')[0]}\n\nA Ficha da Alma foi atualizada.`),{mentions:[target.realJid]});
      return;
    }

    const rawDateParts = args.filter(a => !String(a).startsWith('@'));
    const date = ['definir','define','set'].includes(String(rawDateParts[0]||'').toLowerCase()) ? rawDateParts.slice(1).join(' ') : rawDateParts.join(' ');
    if (!date) {
      const current = getBirthdayForMember(ctx.from, member.memberId);
      const formatted = current ? `${String(current.day).padStart(2,'0')}/${String(current.month).padStart(2,'0')}${current.year ? `/${current.year}` : ''}` : null;
      const text = formatted
        ? `🎂 *Aniversário:* ${formatted}\n\n📍 Cadastrado neste grupo.\n\n×aniversario DD/MM → alterar\n×aniversario remover → remover`
        : `🎂 *Aniversário:* Não cadastrado\n\nVocê ainda não informou sua data de aniversário neste grupo.\n\nPara cadastrar:\n×aniversario DD/MM\n\nExemplo:\n×aniversario 25/09`;
      await ctx.reply(tag(`🎂 *${hasMention ? 'ANIVERSÁRIO' : 'SEU ANIVERSÁRIO'}*\n\n${hasMention ? `👤 @${target.realJid.split('@')[0]}\n\n` : ''}${text}`), { mentions:[target.realJid] });
      return current;
    }
    if(!(await canEditOther(ctx,target.realJid))) throw new ValidationError('Você não pode alterar o aniversário de outra pessoa.');
    const r=await setBirthday(target.realJid,date,{groupId:ctx.from,actor:ctx.sender});
    await ctx.reply(tag(`🎂 *ANIVERSÁRIO ATUALIZADO*\n\n👤 @${target.realJid.split('@')[0]}\n🎂 *${String(r.day).padStart(2,'0')}/${String(r.month).padStart(2,'0')}*${r.year?`/${r.year}`:''}\n\nA Ficha da Alma foi atualizada.`),{mentions:[target.realJid]});
  }});

  registerCommand({ name:'aniversarios', aliases:['listaaniversarios'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx => {
    const sub=String(ctx.args?.[0]||'lista').toLowerCase();
    if(['hoje','today'].includes(sub)){const r=todayBirthdays(ctx.from);const m=await mentionList(ctx,r.map(x=>x.platformId||x.memberId));await ctx.reply(tag(`🎉 *ANIVERSARIANTES DE HOJE*\n\n${m.text.length?m.text.join('\n'):'Ninguém cadastrado hoje.'}`),{mentions:m.mentions});return;}
    if(['proximos','next'].includes(sub)){const r=nextBirthdays(ctx.from,7);const mentions=[];const lines=[];for(const x of r){const m=await mention(ctx,x.platformId||x.memberId);if(!m)continue;mentions.push(m.jid);lines.push(`• ${String(x.day).padStart(2,'0')}/${String(x.month).padStart(2,'0')} — ${m.text}`);}await ctx.reply(tag(`🎂 *PRÓXIMOS ANIVERSÁRIOS*\n\n${lines.length?lines.join('\n'):'Nenhum cadastro resolvível.'}`),{mentions:[...new Set(mentions)]});return;}
    if(['mes','mês','month'].includes(sub)){const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'America/Sao_Paulo',month:'2-digit'}).formatToParts(new Date());const month=Number(parts.find(x=>x.type==='month')?.value);const r=listBirthdays(ctx.from).filter(x=>x.month===month);const rendered=await renderBirthdayRows(ctx,r);await ctx.reply(tag(`🗓️ *ANIVERSÁRIOS DESTE MÊS*\n\n${rendered.text}`),{mentions:rendered.mentions});return;}
    const rows=listBirthdays(ctx.from);const next=nextBirthdays(ctx.from,1)[0];let nextText='Nenhum próximo aniversário resolvível.';let nextMention=null;if(next){const m=await mention(ctx,next.platformId||next.memberId);if(m){nextText=`${m.text} — ${String(next.day).padStart(2,'0')}/${String(next.month).padStart(2,'0')}`;nextMention=m.jid;}}
    const rendered=await renderBirthdayRows(ctx,rows);await ctx.reply(tag(`🎂 *ANIVERSÁRIOS*\n\n👥 Total: *${rows.length}*\n🎉 Próximo: ${nextText}\n\n${rendered.text}`),{mentions:[...new Set([...rendered.mentions,nextMention].filter(Boolean))]});
  }});

  registerCommand({ name:'semdata', aliases:['semdata2'], category:'comunidade', plugin:'community', permission:Role.USER, cooldown:3, groupOnly:true, handler:async ctx=>{const source=Array.isArray(ctx.groupParticipantObjects)&&ctx.groupParticipantObjects.length?ctx.groupParticipantObjects:currentIds(ctx).map(id=>({id}));const missing=[];for(const participant of source){const r=await identity(ctx,participant?.id||participant?.jid||participant?.participant||participant);if(!r?.realJid)continue;const member=await ensureMember(r.realJid);if(!getBirthdayForMember(ctx.from,member.memberId))missing.push(r.realJid);}const m=await mentionList(ctx,missing);await ctx.reply(tag(`👻 *SEM ANIVERSÁRIO*\n\n${m.text.length?m.text.join('\n'):'Todos os participantes possuem data ou não foi possível resolver a menção.'}\n\nTotal: *${m.text.length}*`),{mentions:m.mentions});}});
  registerCommand({ name:'reconciliar', aliases:['reconcile'], category:'comunidade', plugin:'community', permission:Role.GROUP_ADMIN, cooldown:5, groupOnly:true, handler:async ctx=>{const ids=await currentRealJids(ctx);if(!ids.length)throw new ValidationError('Participantes indisponíveis.');const r1=reconcile({groupId:ctx.from,currentIds:ids,collection:'nicks'});const r2=reconcile({groupId:ctx.from,currentIds:ids,collection:'birthdays'});await ctx.reply(tag(`🔎 *RECONCILIAÇÃO*\n\n🏷️ Nicks: ${r1.matched.length} OK · ${r1.missing.length} sem · ${r1.stale.length} antigos\n🎂 Aniversários: ${r2.matched.length} OK · ${r2.missing.length} sem · ${r2.stale.length} antigos\n\n⚠️ Nenhum cadastro é apagado automaticamente.`));}});
  registerCommand({ name:'buscarusuario', aliases:['searchuser'], category:'dono', plugin:'community', permission:Role.OWNER, cooldown:5, description:'Busca usuários (nome do ZAP, nick, número ou menção) e mostra em quais grupos estão, com link quando o bot é ADM.', usage:'buscarusuario <nome|número|@menção>', handler:async ctx=>{const sock=ctx.sock||ctx.socket;if(!sock?.groupFetchAllParticipating)throw new ValidationError('Conexão indisponível no momento.');const r=await searchUsers(sock,{query:ctx.q,mentionedJid:ctx.mentioned?.[0]||null,quotedJid:ctx.quotedParticipant||null,prefix:ctx.prefix||'×'});await ctx.reply(tag(r.text),{mentions:r.mentions});}});
  registerCommand({ name:'preferencias', aliases:['minhasprefs'], category:'personal', plugin:'community', permission:Role.USER, cooldown:3, privateOnly:true, handler:async ctx=>{const sub=String(ctx.args?.[0]||'ver').toLowerCase();if(sub==='ver'){const p=getPreferences(ctx.sender);return ctx.reply(tag(`⚙️ *PREFERÊNCIAS*\n\nIdioma: ${p.language}\nTema: ${p.theme}\nEstilo: ${p.responseStyle}\nNotificações: ${p.notifications?'ON':'OFF'}\nAniversários: ${p.birthdayReminders?'ON':'OFF'}`));}const key=ctx.args?.[0];const value=ctx.args?.slice(1).join(' ');if(!value)throw new ValidationError('preferencias <chave> <valor>');const allowed={idioma:'language',tema:'theme',estilo:'responseStyle',notificacoes:'notifications',aniversarios:'birthdayReminders'};const k=allowed[String(key).toLowerCase()];if(!k)throw new ValidationError('Chaves: idioma, tema, estilo, notificacoes, aniversarios');const val=['notifications','birthdayReminders'].includes(k)?['on','true','sim','1'].includes(value.toLowerCase()):value;await setPreference(ctx.sender,k,val);await ctx.reply(tag(`⚙️ Preferência *${k}* atualizada.`));}});
}
export default {register};
