import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import service from '../../games/gartic/GarticService.js';
export async function register(){
  registerCommand({name:'gartic',aliases:[],category:'jogos',plugin:'gartic',permission:Role.USER,groupOnly:true,cooldown:3,priority:1005,description:'Em manutenção: comando temporariamente bloqueado até o banco de palavras original ser completado.',handler:ctx=>service.start(ctx)});
}
export default {register};
