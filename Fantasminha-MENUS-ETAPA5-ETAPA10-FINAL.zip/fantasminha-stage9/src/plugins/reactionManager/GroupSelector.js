const CANCEL = new Set(['0', 'cancelar', 'cancel', 'voltar', 'sair']);
const ALL = new Set(['todos', 'todas', '*']);

export function normalizeGroups(groups = []) {
  return groups.map((group, index) => ({
    id: String(group.id || group.jid || group.groupId || '').trim(),
    name: String(group.name || group.subject || `Grupo ${index + 1}`).trim(),
    available: group.available !== false
  })).filter(group => group.id).sort((a, b) => a.name.localeCompare(b.name, 'pt-BR') || a.id.localeCompare(b.id));
}

export function paginate(groups, page = 1, pageSize = 8) {
  const items = normalizeGroups(groups);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));
  const currentPage = Math.min(Math.max(1, Number(page) || 1), totalPages);
  return { items: items.slice((currentPage - 1) * pageSize, currentPage * pageSize), page: currentPage, pageSize, total: items.length, totalPages };
}

export function selectGroups(input, groups = [], { currentGroupId = null, allowAll = true } = {}) {
  const available = normalizeGroups(groups).filter(group => group.available);
  const value = String(input ?? '').trim();
  if (CANCEL.has(value.toLowerCase())) return { cancelled: true, ids: [] };
  if (value.toLowerCase() === 'este' || value.toLowerCase() === 'local') {
    return currentGroupId && available.some(group => group.id === currentGroupId) ? { ids: [currentGroupId] } : { ids: [], error: 'Grupo atual indisponível.' };
  }
  if (allowAll && ALL.has(value.toLowerCase())) return { ids: available.map(group => group.id), all: true };
  const search = value.match(/^(?:buscar|search)\s+(.+)$/i)?.[1];
  const source = search ? available.filter(group => group.name.toLocaleLowerCase('pt-BR').includes(search.toLocaleLowerCase('pt-BR'))) : available;
  if (search && !source.length) return { ids: [], error: `Nenhum grupo encontrado para “${search}”.` };
  if (search) return { search: true, results: source, ids: [] };
  const tokens = value.split(/[\s,;]+/).filter(Boolean);
  const ids = [];
  for (const token of tokens) {
    const byIndex = /^\d+$/.test(token) ? available[Number(token) - 1] : null;
    const matches = byIndex ? [byIndex] : source.filter(group => group.id === token || group.name.toLocaleLowerCase('pt-BR') === token.toLocaleLowerCase('pt-BR'));
    if (!matches.length) return { ids: [], error: `Grupo ${token} não encontrado.` };
    const match = matches[0];
    if (!ids.includes(match.id)) ids.push(match.id);
  }
  return ids.length ? { ids } : { ids: [], error: 'Selecione ao menos um grupo ou digite 0 para cancelar.' };
}

export default { normalizeGroups, paginate, selectGroups };
