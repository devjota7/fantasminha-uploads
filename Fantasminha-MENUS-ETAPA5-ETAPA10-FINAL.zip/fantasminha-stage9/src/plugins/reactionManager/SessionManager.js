import * as service from './ReactionService.js';
import { selectGroups, paginate, normalizeGroups } from './GroupSelector.js';
import config from '../../core/config.js';
import { configuredOwner } from '../../core/permissions.js';

export const SESSION_TTL_MS = 10 * 60 * 1000;
const sessions = new Map();
const keyFor = ctx => `${String(ctx.sender || 'unknown')}::${String(ctx.from || 'private')}`;
const now = () => Date.now();
const expired = session => !session || session.expiresAt <= now();
const touch = session => { session.expiresAt = now() + SESSION_TTL_MS; return session; };
const send = async (ctx, text) => { await ctx.reply?.(text); return { handled: true, session: true }; };
const groupsOf = ctx => normalizeGroups(ctx.groups || ctx.groupList || []);
const valid = (value, list) => list.includes(String(value || '').trim().toUpperCase());
const menuBack = () => `${centralMenu}\n\n0 = voltar`;

export const centralMenu = [
  '╔════════════════════════════════════════════════════════════╗',
  '║        👑 FANTASMINHA • REACT CENTRAL 👑                  ║',
  '╠════════════════════════════════════════════════════════════╣',
  '║ [1] 💎 ➕ Criar Nova Reação                                ║',
  '║ [2] 💎 📋 Minhas Reações (Listar)                         ║',
  '║ [3] 💎 ⚙️ Gerenciar (Editar/Ativar/Excluir)               ║',
  '║ [4] 💎 📊 Estatísticas & Métricas                         ║',
  '║ [5] 💎 📜 Histórico de Auditoria                           ║',
  '║ [6] 💎 🛠️ Configurações do Sistema                        ║',
  '╠════════════════════════════════════════════════════════════╣',
  '║ ✨ Digite o número da opção desejada.                      ║',
  '║ 0️⃣ Cancelar e Fechar Painel                                ║',
  '╚════════════════════════════════════════════════════════════╝'
].join('\n');

export function startSession(ctx, state = { step: 'menu', data: {} }) {
  if (!configuredOwner(ctx?.sender)) return null;
  const session = { id: `RXS-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`, owner: ctx.sender, context: ctx.from || 'private', state, createdAt: now(), expiresAt: now() + SESSION_TTL_MS };
  sessions.set(keyFor(ctx), session);
  return session;
}
export function getSession(ctx) { const key = keyFor(ctx); const session = sessions.get(key); if (expired(session)) { sessions.delete(key); return null; } return touch(session); }
export function closeSession(ctx) { return sessions.delete(keyFor(ctx)); }
export function clearExpired() { for (const [key, session] of sessions) if (expired(session)) sessions.delete(key); return sessions.size; }
export function sessionCount() { clearExpired(); return sessions.size; }
export function resetSessions() { sessions.clear(); }

const createPrompt = () => '🎯 *ETAPA 1/5 — GATILHO*\nEnvie a mensagem que deve ativar a reação.\n0 = cancelar';
const groupPrompt = (ctx, page = 1, selected = []) => {
  const pageData = paginate(groupsOf(ctx), page, 8);
  const selectedSet = new Set(selected);
  const lines = pageData.items.map((group, index) => `${selectedSet.has(group.id) ? '✅' : '❖'} [${String(index + 1).padStart(2, '0')}] ${group.name}`);
  return `╔════════════════════════════════════════════════════════════╗\n║ 👑 SELEÇÃO DE GRUPOS • VIP SELECTOR                       ║\n╠════════════════════════════════════════════════════════════╣\n║ Página ${pageData.page}/${pageData.totalPages} • selecionados: ${selected.length}                         ║\n╠════════════════════════════════════════════════════════════╣\n${lines.join('\n') || '║ Nenhum grupo disponível.                                  ║'}\n╠════════════════════════════════════════════════════════════╣\n║ 💡 1, 3, 5 • "todos" • "buscar nome"                      ║\n║ ▶️ próxima • anterior • 0 cancelar                         ║\n╚════════════════════════════════════════════════════════════╝`;
};
const resolvePageInput = (input, ctx, page = 1) => {
  if (!/^[\d\s,;]+$/.test(input)) return input;
  const pageData = paginate(groupsOf(ctx), page, 8);
  return input.split(/[\s,;]+/).filter(Boolean).map(token => pageData.items[Number(token) - 1]?.id || token).join(',');
};
const preview = data => `╔════════════════════════════════════════════════════════════╗\n║ 👑 CONFIRMAÇÃO • NOVA REAÇÃO                              ║\n╠════════════════════════════════════════════════════════════╣\n║ 🏷️ ID: ${data.id || 'será gerado'}\n║ 🎯 Gatilho: “${data.trigger}”\n║ 😀 Emoji: ${data.emoji}\n║ 🔍 Tipo: ${data.matcher}\n║ 🌐 Escopo: ${data.scope}\n║ 📌 Grupos: ${(data.groupIds || []).length || 'escopo global'}\n║ 🟢 Status: ATIVA\n╠════════════════════════════════════════════════════════════╣\n║ [1] ✅ Confirmar e Salvar                                  ║\n║ [2] ✏️ Alterar Dados                                       ║\n║ [3] ❌ Cancelar Criação                                    ║\n╚════════════════════════════════════════════════════════════╝`;
const editPreview = (before, after) => `╔════════════════════════════════════════════════════════════╗\n║ 👑 ALTERAÇÃO • CONFIRMAÇÃO VIP                             ║\n╠════════════════════════════════════════════════════════════╣\n║ 🏷️ REAÇÃO: ${after.id}\n║ 🔻 ANTES:\n║ ${before.trigger} ➔ ${before.emoji} [${before.matcher}]\n║ 🌐 ${before.scope} • ${(before.groupIds || []).join(', ') || 'global'}\n║\n║ 🔹 DEPOIS:\n║ ${after.trigger} ➔ ${after.emoji} [${after.matcher}]\n║ 🌐 ${after.scope} • ${(after.groupIds || []).join(', ') || 'global'}\n╠════════════════════════════════════════════════════════════╣\n║ [1] ✅ Confirmar e Aplicar                                ║\n║ [2] ❌ Cancelar Alteração                                  ║\n╚════════════════════════════════════════════════════════════╝`;
const managePreview = (data, rule) => `╔════════════════════════════════════════════════════════════╗\n║ 👑 GERENCIAMENTO • CONFIRMAÇÃO                             ║\n╠════════════════════════════════════════════════════════════╣\n║ 🏷️ ${rule.id}\n║ 🎯 ${rule.trigger} ➔ ${rule.emoji}\n║ 📌 Estado atual: ${rule.active ? 'ATIVA' : 'DESATIVADA'}\n║ 🌐 Escopo: ${rule.scope}\n╠════════════════════════════════════════════════════════════╣\n║ Ação: ${data.action === 'delete' ? 'EXCLUSÃO SOFT-DELETE' : data.action === 'enable' ? 'ATIVAÇÃO' : 'DESATIVAÇÃO'}\n╠════════════════════════════════════════════════════════════╣\n║ [1] ✅ Confirmar                                           ║\n║ [2] ❌ Cancelar                                             ║\n╚════════════════════════════════════════════════════════════╝`;
const listRulesForGroups = (groupIds, includeInactive = true) => {
  const rules = service.list({ page: 1, pageSize: 100000, includeInactive }).items;
  if (!groupIds?.length) return rules;
  return rules.filter(rule => rule.scope !== 'LOCAL' || (rule.groupIds || []).some(id => groupIds.includes(id)));
};
const renderRuleList = (rules, title = 'REAÇÕES') => `╔════════════════════════════════════════════════════════════╗\n║ 👑 ${title}\n╠════════════════════════════════════════════════════════════╣\n${rules.map(rule => `║ ${rule.active ? '🟢' : '🔴'} ${rule.id} • ${rule.trigger} ➔ ${rule.emoji}\n║    ${rule.matcher} • ${rule.scope} • ${(rule.groupIds || []).join(', ') || 'global'}`).join('\n') || '║ Nenhuma reação encontrada.'}\n╚════════════════════════════════════════════════════════════╝`;
const detailsRender = rule => `╔════════════════════════════════════════════════════════════╗\n║ 👑 DETALHES • ${rule.id}\n╠════════════════════════════════════════════════════════════╣\n║ 🎯 Gatilho: ${rule.trigger}\n║ 😀 Emoji: ${rule.emoji}\n║ 🔍 Matcher: ${rule.matcher}\n║ 🌐 Escopo: ${rule.scope}\n║ 👥 Grupos: ${(rule.groupIds || []).join(', ') || 'global'}\n║ 🟢 Status: ${rule.active ? 'ATIVA' : 'DESATIVADA'}\n║ ⚡ Acionamentos: ${rule.matches || 0}\n║ 🗓️ Criada: ${rule.createdAt ? new Date(rule.createdAt).toLocaleString('pt-BR') : '—'}\n║ 🗓️ Atualizada: ${rule.updatedAt ? new Date(rule.updatedAt).toLocaleString('pt-BR') : '—'}\n║ 👤 Criador: ${rule.createdBy || 'não registrado'}\n╚════════════════════════════════════════════════════════════╝`;

async function createStep(ctx, session, input) {
  const data = session.state.data;
  if (input === '0') return closeSession(ctx), send(ctx, '👻 Operação cancelada.');
  if (session.state.step === 'trigger') { if (!input || input.length > 120) return send(ctx, '❌ Gatilho inválido.'); data.trigger = input; session.state.step = 'emoji'; return send(ctx, '😀 *ETAPA 2/5 — EMOJI*\nEnvie um emoji.\n0 = cancelar'); }
  if (session.state.step === 'emoji') { if (!input || [...input].length > 16) return send(ctx, '❌ Emoji inválido.'); data.emoji = input; session.state.step = 'matcher'; return send(ctx, '🔍 *ETAPA 3/5 — CORRESPONDÊNCIA*\n1 = EXATA\n2 = PALAVRA\n3 = CONTÉM\n0 = cancelar'); }
  if (session.state.step === 'matcher') { const matcher = { '1': 'EXACT', '2': 'WORD', '3': 'CONTAINS' }[input] || input.toUpperCase(); if (!valid(matcher, ['EXACT', 'WORD', 'CONTAINS'])) return send(ctx, '❌ Escolha 1, 2 ou 3.'); data.matcher = matcher; session.state.step = 'scope'; return send(ctx, '🌐 *ETAPA 4/5 — ESCOPO*\n1 = Este grupo\n2 = Selecionar grupos\n3 = Todos os grupos\n4 = Privado + grupos\n0 = cancelar'); }
  if (session.state.step === 'scope') { const scope = { '1': 'LOCAL', '2': 'LOCAL', '3': 'GLOBAL', '4': 'GLOBAL_PRIVATE' }[input] || input.toUpperCase(); if (!valid(scope, ['LOCAL', 'GLOBAL', 'GLOBAL_PRIVATE'])) return send(ctx, '❌ Escopo inválido.'); data.scope = scope; if (input === '2') { session.state.page = 1; session.state.step = 'groups'; return send(ctx, groupPrompt(ctx, 1)); } data.groupIds = scope === 'LOCAL' && ctx.from ? [ctx.from] : []; session.state.step = 'confirm'; return send(ctx, preview(data)); }
  if (session.state.step === 'groups') { if (/^(próxima|proxima|next)$/i.test(input)) { session.state.page = (session.state.page || 1) + 1; return send(ctx, groupPrompt(ctx, session.state.page, data.groupIds || [])); } if (/^(anterior|prev)$/i.test(input)) { session.state.page = Math.max(1, (session.state.page || 1) - 1); return send(ctx, groupPrompt(ctx, session.state.page, data.groupIds || [])); } const selected = selectGroups(resolvePageInput(input, ctx, session.state.page || 1), groupsOf(ctx), { currentGroupId: ctx.from }); if (selected.search) return send(ctx, selected.results.map((group, index) => `${index + 1}. ${group.name} (${group.id})`).join('\n')); if (selected.cancelled) return closeSession(ctx), send(ctx, '👻 Operação cancelada.'); if (selected.error) return send(ctx, `❌ ${selected.error}`); data.groupIds = selected.ids; session.state.step = 'confirm'; return send(ctx, preview(data)); }
  if (session.state.step === 'confirm') { if (input === '3') return closeSession(ctx), send(ctx, '👻 Criação cancelada.'); if (input === '2') { session.state.step = 'trigger'; session.state.data = {}; return send(ctx, createPrompt()); } if (input !== '1' && !/^confirmar$/i.test(input)) return send(ctx, 'Digite 1 para confirmar, 2 para alterar ou 3 para cancelar.'); const rule = await service.create(data, ctx); closeSession(ctx); return send(ctx, `✅ Reação *${rule.id}* criada com sucesso.`); }
  return send(ctx, createPrompt());
}

async function editStep(ctx, session, input) {
  const data = session.state.data;
  if (input === '0') return closeSession(ctx), send(ctx, '👻 Edição cancelada.');
  if (session.state.step === 'edit-groups') { if (/^(próxima|proxima|next)$/i.test(input)) { session.state.page = (session.state.page || 1) + 1; return send(ctx, groupPrompt(ctx, session.state.page, data.groupIds || [])); } if (/^(anterior|prev)$/i.test(input)) { session.state.page = Math.max(1, (session.state.page || 1) - 1); return send(ctx, groupPrompt(ctx, session.state.page, data.groupIds || [])); } const selected = selectGroups(resolvePageInput(input, ctx, session.state.page || 1), groupsOf(ctx), { currentGroupId: ctx.from }); if (selected.cancelled) return closeSession(ctx), send(ctx, '👻 Edição cancelada.'); if (selected.error) return send(ctx, `❌ ${selected.error}`); if (selected.search) return send(ctx, selected.results.map((g, i) => `${i + 1}. ${g.name} (${g.id})`).join('\n')); data.groupIds = selected.ids; session.state.step = 'edit-confirm'; return send(ctx, editPreview(session.state.before, data)); }
  if (session.state.step === 'edit-id') { try { const rule = service.details(input); session.state.before = structuredClone(rule); session.state.data = { id: rule.id, trigger: rule.trigger, emoji: rule.emoji, matcher: rule.matcher, scope: rule.scope, groupIds: rule.groupIds || [] }; session.state.step = 'edit-trigger'; return send(ctx, `✏️ *EDIÇÃO DE ${rule.id}*\n\nEnvie o novo gatilho ou “manter”.\n0 = cancelar`); } catch (error) { return send(ctx, `❌ ${error.message}`); } }
  if (session.state.step === 'edit-trigger') { if (input.toLowerCase() !== 'manter') data.trigger = input; session.state.step = 'edit-emoji'; return send(ctx, '😀 Envie o novo emoji ou “manter”.'); }
  if (session.state.step === 'edit-emoji') { if (input.toLowerCase() !== 'manter') data.emoji = input; session.state.step = 'edit-matcher'; return send(ctx, '🔍 Envie EXACT, WORD, CONTAINS ou “manter”.'); }
  if (session.state.step === 'edit-matcher') { if (input.toLowerCase() !== 'manter') { const matcher = input.toUpperCase(); if (!valid(matcher, ['EXACT', 'WORD', 'CONTAINS'])) return send(ctx, '❌ Matcher inválido.'); data.matcher = matcher; } session.state.step = 'edit-scope'; return send(ctx, '🌐 Envie LOCAL, GLOBAL, GLOBAL_PRIVATE ou “manter”.'); }
  if (session.state.step === 'edit-scope') { if (input.toLowerCase() !== 'manter') { const scope = input.toUpperCase(); if (!valid(scope, ['LOCAL', 'GLOBAL', 'GLOBAL_PRIVATE'])) return send(ctx, '❌ Escopo inválido.'); data.scope = scope; } if (data.scope === 'LOCAL') { session.state.page = 1; session.state.step = 'edit-groups'; return send(ctx, groupPrompt(ctx, 1, data.groupIds || [])); } session.state.step = 'edit-confirm'; return send(ctx, editPreview(session.state.before, data)); }
  if (session.state.step === 'edit-confirm') { if (input === '2' || /^cancelar$/i.test(input)) return closeSession(ctx), send(ctx, '👻 Edição cancelada.'); if (input !== '1' && !/^confirmar$/i.test(input)) return send(ctx, 'Digite 1 para confirmar ou 2 para cancelar.'); const rule = await service.update(data.id, data, ctx); closeSession(ctx); return send(ctx, `✅ Reação *${rule.id}* atualizada.\n\n${detailsRender(rule)}`); }
  return send(ctx, '✏️ Envie o ID da reação para editar.');
}

const listStep = async (ctx, session, input) => {
  if (input === '0') { session.state.step = 'menu'; return send(ctx, centralMenu); }
  if (session.state.step === 'list') {
    if (input.toLowerCase() === 'detalhes') { session.state.step = 'list-detail'; return send(ctx, '🆔 Envie o ID da reação.'); }
    if (/^RX-/i.test(input)) { try { return send(ctx, `${detailsRender(service.details(input))}\n\n0 = voltar`); } catch (error) { return send(ctx, `❌ ${error.message}`); } }
    const page = service.list({ page: Number(input) || 1, pageSize: 3 });
    return send(ctx, `${renderRuleList(page.items)}\n\n📄 Página ${page.page}/${page.totalPages}\nDigite o número da página, um ID para detalhes ou 0 para voltar.`);
  }
  if (session.state.step === 'list-detail') { try { return send(ctx, `${detailsRender(service.details(input))}\n\n0 = voltar`); } catch (error) { return send(ctx, `❌ ${error.message}`); } }
};

const renderStats = stats => `╔════════════════════════════════════════════════════════════╗\n║ 👑 RELATÓRIO • ESTATÍSTICAS                               ║\n╠════════════════════════════════════════════════════════════╣\n║ Regras: ${stats.rules} • Ativas: ${stats.active}\n║ ⚡ Acionamentos: ${stats.matched}\n║ 💬 Reações enviadas: ${stats.reacted}\n║ ❌ Falhas: ${stats.errors}\n║ 🏆 Mais utilizadas: ${(stats.top || []).map(item => `${item.id} (${item.matches})`).join(', ') || 'nenhuma'}\n║ 🌐 Por grupos: ${(stats.byGroup || []).map(item => `${item.groupId} (${item.matches})`).join(', ') || 'nenhum'}\n║ 📅 Período: ${stats.period?.events || 0} eventos\n╚════════════════════════════════════════════════════════════╝`;
const renderHistory = events => `╔════════════════════════════════════════════════════════════╗\n║ 👑 AUDITORIA • LOGS DE ELITE                              ║\n╠════════════════════════════════════════════════════════════╣\n${events.map(event => `║ 🗓️ ${new Date(event.at).toLocaleString('pt-BR')}\n║ 👤 ${event.actor || 'sistema'} • 🏷️ ${event.action}\n║ 📌 ${event.details?.ruleId || ''}`).join('\n') || '║ Nenhum evento encontrado.'}\n╚════════════════════════════════════════════════════════════╝`;
const filterMenu = type => type === 'stats' ? '📊 1 = Geral\n2 = Mais utilizadas\n3 = Por reação\n4 = Por grupos\n5 = Por período\n0 = voltar' : '📜 1 = Todos\n2 = Por grupos\n3 = Por reação\n4 = Por administrador\n5 = Por período\n0 = voltar';
const statsStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'menu'; return send(ctx, centralMenu); } if (input === '4') { session.state.step = 'stats-groups'; session.state.page = 1; return send(ctx, groupPrompt(ctx)); } if (input === '3') { session.state.step = 'stats-rule'; return send(ctx, '🎯 Envie o ID da reação.'); } if (input === '5') { session.state.step = 'stats-period'; return send(ctx, '📅 Envie o período como AAAA-MM-DD AAAA-MM-DD.\nEx.: 2026-09-01 2026-09-24'); } if (input === '1' || input === '2') return send(ctx, renderStats(service.stats({ mode: input, from: 0, to: Date.now() }))); return send(ctx, filterMenu('stats')); };
const statsGroupsStep = async (ctx, session, input) => { if (/^(próxima|proxima|next)$/i.test(input)) { session.state.page = (session.state.page || 1) + 1; return send(ctx, groupPrompt(ctx, session.state.page)); } if (/^(anterior|prev)$/i.test(input)) { session.state.page = Math.max(1, (session.state.page || 1) - 1); return send(ctx, groupPrompt(ctx, session.state.page)); } if (input === '0') { session.state.step = 'stats'; return send(ctx, filterMenu('stats')); } const selected = selectGroups(resolvePageInput(input, ctx, session.state.page || 1), groupsOf(ctx), { currentGroupId: ctx.from }); if (selected.error) return send(ctx, `❌ ${selected.error}`); if (selected.search) return send(ctx, selected.results.map((g, i) => `${i + 1}. ${g.name} (${g.id})`).join('\n')); return send(ctx, renderStats(service.stats({ groupIds: selected.ids, mode: 'group', from: 0, to: Date.now() }))); };
const statsRuleStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'stats'; return send(ctx, filterMenu('stats')); } try { const rule = service.details(input); return send(ctx, renderStats(service.stats({ ruleId: rule.id, mode: 'reaction', from: 0, to: Date.now() }))); } catch (error) { return send(ctx, `❌ ${error.message}`); } };
const parsePeriod = input => { const parts = input.trim().split(/\s+/); if (parts.length !== 2 || !/^\d{4}-\d{2}-\d{2}$/.test(parts[0]) || !/^\d{4}-\d{2}-\d{2}$/.test(parts[1])) return null; const from = new Date(`${parts[0]}T00:00:00`).getTime(); const to = new Date(`${parts[1]}T23:59:59.999`).getTime(); return Number.isFinite(from) && Number.isFinite(to) ? { from, to } : null; };
const statsPeriodStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'stats'; return send(ctx, filterMenu('stats')); } const period = parsePeriod(input); if (!period) return send(ctx, '❌ Período inválido. Use AAAA-MM-DD AAAA-MM-DD.'); return send(ctx, renderStats(service.stats({ mode: 'period', ...period }))); };
const historyStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'menu'; return send(ctx, centralMenu); } if (input === '2') { session.state.step = 'history-groups'; session.state.page = 1; return send(ctx, groupPrompt(ctx)); } if (input === '3') { session.state.step = 'history-rule'; return send(ctx, '🎯 Envie o ID da reação.'); } if (input === '4') { session.state.step = 'history-actor'; return send(ctx, '👤 Envie o identificador do administrador.'); } if (input === '5') { session.state.step = 'history-period'; return send(ctx, '📅 Envie o período como AAAA-MM-DD AAAA-MM-DD.'); } return send(ctx, renderHistory(service.history({ from: 0, to: Date.now() }))); };
const historyGroupsStep = async (ctx, session, input) => { if (/^(próxima|proxima|next)$/i.test(input)) { session.state.page = (session.state.page || 1) + 1; return send(ctx, groupPrompt(ctx, session.state.page)); } if (/^(anterior|prev)$/i.test(input)) { session.state.page = Math.max(1, (session.state.page || 1) - 1); return send(ctx, groupPrompt(ctx, session.state.page)); } if (input === '0') { session.state.step = 'history'; return send(ctx, filterMenu('history')); } const selected = selectGroups(resolvePageInput(input, ctx, session.state.page || 1), groupsOf(ctx), { currentGroupId: ctx.from }); if (selected.error) return send(ctx, `❌ ${selected.error}`); if (selected.search) return send(ctx, selected.results.map((g, i) => `${i + 1}. ${g.name} (${g.id})`).join('\n')); return send(ctx, renderHistory(service.history({ groupIds: selected.ids, from: 0, to: Date.now() }))); };
const historyRuleStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'history'; return send(ctx, filterMenu('history')); } try { const rule = service.details(input); return send(ctx, renderHistory(service.history({ ruleId: rule.id, from: 0, to: Date.now() }))); } catch (error) { return send(ctx, `❌ ${error.message}`); } };
const historyActorStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'history'; return send(ctx, filterMenu('history')); } return send(ctx, renderHistory(service.history({ actor: input, from: 0, to: Date.now() }))); };
const historyPeriodStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'history'; return send(ctx, filterMenu('history')); } const period = parsePeriod(input); if (!period) return send(ctx, '❌ Período inválido. Use AAAA-MM-DD AAAA-MM-DD.'); return send(ctx, renderHistory(service.history({ ...period }))); };
const configStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'menu'; return send(ctx, centralMenu); } if (input === '1') { const result = await service.setConfig({ enabled: !service.getConfig().enabled }, ctx); return send(ctx, `🛠️ Sistema automático: ${result.enabled ? '🟢 ativo' : '🔴 desativado'}\n\n${filterMenu('config')}`); } if (input === '2') return send(ctx, `🌐 Escopos: ${Object.entries(service.getConfig().allowedScopes).map(([key, value]) => `${key}: ${value ? '🟢' : '🔴'}`).join(' | ')}`); if (input === '3') return send(ctx, `⏱️ Limites: ${JSON.stringify(service.getConfig().limits)}`); if (input === '4') { session.state.step = 'maintenance'; return send(ctx, '🧹 1 = Limpar métricas\n2 = Limpar dados temporários\n3 = Recarregar regras\n4 = Verificar integridade\n0 = voltar'); } return send(ctx, '❌ Opção inválida.'); };
const maintenanceStep = async (ctx, session, input) => {
  if (session.state.confirmMaintenance) {
    if (input === '1' || /^confirmar$/i.test(input)) {
      session.state.confirmMaintenance = false;
      await service.clearMetrics(ctx);
      return send(ctx, '✅ Métricas limpas.');
    }
    if (input === '2' || /^cancelar$/i.test(input)) {
      session.state.confirmMaintenance = false;
      return send(ctx, '👻 Limpeza cancelada.');
    }
    return send(ctx, 'Digite 1 para confirmar ou 2 para cancelar.');
  }
  if (input === '0') { session.state.step = 'config'; return send(ctx, '🛠️ 1 = Sistema\n2 = Escopos\n3 = Limites\n4 = Manutenção\n0 = voltar'); }
  if (input === '1') { session.state.confirmMaintenance = true; return send(ctx, '⚠️ Limpar métricas apagará contadores e eventos métricos das reações.\n1 = confirmar\n2 = cancelar'); }
  if (input === '2') { resetSessions(); return send(ctx, '✅ Dados temporários limpos.'); }
  if (input === '3') { service.reload(); return send(ctx, '✅ Regras recarregadas da persistência oficial.'); }
  if (input === '4') return send(ctx, `✅ Integridade: ${service.integrity().ok ? 'OK' : 'FALHA'}`);
  return send(ctx, '❌ Opção inválida.');
};

async function manageStep(ctx, session, input) { if (input === '0') { session.state.step = 'menu'; return send(ctx, centralMenu); } const actions = { '1': 'edit', '2': 'enable', '3': 'disable', '4': 'delete' }; if (actions[input]) { session.state.data = { action: actions[input], groupIds: [] }; session.state.page = 1; session.state.step = 'manage-groups'; return send(ctx, groupPrompt(ctx)); } return send(ctx, '❌ Escolha 1, 2, 3 ou 4.'); }
const manageGroupsStep = async (ctx, session, input) => { if (/^(próxima|proxima|next)$/i.test(input)) { session.state.page = (session.state.page || 1) + 1; return send(ctx, groupPrompt(ctx, session.state.page)); } if (/^(anterior|prev)$/i.test(input)) { session.state.page = Math.max(1, (session.state.page || 1) - 1); return send(ctx, groupPrompt(ctx, session.state.page)); } if (input === '0') { session.state.step = 'manage'; return send(ctx, '⚙️ 1 = Editar reação\n2 = Ativar\n3 = Desativar\n4 = Excluir\n0 = voltar'); } const selected = selectGroups(resolvePageInput(input, ctx, session.state.page || 1), groupsOf(ctx), { currentGroupId: ctx.from }); if (selected.error) return send(ctx, `❌ ${selected.error}`); if (selected.search) return send(ctx, selected.results.map((g, i) => `${i + 1}. ${g.name} (${g.id})`).join('\n')); session.state.data.groupIds = selected.ids; const allRules = listRulesForGroups(selected.ids, true); const action = session.state.data.action; const rules = action === 'enable' ? allRules.filter(rule => !rule.active) : action === 'disable' ? allRules.filter(rule => rule.active) : allRules; if (!rules.length) return send(ctx, '❌ Nenhuma reação encontrada nesses grupos. Escolha outros grupos ou 0 para voltar.'); session.state.data.rules = rules.map(r => r.id); session.state.step = 'manage-id'; return send(ctx, `${renderRuleList(rules, 'REAÇÕES DISPONÍVEIS') }\n\n🆔 Envie o ID da reação.`); };
const manageIdStep = async (ctx, session, input) => { if (input === '0') { session.state.step = 'manage'; return send(ctx, '⚙️ 1 = Editar reação\n2 = Ativar\n3 = Desativar\n4 = Excluir\n0 = voltar'); } try { const rule = service.details(input); if (session.state.data.rules?.length && !session.state.data.rules.includes(rule.id)) return send(ctx, '❌ Essa reação não pertence aos grupos selecionados.'); session.state.data.id = rule.id; if (session.state.data.action === 'edit') { session.state.before = structuredClone(rule); session.state.data = { id: rule.id, trigger: rule.trigger, emoji: rule.emoji, matcher: rule.matcher, scope: rule.scope, groupIds: rule.groupIds || [] }; session.state.step = 'edit-trigger'; return send(ctx, `✏️ *EDIÇÃO DE ${rule.id}*\n\nEnvie o novo gatilho ou “manter”.\n0 = cancelar`); } session.state.step = 'manage-confirm'; return send(ctx, managePreview(session.state.data, rule)); } catch (error) { return send(ctx, `❌ ${error.message}`); } };
const manageConfirmStep = async (ctx, session, input) => { if (input === '2' || /^cancelar$/i.test(input)) { session.state.step = 'manage'; return send(ctx, '👻 Operação cancelada.\n\n' + centralMenu); } if (input !== '1' && !/^confirmar$/i.test(input)) return send(ctx, 'Digite 1 para confirmar ou 2 para cancelar.'); const { action, id } = session.state.data; const rule = action === 'delete' ? await service.softDelete(id, ctx) : await service.toggle(id, action === 'enable', ctx); session.state.step = 'menu'; return send(ctx, `✅ Reação *${rule.id}* ${action === 'delete' ? 'excluída com soft-delete' : action === 'enable' ? 'ativada' : 'desativada'}.\n\n${centralMenu}`); };

async function menuStep(ctx, session, input) { if (input === '0') return closeSession(ctx), send(ctx, '👻 Central fechada.'); if (input === '1') { session.state.step = 'trigger'; session.state.data = {}; return send(ctx, createPrompt()); } if (input === '2') { session.state.step = 'list'; return listStep(ctx, session, '1'); } if (input === '3') { session.state.step = 'manage'; return send(ctx, '⚙️ 1 = Editar reação\n2 = Ativar\n3 = Desativar\n4 = Excluir\n0 = voltar'); } if (input === '4') { session.state.step = 'stats'; return send(ctx, filterMenu('stats')); } if (input === '5') { session.state.step = 'history'; return send(ctx, filterMenu('history')); } if (input === '6') { session.state.step = 'config'; return send(ctx, '🛠️ 1 = Sistema\n2 = Escopos\n3 = Limites\n4 = Manutenção\n0 = voltar'); } return send(ctx, centralMenu); }

export async function handleSession(ctx) {
  if (!configuredOwner(ctx?.sender)) return { handled: false };
  const session = getSession(ctx); if (!session) return { handled: false };
  const input = String(ctx.body || ctx.text || '').trim(); if (!input || input.startsWith(ctx.prefix || config.prefix)) return { handled: false };
  const step = session.state.step;
  if (step === 'menu') return menuStep(ctx, session, input);
  if (['trigger', 'emoji', 'matcher', 'scope', 'groups', 'confirm'].includes(step)) return createStep(ctx, session, input);
  if (['edit-id', 'edit-trigger', 'edit-emoji', 'edit-matcher', 'edit-scope', 'edit-groups', 'edit-confirm'].includes(step)) return editStep(ctx, session, input);
  if (step === 'manage') return manageStep(ctx, session, input);
  if (step === 'manage-groups') return manageGroupsStep(ctx, session, input);
  if (step === 'manage-id') return manageIdStep(ctx, session, input);
  if (step === 'manage-confirm') return manageConfirmStep(ctx, session, input);
  if (['list', 'list-detail'].includes(step)) return listStep(ctx, session, input);
  if (step === 'stats') return statsStep(ctx, session, input);
  if (step === 'stats-groups') return statsGroupsStep(ctx, session, input);
  if (step === 'stats-rule') return statsRuleStep(ctx, session, input);
  if (step === 'stats-period') return statsPeriodStep(ctx, session, input);
  if (step === 'history') return historyStep(ctx, session, input);
  if (step === 'history-groups') return historyGroupsStep(ctx, session, input);
  if (step === 'history-rule') return historyRuleStep(ctx, session, input);
  if (step === 'history-actor') return historyActorStep(ctx, session, input);
  if (step === 'history-period') return historyPeriodStep(ctx, session, input);
  if (step === 'config') return configStep(ctx, session, input);
  if (step === 'maintenance') return maintenanceStep(ctx, session, input);
  closeSession(ctx); return { handled: false };
}

export { renderStats, renderHistory };
export default { startSession, getSession, closeSession, handleSession, sessionCount, clearExpired, resetSessions };
