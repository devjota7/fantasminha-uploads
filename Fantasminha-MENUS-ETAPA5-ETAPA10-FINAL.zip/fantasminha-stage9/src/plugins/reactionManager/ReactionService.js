import { readCollection, updateCollection } from '../../database/store.js';
import { auditFind, recordAudit } from '../../platform/audit/index.js';

export const COLLECTION = 'reaction-manager';
export const MAX_RULES = 500;
const now = () => Date.now();
const seenMessages = new Map();
const ruleLastReaction = new Map();
const SEEN_TTL_MS = 5 * 60 * 1000;
const norm = value => String(value ?? '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('pt-BR');
const escapeRegExp = value => String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const defaults = () => ({ version: 3, rules: [], stats: { matched: 0, reacted: 0, errors: 0, lastMatchAt: null }, config: { enabled: true, allowedScopes: { LOCAL: true, GLOBAL: true, GLOBAL_PRIVATE: true }, limits: { maxRules: MAX_RULES, cooldownMs: 0, maxReactionsPerMessage: 1 } } });

export function loadState() {
  const state = readCollection(COLLECTION, defaults());
  state.rules = Array.isArray(state.rules) ? state.rules : [];
  state.stats = { ...defaults().stats, ...(state.stats || {}) };
  state.config = { ...defaults().config, ...(state.config || {}), allowedScopes: { ...defaults().config.allowedScopes, ...(state.config?.allowedScopes || {}) }, limits: { ...defaults().config.limits, ...(state.config?.limits || {}) } };
  return state;
}
const allRules = state => Array.isArray(state.rules) ? state.rules : [];
const activeRules = state => allRules(state).filter(rule => !rule.deletedAt && rule.active);
const inactiveRules = state => allRules(state).filter(rule => !rule.deletedAt && !rule.active);
const deletedRules = state => allRules(state).filter(rule => Boolean(rule.deletedAt));
const findManageableRule = (state, value) => { const key = String(value ?? '').trim().toLowerCase(); return allRules(state).find((rule, index) => !rule.deletedAt && (rule.id?.toLowerCase() === key || String(index + 1) === key)) || null; };

export function matches(rule, text) { const source = norm(text), trigger = norm(rule?.trigger); if (!source || !trigger) return false; if (rule.matcher === 'CONTAINS') return source.includes(trigger); if (rule.matcher === 'WORD') return new RegExp(`(^|[^\\p{L}\\p{N}_])${escapeRegExp(trigger)}(?=$|[^\\p{L}\\p{N}_])`, 'iu').test(source); return source === trigger; }
export function targets(rule, ctx = {}) { if (rule.scope === 'GLOBAL') return true; if (rule.scope === 'GLOBAL_PRIVATE') return true; return Boolean(ctx.isGroup) && (!rule.groupIds?.length || rule.groupIds.includes(ctx.from)); }
function validate(data, state = loadState()) { const trigger = String(data.trigger ?? '').trim(), emoji = String(data.emoji ?? '').trim(), matcher = String(data.matcher || 'EXACT').toUpperCase(), scope = String(data.scope || 'LOCAL').toUpperCase(); if (!trigger || trigger.length > 120) throw new Error('O gatilho deve ter entre 1 e 120 caracteres.'); if (!emoji || [...emoji].length > 16) throw new Error('Informe um emoji válido.'); if (!['EXACT', 'WORD', 'CONTAINS'].includes(matcher)) throw new Error('Matcher inválido.'); if (!state.config.allowedScopes[scope]) throw new Error('Este escopo está desativado nas configurações.'); return { trigger, emoji, matcher, scope }; }
async function audit(ctx, action, rule = null, before = null, after = null, details = {}) { return recordAudit({ actor: ctx?.sender || null, target: ctx?.from || null, scope: ctx?.from || null, action, before, after, details: { ...details, ruleId: rule?.id || after?.id || before?.id || null } }); }

export async function create(data, ctx = {}) { const state = loadState(); if (activeRules(state).length >= Number(state.config.limits.maxRules || MAX_RULES)) throw new Error('Limite de regras atingido.'); const values = validate(data, state); const requestedId = data.id ? String(data.id) : null; const duplicate = state.rules.find(rule => (requestedId && rule.id === requestedId) || (activeRules(state).includes(rule) && norm(rule.trigger) === norm(values.trigger) && rule.matcher === values.matcher && rule.scope === values.scope && JSON.stringify([...(rule.groupIds || [])].sort()) === JSON.stringify([...(data.groupIds || [])].sort()))); if (duplicate) throw new Error(`Regra duplicada: ${duplicate.id}.`); const rule = { id: requestedId || `RX-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`, ...values, groupIds: values.scope === 'LOCAL' ? (data.groupIds || (ctx.from ? [ctx.from] : [])) : [], active: true, createdAt: now(), updatedAt: now(), matches: 0, matchEvents: [], createdBy: ctx?.sender || null }; await updateCollection(COLLECTION, current => { const next = { ...defaults(), ...current, rules: Array.isArray(current.rules) ? current.rules : [] }; next.rules.push(rule); return next; }, defaults()); await audit(ctx, 'REACTION_CREATED', rule, null, rule); return rule; }
export async function update(value, data, ctx = {}) { const state = loadState(), current = findManageableRule(state, value); if (!current) throw new Error('Essa reação não existe ou foi excluída.'); const values = validate({ ...current, ...data }, state); const updated = { ...current, ...values, groupIds: values.scope === 'LOCAL' ? (data.groupIds || current.groupIds || (ctx.from ? [ctx.from] : [])) : [], active: data.active === undefined ? current.active : Boolean(data.active), deletedAt: null, updatedAt: now() }; await updateCollection(COLLECTION, next => ({ ...next, rules: next.rules.map(rule => rule.id === current.id ? updated : rule) }), defaults()); await audit(ctx, 'REACTION_UPDATED', current, current, updated); return updated; }
export async function toggle(value, active, ctx = {}) { const state = loadState(), current = findManageableRule(state, value); if (!current) throw new Error('Essa reação não existe ou foi excluída.'); const updated = { ...current, active: Boolean(active), updatedAt: now() }; await updateCollection(COLLECTION, next => ({ ...next, rules: next.rules.map(rule => rule.id === current.id ? updated : rule) }), defaults()); await audit(ctx, active ? 'REACTION_ENABLED' : 'REACTION_DISABLED', current, current, updated); return updated; }
export async function softDelete(value, ctx = {}) { const state = loadState(), current = findManageableRule(state, value); if (!current) throw new Error('Essa reação não existe ou já foi excluída.'); const updated = { ...current, active: false, deletedAt: now(), updatedAt: now() }; await updateCollection(COLLECTION, next => ({ ...next, rules: next.rules.map(rule => rule.id === current.id ? updated : rule) }), defaults()); await audit(ctx, 'REACTION_DELETED', current, current, updated); return updated; }
export async function clear(ctx = {}) { const state = loadState(), before = activeRules(state); const at = now(); await updateCollection(COLLECTION, next => ({ ...next, rules: next.rules.map(rule => rule.deletedAt || !rule.active ? rule : { ...rule, active: false, updatedAt: at }) }), defaults()); await audit(ctx, 'REACTION_DISABLED', null, before, null, { count: before.length }); return before.length; }
export function list({ page = 1, pageSize = 3, includeInactive = false, includeDeleted = false } = {}) { const state = loadState(); const rules = includeDeleted ? deletedRules(state) : (includeInactive ? [...activeRules(state), ...inactiveRules(state)] : activeRules(state)); const totalPages = Math.max(1, Math.ceil(rules.length / pageSize)), currentPage = Math.min(Math.max(1, Number(page) || 1), totalPages); return { items: rules.slice((currentPage - 1) * pageSize, currentPage * pageSize), page: currentPage, pageSize, total: rules.length, totalPages }; }
export function details(value) { const rule = findManageableRule(loadState(), value); if (!rule) throw new Error('Essa reação não existe ou foi excluída.'); return rule; }
export function getConfig() { return loadState().config; }
export async function setConfig(patch, ctx = {}) { const nextConfig = await updateCollection(COLLECTION, state => ({ ...defaults(), ...state, config: { ...loadState().config, ...patch, allowedScopes: { ...loadState().config.allowedScopes, ...(patch.allowedScopes || {}) }, limits: { ...loadState().config.limits, ...(patch.limits || {}) } } }), defaults()); await audit(ctx, 'REACTION_CONFIG_UPDATED', null, null, nextConfig.config); return nextConfig.config; }
export async function clearMetrics(ctx = {}) { const before = loadState().stats; await updateCollection(COLLECTION, state => ({ ...state, stats: defaults().stats, rules: state.rules.map(rule => ({ ...rule, matches: 0, matchEvents: [] })) }), defaults()); await audit(ctx, 'REACTION_METRICS_CLEARED', null, before, defaults().stats); }
export function reload() { return loadState(); }
export function integrity() { const state = loadState(), errors = []; const ids = new Set(); for (const rule of state.rules) { if (!rule.id || ids.has(rule.id)) errors.push(`ID duplicado: ${rule.id}`); ids.add(rule.id); if (!['EXACT', 'WORD', 'CONTAINS'].includes(rule.matcher)) errors.push(`Matcher inválido: ${rule.id}`); } return { ok: errors.length === 0, errors, rules: state.rules.length }; }

export function stats({ groupIds = null, ruleId = null, from = 0, to = Infinity, mode = 'all' } = {}) { const state = loadState(); const rules = activeRules(state).filter(rule => (!groupIds?.length || rule.scope !== 'LOCAL' || (rule.groupIds || []).some(id => groupIds.includes(id))) && (!ruleId || rule.id === ruleId)); const top = [...rules].sort((a, b) => (b.matches || 0) - (a.matches || 0)).slice(0, 10).map(rule => ({ id: rule.id, trigger: rule.trigger, matches: rule.matches || 0 })); const byGroup = {}; for (const rule of rules) for (const groupId of rule.groupIds || []) { byGroup[groupId] ||= { groupId, rules: 0, matches: 0 }; byGroup[groupId].rules++; byGroup[groupId].matches += rule.matches || 0; } const periodEvents = auditFind(event => ['REACTION_MATCHED', 'REACTION_SENT'].includes(event.action) && event.at >= from && event.at <= to); return { ...state.stats, rules: rules.length, active: rules.filter(rule => rule.active).length, top, byReaction: rules.map(rule => ({ id: rule.id, trigger: rule.trigger, matches: rule.matches || 0 })), byGroup: Object.values(byGroup), period: { from, to, events: periodEvents.length }, mode }; }
export function history({ filter = '1', groupIds = null, ruleId = null, actor = null, from = 0, to = Infinity, limit = 50 } = {}) { let events = auditFind(event => event.action?.startsWith('REACTION_') && event.at >= from && event.at <= to); if (groupIds?.length) events = events.filter(event => groupIds.includes(event.scope) || groupIds.includes(event.target)); if (ruleId) events = events.filter(event => event.details?.ruleId === ruleId || event.before?.id === ruleId || event.after?.id === ruleId); if (actor) events = events.filter(event => String(event.actor) === String(actor)); return events.slice(-limit).reverse(); }

export async function executeAutomatic(ctx, sendReaction) {
  const state = loadState();
  if (!state.config.enabled || !ctx || ctx.fromMe || !ctx.message?.key?.id) return { handled: false };
  const messageId = String(ctx.message.key.id);
  const current = now();
  for (const [key, at] of seenMessages) if (current - at > SEEN_TTL_MS) seenMessages.delete(key);
  if (seenMessages.has(messageId)) return { handled: false, duplicate: true };
  seenMessages.set(messageId, current);
  const text = String(ctx.body || ctx.text || '').trim();
  if (!text || text.startsWith(ctx.prefix || '×')) return { handled: false };
  const candidates = activeRules(state).filter(rule => rule.active && targets(rule, ctx) && matches(rule, text));
  candidates.sort((a, b) => ({ EXACT: 3, WORD: 2, CONTAINS: 1 }[b.matcher] || 0) - ({ EXACT: 3, WORD: 2, CONTAINS: 1 }[a.matcher] || 0) || a.createdAt - b.createdAt);
  const maxPerMessage = Math.max(1, Number(state.config.limits.maxReactionsPerMessage || 1));
  const selected = candidates.slice(0, maxPerMessage);
  if (!selected.length) return { handled: false };
  const reactedRules = [];
  for (const rule of selected) {
    const cooldownMs = Math.max(0, Number(state.config.limits.cooldownMs || 0));
    const cooldownKey = `${rule.id}::${ctx.from || 'private'}`;
    if (cooldownMs && current - Number(ruleLastReaction.get(cooldownKey) || 0) < cooldownMs) continue;
    state.stats.matched++;
    rule.matches = (rule.matches || 0) + 1;
    rule.matchEvents ||= [];
    rule.matchEvents.push({ at: current, groupId: ctx.from || null });
    state.stats.lastMatchAt = current;
    try {
      await sendReaction(ctx, rule.emoji);
      ruleLastReaction.set(cooldownKey, current);
      state.stats.reacted++;
      reactedRules.push(rule.id);
      await audit(ctx, 'REACTION_MATCHED', rule, null, null);
      await audit(ctx, 'REACTION_SENT', rule, null, null);
    } catch (error) {
      state.stats.errors++;
      await audit(ctx, 'REACTION_FAILED', rule, null, null, { error: error.message });
    }
  }
  await updateCollection(COLLECTION, () => state, defaults());
  return reactedRules.length ? { handled: true, reacted: true, ruleId: reactedRules[0], ruleIds: reactedRules } : { handled: false };
}
export default { loadState, matches, targets, create, update, toggle, softDelete, clear, list, details, getConfig, setConfig, clearMetrics, reload, integrity, stats, history, executeAutomatic };
