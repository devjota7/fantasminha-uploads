import { registerCommand } from '../../core/registry.js';
import { Role, configuredOwner } from '../../core/permissions.js';
import { handle, handleSession as handleSessionController } from './ReactController.js';
import { executeAutomatic } from './ReactionService.js';

async function sendReaction(ctx, emoji) {
  const socket = ctx.sock || ctx.socket;
  const key = ctx.message?.key || ctx.key;
  if (!socket?.sendMessage || !ctx.from || !key) throw new Error('Contexto Baileys insuficiente');
  await socket.sendMessage(ctx.from, { react: { text: emoji, key } });
}

export async function register() {
  registerCommand({
    name: 'react',
    aliases: [],
    category: 'dono',
    plugin: 'reactionManager',
    permission: Role.OWNER,
    ownerOnly: true,
    priority: 1000,
    cooldown: 1,
    description: 'Abre a Central administrativa de reações.',
    usage: '×react',
    classification: 'ACTIVE',
    audit: true,
    handler: async ctx => handle({ ...ctx, isOwner: configuredOwner(ctx.sender) })
  });
}

export async function handleAutomaticReaction(ctx) {
  return executeAutomatic(ctx, sendReaction);
}

export async function handleSession(ctx) {
  if (!configuredOwner(ctx?.sender)) return { handled: false };
  return handleSessionController(ctx);
}

export { handle };
export default { register, handleAutomaticReaction, handleSession, handle };
