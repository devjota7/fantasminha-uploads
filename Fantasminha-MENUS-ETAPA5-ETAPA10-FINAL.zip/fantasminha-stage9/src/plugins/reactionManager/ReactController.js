import { startSession, handleSession as handleOfficialSession, centralMenu } from './SessionManager.js';
import { configuredOwner } from '../../core/permissions.js';

const help = () => `👑 *Fantasminha React Central*\n\n×react abre a Central administrativa oficial.\nEscolha uma opção pelo número.\n\n0️⃣ Cancelar e fechar painel.`;
const ownerOnly = ctx => configuredOwner(ctx?.sender);
const send = async (ctx, text) => { await ctx.reply?.(text); return { found: true }; };

/**
 * Entrada única do comando. Toda regra de negócio e toda máquina de estados
 * vivem no SessionManager/ReactionService; este módulo apenas autoriza e inicia.
 */
export async function handle(ctx = {}) {
  if (!ownerOnly(ctx)) return send(ctx, '👻 ×react é exclusivo do dono autorizado.');
  startSession(ctx);
  return send(ctx, `${centralMenu}\n\n${help()}`);
}

export async function handleSession(ctx = {}) {
  if (!ownerOnly(ctx)) return { handled: false };
  return handleOfficialSession(ctx);
}

export const menu = () => centralMenu;
export default { handle, handleSession, menu };
