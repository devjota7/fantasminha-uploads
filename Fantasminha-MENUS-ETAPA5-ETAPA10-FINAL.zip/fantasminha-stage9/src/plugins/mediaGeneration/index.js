import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { generateBrat } from '../../services/bratEngine.js';

export async function register() {
  registerCommand({
    name: 'brat', aliases: ['brata', 'abrat'], category: 'midia', plugin: 'mediaGeneration',
    permission: Role.USER, cooldown: 2, description: 'Gera figurinha Brat a partir de texto.',
    usage: '×brat <texto> [| fundo | cor do texto | blur]',
    handler: async ctx => {
      const raw = String(ctx.qRaw ?? ctx.q ?? '').trim();
      if (!raw) return ctx.reply('👻 *BRAT*\n\nUse: ×brat <texto>\nOpcional: texto | fundo | cor do texto | blur\nAté 500 caracteres e 10 linhas.');
      const parts = raw.split('|').map(x => x.trim());
      try {
        const result = await generateBrat({ text: parts[0], background: parts[1] || 'white', textColor: parts[2] || 'black', blur: parts[3] || 0, actor: ctx.sender || ctx.from || 'global' });
        const sock = ctx.sock || ctx.socket;
        if (!sock?.sendMessage) return ctx.reply('❌ A conexão de mídia não está disponível.');
        await sock.sendMessage(ctx.from || ctx.sender, { sticker: result.buffer, mimetype: 'image/webp' }, ctx.message ? { quoted: ctx.message } : undefined);
        return { ok: true, cached: Boolean(result.cached), lines: result.lines };
      } catch (error) {
        return ctx.reply(`❌ *BRAT*\n${error?.message || 'Não foi possível gerar a figurinha.'}`);
      }
    }
  });
}
export default { register };
