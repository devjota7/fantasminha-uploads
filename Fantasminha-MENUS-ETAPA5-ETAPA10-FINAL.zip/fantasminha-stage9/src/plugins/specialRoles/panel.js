import config from '../../core/config.js';
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { SPECIAL_ROLE, SPECIAL_ROLE_META, SPECIAL_ROLES_FOR_MANAGEMENT } from '../../core/specialRoles.js';
import * as manager from '../../services/specialRoleManagement.js';

const sessions = new Map();
const TTL = 10 * 60 * 1000;
const keyOf = ctx => `${ctx.from || 'private'}|${ctx.sender || ctx.senderOriginal || ''}`;
const nav = '\n\n9️⃣ Voltar · 0️⃣ Cancelar';
const label = role => SPECIAL_ROLE_META[role]?.label || role;
const roleMenu = () => SPECIAL_ROLES_FOR_MANAGEMENT.map((r, i) => `${i + 1}️⃣ ${label(r)}`).join('\n');

function open(ctx, step = 'main', data = {}) {
  sessions.set(keyOf(ctx), { step, data, expires: Date.now() + TTL });
}
function close(ctx) { sessions.delete(keyOf(ctx)); }
export function hasSession(ctx) { return sessions.has(keyOf(ctx)); }
export function clearSessions() { sessions.clear(); }

function mainText() {
  return [
    '👻 *FANTASMINHA · GERENCIAR CARGOS*',
    '',
    '🔐 Acesso exclusivo: 👑 Dono Principal',
    '',
    '1️⃣ Adicionar cargo',
    '2️⃣ Remover cargo',
    '3️⃣ Listar cargos especiais',
    '4️⃣ Listar pessoas com cargo',
    '5️⃣ Ver cargos de uma pessoa',
    '6️⃣ Estatísticas',
    '0️⃣ Cancelar'
  ].join('\n');
}

function peopleText(ctx, roleId) {
  const rows = manager.listRoleAssignments(ctx, roleId);
  if (!rows.length) return `${label(roleId)}\n\nNenhuma pessoa encontrada.${nav}`;
  return `${label(roleId)}\n\n${rows.map((r, i) => `${i + 1}. @${String(r.id).split('@')[0]}`).join('\n')}${nav}`;
}

function allPeopleText(ctx) {
  const blocks = SPECIAL_ROLES_FOR_MANAGEMENT.map(roleId => {
    const rows = manager.listRoleAssignments(ctx, roleId);
    return `${label(roleId)}: ${rows.length}`;
  });
  return ['📊 *PESSOAS POR CARGO*', '', ...blocks, '', 'Use 4 para detalhar um cargo.', nav].join('\n');
}

function statsText(ctx) {
  const rows = SPECIAL_ROLES_FOR_MANAGEMENT.map(roleId => ({ roleId, count: manager.listRoleAssignments(ctx, roleId).length }));
  const total = rows.reduce((sum, x) => sum + x.count, 0);
  return ['📈 *ESTATÍSTICAS DE CARGOS*', '', ...rows.map(x => `${label(x.roleId)}: *${x.count}*`), '', `Total de atribuições: *${total}*`, 'O mesmo usuário pode aparecer em mais de um status.', nav].join('\n');
}

function roleFromNumber(text) {
  const n = Number(text);
  return Number.isInteger(n) && n >= 1 && n <= SPECIAL_ROLES_FOR_MANAGEMENT.length ? SPECIAL_ROLES_FOR_MANAGEMENT[n - 1] : null;
}

function targetFrom(ctx, text) {
  return ctx.mentioned?.[0] || ctx.quotedParticipant || text || null;
}

async function step(ctx, text) {
  const s = sessions.get(keyOf(ctx));
  if (!s) return false;
  if (Date.now() > s.expires) { close(ctx); return false; }
  s.expires = Date.now() + TTL;
  const value = String(text || '').trim();
  if (!value) return true;
  if (value === '0') { close(ctx); await ctx.reply('❌ Painel de cargos cancelado.'); return true; }
  if (value === '9' && s.step !== 'main') { s.step = 'main'; s.data = {}; await ctx.reply(mainText()); return true; }

  if (s.step === 'main') {
    if (value === '1') { s.step = 'add_role'; return ctx.reply(`➕ *ADICIONAR CARGO*\n\n${roleMenu()}${nav}`); }
    if (value === '2') { s.step = 'remove_role'; return ctx.reply(`➖ *REMOVER CARGO*\n\n${roleMenu()}${nav}`); }
    if (value === '3') return ctx.reply(`🏷️ *CARGOS ESPECIAIS GERENCIÁVEIS*\n\n${roleMenu()}\n\n👑 Dono Principal: fixo, não atribuível pelo painel.\n🚫 ADM do WhatsApp, Bot Admin e Moderador de grupo não aparecem aqui.${nav}`);
    if (value === '4') { s.step = 'people_role'; return ctx.reply(`👥 *LISTAR PESSOAS COM CARGO*\n\n${roleMenu()}${nav}`); }
    if (value === '5') { s.step = 'inspect_target'; return ctx.reply(`🔎 *VER CARGOS DE UMA PESSOA*\n\nMencione, responda ou informe o identificador.${nav}`); }
    if (value === '6') return ctx.reply(statsText(ctx));
    return ctx.reply('Escolha uma opção de 0 a 6.');
  }

  if (s.step === 'add_role' || s.step === 'remove_role' || s.step === 'people_role') {
    const roleId = roleFromNumber(value);
    if (!roleId) return ctx.reply(`Escolha de 1 a ${SPECIAL_ROLES_FOR_MANAGEMENT.length}.`);
    s.data.roleId = roleId;
    if (s.step === 'add_role') s.step = 'add_target';
    else if (s.step === 'remove_role') s.step = 'remove_target';
    else s.step = 'people_list';
    if (s.step === 'people_list') return ctx.reply(peopleText(ctx, roleId));
    return ctx.reply(`${label(roleId)}\n\nEnvie uma menção, responda à mensagem da pessoa ou informe o identificador.${nav}`);
  }

  if (s.step === 'add_target') {
    const target = targetFrom(ctx, value);
    if (!target) throw new ValidationError('Informe a pessoa que receberá o cargo.');
    const result = await manager.grant(ctx, s.data.roleId, target);
    s.step = 'main'; s.data = {};
    return ctx.reply(`✅ *CARGO PROCESSADO*\n\n${label(result.roleId)}\n${result.message || (result.changed ? 'Cargo concedido.' : 'Cargo já estava ativo.')}\n\n${mainText()}`);
  }

  if (s.step === 'remove_target') {
    const target = targetFrom(ctx, value);
    if (!target) throw new ValidationError('Informe a pessoa que perderá o cargo.');
    const result = await manager.revoke(ctx, s.data.roleId, target);
    s.step = 'main'; s.data = {};
    return ctx.reply(`✅ *CARGO PROCESSADO*\n\n${label(result.roleId)}\n${result.message || (result.changed ? 'Cargo removido.' : 'Cargo já estava inativo.')}\n\n${mainText()}`);
  }

  if (s.step === 'inspect_target') {
    const target = targetFrom(ctx, value);
    if (!target) throw new ValidationError('Informe a pessoa que deseja consultar.');
    const result = await manager.inspect(ctx, target);
    const roles = result.roles.length ? result.roles.map(label).join('\n') : 'Nenhum cargo/status especial encontrado.';
    s.step = 'main'; s.data = {};
    return ctx.reply(`🔎 *CARGOS DA PESSOA*\n\n👤 ${result.identity.name || result.identity.realJid || result.identity.requested}\n\n${roles}\n\n${mainText()}`);
  }

  return true;
}

export async function handleSessionInput(ctx) {
  const s = sessions.get(keyOf(ctx));
  if (!s) return { handled: false };
  const text = String(ctx.body || ctx.text || '').trim();
  if (!text) return { handled: false };
  if (ctx.prefix && text.startsWith(ctx.prefix)) { close(ctx); return { handled: false }; }
  try { await step(ctx, text); } catch (error) { await ctx.reply(`⚠️ ${error.message || 'Não foi possível concluir a operação.'}`); }
  return { handled: true };
}

export async function register() {
  registerCommand({
    name: 'gerenciarcargo', aliases: ['gerenciacargo', 'cargospainel'], category: 'dono', plugin: 'specialRoles',
    permission: Role.USER, cooldown: 2, specialPermission: 'manage_special_roles', specialRoles: [SPECIAL_ROLE.OWNER],
    description: 'Painel central dos cargos/status especiais do Fantasminha.', usage: '×gerenciarcargo',
    handler: async ctx => { open(ctx); return ctx.reply(mainText()); }
  });
}

export default { register, handleSessionInput, hasSession, clearSessions };
