import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import { SPECIAL_ROLE } from '../../core/specialRoles.js';
import { resolveSpecialRoleIdentity } from '../../core/specialRoleIdentity.js';
import * as manager from '../../services/specialRoleManagement.js';
import * as panel from './panel.js';

const tag = text => `× 👻 FANTASMINHA\n\n${text}`;
const targetOf = ctx => ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.args?.[0] || null;

async function assertSupportTarget(ctx, target) {
  const resolved = await resolveSpecialRoleIdentity(ctx, target);
  const blocked = [SPECIAL_ROLE.OWNER, SPECIAL_ROLE.CO_OWNER, SPECIAL_ROLE.SUB_OWNER];
  if (resolved.roles.some(role => blocked.includes(role))) throw new ValidationError('Não é permitido atribuir o cargo Suporte a Dono, Co-Dono ou Subdono.');
  return resolved;
}

export async function register() {
  await panel.register();
  registerCommand({
    name: 'addsuporte', aliases: ['adicionarsuporte', 'addsupport'], category: 'dono', plugin: 'specialRoles',
    permission: Role.USER, cooldown: 1, specialPermission: 'manage_support', specialRoles: ['owner', 'co_owner', 'sub_owner'],
    description: 'Adiciona o cargo especial Suporte.', usage: '×addsuporte @pessoa',
    handler: async ctx => {
      const target = targetOf(ctx);
      if (!target) throw new ValidationError('Mencione, responda ou informe o identificador da pessoa.');
      await assertSupportTarget(ctx, target);
      const result = await manager.grant(ctx, SPECIAL_ROLE.SUPPORT, target);
      return ctx.reply(tag(result.changed ? '🆘 *SUPORTE ADICIONADO*\n\nO cargo Suporte foi concedido.' : '🆘 Essa pessoa já possui o cargo Suporte.'));
    }
  });

  registerCommand({
    name: 'rmvsuporte', aliases: ['rmsuporte', 'removesuporte', 'delsuporte'], category: 'dono', plugin: 'specialRoles',
    permission: Role.USER, cooldown: 1, specialPermission: 'manage_support', specialRoles: ['owner', 'co_owner', 'sub_owner'],
    description: 'Remove o cargo especial Suporte.', usage: '×rmvsuporte @pessoa',
    handler: async ctx => {
      const target = targetOf(ctx);
      if (!target) throw new ValidationError('Mencione, responda ou informe o identificador da pessoa.');
      const result = await manager.revoke(ctx, SPECIAL_ROLE.SUPPORT, target);
      return ctx.reply(tag(result.changed ? '🆘 *SUPORTE REMOVIDO*\n\nO cargo Suporte foi removido.' : 'Essa pessoa não possui o cargo Suporte.'));
    }
  });
}

export { panel };
export default { register, panel };
