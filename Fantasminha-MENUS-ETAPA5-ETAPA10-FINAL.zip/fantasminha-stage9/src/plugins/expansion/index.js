import { env } from '../../config/env.js';
/**
 * Fantasminha 5.0 — Expansion Pack
 * 100 comandos adicionais, sem votação, focados em operação, comunidade,
 * personalização, jogos leves e ferramentas. Tudo usa a store JSON existente.
 */
import crypto from 'crypto';
import os from 'os';
import fs from 'fs';
import path from 'path';
import { registerCommand, registerAlias, listCommands, registryStats } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { readCollection, updateCollection, DB_ROOT, getUser, upsertUser } from '../../database/store.js';
import config from '../../core/config.js';
import { snapshot as metricsSnapshot, resetMetrics } from '../../core/metrics.js';
import { healthSnapshot, healthText } from '../../core/health.js';
import { ValidationError } from '../../core/errors.js';
import { buildPublicProfile, profileText } from '../../services/profile.js';


const tag = s => `👻 *FANTASMINHA 5.0*\n\n${s}`;
const q = ctx => String(ctx.q || '').trim();
const args = ctx => ctx.args || [];
const now = () => Date.now();
const id = () => crypto.randomBytes(3).toString('hex').toUpperCase();
const cleanId = v => String(v || '').replace(/[^0-9A-Za-z_@.-]/g, '').slice(0, 100);
const target = ctx => ctx.mentioned?.[0] || args(ctx)[0] || ctx.sender;
const text = (ctx, from = 0) => args(ctx).slice(from).join(' ').trim();
const save = (c, updater, fallback = {}) => updateCollection(c, updater, fallback);

function evaluateArithmetic(expression) {
  const raw = String(expression).replace(/\s+/g, '');
  const tokens = raw.match(/(?:\d+(?:\.\d+)?|[()+\-*/%])/g) || [];
  if (!raw || tokens.join('') !== raw) throw new ValidationError('Expressão inválida.');
  const values = [], ops = [], prec = {'+':1,'-':1,'*':2,'/':2,'%':2};
  const apply = () => {
    const op = ops.pop(), b = values.pop(), a = values.pop();
    if (a === undefined || b === undefined) throw new ValidationError('Expressão inválida.');
    let r = op === '+' ? a + b : op === '-' ? a - b : op === '*' ? a * b : op === '/' ? a / b : a % b;
    if (!Number.isFinite(r)) throw new ValidationError('Resultado inválido.');
    values.push(r);
  };
  let expectValue = true;
  for (const token of tokens) {
    if (/^\d/.test(token)) { values.push(Number(token)); expectValue = false; continue; }
    if (token === '(') { ops.push(token); expectValue = true; continue; }
    if (token === ')') { while (ops.length && ops.at(-1) !== '(') apply(); if (ops.pop() !== '(') throw new ValidationError('Expressão inválida.'); expectValue = false; continue; }
    if (expectValue && (token === '+' || token === '-')) values.push(0);
    else if (expectValue) throw new ValidationError('Expressão inválida.');
    while (ops.length && ops.at(-1) !== '(' && prec[ops.at(-1)] >= prec[token]) apply();
    ops.push(token); expectValue = true;
  }
  if (expectValue) throw new ValidationError('Expressão inválida.');
  while (ops.length) { if (ops.at(-1) === '(') throw new ValidationError('Expressão inválida.'); apply(); }
  if (values.length !== 1 || !Number.isFinite(values[0])) throw new ValidationError('Resultado inválido.');
  return values[0];
}

async function audit(ctx, action, details = {}) {
  await save('audit', d => {
    d.events ||= [];
    d.events.push({ id: `AUD-${id()}`, at: now(), action, actor: ctx.sender, group: ctx.from || null, details });
    if (d.events.length > 10000) d.events.splice(0, d.events.length - 10000);
    return d;
  }, { events: [] });
}

function safeEnv() {
  return Object.fromEntries(['NODE_ENV','BOT_NAME','BOT_VERSION','OWNER_NAME','PREFIX','DEFAULT_LANGUAGE','OPENAI_MODEL'].map(k => [k, env[k] || null]));
}

function userRecord(uid) {
  return getUser(uid) || { id: uid, name: '', economy: { wallet: 0, bank: 0 }, rpg: { level: 1, xp: 0 }, premium: { active: false } };
}


const commands = [
  // Fundação / diagnóstico
  ['painel','👻 Painel rápido do sistema.',Role.OWNER,'owner'],
  ['sobrebot','📦 Mostra versão e arquitetura.',Role.USER,'system'],
  ['idfantasma','👻 Mostra seu identificador interno.',Role.USER,'system'],
  ['idgrupo','🆔 Mostra o ID do grupo atual.',Role.GROUP_ADMIN,'group-id'],
  ['meucontexto','🧩 Mostra seu contexto persistente resumido.',Role.USER,'system'],
  ['tempoativo','⏱️ Mostra uptime do processo.',Role.USER,'system'],
  ['memoriahost','🧠 Mostra memória do host/processo.',Role.USER,'system'],
  ['diagnostico','🩺 Diagnóstico do núcleo.',Role.OWNER,'diagnostic'],
  ['configresumo','⚙️ Resumo seguro da configuração.',Role.OWNER,'config'],
  ['limparlogs','🧹 Remove logs antigos com retenção configurável.',Role.OWNER,'cleanup'],
  ['eventosrecentes','🚌 Últimos eventos do barramento/auditoria.',Role.OWNER,'events'],
  ['dependenciasbot','🕸️ Mostra mapa básico de módulos.',Role.OWNER,'deps'],
  ['flagsbot','🚩 Lista feature flags ativas.',Role.OWNER,'flags'],
  ['jobsbot','⏱️ Mostra jobs internos.',Role.OWNER,'jobs'],
  ['incidentenovo','🚨 Abre incidente operacional.',Role.OWNER,'incident-new'],
  ['incidenteslista','🚨 Lista incidentes abertos/recentes.',Role.OWNER,'incident-list'],
  ['buscabot','🔎 Busca em configurações/dados públicos.',Role.OWNER,'search'],
  ['comandobusca','🔎 Pesquisa comandos por nome/descrição.',Role.USER,'command-search'],
  ['aliasbusca','🔎 Pesquisa aliases registrados.',Role.USER,'alias-search'],
  ['permissoesbot','🔐 Mostra níveis de permissão.',Role.USER,'permissions'],
  ['segurancabot','🛡️ Mostra controles de segurança.',Role.OWNER,'security'],
  ['limitesbot','⏱️ Mostra limites gerais.',Role.USER,'limits'],
  ['filasaude','🚌 Mostra estado de filas internas.',Role.OWNER,'queue'],
  ['metricasbot','📊 Mostra métricas do processo.',Role.OWNER,'metrics'],
  ['exportarconfigsegura','📤 Exporta configuração sem segredos.',Role.OWNER,'export-config'],
  ['checarsistema','🩺 Executa checagem completa rápida.',Role.OWNER,'full-check'],
  ['repararindice','🛠️ Reconstrói índices simples do banco.',Role.OWNER,'repair-index'],
  ['limpartemporarios','🧹 Limpa temporários seguros.',Role.OWNER,'tmp-clean'],
  ['verenv','🔐 Mostra somente variáveis públicas do ambiente.',Role.OWNER,'env'],
  // Comunidade / perfil
  ['perfil','👻 Mostra a ficha pública completa do usuário.',Role.USER,'public-profile'],
  ['perfilbio','📝 Define sua bio interna.',Role.USER,'profile-bio'],
  ['perfilcargo','🏷️ Mostra seu papel no grupo.',Role.USER,'profile-role'],
  ['preferenciasbot','⚙️ Mostra suas preferências.',Role.USER,'prefs'],
  ['setidioma','🌎 Define idioma preferido.',Role.USER,'set-lang'],
  ['setprefixo','⌨️ Mostra o prefixo atual do bot.',Role.USER,'prefix'],
  ['meusnumeros','📈 Mostra estatísticas pessoais.',Role.USER,'personal-stats'],
  ['streak','🔥 Mostra sequência de uso.',Role.USER,'streak'],
  ['marcarfavorito','⭐ Marca um comando como favorito.',Role.USER,'favorite-add'],
  ['meusfavoritos','⭐ Lista favoritos.',Role.USER,'favorite-list'],
  ['removerfavorito','⭐ Remove favorito.',Role.USER,'favorite-remove'],
  ['lembretes','🔔 Lista lembretes locais.',Role.USER,'reminder-list'],
  ['lembrar','🔔 Cria lembrete em minutos.',Role.USER,'reminder-add'],
  ['apagarlembrete','🗑️ Remove lembrete.',Role.USER,'reminder-del'],
  ['reputacaoperfil','⭐ Mostra reputação resumida.',Role.USER,'rep-profile'],
  ['conquistasperfil','🎖️ Mostra conquistas resumidas.',Role.USER,'achievements'],
  ['progressoexp','📈 Mostra progressão resumida.',Role.USER,'progress'],
  // Jogos leves
  ['caraoucoroa','🪙 Joga cara ou coroa.',Role.USER,'coin'],
  ['jokenpo','✊ Joga pedra papel tesoura.',Role.USER,'rps'],
  ['maioroumenor','🎴 Adivinhe se o próximo número será maior/menor.',Role.USER,'higher-lower'],
  ['dueloemoji','⚔️ Duelo aleatório de emojis.',Role.USER,'emoji-battle'],
  ['sequencia','🧠 Gera sequência para memorizar.',Role.USER,'sequence'],
  ['verdadeirofalso','❓ Pergunta verdadeiro/falso.',Role.USER,'tf'],
  ['roletaemoji','🎡 Sorteia um emoji.',Role.USER,'emoji-wheel'],
  ['rankingjogos','🏆 Ranking de uso dos jogos.',Role.USER,'game-ranking'],
  // Ferramentas / produtividade
  ['calc','🧮 Calculadora segura.',Role.USER,'calc'],
  ['contador','🔢 Conta palavras/caracteres.',Role.USER,'counter'],
  ['maiusculas','🔠 Converte texto para maiúsculas.',Role.USER,'upper'],
  ['minusculas','🔡 Converte texto para minúsculas.',Role.USER,'lower'],
  ['titulo','🔤 Formata texto em estilo título.',Role.USER,'title'],
  ['limpartexto','🧹 Normaliza espaços de texto.',Role.USER,'clean-text'],
  ['timestamp','🕒 Gera timestamp atual.',Role.USER,'timestamp'],
  ['idaleatorio','🎲 Gera ID aleatório.',Role.USER,'random-id'],
  ['jsonbonito','🧾 Formata JSON enviado.',Role.USER,'json'],
  ['checksum','🔐 Calcula SHA-256 de texto.',Role.USER,'hash'],
  ['ajudapoder','👑 Mostra recursos administrativos novos.',Role.OWNER,'owner-help'],
  ['mapabot','🗺️ Mostra o mapa lógico dos principais módulos.',Role.USER,'map']
];

const handlers = {
  system: async ctx => ctx.reply(tag(`Versão: *${config.botVersion}*\nNode: *${process.version}*\nComandos: *${registryStats().total}*\nCategorias: *${registryStats().categories}*`)),
  about: async ctx => ctx.reply(tag(`👻 *Fantasminha 5.0*\nArquitetura modular, IA auxiliar, governança e jogos leves.\n\nNode: ${process.version}`)),
  id: async ctx => ctx.reply(tag(`👻 Seu ID interno: *${ctx.sender}*`)),
  'group-id': async ctx => { if (!ctx.isGroup || !ctx.from) throw new ValidationError('Este comando só pode ser usado em grupo.'); return ctx.reply(tag(`🆔 ID deste grupo: *${ctx.from}*\n\nUse este valor em ALLOWED_GROUP_IDS para liberar somente este grupo.`)); },
  context: async ctx => { const u = userRecord(ctx.sender); return ctx.reply(tag(`🧩 *CONTEXTO*\nID: ${ctx.sender}\nNome: ${u.name || ctx.pushname || '—'}\nPremium: ${u.premium?.active ? 'sim' : 'não'}\nNível RPG: ${u.rpg?.level || 1}`)); },
  uptime: async ctx => ctx.reply(tag(`⏱️ Uptime: *${Math.floor(process.uptime()/3600)}h ${Math.floor(process.uptime()/60)%60}m ${Math.floor(process.uptime())%60}s*`)),
  memory: async ctx => { const m=process.memoryUsage(),h=os.freemem(); return ctx.reply(tag(`🧠 RSS: ${Math.round(m.rss/1048576)} MB\nHeap: ${Math.round(m.heapUsed/1048576)}/${Math.round(m.heapTotal/1048576)} MB\nHost livre: ${Math.round(h/1048576)} MB`)); },
  diagnostic: async ctx => { const h=healthSnapshot({waConnected:ctx.waConnected===true}); return ctx.reply(healthText(h)); },
  config: async ctx => ctx.reply(tag('⚙️ '+JSON.stringify(safeEnv(),null,2))),
  cleanup: async ctx => { const days=Math.max(1,Number(args(ctx)[0]||14)); const root=path.join(config.root,'logs'); let removed=0; if(fs.existsSync(root)) for(const f of fs.readdirSync(root)){const p=path.join(root,f); const st=fs.statSync(p); if(st.isFile()&&now()-st.mtimeMs>days*86400000){fs.rmSync(p,{force:true});removed++;}} return ctx.reply(tag(`🧹 Removidos *${removed}* logs com mais de ${days} dias.`)); },
  events: async ctx => { const d=readCollection('audit',{events:[]}); const rows=(d.events||[]).slice(-10).reverse().map(e=>`${new Date(e.at).toLocaleString('pt-BR')} — ${e.action}`).join('\n')||'Sem eventos.'; return ctx.reply(tag(`🚌 *EVENTOS*\n\n${rows}`)); },
  deps: async ctx => ctx.reply(tag('🕸️ core → database → services → plugins → commands\n\nDependências externas críticas: Baileys, Sharp, Axios, Cheerio.')),
  flags: async ctx => ctx.reply(tag(Object.entries(config.features||{}).map(([k,v])=>`${v?'🟢':'🔴'} ${k}: ${v?'ON':'OFF'}`).join('\n'))),
  jobs: async ctx => ctx.reply(tag('⏱️ Jobs internos: sincronização de guerras e expiração premium.')),
  'incident-new': async ctx => { const title=text(ctx)||'Incidente sem título'; const rec={id:`INC-${id()}`,title,status:'open',createdAt:now(),actor:ctx.sender}; await save('incidents',d=>{d.items??=[];d.items.push(rec);return d;},{items:[]}); await audit(ctx,'incident-open',{id:rec.id,title}); return ctx.reply(tag(`🚨 Incidente aberto: *${rec.id}*\n${title}`)); },
  'incident-list': async ctx => { const d=readCollection('incidents',{items:[]}); const rows=d.items.slice(-15).reverse().map(x=>`${x.id} — ${x.status} — ${x.title}`).join('\n')||'Sem incidentes.'; return ctx.reply(tag(rows)); },
  search: async ctx => { const term=text(ctx).toLowerCase(); if(!term) throw new ValidationError('Informe um termo.'); const hits=[]; for(const f of fs.readdirSync(DB_ROOT).filter(x=>x.endsWith('.json'))){const s=fs.readFileSync(path.join(DB_ROOT,f),'utf8'); if(s.toLowerCase().includes(term)) hits.push(f);} return ctx.reply(tag(`🔎 Encontrado em: ${hits.join(', ')||'nenhuma coleção'}`)); },
  'command-search': async ctx => { const term=text(ctx).toLowerCase(); const rows=listCommands().filter(c=>`${c.name} ${c.description} ${(c.aliases||[]).join(' ')}`.toLowerCase().includes(term)).slice(0,20).map(c=>`×${c.name} — ${c.description}`).join('\n')||'Nada encontrado.'; return ctx.reply(tag(rows)); },
  'alias-search': async ctx => { const term=text(ctx).toLowerCase(); const rows=listCommands().flatMap(c=>(c.aliases||[]).filter(a=>a.includes(term)).map(a=>`×${a} → ×${c.name}`)).slice(0,30).join('\n')||'Nenhum alias.'; return ctx.reply(tag(rows)); },
  permissions: async ctx => ctx.reply(tag('🔐 Dono 100\nBot Admin 80\nAdmin do grupo 60\nVIP 40\nMembro 10')),
  security: async ctx => ctx.reply(tag('🛡️ Rate limit, cooldown, anti-flood, permissões, auditoria, locks de banco, escrita atômica e anti-crash ativos no núcleo.')),
  limits: async ctx => ctx.reply(tag('⏱️ Cooldown é aplicado por comando. IA possui limites próprios.')),
  queue: async ctx => ctx.reply(tag('🚌 Fila persistente: protegida pela camada de locks do banco. Filas de mídia/IA usam limites e timeouts dos serviços.')),
  metrics: async ctx => { const m=metricsSnapshot(); const top=m.commands.slice(0,8).map(x=>`${x.name}: ${x.calls} usos, ${x.errors} erros`).join('\n')||'Sem dados.'; return ctx.reply(tag(`📊 Uptime: ${Math.round(m.uptimeMs/1000)}s\n\n${top}`)); },
  'export-config': async ctx => { const dest=path.join(config.root,'data',`config-safe-${Date.now()}.json`); fs.writeFileSync(dest,JSON.stringify(safeEnv(),null,2)); return ctx.reply(tag(`📤 Exportação segura criada:\n\`${dest}\``)); },
  'full-check': async ctx => { const h=healthSnapshot({waConnected:ctx.waConnected===true}); const r=registryStats(); return ctx.reply(tag(`🩺 Banco: ${h.database?'OK':'ERRO'}\nRegistry: ${r.valid?'OK':'ERRO'}\nComandos: ${r.total}\nNode: ${process.version}`)); },
  'repair-index': async ctx => { const files=fs.readdirSync(DB_ROOT).filter(x=>x.endsWith('.json')); const index={updatedAt:now(),collections:files.map(f=>f.slice(0,-5))}; fs.writeFileSync(path.join(DB_ROOT,'_indexes.json'),JSON.stringify(index,null,2)); return ctx.reply(tag(`🛠️ Índice reconstruído: *${files.length} coleções*.`)); },
  'tmp-clean': async ctx => { let n=0; for(const root of [DB_ROOT,path.join(config.root,'data')]) if(fs.existsSync(root)) for(const f of fs.readdirSync(root)){if(f.endsWith('.tmp')){fs.rmSync(path.join(root,f),{force:true});n++;}} return ctx.reply(tag(`🧹 ${n} temporários removidos.`)); },
  env: async ctx => ctx.reply(tag(JSON.stringify(safeEnv(),null,2))),


  profile: async ctx => {
    const requested = ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.sender;
    const isCaller = (!ctx.mentioned?.[0] && !ctx.quotedParticipant) || (requested === ctx.sender);
    const p = await buildPublicProfile({
      userId: ctx.sender,
      displayUserId: requested,
      groupId: ctx.from || 'private',
      pushname: ctx.pushname || '',
      groupParticipants: ctx.groupParticipants || [],
      groupParticipantObjects: ctx.groupParticipantObjects || [],
      groupAdmins: ctx.groupAdmins || [],
      groupOwner: ctx.groupOwner || null,
      resolvePNForLID: ctx.resolvePNForLID,
      isCallerOwner: isCaller && !!ctx.isOwner,
      isGroup: !!ctx.isGroup
    });
    const caption = profileText(p);
    const photo = await ctx.profilePictureUrl?.(p.displayUserId);
    const cleanMention = id => {
      if (!id) return null;
      const num = String(id).split('@')[0].split(':')[0].replace(/\D/g, '');
      return num ? `${num}@s.whatsapp.net` : null;
    };
    const mentions = [p.mention, p.bestFriend, p.relationshipPartner].map(cleanMention).filter(Boolean);
    if (photo && ctx.sendMessage) return ctx.sendMessage(ctx.from, { image: { url: photo }, caption, mentions });
    return ctx.reply(caption, { mentions });
  },
  'public-profile': async ctx => {
    const requested = ctx.mentioned?.[0] || ctx.quotedParticipant || ctx.sender;
    const isCaller = (!ctx.mentioned?.[0] && !ctx.quotedParticipant) || (requested === ctx.sender);
    const p = await buildPublicProfile({
      userId: ctx.sender,
      displayUserId: requested,
      groupId: ctx.from || 'private',
      pushname: ctx.pushname || '',
      groupParticipants: ctx.groupParticipants || [],
      groupParticipantObjects: ctx.groupParticipantObjects || [],
      groupAdmins: ctx.groupAdmins || [],
      groupOwner: ctx.groupOwner || null,
      resolvePNForLID: ctx.resolvePNForLID,
      isCallerOwner: isCaller && !!ctx.isOwner,
      isGroup: !!ctx.isGroup
    });
    const caption = profileText(p);
    const photo = await ctx.profilePictureUrl?.(p.displayUserId);
    const cleanMention = id => {
      if (!id) return null;
      const num = String(id).split('@')[0].split(':')[0].replace(/\D/g, '');
      return num ? `${num}@s.whatsapp.net` : null;
    };
    const mentions = [p.mention, p.bestFriend, p.relationshipPartner].map(cleanMention).filter(Boolean);
    if (photo && ctx.sendMessage) return ctx.sendMessage(ctx.from, { image: { url: photo }, caption, mentions });
    return ctx.reply(caption, { mentions });
  },

  'profile-bio': async ctx => { const v=text(ctx); await upsertUser(ctx.sender,{profile:{...userRecord(ctx.sender).profile,bio:v.slice(0,240)}}); return ctx.reply(tag('📝 Bio atualizada.')); },
  'profile-role': async ctx => ctx.reply(tag(`🏷️ Seu papel detectado nesta execução: ${ctx.isOwner?'Dono':ctx.isBotAdmin?'Bot Admin':ctx.isGroupAdmin?'Admin do grupo':ctx.isVip?'VIP':'Membro'}`)),
  prefs: async ctx => { const u=userRecord(ctx.sender); return ctx.reply(tag(JSON.stringify(u.preferences||{},null,2))); },
  'set-lang': async ctx => { const v=args(ctx)[0]||'pt-BR'; await upsertUser(ctx.sender,{preferences:{...userRecord(ctx.sender).preferences,language:v}}); return ctx.reply(tag(`🌎 Idioma preferido: *${v}*`)); },
  prefix: async ctx => ctx.reply(tag(`⌨️ Prefixo: *${config.prefix}*`)),
  'personal-stats': async ctx => { const u=userRecord(ctx.sender); const g=readCollection('game_stats',{byUser:{}}); const s=g.byUser?.[ctx.sender]||{}; return ctx.reply(tag(`📈 Jogos: ${s.plays||0}\nVitórias: ${s.wins||0}\nXP RPG: ${u.rpg?.xp||0}`)); },
  streak: async ctx => { const c='usage_streak'; let out; await save(c,d=>{d.byUser??={}; const x=d.byUser[ctx.sender]||{days:0,last:0}; const day=Math.floor(now()/86400000); if(x.last===day)x.days=x.days||1; else if(x.last===day-1)x.days=(x.days||0)+1; else x.days=1; x.last=day; d.byUser[ctx.sender]=x; out=x; return d;},{byUser:{}}); return ctx.reply(tag(`🔥 Sequência: *${out.days} dia(s)*`)); },
  'favorite-add': async ctx => { const v=args(ctx)[0]; if(!v) throw new ValidationError('Informe o comando.'); await save('favorites',d=>{d.byUser??={};d.byUser[ctx.sender]??=[];if(!d.byUser[ctx.sender].includes(v))d.byUser[ctx.sender].push(v);return d;},{byUser:{}}); return ctx.reply(tag(`⭐ Favorito adicionado: ${v}`)); },
  'favorite-list': async ctx => { const d=readCollection('favorites',{byUser:{}}); return ctx.reply(tag((d.byUser?.[ctx.sender]||[]).map(x=>`×${x}`).join('\n')||'Nenhum favorito.')); },
  'favorite-remove': async ctx => { const v=args(ctx)[0]; await save('favorites',d=>{d.byUser??={};d.byUser[ctx.sender]=(d.byUser[ctx.sender]||[]).filter(x=>x!==v);return d;},{byUser:{}}); return ctx.reply(tag('⭐ Favorito removido.')); },
  'reminder-list': async ctx => { const d=readCollection('reminders',{items:[]}); const l=d.items.filter(x=>x.userId===ctx.sender&&x.at>now()); return ctx.reply(tag(l.map(x=>`${x.id} — ${new Date(x.at).toLocaleString('pt-BR')} — ${x.text}`).join('\n')||'Nenhum lembrete.')); },
  'reminder-add': async ctx => { const mins=Number(args(ctx)[0]); const v=text(ctx,1); if(!Number.isFinite(mins)||mins<1||mins>10080||!v) throw new ValidationError('Use: ×lembrar MINUTOS texto'); const rec={id:`REM-${id()}`,userId:ctx.sender,at:now()+mins*60000,text:v.slice(0,300)}; await save('reminders',d=>{d.items??=[];d.items.push(rec);return d;},{items:[]}); return ctx.reply(tag(`🔔 Lembrete ${rec.id} criado.`)); },
  'reminder-del': async ctx => { const v=args(ctx)[0]; await save('reminders',d=>{d.items??=[];d.items=d.items.filter(x=>!(x.id===v&&x.userId===ctx.sender));return d;},{items:[]}); return ctx.reply(tag('🗑️ Lembrete removido.')); },
  'rep-profile': async ctx => { const u=target(ctx); const d=readCollection('reputation',{byUser:{}}); return ctx.reply(tag(`⭐ Reputação de @${String(u).split('@')[0]}: ${d.byUser?.[u]?.score||0}`),{mentions:[u]}); },
  achievements: async ctx => { const d=readCollection('achievements',{byUser:{}}); return ctx.reply(tag((d.byUser?.[ctx.sender]||[]).map(x=>`🎖️ ${x.name||x}`).join('\n')||'Nenhuma conquista registrada.')); },
  progress: async ctx => { const u=userRecord(ctx.sender); return ctx.reply(tag(`📈 Nível RPG: ${u.rpg?.level||1}\nXP: ${u.rpg?.xp||0}\nPróximo nível: ${(u.rpg?.level||1)*100} XP`)); },

  coin: async ctx => ctx.reply(tag(`🪙 Caiu: *${Math.random()<.5?'CARA':'COROA'}*`)),
  dice: async ctx => { const sides=Math.max(2,Math.min(100,Number(args(ctx)[0]||6))); return ctx.reply(tag(`🎲 D${sides}: *${1+Math.floor(Math.random()*sides)}*`)); },
  'dice-many': async ctx => { const n=Math.max(1,Math.min(10,Number(args(ctx)[0]||2))); const s=Math.max(2,Math.min(100,Number(args(ctx)[1]||6))); const r=Array.from({length:n},()=>1+Math.floor(Math.random()*s)); return ctx.reply(tag(`🎲 ${r.join(' + ')} = *${r.reduce((a,b)=>a+b,0)}*`)); },
  'odd-even': async ctx => { const n=1+Math.floor(Math.random()*100); return ctx.reply(tag(`🔢 Número: *${n}* — ${n%2?'ÍMPAR':'PAR'}`)); },
  rps: async ctx => { const opts=['pedra','papel','tesoura']; const bot=opts[Math.floor(Math.random()*3)]; const user=String(args(ctx)[0]||'').toLowerCase(); if(!opts.includes(user)) return ctx.reply(tag('Use: pedra, papel ou tesoura.')); const win=(user==='pedra'&&bot==='tesoura')||(user==='papel'&&bot==='pedra')||(user==='tesoura'&&bot==='papel'); return ctx.reply(tag(`Você: *${user}*\nBot: *${bot}*\nResultado: *${user===bot?'EMPATE':win?'VOCÊ VENCEU':'BOT VENCEU'}*`)); },
  'higher-lower': async ctx => { const a=1+Math.floor(Math.random()*50),b=1+Math.floor(Math.random()*50),guess=String(args(ctx)[0]||'').toLowerCase(); const actual=b>a?'maior':b<a?'menor':'igual'; return ctx.reply(tag(`Primeiro: ${a}\nSegundo: ${b}\nVocê escolheu: ${guess||'—'}\nResultado: *${actual}*`)); },
  'number-game': async ctx => { const n=1+Math.floor(Math.random()*20); const g=Number(args(ctx)[0]); if(!Number.isFinite(g)) return ctx.reply(tag('Escolha um número de 1 a 20.')); return ctx.reply(tag(g===n?'🎯 Acertou!':`❌ Era *${n}*.`)); },
  scramble: async ctx => { const v=args(ctx)[0]; if(!v) throw new ValidationError('Informe uma palavra.'); const a=[...v]; for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];} return ctx.reply(tag(`🔤 ${a.join('')}`)); },
  anagram: async ctx => { const v=args(ctx)[0]; if(!v) throw new ValidationError('Informe uma palavra.'); const a=[...v].sort(()=>Math.random()-.5).join(''); return ctx.reply(tag(`🔤 Anagrama: *${a}*`)); },
  'mystery-coin': async ctx => ctx.reply(tag(`🪙 O destino escolheu: *${['LUZ','SOMBRA','NÉVOA','ESTRELA'][Math.floor(Math.random()*4)]}*`)),
  'emoji-battle': async ctx => { const e=['👻','🤖','🐉','🦊','🦁','🦄','🐺']; return ctx.reply(tag(`${e[Math.floor(Math.random()*e.length)]} VS ${e[Math.floor(Math.random()*e.length)]}\n🏆 Vencedor: um deles, obviamente.`)); },
  memory: async ctx => { const chars='ABCDEFGHJKLMNPQRSTUVWXYZ'; const s=Array.from({length:5},()=>chars[Math.floor(Math.random()*chars.length)]).join(''); return ctx.reply(tag(`🧠 Memorize: *${s}*\nDepois tente repetir usando ×respostamemoria, se disponível.`)); },
  sequence: async ctx => { const r=Array.from({length:5},()=>Math.floor(Math.random()*10)); return ctx.reply(tag(`🧠 Sequência: *${r.join(' ')}*`)); },
  quiz: async ctx => { const qs=[['Qual planeta é conhecido como planeta vermelho?','marte'],['Quantos lados tem um hexágono?','6'],['Qual é o maior oceano?','pacifico']]; const x=qs[Math.floor(Math.random()*qs.length)]; return ctx.reply(tag(`🧠 ${x[0]}\n\nResposta esperada: *${x[1]}*`)); },
  tf: async ctx => { const qx=[['A água congela a 0°C ao nível do mar.','VERDADEIRO'],['O Sol é um planeta.','FALSO'],['Um triângulo tem três lados.','VERDADEIRO']][Math.floor(Math.random()*3)]; return ctx.reply(tag(`❓ ${qx[0]}\nResposta: *${qx[1]}*`)); },
  challenge: async ctx => { const c=['crie um apelido engraçado','mande um emoji que combine com seu humor','conte uma curiosidade sobre você','escolha uma cor aleatória para hoje','faça uma pergunta interessante no grupo']; return ctx.reply(tag(`🎯 Desafio: *${c[Math.floor(Math.random()*c.length)]}*`)); },
  'emoji-wheel': async ctx => { const e=['👻','🌙','⭐','🪐','🔥','💜','🧩','🎲','🚀']; return ctx.reply(tag(`🎡 Resultado: ${e[Math.floor(Math.random()*e.length)]}`)); },
  'random-word': async ctx => { const w=['fantasma','cosmos','estrela','nebulosa','aventura','amizade','mistério','limbo','portal','galáxia']; return ctx.reply(tag(`🔤 ${w[Math.floor(Math.random()*w.length)]}`)); },
  'random-number': async ctx => { const a=Number(args(ctx)[0]||1),b=Number(args(ctx)[1]||100); const min=Math.min(a,b),max=Math.max(a,b); return ctx.reply(tag(`🔢 *${Math.floor(min+Math.random()*(max-min+1))}*`)); },
  draw: async ctx => { const vals=text(ctx).split('|').map(x=>x.trim()).filter(Boolean); if(vals.length<2) throw new ValidationError('Use opções separadas por |.'); return ctx.reply(tag(`🎉 Sorteado: *${vals[Math.floor(Math.random()*vals.length)]}*`)); },
  'game-ranking': async ctx => { const d=readCollection('game_stats',{byUser:{}}); const rows=Object.values(d.byUser||{}).sort((a,b)=>(b.plays||0)-(a.plays||0)).slice(0,10).map((x,i)=>`${i+1}. ${x.name||x.userId||'?'} — ${x.plays||0} jogos`).join('\n'); return ctx.reply(tag(rows||'Sem dados.')); },

  calc: async ctx => { const exp=text(ctx); if(!exp||!/^[0-9+\-*/%().\s]+$/.test(exp)) throw new ValidationError('Use apenas números e operações + - * / % ( ).'); const result=evaluateArithmetic(exp); return ctx.reply(tag(`🧮 ${exp} = *${result}*`)); },
  counter: async ctx => { const v=text(ctx); return ctx.reply(tag(`🔢 Caracteres: ${v.length}\nPalavras: ${v?v.split(/\s+/).length:0}`)); },
  upper: async ctx => ctx.reply(tag(text(ctx).toUpperCase())),
  lower: async ctx => ctx.reply(tag(text(ctx).toLowerCase())),
  title: async ctx => ctx.reply(tag(text(ctx).toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()))),
  'clean-text': async ctx => ctx.reply(tag(text(ctx).replace(/\s+/g,' ').trim())),
  timestamp: async ctx => ctx.reply(tag(`🕒 ${Date.now()}`)),
  'random-id': async ctx => ctx.reply(tag(`🎲 ${crypto.randomUUID()}`)),
  json: async ctx => { const v=text(ctx); try{return ctx.reply(tag(JSON.stringify(JSON.parse(v),null,2).slice(0,5000)));}catch{throw new ValidationError('JSON inválido.');} },
  hash: async ctx => ctx.reply(tag(`🔐 SHA-256\n${crypto.createHash('sha256').update(text(ctx)).digest('hex')}`)),
  map: async ctx => ctx.reply(tag('🗺️ core → registry → commands/plugins → services → database\n\nEconomia → ledger + loja\nRPG → personagem + XP + dungeons\nClãs → temporadas + guerras')),

  'owner-help': async ctx => ctx.reply(tag(`👑 *EXPANSÃO 5.0*\n100 comandos adicionais distribuídos entre fundação, comunidade, perfil, produtividade e jogos.\n\nUse *${config.prefix}comandobusca termo* para localizar qualquer comando.`))
};

export async function register() {
  for (const [name, description, permission, action] of commands) {
    registerCommand({
      name,
      category: action.startsWith('incident') ||  ['diagnostic','config','backup','cleanup','events','deps','flags','jobs','search','permissions','security','limits','queue','metrics','export-config','full-check','repair-index','tmp-clean','env','owner-help','owner'].includes(action) ? 'dono' : action.startsWith('profile') || action === 'public-profile' || action.startsWith('prefs') || action.startsWith('favorite') || action.startsWith('notes') || action.startsWith('reminder') ? 'perfil' : ['coin','dice','dice-many','odd-even','rps','higher-lower','number-game','scramble','anagram','mystery-coin','emoji-battle','memory','sequence','quiz','tf','challenge','emoji-wheel','random-word','random-number','draw','game-ranking'].includes(action) ? 'jogos' : 'ferramentas',
      plugin:'expansion5', permission, cooldown:2, description,
      responseCapabilities: ['profile','public-profile'].includes(action) ? { supportsCustomMedia:false, hasNativeMedia:true, isMenu:false, responseKey:`command.${name}.default` } : undefined,
      handler: async ctx => {
        const fn=handlers[action];
        if(!fn) throw new Error(`Ação não implementada: ${action}`);
        const result=await fn(ctx);
        if(['coin','dice','dice-many','odd-even','rps','higher-lower','number-game','scramble','anagram','mystery-coin','emoji-battle','memory','sequence','quiz','tf','challenge','emoji-wheel','random-word','random-number','draw'].includes(action)) {
          await save('game_stats',d=>{d.byUser??={};const u=d.byUser[ctx.sender]||{userId:ctx.sender,name:ctx.pushname||'',plays:0,wins:0};u.plays++;d.byUser[ctx.sender]=u;return d;},{byUser:{}});
        }
        return result;
      }
    });
  }
  registerAlias('seguranca', 'segurancabot');
  registerAlias('meuperfil', 'perfil');
}

export default { register };
