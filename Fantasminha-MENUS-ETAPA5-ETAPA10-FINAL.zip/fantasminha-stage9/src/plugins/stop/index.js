import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { beginConfig, beginDelete, createSession, beginSessionConfigure, cancelForContext, handleAnswer, handleGroupInput } from '../../games/stop/StopCore.js';

export async function stopCommand(ctx) {
  const args = Array.isArray(ctx.args) ? ctx.args : String(ctx.commandArgs || '').trim().split(/\s+/).filter(Boolean);
  const sub = String(args[0] || '').toLowerCase();
  if (sub === 'criar') return beginConfig(ctx);
  if (sub === 'configurar' || sub === 'config') return beginSessionConfigure(ctx);
  if (sub === 'cancelar' || sub === 'cancel') return cancelForContext(ctx);
  if (sub === 'excluir' || sub === 'delete') return beginDelete(ctx);
  return createSession(ctx);
}

export async function register(){
  registerCommand({name:'stopcriar',category:'jogos',plugin:'stop',permission:Role.USER,privateOnly:true,cooldown:3,description:'Configura o STOP de forma privada.',handler:beginConfig});
  registerCommand({name:'stopexcluir',category:'jogos',plugin:'stop',permission:Role.USER,privateOnly:true,cooldown:3,description:'Exclui a configuração do STOP sem apagar histórico.',handler:beginDelete});
  registerCommand({name:'stop',aliases:['adedonha'],category:'jogos',plugin:'stop',permission:Role.USER,groupOnly:true,cooldown:3,description:'Cria, configura, cancela ou inicia uma partida STOP.',handler:stopCommand});
}
export { handleAnswer, handleGroupInput };
export default {register,handleAnswer,handleGroupInput,stopCommand};
