import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { getUser, readCollection } from '../../database/store.js';
import { ValidationError } from '../../core/errors.js';
import * as rpg from '../../services/rpgService.js';
import { registerCareerCommands } from './careerCommands.js';

const CLASS_IDS = Object.keys(rpg.CLASSES);

function tag(t) {
  return `× 👻 FANTASMINHA\n\n${t}`;
}

export async function register() {
  registerCareerCommands();
  registerCommand({
    name: 'rpgcriar',
    aliases: ['criarperso'],
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 5,
    handler: async (ctx) => {
      const cls = ctx.q || CLASS_IDS[Math.floor(Math.random() * CLASS_IDS.length)];
      await rpg.createCharacter(ctx.sender, cls, ctx.pushname);
      await ctx.reply(tag(`⚔️ Personagem *${cls}* criado.\n×rpg · ×boss · ×dungeon · ×lojarpg`));
    }
  });

  registerCommand({
    name: 'classe',
    aliases: ['classerpg'],
    category: 'rpg', plugin: 'rpg', cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) return ctx.reply(tag(`🎭 *CLASSES*\n\n${Object.entries(rpg.CLASSES).map(([id,c]) => `• ${id} — ${c.name}`).join('\n')}\n\nUse ×classe <id>`));
      const r = await rpg.chooseClass(ctx.sender, ctx.q.trim());
      await ctx.reply(tag(`🎭 Classe definida: *${rpg.CLASSES[r.class].name}*.`));
    }
  });

  registerCommand({
    name: 'treinar',
    aliases: ['treino'],
    category: 'rpg', plugin: 'rpg', cooldown: 10,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('treinar forca|defesa|agilidade|vitalidade|mana');
      const r = await rpg.train(ctx.sender, ctx.q.trim());
      await ctx.reply(tag(`🏋️ Treino concluído!\n\n📈 ${r.attribute}: *${r.value}*\n✨ +${r.xp} XP`));
    }
  });

  registerCommand({
    name: 'meustreinos',
    aliases: ['statsrpg', 'atributos'],
    category: 'rpg', plugin: 'rpg', cooldown: 3,
    handler: async (ctx) => {
      const r = rpg.stats(ctx.sender); if (!r) throw new ValidationError('Crie seu personagem primeiro: rpgcriar');
      await ctx.reply(tag(`📊 *ATRIBUTOS RPG*\n\n🎭 Classe: *${r.class || '—'}*\n⭐ Nível: *${r.level}*\n✨ XP: *${r.xp}*\n❤️ HP: *${r.hp}/${r.maxHp}*\n⚔️ Ataque: *${r.attack}*\n🛡️ Armadura: *${r.armor}*\n\n💪 Força: ${r.attributes.strength}\n🛡️ Defesa: ${r.attributes.defense}\n🏃 Agilidade: ${r.attributes.agility}\n❤️ Vitalidade: ${r.attributes.vitality}\n🔮 Mana: ${r.attributes.mana}`));
    }
  });

  registerCommand({
    name: 'rpg',
    aliases: ['statusrpg', 'perfilrpg2'],
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 3,
    handler: async (ctx) => {
      const u = getUser(ctx.sender);
      if (!u?.rpg?.class) throw new ValidationError('rpgcriar [classe]');
      const r = u.rpg;
      const p = rpg.power(r);
      await ctx.reply(tag(
        `⚔️ *${u.name || 'Viajante'}* — ${r.class}\n` +
        `Nv.*${r.level}* XP *${r.xp}*\nHP *${r.hp}/${r.maxHp}*\n` +
        `ATK *${p.atk}* DEF *${p.def}*\n` +
        `Arma: ${r.equip?.arma || '—'} | Armadura: ${r.equip?.armadura || '—'}`
      ));
    }
  });

  registerCommand({
    name: 'rpgxp',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 15,
    handler: async (ctx) => {
      const u = getUser(ctx.sender);
      if (!u?.rpg?.class) throw new ValidationError('rpgcriar');
      const gain = 15 + Math.floor(Math.random() * 40);
      const r = await rpg.addXp(ctx.sender, gain, ctx.pushname);
      await ctx.reply(tag(`✨ +${gain} XP → Nv.${r.level}`));
    }
  });

  registerCommand({
    name: 'rpgclasses',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 5,
    handler: async (ctx) => {
      await ctx.reply(tag(`Classes:\n${CLASS_IDS.map((id) => `• ${id} — ${rpg.CLASSES[id].name}`).join('\n')}`));
    }
  });

  registerCommand({
    name: 'rankxp',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 5,
    handler: async (ctx) => {
      const users = readCollection('users', { byId: {} });
      const list = Object.values(users.byId || {})
        .filter((u) => u.rpg?.class)
        .sort((a, b) => (b.rpg?.xp || 0) - (a.rpg?.xp || 0))
        .slice(0, 10);
      if (!list.length) return ctx.reply(tag('Ninguém no rank.'));
      await ctx.reply(tag(`🏆 Rank XP\n\n${list.map((u, i) => `${i + 1}. ${u.name} Nv.${u.rpg.level}`).join('\n')}`));
    }
  });

  registerCommand({
    name: 'lojarpg',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 3,
    handler: async (ctx) => {
      const lines = Object.entries(rpg.EQUIP).map(
        ([id, e]) => `• *${id}* — ${e.name} (${e.slot}) ${e.price}GC atk/def ${e.atk || 0}/${e.def || 0}`
      );
      await ctx.reply(tag(`🛒 *Loja RPG*\n\n${lines.join('\n')}\n\n×comprarequip <id>\n×equipar <id>`));
    }
  });

  registerCommand({
    name: 'comprarequip',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 5,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('comprarequip <id>');
      const item = await rpg.buyEquip(ctx.sender, ctx.q.trim(), ctx.pushname);
      await ctx.reply(tag(`🛒 Comprou *${item.name}*. ×equipar ${ctx.q.trim()}`));
    }
  });

  registerCommand({
    name: 'equipar',
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 3,
    handler: async (ctx) => {
      if (!ctx.q) throw new ValidationError('equipar <id>');
      const r = await rpg.equipItem(ctx.sender, ctx.q.trim());
      await ctx.reply(tag(`🛡️ Equipou *${r.item.name}*.`));
    }
  });

  registerCommand({
    name: 'boss',
    aliases: ['bosses'],
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 20,
    handler: async (ctx) => {
      if (!ctx.q || ctx.q === 'lista') {
        const lines = rpg.BOSSES.map((b) => `• *${b.id}* — ${b.name} (nv≥${b.minLevel})`);
        return ctx.reply(tag(`👹 Bosses\n\n${lines.join('\n')}\n\n×boss <id>`));
      }
      const r = await rpg.fightBoss(ctx.sender, ctx.q.trim(), ctx.pushname);
      await ctx.reply(tag(
        `${r.win ? '🏆 Vitória' : '💀 Derrota'} vs *${r.boss.name}*\n` +
        `HP ${r.hp} | Nv.${r.level} XP ${r.xp}\n` +
        (r.gold ? `+${r.gold} GC\n` : '') +
        r.log.join('\n')
      ));
    }
  });

  registerCommand({
    name: 'dungeon',
    aliases: ['masmorra'],
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 25,
    handler: async (ctx) => {
      if (!ctx.q || ctx.q === 'lista') {
        const lines = rpg.DUNGEONS.map((d) => `• *${d.id}* — ${d.name} (${d.floors} andares, nv≥${d.minLevel})`);
        return ctx.reply(tag(`🏰 Dungeons\n\n${lines.join('\n')}\n\n×dungeon <id>`));
      }
      const r = await rpg.runDungeon(ctx.sender, ctx.q.trim(), ctx.pushname);
      await ctx.reply(tag(
        `🏰 *${r.dungeon.name}*\nAndares: ${r.floorsClear}/${r.dungeon.floors}\n` +
        `+${r.totalXp} XP +${r.totalGold} GC\nHP ${r.hp} Nv.${r.level}`
      ));
    }
  });

  registerCommand({
    name: 'rpgcurar',
    aliases: ['curar'],
    category: 'rpg',
    plugin: 'rpg',
    cooldown: 10,
    handler: async (ctx) => {
      const r = await rpg.heal(ctx.sender, ctx.pushname);
      await ctx.reply(tag(`💚 Curado. HP ${r.hp}/${r.maxHp} (−300 GC)`));
    }
  });
}

export default { register };
