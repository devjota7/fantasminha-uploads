import { registerCommand } from '../../core/registry.js';
import { ValidationError } from '../../core/errors.js';
import * as career from '../../services/rpgCareerService.js';

const tag = t => `👻 FANTASMINHA • RPG\n\n${t}`;
const fmt = n => Number(n || 0).toLocaleString('pt-BR');

function curriculumArgs(q) {
  const raw = String(q || '').trim();
  if (!raw) return null;
  const parts = raw.split('|').map(x => x.trim());
  if (parts.length !== 2) throw new ValidationError('Use: ×curriculo Nome | Idade');
  return { name: parts[0], age: parts[1] };
}

function requireRpgMode(ctx) {
  if (!ctx.groupData?.modorpg) throw new ValidationError('⚔️ Modo RPG desativado! Ative com ×modorpg para usar os comandos de carreira.');
}

export function registerCareerCommands() {
  registerCommand({name:'curriculo', category:'rpg', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Cria ou atualiza o currículo RPG.', usage:'×curriculo Nome | Idade', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    const parsed = curriculumArgs(ctx.q);
    if (!parsed) {
      const c = career.getCareer(ctx.sender);
      if (c?.curriculum?.name && c?.curriculum?.age) return ctx.reply(tag(`📋 *CURRÍCULO RPG*\n\n👤 Nome: *${c.curriculum.name}*\n🎂 Idade: *${c.curriculum.age}* anos\n💼 Profissão: *${c.job?.name || 'Nenhuma'}*\n⭐ Nível RPG: *${c.rpg.level}*\n✨ XP: *${fmt(c.rpg.xp)}*\n\nPara atualizar:\n×curriculo Novo Nome | Idade`));
      return ctx.reply(tag('📋 *CADASTRO DE CURRÍCULO*\n\nInforme seus dados no formato:\n×curriculo Nome | Idade\n\nExemplo:\n×curriculo Eduardo | 16'));
    }
    const c = await career.saveCurriculum(ctx.sender, parsed.name, parsed.age);
    await ctx.reply(tag(`📋 *CURRÍCULO SALVO*\n\n👤 Nome: *${c.name}*\n🎂 Idade: *${c.age} anos*\n\n✅ Agora seu cadastro está pronto para o mercado RPG.\n💼 Use ×vagas para ver as profissões disponíveis.`));
  }});

  registerCommand({name:'level', aliases:['nivel','nível'], category:'rpg', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Mostra nível e progresso de XP.', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    const c = career.getCareer(ctx.sender);
    const p = c?.progress || career.levelProgress({level:1,xp:0});
    const next = p.nextLevelXp - p.xp;
    await ctx.reply(tag(`╭━━━〔 ⭐ PROGRESSÃO RPG 〕━━━╮\n│\n│ 👤 ${c?.curriculum?.name || ctx.pushname || 'Aventureiro'}\n│ ⭐ Nível: *${p.level}*\n│ ✨ XP: *${fmt(p.xp)}*\n│\n│ ${career.renderBar(p.progressPercent,14)} ${p.progressPercent}%\n│ ${fmt(p.progressXp)} / ${fmt(p.nextLevelXp-p.currentLevelXp)} XP\n│\n│ 🎯 Próximo nível: *${fmt(p.nextLevelXp)} XP*\n│ 📈 Faltam: *${fmt(next)} XP*\n│\n│ 💼 Profissão: *${c?.job?.name || 'Nenhuma'}*\n│ 🔓 Vagas liberadas: *${career.unlockedJobs(p.level).length}/${Object.keys(career.JOBS).length}*\n│\n╰━━━━━━━━━━━━━━━━━━━━━━━━╯`));
  }});

  registerCommand({name:'vagas', usage:'×vagas', category:'economia', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Lista as profissões RPG desbloqueadas e bloqueadas.', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    const c = career.getCareer(ctx.sender);
    const level = c?.rpg?.level || 1;
    const unlocked = career.unlockedJobs(level);
    const locked = career.lockedJobs(level);
    const pageSize = 12;
    const shown = [...unlocked.slice(0,pageSize)];
    let text = `╭━━━〔 💼 MERCADO DE PROFISSÕES 〕━━━╮\n│\n│ ⭐ Seu nível: *${level}*\n│ 💼 Atual: *${c?.job?.name || 'Nenhuma'}*\n│ 🔓 Desbloqueadas: *${unlocked.length}/${Object.keys(career.JOBS).length}*\n│\n╰────────────────────────╯\n\n`;
    text += '🔓 *PROFISSÕES DISPONÍVEIS*\n';
    text += shown.map((j,i)=>`${String(i+1).padStart(2,'0')} • ${j.icon} *${j.name}*\n    🔑 ${j.id} · Nv.${j.minLevel}\n    💰 ${fmt(j.min)}–${fmt(j.max)} GC · ✨ +${j.xp} XP`).join('\n\n');
    if (unlocked.length > pageSize) text += `\n\n… +${unlocked.length-pageSize} desbloqueadas. Use ×emprego <id> diretamente.`;
    if (locked.length) {
      text += '\n\n🔒 *PRÓXIMAS CONQUISTAS*\n';
      text += locked.slice(0,8).map(j=>`🔒 ${j.icon} ${j.name} — Nv.${j.minLevel}`).join('\n');
      if (locked.length > 8) text += `\n… e mais ${locked.length-8}.`;
    }
    text += '\n\n💡 ×emprego <id> · ×level';
    await ctx.reply(tag(text));
  }});

  registerCommand({name:'emprego', usage:'×emprego <id da vaga>', category:'economia', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Escolhe uma profissão RPG pelo nível.', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    if (!ctx.q) throw new ValidationError('Use: ×emprego <id da vaga>');
    const r = await career.setJob(ctx.sender, ctx.q.trim());
    await ctx.reply(tag(`╭━━━〔 ✅ CONTRATAÇÃO 〕━━━╮\n│\n│ ${r.job.icon} *${r.job.name}*\n│\n│ 👤 ${r.curriculum.name}\n│ ⭐ Nível ${r.rpg.level}\n│ 🔑 Requisito: nível ${r.job.minLevel}\n│ 💰 ${fmt(r.job.min)}–${fmt(r.job.max)} GC\n│ ✨ +${r.job.xp} XP por trabalho\n│\n│ Status: 🟢 CONTRATADO\n│\n╰━━━━━━━━━━━━━━━━━━━━━━━━╯\n\nUse ×trabalhar para exercer sua profissão.`));
  }});

  registerCommand({name:'trabalhar', aliases:['work'], usage:'×trabalhar', category:'economia', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Trabalha na profissão atual e recebe GC + XP RPG.', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    const r = await career.work(ctx.sender, ctx.pushname);
    let text = `╭━━━〔 ${r.job.icon} JORNADA DE TRABALHO 〕━━━╮\n│\n│ 💼 ${r.job.name}\n│ 💰 +${fmt(r.gained)} GC\n│ ✨ +${r.xp} XP\n│ 💳 Saldo: ${fmt(r.wallet)} GC\n│\n│ ⭐ Nível: ${r.level}`;
    if (r.levelUp) text += `\n│\n│ 🎉 *LEVEL UP!*\n│ ⭐ ${r.oldLevel} → ${r.level}`;
    text += '\n│\n╰━━━━━━━━━━━━━━━━━━━━━━━━╯';
    await ctx.reply(tag(text));
  }});

  registerCommand({name:'demitir', usage:'×demitir', category:'economia', plugin:'rpg-career', priority:1000, cooldown:3, groupOnly:true, description:'Sai da profissão atual.', audit:true, handler:async ctx=>{
    requireRpgMode(ctx);
    const r = await career.resign(ctx.sender);
    await ctx.reply(tag(`👋 *DESLIGAMENTO*\n\n${r.job?.icon || '💼'} ${r.job?.name || r.old}\n\nVocê saiu da profissão.\n\nUse ×vagas para escolher outra.`));
  }});
}
