import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import relationshipService from '../../services/relationshipService.js';

const args = c => Array.isArray(c.args) ? c.args : [];
const target = c => c.mentioned?.[0] || args(c)[0] || null;
const at = id => `@${String(id || '').split('@')[0]}`;

async function userRelation(c) {
  const other = target(c);
  if (!other || other === c.sender) return c.reply('❌ Marque outro usuário. Exemplo: ×relacionamento @user elogiar');
  const actionIndex = c.mentioned?.length ? 0 : 1;
  const action = String(args(c)[actionIndex] || 'ver').toLowerCase();
  try {
    const relation = await relationshipService.interactUsers(c.sender, other, action);
    return c.reply(`❤️ *RELACIONAMENTO SOCIAL*\n\n${at(c.sender)} × ${at(other)}\n💗 Afinidade: ${relation.affinity}\n🤝 Confiança: ${relation.trust}\n🏷️ Status: ${relation.status}\n\nAções: ver, elogiar, ajudar, brigar, beijar, amizade`, { mentions: [other] });
  } catch (error) { return c.reply(`❌ ${error?.message || 'Não foi possível atualizar o relacionamento.'}`); }
}

async function npcRelation(c) {
  const npc = String(args(c)[0] || '').trim();
  const action = String(args(c)[1] || 'ver').toLowerCase();
  if (!npc) return c.reply('🤖 ×relacaonpc <npc> <ver|elogiar|conversar|rivalizar>');
  try {
    const relation = action === 'ver' ? relationshipService.getNpcRelation(c.sender, npc) : await relationshipService.interactNpc(c.sender, npc, action);
    return c.reply(`🤖 *NPC ${relation.npc || npc}*\n❤️ Afinidade: ${relation.affinity}\n🤝 Confiança: ${relation.trust}\n🛡️ Respeito: ${relation.respect}\n🧠 Memórias: ${(relation.memories || []).length}\n📜 Interações: ${(relation.history || []).length}`);
  } catch (error) { return c.reply(`❌ ${error?.message || 'Não foi possível atualizar a relação com o NPC.'}`); }
}

async function npcMemories(c) {
  const npc = String(args(c)[0] || '').trim();
  if (!npc) return c.reply('🤖 ×npcmemorias <nome>');
  const relation = relationshipService.getNpcRelation(c.sender, npc);
  const memories = (relation.memories || []).slice(-15).reverse();
  if (!memories.length) return c.reply('🧠 Esse NPC ainda não possui memória registrada.');
  return c.reply(`🧠 *MEMÓRIAS DE ${relation.npc || npc}*\n\n${memories.map(m => `• ${new Date(m.at).toLocaleString('pt-BR')} — ${m.act}`).join('\n')}`);
}

const common = { permission: Role.USER, category: 'social-relacionamentos', plugin: 'relationships', cooldown: 2, audit: true };
export async function register() {
  registerCommand({ ...common, name: 'relacaouser', aliases: ['relacionamento', 'reluser'], description: 'Consulta ou atualiza a afinidade entre usuários.', usage: '×relacionamento @user <ação>', handler: userRelation });
  registerCommand({ ...common, name: 'relacaonpc', aliases: ['npc', 'relacionamentonpc'], description: 'Consulta ou atualiza sua relação com um NPC.', usage: '×relacaonpc <npc> <ação>', handler: npcRelation });
  registerCommand({ ...common, name: 'npcmemorias', aliases: ['memorianpc'], description: 'Mostra as memórias registradas de um NPC.', usage: '×npcmemorias <nome>', handler: npcMemories });
}
export default { register };
