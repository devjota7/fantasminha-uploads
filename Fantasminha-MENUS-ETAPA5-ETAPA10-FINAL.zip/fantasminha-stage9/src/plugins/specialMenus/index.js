/**
 * Menus especiais — Etapa 1.
 *
 * Os menus são apenas pontos de entrada/navegação nesta etapa.
 * Eles permanecem vazios de comandos de benefício até as etapas seguintes.
 * A autorização de abertura é independente da autorização dos comandos que
 * futuramente aparecerão dentro de cada menu.
 */
import { registerCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { SPECIAL_ROLE } from '../../core/specialRoles.js';
import { getSpecialRoleStats } from '../../services/specialRoleStats.js';

const PLUGIN = 'specialMenus';
const TAG = '† FANTASMINHA · MENUS ESPECIAIS';

const MENU_RULES = Object.freeze([
  {
    name: 'menudono',
    aliases: ['paineldono'],
    title: '👑 MENU DONO',
    description: 'Central do Dono Principal e Co-Dono.',
    roles: ['owner', 'co_owner']
  },
  {
    name: 'menuaranha',
    aliases: ['aranhamenu'],
    title: '🕷️ MENU ARANHA',
    description: 'Central do status Aranha.',
    roles: ['owner', 'co_owner']
  },
  {
    name: 'menuvip',
    aliases: ['vipmenu'],
    title: '💎 MENU VIP',
    description: 'Central dos benefícios VIP.',
    roles: ['owner', 'co_owner']
  },
  {
    name: 'menusubdono',
    aliases: ['subdonomenu'],
    title: '🛡️ MENU SUBDONO',
    description: 'Central do Subdono.',
    roles: ['owner', 'co_owner', 'sub_owner']
  },
  {
    name: 'menusuporte',
    aliases: ['suportemenu'],
    title: '🆘 MENU SUPORTE',
    description: 'Central do Suporte.',
    roles: ['owner', 'co_owner', 'sub_owner', 'support']
  }
]);



const STATS_RULES = Object.freeze([
  { name: 'statsaranha', aliases: ['aranhastats', 'estatisticasaranha'], role: SPECIAL_ROLE.ARANHA, roles: ['owner', 'co_owner', 'aranha'], title: '🕷️ ESTATÍSTICAS ARANHA' },
  { name: 'statssuporte', aliases: ['suportestats', 'estatisticassuporte'], role: SPECIAL_ROLE.SUPPORT, roles: ['owner', 'co_owner', 'support'], title: '🆘 ESTATÍSTICAS SUPORTE' },
  { name: 'statssubdono', aliases: ['subdonostats', 'estatisticassubdono'], role: SPECIAL_ROLE.SUB_OWNER, roles: ['owner', 'co_owner', 'sub_owner'], title: '🛡️ ESTATÍSTICAS SUBDONO' },
  { name: 'statsvip', aliases: ['vipstats', 'estatisticasvip'], role: SPECIAL_ROLE.VIP, roles: ['owner', 'co_owner', 'vip'], title: '💎 ESTATÍSTICAS VIP' }
]);

function statsText(rule, stats) {
  let text = `${TAG}\n\n╭──────────────╮\n        ${rule.title}\n╰──────────────╯\n\n`;
  text += `👥 Total ativo: *${stats.total}*\n`;
  if (rule.role === SPECIAL_ROLE.ARANHA && stats.scope === 'none') {
    text += '\n🕷️ As estatísticas da Aranha são por grupo e precisam ser consultadas em um grupo.';
  } else if (rule.role === SPECIAL_ROLE.VIP) {
    text += `\n🥉 Bronze: *${stats.plans.bronze}*\n🥈 Prata: *${stats.plans.prata}*\n🥇 Ouro: *${stats.plans.ouro}*`;
  }
  return text;
}

function emptyMenuText(menu) {
  return `${TAG}\n\n╭──────────────╮\n        ${menu.title}\n╰──────────────╯\n\n📂 *MENU EM CONSTRUÇÃO*\n\nEste menu está criado, mas ainda não possui comandos nesta etapa.\n\n🔐 O acesso ao menu não concede automaticamente os benefícios ou permissões dos comandos que serão adicionados futuramente.`;
}

export async function register() {
  for (const menu of MENU_RULES) {
    registerCommand({
      name: menu.name,
      aliases: menu.aliases,
      category: 'navegacao',
      plugin: PLUGIN,
      permission: Role.USER,
      specialRoles: menu.roles,
      hidden: true,
      cooldown: 2,
      description: menu.description,
      usage: `×${menu.name}`,
      handler: async ctx => ctx.reply(emptyMenuText(menu))
    });
  }

  for (const rule of STATS_RULES) {
    registerCommand({
      name: rule.name,
      aliases: rule.aliases,
      category: 'navegacao',
      plugin: PLUGIN,
      permission: Role.USER,
      specialRoles: rule.roles,
      hidden: true,
      cooldown: 2,
      description: `Estatísticas do sistema ${rule.role}.`,
      usage: `×${rule.name}`,
      handler: async ctx => ctx.reply(statsText(rule, getSpecialRoleStats(ctx, rule.role)))
    });
  }
}

export { MENU_RULES, STATS_RULES };
export default { register };
