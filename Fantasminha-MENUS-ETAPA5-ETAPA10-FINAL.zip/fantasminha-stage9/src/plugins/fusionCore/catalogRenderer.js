const CATEGORY_MARKERS = Object.freeze({
  sistema: '//', geral: '//', ferramentas: '//', downloads: '//', ia: '//', utilidades: '//',
  produtividade: '//', media: '//', figurinhas: '//', alem: '//', 'mega-expansao': '//', menu: '//',
  perfil: '†', rankings: '†', economia: '†', premium: '†', licenca: '†', personal: '†', conquistas: '†',
  dono: '†', owner: '†', admin: '†', seguranca: '†',
  jogos: '#', quiz: '#', brincadeiras: '#', competitivo: '#', torneios: '#', rpg: '#', world: '#', mundo: '#',
  pets: '#', social: '#', comunidade: '#', clan: '#'
});

const CATEGORY_LABELS = Object.freeze({
  alem: 'ALÉM', licenca: 'LICENÇA', seguranca: 'SEGURANÇA', media: 'MÍDIA',
  'mega-expansao': 'MEGA-EXPANSÃO'
});

function categoryTitle(category) {
  const key = String(category || 'geral').trim().toLowerCase() || 'geral';
  const label = CATEGORY_LABELS[key] || key.replace(/[-_]+/g, ' ').toLocaleUpperCase('pt-BR');
  return `${CATEGORY_MARKERS[key] || '//'} ${label}`;
}

/** Agrupa resultados por assunto; prefixos dos comandos permanecem literais. */
export function renderCatalogRows(rows = [], { prefix = '×', emptyText = 'Nenhum resultado.' } = {}) {
  const source = Array.isArray(rows) ? rows : [];
  if (!source.length) return emptyText;

  const groups = new Map();
  for (const command of source) {
    const category = String(command?.category || 'geral').trim().toLowerCase() || 'geral';
    if (!groups.has(category)) groups.set(category, []);
    groups.get(category).push(command);
  }

  return [...groups.entries()].map(([category, commands]) => {
    const lines = commands.map(command => {
      const name = String(command?.name || '').trim();
      if (!name) return null;
      const description = String(command?.description || '').replace(/\s+/g, ' ').trim();
      return `• ${prefix}${name}${description ? ` — ${description}` : ''}`;
    }).filter(Boolean);
    return lines.length ? `${categoryTitle(category)}\n${lines.join('\n')}` : '';
  }).filter(Boolean).join('\n\n');
}

export default { renderCatalogRows };
