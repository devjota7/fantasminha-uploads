import { registerCommand, listCommands, getCommand } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { setCommandHidden, hiddenCommands } from '../../platform/commandVisibility.js';
import { analyzeScam, getConfig, setConfig, reportScam } from '../../services/antiScam.js';
import { on, Events } from '../../events/index.js';
import { addNote, editNote, getNote, getNoteByPosition, resolveNote, parseNoteDirectInput, listNotes, removeNote, migrateLegacyNotes } from '../../services/notes.js';
import { envelopeStats } from '../../core/messageEnvelope.js';
import { listTools, registerTool } from '../../core/toolRegistry.js';
import { resolveIntent } from '../../services/aiAgent.js';
import { runCommand } from '../../core/registry.js';
import { upsertCustomCommand, removeCustomCommand, listCustomCommands } from '../../services/customCommands.js';
import { platformAnalytics, analyticsText } from '../../platform/analytics.js';
import { listRuntime, setRuntime } from '../../core/runtimeConfig.js';
import { resourceStats } from '../../core/resourceManager.js';
import { queues } from '../../core/queue.js';
import { searchKnowledge, listKnowledge } from '../../services/knowledge/index.js';
import { listJobs } from '../../platform/jobs/index.js';
import { controlSnapshot } from '../../platform/controlCenter/index.js';
import { searchCommands, explainCommand } from '../../services/commandSearch.js';
import { env } from '../../config/env.js';
import { renderCatalogRows } from './catalogRenderer.js';
import { renderCommandHelp } from './helpRenderer.js';


const tag = s => `× 👻 *FANTASMINHA*\n\n${s}`;

export async function register() {
  const defs = [
    {
      name:'controlcenter', aliases:['dashboard','painelweb'], category:'dono', permission:Role.OWNER, cooldown:5,
      description:'Resumo do Control Center e módulos operacionais.',
      handler: async ctx => { const s=controlSnapshot(); return ctx.reply(tag(`🖥️ *CONTROL CENTER*\n\nRegistry: ${s.registry.total} comandos / ${s.registry.aliases} aliases\nFilas: ${Object.keys(s.queues).length}\nRecursos ativos: ${s.resources.active}\nConhecimento: ${s.knowledge.length} documentos\nJobs: ${listJobs().length}\n\nDashboard web: ${env.DASHBOARD_ENABLED==='true'?'ATIVO':'DESATIVADO'}\nHost: ${env.DASHBOARD_HOST||'127.0.0.1'}\nPorta: ${env.DASHBOARD_PORT||8787}`)); }
    },
    {
      name:'filas', aliases:['queues','queue'], category:'sistema', permission:Role.OWNER, cooldown:3,
      handler: async ctx => ctx.reply(tag(`📨 *FILAS*\n\n${Object.values(queues).map(q=>{const x=q.getStatus();return `• *${x.name}* — pendentes ${x.pending} | ativas ${x.active} | concluídas ${x.completed} | falhas ${x.failed} | média ${x.avgMs}ms`;}).join('\n')}`))
    },
    {
      name:'recursos', aliases:['resources','memory'], category:'sistema', permission:Role.OWNER, cooldown:5,
      handler: async ctx => { const s=resourceStats(); return ctx.reply(tag(`🧹 *RECURSOS*\n\nAtivos: *${s.active}*\n${s.resources.slice(0,30).map(x=>`• ${x.id} — ${x.idleMs}ms ocioso`).join('\n')||'Nenhum recurso rastreado.'}`)); }
    },
    {
      name:'runtime', aliases:['configruntime','configlive'], category:'dono', permission:Role.OWNER, cooldown:3,
      handler: async ctx => { const key=ctx.args?.[0]; const value=ctx.args?.slice(1).join(' '); if(!key) return ctx.reply(tag(`⚙️ *RUNTIME*\n\n${listRuntime().map(x=>`• ${x.key} = ${x.value}`).join('\n')}\n\nPara alterar: ×runtime <chave> <valor>`)); let v=value; if(value==='true')v=true; else if(value==='false')v=false; try{setRuntime(key,v);return ctx.reply(tag(`⚙️ ${key} = *${v}*`));}catch(e){return ctx.reply(tag(`❌ ${e.message}`));} }
    },
    {
      name:'conhecimento', aliases:['knowledge','kb','faq'], category:'ia', permission:Role.USER, cooldown:3,
      handler: async ctx => { const q=ctx.q||ctx.args?.join(' '); if(!q) return ctx.reply(tag(`📚 *KNOWLEDGE BASE*\n\n${listKnowledge().map(x=>`• *${x.title}* — ${x.tags.join(', ')}`).join('\n')}\n\nUse: ×conhecimento <pergunta>`)); const rows=searchKnowledge(q); return ctx.reply(tag(`📚 *RESULTADOS*\n\n${rows.map(x=>`• *${x.title}* — relevância ${x.score}`).join('\n')||'Nenhum documento relevante encontrado.'}`)); }
    },

    {
      name:'notas', aliases:['notes'], category:'produtividade', permission:Role.USER, cooldown:2,
      description:'Lista suas notas pessoais.',
      handler: async ctx => {
        await migrateLegacyNotes();
        const rows=listNotes(ctx.sender);
        if(!rows.length) return ctx.reply(tag('📝 *MINHAS NOTAS*\n\nNenhuma nota cadastrada.\n\nUse: ×addnota <nome> | <texto>'));
        return ctx.reply(tag(`📝 *MINHAS NOTAS*\n\n${rows.map((x,i)=>`${i+1}. *${x.name}*`).join('\n')}\n\nAbra com: ×nota <número> ou ×nota <nome>`));
      }
    },
    {
      name:'addnota', aliases:['anotarnota'], category:'produtividade', permission:Role.USER, cooldown:2,
      description:'Cria uma nota pessoal pelo nome.',
      handler: async ctx => {
        await migrateLegacyNotes();
        const raw=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!raw) return ctx.reply(tag('📝 *NOVA NOTA*\n\nUse: ×addnota <nome> | <texto>'));
        const parsed=parseNoteDirectInput(raw);
        if(!parsed.hasSeparator) return ctx.reply(tag('📝 Para criar diretamente, use:\n×addnota <nome> | <texto>\n\nO fluxo de duas mensagens será ativado na próxima etapa.'));
        const name=parsed.name;
        const text=parsed.text;
        if(!name||!text) return ctx.reply(tag('📝 Use: ×addnota <nome> | <texto>'));
        if(getNote(ctx.sender,name)) return ctx.reply(tag(`⚠️ Já existe uma nota chamada *${name}*.\nUse ×editora ${name} | <novo texto> para alterar.`));
        try { const saved=await addNote({userId:ctx.sender,name,text}); return ctx.reply(tag(`📝 *NOTA SALVA*\n\n🏷️ Nome: *${saved.name}*\n📄 ${saved.text}`)); } catch(e) { return ctx.reply(tag(`❌ ${e.message}`)); }
      }
    },
    {
      name:'editora', aliases:['editnota'], category:'produtividade', permission:Role.USER, cooldown:2,
      description:'Edita uma nota pessoal pelo nome ou posição.',
      handler: async ctx => {
        await migrateLegacyNotes();
        const raw=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!raw) return ctx.reply(tag('✏️ Use: ×editora <número ou nome> | <novo texto>'));
        const parsed=parseNoteDirectInput(raw);
        if(!parsed.hasSeparator) return ctx.reply(tag('✏️ Use: ×editora <número ou nome> | <novo texto>\n\nO fluxo de duas mensagens será ativado na próxima etapa.'));
        const ref=parsed.name;
        const text=parsed.text;
        if(!ref||!text) return ctx.reply(tag('✏️ Use: ×editora <número ou nome> | <novo texto>'));
        const note=resolveNote(ctx.sender,ref);
        if(!note) return ctx.reply(tag(`❌ Nota *${ref}* não encontrada.`));
        try { const updated=await editNote({userId:ctx.sender,name:note.name,noteId:note.id,text}); return ctx.reply(tag(`✏️ *NOTA ATUALIZADA*\n\n🏷️ Nome: *${updated.name}*\n📄 ${updated.text}`)); } catch(e) { return ctx.reply(tag(`❌ ${e.message}`)); }
      }
    },
    {
      name:'delnota', aliases:['apagarnota'], category:'produtividade', permission:Role.USER, cooldown:2,
      description:'Apaga uma nota pessoal pelo nome ou posição.',
      handler: async ctx => {
        await migrateLegacyNotes();
        const ref=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!ref) return ctx.reply(tag('🗑️ Use: ×delnota <número ou nome>'));
        const note=resolveNote(ctx.sender,ref);
        if(!note) return ctx.reply(tag(`❌ Nota *${ref}* não encontrada.`));
        const ok=await removeNote(ctx.sender,note.name,note.id);
        return ctx.reply(tag(ok?`🗑️ *NOTA APAGADA*\n\n🏷️ ${note.name}`:'❌ Não foi possível apagar a nota.'));
      }
    },
    {
      name:'nota', aliases:['note'], category:'produtividade', permission:Role.USER, cooldown:2,
      description:'Abre uma nota pessoal pelo nome ou posição.',
      handler: async ctx => {
        await migrateLegacyNotes();
        const ref=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!ref) return ctx.reply(tag('📝 Use: ×nota <número ou nome>'));
        const note=resolveNote(ctx.sender,ref);
        if(!note) return ctx.reply(tag(`❌ Nota *${ref}* não encontrada.`));
        return ctx.reply(tag(`📝 *NOTA*\n\n🏷️ Nome: *${note.name}*\n\n📄 ${note.text}`));
      }
    },
    {
      name:'ocultarcmd', aliases:['hidecmd','cmdhide'], category:'dono', permission:Role.OWNER, cooldown:2,
      handler: async ctx => { const name=ctx.args?.[0]; if(!name) return ctx.reply(tag('Use: ×ocultarcmd <comando>')); if(!getCommand(name)) return ctx.reply(tag(`Comando não encontrado: *${name}*`)); await setCommandHidden(name,true,ctx.sender); return ctx.reply(tag(`👁️‍🗨️ *${name}* foi ocultado do menu, mas continua funcionando.`)); }
    },
    {
      name:'mostrarcmd', aliases:['showcmd','cmdshow'], category:'dono', permission:Role.OWNER, cooldown:2,
      handler: async ctx => { const name=ctx.args?.[0]; if(!name) return ctx.reply(tag('Use: ×mostrarcmd <comando>')); await setCommandHidden(name,false,ctx.sender); return ctx.reply(tag(`👁️ *${name}* está novamente visível no menu.`)); }
    },
    {
      name:'cmdvisiveis', aliases:['comandosvisiveis'], category:'dono', permission:Role.OWNER, cooldown:2,
      handler: async ctx => ctx.reply(tag(`👁️ *VISIBILIDADE*\n\nOcultos: ${hiddenCommands().length}\n${hiddenCommands().slice(0,40).map(x=>`• ${x}`).join('\n')||'Nenhum.'}`))
    },
    {
      name:'scamcheck', aliases:['checkscam','antiscamcheck'], category:'seguranca', permission:Role.USER, cooldown:3,
      handler: async ctx => { const text=ctx.q||ctx.args?.join(' '); if(!text) return ctx.reply(tag('Use: ×scamcheck <texto>')); const r=analyzeScam(text); return ctx.reply(tag(`${r.detected?'🚨':'✅'} *ANÁLISE ANTI-SCAM*\n\nRisco: *${r.risk.toUpperCase()}* (${r.score}/100)\nCategorias: ${r.categories.join(', ')||'nenhuma'}\n\n⚠️ Resultado é heurístico; confirme informações antes de agir.`)); }
    },
    {
      name:'antiscam', aliases:['scamguard'], category:'seguranca', permission:Role.GROUP_ADMIN, cooldown:3, groupOnly:true,
      description:'Configura proteção heurística contra golpes.',
      handler: async ctx => {
        const sub=(ctx.args?.[0]||'').toLowerCase();
        const cfg=getConfig(ctx.from);
        if(!sub) return ctx.reply(tag(`🛡️ *ANTI-SCAM*\n\nStatus: ${cfg.enabled?'ON':'OFF'}\nAção: ${cfg.action}\n\n×antiscam on|off\n×antiscam action alert|delete|warn`));
        if(sub==='on'||sub==='off') { await setConfig(ctx.from,{enabled:sub==='on'}); return ctx.reply(tag(`🛡️ Anti-Scam: *${sub.toUpperCase()}*`)); }
        if(sub==='action' && ['alert','delete','warn'].includes((ctx.args?.[1]||'').toLowerCase())) { await setConfig(ctx.from,{action:ctx.args[1].toLowerCase()}); return ctx.reply(tag(`Ação Anti-Scam: *${ctx.args[1].toLowerCase()}*`)); }
        return ctx.reply(tag('Uso: ×antiscam on|off|action <alert|delete|warn>'));
      }
    },
    {
      name:'listaferramentas', aliases:['tools','aitools'], category:'ia', permission:Role.USER, cooldown:2,
      description:'Lista as ferramentas de IA disponíveis.',
      handler: async ctx => { const t=listTools(); return ctx.reply(tag(`🧠 *TOOLS DISPONÍVEIS*\n\n${t.map(x=>`• *${x.name}* — ${x.description||'sem descrição'}`).join('\n')||'Nenhuma ferramenta registrada.'}`)); }
    },
    {
      name:'envelopes', aliases:['envelope','messageregistry'], category:'sistema', permission:Role.OWNER, cooldown:5,
      handler: async ctx => { const s=envelopeStats(); return ctx.reply(tag(`📨 *MESSAGE ENVELOPE REGISTRY*\n\nEscopos: ${s.scopes}\nMensagens em memória: ${s.entries}\nTTL: ${Math.round(s.ttlMs/60000)} min\nLimite/escopo: ${s.maxPerScope}`)); }
    },
    {
      name:'agente', aliases:['agent'], category:'ia', permission:Role.USER, cooldown:3,
      description:'Interpreta pedidos simples e encaminha para ferramentas autorizadas.',
      handler: async ctx => {
        const query=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!query) return ctx.reply(tag('Use: ×agente <pedido>'));
        const available=new Set(listCommands().map(c=>c.name));
        const intent=resolveIntent(query,available);
        if(!intent) return ctx.reply(tag('🧠 Não identifiquei uma ação segura para esse pedido. Tente usar ×catalogo ou um comando direto.'));
        const result=await runCommand(intent.command,{...ctx,args:intent.args,q:intent.args.join(' '),command:intent.command});
        return result;
      }
    },
    {
      name:'criarcmd', aliases:['addcmd','setcmd'], category:'dono', permission:Role.OWNER, cooldown:2,
      description:'Cria um comando de resposta sem executar código.',
      handler: async ctx => {
        const [name,...rest]=ctx.args||[]; const text=rest.join(' ');
        if(!name||!text) return ctx.reply(tag('Use: ×criarcmd <nome> <resposta>'));
        const item=await upsertCustomCommand({name,text,actor:ctx.sender});
        return ctx.reply(tag(`🧩 Comando personalizado *${item.name}* salvo.`));
      }
    },
    {
      name:'rmcmd', aliases:['delcmd','removecmd'], category:'dono', permission:Role.OWNER, cooldown:2,
      description:'Remove um comando personalizado.',
      handler: async ctx => { const name=ctx.args?.[0]; if(!name) return ctx.reply(tag('Use: ×rmcmd <nome>')); const ok=await removeCustomCommand(name); return ctx.reply(tag(ok?'🗑️ Comando personalizado removido.':'Comando personalizado não encontrado.')); }
    },
    {
      name:'listacmd', aliases:['customcmds'], category:'dono', permission:Role.OWNER, cooldown:2,
      handler: async ctx => { const rows=listCustomCommands(); return ctx.reply(tag(`🧩 *COMANDOS PERSONALIZADOS*\n\n${rows.map(x=>`• *${x.name}* — ${x.text.slice(0,90)}`).join('\n')||'Nenhum.'}`)); }
    },
    {
      name:'guiafantasminha', aliases:['guiabot','manualfantasminha'], category:'dono', permission:Role.OWNER, ownerOnly:true, cooldown:3,
      description:'Guia completo de configuração, personalização e manutenção do Fantasminha.',
      handler: async ctx => {
        const fs=await import('fs/promises');
        const path=await import('path');
        const file=path.join(process.cwd(),'docs','GUIA-FANTASMINHA.txt');
        let text=await fs.readFile(file,'utf8');
        const replacements={
          '${prefix}':ctx.prefix||'×',
          '${nomebot}':'Fantasminha',
          '${nomedono}':ctx.ownerName||'Jota',
          '${numerodono}':ctx.ownerNumber||'configurado no .env'
        };
        for(const [a,b] of Object.entries(replacements)) text=text.split(a).join(b);
        return ctx.reply(text);
      }
    },
    {
      name:'ajuda', aliases:['ajudar','help'], category:'sistema', permission:Role.USER, cooldown:2,
      description:'Explica completamente como usar um comando.',
      handler: async ctx => {
        const query=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!query) return ctx.reply(tag(`📚 *CENTRAL DE AJUDA*\n\nUse *${ctx.prefix||'×'}ajuda <comando>* para receber uma explicação completa.\nExemplo: *${ctx.prefix||'×'}ajuda guerras*\n\n💡 Você também pode escrever uma intenção: *${ctx.prefix||'×'}ajuda quero fazer guerras*\nEu encontro o comando mais relacionado.`));
        const c=explainCommand(query)||searchCommands(query,{limit:1})[0]?.command;
        if(!c) return ctx.reply(tag(`❓ Não encontrei um comando para *${query}*.\n\nTente *${ctx.prefix||'×'}buscar ${query}*.`));
        return ctx.reply(tag(renderCommandHelp(c, { prefix: ctx.prefix || '×' })));
      }
    },
    {
      name:'buscar', aliases:['search','procurar'], category:'sistema', permission:Role.USER, cooldown:2,
      description:'Encontra até 5 comandos relacionados ao que você descreveu.',
      handler: async ctx => {
        const query=String(ctx.q||ctx.args?.join(' ')||'').trim();
        if(!query) return ctx.reply(tag(`🔎 *BUSCA INTELIGENTE*\n\nEscreva o que você quer fazer, não precisa saber o nome do comando.\n\nExemplo: *${ctx.prefix||'×'}buscar quero fazer guerras*`));
        const rows=searchCommands(query,{limit:5});
        if(!rows.length) return ctx.reply(tag(`🔎 Nada encontrado para *${query}*.\n\nTente descrever a ação de outro jeito.`));
        return ctx.reply(tag(`🔎 *ENCONTREI PARA VOCÊ*\n\n${rows.map((x,i)=>`${i+1}️⃣ *${ctx.prefix||'×'}${x.command.name}* — ${x.command.description||x.command.category}`).join('\n')}\n\n📖 Quer saber como usar? *${ctx.prefix||'×'}ajuda ${rows[0].command.name}*`));
      }
    },
    {
      name:'catalogo', aliases:['comandoscatalogo'], category:'sistema', permission:Role.USER, cooldown:2,
      handler: async ctx => { const q=String(ctx.q||'').toLowerCase(); const rows=listCommands().filter(c=>!q||[c.name,c.description,c.category,...c.aliases].join(' ').toLowerCase().includes(q)).slice(0,40); const catalog=renderCatalogRows(rows,{prefix:ctx.prefix||'×'}); return ctx.reply(tag(`📚 *CATÁLOGO*\n\n${catalog}`)); }
    }
  ];
  for (const def of defs) registerCommand({...def, plugin:'fusion-core', version:'10.3.0'});
  on(Events.MESSAGE, async ctx => {
    if (!ctx?.isGroup || !ctx?.from || !ctx?.body || ctx?.isOwner || ctx?.isGroupAdmin) return;
    const cfg=getConfig(ctx.from);
    if (!cfg.enabled) return;
    const result=analyzeScam(ctx.body);
    if (!result.detected) return;
    const incident=await reportScam({text:ctx.body,group:ctx.from,sender:ctx.sender,actor:'anti-scam'});
    if (ctx.reply && cfg.action !== 'delete') await ctx.reply(tag(`🚨 *ALERTA ANTI-SCAM*

Sua mensagem foi sinalizada como possível *${result.risk}* risco (${result.score}/100).
Categorias: ${result.categories.join(', ')||'suspeita'}`));
    if (cfg.action === 'delete' && ctx.deleteMessage) { try { await ctx.deleteMessage(); } catch {} }
  });
  registerTool({name:'status',description:'Mostra o estado operacional do bot.',command:'status',permission:Role.USER});
  registerTool({name:'catalogo',description:'Lista comandos disponíveis.',command:'catalogo',permission:Role.USER});
  registerTool({name:'scamcheck',description:'Analisa um texto por padrões de golpe.',command:'scamcheck',permission:Role.USER});
}
export default { register };
