import { Role, roleName } from '../../core/permissions.js';

function usageFor(command, prefix) {
  return String(command?.usage || `${prefix}${command?.name || 'comando'}${command?.q ? ' <texto>' : ''}`).trim();
}

export function requiresDetailedHelp(command = {}) {
  const permission = Number(command.permission ?? Role.USER);
  const usage = String(command.usage || '');
  const examples = Array.isArray(command.examples) ? command.examples : [];
  return Boolean(
    command.ownerOnly || command.adminOnly || command.groupOnly || command.privateOnly ||
    (Number.isFinite(permission) && permission > Role.USER) ||
    (Array.isArray(command.subcommands) && command.subcommands.length > 0) ||
    /\|/.test(usage) || examples.length > 1 || /\bsubcomandos?\b/i.test(String(command.description || ''))
  );
}

function scopeLabel(command) {
  if (command.groupOnly) return 'Grupo';
  if (command.privateOnly) return 'Privado';
  return 'Grupo ou privado';
}

export function renderCommandHelp(command = {}, { prefix = '×' } = {}) {
  const name = String(command.name || 'comando');
  const description = String(command.description || command.purpose || 'Comando do Fantasminha.');
  const usage = usageFor(command, prefix);
  const examples = Array.isArray(command.examples) && command.examples.length
    ? command.examples.map(example => String(example))
    : [usage];
  const detailed = requiresDetailedHelp(command);
  const header = detailed ? `📖 *DOSSIÊ DO COMANDO — ${prefix}${name}*` : `📖 *GUIA RÁPIDO — ${prefix}${name}*`;

  if (!detailed) {
    const lines = [header, '', '▸ O que faz', description, '', '▸ Como usar', usage];
    if (examples[0] && examples[0] !== usage) lines.push('', '▸ Exemplo', examples[0]);
    return lines.join('\n');
  }

  const aliases = Array.isArray(command.aliases) && command.aliases.length
    ? command.aliases.map(alias => `${prefix}${alias}`).join(', ')
    : 'nenhum';
  const permission = command.ownerOnly ? 'Dono' : roleName(Number(command.permission ?? Role.USER));
  return [
    header,
    '', '▸ O que faz', description,
    '', `▸ Categoria`, `${command.category || 'geral'}${command.subcategory ? ` / ${command.subcategory}` : ''}`,
    `▸ Aliases`, aliases,
    '', '▸ Como usar', usage,
    '', `▸ ${examples.length > 1 ? 'Exemplos' : 'Exemplo'}`, ...examples.map(example => `• ${example}`),
    '', '▸ Acesso e contexto', `Permissão: ${permission}`, `Disponível em: ${scopeLabel(command)}`
  ].join('\n');
}

export default { renderCommandHelp, requiresDetailedHelp };
