import { registerCommand } from '../../core/registry.js';
import { ValidationError } from '../../core/errors.js';
import * as clan from '../../services/clanService.js';

const tag = text => `× 👻 FANTASMINHA • CLÃ\n\n${text}`;
const args = ctx => (Array.isArray(ctx.args) ? ctx.args : String(ctx.q || '').trim().split(/\s+/).filter(Boolean));
const target = ctx => ctx.mentioned?.[0] || args(ctx)[0];
const fmt = n => Number(n || 0).toLocaleString('pt-BR');

export async function register() {
  registerCommand({ name: 'clan', aliases: ['clãs', 'clans'], category: 'clan', plugin: 'clan', cooldown: 3, description: 'Mostra seu clã.', handler: async ctx => {
    const c = clan.getClanFor(ctx.sender);
    if (!c) return ctx.reply(tag(`Você não está em um clã.\n\nUse ×clancriar <nome> ou ×clanrank.`));
    const members = clan.members(ctx.sender);
    return ctx.reply(tag(`🏰 *${c.name}*\n\n🆔 ${c.id}\n👑 Líder: @${c.owner.split('@')[0]}\n⭐ Nível: ${c.level}\n✨ XP: ${fmt(c.xp)}\n💰 Tesouro: ${fmt(c.treasury)} GC\n👥 Membros: ${c.members.length}/${clan.CLAN_MAX_MEMBERS}\n\n${members.slice(0, 15).map((m, i) => `${i + 1}. ${m.name} — ${m.role}`).join('\n')}`));
  }});
  registerCommand({ name: 'clancriar', aliases: ['criarclan', 'criarcla'], category: 'clan', plugin: 'clan', cooldown: 10, description: 'Cria um clã.', handler: async ctx => {
    if (!ctx.q) throw new ValidationError(`Use ×clancriar <nome> — custo ${fmt(clan.CLAN_CREATE_COST)} GC.`);
    const c = await clan.createClan(ctx.sender, ctx.q, ctx.pushname);
    await ctx.reply(tag(`🏰 *CLÃ CRIADO*\n\n${c.name}\n🆔 ${c.id}\n💰 Tesouro inicial: ${fmt(c.treasury)} GC`));
  }});
  registerCommand({ name: 'clanentrar', aliases: ['entrarclan', 'entrarcla'], category: 'clan', plugin: 'clan', cooldown: 5, description: 'Entra em um clã pelo ID.', handler: async ctx => {
    const c = await clan.joinClan(ctx.sender, args(ctx)[0], ctx.pushname);
    await ctx.reply(tag(`✅ Você entrou no clã *${c.name}*.\n👥 ${c.members.length}/${clan.CLAN_MAX_MEMBERS}`));
  }});
  registerCommand({ name: 'clansair', aliases: ['sairclan', 'saircla'], category: 'clan', plugin: 'clan', cooldown: 5, description: 'Sai do clã atual.', handler: async ctx => {
    const c = await clan.leaveClan(ctx.sender);
    await ctx.reply(tag(`👋 Você saiu de *${c.name}*.`));
  }});
  registerCommand({ name: 'clancontribuir', aliases: ['doarclan', 'doarcla'], category: 'clan', plugin: 'clan', cooldown: 5, description: 'Contribui Ghostcoins para o tesouro do clã.', handler: async ctx => {
    const value = args(ctx)[0];
    if (!value) throw new ValidationError('Use ×clancontribuir <valor>.');
    const c = await clan.contribute(ctx.sender, value, ctx.pushname);
    await ctx.reply(tag(`💰 Contribuição registrada: ${fmt(value)} GC.\n🏰 ${c.name}\n⭐ Nível ${c.level} · Tesouro ${fmt(c.treasury)} GC`));
  }});
  registerCommand({ name: 'clanmembros', aliases: ['membrosclan', 'membroscla'], category: 'clan', plugin: 'clan', cooldown: 3, description: 'Lista os membros do clã.', handler: async ctx => {
    const rows = clan.members(ctx.sender);
    await ctx.reply(tag(`👥 *MEMBROS*\n\n${rows.map((m, i) => `${i + 1}. ${m.name} — ${m.role}`).join('\n')}`));
  }});
  registerCommand({ name: 'clanrank', aliases: ['rankclan', 'rankcla'], category: 'clan', plugin: 'clan', cooldown: 5, description: 'Mostra o ranking dos clãs.', handler: async ctx => {
    const rows = clan.ranking(10);
    const list = rows.map((c, i) => `${i + 1}. *${c.name}* — Nv.${c.level} · ${c.members} membros · ${fmt(c.treasury)} GC`).join('\n') || 'Nenhum clã criado.';
    await ctx.reply(tag(`🏆 *RANKING DOS CLÃS*\n\n${list}`));
  }});
}
export default { register };
