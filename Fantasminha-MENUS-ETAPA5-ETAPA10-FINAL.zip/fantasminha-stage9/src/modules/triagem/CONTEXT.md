# Módulo Triagem 2.0 (redesenho)

Fila de entrada para grupos. **O bot coleta, organiza e sinaliza; o admin decide; o dono só analisa.**
Não reaproveita nada da Triagem 1.0 (11.7.11). Nunca criar `src/services/triage*.js` nem `src/plugins/triagem/`.

## Arquivos
- `index.js` — API pública (ganchos do pipeline/connect.js, `buildDeps`).
- `triagem.service.js` — regras: entrada, PV, ficha, aprovar/reprovar/nota, filas.
- `triagem.panel.js` — painéis conversacionais (admin, dono, reprovação guiada). Sessões em memória, 30 min.
- `triagem.repository.js` — persistência no `src/database/store.js` (`triagem_config`, `triagem_rounds`, `triagem_audit`).
- `triagem.signals.js` / `triagem.presenter.js` — sinais de apoio e textos.
- `triagem.identity.js` — identidade canônica JID/LID (compara por sobreposição).
- `*.commands.js` — `triagem`, `triagemficha`, `triagemaprovar`, `triagemcobrar`, `triagemreprovar`, `triagemobs`, `triagemdono`.

## Regras que não podem quebrar
1. Desligada por padrão: precisa de `TRIAGEM_ENABLED=true` no ambiente (sem isso, gancho de entrada, PV e comandos ficam inertes) e, além disso, ativação por grupo; interruptor de emergência do dono (`TRIAGEM_DISABLED=true` também desliga).
2. **Blacklist: só consulta.** Leitura via `src/legacy/adapters/blacklistReader.js`. Reprovar nunca escreve nela.
3. Admin só vê/julga fichas do próprio grupo (ou dos grupos que o usam como grupo de julgamento); sinais entre grupos são só do dono.
4. O dono nunca aprova, reprova nem anota (só configuração global, modelos, relatórios e apagar fichas).
5. Sem Baileys neste módulo (download de mídia fica em `src/platform/media/receivedMedia.js`).
6. Fotos ficam em `data/triagem-media/` (fora do banco e fora do ZIP de release).
7. Uma falha da Triagem nunca pode derrubar boas-vindas/captcha/auto-aceitar (gancho em try/catch).

## Fases 2 e 3 (implementadas)
- `triagem.network.js` — grupos conectados (julgamento compartilhado com aviso, destinos de aprovados), saúde da conexão, adição de aprovados com link de convite como alternativa, `×triagemcobrar` (ID novo, lotes de 5, teto de 30/hora, só no grupo), restrição do pendente (libera sozinha ao vencer o prazo ou se o PV falhar).
- `triagem.reports.js` — estatísticas por período e CSV (sem respostas, fotos nem número completo).
- `triagem.maintenance.js` — tick horário (expira rodadas) e rotina diária: saúde das conexões, fila parada, falhas de PV, aviso de retenção. **Só avisa.** Iniciada por `startTriagemMaintenance` (um gancho no `connect.js`, ao abrir a conexão).
- `triagem.util.js` — mídia, relógio e envio seguro.
- Privacidade: aviso no PV antes das perguntas; **ninguém apaga ficha pelo bot, nem o próprio membro** (pedidos de exclusão vão a um admin ou ao dono); só o dono apaga, no `×triagemdono` (com confirmação e registro sem conteúdo); retenção opcional (só avisa); política de fotos `guardar` (padrão) ou `apagar após julgamento`.
- Configuração: histórico das últimas 20 versões por grupo com restauração; modelos de perguntas da rede (só o dono cria); aviso automático de reprovação ao dono (desligado por padrão).
- Aprovado que volta: nova ficha de atualização com a ficha anterior intacta; por padrão é um pedido (`optional`), o admin pode tornar obrigatório.
- Sinais entre grupos (aprovado/reprovado/resposta idêntica em outro grupo) só aparecem na visão do dono.
- `deps` extras (vindos do socket em `index.js`): `fetchGroups`, `addToGroup`, `inviteLink`, `deleteMessage`, `send.document`.
