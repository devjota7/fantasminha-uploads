import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as service from './triagem.service.js';
import * as view from './triagem.presenter.js';
import { guarded, actorOf, resolveOne, usage } from './triagem.commandKit.js';
import { mentionTag } from './triagem.identity.js';

async function handler(ctx) {
  const query = (ctx.args || [])[0];
  if (!query) return ctx.reply(usage('×triagemaprovar <ID ou #n>'));
  const { rows, round } = resolveOne(ctx, query);
  if (!rows.length) return ctx.reply('🔎 Ficha não encontrada neste grupo.');
  if (!round) return ctx.reply('⚠️ Mais de uma ficha encontrada. Use o ID TRG-… ou o #número.');
  const actor = actorOf(ctx);
  const deps = buildDeps(ctx);
  if (/^repetir$/i.test((ctx.args || [])[1] || '')) {
    const rep = await service.retryApproval(round.id, actor, deps);
    if (!rep.ok) return ctx.reply(`⚠️ ${rep.error}`);
    if (rep.nothing) return ctx.reply('✅ Nada a repetir: todos os destinos já receberam a pessoa.');
    return ctx.reply(`🔁 Repetição feita.${view.renderApprovalSummary(rep.approval)}`);
  }
  const res = await service.approve(round.id, actor, deps);
  if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
  if (res.test) return ctx.reply('🧪 Ficha de teste encerrada. Nada foi alterado para ninguém.');
  const admin = mentionTag([actor.id]);
  return deps.send.text(ctx.from, `✅ @${mentionTag(res.round.ids)} foi *aprovado(a)* por @${admin} — ${view.shortId(res.round)}${view.renderApprovalSummary(res.approval)}`,
    [res.round.ids.find(i => i.endsWith('@s.whatsapp.net')) || res.round.ids[0], actor.id]);
}

export default defineCommandContract({
  name: 'triagemaprovar', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: true,
  enabled: true, cooldown: 2, audit: true, publicName: 'Aprovar triagem',
  description: 'Aprova uma ficha de triagem do seu grupo. Só admins aprovam; o dono apenas analisa.',
  purpose: 'Marca a ficha como aprovada e avisa o membro no privado.',
  usage: '×triagemaprovar <ID ou #n> [repetir]', syntax: '×triagemaprovar <ID ou #n> [repetir]', examples: ['×triagemaprovar #42', '×triagemaprovar #42 repetir'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(handler)
});
