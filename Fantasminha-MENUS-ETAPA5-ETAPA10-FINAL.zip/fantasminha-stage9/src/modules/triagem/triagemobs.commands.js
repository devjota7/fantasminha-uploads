import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as service from './triagem.service.js';
import { guarded, actorOf, resolveOne, usage } from './triagem.commandKit.js';

async function handler(ctx) {
  const [query, ...rest] = ctx.args || [];
  const text = rest.join(' ').trim();
  if (!query || !text) return ctx.reply(usage('×triagemobs <ID ou #n> <texto da nota>'));
  const { rows, round } = resolveOne(ctx, query);
  if (!rows.length) return ctx.reply('🔎 Ficha não encontrada neste grupo.');
  if (!round) return ctx.reply('⚠️ Mais de uma ficha encontrada. Use o ID TRG-… ou o #número.');
  const res = await service.addNote(round.id, actorOf(ctx), text, buildDeps(ctx));
  return ctx.reply(res.ok ? `📝 Nota registrada na ficha #${res.round.n}.` : `⚠️ ${res.error}`);
}

export default defineCommandContract({
  name: 'triagemobs', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: true,
  enabled: true, cooldown: 2, audit: true, publicName: 'Nota na triagem',
  description: 'Adiciona uma nota interna a uma ficha (só acrescenta; nunca edita nem apaga).',
  purpose: 'Registra observações dos admins na ficha.',
  usage: '×triagemobs <ID ou #n> <texto>', syntax: '×triagemobs <ID ou #n> <texto>', examples: ['×triagemobs #42 conferir idade com o grupo'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(handler)
});
