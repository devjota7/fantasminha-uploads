/**
 * Manutenção periódica da Triagem (sem timers por rodada):
 *  - a cada tick: expira rodadas vencidas;
 *  - 1x por dia: saúde das conexões, fila parada, falhas repetidas de PV e aviso de retenção.
 * Só avisa; nunca apaga nem decide nada.
 */
import { STATUS, LIMITS } from './triagem.constants.js';
import * as repo from './triagem.repository.js';
import * as service from './triagem.service.js';
import * as network from './triagem.network.js';
import { nowOf, safe, ownerChatIds } from './triagem.util.js';
import { fmtDate } from './triagem.presenter.js';

async function notifyOwner(deps, text) {
  for (const chat of ownerChatIds()) await safe(() => deps.send.text(chat, text));
}

export async function runDaily(deps) {
  const now = nowOf(deps);
  const alerts = [];
  const cfgAll = repo.readConfig().groups;
  const groups = await network.fetchGroups(deps);

  // 1) saúde das conexões de cada grupo ativo
  for (const [groupId, cfg] of Object.entries(cfgAll)) {
    if (!cfg.enabled) continue;
    const bad = [];
    const ids = [...(cfg.judgeGroupId ? [cfg.judgeGroupId] : []), ...(cfg.approvedGroupIds || [])];
    for (const id of ids) { const h = network.healthOf(id, groups); if (!h.ok) bad.push(`${h.name || id} (${h.reason})`); }
    const own = network.healthOf(groupId, groups);
    if (!own.ok) bad.push(`${own.name || groupId} (${own.reason})`);
    if (bad.length) {
      alerts.push(`🔌 Grupo ${groupId}: conexão com problema → ${bad.join('; ')}`);
      if (own.ok) await safe(() => deps.send.text(groupId, `⚠️ *Triagem:* há grupos conectados com problema: ${bad.join('; ')}. Fichas voltam para este grupo enquanto isso. Revisem em ×triagem > Grupos.`));
      await repo.appendAudit({ action: 'health_alert', groupId, detail: bad.length }, now);
    }
  }

  // 2) fila parada (ficha aguardando julgamento há muito tempo)
  const stalled = repo.allRounds().filter(r => !r.isTest && r.status === STATUS.SUBMITTED && r.submittedAt && now - r.submittedAt > LIMITS.stalledHours * 3600_000);
  if (stalled.length) {
    alerts.push(`⏸️ Fila parada: ${stalled.length} ficha(s) aguardando julgamento há mais de ${LIMITS.stalledHours}h (mais antiga: ${fmtDate(Math.min(...stalled.map(r => r.submittedAt)))}).`);
    const perGroup = new Map();
    for (const r of stalled) perGroup.set(r.judgeGroupId || r.groupId, (perGroup.get(r.judgeGroupId || r.groupId) || 0) + 1);
    for (const [chat, n] of perGroup) await safe(() => deps.send.text(chat, `⏸️ *Triagem:* ${n} ficha(s) aguardando julgamento há mais de ${LIMITS.stalledHours}h. Use ×triagem > Fila.`));
  }

  // 3) falha repetida de PV nas últimas 24h
  const pvFails = repo.readAudit().filter(a => a.action === 'pv_failed' && a.at > now - LIMITS.dailyMs).length;
  if (pvFails >= LIMITS.pvFailAlertCount) alerts.push(`📵 ${pvFails} falhas de PV nas últimas 24h. O bot pode estar com problema para falar no privado.`);

  // 4) retenção (só avisa)
  const due = service.retentionDue(now);
  if (due.length) alerts.push(`🗓️ Retenção: ${due.length} ficha(s) passaram do prazo de ${repo.getGlobal().retentionDays} dia(s). Apague manualmente em ×triagemdono se quiser.`);

  if (alerts.length) await notifyOwner(deps, ['🕷️ *TRIAGEM — ALERTAS DO DIA*', '', ...alerts].join('\n'));
  await repo.updateGlobal(g => { g.lastDaily = now; return g; });
  return { alerts };
}

/** Tick horário: expira rodadas e, se passou 1 dia desde a última vez, roda a rotina diária. */
export async function tick(deps) {
  if (!repo.isGloballyEnabled() || repo.isEmergencyOff()) return { skipped: true };
  const now = nowOf(deps);
  await repo.sweepExpired(now);
  if (now - (repo.getGlobal().lastDaily || 0) >= LIMITS.dailyMs) return runDaily(deps);
  return { alerts: [] };
}

let timer = null;
export function start(buildDeps) {
  stop();
  const run = () => tick(buildDeps()).catch(err => console.error(`[TRIAGEM] manutenção: ${err.message}`));
  timer = setInterval(run, LIMITS.maintenanceTickMs);
  timer.unref?.();
  setTimeout(run, 60_000).unref?.();
  return true;
}
export function stop() { if (timer) clearInterval(timer); timer = null; }

export default { runDaily, tick, start, stop };
