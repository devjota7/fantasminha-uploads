import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as service from './triagem.service.js';
import * as panel from './triagem.panel.js';
import * as view from './triagem.presenter.js';
import { REJECT_REASONS } from './triagem.constants.js';
import { guarded, actorOf, resolveOne, usage } from './triagem.commandKit.js';
import { mentionTag } from './triagem.identity.js';

const yn = v => (/^(s|sim|1)$/i.test(v) ? true : /^(n|nao|não|2)$/i.test(v) ? false : null);

async function handler(ctx) {
  const [query, reason, retry, notify] = ctx.args || [];
  if (!query) return ctx.reply(usage('×triagemreprovar <ID ou #n> [motivo 1-5] [nova tentativa s/n] [avisar membro s/n]'));
  const { rows, round } = resolveOne(ctx, query);
  if (!rows.length) return ctx.reply('🔎 Ficha não encontrada neste grupo.');
  if (!round) return ctx.reply('⚠️ Mais de uma ficha encontrada. Use o ID TRG-… ou o #número.');
  const actor = actorOf(ctx);
  const deps = buildDeps(ctx);
  if (!service.canJudge(actor, round)) return ctx.reply(`⚠️ ${actor.isOwner ? 'O dono só analisa: quem reprova é o admin do grupo.' : 'Você não pode julgar esta ficha.'}`);

  const direct = reason !== undefined && REJECT_REASONS[reason] && yn(retry ?? '') !== null && yn(notify ?? '') !== null;
  if (!direct) return panel.startRejectFlow(ctx, round, deps);

  const res = await service.reject(round.id, actor, { reason: Number(reason), retry: yn(retry), notify: yn(notify) }, deps);
  if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
  if (res.test) return ctx.reply('🧪 Ficha de teste encerrada. Nada foi alterado para ninguém.');
  return deps.send.text(ctx.from, `🚫 ${view.shortId(res.round)} de @${mentionTag(res.round.ids)} foi *reprovada* por @${mentionTag([actor.id])}.`,
    [res.round.ids.find(i => i.endsWith('@s.whatsapp.net')) || res.round.ids[0], actor.id]);
}

export default defineCommandContract({
  name: 'triagemreprovar', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: true,
  enabled: true, cooldown: 2, audit: true, publicName: 'Reprovar triagem',
  description: 'Reprova uma ficha (guiado ou em linha única). Não escreve na blacklist.',
  purpose: 'Registra o motivo, define nova tentativa e avisa o membro. O dono vê a ficha de reprovação.',
  usage: '×triagemreprovar <ID ou #n> [motivo] [s/n] [s/n]', syntax: '×triagemreprovar <ID ou #n> [motivo 1-5] [nova tentativa s/n] [avisar s/n]',
  examples: ['×triagemreprovar #42', '×triagemreprovar #42 3 n n'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(handler)
});
