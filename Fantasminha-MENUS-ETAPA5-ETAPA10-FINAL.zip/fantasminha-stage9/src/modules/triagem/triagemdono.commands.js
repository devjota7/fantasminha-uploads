import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as panel from './triagem.panel.js';
import { guarded } from './triagem.commandKit.js';

export default defineCommandContract({
  name: 'triagemdono', aliases: [], category: 'dono', permission: Role.OWNER, ownerOnly: true,
  enabled: true, cooldown: 2, audit: true, publicName: 'Triagem (dono)',
  description: 'Painel do dono: fila global, reprovações, busca e interruptor de emergência. Somente leitura.',
  purpose: 'O dono analisa a triagem da rede sem aprovar nem reprovar.',
  usage: '×triagemdono', syntax: '×triagemdono', examples: ['×triagemdono'],
  authorization: { level: 'OWNER', ownerOnly: true },
  handler: guarded(async ctx => panel.openOwnerPanel(ctx, buildDeps(ctx)))
});
