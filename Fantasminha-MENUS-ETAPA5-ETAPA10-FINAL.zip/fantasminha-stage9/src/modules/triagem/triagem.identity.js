/**
 * Identidade canônica da Triagem. A mesma pessoa pode aparecer como JID
 * (...@s.whatsapp.net) ou LID (...@lid); guardamos todas as formas conhecidas
 * e comparamos por sobreposição, nunca por string solta.
 */
export function normalizeId(value) {
  let s = String(value ?? '').trim().toLowerCase();
  if (!s) return '';
  if (!s.includes('@')) {
    const digits = s.replace(/\D/g, '');
    return digits ? `${digits}@s.whatsapp.net` : '';
  }
  const [user, domain] = s.split('@');
  return `${user.split(':')[0]}@${domain}`;
}

export function collectIds(...values) {
  const out = [];
  for (const v of values.flat(Infinity)) {
    const n = normalizeId(v);
    if (n && !out.includes(n)) out.push(n);
  }
  return out;
}

export function idsOverlap(a = [], b = []) {
  const set = new Set(collectIds(a));
  return collectIds(b).some(x => set.has(x));
}

export function isLidId(id) { return String(id || '').endsWith('@lid'); }
export function isJidId(id) { return String(id || '').endsWith('@s.whatsapp.net'); }

export function canonicalKey(ids = []) {
  const list = collectIds(ids);
  return list.find(isLidId) || list.find(isJidId) || list[0] || '';
}

export function phoneFromIds(ids = []) {
  const jid = collectIds(ids).find(isJidId);
  return jid ? jid.split('@')[0] : '';
}

export function digitsOf(value) { return String(value ?? '').replace(/\D/g, ''); }

export function mentionTag(ids = []) {
  const jid = collectIds(ids).find(isJidId) || collectIds(ids)[0] || '';
  return jid.split('@')[0];
}

export function pickChatId(ids = [], pvChat = null) {
  if (pvChat) return pvChat;
  const list = collectIds(ids);
  return list.find(isJidId) || list[0] || null;
}

export default { normalizeId, collectIds, idsOverlap, canonicalKey, phoneFromIds, digitsOf, mentionTag, pickChatId };
