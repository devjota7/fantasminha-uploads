/** Textos da Triagem 2.0. Sem lógica de negócio. */
import { QUESTION_TYPES, REJECT_REASONS, STATUS, RETURNING_MODES, PHOTO_POLICIES } from './triagem.constants.js';
import { mentionTag } from './triagem.identity.js';

const STATUS_LABEL = Object.freeze({
  [STATUS.PENDING]: '⏳ Aguardando início',
  [STATUS.IN_PROGRESS]: '✍️ Respondendo',
  [STATUS.SUBMITTED]: '📨 Aguardando julgamento',
  [STATUS.APPROVED]: '✅ Aprovada',
  [STATUS.REJECTED]: '🚫 Reprovada',
  [STATUS.EXPIRED]: '⌛ Expirada',
  [STATUS.SUPERSEDED]: '♻️ Substituída',
  [STATUS.RELEASED]: '🔓 Liberada'
});
export const statusLabel = s => STATUS_LABEL[s] || s;

export function fmtDate(ms) {
  if (!ms) return '—';
  const d = new Date(ms - 3 * 3600_000); // horário de Brasília (UTC-3)
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getUTCDate())}/${p(d.getUTCMonth() + 1)}/${d.getUTCFullYear()} ${p(d.getUTCHours())}:${p(d.getUTCMinutes())}`;
}

export const shortId = round => `${round.id}${round.isTest ? '' : ` (#${round.n})`}`;

export function renderAnnouncement(round, { botNumber, hours, total }) {
  const link = botNumber ? `https://wa.me/${botNumber}?text=${encodeURIComponent(round.id)}` : null;
  const lines = [
    '🕷️ *NOVA TRIAGEM*',
    '',
    `Bem-vindo(a), @${mentionTag(round.ids)}!`,
    `Para liberar sua participação, responda ${total} pergunta(s) no privado do bot.`,
    `⏳ Prazo para começar: ${hours}h`,
    ''
  ];
  if (link) lines.push(`👉 Toque para iniciar:\n${link}`, '');
  lines.push(`🆔 ${shortId(round)}`);
  if (!link) lines.push('Envie esse código no privado do bot para começar.');
  return lines.join('\n');
}

export function renderIntro(round) {
  return [
    '🕷️ *TRIAGEM*',
    '',
    `Grupo: ${round.groupName || 'grupo'}`,
    `Perguntas: ${round.questions.length}`,
    'Responda uma de cada vez. Suas respostas serão analisadas por um admin do grupo.',
    '',
    '🔒 *Privacidade:* suas respostas (e fotos, se pedidas) ficam guardadas só para esta análise de entrada. Quem pode ver: os admins que julgam este grupo e o dono do bot.',
    'Para pedir a exclusão dos seus dados, fale com um admin do grupo ou com o dono: o bot não apaga fichas por conta própria nem a pedido de membros.',
    ''
  ].join('\n');
}

export function renderQuestion(q, index, total) {
  const lines = [`*Pergunta ${index + 1}/${total}*`, q.text];
  if (q.type === 'data') lines.push('_Envie no formato DD/MM/AAAA._');
  if (q.type === 'numero') lines.push('_Responda só com números._');
  if (q.type === 'simnao') lines.push('_Responda *sim* ou *não*._');
  if (q.type === 'foto') lines.push('_Envie uma foto._');
  if (q.type === 'escolha') lines.push(...(q.options || []).map((o, i) => `${i + 1}) ${o}`), '_Responda com o número da opção._');
  return lines.join('\n');
}

export function invalidHint(q) {
  const map = {
    data: '⚠️ Data inválida. Use DD/MM/AAAA, por exemplo 25/12/2000.',
    numero: '⚠️ Envie apenas um número.',
    simnao: '⚠️ Responda com *sim* ou *não*.',
    escolha: '⚠️ Escolha uma das opções pelo número.',
    foto: '⚠️ Preciso de uma *foto* nesta pergunta.',
    texto: '⚠️ Envie uma resposta em texto.'
  };
  return map[q.type] || map.texto;
}

export function renderSubmitted(round) {
  return `✅ *Triagem enviada!*\n\nSua ficha ${shortId(round)} foi encaminhada para análise. Aguarde a decisão dos admins no grupo.`;
}

const signalLine = s => `${s.icon} ${s.text}`;
const APPROVAL_LABEL = { added: '✅ adicionado(a)', invited: '📨 link de convite enviado', failed: '⚠️ falhou' };

export function renderFicha(round, signals = [], { viewer = 'admin', origin = false } = {}) {
  const head = [
    `📋 *FICHA ${shortId(round)}*${round.isTest ? ' — 🧪 TESTE' : ''}`,
    `${origin ? 'Origem: Grupo' : 'Grupo:'} ${round.groupName || round.groupId}`,
    ...(round.returning ? ['🔁 Já foi aprovado(a) aqui antes: ficha de atualização.'] : []),
    `Pessoa: @${mentionTag(round.ids)}${round.pushName ? ` (${round.pushName})` : ''}`,
    `Status: ${statusLabel(round.status)}`,
    `Criada: ${fmtDate(round.createdAt)} · Enviada: ${fmtDate(round.submittedAt)}`
  ];
  const sig = signals.length ? ['', '*Sinais* (apoio, não decidem):', ...signals.map(signalLine)] : ['', '*Sinais:* nenhum alerta.'];
  const ans = ['', '*Respostas:*'];
  round.questions.forEach((q, i) => {
    const a = (round.answers || []).find(x => x.qid === q.id);
    const shown = a ? (a.mediaFile ? '🖼️ [foto enviada]' : (a.text || '—')) : '— (sem resposta)';
    ans.push(`${i + 1}. ${q.text}\n   ➜ ${shown}`);
  });
  const notes = (round.notes || []).length
    ? ['', '*Notas internas:*', ...round.notes.map(n => `• ${fmtDate(n.at)} — ${n.text}`)] : [];
  const approval = round.approval?.results?.length
    ? ['', '*Grupos de aprovados:*', ...round.approval.results.map(x => `• ${x.name}: ${APPROVAL_LABEL[x.status] || x.status}${x.detail ? ` (${x.detail})` : ''}`)] : [];
  const decision = round.rejection
    ? ['', `*Reprovação:* ${REJECT_REASONS[round.rejection.reason] || 'Outro'} · nova tentativa: ${round.rejection.retry ? 'sim (7 dias)' : 'não'}`]
    : [];
  const foot = [];
  if (round.status === STATUS.SUBMITTED && !round.isTest && viewer === 'admin') {
    foot.push('', `✅ ×triagemaprovar #${round.n}`, `🚫 ×triagemreprovar #${round.n}`, `📝 ×triagemobs #${round.n} <texto>`);
  }
  if (viewer === 'owner') foot.push('', '_Visão do dono: somente leitura._');
  return [...head, ...sig, ...ans, ...notes, ...approval, ...decision, ...foot].join('\n');
}

export function renderRejectionFicha(round, blacklist) {
  const bl = blacklist ? (blacklist.grupo || blacklist.global ? 'sim' : 'não') : 'não verificado';
  return [
    `🚫 *REPROVAÇÃO ${shortId(round)}*`,
    `Grupo: ${round.groupName || round.groupId}`,
    `Pessoa: @${mentionTag(round.ids)}`,
    `Motivo: ${REJECT_REASONS[round.rejection?.reason] || 'Outro'}`,
    `Nova tentativa: ${round.rejection?.retry ? 'sim (7 dias)' : 'não'} · Membro avisado: ${round.rejection?.notified ? 'sim' : 'não'}`,
    `Decidido por: @${String(round.decidedBy || '').split('@')[0]} em ${fmtDate(round.decidedAt)}`,
    `Consta na blacklist atual: ${bl}`,
    '_A Triagem não escreve na blacklist. Se quiser banir, use o addblackglobal._'
  ].join('\n');
}

export function renderMemberApproved(round) {
  return `✅ *Triagem aprovada!*\n\nSua ficha ${shortId(round)} em *${round.groupName || 'grupo'}* foi aprovada pelos admins. Seja bem-vindo(a)!`;
}

export function renderMemberRejected(round) {
  const r = round.rejection || {};
  return [
    '🚫 *Triagem não aprovada*',
    '',
    `Sua ficha ${shortId(round)} em *${round.groupName || 'grupo'}* não foi aprovada.`,
    `Motivo: ${REJECT_REASONS[r.reason] || 'Outro'}`,
    r.retry ? 'Você pode tentar novamente em 7 dias.' : 'Neste momento não é possível tentar novamente.'
  ].join('\n');
}

export function renderInviteLink(groupName, link) {
  return `📨 O WhatsApp não permitiu adicionar você direto em *${groupName}*. Entre pelo link:\n${link}`;
}

export function renderApprovalSummary(results = []) {
  if (!results.length) return '';
  return ['', '*Grupos de aprovados:*', ...results.map(x => `• ${x.name}: ${APPROVAL_LABEL[x.status] || x.status}${x.detail ? ` (${x.detail})` : ''}`),
    results.some(x => x.status !== 'added') ? '_Para repetir os que falharam: ×triagemaprovar #n repetir_' : ''].filter(Boolean).join('\n');
}

export function renderCobranca(rounds, { botNumber, hours, total }) {
  const lines = ['🕷️ *COBRANÇA DE TRIAGEM*', `Responda ${total} pergunta(s) no privado do bot. ⏳ Prazo: ${hours}h`, ''];
  for (const r of rounds) {
    const link = botNumber ? ` — https://wa.me/${botNumber}?text=${encodeURIComponent(r.id)}` : '';
    lines.push(`• @${mentionTag(r.ids)} — 🆔 ${shortId(r)}${link}`);
  }
  if (!botNumber) lines.push('', 'Envie seu código no privado do bot.');
  return lines.join('\n');
}

export function renderReturning(round, { botNumber, hours, total, required }) {
  const link = botNumber ? `https://wa.me/${botNumber}?text=${encodeURIComponent(round.id)}` : null;
  const lines = ['🔁 *ATUALIZAÇÃO DE FICHA*', '', `Bem-vindo(a) de volta, @${mentionTag(round.ids)}!`,
    required ? `Neste grupo a atualização é *obrigatória*: responda ${total} pergunta(s) no privado do bot. ⏳ Prazo: ${hours}h`
      : `Se quiser, atualize sua ficha (${total} pergunta(s)) no privado do bot. É um pedido, não uma obrigação.`, ''];
  if (link) lines.push(`👉 ${link}`, '');
  lines.push(`🆔 ${shortId(round)}`);
  return lines.join('\n');
}

export function renderPvFailed(round) {
  return `⚠️ Não consegui falar com @${mentionTag(round.ids)} no privado (${shortId(round)}). A restrição foi liberada. Admins: confiram com a pessoa.`;
}

export function renderRestricted(round, { botNumber }) {
  const link = botNumber ? `https://wa.me/${botNumber}?text=${encodeURIComponent(round.id)}` : '';
  return `🕷️ @${mentionTag(round.ids)}, termine sua triagem para liberar o chat do grupo.${link ? `\n👉 ${link}` : `\nCódigo: ${round.id}`}`;
}

export function renderConnectionMap(map) {
  const mark = h => (h?.unknown ? '❔' : h?.ok ? '✅' : '⚠️');
  const lines = ['🗺️ *MAPA DE GRUPOS*', `📥 Entrada: ${map.entry.name}`, `   🆔 ${map.entry.fantId || 'FANTGRUP—'}`];
  lines.push(map.judge ? `⚖️ Julgamento: ${map.judge.name} ${mark(map.judge.health)}
   🆔 ${map.judge.fantId || 'FANTGRUP—'}${map.judge.health?.ok === false ? `
   ⚠️ ${map.judge.health.reason}` : ''}` : '⚖️ Julgamento: este mesmo grupo');
  if (map.approved.length) { lines.push('📚 Destinos dos aprovados:'); map.approved.forEach((g, i) => lines.push(`   ${i + 1}. ${g.name} ${mark(g.health)}
      🆔 ${g.fantId || 'FANTGRUP—'}${g.health?.ok === false ? `
      ⚠️ ${g.health.reason}` : ''}`)); }
  else lines.push('📚 Destinos dos aprovados: nenhum (o aprovado só recebe o aviso)');
  if (!map.checked) lines.push('_Não consegui consultar o WhatsApp agora; a saúde dos grupos não foi verificada._');
  return lines.join('\n');
}

export function renderStats(stats, { title = '📊 *ESTATÍSTICAS*', period = 'geral' } = {}) {
  const pct = n => (n === null ? '—' : `${Math.round(n * 100)}%`);
  const dur = ms => { if (ms === null) return '—'; const m = Math.round(ms / 60000); return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${m % 60}min`; };
  const lines = [title, `Período: ${period}`, '',
    `Fichas criadas: ${stats.total}`,
    `✅ Aprovadas: ${stats.approved} · 🚫 Reprovadas: ${stats.rejected}`,
    `📨 Aguardando julgamento: ${stats.submitted} · ✍️ Em andamento/pendentes: ${stats.open}`,
    `⌛ Expiradas: ${stats.expired} · ♻️ Substituídas: ${stats.superseded}`,
    `Taxa de aprovação: ${pct(stats.approvalRate)}`,
    `Tempo médio para responder: ${dur(stats.avgAnswerMs)}`,
    `Tempo médio até a decisão: ${dur(stats.avgDecisionMs)}`];
  const reasons = Object.entries(stats.reasons || {});
  if (reasons.length) { lines.push('', 'Motivos de reprovação:'); reasons.forEach(([k, v]) => lines.push(`• ${REJECT_REASONS[k] || 'Outro'}: ${v}`)); }
  return lines.join('\n');
}

export function renderHistory(list) {
  if (!list.length) return '_Nenhuma alteração registrada ainda._';
  return list.slice(0, 10).map((h, i) => `${i + 1}. ${fmtDate(h.at)} — ${h.config?.questions?.length ?? 0} pergunta(s), prazo ${h.config?.startHours ?? '?'}h — por @${String(h.by || 'sistema').split('@')[0]}`).join('\n');
}

export const returningModeLabel = m => RETURNING_MODES[m] || m;
export const photoPolicyLabel = p => PHOTO_POLICIES[p] || p;

export function questionTypeMenu() {
  return Object.values(QUESTION_TYPES).map((label, i) => `${i + 1}) ${label}`).join('\n');
}

export default { renderInviteLink, renderApprovalSummary, renderCobranca, renderReturning, renderPvFailed, renderRestricted, renderConnectionMap, renderStats, renderHistory, statusLabel, fmtDate, shortId, renderAnnouncement, renderIntro, renderQuestion, invalidHint, renderSubmitted, renderFicha, renderRejectionFicha, renderMemberApproved, renderMemberRejected, questionTypeMenu };
