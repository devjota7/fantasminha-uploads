import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as service from './triagem.service.js';
import { guarded, actorOf, resolveOne, usage } from './triagem.commandKit.js';

async function handler(ctx) {
  const deps = buildDeps(ctx);
  const query = (ctx.args || []).join(' ').trim() || (ctx.mentioned?.[0] || '');
  if (!query) {
    if (!ctx.isGroup) return ctx.reply(usage('×triagemficha <ID TRG-… | número com DDI>'));
    return ctx.reply(service.renderQueue(await service.listQueue({ groupId: ctx.from }, deps)));
  }
  const { rows, round } = resolveOne(ctx, query, { owner: !!ctx.isOwner });
  if (!rows.length) return ctx.reply('🔎 Nenhuma ficha encontrada.');
  if (!round) return ctx.reply(service.renderQueue(rows, { showGroup: !!ctx.isOwner, title: '🔎 *VÁRIAS FICHAS ENCONTRADAS*' }));
  const actor = actorOf(ctx);
  if (!service.canView(actor, round)) return ctx.reply('🚫 Você só pode abrir fichas do grupo onde é admin.');
  const viewer = service.canJudge(actor, round) ? 'admin' : 'owner';
  const ficha = service.buildFicha(round, { viewer });
  return service.deliverFicha(ctx.from, round, ficha, deps);
}

export default defineCommandContract({
  name: 'triagemficha', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: false,
  enabled: true, cooldown: 2, audit: true, publicName: 'Ficha da triagem',
  description: 'Abre a ficha de triagem por ID, #número, @menção ou número (dono: de qualquer lugar, só leitura).',
  purpose: 'Mostra respostas, sinais e notas de uma ficha de triagem.',
  usage: '×triagemficha <ID | #n | @pessoa | número>', syntax: '×triagemficha <ID | #n | @pessoa | número>',
  examples: ['×triagemficha #42', '×triagemficha TRG-A1B2C3D4'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(handler)
});
