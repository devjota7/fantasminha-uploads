import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as panel from './triagem.panel.js';
import { guarded } from './triagem.commandKit.js';

export default defineCommandContract({
  name: 'triagem', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: true,
  enabled: true, cooldown: 2, audit: true, publicName: 'Triagem de entrada',
  description: 'Painel da triagem de novos membros: perguntas, fila, ativação e teste.',
  purpose: 'Configura e acompanha a triagem de quem entra no grupo. O bot coleta e sinaliza; os admins decidem.',
  usage: '×triagem', syntax: '×triagem', examples: ['×triagem'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(async ctx => panel.openAdminPanel(ctx, buildDeps(ctx)))
});
