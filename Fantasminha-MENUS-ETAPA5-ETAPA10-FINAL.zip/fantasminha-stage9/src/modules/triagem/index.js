/**
 * API pública do módulo Triagem 2.0 (usada pelo pipeline, pelo connect.js e pelos comandos).
 * Desligada por padrão: nada acontece até um admin ativar a triagem no grupo.
 */
import { downloadReceivedImage } from '../../platform/media/receivedMedia.js';
import * as service from './triagem.service.js';
import * as panel from './triagem.panel.js';
import * as repo from './triagem.repository.js';
import * as network from './triagem.network.js';
import * as maintenance from './triagem.maintenance.js';
import { collectIds, idsOverlap } from './triagem.identity.js';
import { ID_PATTERN } from './triagem.constants.js';

function botNumberOf(botJid) { return String(botJid || '').split(':')[0].split('@')[0]; }

/** Ferramentas de grupo sobre o socket (a única parte que fala com o WhatsApp). */
function groupTools(raw) {
  if (!raw) return {};
  const botIds = () => collectIds(raw.user?.id, raw.user?.lid);
  return {
    fetchGroups: async () => {
      const all = await raw.groupFetchAllParticipating();
      return Object.values(all || {}).map(g => {
        const admins = (g.participants || []).filter(p => p.admin);
        const idsOf = p => [p.id, p.jid, p.phoneNumber, p.lid].filter(Boolean);
        return { id: g.id, name: g.subject || g.id, botAdmin: admins.some(p => idsOverlap(idsOf(p), botIds())), adminIds: admins.flatMap(idsOf) };
      });
    },
    addToGroup: async (groupId, jid) => {
      try {
        const res = await raw.groupParticipantsUpdate(groupId, [jid], 'add');
        const status = String(res?.[0]?.status || '');
        return status === '200' || status === '409' ? 'added' : 'invite_needed';
      } catch { return 'failed'; }
    },
    inviteLink: async groupId => {
      const code = await raw.groupInviteCode(groupId);
      return code ? `https://chat.whatsapp.com/${code}` : null;
    },
    deleteMessage: key => raw.sendMessage(key.remoteJid, { delete: key })
  };
}

export function buildDeps(ctx) {
  const raw = ctx?.sock || ctx?.socket;
  const sendRaw = (chat, content) => (raw?.sendMessage ? raw.sendMessage(chat, content) : ctx.sendMessage(chat, content));
  return {
    send: {
      text: (chat, text, mentions = []) => sendRaw(chat, { text, mentions }),
      image: (chat, buffer, caption = '', mentions = []) => sendRaw(chat, { image: buffer, caption, mentions }),
      document: (chat, buffer, fileName, mimetype = 'text/csv') => sendRaw(chat, { document: buffer, fileName, mimetype })
    },
    downloadImage: message => downloadReceivedImage(message),
    resolvePN: typeof ctx?.resolvePNForLID === 'function' ? lid => ctx.resolvePNForLID(lid) : undefined,
    botNumber: botNumberOf(ctx?.botJid || raw?.user?.id),
    ...groupTools(raw)
  };
}

export function buildSocketDeps(sock) {
  return {
    send: {
      text: (chat, text, mentions = []) => sock.sendMessage(chat, { text, mentions }),
      image: (chat, buffer, caption = '', mentions = []) => sock.sendMessage(chat, { image: buffer, caption, mentions }),
      document: (chat, buffer, fileName, mimetype = 'text/csv') => sock.sendMessage(chat, { document: buffer, fileName, mimetype })
    },
    downloadImage: message => downloadReceivedImage(message),
    botNumber: botNumberOf(sock?.user?.id),
    ...groupTools(sock)
  };
}

/** Gancho do connect.js: membro entrou no grupo. Nunca lança erro para o fluxo existente. */
export async function onTriagemMemberJoined(sock, { groupId, groupName, participants, pushNames }) {
  try {
    return await service.onMemberJoined({ groupId, groupName, participants, pushNames, botJid: sock?.user?.id }, buildSocketDeps(sock));
  } catch (error) {
    console.error(`[TRIAGEM] falha ao iniciar triagem: ${error.message}`);
    return { error: error.message };
  }
}

// O WhatsApp às vezes entrega a mesma mensagem duas vezes. Este gancho roda antes do
// dedupe geral do pipeline, então guarda os IDs que já tratou para não responder 2x.
const handledMessages = new Map();
const DEDUPE_TTL_MS = 10 * 60 * 1000;
function rememberHandled(id) {
  const now = Date.now();
  handledMessages.set(id, now);
  if (handledMessages.size > 2000) for (const [key, at] of handledMessages) if (now - at > DEDUPE_TTL_MS) handledMessages.delete(key);
}

/** Gancho do pipeline: sessões de painel (grupo/PV) e respostas do membro no PV. */
export async function handleTriagemInput(ctx) {
  if (!ctx || ctx.fromMe || !repo.isGloballyEnabled()) return { handled: false };
  const messageId = ctx.message?.key?.id || null;
  if (messageId && handledMessages.has(messageId)) return { handled: true, duplicate: true };
  const deps = buildDeps(ctx);
  let result = await panel.handleSessionInput(ctx, deps);
  if (!result.handled && !ctx.isPrivate && ctx.isGroup && !repo.isEmergencyOff()) result = await network.handleGroupMessage(ctx, deps);
  if (!result.handled && ctx.isPrivate) {
    const text = String(ctx.body || ctx.text || '').trim();
    if (!(ctx.prefix && text.startsWith(ctx.prefix) && !ID_PATTERN.test(text))) {
      result = await service.handlePrivateInput({
        sender: ctx.sender, senderAlternate: ctx.senderAlternate, senderOriginal: ctx.senderOriginal,
        chatId: ctx.from, text,
        hasImage: !!ctx.message?.message?.imageMessage,
        message: ctx.message?.message?.imageMessage || null
      }, deps);
    }
  }
  if (result?.handled && messageId) rememberHandled(messageId);
  return result || { handled: false };
}

/** Usado pelo gate de PV (antipv) para não bloquear quem está respondendo a triagem. */
export function isTriagemPrivateFlow(sender, body, extra = {}) {
  try {
    if (!repo.isGloballyEnabled()) return false;
    return service.hasOpenRoundForPrivateInput({ sender, senderAlternate: extra.senderAlternate, senderOriginal: extra.senderOriginal, chatId: extra.chatId, text: body });
  } catch { return false; }
}

export function isTriagemCode(text) { return ID_PATTERN.test(String(text || '').trim()); }

/** Gancho do connect.js (conexão aberta): inicia a manutenção periódica. Idempotente. */
export function startTriagemMaintenance(sock) {
  try { return maintenance.start(() => buildSocketDeps(sock)); } catch (error) { console.error(`[TRIAGEM] manutenção não iniciou: ${error.message}`); return false; }
}

export { service, panel, network, maintenance };
export default { startTriagemMaintenance, buildDeps, buildSocketDeps, onTriagemMemberJoined, handleTriagemInput, isTriagemPrivateFlow, isTriagemCode };
