/** Utilitários internos da Triagem (sem regra de negócio): tempo, envio seguro, mídia e espera. */
import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';
import { collectIds, isJidId } from './triagem.identity.js';

export const nowOf = deps => (typeof deps?.now === 'function' ? deps.now() : Date.now());
export const safe = async fn => { try { return await fn(); } catch { return null; } };
export const mentionJid = ids => collectIds(ids).find(isJidId) || collectIds(ids)[0];
export const sleepOf = deps => (typeof deps?.sleep === 'function' ? deps.sleep : ms => new Promise(r => setTimeout(r, ms)));

export function mediaRoot() { return process.env.TRIAGEM_MEDIA_DIR || path.join(config.root, 'data', 'triagem-media'); }

export function saveMedia(roundId, qid, buffer) {
  const rel = `${roundId}/${qid}.jpg`;
  const full = path.join(mediaRoot(), rel);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, buffer);
  return rel;
}

export function readMedia(rel) {
  const full = path.resolve(mediaRoot(), rel);
  if (!full.startsWith(path.resolve(mediaRoot()) + path.sep)) return null;
  try { return fs.readFileSync(full); } catch { return null; }
}

/** Apaga as fotos de uma rodada (pasta data/triagem-media/<ID>). Devolve quantas foram removidas. */
export function deleteRoundMedia(roundId) {
  const dir = path.resolve(mediaRoot(), String(roundId || ''));
  if (!String(roundId || '') || !dir.startsWith(path.resolve(mediaRoot()) + path.sep)) return 0;
  let n = 0;
  try { n = fs.readdirSync(dir).length; fs.rmSync(dir, { recursive: true, force: true }); } catch { /* sem fotos */ }
  return n;
}

/** Remove os arquivos de foto e marca as respostas (a ficha continua, sem a imagem). */
export function stripPhotos(round, label = '[foto removida]') {
  let removed = 0;
  for (const a of round.answers || []) {
    if (!a.mediaFile) continue;
    a.mediaFile = null; a.text = label; removed += 1;
  }
  if (removed) deleteRoundMedia(round.id);
  return removed;
}

export function ownerChatIds() {
  const digits = String(config.ownerNumber || '').replace(/\D/g, '');
  return digits ? [`${digits}@s.whatsapp.net`] : [];
}
