/**
 * Fase 2 — rede de grupos: conexão de grupos (julgamento e aprovados), saúde da conexão,
 * adição de aprovados (com link de convite como alternativa), cobrança em lote e restrição do pendente.
 *
 * Tudo chega por `deps` (nada de Baileys aqui):
 *   fetchGroups() -> [{ id, name, botAdmin, adminIds[] }]
 *   addToGroup(groupId, jid) -> 'added' | 'invite_needed' | 'failed'
 *   inviteLink(groupId) -> string|null
 *   deleteMessage(key), sleep(ms)
 */
import { STATUS, OPEN_STATUSES, LIMITS } from './triagem.constants.js';
import { collectIds, idsOverlap, pickChatId } from './triagem.identity.js';
import * as repo from './triagem.repository.js';
import * as view from './triagem.presenter.js';
import * as groupRegistry from '../../services/groupRegistry.js';
import { nowOf, safe, mentionJid, sleepOf } from './triagem.util.js';

const MAX_APPROVED_GROUPS = 5;

/* ---------------- consulta de grupos e saúde ---------------- */
export async function fetchGroups(deps) {
  if (typeof deps?.fetchGroups !== 'function') return null;
  const list = await safe(() => deps.fetchGroups());
  if (!Array.isArray(list)) return null;
  try {
    await groupRegistry.sync(list);
    const legacyIds = [
      ...Object.keys(repo.readConfig().groups || {}),
      ...repo.allRounds().flatMap(r => [r.groupId, r.judgeGroupId].filter(Boolean)),
      ...Object.values(repo.readConfig().groups || {}).flatMap(g => g.approvedGroupIds || [])
    ];
    await groupRegistry.migrateLegacyGroupIds(legacyIds);
  } catch (error) { console.error(`[GROUP_REGISTRY] sync/migração falhou: ${error.message}`); }
  return list;
}

export function healthOf(groupId, groups) {
  if (!groups) return { ok: true, unknown: true, reason: '' };
  const g = groups.find(x => x.id === groupId);
  if (!g) return { ok: false, reason: 'o bot não está mais no grupo', name: groupId };
  if (!g.botAdmin) return { ok: false, reason: 'o bot perdeu o admin', name: g.name || groupId };
  return { ok: true, name: g.name || groupId };
}

export async function groupHealth(groupId, deps) {
  return healthOf(groupId, await fetchGroups(deps));
}

/** Só aparece o que o admin pode usar: bot admin + o próprio admin também admin (dono vê todos). */
export async function listConnectable(actor, deps, { exclude = [] } = {}) {
  const groups = await fetchGroups(deps);
  if (!groups) return null;
  const mine = collectIds(actor?.ids || actor?.id);
  return groups
    .filter(g => g.botAdmin && !exclude.includes(g.id) && (actor?.isOwner || idsOverlap(mine, g.adminIds || [])))
    .map(g => ({ id: g.id, name: g.name || g.id, fantId: groupRegistry.getByGroupId(g.id)?.fantId || null }));
}

const nameIn = (id, groups) => groups?.find(g => g.id === id)?.name || id;

/* ---------------- resolução por ID Fantasminha ---------------- */
export async function resolveConnectableFantId(fantId, actor, deps) {
  const record = groupRegistry.getByFantId(fantId);
  if (!record) return { ok: false, error: 'ID de grupo não encontrado. Confira o FANTGRUP-... enviado.' };
  const allowed = await listConnectable(actor, deps);
  if (!allowed) return { ok: false, error: 'Não consegui consultar os grupos agora. Tente de novo em instantes.' };
  const target = allowed.find(g => g.id === record.groupId);
  if (!target) return { ok: false, error: 'Esse grupo não está disponível para esta conexão: o bot e você precisam ser admins nele.' };
  return { ok: true, target, record };
}

export async function setJudgeGroupByFantId(groupId, fantId, actor, deps, options = {}) {
  const resolved = await resolveConnectableFantId(fantId, actor, deps);
  if (!resolved.ok) return resolved;
  return setJudgeGroup(groupId, resolved.target.id, actor, deps, options);
}

export async function addApprovedGroupByFantId(groupId, fantId, actor, deps) {
  const resolved = await resolveConnectableFantId(fantId, actor, deps);
  if (!resolved.ok) return resolved;
  return addApprovedGroup(groupId, resolved.target.id, actor, deps);
}

/* ---------------- conexão dos grupos ---------------- */
export async function setJudgeGroup(groupId, judgeId, actor, deps, { confirm = false } = {}) {
  const now = nowOf(deps);
  if (!judgeId || judgeId === groupId) {
    const cfg = await repo.updateGroupConfig(groupId, g => { g.judgeGroupId = null; return g; }, now, { by: actor?.id });
    await repo.appendAudit({ action: 'judge_cleared', groupId, actor: actor?.id }, now);
    return { ok: true, config: cfg };
  }
  const allowed = await listConnectable(actor, deps);
  if (!allowed) return { ok: false, error: 'Não consegui consultar os grupos agora. Tente de novo em instantes.' };
  const target = allowed.find(g => g.id === judgeId);
  if (!target) return { ok: false, error: 'Esse grupo não está disponível: o bot e você precisam ser admins nele.' };
  const cfgAll = repo.readConfig().groups;
  const sharing = Object.entries(cfgAll).filter(([id, g]) => id !== groupId && g.judgeGroupId === judgeId).map(([id]) => id);
  if (sharing.length && !confirm) {
    const groups = await fetchGroups(deps);
    return { ok: false, needConfirm: true, shared: sharing.map(id => nameIn(id, groups)), target };
  }
  const cfg = await repo.updateGroupConfig(groupId, g => { g.judgeGroupId = judgeId; return g; }, now, { by: actor?.id });
  await repo.appendAudit({ action: 'judge_set', groupId, judgeGroupId: judgeId, actor: actor?.id }, now);
  return { ok: true, config: cfg, target };
}

export async function addApprovedGroup(groupId, targetId, actor, deps) {
  const now = nowOf(deps);
  if (targetId === groupId) return { ok: false, error: 'O destino dos aprovados não pode ser o próprio grupo de entrada.' };
  const allowed = await listConnectable(actor, deps);
  if (!allowed) return { ok: false, error: 'Não consegui consultar os grupos agora. Tente de novo em instantes.' };
  const target = allowed.find(g => g.id === targetId);
  if (!target) return { ok: false, error: 'Esse grupo não está disponível: o bot e você precisam ser admins nele.' };
  let error = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (g.approvedGroupIds.includes(targetId)) { error = 'Esse grupo já é um destino de aprovados.'; return g; }
    if (g.approvedGroupIds.length >= MAX_APPROVED_GROUPS) { error = `Limite de ${MAX_APPROVED_GROUPS} destinos atingido.`; return g; }
    g.approvedGroupIds = [...g.approvedGroupIds, targetId];
    return g;
  }, now, { by: actor?.id });
  if (error) return { ok: false, error };
  await repo.appendAudit({ action: 'approved_group_added', groupId, targetGroupId: targetId, actor: actor?.id }, now);
  return { ok: true, config: cfg, target };
}

export async function removeApprovedGroup(groupId, index, actor, deps) {
  const now = nowOf(deps);
  let removed = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (index >= 0 && index < g.approvedGroupIds.length) [removed] = g.approvedGroupIds.splice(index, 1);
    return g;
  }, now, { by: actor?.id });
  if (!removed) return { ok: false, error: 'Destino não encontrado.' };
  await repo.appendAudit({ action: 'approved_group_removed', groupId, targetGroupId: removed, actor: actor?.id }, now);
  return { ok: true, config: cfg, removed };
}

/** Mapa da conexão: entrada, julgamento e aprovados, cada um com status de saúde. */
export async function connectionMap(groupId, groupName, deps) {
  const cfg = repo.getGroupConfig(groupId);
  const groups = await fetchGroups(deps);
  const item = id => {
    const record = groupRegistry.getByGroupId(id);
    return { id, name: nameIn(id, groups), fantId: record?.fantId || null, health: healthOf(id, groups) };
  };
  const entryRecord = groupRegistry.getByGroupId(groupId);
  return {
    entry: { id: groupId, name: groupName || nameIn(groupId, groups), fantId: entryRecord?.fantId || null },
    judge: cfg.judgeGroupId ? item(cfg.judgeGroupId) : null,
    approved: cfg.approvedGroupIds.map(item),
    checked: !!groups
  };
}

/* ---------------- destino da ficha (julgamento) ---------------- */
export async function resolveJudgeTarget(round, deps) {
  const cfg = repo.getGroupConfig(round.groupId);
  const judge = cfg.judgeGroupId;
  if (!judge || judge === round.groupId) return { chatId: round.groupId, judgeGroupId: null };
  const h = await groupHealth(judge, deps);
  if (h.ok) return { chatId: judge, judgeGroupId: judge };
  return { chatId: round.groupId, judgeGroupId: null, fellBack: true, reason: h.reason, judgeName: h.name };
}

/* ---------------- aprovação: adicionar aos grupos permanentes ---------------- */
async function addOne(round, gid, groups, deps) {
  const info = groups?.find(g => g.id === gid);
  const name = info?.name || gid;
  const h = healthOf(gid, groups);
  if (!h.ok) return { groupId: gid, name, status: 'failed', detail: h.reason };
  const outcome = await safe(() => deps.addToGroup?.(gid, mentionJid(round.ids)));
  if (outcome === 'added') return { groupId: gid, name, status: 'added' };
  const link = await safe(() => deps.inviteLink?.(gid));
  if (!link) return { groupId: gid, name, status: 'failed', detail: 'o WhatsApp recusou e não consegui gerar o link' };
  const sent = await safe(() => deps.send.text(pickChatId(round.ids, round.pvChat), view.renderInviteLink(name, link)));
  return sent === null ? { groupId: gid, name, status: 'failed', detail: 'não consegui enviar o link no PV' } : { groupId: gid, name, status: 'invited' };
}

export async function finalizeApproval(round, deps, { only = null } = {}) {
  const now = nowOf(deps);
  const cfg = repo.getGroupConfig(round.groupId);
  const targets = (only || cfg.approvedGroupIds).filter(Boolean);
  if (!targets.length) return { results: [] };
  const groups = await fetchGroups(deps);
  const results = [];
  for (const gid of targets) results.push(await addOne(round, gid, groups, deps));
  await repo.updateRound(round.id, r => {
    const prev = (r.approval?.results || []).filter(x => !targets.includes(x.groupId));
    r.approval = { at: now, results: [...prev, ...results] };
    return r;
  });
  await repo.appendAudit({ action: 'approval_finalized', roundId: round.id, groupId: round.groupId, results: results.map(x => `${x.status}`).join(',') }, now);
  return { results };
}

export async function retryApproval(round, deps) {
  const failed = (round.approval?.results || []).filter(x => x.status !== 'added').map(x => x.groupId);
  if (!failed.length) return { results: [], nothing: true };
  return finalizeApproval(round, deps, { only: failed });
}

/* ---------------- cobrança em lote ---------------- */
const COBRAVEL = [STATUS.PENDING, STATUS.IN_PROGRESS, STATUS.EXPIRED];

export function previewCobrar(groupId, now = Date.now()) {
  const rounds = repo.allRounds().filter(r => r.groupId === groupId && !r.isTest);
  const since = now - LIMITS.cobrarLookbackDays * 86400_000;
  return rounds.filter(r =>
    COBRAVEL.includes(r.status) && !r.optional && r.createdAt >= since
    && !rounds.some(o => o.id !== r.id && o.createdAt > r.createdAt && idsOverlap(o.ids, r.ids))
  ).sort((a, b) => a.createdAt - b.createdAt);
}

export function chargedLastHour(now = Date.now()) {
  return repo.readAudit().filter(a => a.action === 'round_charged' && a.at > now - 3600_000).length;
}

export async function cobrar(groupId, groupName, actor, deps) {
  const now = nowOf(deps);
  const cfg = repo.getGroupConfig(groupId);
  if (!cfg.enabled || !cfg.questions.length) return { ok: false, error: 'A triagem está desativada neste grupo.' };
  const rows = previewCobrar(groupId, now);
  if (!rows.length) return { ok: true, charged: 0, remaining: 0, total: 0, empty: true };
  const room = Math.max(0, LIMITS.cobrarMaxPerHour - chargedLastHour(now));
  const batchRows = rows.slice(0, room);
  const fresh = [];
  for (const old of batchRows) {
    await repo.updateRound(old.id, r => { r.status = STATUS.SUPERSEDED; r.decidedAt = now; return r; });
    const { round } = await repo.createRound({
      groupId, groupName, ids: old.ids, pushName: old.pushName, questions: cfg.questions,
      expiresAt: now + cfg.startHours * 3600_000, extra: { chargedFrom: old.id }
    }, now);
    await repo.updateRound(old.id, r => { r.supersededBy = round.id; return r; });
    await repo.appendAudit({ action: 'round_charged', roundId: round.id, previousId: old.id, groupId, actor: actor?.id }, now);
    fresh.push(round);
  }
  const sleep = sleepOf(deps);
  for (let i = 0; i < fresh.length; i += LIMITS.cobrarBatch) {
    const chunk = fresh.slice(i, i + LIMITS.cobrarBatch);
    await safe(() => deps.send.text(groupId, view.renderCobranca(chunk, { botNumber: deps.botNumber, hours: cfg.startHours, total: cfg.questions.length }), chunk.map(r => mentionJid(r.ids))));
    if (i + LIMITS.cobrarBatch < fresh.length) await sleep(LIMITS.cobrarDelayMs);
  }
  return { ok: true, charged: fresh.length, remaining: rows.length - fresh.length, total: rows.length, rounds: fresh };
}

/* ---------------- restrição do pendente ---------------- */
export async function liftRestriction(round, reason, deps) {
  const now = nowOf(deps);
  await repo.updateRound(round.id, r => { r.restrictionLifted = true; r.pvFailed = reason === 'pv_failed' ? true : r.pvFailed; return r; });
  await repo.appendAudit({ action: reason === 'pv_failed' ? 'pv_failed' : 'restriction_lifted', roundId: round.id, groupId: round.groupId, actor: 'bot' }, now);
  if (reason === 'pv_failed') {
    await safe(() => deps.send.text(round.groupId, view.renderPvFailed(round), [mentionJid(round.ids)]));
  }
}

/** Mensagem de grupo de quem está com triagem aberta: apaga (se a restrição estiver ligada) e lembra do link. */
export async function handleGroupMessage(ctx, deps) {
  const now = nowOf(deps);
  const groupId = ctx.from;
  const cfg = repo.getGroupConfig(groupId);
  if (!cfg.enabled || !cfg.restrictPending) return { handled: false };
  if (ctx.isGroupAdmin || ctx.isOwner) return { handled: false };
  const ids = collectIds(ctx.sender, ctx.senderAlternate, ctx.senderOriginal);
  if (!ids.length) return { handled: false };
  const round = repo.openRoundsForIds(ids).find(r =>
    r.groupId === groupId && !r.isTest && !r.optional && !r.restrictionLifted
    && !(r.status === STATUS.PENDING && r.expiresAt && r.expiresAt < now));
  if (!round) return { handled: false };
  const key = ctx.message?.key;
  const deleted = key ? await safe(() => deps.deleteMessage?.(key)) : null;
  if (!round.lastReminderAt || now - round.lastReminderAt > LIMITS.reminderMs) {
    await repo.updateRound(round.id, r => { r.lastReminderAt = now; return r; });
    await safe(() => deps.send.text(groupId, view.renderRestricted(round, { botNumber: deps.botNumber }), [mentionJid(round.ids)]));
  }
  return { handled: true, restricted: true, deleted: deleted !== null };
}

export default {
  fetchGroups, healthOf, groupHealth, listConnectable, resolveConnectableFantId, setJudgeGroupByFantId, addApprovedGroupByFantId, setJudgeGroup, addApprovedGroup, removeApprovedGroup,
  connectionMap, resolveJudgeTarget, finalizeApproval, retryApproval, previewCobrar, chargedLastHour, cobrar,
  liftRestriction, handleGroupMessage
};
