/** Fase 3 — estatísticas por período e exportação de relatórios (CSV sem respostas nem fotos). */
import { STATUS, STATS_PERIODS } from './triagem.constants.js';
import { phoneFromIds } from './triagem.identity.js';
import { fmtDate } from './triagem.presenter.js';

export function periodSince(key, now = Date.now()) {
  const p = STATS_PERIODS[key];
  if (!p) return null;
  return { label: p.label, since: p.days ? now - p.days * 86400_000 : 0 };
}

const avg = list => (list.length ? list.reduce((a, b) => a + b, 0) / list.length : null);

export function computeStats(rounds, { since = 0 } = {}) {
  const rows = rounds.filter(r => !r.isTest && r.createdAt >= since);
  const count = s => rows.filter(r => r.status === s).length;
  const approved = count(STATUS.APPROVED);
  const rejected = count(STATUS.REJECTED);
  const judged = approved + rejected;
  const reasons = {};
  for (const r of rows.filter(x => x.status === STATUS.REJECTED)) { const k = r.rejection?.reason ?? 5; reasons[k] = (reasons[k] || 0) + 1; }
  return {
    total: rows.length, approved, rejected,
    submitted: count(STATUS.SUBMITTED),
    open: count(STATUS.PENDING) + count(STATUS.IN_PROGRESS),
    expired: count(STATUS.EXPIRED), superseded: count(STATUS.SUPERSEDED),
    approvalRate: judged ? approved / judged : null,
    avgAnswerMs: avg(rows.filter(r => r.startedAt && r.submittedAt).map(r => r.submittedAt - r.startedAt)),
    avgDecisionMs: avg(rows.filter(r => r.submittedAt && r.decidedAt && [STATUS.APPROVED, STATUS.REJECTED].includes(r.status)).map(r => r.decidedAt - r.submittedAt)),
    reasons
  };
}

const csvCell = v => {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = `'${s}`; // evita injeção de fórmula em planilhas
  return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const mask = ids => { const p = phoneFromIds(ids); return p ? `…${p.slice(-4)}` : ''; };

/** Relatório sem dados pessoais sensíveis: sem respostas, fotos, notas nem número completo. */
export function toCsv(rounds, { since = 0 } = {}) {
  const head = ['id', 'numero', 'grupo', 'status', 'criada', 'enviada', 'decidida', 'motivo_reprovacao', 'nova_tentativa', 'pessoa_final'];
  const rows = rounds.filter(r => !r.isTest && r.createdAt >= since).sort((a, b) => a.createdAt - b.createdAt).map(r => [
    r.id, r.n, r.groupName || r.groupId, r.status, fmtDate(r.createdAt), fmtDate(r.submittedAt), fmtDate(r.decidedAt),
    r.rejection?.reason ?? '', r.rejection ? (r.rejection.retry ? 'sim' : 'não') : '', mask(r.ids)
  ]);
  return [head, ...rows].map(row => row.map(csvCell).join(',')).join('\n');
}

export default { periodSince, computeStats, toCsv };
