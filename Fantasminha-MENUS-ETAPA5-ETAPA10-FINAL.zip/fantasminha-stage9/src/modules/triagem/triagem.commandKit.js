/** Utilitários compartilhados pelos comandos da Triagem (não é um arquivo de comando). */
import { collectIds } from './triagem.identity.js';
import { ID_PATTERN } from './triagem.constants.js';
import * as service from './triagem.service.js';
import * as repo from './triagem.repository.js';

/** Envolve o handler: com TRIAGEM_ENABLED≠true o comando só avisa que a Triagem está desligada. */
export const guarded = handler => async ctx => (repo.isGloballyEnabled()
  ? handler(ctx)
  : ctx.reply('🔴 A Triagem está desligada neste bot (TRIAGEM_ENABLED). Peça ao dono para ativá-la.'));

export function actorOf(ctx) {
  return { id: collectIds(ctx.sender)[0] || String(ctx.sender || ''), ids: collectIds(ctx.sender, ctx.senderAlternate, ctx.senderOriginal), isOwner: !!ctx.isOwner, isGroupAdmin: !!ctx.isGroupAdmin, chatId: ctx.from };
}

/** Resolve UMA ficha a partir do primeiro argumento (ID, #n, @menção ou número). */
export function resolveOne(ctx, query, { owner = false } = {}) {
  const idQuery = ID_PATTERN.test(String(query || '').trim());
  const groupId = owner && (idQuery || !ctx.isGroup) ? null : (ctx.isGroup ? ctx.from : null);
  const rows = service.findRounds(query, { groupId, mentioned: ctx.mentioned || [] });
  return { rows, round: rows.length === 1 ? rows[0] : null };
}

export const usage = text => `ℹ️ Uso: ${text}`;
