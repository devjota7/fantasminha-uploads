/**
 * Sinais da ficha: apoio visual para o admin, NUNCA decidem nada.
 * Para o admin, todo sinal usa apenas dados do PRÓPRIO grupo.
 * Cruzamento entre grupos é exclusivo do dono (viewer === 'owner').
 */
import { LIMITS, STATUS, REJECT_REASONS } from './triagem.constants.js';
import { phoneFromIds } from './triagem.identity.js';

export function parseBirthDate(text) {
  const m = String(text ?? '').trim().match(/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})$/);
  if (!m) return null;
  const d = Number(m[1]), mo = Number(m[2]), y = Number(m[3]);
  const date = new Date(Date.UTC(y, mo - 1, d));
  if (date.getUTCFullYear() !== y || date.getUTCMonth() !== mo - 1 || date.getUTCDate() !== d) return null;
  return { d, mo, y, iso: `${y}-${String(mo).padStart(2, '0')}-${String(d).padStart(2, '0')}` };
}

export function ageFromIso(iso, now = Date.now()) {
  const m = String(iso ?? '').match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (!m) return null;
  const today = new Date(now);
  let age = today.getUTCFullYear() - Number(m[1]);
  const before = (today.getUTCMonth() + 1) < Number(m[2]) || ((today.getUTCMonth() + 1) === Number(m[2]) && today.getUTCDate() < Number(m[3]));
  if (before) age -= 1;
  return age;
}

const norm = v => String(v ?? '').toLowerCase().replace(/\s+/g, ' ').trim();

function fmtDuration(ms) {
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  return m < 60 ? `${m}min ${s % 60}s` : `${Math.floor(m / 60)}h ${m % 60}min`;
}

/**
 * @param {object} round rodada
 * @param {{rounds?:object[], blacklist?:object, viewer?:'admin'|'owner', now?:number}} opts
 */
export function computeSignals(round, { rounds = [], blacklist = null, viewer = 'admin', now = Date.now() } = {}) {
  const signals = [];
  const others = rounds.filter(r => r.id !== round.id && !r.isTest);
  const samePerson = r => r.ids?.some(id => round.ids?.includes(id));

  // 🔁 rodadas anteriores NESTE grupo
  const prev = others.filter(r => r.groupId === round.groupId && samePerson(r) && r.createdAt < round.createdAt);
  if (prev.length) {
    const lastRej = prev.filter(r => r.status === STATUS.REJECTED).sort((a, b) => b.decidedAt - a.decidedAt)[0];
    const extra = lastRej ? ` · última reprovação: ${REJECT_REASONS[lastRej.rejection?.reason] || 'sem motivo'}` : '';
    signals.push({ key: 'previous', icon: '🔁', level: lastRej ? 'warn' : 'info', text: `${prev.length} rodada(s) anterior(es) neste grupo${extra}` });
  }

  // ⚫ blacklist (somente leitura)
  if (blacklist) {
    const where = [];
    if (blacklist.grupo) where.push(`grupo${blacklist.motivoGrupo ? ` (${blacklist.motivoGrupo})` : ''}`);
    if (blacklist.global) where.push(`global${blacklist.motivoGlobal ? ` (${blacklist.motivoGlobal})` : ''}`);
    if (where.length) signals.push({ key: 'blacklist', icon: '⚫', level: 'alert', text: `Consta na blacklist: ${where.join(' e ')}` });
  }

  // ✂️ respostas vazias/curtas e idênticas (mesmo grupo)
  const textAnswers = (round.answers || []).filter(a => a.type === 'texto');
  const tooShort = textAnswers.filter(a => norm(a.text).length <= LIMITS.shortAnswerChars).length;
  if (tooShort) signals.push({ key: 'short', icon: '✂️', level: 'warn', text: `${tooShort} resposta(s) de texto muito curta(s)` });
  const mine = new Set(textAnswers.map(a => norm(a.text)).filter(t => t.length >= 6));
  if (mine.size) {
    const dupOf = others.find(r => r.groupId === round.groupId && !samePerson(r)
      && (r.answers || []).some(a => a.type === 'texto' && mine.has(norm(a.text))));
    if (dupOf) signals.push({ key: 'identical', icon: '✂️', level: 'warn', text: `Resposta idêntica à da ficha #${dupOf.n} deste grupo` });
  }

  // ⏱️ tempo
  if (round.startedAt && round.submittedAt) {
    const total = round.submittedAt - round.startedAt;
    const count = Math.max(1, (round.answers || []).length);
    const fast = total / count < LIMITS.tooFastMsPerQuestion;
    signals.push({ key: 'time', icon: '⏱️', level: fast ? 'warn' : 'info', text: `Respondeu em ${fmtDuration(total)}${fast ? ' (rápido demais)' : ''}` });
  }

  // 🎂 idade
  const birth = (round.answers || []).find(a => a.type === 'data' && a.value);
  if (birth) {
    const age = ageFromIso(birth.value, now);
    if (age !== null) signals.push({ key: 'age', icon: '🎂', level: age < 18 ? 'alert' : 'info', text: `${age} anos${age < 18 ? ' — MENOR DE 18' : ''}` });
  }

  // ☎️ DDI
  const phone = phoneFromIds(round.ids);
  if (phone) signals.push({ key: 'ddi', icon: '☎️', level: 'info', text: phone.startsWith('55') ? 'DDI +55 (Brasil)' : `DDI +${phone.slice(0, 2)}… (fora do +55)` });

  // 🖼️ foto
  const photoQs = (round.questions || []).filter(q => q.type === 'foto');
  if (photoQs.length) {
    const missing = photoQs.filter(q => !(round.answers || []).some(a => a.qid === q.id && a.mediaFile)).length;
    if (missing) signals.push({ key: 'photo', icon: '🖼️', level: 'warn', text: `${missing} foto(s) ausente(s) ou não baixada(s)` });
  }

  if (round.identityVerified === false) {
    signals.push({ key: 'identity', icon: '⚠️', level: 'warn', text: 'Identidade do PV não confirmada (confira se é a mesma pessoa)' });
  }

  // ✅ cruzamento entre grupos: SOMENTE DONO
  if (viewer === 'owner') {
    const elsewhere = others.filter(r => r.groupId !== round.groupId && samePerson(r));
    const approved = elsewhere.filter(r => r.status === STATUS.APPROVED);
    const rejected = elsewhere.filter(r => r.status === STATUS.REJECTED);
    if (mine.size) {
      const dupElsewhere = others.find(r => r.groupId !== round.groupId && !samePerson(r)
        && (r.answers || []).some(a => a.type === 'texto' && mine.has(norm(a.text))));
      if (dupElsewhere) signals.push({ key: 'x-identical', icon: '✂️', level: 'warn', text: `Resposta idêntica à de uma ficha de outro grupo (${dupElsewhere.groupName || dupElsewhere.groupId} #${dupElsewhere.n}) (visão do dono)` });
    }
    if (approved.length) signals.push({ key: 'x-approved', icon: '✅', level: 'info', text: `Aprovado em ${approved.length} outro(s) grupo(s) (visão do dono)` });
    if (rejected.length) signals.push({ key: 'x-rejected', icon: '🚫', level: 'warn', text: `Reprovado em ${rejected.length} outro(s) grupo(s) (visão do dono)` });
  }
  return signals;
}

export default { computeSignals, parseBirthDate, ageFromIso };
