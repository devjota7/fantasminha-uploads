/** Constantes da Triagem 2.0 (redesenho). Nada aqui vem da Triagem 1.0. */
export const STATUS = Object.freeze({
  PENDING: 'pending',
  IN_PROGRESS: 'in_progress',
  SUBMITTED: 'submitted',
  APPROVED: 'approved',
  REJECTED: 'rejected',
  EXPIRED: 'expired',
  SUPERSEDED: 'superseded',
  RELEASED: 'released'
});

export const OPEN_STATUSES = Object.freeze([STATUS.PENDING, STATUS.IN_PROGRESS]);

export const QUESTION_TYPES = Object.freeze({
  texto: 'Texto',
  data: 'Data de nascimento',
  numero: 'Número',
  simnao: 'Sim/Não',
  escolha: 'Escolha',
  foto: 'Foto'
});

export const REJECT_REASONS = Object.freeze({
  1: 'Ficha incompleta',
  2: 'Idade',
  3: 'Conta suspeita',
  4: 'Fora do perfil',
  5: 'Outro'
});

export const LIMITS = Object.freeze({
  maxQuestions: 20,
  maxQuestionLength: 300,
  maxAnswerLength: 600,
  maxOptions: 10,
  defaultStartHours: 24,
  minHours: 1,
  maxHours: 168,
  idleHours: 24,
  sessionMs: 30 * 60 * 1000,
  auditMax: 2000,
  tooFastMsPerQuestion: 2500,
  shortAnswerChars: 2,
  retryDays: 7,
  queueLines: 15,
  historyMax: 20,
  cobrarMaxPerHour: 30,
  cobrarBatch: 5,
  cobrarDelayMs: 3000,
  cobrarLookbackDays: 30,
  reminderMs: 10 * 60 * 1000,
  stalledHours: 24,
  pvFailAlertCount: 3,
  dailyMs: 24 * 3600_000,
  maintenanceTickMs: 3600_000,
  templatesMax: 30
});

export const RETURNING_MODES = Object.freeze({ request: 'pedido', required: 'obrigatório' });
export const PHOTO_POLICIES = Object.freeze({ keep: 'guardar', delete_on_decision: 'apagar após julgamento' });
export const STATS_PERIODS = Object.freeze({ 1: { label: 'hoje', days: 1 }, 2: { label: '7 dias', days: 7 }, 3: { label: '30 dias', days: 30 }, 4: { label: 'geral', days: 0 } });

export const ID_PATTERN = /^TRG-[A-Z0-9]{8}$/i;

export const COLLECTIONS = Object.freeze({
  config: 'triagem_config',
  rounds: 'triagem_rounds',
  audit: 'triagem_audit'
});
