/**
 * Painéis conversacionais da Triagem (admin, dono e fluxo de reprovação).
 * Sessões vivem em memória, expiram em 30 min, e 9 volta / 0 cancela em toda tela.
 * Mensagens que começam com o prefixo de comando cancelam a sessão.
 */
import { LIMITS, QUESTION_TYPES, REJECT_REASONS, STATUS, STATS_PERIODS, RETURNING_MODES, PHOTO_POLICIES } from './triagem.constants.js';
import { collectIds } from './triagem.identity.js';
import * as repo from './triagem.repository.js';
import * as service from './triagem.service.js';
import * as view from './triagem.presenter.js';
import * as groupRegistry from '../../services/groupRegistry.js';

const sessions = new Map();
const TYPE_KEYS = Object.keys(QUESTION_TYPES);
const nowOf = deps => (typeof deps?.now === 'function' ? deps.now() : Date.now());
const keyOf = ctx => `${ctx.from}|${collectIds(ctx.sender)[0] || ctx.sender}`;

export function hasSession(ctx) { return sessions.has(keyOf(ctx)); }
export function clearSessions() { sessions.clear(); }

function open(ctx, deps, session) {
  sessions.set(keyOf(ctx), { ...session, expires: nowOf(deps) + LIMITS.sessionMs });
}
const close = ctx => sessions.delete(keyOf(ctx));
const actorOf = ctx => ({ id: collectIds(ctx.sender)[0] || ctx.sender, ids: collectIds(ctx.sender, ctx.senderAlternate, ctx.senderOriginal), isOwner: !!ctx.isOwner, isGroupAdmin: !!ctx.isGroupAdmin, chatId: ctx.from });
const NAV = '\n\n9️⃣ Voltar · 0️⃣ Cancelar';

/* ---------------- telas do admin ---------------- */
const onoff = v => (v ? '🟢 ligada' : '⚪ desligada');
const periodMenu = () => Object.entries(STATS_PERIODS).map(([k, p]) => `${k}️⃣ ${p.label}`).join('\n');

async function mainText(ctx, deps) {
  const groupId = ctx.from;
  const cfg = service.getGroupConfig(groupId);
  const queue = await service.listQueue({ groupId }, deps);
  return [
    '🕷️ *TRIAGEM — PAINEL*',
    `Grupo: ${ctx.groupName || 'este grupo'}`,
    `Status: ${cfg.enabled ? '🟢 Ativa' : '🔴 Desativada'}`,
    `Perguntas: ${cfg.questions.length} · Prazo para iniciar: ${cfg.startHours}h`,
    `Na fila: ${queue.length}`,
    '',
    '1️⃣ Configuração',
    '2️⃣ Perguntas',
    '3️⃣ Grupos',
    '4️⃣ Fila',
    '5️⃣ Estatísticas',
    '0️⃣ Cancelar'
  ].join('\n');
}

function configText(cfg) {
  return ['⚙️ *CONFIGURAÇÃO*', `Status: ${cfg.enabled ? '🟢 Ativa' : '🔴 Desativada'}`, `Prazo para iniciar: ${cfg.startHours}h`,
    `Restrição do pendente: ${onoff(cfg.restrictPending)}`, `Aprovado que volta: ${RETURNING_MODES[cfg.returningMode] || cfg.returningMode}`, '',
    `1️⃣ ${cfg.enabled ? 'Desativar' : 'Ativar'} triagem`, '2️⃣ Alterar prazo', '3️⃣ Ligar/desligar restrição do pendente', '4️⃣ Aprovado que volta: pedido ↔ obrigatório',
    '5️⃣ Testar triagem', '6️⃣ Histórico e restaurar', NAV.trim()].join('\n');
}

function questionsText(cfg) {
  const list = cfg.questions.length
    ? cfg.questions.map((q, i) => `${i + 1}. [${QUESTION_TYPES[q.type]}] ${q.text}`).join('\n')
    : '_Nenhuma pergunta cadastrada._';
  return ['❓ *PERGUNTAS*', list, '', '1️⃣ Adicionar', '2️⃣ Remover', '3️⃣ Usar modelo da rede', NAV.trim()].join('\n');
}

const groupsMenu = [
  '1️⃣ 🔗 Conectar julgamento',
  '2️⃣ 📚 Conectar destino de aprovados',
  '3️⃣ 🔌 Desconectar julgamento',
  '4️⃣ 🗑️ Remover destino de aprovados',
  '5️⃣ 🩺 Verificar saúde',
].join('\n');

const groupError = (title, detail, hint = '') => [
  `❌ *${title}*`,
  detail ? `\n${detail}` : '',
  hint ? `\n💡 ${hint}` : '',
  NAV
].join('');

const groupSuccess = (title, detail = '') => [
  `✅ *${title}*`,
  detail ? `\n${detail}` : ''
].join('');

async function groupsScreen(ctx, deps) {
  const map = await service.network.connectionMap(ctx.from, ctx.groupName, deps);
  return `🕷️ *TRIAGEM · GRUPOS*\n\n${view.renderConnectionMap(map)}\n\n${groupsMenu}${NAV}`;
}

export async function openAdminPanel(ctx, deps) {
  open(ctx, deps, { kind: 'admin', step: 'main', data: {} });
  return ctx.reply(await mainText(ctx, deps));
}

async function showMain(ctx, deps, s) { s.step = 'main'; s.data = {}; return ctx.reply(await mainText(ctx, deps)); }

const numbered = list => list.map((g, i) => `${i + 1}. ${g.name}`).join('\n');
const yesNo = v => (/^(1|s|sim)$/i.test(v) ? true : /^(2|n|nao|não)$/i.test(v) ? false : null);

async function adminStep(ctx, deps, s, text) {
  const groupId = ctx.from;
  const actor = actorOf(ctx);
  if (text === '0') { close(ctx); return ctx.reply('❌ Painel da triagem cancelado.'); }
  if (text === '9' && s.step !== 'main') {
    if (['history_confirm'].includes(s.step)) { s.step = 'history'; }
    else if (['judge_id', 'judge_confirm', 'appr_id', 'appr_remove'].includes(s.step)) { s.step = 'groups'; return ctx.reply(await groupsScreen(ctx, deps)); }
    else return showMain(ctx, deps, s);
  }
  const cfg = service.getGroupConfig(groupId);

  switch (s.step) {
    case 'main':
      if (text === '1') { s.step = 'config'; return ctx.reply(configText(cfg)); }
      if (text === '2') { s.step = 'questions'; return ctx.reply(questionsText(cfg)); }
      if (text === '3') { s.step = 'groups'; return ctx.reply(await groupsScreen(ctx, deps)); }
      if (text === '4') { s.step = 'queue'; return ctx.reply(service.renderQueue(await service.listQueue({ groupId }, deps)) + NAV); }
      if (text === '5') { s.step = 'stats'; return ctx.reply(`📊 *ESTATÍSTICAS* — escolha o período:\n${periodMenu()}${NAV}`); }
      return ctx.reply('Escolha uma opção de 0 a 5.');
    case 'config':
      if (text === '1') {
        const res = await service.setEnabled(groupId, !cfg.enabled, actor.id);
        if (!res.ok) return ctx.reply(`⚠️ ${res.error}\n\n${configText(cfg)}`);
        return ctx.reply(`${res.config.enabled ? '🟢 Triagem ativada.' : '🔴 Triagem desativada.'}\n\n${configText(res.config)}`);
      }
      if (text === '2') { s.step = 'config_hours'; return ctx.reply(`Quantas horas o membro terá para começar? (${LIMITS.minHours} a ${LIMITS.maxHours})${NAV}`); }
      if (text === '3') { const res = await service.setRestrictPending(groupId, !cfg.restrictPending, actor.id); return ctx.reply(`${res.config.restrictPending ? '🔒 Restrição ligada: mensagens de quem está pendente serão apagadas até terminar (o bot precisa ser admin). Se o PV falhar, a pessoa é liberada.' : '🔓 Restrição desligada.'}\n\n${configText(res.config)}`); }
      if (text === '4') { const res = await service.setReturningMode(groupId, cfg.returningMode === 'request' ? 'required' : 'request', actor.id); return ctx.reply(`🔁 Aprovado que volta: ${RETURNING_MODES[res.config.returningMode]}.\n\n${configText(res.config)}`); }
      if (text === '5') {
        const res = await service.startTestRound({ groupId, groupName: ctx.groupName, adminIds: [ctx.sender, ctx.senderAlternate, ctx.senderOriginal], chatId: null }, deps);
        close(ctx);
        if (!res.ok) return ctx.reply(groupError('NÃO FOI POSSÍVEL CONECTAR', res.error, 'Confira o FANTGRUP e tente novamente.'));
        return ctx.reply(`🧪 *Teste criado.*\n\nEnvie o código abaixo no *privado do bot* para responder como se fosse um membro novo. A ficha de teste volta só para você, sem afetar ninguém.\n\n${res.round.id}`);
      }
      if (text === '6') { s.step = 'history'; const list = service.getHistory(groupId); return ctx.reply(`🕓 *HISTÓRICO DE CONFIGURAÇÃO*\n${view.renderHistory(list)}${list.length ? '\n\nDigite o número da versão para restaurar.' : ''}${NAV}`); }
      return ctx.reply('Escolha de 1 a 6, 9 ou 0.');
    case 'config_hours': {
      const res = await service.setStartHours(groupId, text, actor.id);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'config';
      return ctx.reply(`✅ Prazo atualizado.\n\n${configText(res.config)}`);
    }
    case 'history': {
      const list = service.getHistory(groupId);
      const n = Number(text);
      if (!list[n - 1]) return ctx.reply('Escolha o número de uma versão da lista (ou 9/0).');
      s.step = 'history_confirm'; s.data = { n };
      return ctx.reply(`Restaurar a versão ${n}? Perguntas, prazo e conexões voltam como estavam (o estado ativo/desativo atual é mantido).\n1️⃣ Sim\n2️⃣ Não`);
    }
    case 'history_confirm': {
      const v = yesNo(text); if (v === null) return ctx.reply('Responda 1 (sim) ou 2 (não).');
      s.step = 'config';
      if (!v) return ctx.reply(configText(cfg));
      const res = await service.restoreConfig(groupId, s.data.n, actor.id);
      return ctx.reply(res.ok ? `✅ Versão restaurada.\n\n${configText(res.config)}` : `⚠️ ${res.error}`);
    }
    case 'questions':
      if (text === '1') { s.step = 'q_type'; s.data = {}; return ctx.reply(`Tipo da nova pergunta:\n${view.questionTypeMenu()}${NAV}`); }
      if (text === '2') {
        if (!cfg.questions.length) return ctx.reply('⚠️ Não há perguntas para remover.');
        s.step = 'q_remove'; return ctx.reply(`Qual pergunta remover? (1 a ${cfg.questions.length})${NAV}`);
      }
      if (text === '3') {
        const tpls = service.listTemplates();
        if (!tpls.length) return ctx.reply('⚠️ O dono ainda não criou modelos da rede.');
        s.step = 'q_template';
        return ctx.reply(`📑 *MODELOS DA REDE*\n${tpls.map((t, i) => `${i + 1}. ${t.name} (${t.questions.length} pergunta(s))`).join('\n')}\n\nDigite o número para ACRESCENTAR as perguntas ao grupo.${NAV}`);
      }
      return ctx.reply('Escolha 1, 2, 3, 9 ou 0.');
    case 'q_template': {
      const res = await service.applyTemplate(groupId, Number(text) - 1, actor.id);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'questions';
      return ctx.reply(`✅ Modelo "${res.template.name}" aplicado.\n\n${questionsText(res.config)}`);
    }
    case 'q_type': {
      const type = TYPE_KEYS[Number(text) - 1];
      if (!type) return ctx.reply(`Escolha de 1 a ${TYPE_KEYS.length}.`);
      s.data.type = type; s.step = 'q_text';
      return ctx.reply(`Digite o texto da pergunta (até ${LIMITS.maxQuestionLength} caracteres).${NAV}`);
    }
    case 'q_text':
      s.data.text = text;
      if (s.data.type === 'escolha') { s.step = 'q_options'; return ctx.reply(`Digite as opções separadas por vírgula (2 a ${LIMITS.maxOptions}).${NAV}`); }
      return saveQuestion(ctx, deps, s, groupId);
    case 'q_options':
      s.data.options = text.split(',').map(x => x.trim()).filter(Boolean);
      return saveQuestion(ctx, deps, s, groupId);
    case 'q_remove': {
      const res = await service.removeQuestion(groupId, Number(text) - 1, actor.id);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'questions';
      return ctx.reply(`🗑️ Removida: ${res.removed.text}${res.config.enabled ? '' : '\n_(Triagem desativada: sem perguntas.)_'}\n\n${questionsText(res.config)}`);
    }
    case 'groups': {
      if (text === '5') return ctx.reply(`${await groupsScreen(ctx, deps)}`);
      if (text === '1') {
        s.step = 'judge_id';
        return ctx.reply(`🔗 *CONECTAR GRUPO DE JULGAMENTO*\n\nEnvie o ID Fantasminha do grupo de destino.\n\n🆔 Exemplo: FANTGRUP-7K4M9X2P\n\n⚠️ O grupo precisa estar registrado no Fantasminha.${NAV}`);
      }
      if (text === '2') {
        s.step = 'appr_id';
        return ctx.reply(`📚 *CONECTAR DESTINO DE APROVADOS*\n\nEnvie o ID Fantasminha do grupo de destino.\n\n🆔 Exemplo: FANTGRUP-8H2K91LM\n\n⚠️ O grupo precisa estar registrado no Fantasminha.${NAV}`);
      }
      if (text === '3') {
        if (!cfg.judgeGroupId) return ctx.reply('ℹ️ O julgamento já está neste próprio grupo.');
        const res = await service.network.setJudgeGroup(groupId, null, actor, deps);
        s.step = 'groups';
        return ctx.reply(res.ok ? `✅ Julgamento desconectado.\n\n${await groupsScreen(ctx, deps)}` : `⚠️ ${res.error}`);
      }
      if (text === '4') {
        if (!cfg.approvedGroupIds.length) return ctx.reply('⚠️ Não há destinos para remover.');
        s.step = 'appr_remove'; return ctx.reply(`Qual destino remover? (1 a ${cfg.approvedGroupIds.length})${NAV}`);
      }
      return ctx.reply('Escolha de 1 a 5, 9 ou 0.');
    }
    case 'judge_id': {
      const res = await service.network.setJudgeGroupByFantId(groupId, text, actor, deps);
      if (res.needConfirm) { s.data = { fantId: text }; s.step = 'judge_confirm'; return ctx.reply(`⚠️ *${res.target.name}* já julga fichas de: ${res.shared.join(', ')}.\nContinuar mesmo assim?\n1️⃣ Sim\n2️⃣ Não`); }
      if (!res.ok) return ctx.reply(groupError('NÃO FOI POSSÍVEL CONECTAR', res.error, 'Confira o FANTGRUP e tente novamente.'));
      s.step = 'groups';
      return ctx.reply(`✅ Grupo de julgamento conectado.\n🆔 ${res.target.fantId || text.toUpperCase()}\n\n${await groupsScreen(ctx, deps)}`);
    }
    case 'judge_confirm': {
      const v = yesNo(text); if (v === null) return ctx.reply('Responda 1 (sim) ou 2 (não).');
      s.step = 'groups';
      if (!v) return ctx.reply(await groupsScreen(ctx, deps));
      const res = await service.network.setJudgeGroupByFantId(groupId, s.data.fantId, actor, deps, { confirm: true });
      return ctx.reply(res.ok ? `✅ Julgamento atualizado.\n\n${await groupsScreen(ctx, deps)}` : `⚠️ ${res.error}`);
    }
    case 'appr_id': {
      const res = await service.network.addApprovedGroupByFantId(groupId, text, actor, deps);
      if (!res.ok) return ctx.reply(groupError('NÃO FOI POSSÍVEL CONECTAR', res.error, 'Confira o FANTGRUP e tente novamente.'));
      s.step = 'groups';
      return ctx.reply(`${groupSuccess('DESTINO CONECTADO', `🆔 ${res.target.fantId || text.toUpperCase()}`)}\n\n${await groupsScreen(ctx, deps)}`);
    }
    case 'appr_remove': {
      const res = await service.network.removeApprovedGroup(groupId, Number(text) - 1, actor, deps);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'groups';
      return ctx.reply(`🗑️ Destino removido.\n\n${await groupsScreen(ctx, deps)}`);
    }
    case 'stats': {
      if (!STATS_PERIODS[text]) return ctx.reply(`Escolha de 1 a ${Object.keys(STATS_PERIODS).length}.`);
      const { stats, period } = service.stats(groupId, text, nowOf(deps));
      return ctx.reply(`${view.renderStats(stats, { period })}\n\n${periodMenu()}${NAV}`);
    }
    case 'queue':
      return ctx.reply('Use 9 para voltar ou 0 para cancelar.');
    default:
      return showMain(ctx, deps, s);
  }
}

async function saveQuestion(ctx, deps, s, groupId) {
  const res = await service.addQuestion(groupId, s.data, actorOf(ctx).id);
  if (!res.ok) { s.step = s.data.type === 'escolha' && s.data.text ? 'q_options' : 'q_text'; return ctx.reply(`⚠️ ${res.error}`); }
  s.step = 'questions'; s.data = {};
  return ctx.reply(`✅ Pergunta adicionada.\n\n${questionsText(res.config)}`);
}

/* ---------------- ×triagemcobrar: confirmação antes de cobrar ---------------- */
export async function startCobrarFlow(ctx, deps) {
  const rows = service.network.previewCobrar(ctx.from, nowOf(deps));
  const cfg = service.getGroupConfig(ctx.from);
  if (!cfg.enabled) return ctx.reply('⚠️ A triagem está desativada neste grupo. Ative em ×triagem > Configuração.');
  if (!rows.length) return ctx.reply('✅ Ninguém pendente para cobrar agora.');
  const room = Math.max(0, LIMITS.cobrarMaxPerHour - service.network.chargedLastHour(nowOf(deps)));
  open(ctx, deps, { kind: 'cobrar', step: 'cb_confirm', data: { count: rows.length } });
  return ctx.reply([`🔔 *Cobrar triagem*`, `Pendentes neste grupo: ${rows.length}`,
    room >= rows.length ? 'Todos serão cobrados agora, cada um com um ID novo (o anterior deixa de valer).' : `Para não arriscar o número do bot, só ${room} podem ser cobrados nesta hora; os demais ficam para depois.`,
    '', '1️⃣ Confirmar', '2️⃣ Cancelar'].join('\n'));
}

async function cobrarStep(ctx, deps, s, text) {
  const v = yesNo(text);
  if (text === '0' || v === false) { close(ctx); return ctx.reply('❌ Cobrança cancelada.'); }
  if (v === null) return ctx.reply('Responda 1 (confirmar) ou 2 (cancelar).');
  close(ctx);
  const res = await service.network.cobrar(ctx.from, ctx.groupName, actorOf(ctx), deps);
  if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
  if (res.empty) return ctx.reply('✅ Ninguém pendente para cobrar agora.');
  return ctx.reply(`🔔 Cobrados: ${res.charged}${res.remaining ? ` · ainda pendentes (limite por hora): ${res.remaining}. Repita ×triagemcobrar mais tarde.` : ''}`);
}

/* ---------------- fluxo de reprovação guiada ---------------- */
export async function startRejectFlow(ctx, round, deps) {
  open(ctx, deps, { kind: 'reject', step: 'rj_reason', data: { roundId: round.id } });
  const reasons = Object.entries(REJECT_REASONS).map(([k, v]) => `${k}️⃣ ${v}`).join('\n');
  return ctx.reply(`🚫 *Reprovar ${view.shortId(round)}*\n\nMotivo:\n${reasons}\n\n0️⃣ Cancelar\n_Dica: ×triagemreprovar #${round.n} 3 n n (motivo, nova tentativa s/n, avisar membro s/n)_`);
}

async function rejectStep(ctx, deps, s, text) {
  if (text === '0') { close(ctx); return ctx.reply('❌ Reprovação cancelada.'); }
  const yn = v => (/^(1|s|sim)$/i.test(v) ? true : /^(2|n|nao|não)$/i.test(v) ? false : null);
  if (s.step === 'rj_reason') {
    if (!REJECT_REASONS[text]) return ctx.reply('Escolha um motivo de 1 a 5.');
    s.data.reason = Number(text); s.step = 'rj_retry';
    return ctx.reply('Permitir nova tentativa em 7 dias?\n1️⃣ Sim\n2️⃣ Não\n0️⃣ Cancelar');
  }
  if (s.step === 'rj_retry') {
    const v = yn(text); if (v === null) return ctx.reply('Responda 1 (sim) ou 2 (não).');
    s.data.retry = v; s.step = 'rj_notify';
    return ctx.reply('Avisar o membro no privado?\n1️⃣ Sim\n2️⃣ Não\n0️⃣ Cancelar');
  }
  const v = yn(text); if (v === null) return ctx.reply('Responda 1 (sim) ou 2 (não).');
  const { roundId, reason, retry } = s.data;
  close(ctx);
  const res = await service.reject(roundId, actorOf(ctx), { reason, retry, notify: v }, deps);
  if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
  return ctx.reply(`🚫 Ficha ${view.shortId(res.round)} reprovada. O dono pode ver a ficha de reprovação.`);
}

/* ---------------- painel do dono (analisa; só mexe em configuração global) ---------------- */
function ownerMainText() {
  const off = repo.isEmergencyOff();
  return ['👑 *TRIAGEM — DONO* (somente leitura nas fichas)', `Triagem global: ${off ? '🔴 DESLIGADA (emergência)' : '🟢 funcionando'}`, '',
    '1️⃣ Fila global', '2️⃣ Reprovações', '3️⃣ Buscar pessoa', `4️⃣ ${off ? 'Religar' : 'Desligar'} tudo (emergência)`,
    '5️⃣ Estatísticas', '6️⃣ Exportar relatório (CSV)', '7️⃣ Modelos de perguntas', '8️⃣ Configuração global', '9️⃣ Registro global de grupos', '0️⃣ Cancelar',
    '_O dono analisa: aprovar e reprovar são dos admins._'].join('\n');
}

function globalText() {
  const g = repo.getGlobal();
  return ['🛠️ *CONFIGURAÇÃO GLOBAL*',
    `Aviso automático de reprovação ao dono: ${onoff(g.autoNotifyRejection)}`,
    `Retenção: ${g.retentionDays ? `${g.retentionDays} dia(s) (só avisa)` : 'desligada'}`,
    `Fotos após o julgamento: ${PHOTO_POLICIES[g.photoPolicy] || g.photoPolicy}`, '',
    '1️⃣ Alternar aviso de reprovação', '2️⃣ Definir retenção (dias; 0 desliga)', '3️⃣ Alternar fotos: guardar ↔ apagar após julgamento', '4️⃣ Apagar uma ficha (por ID)', NAV.trim()].join('\n');
}

function templatesText() {
  const t = service.listTemplates();
  return ['📑 *MODELOS DA REDE*', t.length ? t.map((x, i) => `${i + 1}. ${x.name} (${x.questions.length} pergunta(s))`).join('\n') : '_Nenhum modelo salvo._', '',
    '1️⃣ Salvar as perguntas DESTE grupo como modelo (abra o painel dentro do grupo)', '2️⃣ Apagar um modelo', NAV.trim()].join('\n');
}

async function ownerGroupsText(deps, query = '') {
  const live = await service.network.fetchGroups(deps);
  const rows = query ? groupRegistry.search(query) : groupRegistry.list();
  const active = rows.filter(g => g.status === 'active').length;
  const unavailable = rows.length - active;
  const lines = ['🌐 *REGISTRO GLOBAL DE GRUPOS*', `👥 Registrados: ${rows.length} · 🟢 ${active} · ⚪ ${unavailable}`, ''];
  if (!rows.length) lines.push('_Nenhum grupo registrado ainda._');
  else rows.forEach((g, i) => lines.push(`╭─ ${i + 1}. ${g.status === 'active' ? '🟢' : '⚪'} *${g.name}*\n│ 🆔 ${g.fantId}\n│ 📡 ${g.status === 'active' ? 'Disponível' : 'Indisponível'}\n╰────────────`));
  lines.push('', '1️⃣ Lista completa', '2️⃣ Consultar ID', '3️⃣ Buscar grupo', '4️⃣ Detalhes por ID', NAV.trim());
  return lines.join('\n');
}

async function ownerGroupDetails(id) {
  const g = groupRegistry.getByFantId(id);
  if (!g) return `⚠️ ID não encontrado: ${String(id).toUpperCase()}`;
  return [`🌐 *DETALHES DO GRUPO*`, `👥 ${g.name}`, `🆔 ${g.fantId}`, `📡 Status: ${g.status === 'active' ? '🟢 Ativo' : '⚪ Indisponível'}`, `📅 Registrado: ${new Date(g.createdAt).toLocaleString('pt-BR')}`, `🕐 Última presença: ${new Date(g.lastSeenAt).toLocaleString('pt-BR')}`, '', '_O ID real do WhatsApp permanece interno._'].join('\n');
}

export async function openOwnerPanel(ctx, deps) {
  open(ctx, deps, { kind: 'owner', step: 'main', data: {} });
  return ctx.reply(ownerMainText());
}

async function ownerStep(ctx, deps, s, text) {
  const actor = actorOf(ctx);
  if (text === '0') { close(ctx); return ctx.reply('❌ Painel do dono cancelado.'); }
  if (text === '9' && s.step !== 'main') {
    if (['tpl_name', 'tpl_delete'].includes(s.step)) { s.step = 'templates'; return ctx.reply(templatesText()); }
    if (['g_retention', 'g_delete_id', 'g_delete_confirm'].includes(s.step)) { s.step = 'global'; return ctx.reply(globalText()); }
    if (['owner_groups_search', 'owner_groups_id', 'owner_groups_detail'].includes(s.step)) { s.step = 'owner_groups'; return ctx.reply(await ownerGroupsText(deps)); }
    s.step = 'main'; return ctx.reply(ownerMainText());
  }
  switch (s.step) {
    case 'search': {
      const rows = service.findRounds(text, {});
      s.step = 'main';
      if (!rows.length) return ctx.reply(`Nenhuma ficha encontrada para "${text}".\n\n${ownerMainText()}`);
      return ctx.reply(service.renderQueue(rows, { showGroup: true, title: '🔎 *RESULTADO DA BUSCA*' }) + `\n\n${ownerMainText()}`);
    }
    case 'stats': case 'export': {
      if (!STATS_PERIODS[text]) return ctx.reply(`Escolha de 1 a ${Object.keys(STATS_PERIODS).length}.`);
      if (s.step === 'stats') { const { stats, period } = service.stats(null, text, nowOf(deps)); return ctx.reply(`${view.renderStats(stats, { title: '📊 *ESTATÍSTICAS DA REDE*', period })}\n\n${periodMenu()}${NAV}`); }
      const out = service.exportCsv(text, nowOf(deps));
      s.step = 'main';
      if (typeof deps.send?.document !== 'function') return ctx.reply('⚠️ Envio de arquivo indisponível neste ambiente.');
      await deps.send.document(ctx.from, Buffer.from(`\uFEFF${out.csv}`, 'utf8'), out.fileName, 'text/csv');
      await repo.appendAudit({ action: 'report_exported', actor: actor.id, period: out.period }, nowOf(deps));
      return ctx.reply(`📤 Relatório (${out.period}) enviado. Sem respostas, fotos nem números completos.\n\n${ownerMainText()}`);
    }
    case 'templates':
      if (text === '1') {
        if (!ctx.isGroup) return ctx.reply('⚠️ Abra o ×triagemdono dentro do grupo cujas perguntas você quer salvar.');
        s.step = 'tpl_name'; return ctx.reply(`Dê um nome ao modelo (até 40 caracteres).${NAV}`);
      }
      if (text === '2') { if (!service.listTemplates().length) return ctx.reply('⚠️ Não há modelos.'); s.step = 'tpl_delete'; return ctx.reply(`Qual modelo apagar? (número)${NAV}`); }
      return ctx.reply('Escolha 1, 2, 9 ou 0.');
    case 'tpl_name': {
      const res = await service.saveTemplate(ctx.from, text, actor);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'templates';
      return ctx.reply(`✅ Modelo salvo.\n\n${templatesText()}`);
    }
    case 'tpl_delete': {
      const res = await service.deleteTemplate(Number(text) - 1, actor);
      if (!res.ok) return ctx.reply(`⚠️ ${res.error}`);
      s.step = 'templates';
      return ctx.reply(`🗑️ Modelo apagado.\n\n${templatesText()}`);
    }
    case 'owner_groups': {
      if (text === '1') return ctx.reply(await ownerGroupsText(deps));
      if (text === '2') { s.step = 'owner_groups_id'; return ctx.reply(`Envie o ID Fantasminha (FANTGRUP-...).${NAV}`); }
      if (text === '3') { s.step = 'owner_groups_search'; return ctx.reply(`Digite parte do nome do grupo ou do ID.${NAV}`); }
      if (text === '4') { s.step = 'owner_groups_detail'; return ctx.reply(`Envie o ID Fantasminha do grupo.${NAV}`); }
      return ctx.reply('Escolha de 1 a 4, 9 ou 0.');
    }
    case 'owner_groups_id':
    case 'owner_groups_detail': {
      const details = await ownerGroupDetails(text);
      s.step = 'owner_groups';
      return ctx.reply(`${details}\n\n${await ownerGroupsText(deps)}`);
    }
    case 'owner_groups_search': {
      const rows = groupRegistry.search(text);
      s.step = 'owner_groups';
      return ctx.reply(`${rows.length ? rows.map((g, i) => `${i + 1}. ${g.status === 'active' ? '🟢' : '⚪'} ${g.name}\n   🆔 ${g.fantId}`).join('\n') : 'Nenhum grupo encontrado.'}\n\n${await ownerGroupsText(deps)}`);
    }
    case 'global':
      if (text === '1') { await repo.updateGlobal(g => { g.autoNotifyRejection = !g.autoNotifyRejection; return g; }); return ctx.reply(`✅ Atualizado.\n\n${globalText()}`); }
      if (text === '2') { s.step = 'g_retention'; return ctx.reply(`Quantos dias de retenção? (0 desliga; máx. 3650). O bot só AVISA, nunca apaga sozinho.${NAV}`); }
      if (text === '3') { await repo.updateGlobal(g => { g.photoPolicy = g.photoPolicy === 'keep' ? 'delete_on_decision' : 'keep'; return g; }); return ctx.reply(`✅ Atualizado.\n\n${globalText()}`); }
      if (text === '4') { s.step = 'g_delete_id'; return ctx.reply(`Digite o ID da ficha a apagar (TRG-XXXXXXXX).${NAV}`); }
      return ctx.reply('Escolha de 1 a 4, 9 ou 0.');
    case 'g_retention': {
      const n = Math.floor(Number(text));
      if (!Number.isFinite(n) || n < 0 || n > 3650) return ctx.reply('Informe um número de 0 a 3650.');
      await repo.updateGlobal(g => { g.retentionDays = n; return g; });
      await repo.appendAudit({ action: 'retention_set', actor: actor.id, days: n }, nowOf(deps));
      s.step = 'global';
      return ctx.reply(`✅ Retenção atualizada.\n\n${globalText()}`);
    }
    case 'g_delete_id': {
      const round = repo.getRound(text);
      if (!round) return ctx.reply('⚠️ Ficha não encontrada. Confira o ID.');
      s.data = { roundId: round.id }; s.step = 'g_delete_confirm';
      return ctx.reply(`⚠️ Apagar DEFINITIVAMENTE a ficha ${view.shortId(round)} (${round.groupName || round.groupId}, ${view.statusLabel(round.status)}), com respostas e fotos? Fica registrado só quem apagou e quando.\n1️⃣ Apagar\n2️⃣ Cancelar`);
    }
    case 'g_delete_confirm': {
      const v = yesNo(text); if (v === null) return ctx.reply('Responda 1 (apagar) ou 2 (cancelar).');
      s.step = 'global';
      if (!v) return ctx.reply(`Cancelado.\n\n${globalText()}`);
      const res = await service.deleteRound(s.data.roundId, actor, deps);
      return ctx.reply(res.ok ? `🗑️ Ficha ${res.round.id} apagada.\n\n${globalText()}` : `⚠️ ${res.error}`);
    }
    default:
      break;
  }
  if (text === '1') return ctx.reply(service.renderQueue(await service.listQueue({}, deps), { showGroup: true, title: '📥 *FILA GLOBAL*' }) + `\n\n${ownerMainText()}`);
  if (text === '2') {
    const rows = (await service.listQueue({ statuses: [STATUS.REJECTED] }, deps)).sort((a, b) => b.decidedAt - a.decidedAt);
    return ctx.reply(service.renderQueue(rows, { showGroup: true, title: '🚫 *REPROVAÇÕES*' }) + `\n\n${ownerMainText()}`);
  }
  if (text === '3') { s.step = 'search'; return ctx.reply(`Digite o número com DDI (ex.: 5511999999999) ou o ID TRG-...${NAV}`); }
  if (text === '4') {
    const next = !repo.isEmergencyOff();
    await repo.setEmergencyOff(next);
    await repo.appendAudit({ action: next ? 'emergency_off' : 'emergency_on', actor: collectIds(ctx.sender)[0] || ctx.sender }, nowOf(deps));
    return ctx.reply(`${next ? '🔴 Triagem DESLIGADA em todos os grupos.' : '🟢 Triagem religada.'}\n\n${ownerMainText()}`);
  }
  if (text === '5') { s.step = 'stats'; return ctx.reply(`📊 Período das estatísticas da rede:\n${periodMenu()}${NAV}`); }
  if (text === '6') { s.step = 'export'; return ctx.reply(`📤 Período do relatório:\n${periodMenu()}${NAV}`); }
  if (text === '7') { s.step = 'templates'; return ctx.reply(templatesText()); }
  if (text === '8') { s.step = 'global'; return ctx.reply(globalText()); }
  if (text === '9') { s.step = 'owner_groups'; return ctx.reply(await ownerGroupsText(deps)); }
  return ctx.reply('Escolha uma opção de 0 a 9.');
}

/* ---------------- entrada de mensagens ---------------- */
export async function handleSessionInput(ctx, deps) {
  const k = keyOf(ctx);
  const s = sessions.get(k);
  if (!s) return { handled: false };
  if (nowOf(deps) > s.expires) { sessions.delete(k); return { handled: false }; }
  const text = String(ctx.body || ctx.text || '').trim();
  if (!text) return { handled: false };
  if (ctx.prefix && text.startsWith(ctx.prefix)) { sessions.delete(k); return { handled: false }; }
  s.expires = nowOf(deps) + LIMITS.sessionMs;
  if (s.kind === 'reject') await rejectStep(ctx, deps, s, text);
  else if (s.kind === 'cobrar') await cobrarStep(ctx, deps, s, text);
  else if (s.kind === 'owner') await ownerStep(ctx, deps, s, text);
  else await adminStep(ctx, deps, s, text);
  return { handled: true };
}

export default { openAdminPanel, openOwnerPanel, startCobrarFlow, startRejectFlow, handleSessionInput, hasSession, clearSessions };
