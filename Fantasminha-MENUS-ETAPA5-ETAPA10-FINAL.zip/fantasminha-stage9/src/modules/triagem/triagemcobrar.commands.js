import { Role } from '../../core/permissions.js';
import { defineCommandContract } from '../../core/command/contract.js';
import { buildDeps } from './index.js';
import * as panel from './triagem.panel.js';
import { guarded } from './triagem.commandKit.js';

export default defineCommandContract({
  name: 'triagemcobrar', aliases: [], category: 'admin', permission: Role.GROUP_ADMIN, groupOnly: true,
  enabled: true, cooldown: 5, audit: true, publicName: 'Cobrar triagem',
  description: 'Cobra quem ainda não terminou a triagem, sempre com ID novo, após confirmação. Envio em lotes com limite por hora.',
  purpose: 'Reativa pendentes do grupo: o ID antigo deixa de valer e a pessoa recebe um novo.',
  usage: '×triagemcobrar', syntax: '×triagemcobrar', examples: ['×triagemcobrar'],
  authorization: { level: 'GROUP_ADMIN' },
  handler: guarded(async ctx => panel.startCobrarFlow(ctx, buildDeps(ctx)))
});
