/**
 * Regras de negócio da Triagem 2.0.
 * - O bot só coleta, organiza e sinaliza; o admin decide; o dono só analisa.
 * - Não importa Baileys: o envio e o download de mídia chegam por `deps`.
 * - A blacklist do bot é apenas CONSULTADA (adapter somente-leitura).
 *
 * deps = {
 *   send: { text(chatId, text, mentions?), image(chatId, buffer, caption?, mentions?) },
 *   downloadImage?(rawMessage) -> Buffer|null,
 *   resolvePN?(lid) -> jid|null,
 *   botNumber?: string,
 *   now?(): number
 * }
 */
import crypto from 'node:crypto';
import { STATUS, OPEN_STATUSES, LIMITS, ID_PATTERN, QUESTION_TYPES, REJECT_REASONS } from './triagem.constants.js';
import { collectIds, idsOverlap, pickChatId, isJidId, isLidId, digitsOf } from './triagem.identity.js';
import * as repo from './triagem.repository.js';
import { computeSignals, parseBirthDate } from './triagem.signals.js';
import * as view from './triagem.presenter.js';
import { consultarBlacklist } from '../../legacy/adapters/blacklistReader.js';
import { nowOf, safe, mentionJid, mediaRoot, saveMedia, readMedia, stripPhotos, deleteRoundMedia, ownerChatIds } from './triagem.util.js';
import * as network from './triagem.network.js';
import * as reports from './triagem.reports.js';

export { mediaRoot, network };

/* ---------------- identidade ---------------- */
async function extendIds(ids, deps) {
  const out = [...ids];
  if (typeof deps?.resolvePN === 'function') {
    for (const id of ids.filter(isLidId)) {
      const pn = await safe(() => deps.resolvePN(id));
      if (pn) out.push(pn);
    }
  }
  return collectIds(out);
}

/* ---------------- configuração (usada pelo painel) ---------------- */
export function getGroupConfig(groupId) { return repo.getGroupConfig(groupId); }

export async function addQuestion(groupId, { type, text, options = [] }, by = null) {
  if (!QUESTION_TYPES[type]) return { ok: false, error: 'Tipo de pergunta inválido.' };
  const clean = String(text || '').trim().slice(0, LIMITS.maxQuestionLength);
  if (!clean) return { ok: false, error: 'A pergunta não pode ficar vazia.' };
  const opts = options.map(o => String(o).trim()).filter(Boolean).slice(0, LIMITS.maxOptions);
  if (type === 'escolha' && opts.length < 2) return { ok: false, error: 'Informe pelo menos 2 opções.' };
  let error = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (g.questions.length >= LIMITS.maxQuestions) { error = `Limite de ${LIMITS.maxQuestions} perguntas atingido.`; return g; }
    g.questions.push({ id: `q_${crypto.randomBytes(3).toString('hex')}`, type, text: clean, ...(type === 'escolha' ? { options: opts } : {}) });
    return g;
  }, Date.now(), { by });
  return error ? { ok: false, error } : { ok: true, config: cfg };
}

export async function removeQuestion(groupId, index, by = null) {
  let removed = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (index >= 0 && index < g.questions.length) { [removed] = g.questions.splice(index, 1); }
    if (!g.questions.length) g.enabled = false;
    return g;
  }, Date.now(), { by });
  return removed ? { ok: true, removed, config: cfg } : { ok: false, error: 'Pergunta não encontrada.' };
}

export async function setEnabled(groupId, value, by = null) {
  let error = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (value && !g.questions.length) { error = 'Cadastre pelo menos 1 pergunta antes de ativar.'; return g; }
    g.enabled = !!value;
    return g;
  }, Date.now(), { by });
  return error ? { ok: false, error } : { ok: true, config: cfg };
}

export async function setStartHours(groupId, hours, by = null) {
  const h = Math.floor(Number(hours));
  if (!Number.isFinite(h) || h < LIMITS.minHours || h > LIMITS.maxHours) return { ok: false, error: `Use um valor entre ${LIMITS.minHours} e ${LIMITS.maxHours} horas.` };
  const cfg = await repo.updateGroupConfig(groupId, g => { g.startHours = h; return g; }, Date.now(), { by });
  return { ok: true, config: cfg };
}

/* ---------------- entrada no grupo ---------------- */
export async function onMemberJoined(evt, deps) {
  const now = nowOf(deps);
  if (!repo.isGloballyEnabled()) return { skipped: 'global_disabled', rounds: [] };
  if (repo.isEmergencyOff()) return { skipped: 'emergency', rounds: [] };
  const cfg = repo.getGroupConfig(evt.groupId);
  if (!cfg.enabled || !cfg.questions.length) return { skipped: 'disabled', rounds: [] };
  const botIds = collectIds(evt.botJid);
  const rounds = [];
  for (const participant of evt.participants || []) {
    const ids = await extendIds(collectIds(participant), deps);
    if (!ids.length || idsOverlap(ids, botIds)) continue;
    const previous = repo.roundsForIds(ids, { groupId: evt.groupId }).find(r => r.status === STATUS.APPROVED);
    const required = cfg.returningMode === 'required';
    const { created, round } = await repo.createRound({
      groupId: evt.groupId, groupName: evt.groupName || '', ids,
      pushName: evt.pushNames?.[participant] || '', questions: cfg.questions,
      expiresAt: now + cfg.startHours * 3600_000,
      extra: previous ? { returning: { previousId: previous.id }, optional: !required } : {}
    }, now);
    rounds.push({ created, round });
    if (!created) continue;
    await repo.appendAudit({ action: 'round_created', roundId: round.id, groupId: round.groupId, actor: 'bot', returning: !!previous }, now);
    const opts = { botNumber: deps?.botNumber, hours: cfg.startHours, total: cfg.questions.length };
    if (previous) {
      const target = await network.resolveJudgeTarget(round, deps);
      const old = buildFicha(previous, { viewer: 'admin', now, origin: !!target.judgeGroupId });
      await safe(() => deps.send.text(target.chatId, `🔁 *Ficha anterior de quem voltou*\n\n${old.text}`, old.mentions));
      await safe(() => deps.send.text(evt.groupId, view.renderReturning(round, { ...opts, required }), [mentionJid(round.ids)]));
    } else {
      await safe(() => deps.send.text(evt.groupId, view.renderAnnouncement(round, opts), [mentionJid(round.ids)]));
    }
  }
  return { rounds };
}

/* ---------------- PV: o membro responde ---------------- */
async function parseAnswer(round, q, msg, deps) {
  const text = String(msg.text || '').trim();
  if (q.type === 'foto') {
    if (!msg.hasImage) return { ok: false };
    const buffer = await safe(() => deps.downloadImage?.(msg.message));
    if (!buffer) return { ok: false, hint: '⚠️ Não consegui baixar a foto. Envie novamente.' };
    return { ok: true, answer: { text: '[foto]', mediaFile: saveMedia(round.id, q.id, buffer) } };
  }
  if (!text) return { ok: false };
  const clipped = text.slice(0, LIMITS.maxAnswerLength);
  switch (q.type) {
    case 'data': {
      const b = parseBirthDate(text);
      if (!b || b.y < 1900 || b.y > new Date(nowOf(deps)).getUTCFullYear()) return { ok: false };
      return { ok: true, answer: { text: `${String(b.d).padStart(2, '0')}/${String(b.mo).padStart(2, '0')}/${b.y}`, value: b.iso } };
    }
    case 'numero': {
      if (!/^-?\d+([.,]\d+)?$/.test(text)) return { ok: false };
      return { ok: true, answer: { text: text.replace(',', '.'), value: Number(text.replace(',', '.')) } };
    }
    case 'simnao': {
      const t = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      if (['sim', 's', 'yes', 'y'].includes(t)) return { ok: true, answer: { text: 'Sim', value: 'sim' } };
      if (['nao', 'n', 'no'].includes(t)) return { ok: true, answer: { text: 'Não', value: 'nao' } };
      return { ok: false };
    }
    case 'escolha': {
      const opts = q.options || [];
      const n = /^\d+$/.test(text) ? Number(text) : 0;
      const idx = n >= 1 && n <= opts.length ? n - 1 : opts.findIndex(o => o.toLowerCase() === text.toLowerCase());
      if (idx < 0) return { ok: false };
      return { ok: true, answer: { text: opts[idx], value: idx } };
    }
    default:
      return { ok: true, answer: { text: clipped } };
  }
}

async function sendQuestion(round, deps) {
  const q = round.questions[round.currentIndex];
  const chat = pickChatId(round.ids, round.pvChat);
  await safe(() => deps.send.text(chat, view.renderQuestion(q, round.currentIndex, round.questions.length)));
}

async function startRound(round, msg, ids, verified, deps) {
  const now = nowOf(deps);
  const started = await repo.updateRound(round.id, r => {
    r.status = STATUS.IN_PROGRESS;
    r.startedAt = r.startedAt || now;
    r.lastActivityAt = now; r.lastQuestionAt = now;
    r.pvChat = msg.chatId || r.pvChat;
    r.pvClaimed = true;
    r.ids = collectIds(r.ids, verified ? ids : []);
    if (!verified) { r.identityVerified = false; r.ids = collectIds(r.ids, ids); }
    return r;
  });
  await repo.appendAudit({ action: 'round_started', roundId: round.id, groupId: round.groupId, actor: 'member' }, now);
  const introSent = await safe(() => deps.send.text(started.pvChat, view.renderIntro(started)));
  if (introSent === null) { await network.liftRestriction(started, 'pv_failed', deps); return started; }
  await sendQuestion(started, deps);
  return started;
}

export function hasOpenRoundForPrivateInput(msg) {
  const ids = collectIds(msg.sender, msg.senderAlternate, msg.senderOriginal, msg.chatId);
  if (ID_PATTERN.test(String(msg.text || '').trim())) return true;
  return ids.length > 0 && repo.openRoundsForIds(ids).length > 0;
}

export async function handlePrivateInput(msg, deps) {
  const now = nowOf(deps);
  const text = String(msg.text || '').trim();
  const baseIds = collectIds(msg.sender, msg.senderAlternate, msg.senderOriginal, msg.chatId);
  if (!baseIds.length) return { handled: false };
  const isCode = ID_PATTERN.test(text);
  if (!isCode && !repo.openRoundsForIds(baseIds).length) return { handled: false };
  await repo.sweepExpired(now);
  const ids = await extendIds(baseIds, deps);
  const reply = body => safe(() => deps.send.text(msg.chatId || baseIds[0], body));

  if (isCode) {
    const round = repo.getRound(text);
    if (!round) { await reply('⚠️ Código de triagem não encontrado.'); return { handled: true }; }
    const overlap = idsOverlap(round.ids, ids);
    if (!overlap) {
      const senderKnowsJid = ids.some(isJidId);
      const roundKnowsJid = round.ids.some(isJidId);
      const claimable = round.status === STATUS.PENDING && !round.pvClaimed && !(senderKnowsJid && roundKnowsJid);
      if (!claimable) { await reply('⚠️ Este código pertence a outra pessoa.'); return { handled: true }; }
    }
    if (round.status === STATUS.PENDING) { await startRound(round, msg, ids, overlap, deps); return { handled: true, roundId: round.id }; }
    if (round.status === STATUS.IN_PROGRESS) { await sendQuestion(round, deps); return { handled: true, roundId: round.id }; }
    await reply(`ℹ️ A ficha ${view.shortId(round)} está: ${view.statusLabel(round.status)}.`);
    return { handled: true, roundId: round.id };
  }

  const open = repo.openRoundsForIds(ids);
  if (!open.length) return { handled: false };
  const inProgress = open.filter(r => r.status === STATUS.IN_PROGRESS);
  const pending = open.filter(r => r.status === STATUS.PENDING);
  if (!inProgress.length) {
    if (pending.length > 1) {
      await reply(`Você tem mais de uma triagem pendente. Envie o código da que quer responder:\n${pending.map(r => `• ${r.id} — ${r.groupName || 'grupo'}`).join('\n')}`);
      return { handled: true };
    }
    await startRound(pending[0], msg, ids, true, deps);
    return { handled: true, roundId: pending[0].id };
  }

  const round = inProgress[0];
  const q = round.questions[round.currentIndex];
  const parsed = await parseAnswer(round, q, msg, deps);
  if (!parsed.ok) {
    await reply(parsed.hint || view.invalidHint(q));
    return { handled: true, roundId: round.id };
  }
  let finished = false;
  const updated = await repo.updateRound(round.id, r => {
    if (r.status !== STATUS.IN_PROGRESS || r.currentIndex !== round.currentIndex) return r; // evita resposta duplicada
    r.answers.push({ qid: q.id, type: q.type, answeredAt: now, elapsedMs: Math.max(0, now - (r.lastQuestionAt || now)), ...parsed.answer });
    r.currentIndex += 1;
    r.lastActivityAt = now; r.lastQuestionAt = now;
    finished = r.currentIndex >= r.questions.length;
    return r;
  });
  if (!updated) return { handled: true };
  if (finished) await submitRound(updated, deps);
  else await sendQuestion(updated, deps);
  return { handled: true, roundId: round.id };
}

/* ---------------- ficha e julgamento ---------------- */
export function buildFicha(round, { viewer = 'admin', now = Date.now(), origin = false } = {}) {
  const all = repo.allRounds();
  const scoped = viewer === 'owner' ? all : all.filter(r => r.groupId === round.groupId);
  const blacklist = consultarBlacklist(round.groupId, round.ids);
  const signals = computeSignals(round, { rounds: scoped, blacklist, viewer, now });
  const mentions = [mentionJid(round.ids)].filter(Boolean);
  return { text: view.renderFicha(round, signals, { viewer, origin: origin || !!round.judgeGroupId }), mentions, signals };
}

export async function deliverFicha(chatId, round, ficha, deps) {
  await safe(() => deps.send.text(chatId, ficha.text, ficha.mentions));
  for (const a of round.answers || []) {
    if (!a.mediaFile) continue;
    const q = round.questions.find(x => x.id === a.qid);
    const buffer = readMedia(a.mediaFile);
    if (buffer) await safe(() => deps.send.image(chatId, buffer, `🖼️ ${view.shortId(round)} — ${q?.text || 'foto'}`));
  }
}

async function submitRound(round, deps) {
  const now = nowOf(deps);
  const submitted = await repo.updateRound(round.id, r => { r.status = STATUS.SUBMITTED; r.submittedAt = now; return r; });
  await repo.appendAudit({ action: 'round_submitted', roundId: round.id, groupId: round.groupId, actor: 'member' }, now);
  await safe(() => deps.send.text(pickChatId(submitted.ids, submitted.pvChat), view.renderSubmitted(submitted)));
  let target = pickChatId(submitted.ids, submitted.pvChat);
  let judgeGroupId = null;
  if (!submitted.isTest) {
    const route = await network.resolveJudgeTarget(submitted, deps);
    target = route.chatId; judgeGroupId = route.judgeGroupId;
    if (route.fellBack) {
      await repo.appendAudit({ action: 'judge_unhealthy', roundId: round.id, groupId: round.groupId, judgeName: route.judgeName, reason: route.reason }, now);
      await safe(() => deps.send.text(submitted.groupId, `⚠️ O grupo de julgamento (${route.judgeName}) não está acessível: ${route.reason}. A ficha ${view.shortId(submitted)} foi enviada aqui. Revisem a conexão em ×triagem > Grupos.`));
    }
    if (judgeGroupId) await repo.updateRound(round.id, r => { r.judgeGroupId = judgeGroupId; return r; });
  }
  const ficha = buildFicha({ ...submitted, judgeGroupId }, { viewer: 'admin', now, origin: !!judgeGroupId });
  const sent = await safe(() => deliverFicha(target, submitted, ficha, deps));
  if (sent === null) await repo.appendAudit({ action: 'deliver_failed', roundId: round.id, groupId: round.groupId, actor: 'bot' }, now);
  return submitted;
}

export function canJudge(actor, round) {
  if (!actor || !round) return false;
  return !!actor.isGroupAdmin && !!actor.chatId && (actor.chatId === round.groupId || (!!round.judgeGroupId && actor.chatId === round.judgeGroupId));
}

export function canView(actor, round) {
  if (!actor || !round) return false;
  if (actor.isOwner) return true;
  return canJudge(actor, round);
}

export async function approve(roundId, actor, deps) {
  const now = nowOf(deps);
  const round = repo.getRound(roundId);
  if (!round) return { ok: false, error: 'Ficha não encontrada.' };
  if (!canJudge(actor, round)) return { ok: false, error: actor?.isOwner ? 'O dono só analisa: quem aprova é o admin do grupo.' : 'Você não pode julgar esta ficha.' };
  if (round.isTest) { await repo.updateRound(round.id, r => { r.status = STATUS.RELEASED; r.decidedAt = now; r.decidedBy = actor.id; return r; }); return { ok: true, test: true, round }; }
  if (round.status !== STATUS.SUBMITTED) return { ok: false, error: `Esta ficha está: ${view.statusLabel(round.status)}.` };
  const updated = await repo.updateRound(round.id, r => {
    if (r.status !== STATUS.SUBMITTED) return r;
    r.status = STATUS.APPROVED; r.decidedAt = now; r.decidedBy = actor.id; return r;
  });
  if (updated.status !== STATUS.APPROVED) return { ok: false, error: 'Esta ficha já foi julgada.' };
  await repo.appendAudit({ action: 'round_approved', roundId: round.id, groupId: round.groupId, actor: actor.id }, now);
  await safe(() => deps.send.text(pickChatId(updated.ids, updated.pvChat), view.renderMemberApproved(updated)));
  const { results } = await network.finalizeApproval(updated, deps);
  const final = await applyPhotoPolicy(repo.getRound(updated.id) || updated);
  return { ok: true, round: final, approval: results };
}

/** Aprovação repetida só para os grupos que falharam ou ficaram só com link. */
export async function retryApproval(roundId, actor, deps) {
  const round = repo.getRound(roundId);
  if (!round) return { ok: false, error: 'Ficha não encontrada.' };
  if (!canJudge(actor, round)) return { ok: false, error: 'Você não pode julgar esta ficha.' };
  if (round.status !== STATUS.APPROVED) return { ok: false, error: 'Só dá para repetir em ficha aprovada.' };
  const res = await network.retryApproval(round, deps);
  if (res.nothing) return { ok: true, nothing: true, round };
  return { ok: true, round: repo.getRound(round.id), approval: res.results };
}

async function applyPhotoPolicy(round) {
  if (repo.getGlobal().photoPolicy !== 'delete_on_decision') return round;
  const out = await repo.updateRound(round.id, r => { stripPhotos(r); return r; });
  return out || round;
}

export async function reject(roundId, actor, { reason = 5, retry = false, notify = true } = {}, deps) {
  const now = nowOf(deps);
  const round = repo.getRound(roundId);
  if (!round) return { ok: false, error: 'Ficha não encontrada.' };
  if (!canJudge(actor, round)) return { ok: false, error: actor?.isOwner ? 'O dono só analisa: quem reprova é o admin do grupo.' : 'Você não pode julgar esta ficha.' };
  const code = REJECT_REASONS[reason] ? Number(reason) : 5;
  if (round.isTest) { await repo.updateRound(round.id, r => { r.status = STATUS.RELEASED; r.decidedAt = now; r.decidedBy = actor.id; return r; }); return { ok: true, test: true, round }; }
  if (round.status !== STATUS.SUBMITTED) return { ok: false, error: `Esta ficha está: ${view.statusLabel(round.status)}.` };
  const updated = await repo.updateRound(round.id, r => {
    if (r.status !== STATUS.SUBMITTED) return r;
    r.status = STATUS.REJECTED; r.decidedAt = now; r.decidedBy = actor.id;
    r.rejection = { reason: code, retry: !!retry, retryAfter: retry ? now + LIMITS.retryDays * 86400_000 : null, notified: !!notify };
    return r;
  });
  if (updated.status !== STATUS.REJECTED) return { ok: false, error: 'Esta ficha já foi julgada.' };
  await repo.appendAudit({ action: 'round_rejected', roundId: round.id, groupId: round.groupId, actor: actor.id, reason: code }, now);
  if (notify) await safe(() => deps.send.text(pickChatId(updated.ids, updated.pvChat), view.renderMemberRejected(updated)));
  if (repo.getGlobal().autoNotifyRejection) {
    const text = view.renderRejectionFicha(updated, consultarBlacklist(updated.groupId, updated.ids));
    for (const chat of ownerChatIds()) await safe(() => deps.send.text(chat, text, [mentionJid(updated.ids)]));
  }
  const final = await applyPhotoPolicy(repo.getRound(updated.id) || updated);
  return { ok: true, round: final };
}

export async function addNote(roundId, actor, text, deps) {
  const now = nowOf(deps);
  const round = repo.getRound(roundId);
  if (!round) return { ok: false, error: 'Ficha não encontrada.' };
  if (!canJudge(actor, round)) return { ok: false, error: actor?.isOwner ? 'O dono só analisa; notas são dos admins do grupo.' : 'Você não pode anotar nesta ficha.' };
  const clean = String(text || '').trim().slice(0, 300);
  if (!clean) return { ok: false, error: 'Escreva o texto da nota.' };
  const updated = await repo.updateRound(round.id, r => { r.notes.push({ at: now, by: actor.id, text: clean }); return r; });
  await repo.appendAudit({ action: 'note_added', roundId: round.id, groupId: round.groupId, actor: actor.id }, now);
  return { ok: true, round: updated };
}

/* ---------------- privacidade: só o dono apaga ---------------- */
/** Só o dono apaga uma ficha por completo (com registro de quem e quando, sem guardar o conteúdo). */
export async function deleteRound(roundId, actor, deps) {
  const now = nowOf(deps);
  if (!actor?.isOwner) return { ok: false, error: 'Só o dono pode apagar fichas.' };
  const round = repo.getRound(roundId);
  if (!round) return { ok: false, error: 'Ficha não encontrada.' };
  deleteRoundMedia(round.id);
  await repo.deleteRound(round.id);
  await repo.appendAudit({ action: 'round_deleted', roundId: round.id, groupId: round.groupId, actor: actor.id }, now);
  return { ok: true, round };
}

/** Fichas já decididas há mais tempo que o prazo de retenção (só avisa; a exclusão é manual). */
export function retentionDue(now = Date.now()) {
  const days = Number(repo.getGlobal().retentionDays) || 0;
  if (!days) return [];
  const limit = now - days * 86400_000;
  const done = [STATUS.APPROVED, STATUS.REJECTED, STATUS.EXPIRED, STATUS.SUPERSEDED, STATUS.RELEASED];
  return repo.allRounds().filter(r => !r.isTest && done.includes(r.status) && (r.decidedAt || r.createdAt) < limit);
}

/* ---------------- busca e filas ---------------- */
/** Grupos cujas fichas este chat enxerga: ele mesmo + os que o usam como grupo de julgamento. */
export function scopeGroups(chatId) { return repo.groupsJudgedBy(chatId); }

export function findRounds(query, { groupId = null, mentioned = [] } = {}) {
  const q = String(query || '').trim();
  const scope = groupId ? scopeGroups(groupId) : null;
  const inScope = r => !scope || scope.includes(r.groupId);
  if (ID_PATTERN.test(q)) { const r = repo.getRound(q); return r && inScope(r) ? [r] : []; }
  const num = q.match(/^#?(\d{1,6})$/);
  if (num && groupId) {
    const hits = scope.map(g => repo.getRoundByNumber(g, num[1])).filter(Boolean);
    return hits;
  }
  if (mentioned?.length) {
    const rows = repo.roundsForIds(collectIds(mentioned), {}).filter(inScope);
    if (rows.length) return rows;
  }
  const digits = digitsOf(q);
  if (digits.length >= 7) {
    return repo.allRounds()
      .filter(r => !r.isTest && inScope(r) && r.ids.some(id => id.split('@')[0].includes(digits)))
      .sort((a, b) => b.createdAt - a.createdAt);
  }
  return [];
}

export async function listQueue({ groupId = null, statuses = [STATUS.SUBMITTED, STATUS.IN_PROGRESS, STATUS.PENDING] } = {}, deps) {
  await repo.sweepExpired(nowOf(deps));
  const scope = groupId ? scopeGroups(groupId) : null;
  return repo.allRounds()
    .filter(r => !r.isTest && (!scope || scope.includes(r.groupId)) && statuses.includes(r.status))
    .sort((a, b) => b.createdAt - a.createdAt);
}

export function renderQueue(rows, { showGroup = false, title = '📥 *FILA DE TRIAGEM*' } = {}) {
  if (!rows.length) return `${title}\n\nNada por aqui.`;
  const lines = rows.slice(0, LIMITS.queueLines).map(r =>
    `• ${showGroup ? `${r.groupName || r.groupId} · ` : ''}#${r.n} ${r.id} — @${(r.ids[0] || '').split('@')[0]} — ${view.statusLabel(r.status)}`);
  const more = rows.length > LIMITS.queueLines ? `\n… e mais ${rows.length - LIMITS.queueLines}.` : '';
  return `${title}\n\n${lines.join('\n')}${more}\n\nAbra uma ficha com ×triagemficha <ID ou #n>.`;
}

/* ---------------- opções do grupo, histórico, modelos, relatórios ---------------- */
export async function setRestrictPending(groupId, value, by = null) {
  const cfg = await repo.updateGroupConfig(groupId, g => { g.restrictPending = !!value; return g; }, Date.now(), { by });
  return { ok: true, config: cfg };
}

export async function setReturningMode(groupId, mode, by = null) {
  if (!['request', 'required'].includes(mode)) return { ok: false, error: 'Modo inválido.' };
  const cfg = await repo.updateGroupConfig(groupId, g => { g.returningMode = mode; return g; }, Date.now(), { by });
  return { ok: true, config: cfg };
}

export function getHistory(groupId) { return repo.getHistory(groupId); }

export async function restoreConfig(groupId, index, by = null) {
  const cfg = await repo.restoreGroupConfig(groupId, index, Date.now(), { by });
  if (!cfg) return { ok: false, error: 'Versão não encontrada.' };
  await repo.appendAudit({ action: 'config_restored', groupId, actor: by }, Date.now());
  return { ok: true, config: cfg };
}

export function listTemplates() { return repo.getGlobal().templates || []; }

export async function saveTemplate(groupId, name, actor) {
  if (!actor?.isOwner) return { ok: false, error: 'Só o dono cria modelos da rede.' };
  const clean = String(name || '').trim().slice(0, 40);
  if (!clean) return { ok: false, error: 'Dê um nome ao modelo.' };
  const questions = repo.getGroupConfig(groupId).questions;
  if (!questions.length) return { ok: false, error: 'Este grupo ainda não tem perguntas para salvar.' };
  let error = null;
  const g = await repo.updateGlobal(glob => {
    const list = glob.templates || [];
    if (list.length >= LIMITS.templatesMax) { error = 'Limite de modelos atingido.'; return glob; }
    glob.templates = [...list.filter(t => t.name.toLowerCase() !== clean.toLowerCase()), { id: `m_${crypto.randomBytes(3).toString('hex')}`, name: clean, questions: JSON.parse(JSON.stringify(questions)), by: actor.id, at: Date.now() }];
    return glob;
  });
  if (error) return { ok: false, error };
  await repo.appendAudit({ action: 'template_saved', groupId, actor: actor.id }, Date.now());
  return { ok: true, templates: g.templates };
}

export async function deleteTemplate(index, actor) {
  if (!actor?.isOwner) return { ok: false, error: 'Só o dono apaga modelos.' };
  let removed = null;
  const g = await repo.updateGlobal(glob => { const list = [...(glob.templates || [])]; [removed] = index >= 0 && index < list.length ? list.splice(index, 1) : []; glob.templates = list; return glob; });
  return removed ? { ok: true, removed, templates: g.templates } : { ok: false, error: 'Modelo não encontrado.' };
}

/** Acrescenta as perguntas do modelo às do grupo (ids novos), respeitando o limite. */
export async function applyTemplate(groupId, index, by = null) {
  const tpl = listTemplates()[index];
  if (!tpl) return { ok: false, error: 'Modelo não encontrado.' };
  let error = null;
  const cfg = await repo.updateGroupConfig(groupId, g => {
    if (g.questions.length + tpl.questions.length > LIMITS.maxQuestions) { error = `Passaria do limite de ${LIMITS.maxQuestions} perguntas.`; return g; }
    for (const q of tpl.questions) g.questions.push({ ...JSON.parse(JSON.stringify(q)), id: `q_${crypto.randomBytes(3).toString('hex')}` });
    return g;
  }, Date.now(), { by });
  return error ? { ok: false, error } : { ok: true, config: cfg, template: tpl };
}

export function stats(groupId, periodKey, now = Date.now()) {
  const period = reports.periodSince(periodKey, now) || reports.periodSince(4, now);
  const scope = groupId ? scopeGroups(groupId) : null;
  const rows = repo.allRounds().filter(r => !scope || scope.includes(r.groupId));
  return { stats: reports.computeStats(rows, { since: period.since }), period: period.label };
}

export function exportCsv(periodKey, now = Date.now()) {
  const period = reports.periodSince(periodKey, now) || reports.periodSince(4, now);
  return { csv: reports.toCsv(repo.allRounds(), { since: period.since }), period: period.label, fileName: `triagem-${period.label.replace(/\s+/g, '')}-${new Date(now).toISOString().slice(0, 10)}.csv` };
}

export async function startTestRound({ groupId, groupName, adminIds, chatId }, deps) {
  const cfg = repo.getGroupConfig(groupId);
  if (!cfg.questions.length) return { ok: false, error: 'Cadastre pelo menos 1 pergunta para testar.' };
  const now = nowOf(deps);
  const ids = await extendIds(collectIds(adminIds, chatId), deps);
  const { round } = await repo.createRound({ groupId, groupName, ids, questions: cfg.questions, expiresAt: now + 3600_000, isTest: true }, now);
  return { ok: true, round };
}

export default {
  mediaRoot, getGroupConfig, addQuestion, removeQuestion, setEnabled, setStartHours,
  onMemberJoined, handlePrivateInput, hasOpenRoundForPrivateInput, buildFicha, deliverFicha,
  canJudge, canView, approve, retryApproval, reject, addNote, deleteRound, retentionDue, scopeGroups, setRestrictPending, setReturningMode, getHistory, restoreConfig, listTemplates, saveTemplate, deleteTemplate, applyTemplate, stats, exportCsv, network, findRounds, listQueue, renderQueue, startTestRound
};
