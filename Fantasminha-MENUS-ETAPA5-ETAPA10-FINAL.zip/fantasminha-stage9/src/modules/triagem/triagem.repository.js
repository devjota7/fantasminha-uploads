/**
 * Persistência da Triagem 2.0 sobre src/database/store.js
 * (escrita atômica + lock por coleção). Não usa o banco legado de dados/.
 */
import crypto from 'node:crypto';
import { readCollection, updateCollection } from '../../database/store.js';
import { COLLECTIONS, STATUS, OPEN_STATUSES, LIMITS } from './triagem.constants.js';
import { collectIds, idsOverlap } from './triagem.identity.js';

const clone = v => JSON.parse(JSON.stringify(v));
const DEFAULT_GROUP = Object.freeze({
  enabled: false, questions: [], startHours: LIMITS.defaultStartHours, updatedAt: 0,
  judgeGroupId: null, approvedGroupIds: [], restrictPending: false, returningMode: 'request'
});
const DEFAULT_GLOBAL = Object.freeze({
  emergencyOff: false, autoNotifyRejection: false, retentionDays: 0, photoPolicy: 'keep',
  templates: [], lastDaily: 0, lastPvAlert: 0, lastRetentionAlert: 0
});
const CONFIG_FALLBACK = () => ({ groups: {}, global: { ...clone(DEFAULT_GLOBAL) }, history: {} });
const stable = v => JSON.stringify(v, (k, x) => (k === 'updatedAt' ? undefined : x));

/* ---------------- configuração ---------------- */
export function readConfig() {
  const cfg = readCollection(COLLECTIONS.config, CONFIG_FALLBACK());
  cfg.groups ||= {};
  cfg.global = { ...clone(DEFAULT_GLOBAL), ...(cfg.global || {}) };
  cfg.history ||= {};
  return cfg;
}

export function getGroupConfig(groupId) {
  const cfg = readConfig();
  return { ...clone(DEFAULT_GROUP), ...(cfg.groups[groupId] || {}) };
}

export async function updateGroupConfig(groupId, mutator, now = Date.now(), meta = {}) {
  let result;
  await updateCollection(COLLECTIONS.config, cfg => {
    cfg.groups ||= {};
    cfg.global = { ...clone(DEFAULT_GLOBAL), ...(cfg.global || {}) };
    cfg.history ||= {};
    const current = { ...clone(DEFAULT_GROUP), ...(cfg.groups[groupId] || {}) };
    const before = clone(current);
    const next = mutator(current) || current;
    if (stable(before) !== stable(next)) {
      const list = cfg.history[groupId] ||= [];
      list.push({ at: now, by: meta.by || 'sistema', config: before });
      if (list.length > LIMITS.historyMax) cfg.history[groupId] = list.slice(-LIMITS.historyMax);
    }
    next.updatedAt = now;
    cfg.groups[groupId] = next;
    result = next;
    return cfg;
  }, CONFIG_FALLBACK());
  return result;
}

export function getHistory(groupId) { return [...(readConfig().history[groupId] || [])].reverse(); }

/** Restaura uma versão anterior (1 = a mais recente). Mantém o estado ativo/desativo atual. */
export async function restoreGroupConfig(groupId, index, now = Date.now(), meta = {}) {
  const list = getHistory(groupId);
  const entry = list[Number(index) - 1];
  if (!entry) return null;
  return updateGroupConfig(groupId, g => ({ ...clone(DEFAULT_GROUP), ...clone(entry.config), enabled: g.enabled && (entry.config.questions || []).length > 0 }), now, { by: meta.by || 'restauração' });
}

export function getGlobal() { return readConfig().global; }

export async function updateGlobal(mutator) {
  let result;
  await updateCollection(COLLECTIONS.config, cfg => {
    cfg.groups ||= {};
    cfg.history ||= {};
    const g = { ...clone(DEFAULT_GLOBAL), ...(cfg.global || {}) };
    result = mutator(g) || g;
    cfg.global = result;
    return cfg;
  }, CONFIG_FALLBACK());
  return result;
}

export function groupsJudgedBy(chatId) {
  const cfg = readConfig();
  const ids = Object.entries(cfg.groups).filter(([, g]) => g.judgeGroupId === chatId).map(([id]) => id);
  for (const r of allRounds()) if (r.judgeGroupId === chatId) ids.push(r.groupId);
  return [...new Set([chatId, ...ids])];
}

/** Interruptor global do ambiente: a Triagem só funciona com TRIAGEM_ENABLED=true (padrão: desligada). */
export function isGloballyEnabled() {
  return process.env.TRIAGEM_ENABLED === 'true';
}

export function isEmergencyOff() {
  return readConfig().global.emergencyOff === true || process.env.TRIAGEM_DISABLED === 'true';
}

export async function setEmergencyOff(value) {
  await updateGlobal(g => { g.emergencyOff = !!value; return g; });
  return !!value;
}

/* ---------------- rodadas ---------------- */
const ROUNDS_FALLBACK = { seq: {}, rounds: {} };
export function readRounds() {
  const data = readCollection(COLLECTIONS.rounds, ROUNDS_FALLBACK);
  data.seq ||= {};
  data.rounds ||= {};
  return data;
}

export function allRounds() { return Object.values(readRounds().rounds); }
export function getRound(id) { return readRounds().rounds[String(id || '').toUpperCase()] || null; }

export function getRoundByNumber(groupId, n) {
  const num = Number(n);
  return allRounds().filter(r => r.groupId === groupId && r.n === num && !r.isTest).sort((a, b) => b.createdAt - a.createdAt)[0] || null;
}

export function roundsForIds(ids, { groupId = null, includeTests = false } = {}) {
  return allRounds()
    .filter(r => (includeTests || !r.isTest) && (!groupId || r.groupId === groupId) && idsOverlap(r.ids, ids))
    .sort((a, b) => b.createdAt - a.createdAt);
}

export function openRoundsForIds(ids) {
  return allRounds().filter(r => OPEN_STATUSES.includes(r.status) && idsOverlap(r.ids, ids)).sort((a, b) => b.createdAt - a.createdAt);
}

function newRoundId(existing) {
  for (let i = 0; i < 20; i++) {
    const id = `TRG-${crypto.randomBytes(5).toString('hex').toUpperCase().slice(0, 8)}`;
    if (!existing[id]) return id;
  }
  throw new Error('Não foi possível gerar um ID de triagem único.');
}

/**
 * Cria a rodada de forma idempotente: se já existir uma rodada aberta ou
 * aguardando julgamento para a mesma pessoa no mesmo grupo, devolve a existente.
 */
export async function createRound({ groupId, groupName = '', ids, pushName = '', questions = [], expiresAt, isTest = false, identityVerified = true, extra = {} }, now = Date.now()) {
  const normalized = collectIds(ids);
  if (!groupId || !normalized.length) throw new Error('Rodada precisa de grupo e identidade.');
  let outcome;
  await updateCollection(COLLECTIONS.rounds, data => {
    data.seq ||= {}; data.rounds ||= {};
    const dup = Object.values(data.rounds).find(r =>
      r.groupId === groupId && !!r.isTest === !!isTest && idsOverlap(r.ids, normalized)
      && [...OPEN_STATUSES, STATUS.SUBMITTED].includes(r.status));
    if (dup) {
      const merged = collectIds(dup.ids, normalized);
      if (merged.length !== dup.ids.length) dup.ids = merged;
      outcome = { created: false, round: dup };
      return data;
    }
    const id = newRoundId(data.rounds);
    const n = isTest ? 0 : (data.seq[groupId] = (data.seq[groupId] || 0) + 1);
    const round = {
      id, n, groupId, groupName, ids: normalized, pushName, isTest: !!isTest, identityVerified,
      status: STATUS.PENDING, questions: clone(questions), answers: [], currentIndex: 0,
      createdAt: now, expiresAt, startedAt: null, submittedAt: null, lastActivityAt: now, lastQuestionAt: null,
      decidedAt: null, decidedBy: null, rejection: null, notes: [], pvChat: null, ...clone(extra)
    };
    data.rounds[id] = round;
    outcome = { created: true, round };
    return data;
  }, ROUNDS_FALLBACK);
  return outcome;
}

export async function updateRound(id, mutator) {
  const key = String(id || '').toUpperCase();
  let result = null;
  await updateCollection(COLLECTIONS.rounds, data => {
    data.rounds ||= {};
    const round = data.rounds[key];
    if (!round) return data;
    const next = mutator(round) || round;
    data.rounds[key] = next;
    result = next;
    return data;
  }, ROUNDS_FALLBACK);
  return result;
}

export async function deleteRound(id) {
  const key = String(id || '').toUpperCase();
  let removed = null;
  await updateCollection(COLLECTIONS.rounds, data => {
    data.rounds ||= {};
    removed = data.rounds[key] || null;
    delete data.rounds[key];
    return data;
  }, ROUNDS_FALLBACK);
  return removed;
}

/** Marca como expiradas as rodadas vencidas (sem timers: varredura sob demanda). */
export async function sweepExpired(now = Date.now(), groupId = null) {
  const changed = [];
  await updateCollection(COLLECTIONS.rounds, data => {
    data.rounds ||= {};
    for (const r of Object.values(data.rounds)) {
      if (groupId && r.groupId !== groupId) continue;
      const idleLimit = (r.lastActivityAt || r.createdAt) + LIMITS.idleHours * 3600_000;
      const due = (r.status === STATUS.PENDING && r.expiresAt && r.expiresAt < now)
        || (r.status === STATUS.IN_PROGRESS && idleLimit < now);
      if (due) { r.status = STATUS.EXPIRED; r.decidedAt = now; changed.push(r.id); }
    }
    return data;
  }, ROUNDS_FALLBACK);
  return changed;
}

/* ---------------- auditoria ---------------- */
export async function appendAudit(entry, now = Date.now()) {
  await updateCollection(COLLECTIONS.audit, data => {
    data.items ||= [];
    data.items.push({ at: now, ...entry });
    if (data.items.length > LIMITS.auditMax) data.items = data.items.slice(-LIMITS.auditMax);
    return data;
  }, { items: [] });
}

export function readAudit() { return readCollection(COLLECTIONS.audit, { items: [] }).items || []; }

export default { readConfig, getGroupConfig, updateGroupConfig, getHistory, restoreGroupConfig, getGlobal, updateGlobal, groupsJudgedBy, isGloballyEnabled, isEmergencyOff, setEmergencyOff, readRounds, allRounds, getRound, getRoundByNumber, roundsForIds, openRoundsForIds, createRound, updateRound, deleteRound, sweepExpired, appendAudit, readAudit };
