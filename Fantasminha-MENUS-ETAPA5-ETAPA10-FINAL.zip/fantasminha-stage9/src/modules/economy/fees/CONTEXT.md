# MODULE: Economy Fees

## Responsabilidade
Manter a política única de taxas configuráveis e expor leitura, alteração, reset e cálculo; fornecer a Wallet moderna e três cases legados de economia uma leitura atual e síncrona da taxa.

## Não é responsabilidade deste módulo
Não modifica saldos, não executa operações financeiras, não cria tesouro, não migra comandos públicos nem lê/escreve `economy.json` ou registros de usuários. O adapter legado só consome o getter.

## Como este módulo é usado
`fees.service.js` expõe `getFees`, `getRateBps`, `getFeeRateSync`, `setFee`, `resetFees`, `resolveFeeKey` (aliases de tipo digitados pelo dono) e participante somente-leitura para transações financeiras. O padrão não grava a coleção até a primeira alteração. `fees.presenter.js` só formata as respostas dos comandos. `dados/src/index.js` importa `getFeeRateSync` para saque, transferência e venda de marketplace; leitura falha retorna o default legado e registra aviso.

## Comandos
Três comandos, um por arquivo (`taxa.commands.js`, `edittaxa.commands.js`, `taxareset.commands.js`), todos de categoria `dono`, exclusivos do dono pelo mecanismo `Role.OWNER`/`ownerOnly` do Registry e listados **somente** no menu do dono, na seção "Taxas" (`dados/src/menus/menuMap.js`, id `taxas`):

- `×taxa` (aliases `taxas`, `fee`, `fees`): mostra as três taxas atuais, o padrão de cada uma e um exemplo prático.
- `×edittaxa <tipo> <valor>` (aliases `edittaxas`, `editartaxa`): altera uma taxa. Tipos: `sacar`/`saque`, `transferência`/`transferencia`/`transferir`/`pix`, `mercado` (sem distinção de maiúsculas ou acentos). Valor: 0 a 100, inteiro ou decimal (até duas casas), com ou sem `%`, vírgula ou ponto. Aplica direto, sem confirmação.
- `×taxareset` (aliases `resettaxa`, `resettaxas`): restaura 5 / 15 / 5, sem confirmação.

Não há comando nem subcomando de histórico. Não habilita comandos públicos Wallet.

## Dados
`fees.repository.js` usa a coleção dedicada `economy_fees` de `src/database/store.js` e armazena rates em basis points, mais autor e horário da última alteração (`updatedBy`/`updatedAt`); **não há histórico de alterações**. Um campo `history` de registros antigos é ignorado e some na próxima gravação. Não altera schema de usuários ou `economy.json`. O adapter JSON é exclusivo de testes temporários. As vendas legadas continuam usando sua base separada `dados/database/economy.json`.

## Dependências
Store moderno, API `src/platform/audit` e API pública de Fees consumida pelo adapter transitório em `dados/src/index.js`; Wallet usa somente a API pública do service.

## Dependências proibidas
Baileys, imports do repository interno Wallet, escrita direta em `dados/database`, importação integral/execução do dispatcher em testes, ou import de repositories de usuários.

## Eventos
Cada alteração/reset tenta registrar evento em `platform/audit` em melhor esforço (log técnico de plataforma, não consultável pelo usuário); se falhar, a alteração já gravada permanece. O Registry também audita a execução de todo comando `ownerOnly`. Operações Wallet registram `fee.saque`/`fee.transferencia` no ledger transacional moderno. A venda legada retém a taxa no pagamento líquido, mas ainda não a espelha como `fee.mercado` no ledger moderno, pois isso exigiria uma escrita cruzada não atômica.

## Concorrência
A leitura da taxa em operação Wallet é participante read-only (com lock entre processos) na mesma transação que modifica usuários e ledger. Default não persiste a coleção. Atualizações usam lock do store; não há cache. O getter legado é síncrono, lê o store por `getFeeRateSync` e faz fallback seguro ao default se a leitura falhar.

## Regras de negócio
Defaults: saque 5%, transferência 15%, mercado 5%. Faixa 0–100% (`MAX_FEE_RATE_BPS = 10000`), até duas casas decimais, armazenada em basis points, sem confirmação para valores altos nem para o reset. Extremos: com 0% não há cobrança nem entrada `fee.*` no ledger; com 100% o saque entrega 0 à carteira, a transferência exige `valor + taxa` (2× o valor) e falha com `INSUFFICIENT_FUNDS` sem alterar nada, e o vendedor do mercado recebe 0. A taxa usada fica gravada em cada operação, então mudar a taxa depois não reescreve as antigas. Saque/transferência usam `Math.floor(amount * rate)`. O mercado mantém a fórmula legada `Math.floor(price * (1 - rate))`, que pode reter uma moeda a mais devido ao arredondamento do líquido. Não mudar limites de carteira/banco nem adicionar tesouro.

## Testes
`npm run test:fees`, `npm run test:fees-command` (inclui permissões e visibilidade no menu), `npm run test:wallet`, `npm run test:wallet-concurrency`, `npm run test:wallet-runtime-concurrency` e `npm run test:wallet-legacy-regression`; sempre em `mkdtemp`/wrapper. Nenhum teste inicia o bot ou executa o dispatcher legado.

## Estado da migração
`parcial` — policy Fees e getter legado integrados; saques/transferências Wallet modernos usam Fees. Os comandos públicos Wallet permanecem `enabled: false`. A venda de mercado continua no storage legado e sem evento fee no ledger moderno; não há unificação de bancos.

## Riscos
`data/db` e `dados/database` continuam independentes. Limite de banco, bônus, tesouro e gravação de `fee.mercado` no ledger moderno ficam fora desta rodada. Defaults e fallback impedem operação sem taxa em falha de leitura.
