import { calculateFee, formatFeePercent } from './fees.service.js';
import { DEFAULT_FEE_RATES_BPS } from './fees.repository.js';

/** Textos e formatação das respostas dos comandos de taxa. Sem regra de negócio e sem Baileys. */
export const FEE_LABELS = Object.freeze({ saque: 'Saque', transferencia: 'Transferência', mercado: 'Mercado' });
export const FEE_TYPES_TEXT = 'sacar, transferência, mercado';
const fmt = value => Number(value).toLocaleString('pt-BR');

export function feeExample(key, rateBps) {
  const charge = calculateFee(100, rateBps);
  if (key === 'saque') return `Sacar 100 GC: taxa ${fmt(charge)} GC; recebe ${fmt(100 - charge)} GC.`;
  if (key === 'transferencia') return `Transferir 100 GC custa ${fmt(100 + charge)} GC ao remetente; o destino recebe 100 GC.`;
  return `Venda de 100 GC: taxa ${fmt(charge)} GC; o vendedor recebe ${fmt(100 - charge)} GC.`;
}

export function actorOf(ctx = {}) { return ctx.sender || ctx.senderOriginal || ctx.senderAlternate || ''; }

export function renderFeesOverview(record) {
  const rows = Object.keys(FEE_LABELS).map(key => {
    const current = record.ratesBps[key];
    return `• *${FEE_LABELS[key]}:* ${formatFeePercent(current)}% (padrão ${formatFeePercent(DEFAULT_FEE_RATES_BPS[key])}%)\n  ${feeExample(key, current)}`;
  });
  return `× 👻 *TAXAS DA ECONOMIA*\n\n${rows.join('\n\n')}\n\nAltere com ×edittaxa <tipo> <valor> ou restaure os padrões com ×taxareset.`;
}

export function renderFeeUpdated(result) {
  return `× 👻 *TAXA ATUALIZADA*\n\n${FEE_LABELS[result.feeKey]}: ${formatFeePercent(result.beforeBps)}% → ${formatFeePercent(result.afterBps)}%\n${feeExample(result.feeKey, result.afterBps)}`;
}

export function renderFeesReset(result) {
  const rows = result.changes.map(item => `• ${FEE_LABELS[item.feeKey]}: ${formatFeePercent(item.beforeBps)}% → ${formatFeePercent(item.afterBps)}%\n  ${feeExample(item.feeKey, item.afterBps)}`);
  return `× 👻 *TAXAS RESTAURADAS*\n\n${rows.join('\n\n')}`;
}

export function editUsage() {
  return `Uso: ×edittaxa <tipo> <valor>\nTipos: ${FEE_TYPES_TEXT}\nValor: de 0 a 100 (ex.: ×edittaxa sacar 2,5)`;
}
