import { Role } from '../../../core/permissions.js';
import { defineCommandContract } from '../../../core/command/contract.js';
import feesService from './fees.service.js';
import { actorOf, renderFeesReset } from './fees.presenter.js';

async function handler(ctx = {}) {
  try {
    return await ctx.reply?.(renderFeesReset(await feesService.resetFees(actorOf(ctx))));
  } catch (error) {
    return ctx.reply?.(`❌ ${error?.message || 'Não foi possível restaurar as taxas.'}`);
  }
}

export default defineCommandContract({
  name: 'taxareset', aliases: ['resettaxa', 'resettaxas'], category: 'dono', permission: Role.OWNER,
  ownerOnly: true, enabled: true, cooldown: 0, audit: true, publicName: 'Restaurar taxas',
  description: 'Restaura as taxas padrão: saque 5%, transferência 15% e mercado 5% (somente dono).',
  usage: '×taxareset',
  purpose: 'Volta as três taxas econômicas aos valores padrão do legado, sem pedir confirmação.',
  syntax: '×taxareset', examples: ['×taxareset'],
  authorization: { level: 'OWNER', ownerOnly: true },
  handler
});
