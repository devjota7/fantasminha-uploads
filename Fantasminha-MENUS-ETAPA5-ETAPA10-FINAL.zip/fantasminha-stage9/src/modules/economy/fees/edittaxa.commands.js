import { Role } from '../../../core/permissions.js';
import { defineCommandContract } from '../../../core/command/contract.js';
import feesService, { resolveFeeKey } from './fees.service.js';
import { actorOf, editUsage, renderFeeUpdated } from './fees.presenter.js';

async function handler(ctx = {}) {
  const args = Array.isArray(ctx.args) ? ctx.args.map(value => String(value ?? '').trim()).filter(Boolean) : [];
  if (!args.length) return ctx.reply?.(editUsage());
  try {
    const key = resolveFeeKey(args[0]);
    if (args.length < 2) return ctx.reply?.(`❌ Informe o valor da taxa.\n${editUsage()}`);
    // "5 %" chega como dois argumentos; junta o valor para aceitar o % separado.
    const result = await feesService.setFee(key, args.slice(1).join(' '), actorOf(ctx));
    return ctx.reply?.(renderFeeUpdated(result));
  } catch (error) {
    return ctx.reply?.(`❌ ${error?.message || 'Não foi possível alterar a taxa.'}`);
  }
}

export default defineCommandContract({
  name: 'edittaxa', aliases: ['edittaxas', 'editartaxa'], category: 'dono', permission: Role.OWNER,
  ownerOnly: true, enabled: true, cooldown: 0, audit: true, publicName: 'Editar taxa',
  description: 'Altera a taxa de saque, transferência ou mercado, de 0% a 100% (somente dono).',
  usage: '×edittaxa <tipo> <valor>',
  purpose: 'Define uma taxa econômica (sacar, transferência ou mercado) com qualquer percentual de 0 a 100.',
  syntax: '×edittaxa <tipo> <valor>',
  examples: ['×edittaxa sacar 10%', '×edittaxa transferência 2,5', '×edittaxa mercado 0', '×edittaxa pix 100'],
  authorization: { level: 'OWNER', ownerOnly: true },
  validation: { type: 'sacar | saque | transferência | transferir | pix | mercado', feePercent: '0–100, inteiro ou decimal (até duas casas), com ou sem %' },
  handler
});
