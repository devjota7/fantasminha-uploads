import fs from 'node:fs';
import path from 'node:path';
import { readCollection, updateCollection } from '../../../database/store.js';

export const FEES_COLLECTION = 'economy_fees';
export const FEE_KEYS = Object.freeze(['saque', 'transferencia', 'mercado']);
export const DEFAULT_FEE_RATES_BPS = Object.freeze({ saque: 500, transferencia: 1500, mercado: 500 });
/** Teto de uma taxa: 100% (10.000 pontos-base). Fonte única; fees.service.js reexporta. */
export const MAX_FEE_RATE_BPS = 10_000;

export function createDefaultFeesRecord() {
  return { version: 1, ratesBps: { ...DEFAULT_FEE_RATES_BPS }, updatedAt: null, updatedBy: null };
}

export function normalizeFeesRecord(value) {
  const source = value && typeof value === 'object' ? value : {};
  const storedRates = source.ratesBps && typeof source.ratesBps === 'object' ? source.ratesBps : {};
  const ratesBps = { ...DEFAULT_FEE_RATES_BPS };
  for (const key of FEE_KEYS) {
    const rate = storedRates[key];
    if (Number.isSafeInteger(rate) && rate >= 0 && rate <= MAX_FEE_RATE_BPS) ratesBps[key] = rate;
  }
  // Um campo `history` de registros antigos é ignorado (e some na próxima gravação).
  return {
    version: 1,
    ratesBps,
    updatedAt: Number.isFinite(source.updatedAt) ? source.updatedAt : null,
    updatedBy: typeof source.updatedBy === 'string' ? source.updatedBy : null
  };
}

function runtimeReadRateStep(key, capture) {
  return {
    collection: FEES_COLLECTION,
    readOnly: true,
    fallback: createDefaultFeesRecord(),
    update(record) {
      const normalized = normalizeFeesRecord(record);
      capture(normalized.ratesBps[key]);
      return record;
    }
  };
}

export const feesRepository = Object.freeze({
  collection: FEES_COLLECTION,
  getFees() { return normalizeFeesRecord(readCollection(FEES_COLLECTION, createDefaultFeesRecord())); },
  getFeesSync() { return normalizeFeesRecord(readCollection(FEES_COLLECTION, createDefaultFeesRecord())); },
  update(mutator) {
    return updateCollection(FEES_COLLECTION, current => mutator(normalizeFeesRecord(current)) ?? current, createDefaultFeesRecord());
  },
  createRateReadStep(key, capture) { return runtimeReadRateStep(key, capture); }
});

const queues = new Map();
function serialize(key, fn) {
  const previous = queues.get(key) || Promise.resolve();
  const current = previous.catch(() => {}).then(fn);
  const queued = current.then(() => undefined, () => undefined).finally(() => { if (queues.get(key) === queued) queues.delete(key); });
  queues.set(key, queued);
  return current;
}

/** Repository isolado para testes; não é usado pelo runtime. */
export function createJsonFeesRepository(root) {
  const file = path.join(root, 'fees-test.json');
  const read = () => {
    try { return normalizeFeesRecord(JSON.parse(fs.readFileSync(file, 'utf8'))); }
    catch (error) { if (error.code === 'ENOENT') return createDefaultFeesRecord(); throw error; }
  };
  const write = async value => {
    await fs.promises.mkdir(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
    await fs.promises.writeFile(tmp, JSON.stringify(value, null, 2));
    await fs.promises.rename(tmp, file);
  };
  return {
    getFees: read,
    getFeesSync: read,
    async update(mutator) {
      return serialize(file, async () => {
        const next = normalizeFeesRecord((await mutator(read())) || read());
        await write(next);
        return next;
      });
    },
    createRateReadStep() { return null; }
  };
}

export default feesRepository;
