import { Role } from '../../../core/permissions.js';
import { defineCommandContract } from '../../../core/command/contract.js';
import feesService from './fees.service.js';
import { renderFeesOverview } from './fees.presenter.js';

async function handler(ctx = {}) {
  try {
    return await ctx.reply?.(renderFeesOverview(await feesService.getFees()));
  } catch (error) {
    return ctx.reply?.(`❌ ${error?.message || 'Não foi possível consultar as taxas.'}`);
  }
}

export default defineCommandContract({
  name: 'taxa', aliases: ['taxas', 'fee', 'fees'], category: 'dono', permission: Role.OWNER,
  ownerOnly: true, enabled: true, cooldown: 0, audit: true, publicName: 'Taxas da economia',
  description: 'Mostra as taxas atuais de saque, transferência e mercado (somente dono).',
  usage: '×taxa',
  purpose: 'Consulta as taxas econômicas atuais, os padrões e um exemplo prático de cada uma.',
  syntax: '×taxa', examples: ['×taxa'],
  authorization: { level: 'OWNER', ownerOnly: true },
  handler
});
