import { recordAudit } from '../../../platform/audit/index.js';
import feesRepository, { DEFAULT_FEE_RATES_BPS, FEE_KEYS, MAX_FEE_RATE_BPS } from './fees.repository.js';

/** Faixa administrativa: 0% a 100% por operação (10.000 pontos-base). */
export { MAX_FEE_RATE_BPS };
const KEY_SET = new Set(FEE_KEYS);
const RANGE_TEXT = `entre 0% e ${MAX_FEE_RATE_BPS / 100}%`;

/** Nomes aceitos pelo dono (já sem acento e em minúsculas) -> chave canônica. */
const FEE_KEY_ALIASES = Object.freeze({
  saque: 'saque', sacar: 'saque',
  transferencia: 'transferencia', transferir: 'transferencia', pix: 'transferencia',
  mercado: 'mercado'
});

export class FeeError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'FeeError'; this.code = code; this.details = details; }
}

/** Normaliza texto digitado: minúsculas, sem acentos e sem espaços nas pontas. */
function plainText(value) {
  return String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
}

/** Resolve o tipo digitado pelo dono (sacar, saque, transferência, pix, mercado...) para a chave canônica. */
export function resolveFeeKey(input) {
  const text = plainText(input);
  const key = Object.hasOwn(FEE_KEY_ALIASES, text) ? FEE_KEY_ALIASES[text] : null;
  if (!key) throw new FeeError('UNKNOWN_FEE', `Tipo de taxa desconhecido: ${text || '(vazio)'}. Use sacar, transferência ou mercado.`);
  return key;
}

export function assertFeeKey(key) {
  const normalized = String(key ?? '').trim().toLowerCase();
  if (!KEY_SET.has(normalized)) throw new FeeError('UNKNOWN_FEE', `Taxa desconhecida: ${normalized || '(vazia)'}. Use saque, transferencia ou mercado.`);
  return normalized;
}

/** Converte percentual (0–100, até duas casas) em basis points sem aritmética decimal intermediária. */
export function parseFeePercent(value) {
  let text;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new FeeError('INVALID_FEE', `Valor de taxa inválido. Informe um percentual ${RANGE_TEXT}, com até duas casas decimais.`);
    text = String(value);
  } else if (typeof value === 'string') {
    text = value.trim();
    if (text.endsWith('%')) text = text.slice(0, -1).trim();
  } else {
    throw new FeeError('INVALID_FEE', `Valor de taxa inválido. Informe um percentual ${RANGE_TEXT}, com até duas casas decimais.`);
  }
  text = text.replace(',', '.');
  const match = text.match(/^(\d+)(?:\.(\d{1,2}))?$/);
  if (!match) throw new FeeError('INVALID_FEE', `Valor de taxa inválido. Informe um percentual ${RANGE_TEXT}, com até duas casas decimais.`);
  const whole = Number(match[1]);
  const fractional = Number((match[2] || '').padEnd(2, '0'));
  const rateBps = whole * 100 + fractional;
  if (!Number.isSafeInteger(rateBps) || rateBps < 0 || rateBps > MAX_FEE_RATE_BPS) {
    throw new FeeError('INVALID_FEE', `Taxa fora da faixa permitida. Use um percentual ${RANGE_TEXT}.`, { maxRateBps: MAX_FEE_RATE_BPS });
  }
  return rateBps;
}

export function formatFeePercent(rateBps) {
  const value = Number(rateBps) / 100;
  return Number.isFinite(value) ? value.toFixed(2).replace(/\.0+$|(?<=\.[0-9])0$/, '') : '0';
}

/** Reproduz deliberadamente Math.floor(amount * pct), como os cases legados. */
export function calculateFee(amount, rateBps) {
  if (!Number.isSafeInteger(amount) || amount < 0) throw new FeeError('INVALID_AMOUNT', 'Valor da operação inválido.');
  if (!Number.isSafeInteger(rateBps) || rateBps < 0 || rateBps > MAX_FEE_RATE_BPS) throw new FeeError('INVALID_FEE', 'Taxa persistida inválida.');
  return Math.floor(amount * (rateBps / 10_000));
}

export function createFeesService(repository = feesRepository) {
  const getFees = () => repository.getFees();
  const getRateBps = key => {
    const normalized = assertFeeKey(key);
    const fees = repository.getFeesSync ? repository.getFeesSync() : repository.getFees();
    return fees.ratesBps[normalized] ?? DEFAULT_FEE_RATES_BPS[normalized];
  };
  const createTransactionRateReader = key => {
    const normalized = assertFeeKey(key);
    return Object.freeze({
      key: normalized,
      defaultRateBps: DEFAULT_FEE_RATES_BPS[normalized],
      getCurrentRateBps: () => getRateBps(normalized),
      calculateFee,
      createTransactionReadStep(capture) {
        if (typeof repository.createRateReadStep !== 'function') return null;
        return repository.createRateReadStep(normalized, capture);
      }
    });
  };
  /** Log técnico de plataforma em melhor esforço; não é histórico consultável pelo usuário. */
  async function auditChange({ action, actor, feeKey = null, before = null, after = null, changes = [] }) {
    try {
      await recordAudit({
        actor, action, before, after, result: 'success',
        details: { feeKey, changes }
      });
    } catch {
      // Falha de auditoria de plataforma não desfaz a alteração já gravada.
    }
  }
  async function setFee(key, value, actor) {
    const normalized = assertFeeKey(key);
    const actorId = String(actor ?? '').trim();
    if (!actorId) throw new FeeError('INVALID_ACTOR', 'Não foi possível identificar quem solicitou a alteração.');
    const afterBps = parseFeePercent(value);
    const at = Date.now();
    let change;
    await repository.update(current => {
      const beforeBps = current.ratesBps[normalized];
      change = { action: 'set', feeKey: normalized, beforeBps, afterBps, actor: actorId, at };
      return {
        ...current,
        ratesBps: { ...current.ratesBps, [normalized]: afterBps },
        updatedAt: at, updatedBy: actorId
      };
    });
    await auditChange({ action: 'ECONOMY_FEE_SET', actor: actorId, feeKey: normalized, before: { rateBps: change.beforeBps }, after: { rateBps: change.afterBps } });
    return Object.freeze({ ...change, previous: change.beforeBps, current: change.afterBps, feeRate: afterBps / 100 });
  }
  async function resetFees(actor) {
    const actorId = String(actor ?? '').trim();
    if (!actorId) throw new FeeError('INVALID_ACTOR', 'Não foi possível identificar quem solicitou a alteração.');
    const at = Date.now();
    let changes = [];
    await repository.update(current => {
      changes = FEE_KEYS.map(feeKey => ({
        action: 'reset', feeKey, beforeBps: current.ratesBps[feeKey], afterBps: DEFAULT_FEE_RATES_BPS[feeKey], actor: actorId, at
      }));
      return {
        ...current,
        ratesBps: { ...DEFAULT_FEE_RATES_BPS },
        updatedAt: at, updatedBy: actorId
      };
    });
    await auditChange({ action: 'ECONOMY_FEES_RESET', actor: actorId, changes: changes.map(({ feeKey, beforeBps, afterBps }) => ({ feeKey, beforeBps, afterBps })) });
    return Object.freeze({ changes, ratesBps: { ...DEFAULT_FEE_RATES_BPS }, actor: actorId, at });
  }
  function getFeeRateSync(key) {
    let normalized;
    try {
      normalized = assertFeeKey(key);
      return getRateBps(normalized) / 10_000;
    } catch (error) {
      const fallbackKey = KEY_SET.has(String(key ?? '').trim().toLowerCase()) ? String(key).trim().toLowerCase() : 'saque';
      console.warn(`[fees] leitura síncrona falhou (${error?.message || error}); usando default legado para ${fallbackKey}`);
      return DEFAULT_FEE_RATES_BPS[fallbackKey] / 10_000;
    }
  }
  return Object.freeze({ getFees, getRateBps, getFeeRateSync, createTransactionRateReader, setFee, resetFees });
}

export const feesService = createFeesService();
export const { getFees, getRateBps, getFeeRateSync, setFee, resetFees } = feesService;
export default feesService;
