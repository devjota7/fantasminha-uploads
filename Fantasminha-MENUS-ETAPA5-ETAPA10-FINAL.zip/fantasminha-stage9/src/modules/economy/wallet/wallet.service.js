import runtimeRepository from './wallet.repository.js';
import runtimeFeesService from '../fees/fees.service.js';

export class WalletError extends Error {
  constructor(code, message) { super(message); this.name = 'WalletError'; this.code = code; }
}
export const MAX_AMOUNT = Number.MAX_SAFE_INTEGER;
function amount(value) {
  const n = Number(value);
  if (!Number.isSafeInteger(n) || n <= 0 || n > MAX_AMOUNT) throw new WalletError('INVALID_AMOUNT', 'Valor inválido.');
  return n;
}
function mapError(error) {
  // O runtime lança ValidationError (code VALIDATION) para saldo/banco insuficiente; o adapter JSON já usa INSUFFICIENT_FUNDS.
  const semCodigoEspecifico = !error?.code || error.code === 'VALIDATION';
  if (semCodigoEspecifico && /saldo insuficiente|banco insuficiente/i.test(error?.message || '')) return new WalletError('INSUFFICIENT_FUNDS', error.message);
  return error;
}

export function createWalletService(repository = runtimeRepository, feesService = runtimeFeesService) {
  if (!repository) throw new TypeError('Wallet repository obrigatório');
  if (!feesService || typeof feesService.createTransactionRateReader !== 'function') throw new TypeError('Fees service obrigatório');
  const call = async (fn, ...args) => { try { return await fn(...args); } catch (error) { throw mapError(error); } };
  return Object.freeze({
    getBalance: userId => call(repository.getBalance, userId),
    credit: (userId, value, meta = {}) => call(repository.credit, userId, amount(value), meta),
    debit: (userId, value, meta = {}) => call(repository.debit, userId, amount(value), meta),
    transfer: (from, to, value, meta = {}) => {
      if (!from || !to || from === to) throw new WalletError('INVALID_TRANSFER', 'Transferência inválida.');
      const reader = feesService.createTransactionRateReader('transferencia');
      return call(repository.transferWithFee, from, to, amount(value), meta, reader);
    },
    deposit: (userId, value) => call(repository.deposit, userId, amount(value)),
    withdraw: (userId, value, meta = {}) => {
      const reader = feesService.createTransactionRateReader('saque');
      return call(repository.withdrawWithFee, userId, amount(value), meta, reader);
    }
  });
}

export const walletService = createWalletService();
export const { getBalance, credit, debit, transfer, deposit, withdraw } = walletService;
export default walletService;
