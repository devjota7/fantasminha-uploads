import fs from 'node:fs/promises';
import path from 'node:path';
import * as modernEconomy from '../../../services/economy.js';

const queues = new Map();
const serialize = (key, fn) => {
  const previous = queues.get(key) || Promise.resolve();
  const current = previous.catch(() => {}).then(fn);
  const queued = current.then(() => undefined, () => undefined).finally(() => { if (queues.get(key) === queued) queues.delete(key); });
  queues.set(key, queued);
  return current;
};

/** Adapter de runtime: mantém usuários, ledger e locks no banco moderno. */
export const runtimeWalletRepository = Object.freeze({
  getBalance: userId => modernEconomy.getBalance(userId),
  credit: (userId, amount, meta) => modernEconomy.credit(userId, amount, meta?.reason || 'wallet.credit', meta?.name || '', meta?.operationId || null),
  debit: (userId, amount, meta) => modernEconomy.debit(userId, amount, meta?.reason || 'wallet.debit', meta?.name || '', meta?.operationId || null),
  transferWithFee: (from, to, amount, meta, feeReader) => modernEconomy.transferWithFee(from, to, amount, meta, feeReader),
  deposit: (userId, amount) => modernEconomy.deposit(userId, amount),
  withdrawWithFee: (userId, amount, meta, feeReader) => modernEconomy.withdrawWithFee(userId, amount, meta, feeReader)
});

function initial() { return { users: {}, ledger: [] }; }
async function read(file) {
  try {
    const data = JSON.parse(await fs.readFile(file, 'utf8'));
    data.users ??= {}; data.ledger ??= [];
    return data;
  } catch (error) { if (error.code === 'ENOENT') return initial(); throw error; }
}
async function write(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(value, null, 2));
  await fs.rename(tmp, file);
}
function ensureJsonUser(data, userId) {
  data.users[userId] ||= { wallet: 0, bank: 0, operations: {} };
  const user = data.users[userId];
  user.wallet = Number(user.wallet || 0); user.bank = Number(user.bank || 0); user.operations ??= {};
  return user;
}
function requireFeeReader(reader, key) {
  if (reader?.key !== key || typeof reader.getCurrentRateBps !== 'function' || typeof reader.calculateFee !== 'function') throw new Error('Leitor de taxas inválido.');
  const rateBps = reader.getCurrentRateBps();
  if (!Number.isSafeInteger(rateBps) || rateBps < 0 || rateBps > 10_000) throw new Error('Taxa inválida.'); // 0–100%, mesmo teto de Fees
  return rateBps;
}
function feeResult(amount, rateBps, feeReader, net = amount) {
  return { amount, fee: feeReader.calculateFee(amount, rateBps), net, feeRate: rateBps / 100, feeRateBps: rateBps };
}
function appendLedger(data, entries) {
  data.ledger.push(...entries);
  if (data.ledger.length > 5000) data.ledger = data.ledger.slice(-3000);
}
function sameOperation(entry, { reason, userId, amount, to = null }) {
  const recordedAmount = Number(entry.requestedAmount ?? (reason === 'transfer_out' ? Math.abs(Number(entry.amount || 0)) : entry.amount));
  return entry.reason === reason && entry.userId === userId && recordedAmount === amount && (reason !== 'transfer_out' || entry.to === to);
}
function duplicateResult(entry, amount, feeReader) {
  const feeRateBps = Number(entry.feeRateBps ?? feeReader.getCurrentRateBps());
  const fee = Number(entry.fee || 0);
  const net = Number(entry.net ?? (amount - fee));
  return { amount, fee, net, feeRate: feeRateBps / 100, feeRateBps, duplicate: true };
}

/** Repository isolado para integração; nunca é usado pelo runtime. */
export function createJsonWalletRepository(root) {
  const file = path.join(root, 'wallet-test.json');
  const mutate = (userId, fn) => serialize(file, async () => {
    const data = await read(file); const user = ensureJsonUser(data, userId);
    const result = await fn(user, data);
    await write(file, data);
    return result;
  });
  return {
    async getBalance(userId) {
      const data = await read(file); const user = data.users[userId] || { wallet: 0, bank: 0 };
      return { wallet: user.wallet, bank: user.bank, total: user.wallet + user.bank };
    },
    credit: (userId, amount, meta = {}) => mutate(userId, (user, data) => {
      if (meta.operationId && user.operations[meta.operationId]) return user;
      user.wallet += amount;
      if (meta.operationId) user.operations[meta.operationId] = { reason: 'credit', amount };
      return user;
    }),
    debit: (userId, amount, meta = {}) => mutate(userId, (user, data) => {
      if (meta.operationId && user.operations[meta.operationId]) return user;
      if (user.wallet < amount) throw Object.assign(new Error('Saldo insuficiente.'), { code: 'INSUFFICIENT_FUNDS' });
      user.wallet -= amount;
      if (meta.operationId) user.operations[meta.operationId] = { reason: 'debit', amount };
      return user;
    }),
    async transferWithFee(from, to, amount, meta = {}, feeReader) {
      return serialize(file, async () => {
        const data = await read(file);
        const operationId = meta.operationId || null;
        const existing = operationId && data.ledger.find(entry => entry.operationId === operationId);
        if (existing) {
          if (!sameOperation(existing, { reason: 'transfer_out', userId: from, amount, to })) throw Object.assign(new Error('Identificador de operação já utilizado.'), { code: 'OPERATION_ID_CONFLICT' });
          return duplicateResult(existing, amount, feeReader);
        }
        const fromUser = ensureJsonUser(data, from), toUser = ensureJsonUser(data, to);
        const rateBps = requireFeeReader(feeReader, 'transferencia');
        const result = feeResult(amount, rateBps, feeReader, amount);
        const totalDebit = amount + result.fee;
        if (!Number.isSafeInteger(totalDebit)) throw Object.assign(new Error('Valor total da transferência inválido.'), { code: 'INVALID_AMOUNT' });
        if (fromUser.wallet < totalDebit) throw Object.assign(new Error('Saldo insuficiente para valor e taxa da transferência.'), { code: 'INSUFFICIENT_FUNDS' });
        if (toUser.wallet + amount > modernEconomy.MAX_WALLET) throw Object.assign(new Error('Carteira do destinatário atingiu o limite.'), { code: 'WALLET_LIMIT' });
        fromUser.wallet -= totalDebit; toUser.wallet += amount;
        if (operationId) {
          const op = { amount, fee: result.fee, net: amount, feeRateBps: rateBps };
          fromUser.operations[operationId] = { ...op, reason: 'transfer_out', to };
          toUser.operations[operationId] = { ...op, reason: 'transfer_in', from };
        }
        const at = Date.now();
        const entries = [
          { userId: from, amount: -amount, reason: 'transfer_out', to, requestedAmount: amount, fee: result.fee, net: amount, feeRateBps: rateBps, operationId, at },
          { userId: to, amount, reason: 'transfer_in', from, operationId, at }
        ];
        if (result.fee > 0) entries.push({ userId: from, amount: -result.fee, reason: 'fee.transferencia', feeKey: 'transferencia', feeRateBps: rateBps, operationId, at });
        appendLedger(data, entries); await write(file, data); return result;
      });
    },
    deposit: (userId, amount) => mutate(userId, user => {
      if (user.wallet < amount) throw Object.assign(new Error('Saldo insuficiente.'), { code: 'INSUFFICIENT_FUNDS' });
      user.wallet -= amount; user.bank += amount; return user;
    }),
    withdraw: (userId, amount) => mutate(userId, user => {
      if (user.bank < amount) throw Object.assign(new Error('Saldo insuficiente no banco.'), { code: 'INSUFFICIENT_FUNDS' });
      user.bank -= amount; user.wallet += amount; return user;
    }),
    async withdrawWithFee(userId, amount, meta = {}, feeReader) {
      return serialize(file, async () => {
        const data = await read(file);
        const operationId = meta.operationId || null;
        const existing = operationId && data.ledger.find(entry => entry.operationId === operationId);
        if (existing) {
          if (!sameOperation(existing, { reason: 'withdraw', userId, amount })) throw Object.assign(new Error('Identificador de operação já utilizado.'), { code: 'OPERATION_ID_CONFLICT' });
          return duplicateResult(existing, amount, feeReader);
        }
        const user = ensureJsonUser(data, userId);
        const rateBps = requireFeeReader(feeReader, 'saque');
        const result = feeResult(amount, rateBps, feeReader, amount - feeReader.calculateFee(amount, rateBps));
        if (user.bank < amount) throw Object.assign(new Error('Banco insuficiente.'), { code: 'INSUFFICIENT_FUNDS' });
        user.bank -= amount;
        user.wallet = Math.min(modernEconomy.MAX_WALLET, user.wallet + result.net);
        if (operationId) user.operations[operationId] = { reason: 'withdraw', amount, fee: result.fee, net: result.net, feeRateBps: rateBps };
        const at = Date.now();
        const entries = [{ userId, amount, reason: 'withdraw', requestedAmount: amount, fee: result.fee, net: result.net, feeRateBps: rateBps, operationId, at }];
        if (result.fee > 0) entries.push({ userId, amount: -result.fee, reason: 'fee.saque', feeKey: 'saque', feeRateBps: rateBps, operationId, at });
        appendLedger(data, entries); await write(file, data); return result;
      });
    }
  };
}

export default runtimeWalletRepository;
