# MODULE: Wallet

## Responsabilidade
Expor operações de saldo/transferência com validação, erros tipados e repository injetável. Saque e transferência consultam Fees e registram a taxa queimada no ledger.

## Não é responsabilidade deste módulo
Não migra o marketplace legado, não altera formatos de `data/db` ou `dados/database`, não trata inventário/loja, WhatsApp ou Baileys.

## Como este módulo é usado
O service oferece `getBalance`, `credit`, `debit`, `transfer`, `deposit` e `withdraw`. `transfer`/`withdraw` aceitam metadados, incluindo `operationId`, e retornam `{ fee, net, feeRate, feeRateBps }`. O adapter runtime usa `src/services/economy.js`; o repository JSON serve exclusivamente a testes temporários.

## Comandos
`walletsaldo`, `walletcreditar`, `walletdebitar`, `wallettransferir` continuam `enabled: false` até validação humana. `taxa`, `edittaxa` e `taxareset` pertencem ao domínio Fees, são owner-only, aparecem só no menu do dono e não habilitam comandos públicos Wallet.

## Dados
Runtime delega a `data/db/users.json` e `data/db/economy_ledger.json`; entradas `fee.saque`/`fee.transferencia` guardam fee e rate observada sem mudar schema de usuário. A taxa é lida como participante read-only com lock na mesma transação de saldos/ledger. Testes usam diretórios temporários. Marketplace mantém a base legada `dados/database/economy.json`.

## Dependências
`src/services/economy.js` somente pelo adapter; Fees pela API pública `fees.service.js`.

## Dependências proibidas
Baileys, `dados/src/index.js` como import de runtime, `dados/database/economy.json` pelo Wallet, `menuMap` e repositories internos de outros módulos.

## Eventos
Operações Wallet passam pelo ledger/auditoria moderna; fee/rate ficam no ledger para replay histórico. A taxa de venda legada do mercado ainda não tem evento no ledger moderno, por manter-se em outra base e fora da transação Wallet.

## Concorrência
O adapter runtime delega ao store/transações com lock entre processos, incluindo leitura de taxa. O repository JSON de teste usa fila por arquivo e a mesma semântica de fees/idempotência.

## Regras de negócio
Valores são inteiros seguros e positivos; débitos não deixam saldo negativo. Transferência não permite auto-transferência. Defaults: saque 5%, transferência 15%; a taxa configurada pode ir de 0% a 100% e o cálculo é `Math.floor(amount * rate)`. A 0% não há cobrança nem entrada `fee.*`; a 100% o saque entrega 0 à carteira e a transferência exige `valor + taxa`, falhando com `INSUFFICIENT_FUNDS` sem alterar nada. Saldo/banco insuficiente vira `INSUFFICIENT_FUNDS` tanto no adapter JSON quanto no runtime (`mapError` converte o `ValidationError` do runtime). Saque desconta taxa do valor sacado; transferência cobra taxa extra do remetente e credita o valor solicitado ao destinatário. Replay do mesmo `operationId` não recobra nem altera o rate registrado. Limites de carteira/banco e `deposit` não foram alterados.

## Testes
`test:wallet`, `test:wallet-concurrency`, `test:wallet-runtime-concurrency` e `test:wallet-legacy-regression` cobrem formulas, idempotência, atomicidade, alteração concorrente de taxas e comparação estática via extrator. Nunca executam o dispatcher.

## Estado da migração
`parcial` — Wallet moderna integrada com Fees; getters de taxa substituíram os três percentuais fixos nos cases legados. Comandos públicos Wallet permanecem desativados; não houve validação humana de produção.

## Riscos
As duas bases permanecem independentes e a comparação encontrou diferenças de teto já existentes. Não ativar aliases públicos. Capacidade máxima do banco, bônus, tesouro e espelhamento de `fee.mercado` no ledger moderno ficam pendentes.
