import { getBalance } from './wallet.service.js';

export default {
  name: 'walletsaldo',
  aliases: ['walletbalance'],
  category: 'economia',
  description: 'Consulta a Wallet migrada (ainda não ativada publicamente).',
  usage: 'walletsaldo',
  enabled: false,
  hidden: true,
  legacyBridge: true,
  handler: async ctx => {
    const userId = ctx.sender || ctx.from;
    const balance = await getBalance(userId);
    return ctx.reply?.(`Carteira: ${balance.wallet} GC | Banco: ${balance.bank} GC`);
  }
};
