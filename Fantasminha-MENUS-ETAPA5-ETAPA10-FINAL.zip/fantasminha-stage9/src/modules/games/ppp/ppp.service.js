import { randomInt as cryptoRandomInt } from 'node:crypto';
import {
  PPP_OPENINGS,
  PPP_BODIES,
  PPP_CLOSINGS,
  renderPPPCaption,
  renderPPPCooldown
} from './ppp.texts.js';

export const PPP_COOLDOWN_MS = 30_000;

const cooldowns = new Map();
const lastCombinations = new Map();

function nowDefault() { return Date.now(); }
function randomIndex(max) { return cryptoRandomInt(max); }
function normalize(value) { return String(value || '').trim().toLowerCase(); }

function participantIdentifiers(participant) {
  if (participant && typeof participant === 'object') {
    return [participant.id, participant.jid, participant.participant, participant.lid, participant.phoneNumber, participant.pn, participant.phone, participant.number]
      .filter(Boolean).map(normalize);
  }
  return [participant].filter(Boolean).map(normalize);
}

function cleanup(now) {
  for (const [groupId, timestamp] of cooldowns) {
    if (now - timestamp >= PPP_COOLDOWN_MS) cooldowns.delete(groupId);
  }
  for (const [groupId, value] of lastCombinations) {
    if (now - value.at >= PPP_COOLDOWN_MS * 2) lastCombinations.delete(groupId);
  }
}

function reserveGroup(groupId, now) {
  cleanup(now);
  const previous = cooldowns.get(groupId);
  if (previous !== undefined) {
    const remainingMs = PPP_COOLDOWN_MS - (now - previous);
    if (remainingMs > 0) return { ok: false, remainingMs };
    cooldowns.delete(groupId);
  }
  cooldowns.set(groupId, now);
  return { ok: true };
}

function chooseCombination(groupId, now, random = randomIndex) {
  let openingIndex = random(PPP_OPENINGS.length);
  let bodyIndex = random(PPP_BODIES.length);
  let closingIndex = random(PPP_CLOSINGS.length);
  const previous = lastCombinations.get(groupId)?.key;
  const key = `${openingIndex}:${bodyIndex}:${closingIndex}`;
  if (previous === key) {
    closingIndex = (closingIndex + 1) % PPP_CLOSINGS.length;
  }
  const finalKey = `${openingIndex}:${bodyIndex}:${closingIndex}`;
  lastCombinations.set(groupId, { key: finalKey, at: now });
  return { openingIndex, bodyIndex, closingIndex, key: finalKey };
}

export function executePPP({
  groupId,
  participants = [],
  excludedIds = [],
  now = nowDefault,
  randomInt = randomIndex
} = {}) {
  if (!groupId) return { ok: false, reason: 'missing-group' };
  const current = now();
  const reservation = reserveGroup(groupId, current);
  if (!reservation.ok) {
    return {
      ok: false,
      reason: 'cooldown',
      remainingMs: reservation.remainingMs,
      message: renderPPPCooldown(reservation.remainingMs / 1000)
    };
  }

  const excluded = new Set(excludedIds.flatMap(participantIdentifiers));
  const candidates = participants.filter(participant => {
    const ids = participantIdentifiers(participant);
    return ids.length > 0 && !ids.some(id => excluded.has(id));
  });

  if (!candidates.length) {
    cooldowns.delete(groupId);
    return { ok: false, reason: 'no-target' };
  }

  const target = candidates[randomInt(candidates.length)];
  const combination = chooseCombination(groupId, current, randomInt);
  return {
    ok: true,
    target,
    combination,
    caption: null,
    cooldownMs: PPP_COOLDOWN_MS
  };
}

export function buildPPPCaption(result, mentionText) {
  if (!result?.ok || !result.combination) throw new Error('Resultado PPP inválido.');
  const { openingIndex, bodyIndex, closingIndex } = result.combination;
  return renderPPPCaption({
    opening: PPP_OPENINGS[openingIndex],
    body: PPP_BODIES[bodyIndex],
    closing: PPP_CLOSINGS[closingIndex],
    mentionText
  });
}

export function resetPPPStateForTests() {
  cooldowns.clear();
  lastCombinations.clear();
}

export default { executePPP, buildPPPCaption, resetPPPStateForTests, PPP_COOLDOWN_MS };
