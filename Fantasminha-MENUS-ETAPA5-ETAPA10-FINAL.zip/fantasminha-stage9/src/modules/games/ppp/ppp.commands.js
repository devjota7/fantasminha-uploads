import { defineCommandContract } from '../../../core/command/contract.js';
import { Role } from '../../../core/permissions.js';
import logger from '../../../core/logger.js';
import { resolveUserIdentity, resolveBotIdentity } from '../../../platform/identity/resolver.js';
import { profilePhotoOrDefault } from '../../../shared/assets/defaults.js';
import { executePPP, buildPPPCaption } from './ppp.service.js';
import { PPP_POLL } from './ppp.texts.js';

function participantId(value) {
  if (value && typeof value === 'object') return value.id || value.jid || value.participant || value.lid || value.phoneNumber || value.number || null;
  return value || null;
}

function candidateIds(value) {
  if (value && typeof value === 'object') return [value.id, value.jid, value.participant, value.lid, value.phoneNumber, value.pn, value.phone, value.number].filter(Boolean);
  return [value].filter(Boolean);
}

const PN_SUFFIX = '@s.whatsapp.net';
const LID_SUFFIX = '@lid';
const userPart = jid => String(jid).split('@')[0].split(':')[0];

function asPnJid(value) {
  if (!value) return null;
  const text = String(value).trim();
  if (text.endsWith(PN_SUFFIX)) return `${userPart(text)}${PN_SUFFIX}`;
  if (text.includes('@')) return null;
  const digits = text.replace(/\D/g, '');
  return digits ? `${digits}${PN_SUFFIX}` : null;
}

function asLidJid(value) {
  const text = String(value || '').trim();
  return text.endsWith(LID_SUFFIX) ? `${userPart(text)}${LID_SUFFIX}` : null;
}

// Monta uma MENÇÃO de verdade: o texto "@x" e o JID em `mentions` sempre
// saem do MESMO identificador. Nunca há "@número" escrito sem menção real.
// Preferência: JID de telefone (padrão do projeto); se o telefone não puder
// ser resolvido, menciona pelo próprio JID @lid do participante (o WhatsApp
// exibe o nome do contato). Os dígitos do LID nunca são tratados como telefone.
function buildMention(identity, raw) {
  const pnCandidates = [identity?.realJid, raw?.phoneNumber, raw?.pn, raw?.phone, raw?.number, participantId(raw)];
  for (const candidate of pnCandidates) {
    const jid = asPnJid(candidate);
    if (jid) return { jid, text: `@${userPart(jid)}`, kind: 'pn' };
  }
  const lidCandidates = [identity?.lid, raw?.lid, participantId(raw)];
  for (const candidate of lidCandidates) {
    const jid = asLidJid(candidate);
    if (jid) return { jid, text: `@${userPart(jid)}`, kind: 'lid' };
  }
  return null;
}

function photoContent(photo) {
  if (typeof photo === 'string') return { url: photo };
  return photo;
}

async function handler(ctx = {}) {
  if (!ctx.isGroup) return ctx.reply?.('👻 Esse julgamento só acontece em grupos.');

  const participants = Array.isArray(ctx.groupParticipantObjects) && ctx.groupParticipantObjects.length
    ? ctx.groupParticipantObjects
    : (Array.isArray(ctx.groupParticipants) ? ctx.groupParticipants : []);

  let botIdentity = null;
  try { botIdentity = await resolveBotIdentity(ctx, ctx.from); } catch (error) { logger.warn('ppp', 'falha ao resolver identidade do bot', { message: error?.message }); }

  const excludedIds = [
    ...(botIdentity?.candidates || []),
    botIdentity?.realJid,
    botIdentity?.lid,
    ctx.botJid,
    ...(Array.isArray(ctx.botAliases) ? ctx.botAliases : []),
    ...(Array.isArray(ctx.subBotJids) ? ctx.subBotJids : [])
  ].filter(Boolean);

  const result = executePPP({
    groupId: ctx.from,
    participants,
    excludedIds,
    now: typeof ctx.now === 'function' ? ctx.now : Date.now,
    randomInt: typeof ctx.randomInt === 'function' ? ctx.randomInt : undefined
  });

  if (!result.ok) {
    if (result.reason === 'cooldown') return ctx.reply?.(result.message);
    if (result.reason === 'no-target') return ctx.reply?.('🪦 Não encontrei ninguém além do próprio Fantasminha para julgar.');
    return ctx.reply?.('🕯️ O Além não encontrou um grupo válido para o julgamento.');
  }

  const rawTarget = result.target;
  const rawTargetId = participantId(rawTarget);
  const identity = await resolveUserIdentity(ctx, rawTargetId);
  const mention = buildMention(identity, rawTarget);
  if (!mention) {
    logger.error('ppp', 'participante sem identidade mencionável');
    return ctx.reply?.('🕯️ O Além não conseguiu identificar corretamente o escolhido. Tente novamente.');
  }

  const caption = buildPPPCaption(result, mention.text);
  const photo = await profilePhotoOrDefault(ctx, mention.jid);
  let photoSent = false;

  try {
    if (!photo) throw new Error('Foto do participante e fallback padrão indisponíveis.');
    await ctx.sendMessage?.(ctx.from, {
      image: photoContent(photo),
      caption,
      mentions: [mention.jid]
    });
    photoSent = true;
  } catch (error) {
    logger.error('ppp', 'falha ao enviar foto do julgamento', { message: error?.message });
    await ctx.reply?.(`${caption}\n\n🕯️ A imagem não atravessou o véu, mas o julgamento continua.`).catch?.(() => {});
  }

  try {
    if (typeof ctx.sendPoll !== 'function') throw new Error('Envio de enquete indisponível no contexto.');
    await ctx.sendPoll(ctx.from, PPP_POLL);
  } catch (error) {
    logger.error('ppp', 'falha ao enviar enquete do julgamento', { message: error?.message, photoSent });
    await ctx.reply?.(`${caption}\n\n⚖️ A enquete falhou. Julguem por mensagem: Passo, Penso ou Pego.`).catch?.(() => {});
  }

  return { ok: true, target: rawTargetId, photoSent };
}

export default defineCommandContract({
  name: 'ppp',
  aliases: ['passopensopego', 'passopenso'],
  category: 'jogos',
  description: 'Sorteia alguém do grupo para ser julgado: passo, penso ou pego.',
  usage: '×ppp',
  purpose: 'Sorteia um participante e envia uma enquete de escolha única para o grupo.',
  syntax: '×ppp',
  examples: ['×ppp'],
  groupOnly: true,
  permission: Role.USER,
  cooldown: 0,
  visibleInMenu: true,
  enabled: true,
  handler
});
