# MODULE: ppp

## Responsabilidade
Executar a brincadeira de grupo `×ppp` (Passo, Penso ou Pego): reservar o cooldown por grupo, sortear um participante elegível e montar a legenda usando os textos aprovados.

## Não é responsabilidade deste módulo
Persistir dados, alterar economia, administrar grupos, conhecer Baileys diretamente ou decidir regras de outros jogos.

## Como este módulo é usado
`executePPP()` recebe o grupo, participantes, identidades excluídas e fontes injetáveis de relógio/aleatoriedade. `buildPPPCaption()` transforma a combinação escolhida em legenda.

## Comandos
- `ppp`
- aliases: `passopensopego`, `passopenso`

## Dados
Nenhum repository e nenhum banco. O estado é somente memória de processo para cooldown e última combinação por grupo.

## Dependências
- `core/command/contract` para o contrato do comando.
- `platform/identity` para resolver PN/LID e excluir o bot.
- `shared/assets/defaults` para foto padrão.
- `platform/whatsapp/messages` é exposto pelo contexto; o módulo não importa Baileys.

## Dependências proibidas
Baileys, repositories de outros módulos, `data/db`, `dados/database`, `dados/midias` e APIs externas.

## Eventos
Nenhum.

## Concorrência
`PPP_COOLDOWN_MS = 30000`. A reserva do grupo ocorre de forma síncrona antes do primeiro `await`, portanto chamadas concorrentes no mesmo processo não conseguem reservar o mesmo grupo duas vezes.

## Regras de negócio
- Só grupo.
- O executor pode ser sorteado.
- O bot principal e sub-bots conhecidos são excluídos.
- Todos os demais participantes podem ser sorteados, independentemente de admin/dono/fundador.
- A legenda usa exatamente uma abertura, um corpo e um fechamento aprovados.
- Enquete: `⚖️ Julguem ele(a)` com `Passo`, `Penso`, `Pego`, escolha única.
- Falha de foto não impede tentativa da enquete; falha de enquete gera fallback em texto.

## Testes
`npm run test:ppp` cobre seleção, exclusões, 64 combinações, LID, foto padrão, enquete, falhas, cooldown e concorrência.

## Estado da migração
`parcial` — comando novo, sem legado a remover.

## Riscos
A marcação de um participante LID depende da resolução PN disponível no contexto do WhatsApp. Se a resolução falhar e não houver `phoneNumber`/PN no objeto do participante, o comando responde sem enviar uma marcação incorreta.
