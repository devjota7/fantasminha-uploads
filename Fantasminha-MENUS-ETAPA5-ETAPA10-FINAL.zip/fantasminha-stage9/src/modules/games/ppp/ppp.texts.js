export const PPP_TITLE = '👻 *JOGO: PASSO, PENSO OU PEGO* 🩸';

export const PPP_OPENINGS = Object.freeze([
  '🌑 *As luzes piscaram... e alguém foi escolhido.*',
  '🕯️ *O Além me sussurrou um nome. Eu tentei ignorar, mas ele insistiu.*',
  '👁️ *Tem alguém no grupo que eu estava observando há um tempo... desculpa, é o meu trabalho.*',
  '🪦 *Desenterrei um nome do cemitério de membros inativos...*'
]);

export const PPP_BODIES = Object.freeze([
  '@fulano foi pego(a) no flagra! 👻 Nem o Além te protege agora.',
  '@fulano não escapou dos olhos do Fantasminha! 👁️ Corra... ou não, já é tarde.',
  '@fulano apareceu no meu radar sobrenatural! 🔮 Suas últimas palavras foram "só entrei pra olhar".',
  '@fulano foi arrastado(a) para o julgamento! ⚰️ Sem advogado, sem apelação.'
]);

export const PPP_CLOSINGS = Object.freeze([
  'Eu, obviamente, não me importo... mas a curiosidade me consome. Julguem! 🌒',
  'Não tenho opinião formada. Só quero ver vocês se condenando. 👀',
  'O silêncio do grupo já disse muita coisa. Agora votem. 🩸',
  'Não vou dizer o que eu penso. Mas anotei o voto de cada um de vocês. 📓'
]);

export const PPP_COOLDOWN_TEXT = '🕯️ O Além ainda está se recuperando do último julgamento. Volte em {N}s.';
export const PPP_POLL = Object.freeze({
  name: '⚖️ Julguem ele(a)',
  options: Object.freeze(['Passo', 'Penso', 'Pego']),
  selectableCount: 1
});

export function renderPPPBody(body, mentionText) {
  return body.replace('@fulano', mentionText);
}

export function renderPPPCaption({ opening, body, closing, mentionText }) {
  return [
    PPP_TITLE,
    '',
    opening,
    '',
    renderPPPBody(body, mentionText),
    '',
    closing
  ].join('\n');
}

export function renderPPPCooldown(seconds) {
  return PPP_COOLDOWN_TEXT.replace('{N}', String(Math.max(1, Math.ceil(seconds))));
}

export default {
  PPP_TITLE,
  PPP_OPENINGS,
  PPP_BODIES,
  PPP_CLOSINGS,
  PPP_COOLDOWN_TEXT,
  PPP_POLL,
  renderPPPBody,
  renderPPPCaption,
  renderPPPCooldown
};
