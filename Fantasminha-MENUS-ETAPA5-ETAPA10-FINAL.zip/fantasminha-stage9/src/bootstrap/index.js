/** Entry point arquitetural compatível com o bootstrap legado. */
export { bootstrapV2 as start, bootstrapV2, isBootstrapped } from '../core/bootstrap.js';
import bootstrapV2 from '../core/bootstrap.js';
export default bootstrapV2;
