/** Use case compatível para operações de salas; o serviço legado segue sendo a API pública atual. */
import * as groupRooms from '../../services/groupRooms.js';

export const getGroupRoom = ({ groupId } = {}) => groupRooms.getRoom(groupId);
export const setGroupRoom = ({ groupId, code, userId } = {}) => groupRooms.setRoom(groupId, code, userId);
export const removeGroupRoom = ({ groupId } = {}) => groupRooms.removeRoom(groupId);
export default { getGroupRoom, setGroupRoom, removeGroupRoom };
