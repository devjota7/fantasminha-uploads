/** Identity domain facade. Não normaliza strings localmente nem duplica o resolver. */
export { participantRealJid, buildIdentityIndex, resolveUserIdentity, resolveBotIdentity, isBotGroupAdmin, resolveMentionTargets } from '../../platform/identity/resolver.js';
export * from './specialRoles.js';
