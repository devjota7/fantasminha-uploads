export {
  resolveSpecialRoleIdentity,
  getPrimarySpecialRole,
  hasSpecialRole,
  getSpecialRoleIds
} from '../../core/specialRoleIdentity.js';
export {
  listGlobalRoleUsers,
  hasGlobalRole,
  grantGlobalRole,
  revokeGlobalRole,
  getGlobalRoleAssignments
} from '../../services/specialRoleRegistry.js';
