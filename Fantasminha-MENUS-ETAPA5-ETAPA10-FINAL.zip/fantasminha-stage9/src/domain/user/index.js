/** User domain facade: identidade e dados continuam no Store existente. */
import { getUser, upsertUser } from '../../database/store.js';
export { getUser, upsertUser };
export function isUser(value) { return !!value && typeof value === 'object' && typeof value.id === 'string'; }
export default { getUser, upsertUser, isUser };
