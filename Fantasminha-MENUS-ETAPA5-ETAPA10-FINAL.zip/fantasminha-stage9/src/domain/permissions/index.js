/** Permissions domain facade sobre o sistema central existente. */
export * from '../../core/permissions.js';
