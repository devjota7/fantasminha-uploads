/** Group domain facade: o Store continua sendo a fonte de dados atual. */
import { readCollection, updateCollection } from '../../database/store.js';
const fallback = { byId: {} };
export function findGroup(groupId) { return groupId ? readCollection('groups', fallback).byId?.[groupId] || null : null; }
export async function updateGroup(groupId, updater) { return updateCollection('groups', db => { db.byId ||= {}; db.byId[groupId] = updater(db.byId[groupId] || { id: groupId }); return db; }, fallback).then(db => db.byId[groupId]); }
export default { findGroup, updateGroup };
