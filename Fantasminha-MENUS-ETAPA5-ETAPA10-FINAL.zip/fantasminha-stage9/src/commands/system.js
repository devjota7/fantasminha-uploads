import { registerCommand } from '../core/registry.js';
import { Role } from '../core/permissions.js';
import config from '../core/config.js';
import fs from 'fs';
import path from 'path';

export function registerSystemCommands() {
  registerCommand({
    name: 'forcaridentidade',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 5,
    handler: async (ctx) => {
      const p = path.join(config.root, 'dados', 'src', 'config.json');
      const cfg = JSON.parse(fs.readFileSync(p, 'utf8'));
      cfg.nomebot = 'Fantasminha';
      if (!cfg.nomedono) cfg.nomedono = config.ownerName;
      fs.writeFileSync(p, JSON.stringify(cfg, null, 2));
      await ctx.reply('× 👻 FANTASMINHA\n\nIdentidade: *Fantasminha*.');
    }
  });

  registerCommand({
    name: 'limparcache',
    category: 'dono',
    permission: Role.OWNER,
    cooldown: 10,
    handler: async (ctx) => {
      globalThis.__fantasmaV2Ready = false;
      await ctx.reply('× 👻 FANTASMINHA\n\nCache v2 resetado.');
    }
  });
}

export default { registerSystemCommands };
