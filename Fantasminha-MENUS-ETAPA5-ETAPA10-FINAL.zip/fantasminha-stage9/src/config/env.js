/** Read-only environment facade. Defaults and values remain owned by process.env. */
export const env = process.env;
export default env;
