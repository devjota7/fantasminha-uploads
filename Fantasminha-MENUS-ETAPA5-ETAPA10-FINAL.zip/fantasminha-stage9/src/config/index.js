/** Configuração pública da arquitetura. A fonte de verdade continua em core/config.js. */
export { default } from '../core/config.js';
export * from '../core/config.js';
