import { runCommand, getCommand } from '../core/registry.js';
import logger from '../core/logger.js';
import config from '../core/config.js';
import { getEffectivePrefix } from '../core/prefix.js';
import { rateLimit } from './rateLimit.js';
import { checkFlood, addWarnV2, isAutoBanEnabled } from './antiflood.js';
import { emit, Events } from '../core/events/index.js';
import { cooldownMultiplier } from '../services/vipBenefits.js';
import { resolveMigration, noteMigrationUsed } from '../platform/migrations/index.js';
import { createContext } from '../core/context/index.js';
import { recordEnvelope } from '../core/messageEnvelope.js';
import { getCustomCommand } from '../services/customCommands.js';
import { recordMessage, recordCommandUsage } from '../services/profile.js';
import { handleInnovationMessage } from '../services/innovation.js';
import { isDuplicateMessage } from './messageDedup.js';
import { handleRawGameInput } from '../services/gameInput.js';
import { syncWhatsAppContext } from '../services/api/integration.js';
import { handleAutomaticReaction, handleSession as handleReactionSession } from '../plugins/reactionManager/index.js';

// Catálogo oficial de jogos: comandos redundantes/auxiliares de jogos antigos
// ficam desativados publicamente, mesmo que ainda existam no switch legado.
const RETIRED_GAME_COMMANDS = new Set([
  'anagramaalma', 'cacaalma', 'placaralem', 'rankalem',
  'aceitarbatalha', 'recusarbatalha', 'encerrarjuiz', 'roletaalem',
  'jvelha', 'jogopp', 'campominado', 'mines', 'minesweeper', 'jmminado',
  'enigma', 'enigmas', 'jenigma', 'matematica', 'desafiomatematico', 'mathgame',
  'dado', 'dados', 'parouimpar', 'numerooculto', 'embaralha',
  'moedamisterio', 'memoriaflash', 'quizrapido', 'desafioaleatorio',
  'palavraaleatoria', 'numeroaleatorio', 'sorteioseguro',
]);

import { handleAnswer as handleMemoryCupsAnswer } from '../games/memory-cups/MemoryCupsService.js';
import { handleGuess as handleQuizGuess } from '../games/quiz/QuizService.js';
import { handleInput as handleForcaInput } from '../games/forca/ForcaService.js';
import { handleAnswer as handleStopPrivateInput, handleGroupInput as handleStopGroupInput } from '../games/stop/StopCore.js';
import { privateMessageAllowed } from '../services/pvGateway.js';
import { isPvAllowed } from '../services/pvPermissions.js';
import { handleGuess as handleGarticGuess } from '../games/gartic/GarticService.js';
import { clearAfkFromMessage } from '../services/social.js';
import { handleSessionMessage as handleResponseMediaSession } from '../features/responseMedia/ResponseMediaManager.js';
import { response } from '../core/responses.js';
import { handleTriagemInput } from '../modules/triagem/index.js';

export function extractCommand(text, prefix = config.prefix) {
  if (!text || typeof text !== 'string') return null;
  const t = text.trimStart();
  if (!t.startsWith(prefix)) return null;
  // Preserva o final da carga original; só remove whitespace usado como
  // separador entre o nome do comando e o primeiro caractere da carga.
  const body = t.slice(prefix.length).replace(/^[\t\r\n ]+/, '');
  if (!body) return null;

  // Mantém duas representações: q continua compatível com comandos
  // normais, enquanto qRaw preserva a carga original do comando (incluindo
  // quebras de linha, espaços internos, Unicode, símbolos e pontuação).
  // Isso é necessário para comandos cujo conteúdo deve ser reproduzido
  // literalmente, como ×setregra.
  const match = body.match(/^(\S+)([\s\S]*)$/);
  if (!match) return null;
  const command = match[1].toLowerCase();
  const rawArgs = match[2].replace(/^[\t ]+/, '');
  const args = rawArgs ? rawArgs.split(/\s+/) : [];
  return { command, args, q: args.join(' '), qRaw: rawArgs, raw: body };
}

async function recordProfileActivity(ctx, { countCommand = false } = {}) {
  if (!ctx?.isGroup || !ctx?.sender) return;

  // O ID canônico da mensagem vem do envelope Baileys.
  // Não usar IDs auxiliares do contexto aqui: eles podem mudar entre
  // camadas e transformar 1 mensagem real em vários eventos.
  const messageEventId =
    ctx.message?.key?.id ||
    ctx.key?.id ||
    ctx.messageId ||
    ctx.stanzaId ||
    ctx.id ||
    null;

  try {
    const { resolveUserIdentity } = await import('../platform/identity/resolver.js');
    const identity = await resolveUserIdentity({
      sender: ctx.sender,
      senderOriginal: ctx.senderOriginal,
      senderAlternate: ctx.senderAlternate,
      pushname: ctx.pushname,
      from: ctx.from,
      groupParticipantObjects: ctx.groupParticipantObjects || [],
      getGroupMetadata: ctx.getGroupMetadata,
      resolvePNForLID: ctx.resolvePNForLID
    }, ctx.sender);

    const canonicalUserId =
      identity?.realJid ||
      (identity?.number ? `${identity.number}@s.whatsapp.net` : null) ||
      ctx.sender;

    recordMessage(canonicalUserId, ctx.from, messageEventId);

    if (countCommand) {
      const parsed = extractCommand(ctx.body || ctx.text || '', ctx.prefix || config.prefix);
      if (parsed) {
        const known = !!getCommand(parsed.command) ||
          !!getCustomCommand(parsed.command) ||
          !!resolveMigration(parsed.command);
        if (known) recordCommandUsage(canonicalUserId, ctx.from, messageEventId);
      }
    }
  } catch (e) {
    // Sem identidade resolvida, ainda podemos registrar pelo sender, mas
    // somente com o ID canônico. Nunca cair para incremento sem ID, pois
    // o mesmo envelope pode atravessar mais de uma camada.
    if (messageEventId) {
      recordMessage(ctx.sender, ctx.from, messageEventId);
      if (countCommand) {
        const parsed = extractCommand(ctx.body || ctx.text || '', ctx.prefix || config.prefix);
        if (parsed && getCommand(parsed.command)) recordCommandUsage(ctx.sender, ctx.from, messageEventId);
      }
    }
  }
}

export async function handleMessage(ctx) {
  createContext(ctx);
  // Resolve uma única vez por mensagem. Em grupo: GRUPO -> GLOBAL. Em PV: GLOBAL.
  ctx.prefix = getEffectivePrefix(ctx?.isGroup ? ctx.from : '', { globalPrefix: config.prefix });
  const incomingText = String(ctx.body || ctx.text || '').trim();

  // PV continua sendo uma superfície restrita.
  try {
    const stopResult = ctx?.isPrivate ? await handleStopPrivateInput(ctx) : await handleStopGroupInput(ctx);
    if (stopResult?.handled) return stopResult;
  } catch (e) { logger.warn('stop', `entrada: ${e.message}`); }

  // Triagem 2.0: sessões de painel e respostas do membro no PV (antes do gate de PV).
  try {
    const triagemResult = await handleTriagemInput(ctx);
    if (triagemResult?.handled) return triagemResult;
  } catch (e) { logger.warn('triagem', `entrada: ${e.message}`); }
  try {
    const { handleSessionInput: handleSpecialRoleSession } = await import('../plugins/specialRoles/panel.js');
    const specialRoleResult = await handleSpecialRoleSession(ctx);
    if (specialRoleResult?.handled) return specialRoleResult;
  } catch (e) { logger.warn('special-roles', `sessão: ${e.message}`); }

  if (ctx?.isPrivate && ctx?.sender && !isPvAllowed(ctx.sender) && !privateMessageAllowed(incomingText, ctx.prefix || config.prefix)) {
    return { handled: false, pvBlocked: true };
  }

  if (!ctx?.message?.__fantasminhaDedupAccepted && isDuplicateMessage(ctx)) { logger.debug?.('pipeline', 'mensagem duplicada ignorada'); return { handled:true, duplicate:true }; }

  // Registra a mensagem antes dos fluxos antecipados, mas não contabiliza
  // uso de comando: parser, rate-limit, permissão e execução ainda não foram
  // concluídos. O uso é registrado somente após runCommand/migration.
  await recordProfileActivity(ctx, { countCommand: false });
  void syncWhatsAppContext(ctx).then(integration => { if (integration?.identity?.userId) ctx.apiUserId = integration.identity.userId; }).catch(e => { logger.debug?.('api-integration', `context sync skipped: ${e.message}`); });

  globalThis.__fantasminhaOwnerIds = [config.ownerNumber, config.ownerLid, ...(config.ownerIds || [])].filter(Boolean);
  // AFK clássico: qualquer mensagem do próprio usuário encerra a ausência.
  // O próprio comando ×afk é exceção para permitir criar/atualizar o estado.
  if (ctx.sender && !ctx.fromMe) {
    try { await clearAfkFromMessage(ctx); } catch (e) { logger.debug?.('afk', `não foi possível limpar AFK: ${e.message}`); }
  }
  if (!ctx.isOwner) { const { configuredOwner } = await import('../core/permissions.js'); ctx.isOwner = configuredOwner(ctx.sender); }
  try {
    const reactionSession = await handleReactionSession(ctx);
    if (reactionSession?.handled) return reactionSession;
  } catch (e) { logger.warn('reaction-manager', `sessão: ${e.message}`); }
  try {
    const mediaSession = await handleResponseMediaSession(ctx);
    if (mediaSession?.handled) return mediaSession;
  } catch (e) { logger.warn('response-media', `sessão: ${e.message}`); }
  if (ctx.message) recordEnvelope(ctx.message, { readable: true, kind: ctx.message?.message?.paymentMessage ? 'payment' : 'other' });
  await emit(Events.MESSAGE, ctx);
  try { const reaction = await handleAutomaticReaction(ctx); if (reaction?.handled) return reaction; } catch (e) { logger.warn('reaction-manager', `automática: ${e.message}`); }
  try { const gameInput = await handleRawGameInput(ctx); if (gameInput?.handled) return gameInput; } catch (e) { logger.warn('game-input', e.message); }
  try { const forcaInput = await handleForcaInput(ctx); if (forcaInput?.handled) return forcaInput; } catch (e) { logger.warn('forca', e.message); }
  try { const quizGuess = await handleQuizGuess(ctx); if (quizGuess?.handled) return quizGuess; } catch (e) { logger.warn('quiz', e.message); }
  try { const garticGuess = await handleGarticGuess(ctx); if (garticGuess?.handled) return garticGuess; } catch (e) { logger.warn('gartic', e.message); }
  try { const memoryCups = await handleMemoryCupsAnswer(ctx); if (memoryCups?.handled) return memoryCups; } catch (e) { logger.warn('memory-cups', e.message); }
  try { const game = await handleInnovationMessage(ctx); if (game?.handled) return game; } catch (e) { logger.warn('innovation-game', e.message); }

  // Anti-flood unificado (só comandos / mensagens rápidas)
  if (ctx.sender && !ctx.isOwner && !ctx.isGroupAdmin) {
    const flood = checkFlood(`${ctx.from || 'private'}:${ctx.sender}`, { max: 10, windowMs: 7000 });
    if (flood.flooded) {
      if (ctx.isGroup && ctx.from) {
        const { warns, shouldBan } = await addWarnV2(ctx.from, ctx.sender);
        const autoban = await isAutoBanEnabled(ctx.from);
        if (ctx.reply) {
          await ctx.reply(
            `${response('RATE_LIMIT', { time: 7 })} Warn *${warns}*.` +
              (shouldBan && autoban ? '\n⛔ Limite atingido — *auto-ban* sugerido (admin execute ban).' : '')
          );
        }
        ctx._floodShouldBan = shouldBan && autoban;
        ctx._floodTarget = ctx.sender;
      } else if (ctx.reply) {
        await ctx.reply(response('RATE_LIMIT', { time: 7 }));
      }
      return { handled: true, flooded: true };
    }
  }

  const parsed = extractCommand(ctx.body || ctx.text || '', ctx.prefix || config.prefix);
  if (!parsed) return { handled: false };

  ctx.command = parsed.command;
  ctx.args = parsed.args;
  ctx.q = parsed.q;
  ctx.qRaw = parsed.qRaw;


  if (RETIRED_GAME_COMMANDS.has(parsed.command)) {
    if (ctx.reply) await ctx.reply(`${response('COMMAND_UNAVAILABLE')}\n\nUse ×catalogo para ver os jogos oficiais disponíveis.`);
    return { handled: true, retiredGame: true, command: parsed.command };
  }

  const rl = rateLimit(ctx.sender, { scope: ctx.from || 'private', max: 20, windowMs: 10_000 });
  if (!rl.ok) {
    if (ctx.reply) await ctx.reply(response('RATE_LIMIT', { time: rl.retryAfter }));
    return { handled: true, rateLimited: true };
  }

  // VIP reduz cooldown efetivo via flag no ctx
  ctx.cooldownMult = cooldownMultiplier(ctx.sender);

  if (!getCommand(parsed.command)) {
    const custom = getCustomCommand(parsed.command);
    if (custom) {
      const text = custom.text.replace(/\{user\}/gi, ctx.pushname || ctx.sender || '').replace(/\{q\}/gi, ctx.q || '');
      if (ctx.reply) await ctx.reply(text);
      return { handled: true, custom: true, command: parsed.command };
    }
    const migration = resolveMigration(parsed.command);
    if (migration && getCommand(migration.target)) {
      await noteMigrationUsed(migration, ctx);
      if (migration.mode === 'notice' && ctx.reply) await ctx.reply(`🔄 Comando atualizado: use ${ctx.prefix || config.prefix}${migration.target} daqui para frente.`);
      const result = await runCommand(migration.target, { ...ctx, command: migration.target, migratedFrom: parsed.command });

      if (result.found && ctx.isGroup && ctx.sender) {
        try {
          const { resolveUserIdentity } = await import('../platform/identity/resolver.js');

          const identity = await resolveUserIdentity({
            sender: ctx.sender,
            senderOriginal: ctx.senderOriginal,
            senderAlternate: ctx.senderAlternate,
            pushname: ctx.pushname,
            from: ctx.from,
            groupParticipantObjects: ctx.groupParticipantObjects || [],
            getGroupMetadata: ctx.getGroupMetadata,
            resolvePNForLID: ctx.resolvePNForLID
          }, ctx.sender);

          const canonicalUserId =
            identity?.realJid ||
            (identity?.number ? `${identity.number}@s.whatsapp.net` : null) ||
            ctx.sender;

          const commandEventId =
            ctx.message?.key?.id ||
            ctx.key?.id ||
            ctx.messageId ||
            ctx.stanzaId ||
            ctx.id ||
            null;

          recordCommandUsage(canonicalUserId, ctx.from, commandEventId);
        } catch (e) {
          // Sem identidade resolvida, não incrementar sem ID.
        }
      }

      return { handled: result.found, command: migration.target, migratedFrom: parsed.command };
    }
    return { handled: false, legacy: true, command: parsed.command };
  }

  try {
    const result = await runCommand(parsed.command, ctx);

    if (result.found && ctx.isGroup && ctx.sender) {
      try {
        const { resolveUserIdentity } = await import('../platform/identity/resolver.js');

        const identity = await resolveUserIdentity({
          sender: ctx.sender,
          senderOriginal: ctx.senderOriginal,
          senderAlternate: ctx.senderAlternate,
          pushname: ctx.pushname,
          from: ctx.from,
          groupParticipantObjects: ctx.groupParticipantObjects || [],
          getGroupMetadata: ctx.getGroupMetadata,
          resolvePNForLID: ctx.resolvePNForLID
        }, ctx.sender);

        const canonicalUserId =
          identity?.realJid ||
          (identity?.number ? `${identity.number}@s.whatsapp.net` : null) ||
          ctx.sender;

        const commandEventId =
          ctx.message?.key?.id ||
          ctx.key?.id ||
          ctx.messageId ||
          ctx.stanzaId ||
          ctx.id ||
          null;

        recordCommandUsage(canonicalUserId, ctx.from, commandEventId);
        } catch (e) {
          const fallbackEventId = ctx.message?.key?.id || ctx.key?.id || ctx.messageId || ctx.stanzaId || ctx.id || null;
          if (fallbackEventId) recordCommandUsage(ctx.sender, ctx.from, fallbackEventId);
        }
    }

    return { handled: result.found, command: parsed.command };
  } catch (err) {
    logger.error('pipeline', err.message, { command: parsed.command });
    if (ctx.reply && !err?.__fantasminhaUserErrorHandled) await ctx.reply(err.userMessage || err.message || '🕯️ O véu engasgou.');
    return { handled: true, error: true };
  }
}

export default { extractCommand, handleMessage };
