/**
 * Adapter SOMENTE-LEITURA da blacklist existente do bot.
 * A Triagem 2.0 não possui blacklist própria e nunca escreve na do bot:
 * quem decide banir é o dono, com addblacklist/addblackglobal.
 * Este arquivo só faz leitura (readFileSync) e não importa nenhuma função de escrita.
 */
import fs from 'node:fs';
import path from 'node:path';
import config from '../../core/config.js';
import { collectIds, idsOverlap } from '../../modules/triagem/triagem.identity.js';

function legacyDbDir() {
  return process.env.TRIAGEM_LEGACY_DB_DIR || path.join(config.root, 'dados', 'database');
}

function readJson(file) {
  try {
    if (!fs.existsSync(file)) return null;
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function findEntry(table, ids) {
  if (!table || typeof table !== 'object') return null;
  for (const [key, value] of Object.entries(table)) {
    if (idsOverlap([key], ids)) return { key, value };
  }
  return null;
}

function reasonOf(entry) {
  const reason = entry?.value?.reason;
  return typeof reason === 'string' && reason.trim() ? reason.trim().slice(0, 120) : '';
}

/**
 * @param {string} groupId JID do grupo
 * @param {string[]} identityIds todas as formas conhecidas da pessoa (JID, LID, resolvidas)
 * @returns {{grupo:boolean, global:boolean, motivoGrupo:string, motivoGlobal:string}}
 */
export function consultarBlacklist(groupId, identityIds = []) {
  const ids = collectIds(identityIds);
  const out = { grupo: false, global: false, motivoGrupo: '', motivoGlobal: '' };
  if (!ids.length) return out;
  const dir = legacyDbDir();
  if (groupId) {
    const safeId = String(groupId).replace(/[^a-zA-Z0-9]/g, '_');
    const group = readJson(path.join(dir, 'grupos', `${safeId}.json`));
    const hit = findEntry(group?.blacklist, ids);
    if (hit) { out.grupo = true; out.motivoGrupo = reasonOf(hit); }
  }
  const global = readJson(path.join(dir, 'dono', 'globalBlacklist.json'));
  const gHit = findEntry(global?.users, ids);
  if (gHit) { out.global = true; out.motivoGlobal = reasonOf(gHit); }
  return out;
}

export default { consultarBlacklist };
