import { Role } from '../../core/permissions.js';
import { auditStats } from '../../platform/audit/index.js';
import { defineCommandContract, interpolateResponse } from '../../core/command/contract.js';

const responses = Object.freeze({
  success: { main: '× 👻 *AUDITORIA*\n\n📚 Eventos: *{total}*\n🕒 Último: *{last}*\n🎯 Última ação: *{action}*\n📌 Resultado: *{result}*' },
  errors: { unexpected: '× 👻 Não foi possível consultar a auditoria agora.' }
});
export default defineCommandContract({
  name: 'auditoriav2', aliases: ['auditv2'], category: 'dono', permission: Role.OWNER,
  cooldown: 5, audit: true, publicName: 'Auditoria V2', purpose: 'Consulta eventos de auditoria sem expor conteúdo sensível.',
  syntax: '×auditoriav2', examples: ['×auditv2'], authorization: { level: 'OWNER', ownerOnly: true },
  validation: { arguments: 'none' }, responses, tests: ['tests/command-loader-pilot.test.mjs', 'tests/command-architecture-audit.test.mjs'],
  handler: async ctx => { try { const a = auditStats(); await ctx.reply(interpolateResponse(responses.success.main, { total: a.total, last: a.last ? new Date(a.last.at).toLocaleString('pt-BR') : 'nenhum', action: a.last?.action || '—', result: a.last?.result || '—' })); } catch { await ctx.reply(responses.errors.unexpected); } }
});
