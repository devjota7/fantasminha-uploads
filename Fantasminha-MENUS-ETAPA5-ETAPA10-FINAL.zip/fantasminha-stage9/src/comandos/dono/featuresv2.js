import { Role } from '../../core/permissions.js';
import { getFeatureFlags } from '../../platform/flags/index.js';
import { defineCommandContract } from '../../core/command/contract.js';

const responses = Object.freeze({
  success: { main: flags => `× 👻 *FEATURE FLAGS*\n\n${Object.entries(flags).map(([key, value]) => `${value ? '🟢' : '🔴'} ${key}: *${value ? 'ON' : 'OFF'}*`).join('\n')}` },
  errors: { unexpected: '× 👻 Não foi possível consultar as feature flags agora.' }
});
export default defineCommandContract({
  name: 'featuresv2', aliases: ['featurestatusv2', 'flagsstatusv2'], category: 'dono', permission: Role.OWNER,
  cooldown: 5, audit: true, publicName: 'Feature Flags V2', purpose: 'Consulta o estado efetivo das flags sem alterar configuração.',
  syntax: '×featuresv2', examples: ['×featurestatusv2'], authorization: { level: 'OWNER', ownerOnly: true },
  validation: { arguments: 'none' }, responses, tests: ['tests/command-loader-pilot.test.mjs', 'tests/command-architecture-audit.test.mjs'],
  handler: async ctx => { try { await ctx.reply(responses.success.main(getFeatureFlags())); } catch { await ctx.reply(responses.errors.unexpected); } }
});
