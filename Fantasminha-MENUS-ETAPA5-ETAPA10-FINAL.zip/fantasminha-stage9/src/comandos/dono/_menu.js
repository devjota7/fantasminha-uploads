/** Metadados da categoria; os comandos são derivados do Registry. */
export default Object.freeze({
  category: 'dono',
  title: 'DONO',
  emoji: '👑',
  order: 5
});
