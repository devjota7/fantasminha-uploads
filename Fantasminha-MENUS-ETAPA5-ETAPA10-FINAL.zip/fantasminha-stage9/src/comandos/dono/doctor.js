import { Role } from '../../core/permissions.js';
import { collectSystemSnapshot, systemDoctor } from '../../core/systemOrchestrator.js';
import { defineCommandContract, interpolateResponse } from '../../core/command/contract.js';

const responses = Object.freeze({
  success: { healthy: '× 👻 *FANTASMINHA — DOCTOR*\n\n✅ Sistema saudável.\n{issues}\n\n📦 Registry: {commands} comandos / {aliases} aliases\n💾 Banco: {database}\n🧠 Heap: {heap}%\n⚙️ Jobs: {jobs}' },
  warning: { issues: '× 👻 *FANTASMINHA — DOCTOR*\n\n⚠️ Problemas encontrados:\n{issues}\n\n📦 Registry: {commands} comandos / {aliases} aliases\n💾 Banco: {database}\n🧠 Heap: {heap}%\n⚙️ Jobs: {jobs}' },
  errors: { unexpected: '× 👻 *FANTASMINHA — DOCTOR*\n\n👻 Não foi possível concluir o diagnóstico.' }
});
function render(d) {
  const snapshot = d.snapshot;
  return interpolateResponse(d.ok ? responses.success.healthy : responses.warning.issues, {
    issues: d.issues.map(x => `• ${x}`).join('\n') || '• Nenhum problema crítico.',
    commands: snapshot.registry.enabled, aliases: snapshot.registry.aliases,
    database: snapshot.checks.database ? 'OK' : 'ERRO',
    heap: Math.round(snapshot.memory.heapUsed / Math.max(snapshot.memory.heapTotal, 1) * 100), jobs: snapshot.jobs.length
  });
}
export default defineCommandContract({
  name: 'doctor', aliases: ['healthcheck', 'sysdoctor'], category: 'dono', permission: Role.OWNER,
  cooldown: 10, audit: true, publicName: 'Doctor', purpose: 'Diagnóstico seguro do núcleo, banco, Registry, memória e jobs.',
  syntax: '×doctor', examples: ['×doctor'], contextRequirements: { privateAllowed: true, groupAllowed: true },
  authorization: { level: 'OWNER', ownerOnly: true }, validation: { arguments: 'none' }, responses, tests: ['tests/command-loader-pilot.test.mjs', 'tests/command-architecture-audit.test.mjs'],
  handler: async ctx => { try { await ctx.reply(render(systemDoctor(collectSystemSnapshot({ waConnected: ctx.waConnected === true })))); } catch { await ctx.reply(responses.errors.unexpected); } }
});
