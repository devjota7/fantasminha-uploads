# Arquitetura do Fantasminha

**Status: congelada com Wallet parcial — implementação aditiva, sem ativação pública ou remoção do legado.**

## Objetivo

Preservar o comportamento atual e preparar migrações graduais. A regra é **módulo primeiro, camada depois**: cada domínio futuro concentra seus comandos, services e repositories; as fronteiras compartilhadas ficam em `core`, `platform`, `db` e `shared`.

```text
WhatsApp/Baileys → platform/whatsapp → core → command → module
                                             ↓
                                          service → repository → db
```

Árvore-alvo resumida (não criar pastas vazias só para satisfazer o desenho):

```text
src/{config,db/{connection,migrations,transactions,locks},core/{registry,dispatcher,middleware,events,errors},platform/{whatsapp,media,external},modules/<domínio>,shared,legacy/{adapters,aliases}}
```

## Regras congeladas

- **Commands** são entradas; a direção futura é `Command → Service → Repository → DB`.
- Um módulo usa outro somente por API pública (`*.service.js` ou `index.js`), nunca pelo repository/interno do outro módulo.
- Nenhum módulo de negócio importa Baileys ou detalhes de WhatsApp; o transporte pertence a `src/platform/`. A auditoria encontrou imports legados fora dessa fronteira; eles permanecem sem migração nesta etapa.
- Repositories persistem e não enviam mensagens, não conhecem WhatsApp e não importam módulos de domínio.
- `src/db/` é a fronteira futura de persistência. O runtime atual ainda usa `src/database/store.js` e `dados/src/utils/database.js`; não há troca de banco nesta etapa.
- `src/legacy/{adapters,aliases}` é compatibilidade temporária, não depósito permanente. Não criar `legacy/migrated`.
- Operações econômicas novas usam lock/transação adequado ao backend real; a Wallet foi criada como módulo-molde, mas seus comandos permanecem desativados.
- Menus futuros derivam metadados do Registry; `dados/src/menus/menuMap.js` não foi reescrito.

## Estado real auditado

- Runtime ESM (`"type": "module"`), entrada efetiva `npm start → dados/src/.scripts/start.js → dados/src/connect.js`.
- Node declarado `>=20.9.0`; Baileys `7.0.0-rc14`.
- Registry real: `src/core/registry.js`; bootstrap: `src/core/bootstrap.js`. O contrato atual usa `name`, `handler`, `category` opcional com default `geral`, aliases e metadados; o loader percorre `src/comandos/` quando a pasta existe. Plugins também registram diretamente.
- `data/db/` tem 44 arquivos e ~280K; `src/database/store.js` fornece escrita atômica/durável, lock por arquivo entre processos, recuperação e transações multi-coleção.
- `dados/database/` tem 30 arquivos e ~152K; `dados/src/utils/paths.js` aponta o legado para essa raiz. `economy.json` contém `users`, `wallet`, `bank`, `inventory` e `items`. `withFileLock` serializa apenas dentro de um processo; `saveJsonFileSafe` usa temporário + rename, sem fsync e sem backup ativo.
- Os dois diretórios são fontes distintas e não devem ser tratados como o mesmo banco.

## Checks

O check `scripts/architecture-boundaries.mjs` valida Baileys, acesso cross-module, direção repository→domínio e ciclos. `scripts/architecture-boundaries.baseline.json` fixa a dívida conhecida; novas violações e entradas obsoletas falham. O teste `tests/architecture-boundaries.test.mjs` usa fixtures temporárias para provar FAIL/PASS sem tocar nos dados. Os checks legados continuam válidos, exceto o FAIL pré-existente de Clãs registrado na baseline.

## Estado implementado nesta execução

- `src/modules/economy/wallet/` contém contexto, service, adapter de repository, comando declarativo desativado e testes isolados.
- `src/core/registry.js` aceita `handler` e `run`, normalizando ambos para o mesmo executor; o loader também descobre `src/modules/**/*.commands.js`.
- O legado permanece em `dados/src/index.js` e `dados/src/utils/database.js`; as duas raízes de persistência continuam distintas.

Referências: [AGENTS.md](AGENTS.md) · [MIGRATION.md](MIGRATION.md) · [docs/PLAYBOOKS.md](docs/PLAYBOOKS.md) · [contrato de comandos](src/core/registry/COMMAND_CONTRACT.md).
