import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DB_ROOT, readCollection, writeCollection, upsertUser } from '../src/database/store.js';
import { getBalance, credit, debit, tradeMarketOffer } from '../src/services/economy.js';
import { createOffer, buyOffer, listOffers } from '../src/services/market.js';

const names = ['users','market','economy_ledger'];
const backups = Object.fromEntries(names.map(n => { const f=path.join(DB_ROOT,`${n}.json`); return [n,fs.existsSync(f)?fs.readFileSync(f):null]; }));
const tag = Date.now().toString(36);
const seller=`s10-seller-${tag}@s.whatsapp.net`, buyer=`s10-buyer-${tag}@s.whatsapp.net`, poor=`s10-poor-${tag}@s.whatsapp.net`, buyer2=`s10-buyer2-${tag}@s.whatsapp.net`;
try {
  writeCollection('users',{byId:{
    [seller]:{id:seller,name:'seller',economy:{wallet:1000,bank:0,inventory:{relic:5}}},
    [buyer]:{id:buyer,name:'buyer',economy:{wallet:5000,bank:0,inventory:{}}},
    [poor]:{id:poor,name:'poor',economy:{wallet:10,bank:0,inventory:{}}},
    [buyer2]:{id:buyer2,name:'buyer2',economy:{wallet:5000,bank:0,inventory:{}}}
  }});
  writeCollection('market',{offers:[]}); writeCollection('economy_ledger',{entries:[]});

  const offerId=await createOffer(seller,'relic',1000,2,'Seller');
  assert.equal(readCollection('users').byId[seller].economy.inventory.relic,3);
  assert.equal((await listOffers()).length,1);
  await assert.rejects(()=>buyOffer(poor,offerId,'Poor'),/GC insuficientes/);
  assert.equal((await listOffers()).length,1,'falha deve fazer rollback da oferta');
  assert.equal(readCollection('users').byId[poor].economy.wallet,10);

  const bought=await buyOffer(buyer,offerId,'Buyer');
  assert.equal(bought.qty,2); assert.equal(bought.price,1000);
  assert.equal(readCollection('users').byId[buyer].economy.wallet,3000);
  assert.equal(readCollection('users').byId[seller].economy.wallet,3000);
  assert.equal(readCollection('users').byId[buyer].economy.inventory.relic,2);
  const retry = await buyOffer(buyer,offerId,'Buyer');
  assert.equal(retry.id, offerId, 'mesma operação de compra deve ser idempotente');
  assert.equal((await listOffers()).length,0);
  const ledger=readCollection('economy_ledger').entries;
  assert.equal(ledger.filter(e=>e.operationId==='market-buy:'+buyer+':'+offerId).length,2);

  await assert.rejects(()=>buyOffer(buyer2,offerId,'Buyer2'),/Oferta não encontrada/);

  const offer2=await createOffer(seller,'relic',500,1,'Seller');
  const results=await Promise.allSettled([buyOffer(buyer,offer2,'Buyer'),buyOffer(buyer2,offer2,'Buyer2')]);
  assert.equal(results.filter(r=>r.status==='fulfilled').length,1,'apenas um comprador pode consumir a oferta');
  assert.equal(results.filter(r=>r.status==='rejected').length,1);
  assert.equal((await listOffers()).length,0);
  assert.equal(readCollection('users').byId[seller].economy.inventory.relic,2);

  const op='stage10-idempotent';
  await credit(buyer,100,'stage10', '', op);
  await credit(buyer,100,'stage10', '', op);
  assert.equal((await getBalance(buyer)).wallet,2600,'crédito idempotente');
  await debit(buyer,100,'stage10', '', 'stage10-debit');
  await debit(buyer,100,'stage10', '', 'stage10-debit');
  assert.equal((await getBalance(buyer)).wallet,2500,'débito idempotente');

  console.log('MARKET ETAPA 10 OK — mercado | rollback | atomicidade | idempotência | concorrência | ledger | isolamento');
} finally {
  for (const n of names) { const f=path.join(DB_ROOT,`${n}.json`); if(backups[n]) fs.writeFileSync(f,backups[n]); else fs.rmSync(f,{force:true}); }
}
