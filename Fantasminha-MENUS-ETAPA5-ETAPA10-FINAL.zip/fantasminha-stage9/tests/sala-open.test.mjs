import assert from 'node:assert/strict';
import fs from 'node:fs';
import { Role } from '../src/core/permissions.js';
import { getRoom, setRoom, removeRoom } from '../src/services/groupRooms.js';

const source = fs.readFileSync(new URL('../src/plugins/social/index.js', import.meta.url), 'utf8');
const expectedRole = { addsala: 'GROUP_ADMIN', sala: 'USER', rmsala: 'GROUP_ADMIN' };
for (const [command, role] of Object.entries(expectedRole)) {
  const pattern = new RegExp(`name:'${command}'[\\s\\S]{0,500}?permission:Role\\.${role}[\\s\\S]{0,100}?groupOnly:true`);
  assert.match(source, pattern, `${command} deve ser ${role} + groupOnly`);
}
assert.match(source, /name:'sala'[\s\S]{0,300}?cooldown:0/, 'sala não deve ter espera entre usos');
assert.equal(Role.USER, 10);

const a = 'test-sala-open-a@g.us';
const b = 'test-sala-open-b@g.us';
await removeRoom(a); await await removeRoom(b);
await setRoom(a, 'AAAA', 'user-a@s.whatsapp.net');
assert.equal(getRoom(a).code, 'AAAA');
await setRoom(a, 'BBBB', 'user-b@s.whatsapp.net');
assert.equal(getRoom(a).code, 'BBBB', 'addsala deve substituir o código anterior');
await setRoom(b, 'CCCC', 'user-c@s.whatsapp.net');
assert.equal(getRoom(b).code, 'CCCC');
assert.equal(getRoom(a).code, 'BBBB', 'grupos devem permanecer isolados');
assert.equal(await removeRoom(a), true);
assert.equal(getRoom(a), null);
assert.equal(getRoom(b).code, 'CCCC');
await removeRoom(b);
console.log('SALA TEST PASS — addsala/rmsala ADM, sala livre, substituição automática e isolamento por grupo');
