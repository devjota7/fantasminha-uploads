/**
 * Control Center web integration: HTTP REAL + app.js REAL.
 * Uses the real Control Center server and real auth/API endpoints.
 * The DOM is a minimal deterministic harness because this repository does not
 * ship a browser automation dependency; this is stronger than source regexes
 * but is intentionally not labeled as full browser E2E.
 */
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { startControlCenter, stopControlCenter } from '../src/platform/controlCenter/index.js';

process.env.WEB_AUTH_USERNAME = process.env.WEB_AUTH_USERNAME || 'e2e';
process.env.WEB_AUTH_PASSWORD_HASH = process.env.WEB_AUTH_PASSWORD_HASH || 'scrypt$16384$8$1$xSKneUePkKST_rmV9QXAIg$bUXpRzi3nVh32is0EtlMhBZD5OXI-mefo8oygvcqXETnTJpRsIJ-bf0-Shk9vK9AQma-H6l7jeIBwygzCjE6Fg';
process.env.WEB_AUTH_COOKIE_SECURE = 'false';

const port = 8817;
const base = `http://127.0.0.1:${port}`;
const html = fs.readFileSync(new URL('../web/control-center/index.html', import.meta.url), 'utf8');
const source = fs.readFileSync(new URL('../web/control-center/app.js', import.meta.url), 'utf8');

function navPagesFromRealHtml() {
  return [...html.matchAll(/data-page="([^"]+)"[^>]*class="nav-item/g)].map(m => m[1]);
}
const NAV_PAGES = navPagesFromRealHtml();
assert.deepEqual(NAV_PAGES, ['dashboard','clients','keys','rentals','payments','activity','alerts','ops','system']);

function makeElement() {
  const listeners = {};
  const el = {
    dataset: {}, style: {}, hidden:false, disabled:false, value:'', textContent:'', href:'', _html:'',
    classList:{toggle(){},add(){},remove(){},contains(){return false;}},
    get innerHTML(){return el._html;}, set innerHTML(v){el._html=String(v);},
    addEventListener(evt,fn){(listeners[evt]??=[]).push(fn);}, removeEventListener(){},
    set onclick(fn){el.addEventListener('click',fn);}, set onsubmit(fn){el.addEventListener('submit',fn);},
    dispatch(evt,overrides={}){const event={preventDefault(){},currentTarget:el,target:el,...overrides};for(const fn of (listeners[evt]||[]))fn(event);},
    querySelector(){return makeElement();}, querySelectorAll(){return [];}, appendChild(){}, focus(){}, scrollIntoView(){},
    getAttribute(){return null;}, setAttribute(){}, matches(){return false;}
  };
  return el;
}
const elements = new Map();
const nav = NAV_PAGES.map(page => { const e=makeElement(); e.dataset.page=page; return e; });
const ids = ['main','sidebar','menuButton','modalClose','modal','logout','userName','loginForm','loginError'];
for (const id of ids) elements.set(id, makeElement());
function documentFor() {
  return {
    getElementById(id){ if(!elements.has(id)) elements.set(id,makeElement()); return elements.get(id); },
    querySelector(sel){ if(sel==='#main') return elements.get('main'); return makeElement(); },
    querySelectorAll(sel){ if(sel==='.nav-item') return nav; return []; },
    addEventListener(){}
  };
}

async function run() {
  await startControlCenter({host:'127.0.0.1',port});
  try {
    const login = await fetch(`${base}/api/auth/login`, {
      method:'POST', headers:{'content-type':'application/json'},
      body:JSON.stringify({username:'e2e',password:'TestPass123!'})
    });
    assert.equal(login.status,200,`login HTTP ${login.status}`);
    const loginBody = await login.json();
    assert.equal(loginBody.isAuthenticated,true);
    const csrf = loginBody.csrfToken;
    const setCookies = login.headers.getSetCookie ? login.headers.getSetCookie() : [];
    assert.ok(setCookies.length >= 2, 'login deveria emitir sessão + CSRF cookies');
    const cookieHeader = setCookies.map(v=>v.split(';',1)[0]).join('; ');

    const indexResponse = await fetch(`${base}/`);
    assert.equal(indexResponse.status,200);
    assert.match(await indexResponse.text(), /Fantasminha/);
    const appResponse = await fetch(`${base}/control-center/app.js`);
    assert.equal(appResponse.status,200);
    assert.match(await appResponse.text(), /function loadPage/);

    const realFetchCalls=[];
    async function realFetch(path, options={}) {
      const method=String(options.method||'GET').toUpperCase();
      const headers=new Headers(options.headers||{});
      headers.set('cookie',cookieHeader);
      if(method!=='GET' && method!=='HEAD' && csrf) headers.set('x-csrf-token',csrf);
      const response=await fetch(`${base}${path}`,{...options,headers});
      realFetchCalls.push(`${method} ${path}`);
      return response;
    }

    const sandbox={
      document:documentFor(), window:{addEventListener(){}}, navigator:{clipboard:{writeText:async()=>{}}},
      fetch:realFetch, Headers, FormData:class{}, console, confirm:()=>true, setTimeout, clearTimeout,
      Date,JSON,Promise,Object,Array,Number,String,encodeURIComponent
    };
    sandbox.globalThis=sandbox;
    vm.createContext(sandbox);
    vm.runInContext(source,sandbox,{filename:'web/control-center/app.js'});
    await new Promise(r=>setTimeout(r,150));

    const errors=[];
    for(const btn of nav){
      btn.dispatch('click');
      await new Promise(r=>setTimeout(r,120));
      const text=elements.get('main').innerHTML;
      if(/class="error"/.test(text)) errors.push(`${btn.dataset.page}: ${text}`);
    }
    assert.deepEqual(errors,[],`páginas com erro: ${errors.join('\n')}`);
    for(const endpoint of [
      'GET /api/owner/dashboard','GET /api/owner/clients','GET /api/owner/keys',
      'GET /api/owner/rentals','GET /api/owner/plans','GET /api/owner/payments',
      'GET /api/owner/payments/config','GET /api/owner/activity','GET /api/owner/alerts',
      'GET /api/owner/ops/diagnostics','GET /api/owner/ops/operations?limit=20'
    ]) assert.ok(realFetchCalls.includes(endpoint),`endpoint não executado: ${endpoint}`);

    const csrfMissing=await fetch(`${base}/api/auth/logout`,{method:'POST',headers:{cookie:cookieHeader}});
    assert.equal(csrfMissing.status,403,'logout sem CSRF deve retornar 403');
    const session=await fetch(`${base}/api/auth/session`,{headers:{cookie:cookieHeader}});
    assert.equal(session.status,200,'sessão deve continuar válida após CSRF rejeitado');

    console.log(`CONTROL-CENTER WEB HTTP INTEGRATION: PASS (${realFetchCalls.length} requests HTTP reais, ${NAV_PAGES.length} páginas executadas)`);
  } finally {
    await stopControlCenter();
  }
}
run().catch(err=>{console.error(err.stack||err);process.exitCode=1;});
