import assert from 'node:assert/strict';
import { SPECIAL_ROLE } from '../src/core/specialRoles.js';
import { resolveSpecialRoleIdentity } from '../src/core/specialRoleIdentity.js';
import { grantGlobalRole, revokeGlobalRole, hasGlobalRole } from '../src/services/specialRoleRegistry.js';

const supportId = '5511999990000@s.whatsapp.net';
await revokeGlobalRole(supportId, SPECIAL_ROLE.SUPPORT);
await grantGlobalRole(supportId, SPECIAL_ROLE.SUPPORT, 'stage4-test');
assert.equal(hasGlobalRole(supportId, SPECIAL_ROLE.SUPPORT), true);

const resolved = await resolveSpecialRoleIdentity({ sender: supportId }, supportId);
assert.equal(resolved.roles.includes(SPECIAL_ROLE.SUPPORT), true);
assert.equal(resolved.highestAdministrativeRole, SPECIAL_ROLE.SUPPORT);
assert.equal(resolved.isAdministrative, true);
assert.equal(resolved.systemRoles.includes(SPECIAL_ROLE.VIP), false);

await revokeGlobalRole(supportId, SPECIAL_ROLE.SUPPORT);
assert.equal(hasGlobalRole(supportId, SPECIAL_ROLE.SUPPORT), false);
console.log('CARGOS ETAPA4 IDENTITY: PASS');
