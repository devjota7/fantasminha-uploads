import assert from 'node:assert/strict';
import { createPlayService, playInternals } from '../dados/src/services/play/playService.js';

const sent = [];
const replies = [];
const bot = { async sendMessage(chat, content, opts) { sent.push({ chat, content, opts }); return { ok: true }; } };
const reply = async (text, opts) => { replies.push({ text, opts }); return { ok: true }; };

const provider = {
  async search() { return { ok: true, data: { videoId: 'x', url: 'https://youtube.test/x', title: 'Teste', author: { name: 'Artista' }, timestamp: '01:02', thumbnail: '' } }; },
  async getAudio() { return { ok: true, buffer: Buffer.from('audio'), mimetype: 'audio/mpeg', filename: 'teste.mp3' }; }
};
const ok = await createPlayService({ bot, chatId: 'g@g.us', quoted: {}, reply, provider, requester: { displayName: 'Jota', participantId: '1@s.whatsapp.net' } }).execute('teste');
assert.equal(ok.ok, true);
assert.equal(sent.length, 1);
assert.equal(replies.length, 2);
assert.match(replies[0].text, /Procurando/);
assert.match(replies[1].text, /🎵  Teste/);

const failProvider = {
  async search() { return { ok: true, data: { url: 'https://youtube.test/x', title: 'Teste', author: 'Artista' } }; },
  async getAudio() { return { ok: false, msg: 'Falhou' }; }
};
replies.length = 0; sent.length = 0;
const fail = await createPlayService({ bot, chatId: 'g@g.us', quoted: {}, reply, provider: failProvider, requester: { displayName: 'Jota', participantId: '1@s.whatsapp.net' } }).execute('teste');
assert.equal(fail.ok, false);
assert.equal(fail.code, 'AUDIO_ERROR');
assert.equal(replies.length, 2, 'erro deve ser entregue pelo chamador, sem duplicação interna');
assert.match(playInternals.buildError('audio', { title: 'Teste', artist: 'Artista' }), /Não foi possível manifestar o áudio/);
console.log('PLAY COMMAND FIX PASS');
