import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DB_ROOT, readCollection, writeCollection } from '../src/database/store.js';
import commercial from '../src/services/platformCommercial.js';
import { paymentConfig, createCheckout, verifyWebhookSignature, handleWebhook, paymentSnapshot } from '../src/services/payments/index.js';

const files=['commercial_platform','payment_platform','platform_audit'].map(n=>[n,path.join(DB_ROOT,`${n}.json`)]);
const originals=new Map(files.map(([n,f])=>[f,fs.existsSync(f)?fs.readFileSync(f):null]));
const old={token:process.env.MERCADOPAGO_ACCESS_TOKEN,secret:process.env.MERCADOPAGO_WEBHOOK_SECRET,url:process.env.MERCADOPAGO_WEBHOOK_URL};
try{
  writeCollection('commercial_platform',{version:1,globalMode:false,clients:{},keys:{},rentals:{},plans:{PLN19:{planId:'PLN19',name:'Etapa 19',days:30,price:29.9,features:['games'],active:true}},operations:{}});
  writeCollection('payment_platform',{version:1,payments:{},operations:{}});
  writeCollection('platform_audit',{events:[]});
  delete process.env.MERCADOPAGO_ACCESS_TOKEN; delete process.env.MERCADOPAGO_WEBHOOK_SECRET; delete process.env.MERCADOPAGO_WEBHOOK_URL;
  const client=commercial.ensureClient({clientId:'CLI-ET19',name:'Etapa 19',actor:'test'});
  const key=commercial.createKey({clientId:client.clientId,durationDays:30,actor:'test'});
  const activation=commercial.activateKey(key.secret,'5511999999999-19@g.us','test','et19');
  const rental=activation.rental;
  assert.equal(paymentConfig().configured,false);
  await assert.rejects(()=>createCheckout({rentalId:rental.groupId,planId:'PLN19',actor:'test'}),e=>e.statusCode===503&&e.code==='payment_provider_unavailable');
  process.env.MERCADOPAGO_WEBHOOK_SECRET='etapa19-secret';
  const dataId='123456'; const requestId='req-et19'; const ts=String(Math.floor(Date.now()/1000));
  const manifest=`id:${dataId};request-id:${requestId};ts:${ts};`;
  const sig=crypto.createHmac('sha256',process.env.MERCADOPAGO_WEBHOOK_SECRET).update(manifest).digest('hex');
  assert.equal(verifyWebhookSignature({xSignature:`ts=${ts},v1=${sig}`,xRequestId:requestId,dataId}),true);
  assert.equal(verifyWebhookSignature({xSignature:`ts=${ts},v1=${'0'.repeat(64)}`,xRequestId:requestId,dataId}),false);
  await assert.rejects(()=>handleWebhook({body:{type:'payment',data:{id:dataId}},query:{'data.id':dataId,type:'payment'},headers:{'x-signature':`ts=${ts},v1=${sig}`,'x-request-id':requestId}}),e=>e.statusCode===503&&e.code==='payment_provider_unavailable');
  const snapshot=paymentSnapshot(); assert.equal(snapshot.total,1); assert.equal(snapshot.rejected,1);
  console.log('PAYMENTS ETAPA 19: PASS — provider fail-closed | preço backend | webhook HMAC | sem pagamento fictício');
}finally{
  for(const [f,data] of originals){if(data)fs.writeFileSync(f,data);else fs.rmSync(f,{force:true});}
  if(old.token===undefined)delete process.env.MERCADOPAGO_ACCESS_TOKEN;else process.env.MERCADOPAGO_ACCESS_TOKEN=old.token;
  if(old.secret===undefined)delete process.env.MERCADOPAGO_WEBHOOK_SECRET;else process.env.MERCADOPAGO_WEBHOOK_SECRET=old.secret;
  if(old.url===undefined)delete process.env.MERCADOPAGO_WEBHOOK_URL;else process.env.MERCADOPAGO_WEBHOOK_URL=old.url;
}
process.exit(0);
