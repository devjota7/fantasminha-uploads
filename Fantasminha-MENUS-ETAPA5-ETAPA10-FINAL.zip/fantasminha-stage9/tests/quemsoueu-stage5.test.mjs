import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const dbRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'fantasminha-qse-stage5-'));
process.env.FANTASMINHA_DB_ROOT = dbRoot;

const stats = await import('../src/services/statsEngine.js');
const ranking = await import('../src/games/whoamiRanking.js');

await stats.recordError({ groupId: 'g1', userId: 'u1@s.whatsapp.net', gameType: 'whoami', errors: 2, operationId: 'err-1' });
await stats.recordResult({ groupId: 'g1', userId: 'u1@s.whatsapp.net', gameType: 'whoami', result: 'correct', score: 80, xp: 0, win: true, operationId: 'win-1' });
await stats.recordResult({ groupId: 'g1', userId: 'u1@s.whatsapp.net', gameType: 'whoami', result: 'correct', score: 60, xp: 0, win: true, operationId: 'win-2' });
await stats.recordResult({ groupId: 'g1', userId: 'u2@s.whatsapp.net', gameType: 'whoami', result: 'loss', score: 0, xp: 0, loss: true, operationId: 'loss-1' });
await stats.recordError({ groupId: 'g1', userId: 'u2@s.whatsapp.net', gameType: 'whoami', errors: 1, operationId: 'err-2' });
await stats.recordResult({ groupId: 'g2', userId: 'u1@s.whatsapp.net', gameType: 'whoami', result: 'correct', score: 40, xp: 0, win: true, operationId: 'win-3' });

const local = ranking.whoamiRanking('g1', 10, 'local');
assert.equal(local[0].userId, 'u1@s.whatsapp.net');
assert.equal(local[0].points, 140);
assert.equal(local[0].correct, 2);
assert.equal(local[0].errors, 2);
assert.equal(local[0].bestStreak, 2);
assert.equal(local[1].errors, 1);
assert.equal(local[1].correct, 0);

const global = ranking.whoamiRanking('g1', 10, 'global');
const u1 = global.find(x => x.userId === 'u1@s.whatsapp.net');
assert.equal(u1.points, 180);
assert.equal(u1.correct, 3);
assert.equal(u1.errors, 2);
assert.equal(u1.bestStreak, 2);

const personal = ranking.whoamiPlayerStats('g1', 'u1@s.whatsapp.net');
assert.equal(personal.points, 140);
assert.equal(personal.correct, 2);
assert.equal(personal.errors, 2);
assert.equal(personal.bestStreak, 2);

console.log('PASS: stage5 ranking/stats global-local, erros e sequência');
