import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { DB_ROOT, readCollection, writeCollection } from '../src/database/store.js';
import commercial from '../src/services/platformCommercial.js';
import { getProvisioning, provision, health, listOperations, provisioningProvider } from '../src/services/provisioning/index.js';

const files=['commercial_platform','platform_audit','provisioning'].map(n=>[n,path.join(DB_ROOT,`${n}.json`)]);
const originals=new Map(files.map(([n,f])=>[f,fs.existsSync(f)?fs.readFileSync(f):null]));
try{
 writeCollection('commercial_platform',{version:1,globalMode:false,clients:{},keys:{},rentals:{},plans:{},operations:{}});
 writeCollection('platform_audit',{events:[]});
 writeCollection('provisioning',{version:1,resources:{},operations:{}});
 const client=commercial.ensureClient({clientId:'CLI-ET18',name:'Etapa 18',actor:'test'});
 const key=commercial.createKey({clientId:client.clientId,durationDays:30,actor:'test'});
 const activated=commercial.activateKey(key.secret,'5511999999999-18@g.us','test','et18');
 assert.equal(activated.success,true);
 const rental=activated.rental;
 assert.equal(provisioningProvider.configured,false);
 const status=getProvisioning(rental.rentalId);
 assert.ok(['unknown','UNAVAILABLE'].includes(status.state));
 assert.equal(status.available,false);
 assert.equal(status.resource,null);
 const h=await health(rental.rentalId); assert.equal(h.available,false);
 await assert.rejects(()=>provision(rental.rentalId,'test','req-18'),e=>e.statusCode===503&&e.code==='PROVIDER_UNAVAILABLE');
 const ops=listOperations(rental.rentalId); assert.equal(ops.length,1); assert.equal(ops[0].state,'UNAVAILABLE');
 const audit=readCollection('platform_audit',{events:[]}).events; assert.ok(audit.some(e=>e.action==='PROVISIONING_PROVISION'&&e.result==='unavailable'));
 console.log('PROVISIONING ETAPA 18: PASS — provider unavailable | fail-closed | sem instância fictícia | auditoria');
}finally{for(const [f,data] of originals){if(data)fs.writeFileSync(f,data);else fs.rmSync(f,{force:true});}}
