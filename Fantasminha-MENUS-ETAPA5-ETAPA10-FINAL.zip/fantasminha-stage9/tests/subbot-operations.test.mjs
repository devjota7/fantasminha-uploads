import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createSubBotOperations, isSafeSubBotId } from '../dados/src/utils/subBotOperations.js';

const managerSource = fs.readFileSync(new URL('../dados/src/utils/subBotManager.js', import.meta.url), 'utf8');
const dispatcherSource = fs.readFileSync(new URL('../dados/src/index.js', import.meta.url), 'utf8');
assert.match(managerSource, /export \{[^}]*listSubBots[^}]*reconnectSubBot[^}]*removeSubBot/s);
assert.match(dispatcherSource, /strictOneBasedArrayIndex\(q,\s*listResult\.subbots\.length\)/);

const botId = 'subbot_12345_abcd1234';
const makeFixture = (overrides = {}) => {
  let registry = { [botId]: { phoneNumber: '5511999999999', ownerNumber: 'owner@lid', subBotLid: 'bot@lid', status: 'desconectado', createdAt: '2026-01-01T00:00:00.000Z' } };
  const active = new Map();
  const removing = new Set();
  const events = { saved: 0, initialized: [], removed: [] };
  const deps = {
    loadSubBots: () => structuredClone(registry),
    saveSubBots: (next) => { events.saved++; if (overrides.save === false) return false; registry = structuredClone(next); return true; },
    activeSubBots: active,
    removingSubBots: removing,
    hasCredentials: async () => overrides.credentials !== false,
    initializeSubBot: async (id, bot) => { events.initialized.push([id, bot.phoneNumber]); if (overrides.initializeError) throw new Error('connect failed'); },
    removeAuthDirectory: async (id) => { events.removed.push(id); return overrides.removeAuth !== false; }
  };
  if (overrides.registry) registry = structuredClone(overrides.registry);
  return { operations: createSubBotOperations(deps), active, removing, events, getRegistry: () => registry };
};

assert.equal(isSafeSubBotId(botId), true);
for (const bad of ['../config', '/tmp/file', 'subbot_../../x', 'other_123']) assert.equal(isSafeSubBotId(bad), false);

{
  const f = makeFixture();
  const listed = f.operations.listSubBots();
  assert.equal(listed.success, true);
  assert.equal(listed.subbots.length, 1);
  assert.equal(listed.subbots[0].id, botId);
  assert.equal(listed.subbots[0].isActive, false);
  assert.equal('subBotLid' in listed.subbots[0], false, 'listagem não expõe alias LID do subbot');
  assert.equal('ownerNumber' in listed.subbots[0], false, 'listagem não expõe dados privados do dono');
}

{
  const f = makeFixture({ credentials: false });
  const result = await f.operations.reconnectSubBot(botId);
  assert.equal(result.success, false);
  assert.equal(f.events.initialized.length, 0);
  assert.equal((await f.operations.reconnectSubBot('../bad')).success, false);
}

{
  const f = makeFixture();
  const result = await f.operations.reconnectSubBot(botId);
  assert.equal(result.success, true);
  assert.deepEqual(f.events.initialized, [[botId, '5511999999999']]);
  f.active.set(botId, {});
  assert.match((await f.operations.reconnectSubBot(botId)).message, /já está conectado/);
  assert.equal(f.events.initialized.length, 1, 'não inicia uma segunda conexão ativa');
}

{
  const f = makeFixture();
  const logoutError = new Error('logout failed');
  f.active.set(botId, { logout: async () => { throw logoutError; } });
  const result = await f.operations.removeSubBot(botId);
  assert.equal(result.success, false);
  assert.match(result.message, /cadastro e arquivos foram preservados/);
  assert.equal(f.getRegistry()[botId] !== undefined, true);
  assert.equal(f.events.saved, 0);
  assert.equal(f.events.removed.length, 0);
  assert.equal(f.active.has(botId), true);
  assert.equal(f.removing.size, 0);
}

{
  const f = makeFixture({ save: false });
  f.active.set(botId, { logout: async () => undefined });
  const result = await f.operations.removeSubBot(botId);
  assert.equal(result.success, false);
  assert.match(result.message, /autenticação foram preservados/);
  assert.equal(f.getRegistry()[botId] !== undefined, true);
  assert.equal(f.events.removed.length, 0);
}

{
  const f = makeFixture();
  f.active.set(botId, { logout: async () => undefined });
  const result = await f.operations.removeSubBot(botId);
  assert.equal(result.success, true, result.message);
  assert.equal(f.getRegistry()[botId], undefined);
  assert.deepEqual(f.events.removed, [botId]);
}

console.log('SUBBOT OPERATIONS: PASS — listagem sanitizada, reconexão validada e remoção exige logout/persistência');
