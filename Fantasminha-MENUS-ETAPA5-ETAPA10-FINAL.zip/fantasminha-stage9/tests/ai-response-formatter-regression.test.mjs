import assert from 'node:assert/strict';
import { formatAIResponse } from '../src/services/aiResponseFormatter.js';

const cases = [
  [null, null],
  ['', ''],
  [42, 42],
  ['***forte*** **negrito** __itálico__', '*forte* *negrito* _itálico_'],
  ['antes\n```js\nconst x = 1;\n```\ndepois', 'antes\n\ndepois'],
  ['`inline` e # título\n\n\ntexto', 'inline e # título\n\ntexto'],
];
for (const [input, expected] of cases) assert.equal(formatAIResponse(input), expected);
console.log('AI RESPONSE FORMATTER REGRESSION: PASS');
