import assert from 'node:assert/strict';
import crypto from 'node:crypto';
process.env.NODE_ENV = 'test';
process.env.WEB_AUTH_USERNAME = 'owner-test';
process.env.WEB_AUTH_COOKIE_SECURE = 'false';
process.env.WEB_AUTH_RATE_MAX = '3';
process.env.WEB_AUTH_RATE_WINDOW_MS = '60000';
process.env.WEB_ALLOWED_ORIGINS = 'http://web.test';

const { hashPassword, sessionFromRequest } = await import('../src/platform/controlCenter/auth.js');
const testPassword = `${crypto.randomBytes(24).toString('base64url')}Aa9!`;
process.env.WEB_AUTH_PASSWORD_HASH = await hashPassword(testPassword);
const { startControlCenter, stopControlCenter } = await import('../src/platform/controlCenter/index.js');
startControlCenter({ host:'127.0.0.1', port:18787 });
await new Promise(r=>setTimeout(r,50));
const base='http://127.0.0.1:18787';
const jar={cookie:'',csrf:''};
async function req(path, options={}) {
  const headers=new Headers(options.headers||{});
  headers.set('Origin','http://web.test');
  if(jar.cookie) headers.set('Cookie', `${jar.cookie}${jar.csrf ? `; ${jar.csrf}` : ''}`);
  if (jar.csrf && String(options.method||'GET').toUpperCase() !== 'GET' && !headers.has('X-CSRF-Token') && !path.endsWith('/auth/login')) headers.set('X-CSRF-Token', jar.csrf.split('=')[1]);
  const res=await fetch(base+path,{...options,headers});
  const sets = typeof res.headers.getSetCookie === 'function' ? res.headers.getSetCookie() : (res.headers.get('set-cookie')||'').split(/,(?=\s*fantasminha_)/);
  for (const set of sets) { const first=set.split(';')[0]; if(first.startsWith('fantasminha_session=')) jar.cookie=first; if(first.startsWith('fantasminha_csrf=')) jar.csrf=first; }
  const text=await res.text();
  return {res,body:text?JSON.parse(text):null};
}

let r=await req('/api/auth/session');
assert.equal(r.res.status,401);

r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'owner-test',password:'wrong'})});
assert.equal(r.res.status,401);
assert.deepEqual(r.body,{error:'invalid_credentials'});

r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'wrong-user',password:testPassword})});
assert.equal(r.res.status,401);
assert.deepEqual(r.body,{error:'invalid_credentials'});

r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'owner-test',password:testPassword})});
assert.equal(r.res.status,200);
assert.equal(r.body.isAuthenticated,true);
assert.equal(r.body.user.role,'owner');
assert.ok(r.body.expiresAt > Date.now());
assert.match(r.res.headers.get('set-cookie') || '', /HttpOnly/);
assert.match(r.res.headers.get('set-cookie') || '', /SameSite=Lax/);

r=await req('/api/auth/session');
assert.equal(r.res.status,200);
assert.equal(r.body.isAuthenticated,true);

// Explicit RBAC: a valid session with a non-owner role must receive 403.
const roleSession = sessionFromRequest({ headers: { cookie: jar.cookie } });
assert.ok(roleSession);
roleSession.user.role = 'operator';
r = await req('/api/owner/dashboard');
assert.equal(r.res.status,403);
assert.deepEqual(r.body,{error:'forbidden'});
roleSession.user.role = 'owner';
r = await req('/api/owner/dashboard');
assert.equal(r.res.status,200);

r=await req('/api/auth/logout',{method:'POST'});
assert.equal(r.res.status,204);
r=await req('/api/auth/session');
assert.equal(r.res.status,401);

// Three bad attempts from a fresh username/IP are allowed; the fourth is rate-limited.
for(let i=0;i<3;i++) {
  r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'brute-test',password:'wrong'})});
  assert.equal(r.res.status,401);
}
r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'brute-test',password:'wrong'})});
assert.equal(r.res.status,429);
assert.equal(r.body.error,'too_many_attempts');
assert.ok(Number(r.res.headers.get('retry-after'))>0);

await stopControlCenter();
console.log('WEB AUTH: PASS');
