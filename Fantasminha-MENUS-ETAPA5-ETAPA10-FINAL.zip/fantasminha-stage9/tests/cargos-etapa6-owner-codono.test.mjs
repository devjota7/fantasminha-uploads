import assert from 'node:assert/strict';
import { getCommandPermission, canRoleRunCommand } from '../src/core/rolePermissionMatrix.js';
import { SPECIAL_ROLE } from '../src/core/specialRoles.js';

for (const cmd of ['adddono','adddonos','adicionardono','rmvdono','rmdono','deldono','removerdono','rmdonos']) {
  const rule = getCommandPermission(cmd);
  assert.deepEqual(rule?.roles, [SPECIAL_ROLE.OWNER], `${cmd} must be primary-owner only`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.OWNER, cmd), true);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.CO_OWNER, cmd), false);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUB_OWNER, cmd), false);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUPPORT, cmd), false);
}

assert.equal(canRoleRunCommand(SPECIAL_ROLE.CO_OWNER, 'donos'), true);
assert.equal(canRoleRunCommand(SPECIAL_ROLE.CO_OWNER, 'listadonos'), true);
assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUB_OWNER, 'donos'), false);
assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUPPORT, 'donos'), false);

console.log('CARGOS ETAPA6 OWNER/CO-OWNER: PASS');
