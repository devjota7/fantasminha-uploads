import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const root=fs.mkdtempSync(path.join(os.tmpdir(),'fantasminha-family-stage5-'));
process.env.FANTASMINHA_DB_ROOT=root;
const store=await import('../src/database/store.js');
const {clearRegistry,getCommand,validateRegistry}=await import('../src/core/registry.js');
const family=await import('../src/services/familyService.js');
const plugin=await import('../src/plugins/family/index.js');

await store.upsertUser('pai',{economy:{wallet:20000},family:{spouse:'conjuge'}});
await store.upsertUser('mae',{economy:{wallet:0}});
await store.upsertUser('filho',{economy:{wallet:0}});
await store.upsertUser('conjuge',{economy:{wallet:0}});

clearRegistry();
await plugin.register();

for (const name of ['adotaruser','biologico','desherdar','sairfamilia','arvore','linhagem','familia']) {
  const c=getCommand(name);
  assert.ok(c, `comando ausente: ${name}`);
  assert.equal(c.plugin,'family',`dono incorreto: ${name}`);
  assert.equal(c.groupOnly,true,`groupOnly incorreto: ${name}`);
}
assert.equal(getCommand('deserdar').name,'desherdar');
assert.equal(getCommand('removerfilho').name,'desherdar');
assert.equal(validateRegistry().ok,true);

await family.adopt({parentId:'pai',childId:'filho',biological:false,debitCost:10000});
await family.adopt({parentId:'mae',childId:'filho',biological:true});
assert.deepEqual(family.listChildren('pai'),[{childId:'filho',type:'adotivo'}]);
assert.deepEqual(family.listChildren('mae'),[{childId:'filho',type:'biologico'}]);
assert.equal(family.get('filho').filiationType,undefined);
const tree=family.tree('filho');
assert.ok(tree.lines.some(x=>x.includes('🧬')));
assert.ok(tree.lines.some(x=>x.includes('🍼')));

await family.removeChild({parentId:'pai',childId:'filho'});
assert.equal(family.get('pai').children.length,0);
assert.equal(family.get('filho').parents.length,1);
assert.equal(family.getFiliationType('filho','mae'),'biologico');

await family.leaveFamily({userId:'filho'});
assert.equal(family.get('filho').parents.length,0);
assert.equal(family.get('mae').children.length,0);
assert.equal(family.get('pai').spouse,'conjuge');

console.log('FAMILY_STAGE5_FINAL_PASS');
