import assert from 'node:assert/strict';
import { clearRegistry, registerAlias, registerCommand, getCommand, listCommands, validateRegistry } from '../src/core/registry.js';

clearRegistry();
const handler = async () => null;
registerCommand({ name: 'base', aliases: ['atalho'], priority: 0, handler });
registerCommand({ name: 'novo', aliases: ['atalho'], priority: 100, handler, classification: 'ACTIVE' });
assert.equal(getCommand('atalho')?.name, 'novo');
assert.deepEqual(getCommand('base')?.aliases, []);
assert.equal(validateRegistry().ok, true);

clearRegistry();
registerCommand({ name: 'compat', aliases: ['antigo'], priority: -100, legacyBridge: true, handler });
assert.equal(getCommand('antigo')?.classification, 'LEGACY');
assert.equal(listCommands({ classification: 'LEGACY' }).length, 1);

assert.equal(registerAlias('aliaslivre', 'compat').ok, true);
assert.equal(getCommand('aliaslivre')?.name, 'compat');
assert.equal(registerAlias('aliaslivre', 'outro').reason, 'target_missing');
assert.equal(validateRegistry().ok, true);

clearRegistry();
console.log('REGISTRY ETAPA 1 OK');
