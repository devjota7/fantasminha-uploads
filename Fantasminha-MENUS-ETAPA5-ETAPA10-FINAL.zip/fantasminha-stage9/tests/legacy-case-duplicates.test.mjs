import assert from 'node:assert/strict';
import fs from 'node:fs';
const text=fs.readFileSync(new URL('../dados/src/index.js',import.meta.url),'utf8');
const cases=[...text.matchAll(/\bcase\s+(['"])([^'"]+)\1\s*:/g)];
const switches=[];
let depth=0,pendingSwitch=false;
const switchStack=[];
let i=0;
while(i<text.length){
  if(text.startsWith('//',i)){i=text.indexOf('\n',i);if(i<0)break;continue;}
  if(text.startsWith('/*',i)){i=text.indexOf('*/',i+2)+2;continue;}
  const ch=text[i];
  if(ch==='"'||ch==="'"||ch==='`'){const q=ch;i++;while(i<text.length){if(text[i]==='\\'){i+=2;continue}if(text[i]===q){i++;break}i++;}continue;}
  if(/\s/.test(ch)){i++;continue;}
  if(text.startsWith('switch',i)&&!/[\w$]/.test(text[i-1]||'')&&!/[\w$]/.test(text[i+6]||'')){pendingSwitch=true;i+=6;continue;}
  if(ch==='{'){depth++;if(pendingSwitch){switchStack.push({depth,names:new Set(),duplicates:[]});pendingSwitch=false;}i++;continue;}
  if(ch==='}'){if(switchStack.at(-1)?.depth===depth)switchStack.pop();depth--;i++;continue;}
  if(text.startsWith('case',i)&&!/[\w$]/.test(text[i-1]||'')&&!/[\w$]/.test(text[i+4]||'')){let j=i+4;while(/\s/.test(text[j]||''))j++;const q=text[j];if(q==='"'||q==="'"){j++;let name='';while(j<text.length&&text[j]!==q){name+=text[j++]}const sw=switchStack.at(-1);if(sw&&sw.depth===depth){if(sw.names.has(name))sw.duplicates.push(name);sw.names.add(name);}}i=j+1;continue;}
  i++;
}
const duplicates=[...new Set(switches.flatMap(x=>x.duplicates))];assert.deepEqual(duplicates,[]);console.log('LEGACY CASE DUPLICATES: EXECUTADO-PASSOU');
