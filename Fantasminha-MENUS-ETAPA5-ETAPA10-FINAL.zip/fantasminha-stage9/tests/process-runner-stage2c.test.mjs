import assert from 'node:assert/strict';
import { runProcess, getActiveProcessCount } from '../src/services/processRunner.js';

const ok = await runProcess(process.execPath, ['-e', 'process.stdout.write("runner-ok")'], { timeout: 5000 });
assert.equal(ok.stdout, 'runner-ok');
assert.equal(getActiveProcessCount(), 0);

await assert.rejects(
  runProcess(process.execPath, ['-e', 'setTimeout(() => {}, 10000)'], { timeout: 100 }),
  error => error.processTimeout === true && error.code === null
);
assert.equal(getActiveProcessCount(), 0);

await assert.rejects(
  runProcess(process.execPath, ['-e', 'process.exit(7)'], { timeout: 5000 }),
  error => error.code === 7
);
assert.equal(getActiveProcessCount(), 0);

console.log('PROCESS RUNNER STAGE 2C: PASS');
