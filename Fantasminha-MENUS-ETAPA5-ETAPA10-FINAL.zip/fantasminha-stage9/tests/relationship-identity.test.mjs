import assert from 'node:assert/strict';
import relationshipManager from '../dados/src/funcs/utils/relationships.js';

const ids = {
  aLid: '111111111111111@lid',
  aPn: '5511999999999@s.whatsapp.net',
  bLid: '222222222222222@lid',
  bPn: '5511888888888@s.whatsapp.net'
};
const pairKey = (a, b) => [a, b].sort().join('::');
const oldDate = new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString();
const originalData = relationshipManager._loadData();
const originalSave = relationshipManager._saveData;

try {
  relationshipManager.pendingRequests.clear();
  relationshipManager._saveData({ pairs: {}, archived: [] });

  const selfDating = relationshipManager.createRequest('namoro', 'group@g.us', ids.aLid, ids.aPn, {
    requesterAliases: [ids.aLid, ids.aPn],
    targetAliases: [ids.aPn, ids.aLid],
    requesterCanonical: ids.aLid,
    targetCanonical: ids.aLid
  });
  assert.equal(selfDating.success, false, 'namoro deve rejeitar o próprio usuário quando PN e LID diferem');

  const dating = relationshipManager.createRequest('namoro', 'group@g.us', ids.aLid, ids.bPn, {
    requesterAliases: [ids.aLid, ids.aPn],
    targetAliases: [ids.bLid, ids.bPn],
    requesterCanonical: ids.aLid,
    targetCanonical: ids.bLid
  });
  assert.equal(dating.success, true, dating.message);
  assert.equal(dating.request.target, ids.bLid);
  assert.equal(dating.request.targetRaw, ids.bPn);
  const invalidDating = relationshipManager.processResponse('group@g.us', ids.bLid, 'talvez', [ids.bPn]);
  assert.equal(invalidDating?.reason, 'invalid_response');
  assert.equal(relationshipManager.hasPendingRequest('group@g.us'), true, 'resposta inválida deve preservar o pedido');

  relationshipManager._saveData = () => false;
  const failedDating = relationshipManager.processResponse('group@g.us', ids.bLid, 'sim', [ids.bPn]);
  assert.equal(failedDating?.success, false);
  assert.equal(failedDating?.reason, 'persistence_failed');
  assert.equal(relationshipManager.hasPendingRequest('group@g.us'), true, 'falha de gravação deve permitir retentar aceite');
  relationshipManager._saveData = originalSave;
  const acceptedDating = relationshipManager.processResponse('group@g.us', ids.bLid, 'sim', [ids.bPn]);
  assert.equal(acceptedDating?.success, true, acceptedDating?.message || acceptedDating?.reason);
  assert.equal(relationshipManager.hasPendingRequest('group@g.us'), false);
  assert.equal(relationshipManager._loadData().pairs[pairKey(ids.aLid, ids.bLid)]?.status, 'namoro');

  relationshipManager._saveData({
    pairs: {
      [pairKey(ids.aLid, ids.bPn)]: {
        users: [ids.aLid, ids.bPn],
        status: 'namoro',
        stages: { namoro: { since: oldDate } },
        history: [{ type: 'traicao', at: oldDate }]
      }
    },
    archived: []
  });
  const created = relationshipManager.createRequest('casamento', 'group@g.us', ids.aLid, ids.bPn, {
    requesterAliases: [ids.aLid, ids.aPn],
    targetAliases: [ids.bLid, ids.bPn],
    requesterCanonical: ids.aLid,
    targetCanonical: ids.bLid
  });
  assert.equal(created.success, true, created.message);
  assert.equal(created.request.target, ids.bLid, 'alvo canônico do pedido deve usar a identidade resolvida');
  assert.equal(created.request.targetRaw, ids.bPn, 'menção preserva o PN originalmente marcado');
  const accepted = relationshipManager.processResponse('group@g.us', ids.bLid, 'sim', [ids.bPn]);
  assert.equal(accepted?.success, true, accepted?.message || accepted?.reason);
  const married = relationshipManager._loadData().pairs[pairKey(ids.aLid, ids.bLid)];
  assert.equal(married?.status, 'casamento');
  assert.equal(married?.users.includes(ids.bLid), true);
  assert.equal(married?.history.some(entry => entry.type === 'traicao'), true, 'preserva histórico legado do casal');

  relationshipManager._saveData({
    pairs: {
      [pairKey(ids.aLid, ids.bPn)]: {
        users: [ids.aLid, ids.bPn],
        status: 'namoro',
        history: [{ type: 'traicao', at: oldDate }],
        stages: { namoro: { since: oldDate } }
      }
    },
    archived: []
  });
  const history = relationshipManager.getBetrayalHistory(ids.aLid, ids.bLid, {
    userAAliases: [ids.aLid, ids.aPn],
    userBAliases: [ids.bLid, ids.bPn],
    userACanonical: ids.aLid,
    userBCanonical: ids.bLid
  });
  assert.equal(history.success, true, history.message);
  assert.equal(history.betrayalCount, 1);

  relationshipManager._saveData({
    pairs: {
      [pairKey(ids.aLid, ids.bPn)]: {
        users: [ids.aLid, ids.bPn],
        status: 'namoro',
        history: [],
        stages: { namoro: { since: oldDate } }
      }
    },
    archived: []
  });
  relationshipManager._saveData = () => false;
  const ended = relationshipManager.endRelationship(ids.aLid, ids.bLid, ids.aLid, {
    userAAliases: [ids.aLid, ids.aPn],
    userBAliases: [ids.bLid, ids.bPn],
    userACanonical: ids.aLid,
    userBCanonical: ids.bLid
  });
  assert.equal(ended.success, false);
  assert.match(ended.message, /não foi possível salvar/i);
  const persisted = relationshipManager._loadData();
  assert.equal(persisted.pairs[pairKey(ids.aLid, ids.bPn)]?.status, 'namoro', 'falha de gravação não remove a relação persistida');
  assert.equal(persisted.archived.length, 0, 'falha de gravação não arquiva o relacionamento');

  console.log('RELATIONSHIP IDENTITY: PASS — namoro/casamento JID/LID, histórico legado, respostas inválidas e persistência');
} finally {
  relationshipManager._saveData = originalSave;
  relationshipManager.pendingRequests.clear();
  originalSave.call(relationshipManager, originalData);
}
