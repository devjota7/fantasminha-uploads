import assert from 'node:assert/strict';
import fs from 'node:fs';

const instaService = fs.readFileSync('src/services/social/instagramService.js', 'utf8');
const tiktokService = fs.readFileSync('src/services/social/tiktokService.js', 'utf8');
const instaPlugin = fs.readFileSync('src/plugins/social/perfilInsta.js', 'utf8');
const tiktokPlugin = fs.readFileSync('src/plugins/social/perfilTikTok.js', 'utf8');
const renderer = fs.readFileSync('src/services/social/socialProfileRenderer.js', 'utf8');

assert.match(instaService, /recentPosts\s*:\s*\[\]/);
assert.match(instaService, /collectInstagramPosts\(root, username, 3\)/);
assert.match(tiktokService, /recentVideos:\[\]/);
assert.match(tiktokService, /collectTikTokVideos\(root, username, 3\)/);
assert.match(instaPlugin, /renderSocialProfile/);
assert.match(tiktokPlugin, /renderSocialProfile/);
assert.match(instaPlugin, /Post \$\{i \+ 1\}.*p\.url/s);
assert.match(tiktokPlugin, /Vídeo \$\{i \+ 1\}.*v\.url/s);
assert.match(renderer, /FANTASMINHA/);
assert.match(renderer, /POSTS RECENTES/);
assert.match(renderer, /VÍDEOS RECENTES/);
assert.match(renderer, /imageBuffer/);
assert.match(renderer, /dataUri/);
assert.match(renderer, /import\('sharp'\)/);
console.log('✓ social-profile-image: renderer + 3 recent contents + external clickable links contract OK');
