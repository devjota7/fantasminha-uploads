import assert from 'node:assert/strict';
import { SPECIAL_ROLE } from '../src/core/specialRoles.js';
import { ROLE_PERMISSION, COMMAND_PERMISSION_MATRIX, canRoleRunCommand } from '../src/core/rolePermissionMatrix.js';

const rpgAdmin = [
  'rpgadd','rpgaddmoney','adicionardinheiro',
  'rpgremove','rpgremovemoney','removerdinheiro',
  'rpgsetlevel','setlevel','definirnivelrpg',
  'rpgadditem','adicionaritem','rpgremoveitem','removeritem',
  'rpgresetplayer','resetarjogador'
];
const globalReset = ['rpgresetglobal','resetrpgglobal'];

for (const command of rpgAdmin) {
  assert.equal(COMMAND_PERMISSION_MATRIX[command]?.permission, ROLE_PERMISSION.RPG_ADMIN, command);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.OWNER, command), true, `${command}: owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.CO_OWNER, command), true, `${command}: co-owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUB_OWNER, command), false, `${command}: sub-owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUPPORT, command), false, `${command}: support`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.VIP, command), false, `${command}: vip`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.ARANHA, command), false, `${command}: aranha`);
}

for (const command of globalReset) {
  assert.equal(COMMAND_PERMISSION_MATRIX[command]?.permission, ROLE_PERMISSION.RPG_RESET_GLOBAL, command);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.OWNER, command), true, `${command}: owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.CO_OWNER, command), false, `${command}: co-owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUB_OWNER, command), false, `${command}: sub-owner`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.SUPPORT, command), false, `${command}: support`);
  assert.equal(canRoleRunCommand(SPECIAL_ROLE.USER, command), false, `${command}: user`);
}

console.log('RPG ADMIN CO-OWNER: PASS — 15 comandos Owner+Co-Owner | 2 resets globais Owner-only | demais cargos bloqueados');
