import assert from 'node:assert/strict';
import { getConfiguredProviders } from '../src/services/aiService.js';
assert.deepEqual(getConfiguredProviders({ OPENAI_API_KEY:'x', OPENAI_MODEL:'gpt-5.6-luna' }), [{ name:'openai', model:'gpt-5.6-luna' }]);
assert.deepEqual(getConfiguredProviders({}), []);
console.log('AI FALLBACK LEGACY REMOVED: PASS');
