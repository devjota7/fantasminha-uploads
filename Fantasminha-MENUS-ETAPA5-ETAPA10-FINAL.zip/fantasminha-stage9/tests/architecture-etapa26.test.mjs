import assert from 'node:assert/strict';
import { auditArchitecture } from '../scripts/architecture-audit.mjs';

const result=auditArchitecture();
assert.equal(result.cycles.length,0,`ciclos encontrados: ${JSON.stringify(result.cycles)}`);
assert.equal(result.forbiddenBackupHits.length,0,`APIs/artefatos de backup encontrados: ${JSON.stringify(result.forbiddenBackupHits)}`);
assert.ok(result.files >= 300,`contagem inesperada de arquivos: ${result.files}`);
assert.ok(result.edges > 500,`grafo inesperadamente pequeno: ${result.edges}`);
console.log(`ARCHITECTURE ETAPA 26: PASS (${result.files} files, ${result.edges} edges, 0 cycles, 0 backup APIs)`);
