import assert from 'node:assert/strict';
import { buildCatalogMenu, organizeCommands, parseMenuNavigationArgs } from '../dados/src/menus/catalogMenu.js';
import { unstylize as plain } from '../src/respostas/estilo.js';

const commands = [
  {name:'ban', category:'admin', permission:60, enabled:true},
  {name:'setpersonalidade', category:'dono', permission:100, ownerOnly:true, enabled:true},
  {name:'controlcenter', category:'dono', permission:100, ownerOnly:true, enabled:true},
  {name:'scamcheck', category:'seguranca', permission:10, enabled:true},
  {name:'infovip', category:'premium', permission:40, enabled:true},
  {name:'ajuda', category:'sistema', permission:10, enabled:true},
];

const common={botName:'Fantasminha',userName:'Teste',commands};
const user=buildCatalogMenu('×','adm',{...common,permission:10});
assert.match(plain(user),/Nenhuma seção disponível|ADMINISTRAÇÃO/);
const admin=buildCatalogMenu('×','adm',{...common,permission:60});
assert.match(admin,/×ban\b/); assert.doesNotMatch(admin,/×menu adm (admin|triagem)/);
assert.doesNotMatch(admin,/×setpersonalidade|×controlcenter/);
const owner=buildCatalogMenu('×','dono',{...common,permission:100,subcategory:'configuracao'});
assert.match(owner,/×setpersonalidade/);
assert.match(owner,/×controlcenter/);
const premium=buildCatalogMenu('×','premium',{...common,permission:40,subcategory:'info'});
assert.match(premium,/×infovip/);
const system=buildCatalogMenu('×','sistema',{...common,permission:10,subcategory:'sistema'});
assert.match(system,/×ajuda/);
const nav=parseMenuNavigationArgs(['dono','2']);
assert.equal(nav.ok,false);
assert.equal(parseMenuNavigationArgs(['dono','configuracao']).ok,false);
assert.equal(parseMenuNavigationArgs(['dono','configuracao']).ok,false);
const org=organizeCommands(commands,{permission:100});
assert.equal(org.duplicates.length,0);
console.log('menus-privilege-etapa30 PASS');
