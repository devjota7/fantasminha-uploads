import assert from 'node:assert/strict';
process.env.BOT_PREFIX='!';process.env.PREFIX='/';
const {getBotPrefix,getEffectivePrefix}=await import('../src/core/prefix.js');
const fs=await import('node:fs');const legacy=fs.readFileSync(new URL('../dados/src/index.js',import.meta.url),'utf8');const block=legacy.slice(legacy.indexOf("case 'prefixo':"),legacy.indexOf("case 'nomedono':"));assert.equal(/config\.prefixo\s*=|writeJsonFile\(CONFIG_FILE/.test(block),false);
assert.equal(getBotPrefix(),'×');
assert.equal(getBotPrefix('!'),'×');
assert.equal(getEffectivePrefix('virtual'),'×');
console.log('PREFIX GLOBAL FIXED: EXECUTADO-PASSOU');
