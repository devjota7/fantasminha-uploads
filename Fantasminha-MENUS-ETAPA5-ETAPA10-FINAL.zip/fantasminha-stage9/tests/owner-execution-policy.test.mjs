import assert from 'node:assert/strict';
import { ownerShellAllowed, ownerEvalAllowed, ownerExecutionPolicy } from '../src/core/ownerExecutionPolicy.js';

const env = {};
assert.equal(ownerShellAllowed({ isOwner: false, env }), false);
assert.equal(ownerEvalAllowed({ isOwner: false, env }), false);
assert.equal(ownerShellAllowed({ isOwner: true, env }), false);
assert.equal(ownerEvalAllowed({ isOwner: true, env }), false);
assert.deepEqual(ownerExecutionPolicy(env), { shellEnabled:false, evalEnabled:false, defaultShellEnabled:false, defaultEvalEnabled:false });

assert.equal(ownerShellAllowed({ isOwner: true, env: { ALLOW_OWNER_SHELL: 'true' } }), true);
assert.equal(ownerShellAllowed({ isOwner: false, env: { ALLOW_OWNER_SHELL: 'true' } }), false);
assert.equal(ownerEvalAllowed({ isOwner: true, env: { ALLOW_OWNER_EVAL: 'true' } }), true);
assert.equal(ownerEvalAllowed({ isOwner: true, env: { ALLOW_OWNER_EVAL: 'TRUE' } }), true);
assert.equal(ownerEvalAllowed({ isOwner: true, env: { ALLOW_OWNER_EVAL: '1' } }), false);

console.log('OWNER EXECUTION POLICY OK — defaults disabled; owner identity required for explicit activation.');
