import assert from 'node:assert/strict';
import { sendPoll } from '../src/platform/whatsapp/messages.js';

const calls = [];
const sock = { sendMessage: async (...args) => { calls.push(args); return { ok: true }; } };
const result = await sendPoll(sock, '123@g.us', { name: '⚖️ Julguem ele(a)', options: ['Passo', 'Penso', 'Pego'], selectableCount: 1 });
assert.deepEqual(result, { ok: true });
assert.equal(calls.length, 1);
assert.deepEqual(calls[0], ['123@g.us', { poll: { name: '⚖️ Julguem ele(a)', values: ['Passo', 'Penso', 'Pego'], selectableCount: 1 } }]);
await assert.rejects(() => sendPoll(sock, '123@g.us', { name: '', options: ['A', 'B'] }), /Enquete inválida/);
console.log('PASS: test:platform-poll — adaptador de enquete usa somente a interface do socket.');
