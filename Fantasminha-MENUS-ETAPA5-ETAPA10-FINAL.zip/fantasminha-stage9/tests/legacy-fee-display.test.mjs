import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { formatFeePercent } from '../src/modules/economy/fees/fees.service.js';

const ROOT = new URL('../', import.meta.url);
const extract = command => execFileSync('node', ['scripts/extract-legacy-case.mjs', command], {
  cwd: ROOT,
  encoding: 'utf8'
});

const expected = new Map([
  [0, '0'], [2.5, '2.5'], [5, '5'], [7, '7'], [14, '14'], [15, '15'],
  [28, '28'], [29, '29'], [55, '55'], [56, '56'], [57, '57'], [58, '58'], [100, '100']
]);
for (const [percent, text] of expected) {
  assert.equal(formatFeePercent(percent * 100), text, `formatação ${percent}%`);
}

const saque = extract('sacar');
const transferencia = extract('transferir');
const mercado = extract('mercadoplayer');

assert.match(saque, /Taxa \(\$\{formatFeePercent\(taxaRate \* 10_000\)\}%\)/);
assert.match(transferencia, /Taxa de transferência: \$\{formatFeePercent\(getFeeRateSync\('transferencia'\) \* 10_000\)\}%/);
assert.match(transferencia, /Taxa \(\$\{formatFeePercent\(taxaRate \* 10_000\)\}%\)/);
assert.match(mercado, /Taxa: \$\{formatFeePercent\(getFeeRateSync\('mercado'\) \* 10_000\)\}% por venda/);
assert.match(mercado, /Taxa de \$\{formatFeePercent\(getFeeRateSync\('mercado'\) \* 10_000\)\}% será cobrada na venda/);

for (const [name, source] of [['sacar', saque], ['transferir', transferencia], ['mercadoplayer', mercado]]) {
  assert.doesNotMatch(source, /\$\{taxaRate \* 100\}%/);
  assert.doesNotMatch(source, /\$\{getFeeRateSync\('(?:saque|transferencia|mercado)'\) \* 100\}%/);
  if (name !== 'mercadoplayer') assert.match(source, /Math\.floor\(amount \* taxaRate\)/);
}
assert.match(mercado, /Math\.floor\(listing\.price \* \(1 - getFeeRateSync\('mercado'\)\)\)/);

const indexSource = readFileSync(new URL('../dados/src/index.js', import.meta.url), 'utf8');
assert.match(indexSource, /import \{ formatFeePercent, getFeeRateSync \}/);

console.log('LEGACY FEE DISPLAY: PASS — 13 percentuais sem ruído; mercado usa taxa vigente; fórmulas de cobrança preservadas; casos extraídos sem iniciar bot');
