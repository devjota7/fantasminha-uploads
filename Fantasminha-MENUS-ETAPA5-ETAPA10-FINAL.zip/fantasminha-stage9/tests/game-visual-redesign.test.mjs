import assert from 'node:assert/strict';
import { unstylize } from '../src/respostas/estilo.js';
import { dossierHeader, graffitiHeader, hudHeader, cleanGridTitle } from '../src/games/gamePresentation.js';
import { renderQuestion, renderResult as renderQuizResult } from '../src/games/quiz/QuizRenderer.js';
import { renderRound, renderAnswerPrompt, renderResult as renderMemoryResult } from '../src/games/memory-cups/MemoryCupsRenderer.js';
import * as gartic from '../src/games/gartic/GarticRenderer.js';
import garticService from '../src/games/gartic/GarticService.js';
import { render as renderTower } from '../src/games/torre-limbo/index.js';
import { findErrorGame } from '../src/services/innovation.js';
import game from '../src/services/gameEngine.js';
import { decorateOutgoingContent } from '../src/respostas/outgoing.js';

assert.match(hudHeader('Quiz em andamento', 'QUIZ'), /^\/\/ FANTASMINHA · 0xQUIZ\n/);
assert.match(dossierHeader('Resultado'), /^† DOSSIÊ · /);
assert.match(graffitiHeader('Jogo social'), /^# .* · FANTASMINHA$/);
assert.match(cleanGridTitle('Memória dos copos'), /^👻 /);
assert.equal(unstylize(hudHeader('Quiz em andamento', 'QUIZ').split('\n')[1]), 'QUIZ EM ANDAMENTO');

const session = {
  category: 'geral', difficulty: 'medium', question: 'Qual é a resposta?',
  options: [{ text: 'A' }, { text: 'B' }, { text: 'C' }, { text: 'D' }]
};
const question1 = renderQuestion(session);
const question2 = renderQuestion(session);
assert.match(question1, /^\/\/ FANTASMINHA · 0xQUIZ/m);
assert.ok(question1.includes('Qual é a resposta?'));
assert.ok(question1.includes('4️⃣ D'));
assert.ok(question1.includes('45 segundos'));
assert.notEqual(question1.split('\n').at(-1), question2.split('\n').at(-1), 'rodapé do mesmo tipo de jogo deve variar');

const quizResult = renderQuizResult({
  correctAnswer: 'B', responses: 5, correctCount: 2, wrongCount: 3,
  correctAnswers: [{ userId: 'u2', points: 50, responseTimeMs: 1000 }, { userId: 'u1', points: 80, responseTimeMs: 500 }]
}, id => `@${id}`, 'expired');
assert.match(quizResult, /^† DOSSIÊ ·/);
assert.ok(quizResult.includes('Resposta correta: B'));
assert.ok(quizResult.includes('Participações: 5'));
assert.ok(quizResult.indexOf('@u1') < quizResult.indexOf('@u2'));

const board = renderRound({ level: 4, cupCount: 5, ghostPosition: 2, showGhost: true });
assert.match(board, /^👻 /);
assert.ok(board.includes('👻'));
assert.ok(board.includes('🥤'));
assert.doesNotMatch(board, /1️⃣|2️⃣|3️⃣/, 'grade não revela posições durante a animação');
assert.ok(renderAnswerPrompt({ level: 4, cupCount: 5 }).includes('1 a 5'));
assert.equal(decorateOutgoingContent({ text: board }, { command: 'memoria', category: 'jogos' }).text, board, 'a grade limpa não deve receber uma moldura geral');
const memoryResult = renderMemoryResult({ level: 4, cupCount: 5, selectedPosition: 3, correctPosition: 3, score: 120, bestLevel: 8, streak: 4 });
assert.match(memoryResult, /^† DOSSIÊ ·/);
assert.ok(memoryResult.includes('Pontuação: 120'));
assert.ok(memoryResult.includes('Melhor nível: 8'));

const drawing = gartic.round({ category: 'animais', difficulty: 'easy', word: 'GATO', timeoutMs: 60000 });
assert.match(drawing, /^# .* · FANTASMINHA$/m);
assert.ok(drawing.includes('Letras: _ _ _ _'));
assert.ok(!drawing.includes('GATO'));
assert.ok(gartic.won({ winnerName: 'Jota', word: 'gato', score: 90 }).includes('Pontuação: +90 pontos'));
assert.match(gartic.expired({ word: 'gato' }), /^† DOSSIÊ ·/);

const towerState = {
  floor: 12, score: 160, protections: 1, fragments: 2, multiplier: 1.5,
  floorType: 'dangerous', challenge: { prompt: 'Responda com AZUL.', timer: 5000 }
};
const towerScreen = renderTower(towerState);
assert.match(towerScreen, /^\/\/ FANTASMINHA · 0xTORRE/m);
assert.ok(towerScreen.includes('Andar 12/500'));
assert.ok(towerScreen.includes('Responda com AZUL.'));
assert.ok(towerScreen.includes('Tempo: 5s'));
assert.match(unstylize(renderTower(towerState, '✓ Acerto registrado.')), /† DOSSIÊ · ÚLTIMO RESULTADO/);
assert.doesNotMatch(towerScreen, /╭──────|╰──/);

let scanMessage = '';
const scan = await findErrorGame({
  jid: 'visual-test@g.us', level: 1,
  sendMessage: async (_jid, content) => { scanMessage = content.text; return { key: { id: 'scan' } }; }
});
assert.equal(scan.size, 3);
assert.match(scanMessage, /^\/\/ FANTASMINHA · 0xSCAN/);
assert.ok(scanMessage.includes('Responda com a posição (1-9).'));
assert.equal([...scanMessage].filter(char => char === '🔷').length, 1);

const maintenanceGroup = `gartic-maintenance-${Date.now()}@g.us`;
let maintenanceMessage = '';
await garticService.start({
  isGroup: true, from: maintenanceGroup, sender: 'tester',
  reply: async text => { maintenanceMessage = String(text); return { ok: true }; }
});
assert.ok(unstylize(maintenanceMessage).toLowerCase().includes('em manutenção'));
assert.equal(game.listActiveGames(maintenanceGroup).filter(item => item.gameType === 'gartic').length, 0);

console.log('GAME VISUAL REDESIGN: PASS — HUD, laudo, graffiti, grade limpa e dados preservados');
