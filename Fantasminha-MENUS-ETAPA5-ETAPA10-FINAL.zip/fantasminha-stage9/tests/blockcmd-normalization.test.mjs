import assert from 'node:assert/strict';
import fs from 'node:fs';
const source = fs.readFileSync('dados/src/index.js', 'utf8');
const start = source.indexOf("case 'blockcmd':");
const end = source.indexOf("case 'unblockcmd':", start);
const block = source.slice(start, end);
const unblock = source.slice(end, source.indexOf("case 'ttt':", end));
for (const text of [block, unblock]) {
  assert.ok(text.includes('q.trim().split(/\\s+/)[0]'), 'usa somente o primeiro token');
  assert.ok(text.includes('normalizar('), 'normaliza o comando');
  assert.ok(text.includes("replaceAll(prefix, '')"), 'remove o prefixo');
}
assert.ok(unblock.includes('blockedCommandName'));
console.log('BLOCKCMD NORMALIZATION: PASS');
