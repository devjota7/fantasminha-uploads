// Menu principal em carrossel: 1 cartão por menu, cada cartão com o SEU botão.
// Testa só a montagem (sem WhatsApp): estrutura dos cartões, limites e ids.
import assert from 'node:assert/strict';
import {
  MAIN_MENU_FLOW_ENTRIES,
  MAIN_MENU_CAROUSEL_MIN_CARDS,
  MAIN_MENU_CAROUSEL_MAX_CARDS,
  MAIN_MENU_CAROUSEL_BUTTON_LABEL,
  buildMainMenuCarousels,
  buildCarouselInteractive,
  getMainMenuGroups,
  getMainMenuStyle,
  resolveMainMenuFlowSelection
} from '../dados/src/menus/mainMenuCatalog.js';
import { MENUS } from '../dados/src/menus/menuMap.js';

const flat = carousels => carousels.flatMap(c => c.cards);
const idsOf = carousels => flat(carousels).map(c => c.id);
const cardProfile = body => body.startsWith('// FANTASMINHA · 0x') ? 'glitch'
  : body.startsWith('† DOSSIÊ · ') ? 'dossier'
    : body.startsWith('† FANTASMINHA · ') ? 'gothic'
      : body.startsWith('# ') && body.endsWith(' · FANTASMINHA') ? 'graffiti' : null;

for (const permission of [undefined, 10, 40, 60, 100]) {
  const carousels = buildMainMenuCarousels('×', { permission });
  const cards = flat(carousels);
  const visible = getMainMenuGroups({ permission }).flatMap(g => g.entries);

  // limites do WhatsApp por carrossel
  for (const c of carousels) {
    assert.ok(c.cards.length >= MAIN_MENU_CAROUSEL_MIN_CARDS && c.cards.length <= MAIN_MENU_CAROUSEL_MAX_CARDS,
      `carrossel "${c.title}" com ${c.cards.length} cartões (permissão ${permission})`);
    assert.ok(c.title.length > 0, 'carrossel sem título');
  }
  // cada menu visível aparece em exatamente UM cartão, na mesma ordem da lista
  assert.deepEqual(idsOf(carousels), visible.map(e => e.id), `ordem/conjunto de cartões (permissão ${permission})`);
  assert.equal(new Set(idsOf(carousels)).size, cards.length, 'ids repetidos entre cartões');

  for (const card of cards) {
    // estrutura idêntica em todos os cartões: 1 botão de resposta rápida
    assert.equal(card.button.name, 'quick_reply');
    const params = JSON.parse(card.button.buttonParamsJson);
    assert.equal(params.id, card.id, 'o botão deve devolver o id do PRÓPRIO menu');
    assert.ok(params.display_text.length > 0 && params.display_text.length <= 20, 'rótulo do botão > 20 caracteres');
    assert.equal(params.display_text, MAIN_MENU_CAROUSEL_BUTTON_LABEL);
    // o id é aceito pela lista branca que o ×menu usa ao receber o clique
    assert.equal(resolveMainMenuFlowSelection(card.id)?.command, card.command);
    assert.equal(card.body.includes(`×${card.command}`), false, 'cartão não pode repetir o comando do menu');
    assert.ok(cardProfile(card.body), `card ${card.id} sem assinatura de domínio`);
    assert.equal(card.body.includes(card.command), false, 'corpo do cartão não pode exibir comando');
    assert.equal('description' in card, false, 'description deve ser removido do cartão');
  }
}

const profiles = new Set(flat(buildMainMenuCarousels('×', { permission: 100 })).map(card => cardProfile(card.body)));
assert.deepEqual([...profiles].sort(), ['dossier', 'glitch', 'gothic', 'graffiti'], 'o carrossel deve representar os quatro perfis aprovados');

// visibilidade por permissão
const idsFor = p => new Set(idsOf(buildMainMenuCarousels('×', { permission: p })));
assert.equal(idsFor(10).has('menu:adm'), false);
assert.equal(idsFor(10).has('menu:dono'), false);
assert.equal(idsFor(60).has('menu:adm'), true);
assert.equal(idsFor(60).has('menu:dono'), false);
assert.equal(idsFor(100).has('menu:dono'), true);

// Aranha está na lista de menus, para todos os níveis, em cartão próprio
for (const p of [undefined, 10, 60, 100]) assert.ok(idsFor(p).has('menu:aranha'), `menu:aranha ausente (permissão ${p})`);
assert.equal(resolveMainMenuFlowSelection('menu:aranha').command, 'menuaranha');

// Dono vê todos os destinos do catálogo: um cartão por entrada (13)
assert.equal(flat(buildMainMenuCarousels('×', { permission: 100 })).length, MAIN_MENU_FLOW_ENTRIES.length);

// Todo menu do mapa oficial tem cartão (exceto o que só existe como apelido)
const cardCommands = new Set(flat(buildMainMenuCarousels('×', { permission: 100 })).map(c => c.command));
for (const menu of Object.values(MENUS)) assert.ok(cardCommands.has(menu.command), `sem cartão para ${menu.command}`);

// O corpo do cartão não repete o comando; o prefixo continua relevante apenas no fluxo/lista.
assert.ok(flat(buildMainMenuCarousels('!', { permission: 100 })).every(c => !c.body.includes(`!${c.command}`))); 

// Payload: sem cabeçalho no nível da mensagem, imagem em todos os cartões, 1 botão por cartão
const media = { url: 'x' };
const carousel = buildMainMenuCarousels('×', { permission: 100 })[0];
const payload = buildCarouselInteractive({ bodyText: carousel.title, cards: carousel.cards, imageMessage: media });
assert.equal(payload.header, undefined);
assert.equal(payload.carouselMessage.cards.length, carousel.cards.length);
for (const card of payload.carouselMessage.cards) {
  assert.equal(card.header.hasMediaAttachment, true);
  assert.equal(card.header.imageMessage, media);
  assert.equal(card.nativeFlowMessage.buttons.length, 1);
}

// Estilo: carrossel por padrão; lista agora é texto e botao é o Native Flow.
assert.equal(getMainMenuStyle({}), 'carrossel');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: 'lista' }), 'lista');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: ' LISTA ' }), 'lista');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: 'botao' }), 'botao');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: 'antigo' }), 'botao');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: 'texto' }), 'lista');
assert.equal(getMainMenuStyle({ MENU_PRINCIPAL_ESTILO: 'qualquer' }), 'carrossel');

const sizes = buildMainMenuCarousels('×', { permission: 100 }).map(c => c.cards.length);
console.log(`PASS: test:main-menu-carousel — 1 cartão por destino (13 p/ dono), carrosséis ${sizes.join('+')} (2..10), ids na lista branca, Aranha incluída, estilo lista reversível.`);
