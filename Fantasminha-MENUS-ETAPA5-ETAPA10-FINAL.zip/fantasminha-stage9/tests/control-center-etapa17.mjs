import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DB_ROOT, readCollection, writeCollection } from '../src/database/store.js';
import { hashPassword, __testResetAuthState } from '../src/platform/controlCenter/auth.js';
import commercial from '../src/services/platformCommercial.js';

process.env.NODE_ENV='test';
process.env.WEB_AUTH_USERNAME='etapa17-owner';
process.env.WEB_AUTH_COOKIE_SECURE='false';
process.env.WEB_AUTH_TOTP_SECRET='';
process.env.WEB_AUTH_RATE_PERSIST='false';
process.env.WEB_ALLOWED_ORIGINS='http://etapa17.test';
process.env.WEB_AUTH_PASSWORD_HASH=await hashPassword('Etapa17-Test-Password!');

for(const [name,data] of [
 ['commercial_platform',{version:1,globalMode:false,clients:{},keys:{},rentals:{},plans:{},operations:{}}],
 ['platform_api_keys',{version:1,keys:{}}],
 ['platform_audit',{events:[]}],
 ['web_auth_sessions',{version:1,sessions:{}}]
]) writeCollection(name,data);
__testResetAuthState();
const {startControlCenter,stopControlCenter,waitForControlCenter}=await import('../src/platform/controlCenter/index.js');
const port=18917; startControlCenter({host:'127.0.0.1',port}); await waitForControlCenter(); const base=`http://127.0.0.1:${port}`;
let session='',csrf='';
async function req(path,options={},origin='http://etapa17.test'){
 const headers=new Headers(options.headers||{}); if(origin!==null)headers.set('Origin',origin); headers.set('Connection','close');
 const cookies=[session,csrf?`fantasminha_csrf=${encodeURIComponent(csrf)}`:''].filter(Boolean).join('; '); if(cookies)headers.set('Cookie',cookies);
 const method=String(options.method||'GET').toUpperCase(); if(csrf&&['POST','PUT','PATCH','DELETE'].includes(method)&&!headers.has('X-CSRF-Token'))headers.set('X-CSRF-Token',csrf);
 const response=await fetch(base+path,{...options,headers});
 const sets=typeof response.headers.getSetCookie==='function'?response.headers.getSetCookie():(response.headers.get('set-cookie')||'').split(/,(?=\s*fantasminha_)/);
 for(const set of sets){const first=set.split(';')[0];if(first.startsWith('fantasminha_session='))session=first;if(first.startsWith('fantasminha_csrf='))csrf=decodeURIComponent(first.slice('fantasminha_csrf='.length));}
 const text=await response.text();let body=null;try{body=text?JSON.parse(text):null}catch{body=text;}return {response,body};
}
const post=(path,body={})=>req(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
try{
 let r=await req('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:'etapa17-owner',password:'Etapa17-Test-Password!'})});
 assert.equal(r.response.status,200);
 const client=commercial.ensureClient({clientId:`CLI-${crypto.randomBytes(4).toString('hex')}`,name:'Cliente Etapa 17',actor:'test'});
 const key=commercial.createKey({clientId:client.clientId,durationDays:30,actor:'test'});
 commercial.activateKey(key.secret,'5511888888888-123@g.us','test','et17-act');
 const rental=commercial.listRentals()[0];
 r=await req('/api/owner/rentals'); assert.equal(r.response.status,200); assert.equal(r.body.items.length,1); assert.equal(r.body.items[0].id,rental.rentalId); assert.equal(r.body.items[0].clientName,client.name);
 r=await req(`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/license`); assert.equal(r.response.status,200); assert.equal(r.body.item.licenseId,rental.rentalId);
 r=await req(`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/history`); assert.equal(r.response.status,200); assert.ok(r.body.items.some(x=>x.action==='RENTAL_ACTIVATED'));
 r=await post(`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/state`,{state:'SUSPENDED'}); assert.equal(r.response.status,200); assert.equal(r.body.item.state,'SUSPENDED');
 r=await post(`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/renew`,{days:15}); assert.equal(r.response.status,200); assert.equal(r.body.item.rental.state,'ACTIVE');
 r=await post(`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/state`,{state:'SUSPENDED'}); assert.equal(r.response.status,200);
 r=await post('/api/owner/rentals/expire-due'); assert.equal(r.response.status,200); assert.ok(Array.isArray(r.body.groups));
 const db=readCollection('commercial_platform'); db.rentals[rental.groupId].state='ACTIVE'; db.rentals[rental.groupId].expiresAt=Date.now()-1; writeCollection('commercial_platform',db);
 r=await post('/api/owner/rentals/expire-due'); assert.equal(r.response.status,200); assert.deepEqual(r.body.groups,[rental.groupId]);
 r=await req('/api/owner/rentals',{},'http://evil.etapa17.test'); assert.equal(r.response.status,403);
 r=await fetch(base+`/api/owner/rentals/${encodeURIComponent(rental.rentalId)}/renew`,{method:'POST',headers:{Origin:'http://etapa17.test',Cookie:session,'Content-Type':'application/json',Connection:'close'},body:JSON.stringify({days:10})}); assert.equal(r.status,403);
 r=await req('/api/owner/plans'); assert.equal(r.response.status,200); assert.ok(Array.isArray(r.body.items));
 console.log('CONTROL CENTER ETAPA 17: PASS — rentals | licença | histórico | renovação | estado | expiração | CSRF | origem');
} finally { await stopControlCenter(); }
