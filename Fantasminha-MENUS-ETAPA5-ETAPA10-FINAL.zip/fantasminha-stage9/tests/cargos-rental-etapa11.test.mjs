import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

process.env.FANTASMINHA_TEST_MODE = '1';
const { DB_ROOT } = await import('../src/database/store.js');
for (const n of ['commercial_platform', 'platform_audit']) {
  try { fs.rmSync(path.join(DB_ROOT, `${n}.json`), { force: true }); } catch {}
}
fs.mkdirSync(DB_ROOT, { recursive: true });
fs.writeFileSync(path.join(DB_ROOT, 'platform_audit.json'), JSON.stringify({ events: [] }));

const commercial = await import('../src/services/platformCommercial.js');
const matrix = await import('../src/core/rolePermissionMatrix.js');
const bridge = await import('../src/platform/chatbridge/server.js');

assert.equal(matrix.maxDaysForCommand('addaluguel'), 30);
assert.equal(matrix.maxDaysForCommand('gerarcod'), 30);
assert.equal(matrix.maxDaysForCommand('estenderaluguel'), 30);
assert.deepEqual(matrix.getCommandPermission('removeraluguel').roles, ['owner', 'co_owner']);

const supportKey = commercial.createKey({ durationDays: 30, actor: 'support-command', actorRole: 'support' });
assert.equal(supportKey.durationDays, 30);
assert.throws(() => commercial.createKey({ durationDays: 31, actor: 'support-command', actorRole: 'support' }), /no máximo 30 dias/);
assert.throws(() => commercial.createKey({ durationDays: 'permanent', actor: 'support-command', actorRole: 'support' }), /no máximo 30 dias|permanente/);

const subKey = commercial.createKey({ durationDays: 30, actor: 'subowner-command', actorRole: 'sub_owner' });
assert.equal(subKey.durationDays, 30);
assert.throws(() => commercial.createKey({ durationDays: 365, actor: 'subowner-command', actorRole: 'sub_owner' }), /no máximo 30 dias/);

const ownerKey = commercial.createKey({ durationDays: 365, actor: 'owner-command', actorRole: 'owner' });
assert.equal(ownerKey.durationDays, 365);
const ownerPermanent = commercial.createKey({ durationDays: 'permanent', actor: 'owner-command', actorRole: 'owner' });
assert.equal(ownerPermanent.durationDays, 'permanent');
const coOwnerKey = commercial.createKey({ durationDays: 365, actor: 'co-owner-command', actorRole: 'co_owner' });
assert.equal(coOwnerKey.durationDays, 365);

const gid = `120363${Date.now()}@g.us`;
const activated = commercial.activateKey(supportKey.secret, gid, 'support-command');
assert.equal(activated.success, true);
assert.equal(activated.rental.permanent, false);
assert.throws(() => commercial.renewRental(gid, 31, 'support-command', null, 'support'), /no máximo 30 dias/);
const extended = commercial.renewRental(gid, 30, 'support-command', null, 'support');
assert.equal(extended.addedDays, 30);
assert.throws(() => commercial.renewRental(gid, 31, 'subowner-command', null, 'sub_owner'), /no máximo 30 dias/);

assert.equal(bridge.SPECIAL_ROLE_DELEGATED_COMMANDS.has('addaluguel'), true);
assert.equal(bridge.SPECIAL_ROLE_DELEGATED_COMMANDS.has('gerarcod'), true);
assert.equal(bridge.SPECIAL_ROLE_DELEGATED_COMMANDS.has('estenderaluguel'), true);
assert.equal(bridge.SPECIAL_ROLE_DELEGATED_COMMANDS.has('removeraluguel'), false);

const dados = fs.readFileSync(new URL('../dados/src/index.js', import.meta.url), 'utf8');
for (const needle of [
  "authorizeRentalCommand('addaluguel')",
  "authorizeRentalCommand(command)",
  "setGroupRental(from, durationDays, { actorRole: rentalRoleAdd })",
  "generateActivationCode(durationDays, rentalRoleCode)",
  "extendGroupRental(targetGroupId, daysToAdd, rentalRoleExtend)",
  "daysToAdd > 30",
  "durationDays === 'permanent' || durationDays > 30"
]) assert.match(dados, new RegExp(needle.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));

console.log('CARGOS ETAPA11 ALUGUEL: PASS — matriz | backend max 30 | permanente bloqueado | Owner/Co-Owner preservados | bridge delegado');
