import assert from 'node:assert/strict';

const { FantasminhaApiClient, ApiClientError, CircuitBreaker } = await import('../src/services/api/FantasminhaApiClient.js');

const fs = (await import('node:fs')).default;
const pipelineSource = fs.readFileSync(new URL('../src/middleware/pipeline.js', import.meta.url), 'utf8');
assert.match(pipelineSource, /void syncWhatsAppContext\(ctx\)\.then/);
const envExample = fs.readFileSync(new URL('../.env.example', import.meta.url), 'utf8');
for (const key of ['FANTASMINHA_API_ENABLED=', 'FANTASMINHA_API_URL=', 'FANTASMINHA_API_TIMEOUT_MS=', 'FANTASMINHA_API_RETRIES=']) assert.ok(envExample.includes(key));

const originalFetch = globalThis.fetch;
try {
  let calls = 0;
  globalThis.fetch = async (url, opts) => {
    calls++;
    assert.ok(url.startsWith('http://api.test/'));
    assert.ok(opts.headers['x-request-id']);
    assert.equal(opts.headers['x-api-client-secret'], 'secret');
    if (url.endsWith('/api/v1/providers')) return new Response(JSON.stringify({ ok: true, data: { providers: [] } }), { status: 200 });
    return new Response(JSON.stringify({ ok: false, error: { code: 'NOPE', message: 'não encontrado' } }), { status: 404 });
  };
  const c = new FantasminhaApiClient({ baseUrl: 'http://api.test', clientSecret: 'secret', enabled: true, retries: 0 });
  const ok = await c.providers({ userId: 'u', groupId: 'g' });
  assert.equal(ok.ok, true);
  await assert.rejects(() => c.request('/api/v1/unknown', { retries: 0 }), e => e instanceof ApiClientError && e.status === 404 && e.retryable === false);
  assert.equal(c.breaker.state(), 'closed', 'erro 4xx não pode abrir circuit breaker');
  assert.equal(c.maxRetries, 0, 'alias retries deve ser compatível');
  assert.ok(calls >= 2);

  let retryCalls = 0;
  globalThis.fetch = async () => {
    retryCalls++;
    if (retryCalls === 1) return new Response(JSON.stringify({ ok: false, error: { code: 'TEMP', message: 'temporário' } }), { status: 503 });
    return new Response(JSON.stringify({ ok: true, data: { recovered: true } }), { status: 200 });
  };
  const retryClient = new FantasminhaApiClient({ baseUrl: 'http://api.test', clientSecret: 'secret', enabled: true, retries: 1 });
  const recovered = await retryClient.providers();
  assert.equal(recovered.ok, true);
  assert.equal(retryCalls, 2);

  const b = new CircuitBreaker({ failureThreshold: 2, resetMs: 5 });
  b.failure(); b.failure(); assert.equal(b.state(), 'open');
  await new Promise(r => setTimeout(r, 8));
  assert.equal(b.canRequest(), true);

  console.log('FATIA9 API CLIENT CONTRACT/HARDENING: PASS');
} finally {
  globalThis.fetch = originalFetch;
}
