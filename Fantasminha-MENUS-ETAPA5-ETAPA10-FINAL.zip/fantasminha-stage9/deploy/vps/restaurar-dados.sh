#!/usr/bin/env bash
# Restaura SOMENTE dados e segredos a partir de um backup .tgz feito com:
#   cd /root/Bots && tar --exclude='fantasminha/node_modules' --exclude='fantasminha/logs' \
#       -czf fantasminha-COMPLETO.tgz fantasminha
#
# Restaura: .env · data/ · dados/database/ · dados/src/config.json · dados/midias/
# NÃO restaura: código (src, dados/src/*.js...), node_modules, logs.
#
# Uso:  bash deploy/vps/restaurar-dados.sh [--dry-run] [--force] ARQUIVO.tgz
#   --dry-run  só mostra o que seria restaurado (não escreve nada)
#   --force    sobrescreve arquivos existentes (antes copia os atuais para .pre-restore-<data>)
# Sem --force, arquivos que já existem no destino são mantidos.
set -Eeuo pipefail

APP_DIR="${FANTASMINHA_DIR:-/root/Bots/fantasminha}"
SERVICE_NAME="${FANTASMINHA_SERVICE:-fantasminha}"
DRY=0; FORCE=0; ARCHIVE=""

log(){ printf '[👻] %s\n' "$*"; }
warn(){ printf '[⚠️ ] %s\n' "$*" >&2; }
fail(){ printf '[❌] %s\n' "$*" >&2; exit 1; }

while (( $# )); do
  case "$1" in
    --dry-run) DRY=1 ;;
    --force) FORCE=1 ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    -*) fail "Opção desconhecida: $1" ;;
    *) [[ -z "$ARCHIVE" ]] || fail "Informe apenas um arquivo."; ARCHIVE="$1" ;;
  esac
  shift
done

[[ -n "$ARCHIVE" && -f "$ARCHIVE" ]] || fail "Informe o .tgz de backup (arquivo não encontrado: ${ARCHIVE:-<vazio>})."
[[ -d "$APP_DIR" ]] || fail "Pasta do bot não existe: $APP_DIR (envie o bot antes de restaurar os dados)."

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
tar -tzf "$ARCHIVE" > "$TMP/names.txt" 2>"$TMP/err.txt" || { cat "$TMP/err.txt" >&2; fail "O arquivo não é um .tgz válido."; }
[[ -s "$TMP/names.txt" ]] || fail "Backup vazio."

# Segurança: nada de caminho absoluto nem '..'
if grep -Eq '(^/|(^|/)\.\.(/|$))' "$TMP/names.txt"; then
  fail "Backup contém caminhos absolutos ou com '..'. Restauração abortada."
fi

TOP="$(head -n1 "$TMP/names.txt" | cut -d/ -f1)"
[[ -n "$TOP" && "$TOP" != "." ]] || fail "Não consegui identificar a pasta raiz dentro do backup."
if grep -Evq "^${TOP//./\\.}(/|$)" "$TMP/names.txt"; then
  fail "O backup mistura pastas raiz diferentes de '$TOP'. Restauração abortada."
fi

# Lista permitida (sem links simbólicos/hardlinks)
tar -tvzf "$ARCHIVE" | awk -v top="$TOP" '
  { t=substr($1,1,1); name=$6; for(i=7;i<=NF;i++) name=name" "$i; sub(/ -> .*/,"",name);
    if (t=="l" || t=="h") { print "SKIPLINK\t" name; next }
    print "ENTRY\t" t "\t" name }' > "$TMP/verbose.txt"

SKIPPED_LINKS="$(grep -c '^SKIPLINK' "$TMP/verbose.txt" || true)"
: > "$TMP/list.txt"
while IFS=$'\t' read -r kind t name; do
  [[ "$kind" == "ENTRY" ]] || continue
  [[ "$name" != *\\* ]] || continue
  rel="${name#"$TOP"/}"
  [[ "$name" != "$TOP" ]] || continue
  case "$rel" in
    data/db/.locks|data/db/.locks/*|dados/database/tmp|dados/database/tmp/*) continue ;;
    .env|data|data/*|dados/database|dados/database/*|dados/src/config.json|dados/midias|dados/midias/*) printf '%s\n' "$name" >> "$TMP/list.txt" ;;
  esac
done < "$TMP/verbose.txt"

COUNT="$(wc -l < "$TMP/list.txt" | tr -d ' ')"
(( COUNT > 0 )) || fail "Nada para restaurar: o backup não tem .env, data/, dados/database/ nem config.json dentro de '$TOP/'."
(( SKIPPED_LINKS == 0 )) || warn "$SKIPPED_LINKS link(s) simbólico(s)/hardlink(s) ignorado(s) por segurança."

log "Backup: $ARCHIVE (raiz '$TOP')"
log "Destino: $APP_DIR"
log "Itens a restaurar: $COUNT"
for k in ".env" "dados/database/qr-code" "dados/src/config.json" "data/db"; do
  if grep -Fq "$TOP/$k" "$TMP/list.txt"; then printf '   ✓ %s\n' "$k"; else printf '   – %s (não está no backup)\n' "$k"; fi
done

if (( DRY )); then
  log "DRY-RUN: nada foi escrito. Primeiros itens:"; head -n 15 "$TMP/list.txt"; exit 0
fi

if command -v systemctl >/dev/null 2>&1 && systemctl is-active --quiet "$SERVICE_NAME" 2>/dev/null; then
  log "Parando $SERVICE_NAME para restaurar com segurança"
  systemctl stop "$SERVICE_NAME"
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
if (( FORCE )); then
  SAFE="$APP_DIR/.pre-restore-$STAMP"; copied=0
  while IFS= read -r name; do
    rel="${name#"$TOP"/}"
    if [[ -f "$APP_DIR/$rel" ]]; then
      mkdir -p "$SAFE/$(dirname "$rel")"; cp -a "$APP_DIR/$rel" "$SAFE/$rel"; copied=$((copied+1))
    fi
  done < "$TMP/list.txt"
  (( copied == 0 )) || log "Cópia dos $copied arquivo(s) atuais em $SAFE"
  OVERWRITE=(--overwrite)
else
  OVERWRITE=(--skip-old-files)
fi

# --no-recursion: cada nome da lista é extraído exatamente; sem isso, uma pasta listada casa com tudo abaixo dela
# e os arquivos listados individualmente viram "Not found in archive" (tar sai com 2 e o script aborta).
tar -xzf "$ARCHIVE" -C "$APP_DIR" --no-recursion --strip-components=1 --no-same-owner "${OVERWRITE[@]}" -T "$TMP/list.txt"

[[ -f "$APP_DIR/.env" ]] && chmod 600 "$APP_DIR/.env"
[[ -d "$APP_DIR/dados/database/qr-code" ]] && chmod -R go-rwx "$APP_DIR/dados/database/qr-code"
mkdir -p "$APP_DIR/data/db" "$APP_DIR/data/auth" "$APP_DIR/logs"

log "Restauração concluída ($COUNT itens)."
log "Próximo passo: systemctl start $SERVICE_NAME  &&  journalctl -u $SERVICE_NAME -f"
