#!/usr/bin/env bash
# Liga/desliga o Chat Bridge (chat estilo WhatsApp do app Fantasminha SSH).
#   bash deploy/vps/chat-bridge.sh on      # gera token (se preciso), liga e reinicia
#   bash deploy/vps/chat-bridge.sh off     # desliga e reinicia
#   bash deploy/vps/chat-bridge.sh status  # mostra estado e /health
#   bash deploy/vps/chat-bridge.sh token   # imprime o token para colar no app
# O bridge só escuta em 127.0.0.1; o app acessa por túnel SSH.
set -Eeuo pipefail

APP_DIR="${FANTASMINHA_DIR:-/opt/fantasminha}"
SERVICE_NAME="${FANTASMINHA_SERVICE:-fantasminha}"
ENV_FILE="$APP_DIR/.env"
ACTION="${1:-status}"

log(){ printf '[👻] %s\n' "$*"; }
fail(){ printf '[❌] %s\n' "$*" >&2; exit 1; }
[[ -f "$ENV_FILE" ]] || fail ".env não encontrado em $APP_DIR."

get_env(){ grep -E "^$1=" "$ENV_FILE" | tail -n1 | cut -d= -f2- | tr -d '"\r' || true; }
set_env(){
  local key="$1" val="$2"
  if grep -q "^${key}=" "$ENV_FILE"; then sed -i "s#^${key}=.*#${key}=${val}#" "$ENV_FILE"
  else printf '%s=%s\n' "$key" "$val" >> "$ENV_FILE"; fi
}
new_token(){
  if command -v openssl >/dev/null 2>&1; then openssl rand -hex 24
  else head -c 24 /dev/urandom | od -An -tx1 | tr -d ' \n'; fi
}
restart_service(){
  if command -v systemctl >/dev/null 2>&1 && systemctl cat "$SERVICE_NAME" >/dev/null 2>&1; then
    systemctl restart "$SERVICE_NAME"
  else
    log "Serviço $SERVICE_NAME não encontrado; reinicie o bot manualmente."
  fi
}
health(){
  local port; port="$(get_env CHAT_BRIDGE_PORT)"; port="${port:-30100}"
  if command -v curl >/dev/null 2>&1; then curl -fsS --max-time 3 "http://127.0.0.1:${port}/health"
  else node -e 'fetch("http://127.0.0.1:"+process.argv[1]+"/health",{signal:AbortSignal.timeout(3000)}).then(r=>{if(!r.ok)process.exit(1);return r.text()}).then(t=>console.log(t)).catch(()=>process.exit(1))' "$port"; fi
}

case "$ACTION" in
  on)
    token="$(get_env CHAT_BRIDGE_TOKEN)"
    if (( ${#token} < 32 )); then token="$(new_token)"; log "Token novo gerado."; fi
    set_env CHAT_BRIDGE_ENABLED true
    set_env CHAT_BRIDGE_PORT "$(get_env CHAT_BRIDGE_PORT | grep -E '^[0-9]+$' || echo 30100)"
    set_env CHAT_BRIDGE_TOKEN "$token"
    set_env CHAT_BRIDGE_ALLOW_REAL false
    set_env CHAT_BRIDGE_ACTOR_ROLE member
    set_env CHAT_BRIDGE_ALLOW_OWNER_ACTOR false
    set_env CHAT_BRIDGE_ALLOW_REAL_DB false
    chmod 600 "$ENV_FILE"
    restart_service
    log "Aguardando o bridge subir..."
    for _ in $(seq 1 30); do
      if out="$(health 2>/dev/null)"; then log "Bridge ONLINE: $out"; log "Para ver o token: bash deploy/vps/chat-bridge.sh token"; exit 0; fi
      sleep 1
    done
    fail "O bridge não respondeu em 30 s. Veja: journalctl -u $SERVICE_NAME -n 80 --no-pager"
    ;;
  off)
    set_env CHAT_BRIDGE_ENABLED false
    restart_service
    log "Bridge desligado."
    ;;
  token)
    token="$(get_env CHAT_BRIDGE_TOKEN)"
    [[ -n "$token" ]] || fail "Sem token. Rode: bash deploy/vps/chat-bridge.sh on"
    printf '%s\n' "$token"
    ;;
  status)
    t="$(get_env CHAT_BRIDGE_TOKEN)"
    log "CHAT_BRIDGE_ENABLED=$(get_env CHAT_BRIDGE_ENABLED) · porta=$(get_env CHAT_BRIDGE_PORT) · token: ${#t} caracteres (mínimo 32) · modo real: $(get_env CHAT_BRIDGE_ALLOW_REAL)"
    if out="$(health 2>/dev/null)"; then log "/health: $out"; else log "/health: sem resposta (bridge desligado ou bot parado)"; fi
    ;;
  *) fail "Uso: $0 on|off|status|token" ;;
esac
