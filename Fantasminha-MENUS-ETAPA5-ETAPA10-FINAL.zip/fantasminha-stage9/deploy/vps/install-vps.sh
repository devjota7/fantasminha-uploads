#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${FANTASMINHA_DIR:-/opt/fantasminha}"
SERVICE_NAME="fantasminha"
SYSTEMD_DIR="${FANTASMINHA_SYSTEMD_DIR:-/etc/systemd/system}"
BACKUP_ROOT="${FANTASMINHA_BACKUP_DIR:-/root/Bots/backups}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$BACKUP_ROOT/$STAMP"

log(){ printf '\n[👻] %s\n' "$*"; }
fail(){ printf '\n[❌] %s\n' "$*" >&2; exit 1; }

[[ "$(id -u)" == "0" ]] || fail "Execute este instalador como root."
cd "$APP_DIR" || fail "Diretório do projeto não encontrado: $APP_DIR"

command -v node >/dev/null 2>&1 || fail "Node.js não encontrado. Instale Node.js >= 20.9 antes do deploy."
command -v npm >/dev/null 2>&1 || fail "npm não encontrado."
command -v ffmpeg >/dev/null 2>&1 || log "FFmpeg não encontrado; mídia que depende dele poderá ficar indisponível."

NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]")"
(( NODE_MAJOR >= 20 )) || fail "Node.js $(node -v) é antigo; mínimo 20.9."

mkdir -p "$BACKUP_DIR" data/auth data/db data/backups dados/database/grupos dados/midias logs temp
if ! id fantasminha >/dev/null 2>&1; then
  useradd --system --home "$APP_DIR" --shell /usr/sbin/nologin fantasminha
fi
chown -R fantasminha:fantasminha data dados logs temp

log "Backup dos dados locais protegidos"
for p in .env data/auth data/db data/backups dados/database dados/src/config.json dados/midias logs; do
  if [[ -e "$p" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$p")"
    cp -a "$p" "$BACKUP_DIR/$(dirname "$p")/"
  fi
done

if [[ ! -f .env ]]; then
  cp .env.example .env
  chmod 600 .env
  log ".env criado a partir do .env.example. Preencha OWNER_NUMBER/credenciais antes de iniciar."
fi
chmod 600 .env || true
chown fantasminha:fantasminha .env || true

# Produção: o preflight exige cookie seguro do Control Center.
if ! grep -q '^WEB_AUTH_COOKIE_SECURE=' .env; then
  NODE_ENV_VALUE="$(grep -E '^NODE_ENV=' .env | tail -n1 | cut -d= -f2- | tr -d '"\r' || true)"
  if [[ -z "$NODE_ENV_VALUE" || "$NODE_ENV_VALUE" == "production" ]]; then
    printf '\nWEB_AUTH_COOKIE_SECURE=true\n' >> .env
    log "WEB_AUTH_COOKIE_SECURE=true adicionado ao .env (exigido em produção)."
  fi
fi

has_script(){ node -e 'const s=require("./package.json").scripts||{};process.exit(s[process.argv[1]]?0:1)' "$1"; }

log "Instalando dependências do release"
npm ci --no-audit --no-fund

log "Preflight"
node scripts/preflight.mjs || fail "Preflight reprovou. Corrija o .env conforme as mensagens acima e rode de novo."

if [[ "${FANTASMINHA_SKIP_TESTS:-0}" == "1" ]]; then
  log "Certificação 2.0 PULADA (FANTASMINHA_SKIP_TESTS=1)"
else
  log "Certificação 2.0"
  npm run test:final-hardening || fail "Certificação falhou. Leia o erro acima; se for só limitação do ambiente, rode de novo com FANTASMINHA_SKIP_TESTS=1."
fi

if has_script audit:legacy-reachability; then
  log "Auditoria de legados"
  npm run audit:legacy-reachability
else
  log "Auditoria de legados: script audit:legacy-reachability não existe nesta versão (pulado)."
fi

log "Catálogo runtime"
npm run catalog:commands

log "Instalando serviço systemd"
install -m 0644 deploy/systemd/fantasminha.service.example "${SYSTEMD_DIR}/${SERVICE_NAME}.service"
sed -i "s#WorkingDirectory=/opt/fantasminha#WorkingDirectory=${APP_DIR}#; s#EnvironmentFile=/opt/fantasminha/.env#EnvironmentFile=${APP_DIR}/.env#; s#ExecStart=/usr/bin/node dados/src/.scripts/start.js#ExecStart=$(command -v node) dados/src/.scripts/start.js#; s#^ReadWritePaths=.*#ReadWritePaths=${APP_DIR}/data ${APP_DIR}/dados ${APP_DIR}/logs ${APP_DIR}/temp#" "${SYSTEMD_DIR}/${SERVICE_NAME}.service"

systemctl daemon-reload
systemctl enable "$SERVICE_NAME"
systemctl restart "$SERVICE_NAME"
sleep 3

if ! systemctl is-active --quiet "$SERVICE_NAME"; then
  journalctl -u "$SERVICE_NAME" -n 80 --no-pager || true
  fail "Fantasminha não permaneceu ativo. Backup preservado em $BACKUP_DIR"
fi

log "Fantasminha 2.0.0 ONLINE"
systemctl --no-pager --full status "$SERVICE_NAME" | sed -n '1,22p'
printf '\nBackup: %s\n' "$BACKUP_DIR"
printf 'Logs:   journalctl -u %s -f\n' "$SERVICE_NAME"
printf 'Stop:   systemctl stop %s\n' "$SERVICE_NAME"
printf 'Start:  systemctl start %s\n' "$SERVICE_NAME"
printf 'Restart: systemctl restart %s\n' "$SERVICE_NAME"
