import { listCommands } from '../../../src/core/registry.js';

const normalize = v => String(v ?? '').trim().toLowerCase();
const map = [
  ['dono','👑 DONO', c => c.permission >= 80 || c.category === 'dono' || c.category === 'owner'],
  ['admin','🛡️ ADMINS', c => c.permission >= 50 && c.permission < 80 || ['admin','triagem'].includes(c.category)],
  ['downloads','📥 DOWNLOADS', c => c.category === 'downloads'],
  ['jogos','🎡 BRINCADEIRAS', c => ['jogos','alem'].includes(c.category)],
  ['ia','🤖 IA', c => c.category === 'ia' || /gpt|gemini|deepseek|tts|transcrever|ia-/.test(c.name)],
  ['canvas','❇ CANVAS', c => /^(blur|bolsonaro|cadeia|contraste|espelhar|gray|inverter|pixel|rip)$/.test(c.name)],
  ['principal','🚀 PRINCIPAL', c => ! (c.permission >= 80 || c.category === 'dono' || c.category === 'owner' || (c.permission >= 50 && c.permission < 80) || ['admin','triagem','downloads','jogos','alem','ia'].includes(c.category) || /^(blur|bolsonaro|cadeia|contraste|espelhar|gray|inverter|pixel|rip)$/.test(c.name))],
];

function unique(list){ const seen=new Set(); return list.filter(c=>{if(seen.has(c.name))return false;seen.add(c.name);return true;}); }
function sectionCommands(key, commands){
  if(key==='jogos') {
    const gamePlugins=new Set(['quizEngine','forca','stop','gartic','innovation']);
    return unique(commands.filter(c=>c.category==='jogos' || (gamePlugins.has(c.plugin) && (c.category==='quiz' || c.category==='rankings'))));
  }
  const rule=map.find(x=>x[0]===key)?.[2]; return unique(commands.filter(rule));
}
function block(title, prefix, commands){ if(!commands.length)return ''; return `╭━━⪩ ${title} ⪨━━\n▢\n${commands.map(c=>`▢ • ${prefix}${c.name}`).join('\n')}\n▢\n╰━━─「👻」─━━`; }

export default async function menu(prefix='×', botName='Fantasminha', userName='Usuário', customDesign=null, options={}) {
  const commands = listCommands({includeHidden:false}).filter(c=>c.enabled !== false && !c.hidden);
  const requested=normalize(options?.category || options?.categoria || '');
  const page=Math.max(1,Number(options?.page || options?.pagina || 1));
  if(requested){
    const key = map.find(x=>x[0]===requested)?.[0] || requested;
    const found = map.find(x=>x[0]===key);
    if(!found) return `╭━━⪩ MENU ⪨━━\n\nCategoria não encontrada.\n\nUse ${prefix}menu.`;
    const list=sectionCommands(key,commands); const size=45; const pages=Math.max(1,Math.ceil(list.length/size)); const safe=Math.min(page,pages); const slice=list.slice((safe-1)*size,safe*size);
    return `╭━━⪩ ${found[1]} ⪨━━\n▢\n${slice.map(c=>`▢ • ${prefix}${c.name}`).join('\n') || '▢ • Nenhum comando disponível'}\n▢\n╰━━─「👻」─━━\n\nPágina ${safe}/${pages} • ${list.length} comandos ativos\nUse ${prefix}menu para voltar.`;
  }
  const date=new Date();
  const sections=['dono','admin','principal','downloads','jogos','ia','canvas'];
  return `╭━━⪩ BEM VINDO! ⪨━━\n▢\n▢ • ${botName}\n▢ • Data: ${date.toLocaleDateString('pt-BR')}\n▢ • Hora: ${date.toLocaleTimeString('pt-BR')}\n▢ • Prefixo: ${prefix}\n▢ • Versão: 11.7.02\n▢\n╰━━─「🪐」─━━\n\n${sections.map(k=>block(map.find(x=>x[0]===k)[1],prefix,sectionCommands(k,commands))).filter(Boolean).join('\n\n')}\n\n📦 Total: ${commands.length} comandos ativos\n💡 ${prefix}menu <categoria> <página>`;
}
export { sectionCommands };
