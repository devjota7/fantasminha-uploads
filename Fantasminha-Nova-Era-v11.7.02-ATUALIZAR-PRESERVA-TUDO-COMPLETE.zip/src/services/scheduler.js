import logger from '../core/logger.js';
import config from '../core/config.js';
import { syncWarStates } from './wars.js';

let timer = null;

export function startSchedulers() {
  if (timer) return;
  // Não há backup automático de banco: evita crescimento de armazenamento no Android/Termux.
  // O mecanismo de rollback de código do updater permanece independente deste scheduler.

  // Triagem: expiração e lembretes. O scheduler não depende do socket.
  const triageTimer = setInterval(async () => {
    try {
      const { expireSweep, reminderSweep } = await import('./triage.js');
      await expireSweep();
      await reminderSweep();
    } catch (e) { logger.error('triage', e.message); }
  }, 60_000);
  triageTimer.unref?.();

  // Estado das guerras: transições preparação → ativa → encerrada.
  const warTimer = setInterval(async () => {
    try {
      const changes = await syncWarStates();
      for (const change of changes) logger.info('wars', `guerra ${change.type}`, { warId: change.war?.id, type: change.war?.type });
    } catch (e) { logger.error('wars', e.message); }
  }, 30_000);
  warTimer.unref?.();

  // Campeonato Global do Além: mantém a fase persistente sem depender do WhatsApp/socket.
  const championshipTimer = setInterval(async () => {
    try { const { tick } = await import('./clanChampionship.js'); await tick(); } catch (e) { logger.error('championship', e.message); }
  }, 60_000);
  championshipTimer.unref?.();

  // Partidas com timeout: encerramento automático e persistente.
  const gameTimer = setInterval(async () => {
    try { const { expireGames } = await import('./gameEngine.js'); const n = await expireGames(); if (n) logger.info('games', `partidas expiradas: ${n}`); }
    catch (e) { logger.error('games', 'game expiry: ' + e.message); }
  }, 30_000);
  gameTimer.unref?.();

  // Quiz: remove mídia temporária órfã sem manter arquivos indefinidamente.
  const quizCleanupTimer = setInterval(async () => {
    try { const { cleanupOrphans } = await import('../games/quiz/QuizCleanupService.js'); const n = await cleanupOrphans(); if (n) logger.info('quiz', `mídias órfãs removidas: ${n}`); }
    catch (e) { logger.error('quiz', 'cleanup: ' + e.message); }
  }, 10 * 60_000);
  quizCleanupTimer.unref?.();

  const stopRecoveryTimer = setInterval(async () => {
    try { const { recover } = await import('../games/stop/StopCore.js'); await recover(); }
    catch (e) { logger.error('stop', 'recovery tick: ' + e.message); }
  }, 15_000);
  stopRecoveryTimer.unref?.();

  const garticCleanupTimer = setInterval(async () => {
    try { const { cleanupOrphans } = await import('../games/gartic/GarticCleanupService.js'); const n = await cleanupOrphans(); if (n) logger.info('gartic', `mídias órfãs removidas: ${n}`); }
    catch (e) { logger.error('gartic', 'cleanup: ' + e.message); }
  }, 60_000);
  garticCleanupTimer.unref?.();

  // premium expiry soft check hourly
  setInterval(async () => {
    try {
      const { readCollection, writeCollection } = await import('../database/store.js');
      const users = readCollection('users', { byId: {} });
      let changed = false;
      const now = Date.now();
      for (const u of Object.values(users.byId || {})) {
        if (u.premium?.active && u.premium.until && u.premium.until < now) {
          u.premium.active = false;
          changed = true;
        }
      }
      if (changed) writeCollection('users', users);
    } catch (e) {
      logger.error('scheduler', 'premium expiry: ' + e.message);
    }
  }, 3600 * 1000).unref?.();
}

export default { startSchedulers };
