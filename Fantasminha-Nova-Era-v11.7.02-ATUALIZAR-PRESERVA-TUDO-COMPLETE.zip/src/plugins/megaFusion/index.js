import crypto from 'crypto';
import { registerCommand, registerAlias, getCommand, listCommands } from '../../core/registry.js';
import { Role } from '../../core/permissions.js';
import { ValidationError } from '../../core/errors.js';
import config from '../../core/config.js';

const tag = text => `╭━━⪩ 👻 *FANTASMINHA* ⪨━━╮\n${text}\n╰━━━━━━━━━━━━━━━━━━━━╯`;
const q = ctx => String(ctx.q || ctx.args?.join(' ') || '').trim();
const clean = s => String(s || '').replace(/[\u0000-\u001F]/g, '').trim();
const pick = a => a[Math.floor(Math.random() * a.length)];
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function animate(ctx, frames, finalText) {
  if (!ctx.sendMessage || !ctx.from) return ctx.reply(finalText);
  const sent = await ctx.sendMessage(ctx.from, { text: frames[0] });
  const key = sent?.key;
  if (!key) return ctx.reply(finalText);
  for (let i = 1; i < frames.length; i++) {
    await sleep(250);
    try { await ctx.sendMessage(ctx.from, { text: frames[i], edit: key }); } catch {}
  }
  await sleep(250);
  try { return await ctx.sendMessage(ctx.from, { text: finalText, edit: key }); } catch { return ctx.reply(finalText); }
}

function arithmetic(expression) {
  const raw = clean(expression).replace(/,/g, '.');
  if (!raw || raw.length > 160 || !/^[0-9+\-*/%().\s]+$/.test(raw)) throw new ValidationError('Expressão inválida.');
  const tokens = raw.match(/\d+(?:\.\d+)?|[()+\-*/%]/g) || [];
  if (tokens.join('') !== raw.replace(/\s+/g,'')) throw new ValidationError('Expressão inválida.');
  const values=[], ops=[], prec={'+':1,'-':1,'*':2,'/':2,'%':2};
  const apply=()=>{const op=ops.pop(),b=values.pop(),a=values.pop(); if(a===undefined||b===undefined) throw new ValidationError('Expressão inválida.'); let r=op==='+'?a+b:op==='-'?a-b:op==='*'?a*b:op==='/'?a/b:a%b; if(!Number.isFinite(r)) throw new ValidationError('Resultado inválido.'); values.push(r);};
  let expect=true;
  for(const t of tokens){
    if(/^\d/.test(t)){values.push(Number(t));expect=false;continue;}
    if(t==='('){ops.push(t);expect=true;continue;}
    if(t===')'){while(ops.length&&ops.at(-1)!=='(')apply();if(ops.pop()!=='(')throw new ValidationError('Expressão inválida.');expect=false;continue;}
    if(expect&&(t==='+'||t==='-'))values.push(0); else if(expect)throw new ValidationError('Expressão inválida.');
    while(ops.length&&ops.at(-1)!=='('&&prec[ops.at(-1)]>=prec[t])apply(); ops.push(t);expect=true;
  }
  if(expect)throw new ValidationError('Expressão inválida.'); while(ops.length){if(ops.at(-1)==='(')throw new ValidationError('Expressão inválida.');apply();}
  if(values.length!==1)throw new ValidationError('Expressão inválida.'); return values[0];
}

async function explicitReact(ctx) {
  const emoji = clean(ctx.args?.[0] || '').replace(/\s/g,'');
  if (!emoji || [...emoji].length > 5) throw new ValidationError(`Use ${ctx.prefix || '×'}react ❤️ respondendo à mensagem que deseja reagir.`);
  if (!ctx.sendMessage || !ctx.from) throw new ValidationError('Socket indisponível.');
  const key = ctx.quotedKey || ctx.message?.key;
  if (!key?.id) throw new ValidationError('Responda à mensagem que deseja reagir.');
  await ctx.sendMessage(ctx.from, { react: { text: emoji, key } });
  return ctx.reply(`💫 Reação *${emoji}* enviada.`);
}

const aliases = {
  profile:'perfil', meuperfil:'meuperfil', myprofile:'meuperfil',
  commands:'catalogo', comandos:'catalogo', commandlist:'catalogo',
  searchcmd:'buscar', searchcommand:'buscar', procurar:'buscar',
  help:'ajuda', helpcmd:'ajuda',
  tiktok:'tik-tok', tt:'tik-tok', instagram:'instagram', ig:'instagram',
  video2mp3:'to-mp3', mp3:'to-mp3', tomp3:'to-mp3', toaudio:'to-mp3',
  bestfriends:'meubest', best:'meubest',
  afk:'afk', away:'afk',
  rules:'regras', groupinfo:'grupoinfo', groupInfo:'grupoinfo',
  warnings:'warns', warning:'warn',
  rank:'rankxp', ranking:'rankxp', xp:'rankxp', coins:'saldo', balance:'saldo',
  shop:'loja', store:'loja', inventory:'inv', inventario:'inv',
  daily:'daily', weekly:'weekly', work:'work'
};

export async function register() {
  registerCommand({ name:'react', aliases:['reagir'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Reage manualmente a uma mensagem. O Fantasminha não reage automaticamente.', usage:'×react ❤️ (respondendo a uma mensagem)', handler:explicitReact });

  registerCommand({ name:'ping', aliases:['p'], category:'sistema', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Verifica a latência do bot.', handler:async ctx=>{ const start=Date.now(); const sent=await ctx.sendMessage?.(ctx.from,{text:'🏓 *PONG*\n\n⏱️ Medindo...'}); const ms=Date.now()-start; if(sent?.key&&ctx.sendMessage){ try{return ctx.sendMessage(ctx.from,{text:tag(`🏓 *PONG!*

⚡ Latência: *${ms}ms*
🟢 Núcleo: online
👻 Versão: *${config.botVersion}*`),edit:sent.key});}catch{}} return ctx.reply(tag(`🏓 *PONG!*

⚡ Latência: *${ms}ms*
🟢 Núcleo: online`)); }});

  registerCommand({ name:'alive', aliases:['online'], category:'sistema', plugin:'megaFusion', permission:Role.USER, cooldown:3, description:'Mostra o estado básico do bot.', handler:async ctx=>ctx.reply(tag(`🟢 *FANTASMINHA ONLINE*

🤖 ${config.botName}
📦 v${config.botVersion}
⚡ Prefixo: ${ctx.prefix || config.prefix}
🌎 Idioma: ${config.language}
🧩 Registry: ${listCommands().length} comandos ativos`)) });

  registerCommand({ name:'calc', aliases:['calcular','math'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Calculadora segura.', usage:'×calc 2*(10+5)', handler:async ctx=>{const e=q(ctx); if(!e)throw new ValidationError('Informe uma expressão. Ex.: ×calc 2*(10+5)'); const r=arithmetic(e); return ctx.reply(tag(`🧮 *CALCULADORA*

[0m${e} = *${Number(r.toFixed(10)).toLocaleString('pt-BR')}*`));}});

  registerCommand({ name:'hora', aliases:['time','horario'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Mostra data e horário.', handler:async ctx=>{const d=new Date();return ctx.reply(tag(`🕐 *DATA E HORA*

📅 ${d.toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'})}
⏰ ${d.toLocaleTimeString('pt-BR')}`));}});

  registerCommand({ name:'dado', aliases:['dice','rolardado'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Rola um dado.', usage:'×dado [faces]', handler:async ctx=>{const n=Math.min(100,Math.max(2,Number(ctx.args?.[0])||6));const r=1+Math.floor(Math.random()*n);return animate(ctx,['🎲 *Preparando o dado...*','🎲 *Girando...*','🎲 *Quase lá...*'],tag(`🎲 *DADO*

Resultado: *${r}*
Faces: ${n}`));}});

  registerCommand({ name:'moeda', aliases:['coin','flipcoin','caraoucoroa'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Joga cara ou coroa.', handler:async ctx=>animate(ctx,['🪙 *Lançando...*','🪙 *Girando...*','🪙 *Caindo...*'],tag(`🪙 *RESULTADO*

${pick(['🟡 CARA','⚪ COROA'])}`))});

  registerCommand({ name:'8ball', aliases:['bola8','magic8'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Responde uma pergunta aleatoriamente.', usage:'×8ball vou ganhar?', handler:async ctx=>{const question=q(ctx);if(!question)throw new ValidationError('Faça uma pergunta.');const answers=['🔮 Sim, o Véu indica isso.','🌙 Provavelmente.','✨ As chances parecem boas.','🌀 Talvez...','👻 O destino está indeciso.','💀 Melhor não contar com isso.','🌑 Não parece promissor.','🎲 Só o caos sabe.'];return ctx.reply(tag(`🔮 *8 BALL*

❓ ${question}

💬 *${pick(answers)}*`));}});

  registerCommand({ name:'piada', aliases:['joke','humor'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Conta uma piada leve.', handler:async ctx=>ctx.reply(tag(`😂 *PIADA DO ALÉM*

${pick(['Por que o fantasma foi ao médico? Porque estava sem espírito. 👻','O que o zero disse para o oito? Belo cinto! 😎','Qual é o cúmulo da velocidade? Fechar a gaveta e prender a mão. 🫠'])}`))});

  registerCommand({ name:'conselho', aliases:['advice','conselhoaleatorio'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Entrega um conselho recreativo.', handler:async ctx=>ctx.reply(tag(`💡 *CONSELHO DO FANTASMINHA*

${pick(['Não tente resolver tudo de uma vez. Um passo bem feito já é progresso.','Se algo pode ser organizado, transforme em uma lista e comece pelo primeiro item.','Antes de desistir, faça uma pausa e tente de novo com uma abordagem diferente.','Nem toda resposta precisa ser imediata; pensar também faz parte do processo.'])}`))});

  registerCommand({ name:'fato', aliases:['fact','curiosidade'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Mostra uma curiosidade.', handler:async ctx=>ctx.reply(tag(`🧠 *FATO ALEATÓRIO*

${pick(['Polvos possuem três corações. 🐙','Um dia terrestre tem aproximadamente 24 horas por causa da rotação da Terra. 🌍','A luz do Sol leva cerca de 8 minutos e 20 segundos para chegar à Terra. ☀️','Bananas são classificadas botanicamente como frutos. 🍌'])}`))});

  registerCommand({ name:'escolher', aliases:['choose','decidir'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Escolhe uma opção aleatória.', usage:'×escolher pizza | hambúrguer | sushi', handler:async ctx=>{const raw=q(ctx);const options=raw.split(/\s*\|\s*|\s*,\s*/).map(clean).filter(Boolean).slice(0,30);if(options.length<2)throw new ValidationError('Informe pelo menos 2 opções separadas por |.');return animate(ctx,['🎯 *Analisando opções...*','🎯 *Sorteando...*','🎯 *Decidindo...*'],tag(`🎯 *ESCOLHA*

${options.map((x,i)=>`${i+1}. ${x}`).join('\n')}

🏆 Vencedor: *${pick(options)}*`));}});

  registerCommand({ name:'ship', aliases:['casal','compatibilidade'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:3, description:'Calcula uma compatibilidade recreativa entre duas pessoas.', usage:'×ship @a @b', handler:async ctx=>{const ids=ctx.mentioned||[];if(ids.length<2)throw new ValidationError('Mencione duas pessoas.');const score=20+Math.floor(Math.random()*81);return ctx.reply(tag(`💞 *SHIP DO ALÉM*

👤 @${ids[0].split('@')[0]}
❤️ ${score}% ❤️
👤 @${ids[1].split('@')[0]}

🔮 Resultado recreativo — não é uma avaliação real.`),{mentions:ids.slice(0,2)});}});

  registerCommand({ name:'base64', aliases:['b64'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Codifica ou decodifica Base64.', usage:'×base64 encode texto | ×base64 decode texto', handler:async ctx=>{const mode=(ctx.args?.[0]||'encode').toLowerCase();const text=ctx.args?.slice(1).join(' ')||'';if(!text)throw new ValidationError('Use ×base64 encode <texto> ou ×base64 decode <texto>.');let out;if(mode==='decode')out=Buffer.from(text,'base64').toString('utf8');else if(mode==='encode')out=Buffer.from(text,'utf8').toString('base64');else throw new ValidationError('Modo inválido: encode ou decode.');return ctx.reply(tag(`🔐 *BASE64*

Modo: ${mode}

\\\`${out}\\\``));}});

  registerCommand({ name:'morse', aliases:['codigomorse'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Converte texto para Morse.', usage:'×morse SOS', handler:async ctx=>{const text=q(ctx).toUpperCase();if(!text)throw new ValidationError('Informe um texto.');const map={A:'.-',B:'-...',C:'-.-.',D:'-..',E:'.',F:'..-.',G:'--.',H:'....',I:'..',J:'.---',K:'-.-',L:'.-..',M:'--',N:'-.',O:'---',P:'.--.',Q:'--.-',R:'.-.',S:'...',T:'-',U:'..-',V:'...-',W:'.--',X:'-..-',Y:'-.--',Z:'--..',0:'-----',1:'.----',2:'..---',3:'...--',4:'....-',5:'.....',6:'-....',7:'--...',8:'---..',9:'----.'};return ctx.reply(tag(`📡 *MORSE*

${text.split('').map(c=>c===' '?' / ':map[c]||c).join(' ')}`));}});

  registerCommand({ name:'sorteio', aliases:['random','aleatorio'], category:'brincadeiras', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Sorteia um número ou opção.', usage:'×sorteio 1 100', handler:async ctx=>{const a=ctx.args||[];if(a.length>=2&&Number.isFinite(Number(a[0]))&&Number.isFinite(Number(a[1]))){let x=Math.floor(Number(a[0])),y=Math.floor(Number(a[1]));if(x>y)[x,y]=[y,x];return ctx.reply(tag(`🎰 Número sorteado: *${x+Math.floor(Math.random()*(y-x+1))}*`));}if(a.length<2)throw new ValidationError('Use ×sorteio 1 100 ou informe opções separadas por |.');const opts=q(ctx).split(/\s*\|\s*/).map(clean).filter(Boolean);return ctx.reply(tag(`🎰 Escolhido: *${pick(opts)}*`));}});


  registerCommand({ name:'contar', aliases:['count','contagem'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Conta palavras e caracteres de um texto.', usage:'×contar seu texto aqui', handler:async ctx=>{const text=q(ctx);if(!text)throw new ValidationError('Informe um texto.');const words=text.split(/\s+/).filter(Boolean).length;return ctx.reply(tag(`🔢 *CONTADOR*\n\n📝 Palavras: *${words}*\n🔤 Caracteres: *${[...text].length}*\n📏 Sem espaços: *${text.replace(/\s/g,'').length}*`));}});

  registerCommand({ name:'texto', aliases:['texttools','formatartexto'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Transforma texto em maiúsculas, minúsculas ou invertido.', usage:'×texto upper|lower|reverse texto', handler:async ctx=>{const mode=(ctx.args?.[0]||'').toLowerCase();const text=ctx.args?.slice(1).join(' ')||'';if(!text||!['upper','lower','reverse'].includes(mode))throw new ValidationError('Use ×texto upper|lower|reverse <texto>.');const out=mode==='upper'?text.toUpperCase():mode==='lower'?text.toLowerCase():[...text].reverse().join('');return ctx.reply(tag(`✍️ *TRANSFORMAÇÃO*\n\n${out}`));}});

  registerCommand({ name:'hash', aliases:['sha256'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Gera SHA-256 localmente.', usage:'×hash texto', handler:async ctx=>{const text=q(ctx);if(!text)throw new ValidationError('Informe o texto.');const out=crypto.createHash('sha256').update(text).digest('hex');return ctx.reply(tag(`🔐 *SHA-256*\n\n${out}`));}});

  registerCommand({ name:'rot13', aliases:['rot'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Aplica ROT13 ao texto.', usage:'×rot13 texto', handler:async ctx=>{const text=q(ctx);if(!text)throw new ValidationError('Informe o texto.');const out=text.replace(/[A-Za-z]/g,c=>String.fromCharCode((c<='Z'?90:122)>=c.charCodeAt()+13?c.charCodeAt()+13:c.charCodeAt()+13-(c<='Z'?26:26)));return ctx.reply(tag(`🔄 *ROT13*\n\n${out}`));}});

  registerCommand({ name:'url', aliases:['urlencode','urldecode'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Codifica ou decodifica texto para URL.', usage:'×url encode texto | ×url decode texto', handler:async ctx=>{const mode=(ctx.args?.[0]||'encode').toLowerCase();const text=ctx.args?.slice(1).join(' ')||'';if(!text||!['encode','decode'].includes(mode))throw new ValidationError('Use ×url encode <texto> ou ×url decode <texto>.');let out;try{out=mode==='encode'?encodeURIComponent(text):decodeURIComponent(text);}catch{throw new ValidationError('Texto inválido para URL.');}return ctx.reply(tag(`🔗 *URL ${mode.toUpperCase()}*\n\n${out}`));}});

  registerCommand({ name:'uuid', aliases:['idaleatorio'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Gera um identificador aleatório.', handler:async ctx=>ctx.reply(tag(`🆔 *UUID*\n\n${crypto.randomUUID()}`))});

  registerCommand({ name:'senha', aliases:['password','gerarsenha'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Gera uma senha aleatória localmente.', usage:'×senha 16', handler:async ctx=>{const n=Math.min(64,Math.max(8,Number(ctx.args?.[0])||16));const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';const bytes=crypto.randomBytes(n);let out='';for(let i=0;i<n;i++)out+=chars[bytes[i]%chars.length];return ctx.reply(tag(`🔑 *SENHA GERADA*\n\n\`${out}\`\n\n⚠️ Não compartilhe esta senha.`));}});

  registerCommand({ name:'json', aliases:['jsonformat'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Formata ou valida JSON.', usage:'×json {"a":1}', handler:async ctx=>{const text=q(ctx);if(!text)throw new ValidationError('Informe um JSON.');try{const obj=JSON.parse(text);return ctx.reply(tag(`🧩 *JSON VÁLIDO*\n\n\`${JSON.stringify(obj,null,2).slice(0,3500)}\``));}catch(e){return ctx.reply(tag(`❌ *JSON INVÁLIDO*\n\n${e.message}`));}}});

  registerCommand({ name:'timestamp', aliases:['unix','epochtime'], category:'utilidades', plugin:'megaFusion', permission:Role.USER, cooldown:1, description:'Mostra timestamps atuais.', handler:async ctx=>{const ms=Date.now();return ctx.reply(tag(`⏱️ *TIMESTAMP*\n\nMilissegundos: *${ms}*\nSegundos: *${Math.floor(ms/1000)}*`));}});

  registerCommand({ name:'github', aliases:['githubuser'], category:'ferramentas', plugin:'megaFusion', permission:Role.USER, cooldown:5, description:'Consulta um perfil público do GitHub.', usage:'×github octocat', handler:async ctx=>{const user=clean(ctx.args?.[0]||'');if(!user)throw new ValidationError('Informe o usuário do GitHub.');const r=await fetch(`https://api.github.com/users/${encodeURIComponent(user)}`,{headers:{'User-Agent':'Fantasminha/11.7.02'},signal:AbortSignal.timeout(10000)});if(!r.ok)throw new ValidationError(`GitHub respondeu HTTP ${r.status}.`);const d=await r.json();return ctx.reply(tag(`🐙 *GITHUB*\n\n👤 *${d.login}*\n📝 ${d.bio||'Sem bio.'}\n📦 Repositórios: *${d.public_repos}*\n👥 Seguidores: *${d.followers}*\n🔗 ${d.html_url}`));}});

  registerCommand({ name:'wikipedia', aliases:['wiki'], category:'ferramentas', plugin:'megaFusion', permission:Role.USER, cooldown:5, description:'Busca um resumo na Wikipédia.', usage:'×wikipedia buracos negros', handler:async ctx=>{const term=q(ctx);if(!term)throw new ValidationError('Informe o assunto.');const title=encodeURIComponent(term.replace(/\s+/g,'_'));const r=await fetch(`https://pt.wikipedia.org/api/rest_v1/page/summary/${title}`,{headers:{'User-Agent':'Fantasminha/11.7.02'},signal:AbortSignal.timeout(10000)});if(!r.ok)throw new ValidationError('Não encontrei esse assunto na Wikipédia.');const d=await r.json();return ctx.reply(tag(`📚 *WIKIPÉDIA*\n\n*${d.title||term}*\n${String(d.extract||'Sem resumo disponível.').slice(0,2800)}\n\n🔗 ${d.content_urls?.desktop?.page||''}`));}});

  registerCommand({ name:'clima', aliases:['weather','tempo'], category:'ferramentas', plugin:'megaFusion', permission:Role.USER, cooldown:10, description:'Consulta clima atual por cidade.', usage:'×clima Rio de Janeiro', handler:async ctx=>{const city=q(ctx);if(!city)throw new ValidationError('Informe uma cidade.');const r=await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`,{headers:{'User-Agent':'Fantasminha/11.7.02'},signal:AbortSignal.timeout(10000)});if(!r.ok)throw new ValidationError('Serviço de clima indisponível.');const d=await r.json();const c=d.current_condition?.[0],a=d.nearest_area?.[0];if(!c)throw new ValidationError('Cidade não encontrada.');return ctx.reply(tag(`🌦️ *CLIMA*\n\n📍 ${a?.areaName?.[0]?.value||city}\n🌡️ ${c.temp_C}°C (sensação ${c.FeelsLikeC}°C)\n💧 Umidade: ${c.humidity}%\n💨 Vento: ${c.windspeedKmph} km/h\n☁️ ${c.lang_pt?.[0]?.value||c.weatherDesc?.[0]?.value||'—'}`));}});

  registerCommand({ name:'definir', aliases:['define','dictionary'], category:'ferramentas', plugin:'megaFusion', permission:Role.USER, cooldown:5, description:'Busca definição de uma palavra.', usage:'×definir fantasma', handler:async ctx=>{const word=clean(ctx.args?.[0]||'').toLowerCase();if(!word)throw new ValidationError('Informe uma palavra.');const r=await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`,{signal:AbortSignal.timeout(10000)});if(!r.ok)throw new ValidationError('Definição não encontrada.');const d=await r.json();const m=d?.[0]?.meanings?.[0];return ctx.reply(tag(`📖 *DEFINIÇÃO*\n\n*${d?.[0]?.word||word}*\n
${m?.partOfSpeech||'—'}
${m?.definitions?.slice(0,3).map((x,i)=>`${i+1}. ${x.definition}`).join('\n')||'Sem definição.'}`));}});

  registerCommand({ name:'transparencia', aliases:['botinfo','about'], category:'sistema', plugin:'megaFusion', permission:Role.USER, cooldown:2, description:'Mostra informações públicas da arquitetura.', handler:async ctx=>ctx.reply(tag(`🏛️ *FANTASMINHA — TRANSPARÊNCIA*\n\n📦 Versão: *${config.botVersion}*\n🧩 Comandos: *${listCommands().length}*\n🔐 Reações automáticas: *DESATIVADAS*\n🛡️ Registry: centralizado\n💾 Persistência: ativa\n🤖 IA: ${config.features.ai?'habilitada':'desabilitada por configuração'}`))});

  // Compatibility aliases: only point at commands that really exist.
  for (const [alias,target] of Object.entries(aliases)) {
    if (alias === target) continue;
    try { registerAlias(alias,target); } catch {}
  }

  return true;
}
export default { register };
