const fold = s => String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[“”‘’'`´]/g,'').replace(/[^\p{L}\p{N}\s-]/gu,' ').replace(/[\s-]+/g,' ').trim();
export function normalize(value){return fold(value);}
export function matches(input, word, aliases=[]){const a=fold(input), valid=new Set([word,...aliases].map(fold).filter(Boolean));return valid.has(a);}
export default {normalize,matches};
