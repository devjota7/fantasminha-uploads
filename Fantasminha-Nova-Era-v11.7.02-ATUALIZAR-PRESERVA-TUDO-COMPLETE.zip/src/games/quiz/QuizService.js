import crypto from 'node:crypto';
import { readFile } from 'node:fs/promises';
import game from '../../services/gameEngine.js';
import stats from '../../services/statsEngine.js';
import { emit } from '../../events/index.js';
import { recordAudit } from '../../platform/audit/index.js';
import { loadQuestions } from './QuizQuestionBank.js';
import { selectCategory, categoryLabel } from './QuizCategoryEngine.js';
import { selectDifficulty } from './QuizDifficultyEngine.js';
import { chooseFromHistory, record as recordHistory } from './QuizQuestionHistory.js';
import { validateAnswer, looksLikeQuizAnswer } from './QuizAnswerValidator.js';
import { calculateQuizPoints, QUIZ_MAX_TIME_MS } from './QuizScoreEngine.js';
import { generateForRound } from './QuizVisualEngine.js';
import { cleanupSession, cleanupOrphans } from './QuizCleanupService.js';
import { recordQuizResult } from './QuizStatisticsService.js';
import { renderPreparing, renderQuestion, renderResult, renderBusy, renderError } from './QuizRenderer.js';

const GAME_TYPE='quiz';
const timers=new Map();
const finalLocks=new Map();
const norm=s=>String(s??'').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
const uid=c=>c.sender||'unknown';
const gid=c=>c.from||'private';
function active(groupId){return game.listActiveGames(groupId).find(g=>g.gameType===GAME_TYPE)||null;}
function setTimer(gameId,ms,fn){clearTimer(gameId);const t=setTimeout(()=>fn().catch(()=>{}),Math.max(1,ms));t.unref?.();timers.set(gameId,t);}
function clearTimer(gameId){const t=timers.get(gameId);if(t){clearTimeout(t);timers.delete(gameId);}}
async function audit(action,session,details={}){try{await recordAudit({actor:details.userId||session.creatorId||null,target:session.groupId,action,scope:session.groupId,result:'success',details:{quizId:session.quizId,roundId:session.roundId,...details}});}catch{}}
async function event(name,payload){try{await emit(name,payload);}catch{}}
function publicSession(g){return g?.state||{};}

export async function start(ctx){
  if(!ctx.isGroup) return ctx.reply?.('⚠️ O ×quiz funciona apenas em grupos.');
  const groupId=gid(ctx); if(active(groupId)) return ctx.reply?.(renderBusy());
  const questions=loadQuestions();
  if(!questions.length) return ctx.reply?.('👻 Não há perguntas disponíveis para o Quiz.');
  const requestedCategory=ctx.args?.[0]||null; const requestedDifficulty=ctx.args?.[1]||null;
  const category=selectCategory(requestedCategory,[...new Set(questions.map(q=>q.category))]);
  const difficulty=selectDifficulty(requestedDifficulty);
  const pool=questions.filter(q=>q.category===category && q.difficulty===difficulty);
  const fallback=questions.filter(q=>q.category===category);
  const source=pool.length?pool:fallback.length?fallback:questions;
  const question=chooseFromHistory(source,groupId,Math.random,Number(process.env.QUIZ_QUESTION_COOLDOWN_ROUNDS||8));
  const quizId=crypto.randomUUID(),roundId=crypto.randomUUID();
  const state={quizId,roundId,category:question.category,difficulty:question.difficulty,questionId:question.questionId,question:question.question,options:question.options,correctOptionId:question.correctOptionId,aliases:question.aliases||[],status:'PREPARING',responses:[],startedAt:null,expiresAt:null,imageReference:null,createdAt:Date.now(),creatorId:uid(ctx),groupName:ctx.groupName||'Grupo'};
  let g;
  try { g=await game.createGame({groupId,gameType:GAME_TYPE,creatorId:uid(ctx),maxPlayers:1,state,timeoutMs:0,metadata:{quizId,roundId},onePerGroup:true}); }
  catch(e){ if(String(e.message).includes('ativa')) return ctx.reply?.(renderBusy()); throw e; }
  await audit('QUIZ_CREATED',state); await event('quiz.created',{quizId,roundId,groupId});
  try {
    await ctx.reply?.(renderPreparing());
    await event('quiz.image.started',{quizId,roundId,groupId});
    const visual=await generateForRound(question,roundId);
    await game.updateGame(g.gameId,groupId,x=>{x.state.imageReference=visual.reference;x.state.imageProvider=visual.provider;x.state.status='READY';return x;});
    const current=game.getGame(g.gameId);
    const text=renderQuestion(current.state);
    if(typeof ctx.sendMessage!=='function') throw new Error('Socket indisponível para envio do Quiz.');
    const sent=await ctx.sendMessage(groupId,{image:await readFile(visual.path),caption:`👻 *FANTASMINHA 11.7.02*\n\n${text}`,sendEphemeral:true});
    await game.startGame(g.gameId,groupId,uid(ctx));
    const startedAt=Date.now(),expiresAt=startedAt+QUIZ_MAX_TIME_MS;
    const activated=await game.updateGame(g.gameId,groupId,x=>{x.state.status='ACTIVE';x.state.startedAt=startedAt;x.state.expiresAt=expiresAt;x.state.messageId=sent?.key||null;return x;});
    await recordHistory({groupId,questionId:question.questionId,category:question.category,difficulty:question.difficulty,quizId});
    await audit('QUIZ_STARTED',activated.state); await event('quiz.started',{quizId,roundId,groupId,expiresAt});
    setTimer(g.gameId,QUIZ_MAX_TIME_MS,()=>finish(g.gameId,groupId,'expired',ctx));
    return {ok:true,gameId:g.gameId,quizId,roundId};
  } catch(e){
    try{clearTimer(g.gameId);const current=game.getGame(g.gameId);if(current)await game.finishGame(g.gameId,groupId,{status:'CANCELLED',reason:'generation_or_send_failed'});await cleanupSession(state);}catch{}
    await audit('QUIZ_IMAGE_FAILED',state,{error:e.message}); await event('quiz.image.failed',{quizId,roundId,groupId,error:e.message});
    await ctx.reply?.(renderError()); return {ok:false,error:true};
  }
}

export async function handleGuess(ctx){
  if(!ctx.isGroup)return {handled:false};
  const g=active(gid(ctx)); if(!g||g.state?.status!=='ACTIVE')return {handled:false};
  const now=Date.now(); if(now>=Number(g.state.expiresAt||0)){await finish(g.gameId,gid(ctx),'expired',ctx);return {handled:true,expired:true};}
  const text=ctx.command==='quizresposta' ? String(ctx.q||ctx.args?.join(' ')||'').trim() : String(ctx.body||ctx.text||'').trim(); if(!text||ctx.command!=='quizresposta'&&text.startsWith(ctx.prefix||'×'))return {handled:false};
  if(!looksLikeQuizAnswer(g.state,text))return {handled:false};
  const result=validateAnswer(g.state,text); if(!result.accepted)return {handled:false};
  let stored=false;
  const answeredAt=Date.now();
  const response=await game.updateGame(g.gameId,gid(ctx),x=>{
    if(x.state.status!=='ACTIVE'||Date.now()>=Number(x.state.expiresAt||0))return x;
    x.state.responses??=[];
    if(x.state.responses.some(r=>r.userId===uid(ctx)))return x;
    const responseTimeMs=Math.max(0,answeredAt-Number(x.state.startedAt||answeredAt));
    const points=result.isCorrect?calculateQuizPoints(responseTimeMs,QUIZ_MAX_TIME_MS,true):0;
    x.state.responses.push({userId:uid(ctx),userName:ctx.pushname||uid(ctx),firstAnswer:text,answeredAt,responseTimeMs,isCorrect:result.isCorrect,points});
    stored=true;return x;
  });
  if(stored){await event('quiz.answer.received',{quizId:response.state.quizId,roundId:response.state.roundId,userId:uid(ctx),isCorrect:result.isCorrect});}
  return {handled:stored,correct:result.isCorrect,stored};
}

async function finish(gameId,groupId,reason,ctx=null){
  if(finalLocks.has(gameId))return finalLocks.get(gameId);
  const promise=(async()=>{
    clearTimer(gameId);
    const g=game.getGame(gameId); if(!g)return null;
    if(g.groupId!==groupId||g.gameType!==GAME_TYPE)return null;
    if(!['ACTIVE','READY','PREPARING','WAITING','RESOLVING'].includes(g.state?.status))return null;
    const responses=g.state.responses||[];
    const correctAnswers=responses.filter(x=>x.isCorrect).sort((a,b)=>b.points-a.points||a.responseTimeMs-b.responseTimeMs);
    const result={quizId:g.state.quizId,roundId:g.state.roundId,correctAnswer:g.state.options.find(o=>o.id===g.state.correctOptionId)?.text||'indisponível',responses:responses.length,correctCount:correctAnswers.length,wrongCount:responses.filter(x=>!x.isCorrect).length,correctAnswers};
    const resolving=await game.updateGame(gameId,groupId,x=>{if(['FINISHED','CANCELLED','EXPIRED'].includes(x.state.status))return x;x.state.status='RESOLVING';x.state.result=result;x.state.finishedAt=x.state.finishedAt||Date.now();x.state.finishReason=reason;return x;}).catch(()=>null);
    if(!resolving||resolving.state.status!=='RESOLVING')return null;
    await audit(reason==='expired'?'QUIZ_EXPIRED':'QUIZ_RESOLVED',resolving.state,{responses:responses.length});
    try { await recordQuizResult({session:resolving.state,responses,groupName:resolving.state.groupName}); } catch(e) { await audit('QUIZ_STATS_FAILED',resolving.state,{error:e.message}); }
    for(const r of responses){try{await stats.recordResult({groupId,userId:r.userId,gameType:GAME_TYPE,result:r.isCorrect?'correct':'incorrect',win:r.isCorrect,loss:!r.isCorrect,score:r.points,xp:r.isCorrect?Math.max(1,Math.floor(r.points/2)):0});}catch{}}
    const final=await game.finishGame(gameId,groupId,{status:'FINISHED',result}).catch(()=>null);
    if(final) for(const r of responses){ await event('GAME_SCORE_FINALIZED',{eventId:`QUIZ:${g.state.quizId}:${r.userId}`,gameId:GAME_TYPE,gameSessionId:g.gameId,groupId,userId:r.userId,points:r.points,won:r.isCorrect,stats:{correctAnswers:r.isCorrect?1:0,wrongAnswers:r.isCorrect?0:1,totalAnswers:1},groupName:g.state.groupName||'Grupo',occurredAt:Date.now()}); }
    await cleanupSession(resolving.state);
    await audit('QUIZ_FINISHED',resolving.state,{responses:responses.length,points:responses.reduce((n,x)=>n+x.points,0)});
    await event('quiz.finished',{...result,groupId,reason});
    if(ctx?.reply)await ctx.reply(renderResult(result,id=>`@${String(id).split('@')[0]}`),{mentions:correctAnswers.map(x=>x.userId)}).catch(()=>{});
    return final||result;
  })().finally(()=>finalLocks.delete(gameId));
  finalLocks.set(gameId,promise);return promise;
}

export async function recover(){
  const activeGames=game.listActiveGames().filter?.(()=>true) || [];
  const quizGames=Array.isArray(activeGames)?activeGames.filter(g=>g.gameType===GAME_TYPE):[];
  await cleanupOrphans(quizGames.map(g=>g.state?.imageReference).filter(Boolean));
  for(const g of quizGames){
    if(g.state?.status==='RESOLVING'){try{await finish(g.gameId,g.groupId,g.state.finishReason||'expired',null);}catch{};continue;}
    if(g.state?.status!=='ACTIVE'||!g.state?.expiresAt){try{await game.finishGame(g.gameId,g.groupId,{status:'CANCELLED',reason:'recovery_invalid_state'});}catch{};continue;}
    const remaining=Number(g.state.expiresAt)-Date.now();
    if(remaining<=0) await finish(g.gameId,g.groupId,'expired',null);
    else setTimer(g.gameId,remaining,()=>finish(g.gameId,g.groupId,'expired',null));
  }
  return quizGames.length;
}
export async function cancelForContext(ctx){const g=active(gid(ctx));if(!g)return{cancelled:false};clearTimer(g.gameId);await game.finishGame(g.gameId,gid(ctx),{status:'CANCELLED',reason:'cancelled_by_context'}).catch(()=>{});await cleanupSession(g.state);await audit('QUIZ_CANCELLED',g.state,{userId:uid(ctx)});return{cancelled:true,gameId:g.gameId};}
export { active, finish };
export default {start,handleGuess,recover,cancelForContext,active,finish,QUIZ_MAX_TIME_MS};
